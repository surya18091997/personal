package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.common.TestUtility;
import com.walmart.benefits.connector.api.model.PayrollBasicDetails;
import com.walmart.benefits.connector.api.model.PayrollFrequencyDetails;
import com.walmart.benefits.connector.api.model.PayrollSuiTaxDetails;
import com.walmart.benefits.connector.api.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PayrollServiceTest {

    @Mock
    private ConnectorRepository dao;

    @InjectMocks
    private PayrollService service;

    /**
     * Test the functionality of the getAssociatePayrollDetails method.
     *
     * @throws Exception if an error occurs during the test
     */
    @Test
    public void testGetAssociatePayrollDetails() throws Exception {
        // Set up the necessary mocks
        var associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var payrollBasicDetails = new ArrayList<PayrollBasicDetails>();
        payrollBasicDetails.add(TestUtility.getPayrollBasicDetails(associateId));
        given(dao.getPayrollPayCenter(associateIds)).willReturn(payrollBasicDetails);

        var payrollPayPeriod = TestUtility.getPayrollPayPeriodDetails(payrollBasicDetails.get(0).getPayCenterId());
        var payCenterIds = List.of(payrollBasicDetails.get(0).getPayCenterId());
        var payrollRunDates =
                List.of(payrollPayPeriod.getBiweeklyPayPeriodEndDate());


        var suiTax = new PayrollSuiTaxDetails();
        suiTax.setAssociateId(associateId);
        suiTax.setPayCenterId(payrollBasicDetails.get(0).getPayCenterId());
        suiTax.setPayrollRunDate(payrollPayPeriod.getBiweeklyPayPeriodEndDate());
        var suiDetails = List.of(suiTax);
        given(dao.getPayrollPayPeriodDetails(
                String.valueOf(LocalDate.now().getYear()))).willReturn(List.of(payrollPayPeriod));

        var payrollEarnings = TestUtility.getEarnings(associateId,
                payCenterIds.get(0), payrollRunDates.get(0));
        given(dao.getPayrollEarnings(associateIds,
                payrollRunDates,
                payCenterIds
                )).willReturn(payrollEarnings);

        var payrollDeductions = TestUtility.getDeductions(associateId,
                payCenterIds.get(0), payrollRunDates.get(0));
        given(dao.getPayrollDeductions(associateIds,
                payrollRunDates,
                payCenterIds)).willReturn(payrollDeductions);

        var payrollHours = TestUtility.getPayrollWorkHours(associateId,
                payCenterIds.get(0), payrollRunDates.get(0));
        given(dao.getPayrollHours(associateIds,
                payrollRunDates,
                payCenterIds)).willReturn(payrollHours);

        // Call the method
        var result = service.getAssociatePayrollDetails(associateIds).get();

        // Verify the results
        assertEquals(payrollBasicDetails.get(0).getPayCenterId(),
                result.get(associateId).get(0).getPayCenterId());
        assertEquals(payrollPayPeriod.getBiweeklyPayPeriodStartDate(), result.get(associateId).get(0).getPayPeriodStartDate());
        assertEquals(payrollPayPeriod.getBiweeklyPayPeriodEndDate(), result.get(associateId).get(0).getPayPeriodEndDate());
        assertEquals(payrollEarnings.size(), result.get(associateId).get(0).getEarnings().size());
        assertEquals(payrollDeductions.size(), result.get(associateId).get(0).getDeductions().size());
        assertEquals(payrollHours.size(), result.get(associateId).get(0).getHours().size());
    }


    @Test
    public void testGetAndMapPayrollHours_EmptyPayrollHoursList() {
        // Arrange
        var associateId = "12345678";
        List<String> associateIds = new ArrayList<>();
        List<String> payrollRunDates = new ArrayList<>();
        List<String> payCenterIds = new ArrayList<>();
        HashMap<String, PayrollInfo> associatePayrollMap = new HashMap<>();

        // Mock the DAO to return null
        when(dao.getPayrollHours(any(), any(), any())).thenReturn(new ArrayList<>());

        // Act
        CompletableFuture<Void> result = service.getAndMapPayrollHours(
                associateIds,
                payrollRunDates,
                payCenterIds,
                associatePayrollMap
        );

        // Assert
        assertNull(associatePayrollMap.get(associateId));
    }

    @Test
    public void testGetAndMapPayrollHours_NullPayrollHoursList() {
        // Arrange
        var associateId = "12345678";
        List<String> associateIds = new ArrayList<>();
        List<String> payrollRunDates = new ArrayList<>();
        List<String> payCenterIds = new ArrayList<>();
        HashMap<String, PayrollInfo> associatePayrollMap = new HashMap<>();

        // Mock the DAO to return null
        when(dao.getPayrollHours(any(), any(), any())).thenReturn(null);

        // Act
        CompletableFuture<Void> result = service.getAndMapPayrollHours(
                associateIds,
                payrollRunDates,
                payCenterIds,
                associatePayrollMap
        );

        // Assert
        assertNull(associatePayrollMap.get(associateId));
    }

    @Test
    public void testGetAssociatePayrollDetails_FilteredPayPeriod() throws Exception {
        // Arrange
        var associateId1 = "12345678";
        var associateId2 = "87654321";
        var associateIds = List.of(associateId1, associateId2);

        var payrollBasicDetails1 = TestUtility.getPayrollBasicDetails(associateId1);
        payrollBasicDetails1.setPayCenterId("PC1");
        payrollBasicDetails1.setPayrollRunDate(LocalDate.now());

        var payrollBasicDetails2 = TestUtility.getPayrollBasicDetails(associateId2);
        payrollBasicDetails2.setPayCenterId(null); // Invalid payCenterId

        var payrollBasicDetailsList = List.of(payrollBasicDetails1, payrollBasicDetails2);
        given(dao.getPayrollPayCenter(associateIds)).willReturn(payrollBasicDetailsList);

        // Act
        var result = service.getAssociatePayrollDetails(associateIds).get();

        // Assert
        assertEquals(1, result.size()); // Only associateId1 should be processed
        assertEquals("PC1", result.get(associateId1).get(0).getPayCenterId());
        assertNull(result.get(associateId2)); // associateId2 should be filtered out
    }


    @Test
    public void testGetAssociatePayrollDetails_EarningsForAssociateWithNullPayrollRunDate() throws Exception {
        // Arrange
        var associateId1 = "12345678";
        var associateId2 = "87654321";
        var associateIds = List.of(associateId1, associateId2);

        var payrollBasicDetails1 = TestUtility.getPayrollBasicDetails(associateId1);
        payrollBasicDetails1.setPayCenterId("PC1");
        payrollBasicDetails1.setPayrollRunDate(LocalDate.now());

        var payrollBasicDetails2 = TestUtility.getPayrollBasicDetails(associateId2);
        payrollBasicDetails2.setPayCenterId("PC2");
        payrollBasicDetails2.setPayrollRunDate(null); // Valid case as payrollRunDate can be null

        var payrollBasicDetailsList = List.of(payrollBasicDetails1, payrollBasicDetails2);
        given(dao.getPayrollPayCenter(associateIds)).willReturn(payrollBasicDetailsList);

        var payrollEarnings = TestUtility.getEarnings(associateId1, "PC1", LocalDate.now().toString());
        given(dao.getPayrollEarnings(any(), any(), any())).willReturn(payrollEarnings);


        // Act
        var result = service.getAssociatePayrollDetails(associateIds).get();

        // Assert
        assertEquals(2, result.size()); // Both associateId1 and associateId2 should be processed
        assertEquals("PC1", result.get(associateId1).get(0).getPayCenterId());
        assertEquals("PC2", result.get(associateId2).get(0).getPayCenterId()); // associateId2 should still be included
        assertNull(result.get(associateId2).get(0).getPayrollRunDate()); // payrollRunDate is null for associateId2

        // Verify earnings for associateId2 is null
        assertNull(result.get(associateId2).get(0).getEarnings());
    }
}