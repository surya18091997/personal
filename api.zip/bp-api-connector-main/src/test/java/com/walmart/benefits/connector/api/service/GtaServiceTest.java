package com.walmart.benefits.connector.api.service;

import com.walmart.benefitsplatformentitymodel.interdomain.gta.GtaInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class GtaServiceTest {

    @InjectMocks
    private GtaService service;

    @Test
    public void testGetGTAInfo(){
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);

        GtaInfo gtaInfo =
                service.getGTAInfo(associateIds);
        assertNull(gtaInfo);
    }
}