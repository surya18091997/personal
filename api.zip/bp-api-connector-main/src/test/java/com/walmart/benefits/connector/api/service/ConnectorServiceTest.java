package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.model.AssociateUpstreamDetails;
import com.walmart.benefitsplatformentitymodel.interdomain.gta.GtaInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.PersonalInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Deduction;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Earning;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.BDDMockito.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@ExtendWith(MockitoExtension.class)
public class ConnectorServiceTest {

    @Mock
    private CoreHrService coreHrService;

    @Mock
    private PayrollService payrollService;

    @Mock
    private GtaService gtaService;

    @InjectMocks
    private ConnectorService service;

    private List<PayrollInfo> setExpectedPayrollInfo() {
        var expectedPayrollInfoList = new ArrayList<PayrollInfo>();
        var expectedPayrollInfo = new PayrollInfo();
        expectedPayrollInfo.setPayCenterId("1");
        expectedPayrollInfo.setPayrollRunDate(LocalDate.parse("2024-10-06").toString());
        var earnings = new ArrayList<Earning>();
        var earning = new Earning();
        earning.setAmount(123.0);
        earnings.add(earning);
        expectedPayrollInfo.setEarnings(earnings);

        var deductions = new ArrayList<Deduction>();
        var deduction = new Deduction();
        deduction.setCurrentAmount(123.00);
        deduction.setType("KH");
        deductions.add(deduction);
        expectedPayrollInfo.setDeductions(deductions);
        expectedPayrollInfoList.add(expectedPayrollInfo);
        return expectedPayrollInfoList;
    }

    private AssociateInfo setExpectedAssociateInfo(String associateId) {
        var expectedAssociateInfo = new AssociateInfo();
        expectedAssociateInfo.setAssociateId(associateId);
        var contact = new Contact();
        contact.setPhoneNumber("12345567890");
        expectedAssociateInfo.setContact(contact);
        var personalInfo = new PersonalInfo();
        personalInfo.setCountryCode("US");
        expectedAssociateInfo.setPersonalInfo(personalInfo);
        return expectedAssociateInfo;
    }

    @Test
    public void QueryAssociateUpstreamDetails_MapsAssociateInfoCorrectly() throws Exception {
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);

        var expectedAssociateInfo = setExpectedAssociateInfo(associateId);
        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, expectedAssociateInfo);

        CompletableFuture<Map<String, AssociateInfo>> aiFuture =
                CompletableFuture.completedFuture(associateInfoMap);

        given(coreHrService.getAssociateHrDetails(associateIds)).willReturn(aiFuture);

        Set<String> requestedFields = new HashSet<String>();
        requestedFields.add("associateInfo");
        AssociateUpstreamDetails result =
                service.queryAssociateUpstreamDetails(associateId, requestedFields);

        assertEquals(expectedAssociateInfo.getAssociateId(),
                result.getAssociateInfo().getAssociateId());
        assertEquals(expectedAssociateInfo.getContact().getPhoneNumber(),
                result.getAssociateInfo().getContact().getPhoneNumber());
        assertEquals(expectedAssociateInfo.getPersonalInfo().getCountryCode(),
                result.getAssociateInfo().getPersonalInfo().getCountryCode());
    }

    @Test
    public void QueryAssociateUpstreamDetails_MapsPayrollInfoCorrectly() throws Exception {
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);

        var expectedPayrollInfo = setExpectedPayrollInfo();
        var payrollInfoMap = new HashMap<String, List<PayrollInfo>>();
        payrollInfoMap.put(associateId, expectedPayrollInfo);

        CompletableFuture<Map<String, List<PayrollInfo>>> piFuture =
                CompletableFuture.completedFuture(payrollInfoMap);

        given(payrollService.getAssociatePayrollDetails(associateIds)).willReturn(piFuture);

        Set<String> requestedFields = new HashSet<String>();
        requestedFields.add("payrollInfo");
        AssociateUpstreamDetails result =
                service.queryAssociateUpstreamDetails(associateId, requestedFields);

        assertEquals(expectedPayrollInfo.get(0).getEarnings().size(),
                result.getPayrollInfo().get(0).getEarnings().size());
        assertEquals(expectedPayrollInfo.get(0).getDeductions().size(),
                result.getPayrollInfo().get(0).getDeductions().size());
        assertEquals(expectedPayrollInfo.get(0).getEarnings().get(0).getAmount(),
                result.getPayrollInfo().get(0).getEarnings().get(0).getAmount());
        assertEquals(expectedPayrollInfo.get(0).getDeductions().get(0).getCurrentAmount(),
                result.getPayrollInfo().get(0).getDeductions().get(0).getCurrentAmount());
    }
}