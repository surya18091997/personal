package com.walmart.benefits.connector.api.controller;

import com.walmart.benefits.connector.api.model.AssociateUpstreamDetails;
import com.walmart.benefits.connector.api.service.ConnectorService;
import com.walmart.benefits.connector.api.validator.AssociateQueryValidator;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.SelectedField;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AssociateQueryControllerTest {

    @Mock
    private AssociateQueryValidator validator;

    @Mock
    private ConnectorService service;

    @InjectMocks
    private AssociateQueryController controller;

    @Mock
    private DataFetchingEnvironment mockEnv;

    @Mock
    private DataFetchingFieldSelectionSet mockSelectionSet;

    @BeforeEach
    public void setUp() {
        when(mockEnv.getSelectionSet()).thenReturn(mockSelectionSet);
    }

    @Test
    public void queryAssociateUpstreamDetails_returnsNull_whenAssociateIdNotFound() throws Exception {
        // Arrange
        String associateId = "nonexistent";
        Set<String> requestedFields = new HashSet<>();
        requestedFields.add("payrollInfo");
        requestedFields.add("associateInfo");

        List<SelectedField> selectedFields = requestedFields.stream()
                .map(field -> {
                    SelectedField selectedField = Mockito.mock(SelectedField.class);
                    when(selectedField.getName()).thenReturn(field);
                    return selectedField;
                })
                .collect(Collectors.toList());

        when(mockSelectionSet.getFields()).thenReturn(selectedFields);

        doNothing().when(validator).ValidateAssociateInput(associateId);
        when(service.queryAssociateUpstreamDetails(associateId, requestedFields)).thenReturn(null);

        // Act
        AssociateUpstreamDetails actualResult = controller.queryAssociateUpstreamDetails(associateId, mockEnv);

        // Assert
        assertEquals(null, actualResult);
    }

    @Test
    public void queryMultipleAssociateUpstreamDetails_returnsEmptyList_whenNoAssociateIdsProvided() throws Exception {
        // Arrange
        List<String> associateIds = List.of();
        Set<String> requestedFields = new HashSet<>();
        requestedFields.add("payrollInfo");
        requestedFields.add("associateInfo");

        List<SelectedField> selectedFields = requestedFields.stream()
                .map(field -> {
                    SelectedField selectedField = Mockito.mock(SelectedField.class);
                    when(selectedField.getName()).thenReturn(field);
                    return selectedField;
                })
                .collect(Collectors.toList());

        when(mockSelectionSet.getFields()).thenReturn(selectedFields);

        doNothing().when(validator).ValidateAssociatesInput(associateIds);
        when(service.queryAssociateUpstreamDetails(associateIds, requestedFields)).thenReturn(List.of());

        // Act
        List<AssociateUpstreamDetails> actualResult = controller.queryMultipleAssociateUpstreamDetails(associateIds, mockEnv);

        // Assert
        assertEquals(List.of(), actualResult);
    }
}