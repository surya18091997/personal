package com.walmart.benefits.connector.api.validator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.List;

public class AssociateQueryValidatorTest {

    private final AssociateQueryValidator validator = new AssociateQueryValidator();

    @Test
    public void testValidateAssociateInput_ValidAssociateId() {
        // Arrange
        String associateId = "12345678";

        // Act
        validator.ValidateAssociateInput(associateId);

        // Assert
        // No Exception should be thrown
        Assertions.assertEquals("12345678", associateId);

    }

    @Test
    public void testValidateAssociateInput_InvalidAssociateId() {
        // Arrange
        String associateId = "0";

        // Act and Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            validator.ValidateAssociateInput(associateId);
        });
    }

    @Test
    public void testValidateAssociatesInput_NullList() {
        // Arrange
        List<String> associateIds = null;

        // Act and Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            validator.ValidateAssociatesInput(associateIds);
        });
    }

    @Test
    public void testValidateAssociatesInput_EmptyList() {
        // Arrange
        List<String> associateIds = new ArrayList<>();

        // Act and Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            validator.ValidateAssociatesInput(associateIds);
        });
    }

    @Test
    public void testValidateAssociatesInput_ValidList() {
        // Arrange
        List<String> associateIds = List.of("12345678", "87654321");

        // Act
        validator.ValidateAssociatesInput(associateIds);

        // Assert
        // No Exception should be thrown
        Assertions.assertEquals(2, associateIds.size());
    }

    @Test
    public void testValidateAssociatesInput_InvalidList() {
        // Arrange
        List<String> associateIds = List.of("0", "12345678");

        // Act and Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            validator.ValidateAssociatesInput(associateIds);
        });
    }

    @Test
    public void testValidateAssociatesInput_InvalidList_CountExceeds() {
        // Arrange
        List<String> associateIds = List.of(
                "12345671", "12345672", "12345673", "12345674", "12345675",
                "12345676", "12345677", "12345678", "12345679", "12345680",
                "12345681", "12345682", "12345683", "12345684", "12345685",
                "12345686", "12345687", "12345688", "12345689", "12345690",
                "12345691", "12345692", "12345693", "12345694", "12345695"
        );

        // Act and Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            validator.ValidateAssociatesInput(associateIds);
        });
    }
}