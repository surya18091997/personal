package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.common.TestUtility;
import com.walmart.benefits.connector.api.model.AddressWithAssociateId;
import com.walmart.benefits.connector.api.model.HireRescindDetails;
import com.walmart.benefits.connector.api.model.ManagementTraineeDetails;
import com.walmart.benefits.connector.api.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.*;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Address;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class CoreHrServiceTest {

    @Mock
    private ConnectorRepository dao;

    @InjectMocks
    private CoreHrService service;

    @Test
    public void testGetAssociateHrDetails() throws Exception {
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var expectedAssociateInfo = new ArrayList<AssociateInfo>();
        expectedAssociateInfo.add(TestUtility.getExpectedAssociateInfo(associateId));
        var expectedEmploymentHistory =
                TestUtility.getExpectedEmploymentHistory(associateId);
        var expectedOtherPosition =
                TestUtility.getExpectedOtherPositionDetails(associateId);
        var expectedPrimaryPosition =
                TestUtility.getExpectedPrimaryPositionDetails(associateId);

        given(dao.getAssociateDetailsFromCoreHr(associateIds)).willReturn(expectedAssociateInfo);
        given(dao.getEmploymentHistory(associateIds)).willReturn(expectedEmploymentHistory);
        given(dao.getOtherPositionDetails(associateIds)).willReturn(expectedOtherPosition);
        given(dao.getPrimaryPositionDetails(associateIds)).willReturn(expectedPrimaryPosition);

        CompletableFuture<Map<String, AssociateInfo>> aiFuture =
                service.getAssociateHrDetails(associateIds);


        AssociateInfo result = aiFuture.get().get(associateId);

        assertEquals(expectedAssociateInfo.get(0).getAssociateId(),
                result.getAssociateId());
        assertEquals(expectedAssociateInfo.get(0).getContact().getPhoneNumber(),
                result.getContact().getPhoneNumber());
        assertEquals(expectedAssociateInfo.get(0).getPersonalInfo().getCountryCode(),
                result.getPersonalInfo().getCountryCode());
        assertEquals(expectedAssociateInfo.get(0).getEmployment().getEmploymentHistory().get(0).getHireDate(),
                result.getEmployment().getEmploymentHistory().get(0).getHireDate());
        assertEquals(expectedAssociateInfo.get(0).getEmployment().getEmploymentHistory().get(0).getPayRateType(),
                result.getEmployment().getEmploymentHistory().get(0).getPayRateType());
        assertEquals(expectedAssociateInfo.get(0).getEmployment().getPrimaryPositionInfo().getPositionId(),
                result.getEmployment().getPrimaryPositionInfo().getPositionId());
        assertEquals(expectedAssociateInfo.get(0).getEmployment().getPrimaryPositionInfo().getJobId(),
                result.getEmployment().getPrimaryPositionInfo().getJobId());
    }

    @Test
    public void testGetAssociateHrDetails_CallsGetAssociateDetailsFromCoreHr() {
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var expectedAssociateInfo = new ArrayList<AssociateInfo>();
        expectedAssociateInfo.add(TestUtility.getExpectedAssociateInfo(associateId));

        var expectedEmploymentHistory =
                TestUtility.getExpectedEmploymentHistory(associateId);
        var expectedOtherPosition =
                TestUtility.getExpectedOtherPositionDetails(associateId);
        var expectedPrimaryPosition = TestUtility.getExpectedPrimaryPositionDetails(associateId);

        given(dao.getAssociateDetailsFromCoreHr(associateIds)).willReturn(expectedAssociateInfo);
        given(dao.getEmploymentHistory(associateIds)).willReturn(expectedEmploymentHistory);
        given(dao.getOtherPositionDetails(associateIds)).willReturn(expectedOtherPosition);
        given(dao.getPrimaryPositionDetails(associateIds)).willReturn(expectedPrimaryPosition);

        service.getAssociateHrDetails(associateIds);

        verify(dao, times(1)).getAssociateDetailsFromCoreHr(associateIds);
    }

    @Test
    public void testGetAndMapEmploymentHistory() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var expectedAssociateInfo = new ArrayList<AssociateInfo>();
        expectedAssociateInfo.add(TestUtility.getExpectedAssociateInfo(associateId));
        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, TestUtility.getExpectedAssociateInfo(associateId));
        var expectedEmploymentHistory =
                TestUtility.getExpectedEmploymentHistory(associateId);

        given(dao.getAssociateDetailsFromCoreHr(associateIds)).willReturn(expectedAssociateInfo);
        given(dao.getEmploymentHistory(associateIds)).willReturn(expectedEmploymentHistory);

        // Act
        CompletableFuture<Void> result =
                service.getAndMapEmploymentHistory(associateIds,
                        associateInfoMap);

        // Assert
        result.join();
        assertEquals(expectedEmploymentHistory.get(0).getEmploymentHistory(),
                service.getAssociateHrDetails(associateIds).join().get(associateId).getEmployment().getEmploymentHistory().get(0));
    }

    @Test
    public void testGetAndMapPrimaryAndOtherPositionsDetails() throws Exception {

        // Create test data
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var expectedAssociateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, expectedAssociateInfo);

        var otherPositions = TestUtility.getExpectedOtherPositionDetails(associateId);
        var primaryPosition = TestUtility.getExpectedPrimaryPositionDetails(associateId);

        // Mock the DAO behavior
        given(dao.getOtherPositionDetails(associateIds)).willReturn(otherPositions);
        given(dao.getPrimaryPositionDetails(associateIds)).willReturn(primaryPosition);

        // Call the method under test
        CompletableFuture<Void> future =
                service.getAndMapPrimaryAndOtherPositionsDetails(associateIds,
                        associateInfoMap);
        future.get();

        // Assert the expected behavior
        assertNotNull(expectedAssociateInfo.getEmployment().getPrimaryPositionInfo());
        assertEquals(primaryPosition.get(0).getPrimaryPositionInfo().getJobId(),
                expectedAssociateInfo.getEmployment().getPrimaryPositionInfo().getJobId());
        assertEquals(primaryPosition.get(0).getPrimaryPositionInfo().getJobEndDate(), expectedAssociateInfo.getEmployment().getPrimaryPositionInfo().getJobEndDate());
        assertEquals(1, expectedAssociateInfo.getEmployment().getOtherPositions().size());
        assertEquals(otherPositions.get(0).getOtherPositions().getJobId(),
                expectedAssociateInfo.getEmployment().getOtherPositions().get(0).getJobId());
        assertEquals(otherPositions.get(0).getOtherPositions().getJobEndDate(), expectedAssociateInfo.getEmployment().getOtherPositions().get(0).getJobEndDate());
    }

    @Test
    void testGetAndMapAddressDetails() throws Exception {
        // Given
        CoreHrService service = new CoreHrService(dao);
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        var addressDetails = new ArrayList<AddressWithAssociateId>();
        var address = new AddressWithAssociateId();
        address.setAssociateId(associateId);
        address.setAddress(new Address());
        address.getAddress().setAddressType("Home");
        address.getAddress().setZip("123456");
        addressDetails.add(address);
        given(dao.getAddressDetails(associateIds)).willReturn(addressDetails);

        // When
        CompletableFuture<Void> result =
                service.getAndMapAddressDetails(associateIds, associateInfoMap);

        // Then
        assertEquals(addressDetails.get(0).getAddress().getZip(),
                associateInfo.getAddress().get(0).getZip());
        assertEquals(addressDetails.get(0).getAddress().getAddressType(),
                associateInfo.getAddress().get(0).getAddressType());
    }

    @Test
    public void testGetAndMapHireRescind_HireRescinded() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId, CommonConstants.YES);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId,
                associateInfo);
        associateInfo.setEmployment(new Employment());
        var hireRescindIndicatorList = new ArrayList<HireRescindDetails>();
        var hireRescindIndicator = new HireRescindDetails();
        hireRescindIndicator.setAssociateId(associateId);
        hireRescindIndicator.setRescindIndicator(CommonConstants.YES);
        hireRescindIndicatorList.add(hireRescindIndicator);
        associateInfo.getEmployment().setHireRescinded(true);
        given(dao.getHireRescindIndicator(associateIds)).willReturn(hireRescindIndicatorList);

        // Act
        CompletableFuture<Void> result =
                service.getAndMapHireRescind(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertTrue(associateInfoMap.get(associateId).getEmployment().isHireRescinded());
    }

    @Test
    public void testGetAndMapHireRescind_NotHireRescinded() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        associateInfo.setEmployment(new Employment());
        var hireRescindIndicatorList = new ArrayList<HireRescindDetails>();
        var hireRescindIndicator = new HireRescindDetails();
        hireRescindIndicator.setAssociateId(associateId);
        hireRescindIndicator.setRescindIndicator("N");
        given(dao.getHireRescindIndicator(associateIds)).willReturn(hireRescindIndicatorList);

        // Act
        CompletableFuture<Void> result =
                service.getAndMapHireRescind(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertFalse(associateInfoMap.get(associateId).getEmployment().isHireRescinded());
    }

    @Test
    public void testGetAndMapHireRescind_NoHireRescindIndicator() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        associateInfo.setEmployment(new Employment());
        var hireRescindIndicatorList = new ArrayList<HireRescindDetails>();
        var hireRescindIndicator = new HireRescindDetails();
        hireRescindIndicator.setAssociateId(associateId);
        hireRescindIndicator.setRescindIndicator(null);
        given(dao.getHireRescindIndicator(associateIds)).willReturn(hireRescindIndicatorList);

        // Act
        CompletableFuture<Void> result =
                service.getAndMapHireRescind(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertFalse(associateInfoMap.get(associateId).getEmployment().isHireRescinded());
    }

    @Test
    public void testGetAndMapIsManagementTrainee_IsManagementTrainee() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        associateInfo.setEmployment(new Employment());

        var managementTraineeList = new ArrayList<ManagementTraineeDetails>();
        var managementTraineeDetails = new ManagementTraineeDetails();
        managementTraineeDetails.setAssociateId(associateId);
        managementTraineeDetails.setIsManagementTrainee(true);
        managementTraineeList.add(managementTraineeDetails);

        given(dao.isManagementTrainee(associateIds)).willReturn(managementTraineeList);

        // Act
        CompletableFuture<Void> result = service.getAndMapIsManagementTrainee(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertTrue(associateInfoMap.get(associateId).getEmployment().getIsManagementTrainee());
    }

    @Test
    public void testGetAndMapIsManagementTrainee_NotManagementTrainee() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        associateInfo.setEmployment(new Employment());

        var managementTraineeList = new ArrayList<ManagementTraineeDetails>();
        var managementTraineeDetails = new ManagementTraineeDetails();
        managementTraineeDetails.setAssociateId(associateId);
        managementTraineeDetails.setIsManagementTrainee(false);
        managementTraineeList.add(managementTraineeDetails);

        given(dao.isManagementTrainee(associateIds)).willReturn(managementTraineeList);

        // Act
        CompletableFuture<Void> result = service.getAndMapIsManagementTrainee(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertFalse(associateInfoMap.get(associateId).getEmployment().getIsManagementTrainee());
    }

    @Test
    public void testGetAndMapIsManagementTrainee_NoIndicator() {
        // Arrange
        String associateId = "12345678";
        var associateIds = new ArrayList<String>();
        associateIds.add(associateId);
        var associateInfo = TestUtility.getExpectedAssociateInfo(associateId);

        var associateInfoMap = new HashMap<String, AssociateInfo>();
        associateInfoMap.put(associateId, associateInfo);
        associateInfo.setEmployment(new Employment());

        var managementTraineeList = new ArrayList<ManagementTraineeDetails>();

        given(dao.isManagementTrainee(associateIds)).willReturn(managementTraineeList);

        // Act
        CompletableFuture<Void> result = service.getAndMapIsManagementTrainee(associateIds, associateInfoMap);
        result.join();

        // Assert
        assertNull(associateInfoMap.get(associateId).getEmployment().getIsManagementTrainee());
    }
}
