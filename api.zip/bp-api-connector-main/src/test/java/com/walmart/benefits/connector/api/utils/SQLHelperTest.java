package com.walmart.benefits.connector.api.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.springframework.dao.EmptyResultDataAccessException;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SQLHelperTest {

    /**
     * Test the functionality of the getTextOrDefault method.
     *
     * @throws SQLException              if an error occurs while accessing the ResultSet
     * @throws EmptyResultDataAccessException if the ResultSet is empty
     */
    @Test
    public void testGetTextOrDefault() throws SQLException, EmptyResultDataAccessException {
        // Create a mock ResultSet
        ResultSet rs = Mockito.mock(ResultSet.class);

        // Mock the behavior of the ResultSet
        Mockito.when(rs.getString("columnName")).thenReturn("value");

        // Create an instance of the SQLHelper class
        SQLHelper sqlHelper = new SQLHelper();

        // Call the getTextOrDefault method
        String result = sqlHelper.getTextOrDefault("columnName", rs);

        // Verify the result
        Assertions.assertEquals("value", result);
    }

    @Test
    public void testGetTextOrDefaultWithNullValue() throws SQLException,
            EmptyResultDataAccessException {
        // Create a mock ResultSet
        ResultSet rs = Mockito.mock(ResultSet.class);

        // Mock the behavior of the ResultSet
        Mockito.when(rs.getString("columnName")).thenReturn(null);

        // Create an instance of the SQLHelper class
        SQLHelper sqlHelper = new SQLHelper();

        // Call the getTextOrDefault method
        String result = sqlHelper.getTextOrDefault("columnName", rs);

        // Verify the result
        Assertions.assertEquals("", result);
    }
}