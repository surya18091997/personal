package com.walmart.benefits.connector.api.common;

import com.walmart.benefits.connector.api.model.*;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.*;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.*;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Address;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TestUtility {

    /**
     * Sets the expected employment history.
     *
     * @return the list of employment history records
     */
    public static List<EmploymentHistoryWithAssociateId> getExpectedEmploymentHistory(String associateId) {
        var expectedEmpHistory = new ArrayList<EmploymentHistoryWithAssociateId>();
        var empHistoryRecord = new EmploymentHistoryWithAssociateId();
        empHistoryRecord.setAssociateId(associateId);
        empHistoryRecord.setEmploymentHistory(new EmploymentHistory());
        empHistoryRecord.getEmploymentHistory().setHireDate("2024-10-01");
        empHistoryRecord.getEmploymentHistory().setPositionType("2024-10-01");
        empHistoryRecord.getEmploymentHistory().setPayRateType("H");
        empHistoryRecord.getEmploymentHistory().setTermDate("");
        expectedEmpHistory.add(empHistoryRecord);
        return expectedEmpHistory;
    }

    /**
     * Sets the expected primary position details.
     *
     * @return the primary position information
     */
    public static List<OtherPositionWithAssociateId> getExpectedOtherPositionDetails(String associateId) {
        var positions = new ArrayList<OtherPositionWithAssociateId>();
        var position = new OtherPositionWithAssociateId();
        position.setAssociateId(associateId);
        position.setOtherPositions(new OtherPositions());
        position.getOtherPositions().setPositionId("P_US_123456");
        position.getOtherPositions().setJobId("US-01-123456");
        position.getOtherPositions().setJobClassification("");
        position.getOtherPositions().setJobEffectiveDate("2024-10-01");
        position.getOtherPositions().setJobEndDate("");
        positions.add(position);

        var position2 = new OtherPositionWithAssociateId();
        position2.setAssociateId(associateId);
        position2.setOtherPositions(new OtherPositions());
        position2.getOtherPositions().setPositionId("P_US_12345");
        position2.getOtherPositions().setJobId("US-01-123457");
        position2.getOtherPositions().setJobClassification("");
        position2.getOtherPositions().setJobEffectiveDate("2024-10-02");
        position2.getOtherPositions().setJobEndDate("");

        positions.add(position2);
        return positions;
    }

    /**
     * Sets the expected primary position details.
     *
     * @return the primary position information
     */
    public static List<PrimaryPositionWithAssociateId> getExpectedPrimaryPositionDetails(String associateId) {
        var primaryPositions = new ArrayList<PrimaryPositionWithAssociateId>();
        var position = new PrimaryPositionWithAssociateId();
        position.setAssociateId(associateId);
        position.setPrimaryPositionInfo(new PrimaryPositionInfo());
        position.getPrimaryPositionInfo().setPositionId("P_US_12345");
        position.getPrimaryPositionInfo().setJobId("US-01-123457");
        position.getPrimaryPositionInfo().setJobClassification("");
        position.getPrimaryPositionInfo().setJobEffectiveDate("2024-10-02");
        position.getPrimaryPositionInfo().setJobEndDate("");
        primaryPositions.add(position);
        return primaryPositions;
    }

    /**
     * Sets the expected associate information.
     *
     * @param  associateId    the ID of the associate
     * @return                the expected associate information
     */
    public static AssociateInfo getExpectedAssociateInfo(String associateId) {
        var expectedAssociateInfo = new AssociateInfo();
        expectedAssociateInfo.setAssociateId(associateId);
        var contact = new Contact();
        contact.setPhoneNumber("12345567890");
        expectedAssociateInfo.setContact(contact);
        var personalInfo = new PersonalInfo();
        personalInfo.setCountryCode("US");
        expectedAssociateInfo.setPersonalInfo(personalInfo);
        var empInfo = new Employment();
        empInfo.setPayrollFrequency(PayrollFrequency.BI_WEEKLY);
        empInfo.setHireDate("2024-10-01");
        empInfo.setPayRateType("S");
        expectedAssociateInfo.setEmployment(empInfo);
        var address = new Address();
        address.setAddressType("Home");
        address.setZip("123456");
        expectedAssociateInfo.setAddress(List.of(address));
        return expectedAssociateInfo;
    }

    /**
     * Sets the expected associate information.
     *
     * @param  associateId    the ID of the associate
     * @param  hireRescindIndicator Hire Rescind Indicator
     * @return                the expected associate information
     */
    public static AssociateInfo getExpectedAssociateInfo(String associateId,
                                                         String hireRescindIndicator) {
        var expectedAssociateInfo = new AssociateInfo();
        expectedAssociateInfo.setAssociateId(associateId);
        var contact = new Contact();
        contact.setPhoneNumber("12345567890");
        expectedAssociateInfo.setContact(contact);
        var personalInfo = new PersonalInfo();
        personalInfo.setCountryCode("US");
        expectedAssociateInfo.setPersonalInfo(personalInfo);
        var empInfo = new Employment();
        empInfo.setPayrollFrequency(PayrollFrequency.BI_WEEKLY);
        empInfo.setHireDate("2024-10-01");
        empInfo.setPayRateType("S");
        empInfo.setHireRescinded(hireRescindIndicator.equals(CommonConstants.YES));
        expectedAssociateInfo.setEmployment(empInfo);
        var address = new Address();
        address.setAddressType("Home");
        address.setZip("123456");
        expectedAssociateInfo.setAddress(List.of(address));
        return expectedAssociateInfo;
    }

    /**
     * Returns a PayrollBasicDetails object with a pre-set PayCenterId and PayrollRunDate.
     *
     * @return a PayrollBasicDetails object
     */
    @NotNull
    public static PayrollBasicDetails getPayrollBasicDetails(String associateId) {
        var payrollPayCenter = new PayrollBasicDetails();
        payrollPayCenter.setAssociateId(associateId);
        payrollPayCenter.setPayCenterId("1");
        payrollPayCenter.setPayrollRunDate(LocalDate.now());
        return payrollPayCenter;
    }

    /**
     * Returns a PayrollPayPeriodDetails object with default values.
     *
     * @return a PayrollPayPeriodDetails object
     */
    @NotNull
    public static PayrollPayPeriodDetails getPayrollPayPeriodDetails(String payCenterId) {
        String today = LocalDate.now().toString();
        var payrollPayPeriod = new PayrollPayPeriodDetails();
        payrollPayPeriod.setPayCenterId(payCenterId);
        payrollPayPeriod.setCurrencyCode("UD");
        payrollPayPeriod.setWeeklyPayPeriodStartDate(today);
        payrollPayPeriod.setWeeklyPayPeriodEndDate(today);
        payrollPayPeriod.setBiweeklyPayPeriodStartDate(today);
        payrollPayPeriod.setBiweeklyPayPeriodEndDate(today);
        payrollPayPeriod.setRemainingPayPeriods(1);
        return payrollPayPeriod;
    }

    /**
     * Returns a list of Earning objects.
     *
     * @return a list of Earning objects
     */
    @NotNull
    public static List<EarningWithAssociateId> getEarnings(String associateId, String payCenterId, String payrollRunDate) {
        var payrollEarnings = new ArrayList<EarningWithAssociateId>();
        var earning = new EarningWithAssociateId();
        earning.setAssociateId(associateId);
        earning.setPayCenterId(payCenterId);
        earning.setPayrollRunDate(payrollRunDate);
        earning.setEarning(new Earning());
        earning.getEarning().setType(EarningType.REGULAR);
        earning.getEarning().setAmount(10.0);
        payrollEarnings.add(earning);
        return payrollEarnings;
    }

    /**
     * Returns a list of Deduction objects.
     *
     * @return a list of Deduction objects
     */
    @NotNull
    public static List<DeductionWithAssociateId> getDeductions(String associateId,
                                                 String payCenterId, String payrollRunDate) {
        var payrollDeductions = new ArrayList<DeductionWithAssociateId>();
        var deduction = new DeductionWithAssociateId();
        deduction.setAssociateId(associateId);
        deduction.setPayCenterId(payCenterId);
        deduction.setPayrollRunDate(payrollRunDate);
        deduction.setDeduction(new Deduction());
        deduction.getDeduction().setCurrentAmount(10.0);
        deduction.getDeduction().setType("KH");
        payrollDeductions.add(deduction);
        return payrollDeductions;
    }

    /**
     * Returns a list of PayrollWorkHours objects with a single element.
     *
     * @return a list of PayrollWorkHours objects
     */
    @NotNull
    public static List<PayrollWorkHoursWithAssociateId> getPayrollWorkHours(String associateId,
                                                                  String payCenterId, String payrollRunDate) {
        var payrollHours = new ArrayList<PayrollWorkHoursWithAssociateId>();
        var hour = new PayrollWorkHoursWithAssociateId();
        hour.setAssociateId(associateId);
        hour.setPayCenterId(payCenterId);
        hour.setPayrollRunDate(payrollRunDate);
        hour.setPayrollWorkHours(new PayrollWorkHours());
        hour.getPayrollWorkHours().setHours(10.0);
        payrollHours.add(hour);
        return payrollHours;
    }

    /**
     * Returns an instance of PayrollInfo with pre-set values.
     *
     * @return an instance of PayrollInfo
     */
    public static List<PayrollInfo> getExpectedPayrollInfo(String associateId) {
        var expectedPayrollInfoList = new ArrayList<PayrollInfo>();
        var expectedPayrollInfo = new PayrollInfo();
        var payrollBasicDetails = TestUtility.getPayrollBasicDetails(associateId);
        var payrollPayPeriod =
                TestUtility.getPayrollPayPeriodDetails(payrollBasicDetails.getPayCenterId());
        var payrollEarnings = TestUtility.getEarnings(associateId,
                payrollBasicDetails.getPayCenterId(),
                payrollBasicDetails.getPayrollRunDate().toString());
        var payrollDeductions = TestUtility.getDeductions(associateId,
                payrollBasicDetails.getPayCenterId(),
                payrollBasicDetails.getPayrollRunDate().toString());
        var payrollHours = TestUtility.getPayrollWorkHours(associateId,
                payrollBasicDetails.getPayCenterId(),
                payrollBasicDetails.getPayrollRunDate().toString());

        var earningMap = payrollEarnings.stream()
                        .collect(Collectors.groupingBy(
                                EarningWithAssociateId::getAssociateId,
                                Collectors.mapping(EarningWithAssociateId::getEarning, Collectors.toList())
                        ));
        var deductionMap = payrollDeductions.stream()
                            .collect(Collectors.groupingBy(
                                    DeductionWithAssociateId::getAssociateId,
                                    Collectors.mapping(DeductionWithAssociateId::getDeduction,
                                            Collectors.toList())
                            ));
        var hourMap = payrollHours.stream()
                        .collect(Collectors.groupingBy(
                                PayrollWorkHoursWithAssociateId::getAssociateId,
                                Collectors.mapping(PayrollWorkHoursWithAssociateId::getPayrollWorkHours
                                        , Collectors.toList())
                        ));

        expectedPayrollInfo.setPayCenterId(payrollBasicDetails.getPayCenterId());
        expectedPayrollInfo.setPayrollRunDate(payrollBasicDetails.getPayrollRunDate().toString());
        expectedPayrollInfo.setPayPeriodEndDate(payrollPayPeriod.getBiweeklyPayPeriodEndDate());
        expectedPayrollInfo.setPayPeriodStartDate(payrollPayPeriod.getBiweeklyPayPeriodStartDate());
        expectedPayrollInfo.setEarnings(earningMap.get(associateId));
        expectedPayrollInfo.setDeductions(deductionMap.get(associateId));
        expectedPayrollInfo.setHours(hourMap.get(associateId));
        expectedPayrollInfoList.add(expectedPayrollInfo);
        return expectedPayrollInfoList;
    }
}
