package com.walmart.benefits.connector.api.utils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.concurrent.ThreadPoolExecutor;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class RetryRejectedExecutionHandlerTest {

    @Mock
    private ThreadPoolExecutor executor;

    @InjectMocks
    private RetryRejectedExecutionHandler retryHandler;

    @Test
    void testRejectedExecution() {
        Runnable task = () -> {
            // Mock task
        };

        retryHandler.rejectedExecution(task, executor);

        // Assertions
        Assertions.assertFalse(executor.isShutdown());
    }

    @Test
    public void testConstructor() {
        long retryDelay = 100L;
        RetryRejectedExecutionHandler handler = new RetryRejectedExecutionHandler(retryDelay);
        assertEquals(retryDelay, handler.retryDelay);
    }
}
