package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.hr.PrimaryPositionInfo;
import lombok.Data;

@Data
public class PrimaryPositionWithAssociateId {
    private String associateId;
    private PrimaryPositionInfo primaryPositionInfo;
}

