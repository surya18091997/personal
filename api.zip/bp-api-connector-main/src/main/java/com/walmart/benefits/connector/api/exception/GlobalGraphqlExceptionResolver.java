package com.walmart.benefits.connector.api.exception;

import com.walmart.benefits.connector.api.common.CommonConstants;
import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import org.springframework.graphql.execution.ErrorType;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletionException;

@Slf4j
@Component
public class GlobalGraphqlExceptionResolver extends DataFetcherExceptionResolverAdapter {

    /**
     * Resolves a single GraphQLError based on the given Throwable and DataFetchingEnvironment.
     *
     * @param  ex          the Throwable to resolve
     * @param  env         the DataFetchingEnvironment
     * @return              the resolved GraphQLError
     */
    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        log.error(ex.getMessage(), ex);
        return switch (ex.getClass().getSimpleName()) {
            case CommonConstants.COMPLETION_EXCEPTION ->
                    handleCompletionException((CompletionException) ex, env);
            case CommonConstants.RESOURCE_NOT_FOUND_EXCEPTION ->
                    handleResourceNotFoundException((ResourceNotFoundException) ex, env);
            case CommonConstants.ILLEGAL_ARGUMENT_EXCEPTION ->
                    handleIllegalArgumentException(env);
            default -> handleGlobalException(env);
        };
    }

    private GraphQLError handleIllegalArgumentException(DataFetchingEnvironment env) {
        return GraphqlErrorBuilder.newError(env)
                .message(CommonConstants.BAD_REQUEST_ERROR)
                .errorType(ErrorType.BAD_REQUEST)
                .build();
    }

    private GraphQLError handleResourceNotFoundException(ResourceNotFoundException ex, DataFetchingEnvironment env) {
        return GraphqlErrorBuilder.newError(env)
                .message(ex.getMessage())
                .errorType(ErrorType.NOT_FOUND)
                .build();
    }

    private GraphQLError handleCompletionException(CompletionException ex, DataFetchingEnvironment env) {
        if (ex.getCause() != null && ex.getCause().getClass() == ResourceNotFoundException.class) {
            return this.handleResourceNotFoundException(new ResourceNotFoundException(ex.getMessage()), env);
        } else{
            return this.handleGlobalException(env);
        }
    }

    private GraphQLError handleGlobalException(DataFetchingEnvironment env) {
        return GraphqlErrorBuilder.newError(env)
                .message(CommonConstants.UNEXPECTED_ERROR)
                .errorType(ErrorType.INTERNAL_ERROR)
                .build();
    }
}