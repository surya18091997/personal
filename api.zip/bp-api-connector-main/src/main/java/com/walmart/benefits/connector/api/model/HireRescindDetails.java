package com.walmart.benefits.connector.api.model;

import lombok.Data;

@Data
public class HireRescindDetails {
    private String associateId;
    private String rescindIndicator;
}
