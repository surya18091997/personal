package com.walmart.benefits.connector.api.controller;

import com.walmart.benefits.connector.api.model.AssociateUpstreamDetails;
import com.walmart.benefits.connector.api.service.ConnectorService;
import com.walmart.benefits.connector.api.validator.AssociateQueryValidator;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.SelectedField;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Controller
public class AssociateQueryController {

    private final ConnectorService service;
    private final AssociateQueryValidator validator;

    /**
     * This method used to get the Associate Upstream Details via GraphQL api
     * @param associateId Associate Id parameter
     * @return returns Associate Upstream Details
     */
    @QueryMapping
    public AssociateUpstreamDetails queryAssociateUpstreamDetails(@Argument String associateId, DataFetchingEnvironment environment) throws InterruptedException, ExecutionException {
        validator.ValidateAssociateInput(associateId);
        Set<String> requestedFields = environment.getSelectionSet().getFields().stream().map(SelectedField::getName).collect(Collectors.toSet());
        return service.queryAssociateUpstreamDetails(associateId, requestedFields);
    }

    /**
     * Retrieves a list of AssociateUpstreamDetails for multiple associate IDs.
     * @param associateIds the list of associate IDs
     * @return the list of AssociateUpstreamDetails
     */
    @QueryMapping
    public List<AssociateUpstreamDetails> queryMultipleAssociateUpstreamDetails(@Argument List<String> associateIds, DataFetchingEnvironment environment) throws InterruptedException, ExecutionException {
        validator.ValidateAssociatesInput(associateIds);
        Set<String> requestedFields = environment.getSelectionSet().getFields().stream().map(SelectedField::getName).collect(Collectors.toSet());
        return service.queryAssociateUpstreamDetails(associateIds, requestedFields);
    }
}
