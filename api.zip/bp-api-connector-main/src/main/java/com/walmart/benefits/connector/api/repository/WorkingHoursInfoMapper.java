package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.gta.WorkingHoursInfo;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

@AllArgsConstructor
@Component
public class WorkingHoursInfoMapper implements RowMapper<WorkingHoursInfo> {

    private final SQLHelper sqlHelper;

    /**
     * this method used to map the WorkingHoursInfo object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns WorkingHoursInfo object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public WorkingHoursInfo mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {

        var profile = new WorkingHoursInfo();
        profile.setWorkingHours(rs.getDouble(ColumnConstants.HOURS_QTY));
        profile.setTimeCode(sqlHelper.getTextOrDefault(ColumnConstants.HOUR_TYPE_CODE,
                rs));
        profile.setLoaIndicator(false);
        profile.setPayrollEndDate(sqlHelper.getTextOrDefault(
                ColumnConstants.PAYROLL_END_DATE, rs));
        return profile;
    }
}
