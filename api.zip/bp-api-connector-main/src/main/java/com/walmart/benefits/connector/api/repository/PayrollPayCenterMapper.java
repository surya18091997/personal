package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.PayrollBasicDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

@AllArgsConstructor
@Component
public class PayrollPayCenterMapper implements RowMapper<PayrollBasicDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to PayrollBasicDetails object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns PayrollBasicDetails object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public PayrollBasicDetails mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var payPeriod = new PayrollBasicDetails();
        payPeriod.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        payPeriod.setPayCenterId(sqlHelper.getTextOrDefault(ColumnConstants.PAY_CENTER_ID, rs));
        String runDateStr = sqlHelper.getTextOrDefault(ColumnConstants.RUN_DATE, rs);
        payPeriod.setPayrollRunDate((runDateStr != null && !runDateStr.isEmpty()) ? LocalDate.parse(runDateStr) : null);
        return payPeriod;
    }
}
