package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.AddressWithAssociateId;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Address;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class AssociateAddressMapper implements RowMapper<AddressWithAssociateId> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to AddressWithAssociateId object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns AddressWithAssociateId object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public AddressWithAssociateId mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var address = new AddressWithAssociateId();
        address.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        address.setAddress(new Address());
        address.getAddress().setAddressLine1(sqlHelper.getTextOrDefault(
                ColumnConstants.LINE_1, rs));
        address.getAddress().setAddressLine2(sqlHelper.getTextOrDefault(
                ColumnConstants.LINE_2, rs));
        address.getAddress().setCity(sqlHelper.getTextOrDefault(
                ColumnConstants.CITY, rs));
        address.getAddress().setCountry(sqlHelper.getTextOrDefault(
                ColumnConstants.COUNTRY_CODE, rs));
        address.getAddress().setStateCode(sqlHelper.getTextOrDefault(
                ColumnConstants.STATE, rs));
        address.getAddress().setZip(sqlHelper.getTextOrDefault(
                ColumnConstants.POSTAL_CODE, rs));
        address.getAddress().setIsPrimary(getIsPrimary(sqlHelper.getTextOrDefault(
                ColumnConstants.IS_PRIMARY, rs)));
        address.getAddress().setAddressType(sqlHelper.getTextOrDefault(
                ColumnConstants.ADDRESS_TYPE, rs));
        return address;
    }

    private boolean getIsPrimary(String isPrimary) {
        return isPrimary.equals(CommonConstants.YES);
    }
}
