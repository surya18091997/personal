package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.EmploymentHistoryWithAssociateId;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.EmploymentHistory;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

@AllArgsConstructor
@Component
public class EmploymentHistoryMapper implements RowMapper<EmploymentHistoryWithAssociateId> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to EmploymentHistory object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns EmploymentHistory object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public EmploymentHistoryWithAssociateId mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var history = new EmploymentHistoryWithAssociateId();
        history.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        history.setEmploymentHistory(new EmploymentHistory());
        history.getEmploymentHistory().setHireDate(sqlHelper.getTextOrDefault(
                ColumnConstants.HIRE_DATE, rs));
        history.getEmploymentHistory().setTermDate(sqlHelper.getTextOrDefault(
                ColumnConstants.TERMINATION_DATE, rs));
        history.getEmploymentHistory().setEmploymentType(sqlHelper.getTextOrDefault(
                ColumnConstants.EMP_STATUS_CODE, rs));
        history.getEmploymentHistory().setPayRateType(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_TYPE_CODE, rs));
        history.getEmploymentHistory().setPositionType(sqlHelper.getTextOrDefault(
                ColumnConstants.ASC_TYPE_CODE, rs));
        var effectiveTs = sqlHelper.getTextOrDefault(ColumnConstants.EFF_TS, rs);
        if(effectiveTs.equals(CommonConstants.STRING_EMPTY)) {
            return history;
        }
        var dateTimeFormatter = new DateTimeFormatterBuilder()
                .appendPattern(CommonConstants.DB2_DATE_FORMAT)
                .appendFraction(ChronoField.NANO_OF_SECOND, CommonConstants.ZERO_INT,
                        CommonConstants.MAX_WIDTH, true)
                .toFormatter();
        var inputFormattedTs = LocalDateTime.parse(effectiveTs, dateTimeFormatter);
        var formattedEffTs = inputFormattedTs.atOffset(ZoneOffset.UTC);
        history.getEmploymentHistory().setEffectiveTimeStamp(formattedEffTs.toString());
        return history;
    }
}
