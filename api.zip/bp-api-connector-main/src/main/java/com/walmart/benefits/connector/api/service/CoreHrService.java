package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.AddressWithAssociateId;
import com.walmart.benefits.connector.api.model.EmploymentHistoryWithAssociateId;
import com.walmart.benefits.connector.api.model.OtherPositionWithAssociateId;
import com.walmart.benefits.connector.api.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Slf4j
public class CoreHrService {

    private final ConnectorRepository dao;

    /**
     * Get Associate HR Details asynchronously
     * @param associateIds List of Associate Win Number
     * @return CompletableFuture with Associate Info map
     */
    @Async("asyncTaskExecutor")
    public CompletableFuture<Map<String, AssociateInfo>> getAssociateHrDetails(List<String> associateIds){
        var associateMap = new HashMap<String, AssociateInfo>();
        log.info("Getting Associate info details from Core HR");
        var associateInfoList = dao.getAssociateDetailsFromCoreHr(associateIds);
        if(associateInfoList != null && !associateInfoList.isEmpty()){
            associateInfoList.forEach( associateInfo ->
                associateMap.put(associateInfo.getAssociateId(), associateInfo)
            );
        }
        var historyFuture = this.getAndMapEmploymentHistory(associateIds,
                associateMap);
        var primaryAndOtherPositionsFuture =
                this.getAndMapPrimaryAndOtherPositionsDetails(associateIds, associateMap);
        var addressFuture =  this.getAndMapAddressDetails(associateIds, associateMap);
        var hireRescindFuture = this.getAndMapHireRescind(associateIds, associateMap);
        var isManagementTraineeFuture = this.getAndMapIsManagementTrainee(associateIds, associateMap);

        // Wait for all tasks to complete
        CompletableFuture<Void> allTasks =
                CompletableFuture.allOf(
                        historyFuture, primaryAndOtherPositionsFuture,
                        addressFuture, hireRescindFuture, isManagementTraineeFuture);
        allTasks.join();

        return CompletableFuture.completedFuture(associateMap);
    }

    /**
     * Get and Map the Employment History for the associate
     * @param associateIds List of Associate Win Number
     * @param associateMap Associate Info map object
     * @return CompletableFuture
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapEmploymentHistory(List<String> associateIds,
                                                                 HashMap<String, AssociateInfo> associateMap){
        var historyList = dao.getEmploymentHistory(associateIds);
        if(historyList != null && !historyList.isEmpty()){
            associateMap.keySet().forEach(key -> {
                associateMap.get(key).getEmployment().setEmploymentHistory(historyList.stream()
                        .filter(history -> history.getAssociateId().equals(key))
                        .map(EmploymentHistoryWithAssociateId::getEmploymentHistory)
                        .toList());
            });
        }
        return CompletableFuture.completedFuture(null);
    }

    /**
     * Get and Map the Primary position and Other Positions details for the
     * associate list
     * @param associateIds List of Associate Win Number
     * @param associateMap Associate Map
     * @return CompletableFuture
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapPrimaryAndOtherPositionsDetails(List<String> associateIds,
                                                                               HashMap<String, AssociateInfo> associateMap){

        var primaryPositionList = dao.getPrimaryPositionDetails(associateIds);
        if(primaryPositionList != null && !primaryPositionList.isEmpty()){
            primaryPositionList.forEach( primaryPosition -> {
                associateMap.get(primaryPosition.getAssociateId()).getEmployment()
                        .setPrimaryPositionInfo(primaryPosition.getPrimaryPositionInfo());
            });
        }

        var otherPositionsList = dao.getOtherPositionDetails(associateIds);
        if(otherPositionsList != null && !otherPositionsList.isEmpty()) {
            associateMap.keySet().forEach(key -> {
                var primaryPosition = associateMap.get(key).getEmployment().getPrimaryPositionInfo();
                if (primaryPosition == null){
                    associateMap.get(key).getEmployment().setOtherPositions(otherPositionsList.stream()
                            .filter(otherPosition -> (otherPosition.getAssociateId().equals(key)))
                            .map(OtherPositionWithAssociateId::getOtherPositions)
                            .toList());
                }
                else {
                    associateMap.get(key).getEmployment().setOtherPositions(otherPositionsList.stream()
                            .filter(otherPosition -> (otherPosition.getAssociateId().equals(key)
                                            && !(
                                            otherPosition.getOtherPositions().getPositionId().equals(primaryPosition.getPositionId())
                                                    && otherPosition.getOtherPositions().getJobId().equals(primaryPosition.getJobId())
                                                    && otherPosition.getOtherPositions().getJobEffectiveDate().equals(primaryPosition.getJobEffectiveDate())
                                                    && otherPosition.getOtherPositions().getJobEndDate().equals(primaryPosition.getJobEndDate())
                                    )
                                    )
                            )
                            .map(OtherPositionWithAssociateId::getOtherPositions)
                            .toList());
                }
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapAddressDetails(List<String> associateIds,
                                                              HashMap<String, AssociateInfo> associateMap){
        var addressDetailsList = dao.getAddressDetails(associateIds);

        if(addressDetailsList != null && !addressDetailsList.isEmpty()){
            associateMap.keySet().forEach(key -> {
                associateMap.get(key).setAddress(addressDetailsList.stream()
                        .filter(address -> address.getAssociateId().equals(key))
                        .map(AddressWithAssociateId::getAddress)
                        .toList());
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapHireRescind(List<String> associateIds,
                                                           HashMap<String, AssociateInfo> associateMap){
        var hireRescindIndicatorList = dao.getHireRescindIndicator(associateIds);
        if(hireRescindIndicatorList != null && !hireRescindIndicatorList.isEmpty()){
            hireRescindIndicatorList.forEach(hireRescind -> {
                associateMap.get(hireRescind.getAssociateId()).getEmployment()
                        .setHireRescinded(hireRescind.getRescindIndicator().equals(CommonConstants.YES));
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapIsManagementTrainee(List<String> associateIds,
                                                                   HashMap<String, AssociateInfo> associateMap) {
        var managementTraineeIndicatorList = dao.isManagementTrainee(associateIds);
        if (managementTraineeIndicatorList != null && !managementTraineeIndicatorList.isEmpty()) {
            managementTraineeIndicatorList.forEach(managementTrainee -> {
                associateMap.get(managementTrainee.getAssociateId()).getEmployment()
                        .setIsManagementTrainee(managementTrainee.getIsManagementTrainee());
            });
        }

        return CompletableFuture.completedFuture(null);
    }

}
