package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.*;
import com.walmart.benefits.connector.api.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Slf4j
public class PayrollService {

    private final ConnectorRepository dao;

    /**
     * Get Associate Payroll Details Asynchronously
     * @param associateIds  List of Associate Win Number parameter
     * @return returns CompletableFuture with PayrollInfo map object
     */
    @Async("asyncTaskExecutor")
    public CompletableFuture<Map<String, List<PayrollInfo>>> getAssociatePayrollDetails(List<String> associateIds){
        log.info("Getting Payroll info details from Payroll System");
        var associateMap = new HashMap<String, List<PayrollInfo>>();
        var emptyMap = new HashMap<String, List<PayrollInfo>>();
        if (associateIds == null || associateIds.isEmpty()) {
            return CompletableFuture.completedFuture(emptyMap);
        }
        associateIds.forEach( id ->
                associateMap.put(id, new ArrayList<>())
        );

        var payrollDetailsMap = this.getAndMapPayrollPayCenter(associateIds,
                associateMap);
        if (payrollDetailsMap == null || payrollDetailsMap.isEmpty()) {
            return CompletableFuture.completedFuture(emptyMap);
        }
        associateIds.forEach(id -> {
            if (!payrollDetailsMap.containsKey(id)) {
                associateMap.remove(id);
            }
        });

        // Create two separate maps for filtering based on null values in payrollDetailsMap
        HashMap<String, List<PayrollInfo>> validForPayPeriod = new HashMap<>(associateMap);
        payrollDetailsMap.forEach((id, details) -> {
            if (details.stream().anyMatch(detail -> detail.getPayCenterId() == null || detail.getPayCenterId().isEmpty())) {
                validForPayPeriod.remove(id);
            }
        });

        HashMap<String, List<PayrollInfo>> validForEarningsDeductionsHours = new HashMap<>(associateMap);
        payrollDetailsMap.forEach((id, details) -> {
            if (details.stream().anyMatch(detail -> detail.getPayCenterId() == null || detail.getPayCenterId().isEmpty() || detail.getPayrollRunDate() == null)) {
                validForEarningsDeductionsHours.remove(id);
            }
        });


        PayrollInputs inputsForPayPeriod = getPayrollInputs(validForPayPeriod);
        PayrollInputs inputsForEarningsDeductionsHours = getPayrollInputs(validForEarningsDeductionsHours);


        var payYear = String.valueOf(LocalDate.now().getYear());

        var payPeriodFuture = this.getAndMapPayrollPayPeriodDetails(
            inputsForPayPeriod.payCenterIds(), payYear, inputsForPayPeriod.payCenterIdMap()
        );

        // Only call earnings, deductions, and hours methods if the list of associate IDs is not empty
        CompletableFuture<Void> earningFuture = CompletableFuture.completedFuture(null);
        CompletableFuture<Void> deductionsFuture = CompletableFuture.completedFuture(null);
        CompletableFuture<Void> hoursFuture = CompletableFuture.completedFuture(null);

        if (!validForEarningsDeductionsHours.isEmpty()) {
            earningFuture = this.getAndMapPayrollEarnings(
                new ArrayList<>(validForEarningsDeductionsHours.keySet()),
                inputsForEarningsDeductionsHours.payrollRunDates(),
                inputsForEarningsDeductionsHours.payCenterIds(),
                inputsForEarningsDeductionsHours.associatePayCenterRunDateMap()
            );

            deductionsFuture = this.getAndMapPayrollDeductions(
                new ArrayList<>(validForEarningsDeductionsHours.keySet()),
                inputsForEarningsDeductionsHours.payrollRunDates(),
                inputsForEarningsDeductionsHours.payCenterIds(),
                inputsForEarningsDeductionsHours.associatePayCenterRunDateMap()
            );

            hoursFuture = this.getAndMapPayrollHours(
                new ArrayList<>(validForEarningsDeductionsHours.keySet()),
                inputsForEarningsDeductionsHours.payrollRunDates(),
                inputsForEarningsDeductionsHours.payCenterIds(),
                inputsForEarningsDeductionsHours.associatePayCenterRunDateMap()
            );
        }

        // Wait for all tasks to complete
        CompletableFuture<Void> allTasks =
                CompletableFuture.allOf(payPeriodFuture, earningFuture, deductionsFuture, hoursFuture);
        allTasks.join();

        return CompletableFuture.completedFuture(associateMap);
    }

    @NotNull
    private static PayrollInputs getPayrollInputs(HashMap<String, List<PayrollInfo>> associateMap) {
        var payCenterIds = associateMap.values().stream()
                            .flatMap(List::stream)
                            .map(PayrollInfo::getPayCenterId)
                            .collect(Collectors.toSet())
                            .stream().toList();

        var payrollRunDates = associateMap.values().stream()
                                .flatMap(List::stream)
                                .map(payrollInfo -> (payrollInfo.getPayrollRunDate() != null) ? payrollInfo.getPayrollRunDate() : CommonConstants.STRING_EMPTY)
                                .collect(Collectors.toSet())
                                .stream().toList();

        var payCenterIdMap =
                (HashMap<String, List<PayrollInfo>>) associateMap.values()
                        .stream()
                        .flatMap(List::stream)
                        .collect(Collectors.groupingBy(PayrollInfo::getPayCenterId));

        var associatePayCenterRunDateMap =
                (HashMap<String, PayrollInfo>) associateMap.entrySet().stream()
                                                    .flatMap(entry -> entry.getValue().stream()
                                                        .collect(Collectors.toMap(
                                                                obj -> entry.getKey() + "-" + obj.getPayCenterId() + "-" + obj.getPayrollRunDate(),
                                                                obj -> obj
                                                        )).entrySet().stream())
                                                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        return new PayrollInputs(payCenterIds, payrollRunDates, payCenterIdMap, associatePayCenterRunDateMap);
    }

    private record PayrollInputs(List<String> payCenterIds, List<String> payrollRunDates, HashMap<String, List<PayrollInfo>> payCenterIdMap, HashMap<String, PayrollInfo> associatePayCenterRunDateMap) {
    }

    /**
     * Get and Map th payroll Pay Center details for the associate
     * @param associateIds List of Associate Win Number parameter
     * @param associateMap Associate map with List of PayrollInfo object
     *                     parameter
     */
    private Map<String, List<PayrollBasicDetails>> getAndMapPayrollPayCenter(List<String> associateIds,
                                           HashMap<String, List<PayrollInfo>> associateMap) {
        var payrollBasicDetailsList = dao.getPayrollPayCenter(associateIds);
        if(payrollBasicDetailsList != null && !payrollBasicDetailsList.isEmpty()){
            payrollBasicDetailsList.forEach(payrollBasicDetails -> {
                // Skip adding PayrollInfo if payCenterId is null or empty
                if (payrollBasicDetails.getPayCenterId() != null && !payrollBasicDetails.getPayCenterId().isEmpty()) {
                    var payrollInfo = new PayrollInfo();
                    payrollInfo.setPayCenterId(payrollBasicDetails.getPayCenterId());
                    payrollInfo.setPayrollRunDate(payrollBasicDetails.getPayrollRunDate() != null ? payrollBasicDetails.getPayrollRunDate().toString() : null);
                    associateMap.get(payrollBasicDetails.getAssociateId()).add(payrollInfo);
                }
            });

            // Only group and return details where payCenterId is not null or empty
            return payrollBasicDetailsList.stream()
                .filter(detail -> detail.getPayCenterId() != null && !detail.getPayCenterId().isEmpty())
                .collect(Collectors.groupingBy(PayrollBasicDetails::getAssociateId));
        }

        return Map.of();
    }

    /**
     * Get and Map the Payroll Pay Period Details for the given PayCenter and
     * Year.
     * @param payCenterIds List of PayCenterId parameter
     * @param payYear Year parameter
     * @param payCenterMap pay center map with PayrollInfo object parameter
     * @return returns Completable Future object.
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapPayrollPayPeriodDetails(List<String> payCenterIds
            , String payYear, HashMap<String, List<PayrollInfo>> payCenterMap) {
        PayrollPayPeriodDetails payrollPayPeriodDetails;
        payrollPayPeriodDetails = dao.getPayrollPayPeriodDetails(payYear)
                .stream()
                .findFirst()
                .orElse(null);
        if (payrollPayPeriodDetails != null) {
            payCenterMap.forEach((payCenterId, payrollInfoList) -> {
                if (payrollInfoList != null && !payrollInfoList.isEmpty()) {
                if (CommonConstants.BIWEEKLY_PAY_CENTERS.contains(payCenterId)) {
                    payrollInfoList.forEach(payrollInfo -> {
                    payrollInfo.setPayPeriodStartDate(payrollPayPeriodDetails.getBiweeklyPayPeriodStartDate());
                    payrollInfo.setPayPeriodEndDate(payrollPayPeriodDetails.getBiweeklyPayPeriodEndDate());
                    });
                } else if (CommonConstants.WEEKLY_PAY_CENTER_4.equals(payCenterId)) {
                    payrollInfoList.forEach(payrollInfo -> {
                    payrollInfo.setPayPeriodStartDate(payrollPayPeriodDetails.getWeeklyPayPeriodStartDate());
                    payrollInfo.setPayPeriodEndDate(payrollPayPeriodDetails.getWeeklyPayPeriodEndDate());
                    });
                }
                }
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    /**
     * Get and Map the Payroll Earnings for the associate
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Payroll Run Date parameter
     * @param payCenterIds list of PayCenterId parameter
     * @param associatePayrollMap map of Associate and PayrollInfo object
     * @return returns Completable Future object.
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapPayrollEarnings(List<String> associateIds,
                                                               List<String> payrollRunDates,
                                                               List<String> payCenterIds,
                                                               HashMap<String, PayrollInfo> associatePayrollMap) {
        var payrollEarningsList = dao.getPayrollEarnings(associateIds,
                payrollRunDates,
                payCenterIds);

        if (payrollEarningsList != null && !payrollEarningsList.isEmpty()){
            var payrollEarningsMap =
                    (HashMap<String, List<Earning>>) payrollEarningsList
                            .stream()
                            .collect(Collectors.groupingBy(
                                    item -> item.getAssociateId() + "-" + item.getPayCenterId() + "-" + item.getPayrollRunDate(),
                                    Collectors.mapping(EarningWithAssociateId::getEarning,
                                            Collectors.toList())
                            ));

            payrollEarningsMap.forEach((key, earnings) -> {
                var payrollInfo = associatePayrollMap.get(key);
                if(payrollInfo != null){
                    payrollInfo.setEarnings(earnings);
                }
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    /**
     * Get and Map the Payroll Deductions for the associate
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Payroll Run Date parameter
     * @param payCenterIds list of PayCenterId parameter
     * @param associatePayrollMap map of Associate and PayrollInfo object
     * @return returns Completable Future object.
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapPayrollDeductions(List<String> associateIds,
                                                                 List<String> payrollRunDates,
                                                                 List<String> payCenterIds,
                                                                 HashMap<String, PayrollInfo> associatePayrollMap) {
        var payrollDeductionsList = dao.getPayrollDeductions(associateIds,
                payrollRunDates,
                payCenterIds);

        if (payrollDeductionsList != null && !payrollDeductionsList.isEmpty()){
            var payrollDeductionsMap =
                    (HashMap<String, List<Deduction>>) payrollDeductionsList
                            .stream()
                            .collect(Collectors.groupingBy(
                                    item -> item.getAssociateId() + "-" + item.getPayCenterId() + "-" + item.getPayrollRunDate(),
                                    Collectors.mapping(DeductionWithAssociateId::getDeduction,
                                            Collectors.toList())
                            ));

            payrollDeductionsMap.forEach((key, deductions) -> {
                var payrollInfo = associatePayrollMap.get(key);
                if(payrollInfo != null){
                    payrollInfo.setDeductions(deductions);
                }
            });
        }

        return CompletableFuture.completedFuture(null);
    }

    /**
     * Get and Map the Payroll Hours for the associate
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Payroll Run Date parameter
     * @param payCenterIds list of PayCenterId parameter
     * @param associatePayrollMap map of Associate and PayrollInfo object
     * @return returns Completable Future object.
     */
    @Async("asyncTaskExecutor")
    protected CompletableFuture<Void> getAndMapPayrollHours(List<String> associateIds,
                                                            List<String> payrollRunDates,
                                                            List<String> payCenterIds,
                                                            HashMap<String, PayrollInfo> associatePayrollMap) {
        var payrollHoursList = dao.getPayrollHours(associateIds,
                payrollRunDates,
                payCenterIds);

        if (payrollHoursList != null && !payrollHoursList.isEmpty()){
            var payrollHoursMap =
                    (HashMap<String, List<PayrollWorkHours>>) payrollHoursList
                            .stream()
                            .collect(Collectors.groupingBy(
                                    item -> item.getAssociateId() + "-" + item.getPayCenterId() + "-" + item.getPayrollRunDate(),
                                    Collectors.mapping(PayrollWorkHoursWithAssociateId::getPayrollWorkHours,
                                            Collectors.toList())
                            ));

            payrollHoursMap.forEach((key, hours) -> {
                var payrollInfo = associatePayrollMap.get(key);
                if(payrollInfo != null){
                    payrollInfo.setHours(hours);
                }
            });
        }

        return CompletableFuture.completedFuture(null);
    }

}
