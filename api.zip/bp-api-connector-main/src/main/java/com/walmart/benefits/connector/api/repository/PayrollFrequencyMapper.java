package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.PayrollFrequencyDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class PayrollFrequencyMapper implements RowMapper<PayrollFrequencyDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to PayrollFrequencyDetails object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns PayrollFrequencyDetails object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public PayrollFrequencyDetails mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var payrollFrequencyDetails = new PayrollFrequencyDetails();
        payrollFrequencyDetails.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        payrollFrequencyDetails.setPayrollFrequency(sqlHelper.getTextOrDefault(
                ColumnConstants.COMP_FREQ_CODE, rs));
        return payrollFrequencyDetails;
    }
}
