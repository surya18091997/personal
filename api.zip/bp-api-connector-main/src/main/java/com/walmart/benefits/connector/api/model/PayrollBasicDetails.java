package com.walmart.benefits.connector.api.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;

@Data
public class PayrollBasicDetails {
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern="yyyy-MM-dd")
    private LocalDate payrollRunDate;
    private String payCenterId;
    private String associateId;
}
