package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.model.AssociateUpstreamDetails;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollInfo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static com.walmart.benefits.connector.api.common.CommonConstants.ASSOCIATE_INFO;
import static com.walmart.benefits.connector.api.common.CommonConstants.PAYROLL_INFO;

@AllArgsConstructor
@Slf4j
@Service
public class ConnectorService {

    private final CoreHrService coreHrService;
    private final GtaService gtaService;
    private final PayrollService payrollService;

    /**
     * Query Associate Upstream Details
     *
     * @param associateId Associate Win Number parameter
     * @return returns AssociateUpstreamDetails object
     */
    public AssociateUpstreamDetails queryAssociateUpstreamDetails(String associateId, Set<String> requestedFields) throws InterruptedException, ExecutionException {
        var associateIdList = new ArrayList<String>();
        associateIdList.add(associateId);
        var assocDetails =
                this.queryAssociateUpstreamDetails(associateIdList, requestedFields);
        if (assocDetails != null && !assocDetails.isEmpty()) {
            return assocDetails.get(0);
        }

        return null;
    }

    /**
     * Query Associate Upstream Details for the list of associates
     *
     * @param associateIds List of Associate Win Number parameter
     * @return returns List of AssociateUpstreamDetails object
     */
    public List<AssociateUpstreamDetails> queryAssociateUpstreamDetails(List<String> associateIds, Set<String> requestedFields) throws InterruptedException, ExecutionException {
        var associateHrFuture =
                requestedFields.contains(ASSOCIATE_INFO) ? coreHrService.getAssociateHrDetails(associateIds) : CompletableFuture.completedFuture(new HashMap<String, AssociateInfo>());
        var payrollFuture =
                requestedFields.contains(PAYROLL_INFO) ? payrollService.getAssociatePayrollDetails(associateIds) : CompletableFuture.completedFuture(new HashMap<String, List<PayrollInfo>>());
        // Wait for all tasks to complete
        CompletableFuture<Void> allTasks = CompletableFuture.allOf(associateHrFuture, payrollFuture);
        allTasks.join();

        return mapAssociateDetails(associateIds, (CompletableFuture<Map<String, AssociateInfo>>) associateHrFuture,
                (CompletableFuture<Map<String, List<PayrollInfo>>>) payrollFuture);
    }

    private List<AssociateUpstreamDetails> mapAssociateDetails(List<String> associateIds, CompletableFuture<Map<String, AssociateInfo>> associateHrFuture, CompletableFuture<Map<String, List<PayrollInfo>>> payrollFuture) throws InterruptedException, ExecutionException {
        var result = new ArrayList<AssociateUpstreamDetails>();
        for (var associateId : associateIds) {
            var assocDetails = new AssociateUpstreamDetails();
            var associateHrDetailsMap = associateHrFuture.get();
            var payrollDetailsMap = payrollFuture.get();
            assocDetails.setAssociateInfo(associateHrDetailsMap.get(associateId));
            assocDetails.setPayrollInfo(payrollDetailsMap.get(associateId));
            assocDetails.setGtaInfo(gtaService.getGTAInfo(associateIds));

            if (assocDetails.getAssociateInfo() == null && (assocDetails.getPayrollInfo() == null || assocDetails.getPayrollInfo().isEmpty()) && assocDetails.getGtaInfo() == null) {
                continue;
            }
            result.add(assocDetails);
        }
        return result;
    }


}