package com.walmart.benefits.connector.api.exception;

import com.walmart.benefits.connector.api.common.CommonConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.concurrent.CompletionException;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {
    /**
     * This method used to handle the IllegalArgumentException
     * @param ex IllegalArgumentException parameter
     * @return returns string
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(CommonConstants.BAD_REQUEST_ERROR, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles the ResourceNotFoundException by logging the error and returning a ResponseEntity
     * with the appropriate error message and HTTP status code.
     *
     * @param  ex   the ResourceNotFoundException to handle
     * @return       a ResponseEntity with the error message and HTTP status code
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the CompletionException by logging the error and returning a ResponseEntity
     * with the appropriate error message and HTTP status code.
     *
     * @param  ex   the CompletionException to handle
     * @return       a ResponseEntity with the error message and HTTP status code
     */
    @ExceptionHandler(CompletionException.class)
    public ResponseEntity<String> handleCompletionException(CompletionException ex) {
        if (ex.getCause() != null && ex.getCause().getClass() == ResourceNotFoundException.class) {
            return this.handleResourceNotFoundException(new ResourceNotFoundException(ex.getMessage()));
        } else{
            return this.handleGlobalException(new Exception(ex.getMessage()));
        }
    }

    /**
     * This method used to handle the Generic Exceptions
     * @param ex Exception parameter
     * @return returns string
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGlobalException(Exception ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(CommonConstants.UNEXPECTED_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
