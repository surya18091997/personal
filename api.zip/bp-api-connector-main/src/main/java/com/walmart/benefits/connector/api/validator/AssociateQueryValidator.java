package com.walmart.benefits.connector.api.validator;

import com.walmart.benefits.connector.api.common.CommonConstants;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@NoArgsConstructor
@Component
public class AssociateQueryValidator {

    /**
     * this method used to validate the associate Id input
     * @param associateId associate Id parameter
     */
    public void ValidateAssociateInput(String associateId){
        if(Long.parseLong(associateId) <= CommonConstants.ZERO_LONG) {
            throw new IllegalArgumentException(CommonConstants.ASSOCIATE_ID_ERROR);
        }
    }

    /**
     * this method used to validate the associate Ids input
     * @param associateIds associate Id parameter
     */
    public void ValidateAssociatesInput(List<String> associateIds){
        if(associateIds == null ||associateIds.isEmpty()) {
            throw new IllegalArgumentException(CommonConstants.ASSOCIATE_IDS_ERROR);
        }

        if(associateIds.size() > CommonConstants.MAX_ASSOCIATE_COUNT) {
            throw new IllegalArgumentException(String.format(CommonConstants.ASSOCIATE_IDS_COUNT_ERROR, CommonConstants.MAX_ASSOCIATE_COUNT));
        }

        for(String associateId : associateIds) {
            ValidateAssociateInput(associateId);
        }
    }

}
