package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Earning;
import lombok.Data;

@Data
public class EarningWithAssociateId {
    private String associateId;
    private String payCenterId;
    private String payrollRunDate;
    private Earning earning;
}
