package com.walmart.benefits.connector.api.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class PayrollPayPeriodDetails {
    private String payCenterId;
    private String currencyCode;
    private PayrollFrequency payrollFrequency;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern="yyyy-MM-dd")
    private String biweeklyPayPeriodStartDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern="yyyy-MM-dd")
    private String biweeklyPayPeriodEndDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern="yyyy-MM-dd")
    private String weeklyPayPeriodStartDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern="yyyy-MM-dd")
    private String weeklyPayPeriodEndDate;
    private int remainingPayPeriods;
}
