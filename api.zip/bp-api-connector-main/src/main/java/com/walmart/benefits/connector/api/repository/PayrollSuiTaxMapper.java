package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.PayrollFrequencyDetails;
import com.walmart.benefits.connector.api.model.PayrollSuiTaxDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class PayrollSuiTaxMapper implements RowMapper<PayrollSuiTaxDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to PayrollSuiTaxDetails object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns PayrollSuiTaxDetails object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public PayrollSuiTaxDetails mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var payrollFrequencyDetails = new PayrollSuiTaxDetails();
        payrollFrequencyDetails.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        payrollFrequencyDetails.setPayCenterId(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_CENTER_ID, rs));
        payrollFrequencyDetails.setPayrollRunDate(sqlHelper.getTextOrDefault(
                ColumnConstants.RUN_DATE, rs));
        payrollFrequencyDetails.setPayrollSuiTax(sqlHelper.getTextOrDefault(
                ColumnConstants.SUI_AMT, rs));
        return payrollFrequencyDetails;
    }
}
