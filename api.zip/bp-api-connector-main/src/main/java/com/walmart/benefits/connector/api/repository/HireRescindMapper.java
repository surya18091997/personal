package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.HireRescindDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class HireRescindMapper implements RowMapper<HireRescindDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to HireRescindDetails object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns HireRescindDetails object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public HireRescindDetails mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var hireRescindDetails = new HireRescindDetails();
        hireRescindDetails.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        hireRescindDetails.setRescindIndicator(sqlHelper.getTextOrDefault(
                ColumnConstants.RESCIND_IND, rs));
        return hireRescindDetails;
    }
}
