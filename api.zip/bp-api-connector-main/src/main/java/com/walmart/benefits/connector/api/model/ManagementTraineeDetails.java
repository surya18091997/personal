package com.walmart.benefits.connector.api.model;

import lombok.Data;

@Data
public class ManagementTraineeDetails {
    private String associateId;
    private Boolean isManagementTrainee;
}