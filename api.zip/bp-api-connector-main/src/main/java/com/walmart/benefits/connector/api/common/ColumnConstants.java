package com.walmart.benefits.connector.api.common;

public class ColumnConstants {

    private ColumnConstants() {
    }

    public static final String WIN_NBR = "WIN_NBR";
    public static final String HOME_PHONE_NBR = "HOME_PHONE_NBR";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String MIDDLE_INITIAL = "MIDDLE_INITIAL";
    public static final String GENDER_CODE = "GENDER_CODE";
    public static final String BIRTH_DATE = "BIRTH_DATE";
    public static final String MARITAL_CODE = "ACT_MARITAL_CODE";
    public static final String STATE_PROV_CODE = "STATE_PROV_CODE";
    public static final String COUNTRY_CODE = "COUNTRY_CODE";
    public static final String EMP_STATUS_CODE = "EMPLOY_STAT_CODE";
    public static final String PAY_TYPE_CODE = "PAY_TYPE_CODE";
    public static final String ASC_TYPE_CODE = "ASC_TYPE_CODE";
    public static final String HIRE_DATE = "HIRE_DATE";
    public static final String ORIGINAL_HIRE_DATE = "ORIGINAL_HIRE_DATE";
    public static final String TERMINATION_DATE = "TERMINATION_DATE";
    public static final String TERM_REASON_CODE = "TERM_REASON_CODE";
    public static final String COMP_FREQ_CODE = "COMP_FREQ_CODE";
    public static final String MGR_WIN_NBR = "MGR_WIN_NBR";
    public static final String STORE_NBR = "STORE_NBR";
    public static final String ASC_STORE_NBR = "ASC_STORE_NBR";
    public static final String STORE_STATE_PROV_CD = "STR_STATE_PROV_CD";
    public static final String CHRG_DIV_NBR = "CHRG_MDSE_DIV_NBR";
    public static final String EFF_TS = "EFF_TS";
    public static final String PAY_SEQ_CODE = "PAY_SEQ_CODE";
    public static final String DOE_CODE = "DOE_CODE";
    public static final String DEDUCTION_AMT = "DEDUCTION_AMT";
    public static final String YTD_TOT_DOE_AMT = "YTD_TOT_DOE_AMT";
    public static final String PERCENTAGE = "PERCENTAGE";
    public static final String METHOD = "METHOD";
    public static final String DOE_FREQUENCY_CODE = "DOE_FREQUENCY_CODE";
    public static final String NET_LIMIT_AMT = "NET_LIMIT_AMT";
    public static final String ARREAR_DOE_AMT = "ARREAR_DOE_AMT";
    public static final String YTD_TOT_ARREAR_AMT = "YTD_TOT_ARREAR_AMT";
    public static final String DOE_START_DT = "DOE_START_DT";
    public static final String DOE_END_DT = "DOE_END_DT";
    public static final String EARNING_TYPE_CODE = "EARNING_TYPE_CODE";
    public static final String EARN_AMT = "EARN_AMT";
    public static final String YTD_TOT_EARN_AMT = "YTD_TOT_EARN_AMT";
    public static final String HOUR_TYPE_CODE = "HOUR_TYPE_CODE";
    public static final String PAY_CENTER_ID = "PAY_CENTER_ID";
    public static final String RUN_DATE = "RUN_DATE";
    public static final String CURRENCY_CODE = "CURRENCY_CODE";
    public static final String START_DATE = "START_DATE";
    public static final String END_DATE = "END_DATE";
    public static final String PLAN_BEGIN_DATE = "PLAN_BEGIN_DATE";
    public static final String PLAN_END_DATE = "PLAN_END_DATE";
    public static final String JOB_ID = "JOB_NBR";
    public static final String JOB_CLASSIFICATION = "JOB_CLASSIFICATION";
    public static final String POSITION_ID = "WD_POSITION_ID";
    public static final String EFFECTIVE_DATE = "EFFECTIVE_DATE";
    public static final String OBSOLETE_DATE = "OBSOLETE_DATE";
    public static final String HOURS_QTY = "HOURS_QTY";
    public static final String PAYROLL_END_DATE = "PAYROLL_END_DATE";
    public static final String NATIONAL_ID = "NATIONAL_ID";
    public static final String LINE_1 = "LINE_1";
    public static final String LINE_2 = "LINE_2";
    public static final String CITY = "CITY";
    public static final String STATE = "STATE";
    public static final String POSTAL_CODE = "POSTAL_CODE";
    public static final String IS_PRIMARY = "IS_PRIMARY";
    public static final String ADDRESS_TYPE = "ADDRESS_TYPE";
    public static final String LOA_CODE = "LOA_CODE";
    public static final String LOA_EFF_DATE = "LOA_EFF_DATE";
    public static final String LOA_RETURN_DATE = "LOA_RETURN_DATE";
    public static final String RESCIND_IND = "RESCIND_IND";
    public static final String SUI_AMT = "SUI_AMT";
    public static final String IS_MANAGEMENT_TRAINEE = "IS_MANAGEMENT_TRAINEE";
    public static final String BI_WEEKLY_START_DATE = "BI_WEEKLY_START_DATE";
    public static final String BI_WEEKLY_END_DATE = "BI_WEEKLY_END_DATE";
    public static final String WEEKLY_START_DATE = "WEEKLY_START_DATE";
    public static final String WEEKLY_END_DATE ="WEEKLY_END_DATE";

}

