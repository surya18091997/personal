package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Deduction;
import lombok.Data;

@Data
public class DeductionWithAssociateId {
    private String associateId;
    private String payCenterId;
    private String payrollRunDate;
    private Deduction deduction;
}
