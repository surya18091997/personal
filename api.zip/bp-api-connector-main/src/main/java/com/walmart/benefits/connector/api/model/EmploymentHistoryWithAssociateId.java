package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.hr.EmploymentHistory;
import lombok.Data;

@Data
public class EmploymentHistoryWithAssociateId {
    private String associateId;
    private EmploymentHistory employmentHistory;
}
