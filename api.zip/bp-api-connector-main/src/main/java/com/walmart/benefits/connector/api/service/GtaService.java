package com.walmart.benefits.connector.api.service;

import com.walmart.benefits.connector.api.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.interdomain.gta.GtaInfo;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class GtaService {
    private final ConnectorRepository dao;

    /**
     * Get GTA Info for the list of associate
     * @param associateIds List of Associate Win Number
     * @return GTAInfo object
     */
    public GtaInfo getGTAInfo(List<String> associateIds){
        // Currently we are not using the GTA INFO for 401k, Hence sending
        // the null data.
        return null;
    }
}
