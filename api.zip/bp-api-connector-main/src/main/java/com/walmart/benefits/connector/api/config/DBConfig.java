package com.walmart.benefits.connector.api.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;


@Configuration
public class DBConfig {

    @Bean(name = "db2DB")
    @Primary
    @ConfigurationProperties(prefix = "spring.ds-db2")
    public DataSource db2DataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "db2JdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("db2DB") DataSource db2DB) {
        return new JdbcTemplate(db2DB);
    }


}
