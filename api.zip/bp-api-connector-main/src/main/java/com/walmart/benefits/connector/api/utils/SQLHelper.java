package com.walmart.benefits.connector.api.utils;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotNull;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
@PropertySource("classpath:sql.properties")
@ConfigurationProperties
@Validated
@Data
public class SQLHelper {
    @NotNull
    private String associateQuery ;

    @NotNull
    private String employmentHistoryQuery ;

    @NotNull
    private String otherPositionQuery ;

    @NotNull
    private String primaryPositionQuery ;

    @NotNull
    private String workingHoursQuery;

    @NotNull
    private String associatePayCenterQuery;

    @NotNull
    private String weeklyPayrollDateQuery;

    @NotNull
    private String payrollFrequencyQuery;

    @NotNull
    private String associateSuiTaxQuery;

    @NotNull
    private String associateEarningQuery;

    @NotNull
    private String associateDeductionQuery;

    @NotNull
    private String associateHoursQuery;

    @NotNull
    private String associateAddressQuery;

    @NotNull
    private String hireRescindQuery;

    @NotNull
    private String managementTraineeQuery;

    /**
     * This method used to get the string value from DB column and return the
     * empty string if data is not there
     * @param columnName Column Name parameter
     * @param rs Result Set parameter
     * @return returns column value as string or empty string
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public String getTextOrDefault(String columnName, ResultSet rs) throws SQLException, EmptyResultDataAccessException {
        return StringUtils.hasText(rs.getString(columnName)) ?
                rs.getString(columnName).trim() : "";
    }
}
