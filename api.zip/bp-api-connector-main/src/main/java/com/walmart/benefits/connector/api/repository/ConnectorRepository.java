package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.exception.ResourceNotFoundException;
import com.walmart.benefits.connector.api.model.*;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.gta.WorkingHoursInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.EmploymentHistory;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.OtherPositions;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.PrimaryPositionInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Deduction;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Earning;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollWorkHours;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Address;
import lombok.AllArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Repository
public class ConnectorRepository {
    protected final JdbcTemplate db2JdbcTemplate;
    private final SQLHelper sqlHelper;

    /**
     * This method used to get List of Associate details from Core Hr
     * @param associateIds List of Associate Win Number parameter
     * @return returns List of AssociateInfo object
     */
    public List<AssociateInfo> getAssociateDetailsFromCoreHr(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateQuery(),
                        placeholders),
                associateIds.toArray(),
                new AssociateInfoMapper(sqlHelper));
    }

    /**
     * This method used to get employment history of the associate
     * @param associateIds List of Associate Win Number parameter
     * @return returns Lis of EmploymentHistory object
     */
    public List<EmploymentHistoryWithAssociateId> getEmploymentHistory(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getEmploymentHistoryQuery(),
                        placeholders),
                associateIds.toArray(),
                new EmploymentHistoryMapper(sqlHelper));
    }

    /**
     * This method used to get Other Positions details for the list of
     * associates
     * @param associateIds  List of Associate Win Number paramater
     * @return returns OtherPositionWithAssociateId object
     */
    public List<OtherPositionWithAssociateId> getOtherPositionDetails(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getOtherPositionQuery(),
                        placeholders),
                associateIds.toArray(),
                new OtherPositionMapper(sqlHelper));
    }

    /**
     * This method used to get List of Primary Position details for the
     * associates list
     * @param associateIds List of Associate Win Number parameter
     * @return return List of PrimaryPositionWithAssociateId object
     */
    public List<PrimaryPositionWithAssociateId> getPrimaryPositionDetails(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getPrimaryPositionQuery(),
                        placeholders),
                associateIds.toArray(),
                new PrimaryPositionMapper(sqlHelper));
    }

    /**
     * This method used to get Address details for the list of associates
     * @param associateIds List of Associate Win Number paramater
     * @return returns List of Address object
     */
    public List<AddressWithAssociateId> getAddressDetails(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateAddressQuery(),
                        placeholders),
                associateIds.toArray(),
                new AssociateAddressMapper(sqlHelper));
    }

    /**
     * This method used to get working hours info for associate
     * @param associateId Associate Win Number parameter
     * @return returns List of WorkingHoursInfo object
     */
    public List<WorkingHoursInfo> getWorkingHoursInfoForAssociate(String associateId){
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getWorkingHoursQuery(), CommonConstants.EXCLUDED_HOURS_TYPE),
                new Object[] { associateId },
                new WorkingHoursInfoMapper(sqlHelper));
    }

    /**
     * This method used to get the current pay period begin and end dates  for the current date and
     * plan begin and end date for the pay year
     * @param payYear Year parameter
     * @return returns List of PayrollPayPeriodDetails object
     */
    public List<PayrollPayPeriodDetails> getPayrollPayPeriodDetails( String payYear){
            return db2JdbcTemplate.query(
               sqlHelper.getWeeklyPayrollDateQuery(),
                    new Object[] { payYear },
                    new PayrollPayPeriodDetailsMapper(sqlHelper));
    }

    /**
     * This method used to get the payroll frequency details for the
     * list of associates
     * @param associateIds  List of Associate Win Number details
     * @return returns List of Frequency details value
     */
    public List<PayrollFrequencyDetails> getPayrollFrequencyDetails(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);

        return db2JdbcTemplate.query(
                String.format(sqlHelper.getPayrollFrequencyQuery(),
                        placeholders),
                associateIds.toArray(),
                new PayrollFrequencyMapper(sqlHelper));
    }

    /**
     * This method used to get the Payroll SUI details for the list of
     * associates
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Pay Period Run Date parameter
     * @param payCenterIds list of PayCenter Id parameter
     * @return returns Sui Tax amount value as string
     */
    public List<PayrollSuiTaxDetails> getPayrollSuiTaxDetails(List<String> associateIds,
                                          List<String> payrollRunDates,
                                          List<String> payCenterIds){
        var associatePlaceHolders = getPlaceholdersForQuery(associateIds);
        var runDatePlaceHolders = getPlaceholdersForQuery(payrollRunDates);
        var payCenterPlaceHolders = getPlaceholdersForQuery(payCenterIds);

        List<Object> params = new ArrayList<>(associateIds);
        params.addAll(payrollRunDates);
        params.addAll(payCenterIds);

        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateSuiTaxQuery(),
                        associatePlaceHolders, runDatePlaceHolders, payCenterPlaceHolders),
                params.toArray(),
                new PayrollSuiTaxMapper(sqlHelper));
    }

    /**
     * This method used to get Payroll earnings for the associate
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Pay Period Run Date parameter
     * @param payCenterIds list of PayCenter Id parameter
     * @return returns List of Earning object
     */
    public List<EarningWithAssociateId> getPayrollEarnings(List<String> associateIds,
                                            List<String> payrollRunDates,
                                            List<String> payCenterIds){
        var associatePlaceHolders = getPlaceholdersForQuery(associateIds);
        var runDatePlaceHolders = getPlaceholdersForQuery(payrollRunDates);
        var payCenterPlaceHolders = getPlaceholdersForQuery(payCenterIds);
        List<Object> params = new ArrayList<>(associateIds);
        params.addAll(payrollRunDates);
        params.addAll(payCenterIds);

        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateEarningQuery(),
                        associatePlaceHolders, runDatePlaceHolders, payCenterPlaceHolders),
                params.toArray(),
                new PayrollEarningsMapper(sqlHelper));
    }

    /**
     * This method used to get the Payroll Deductions details for the
     * List of associates
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Pay Period Run Date parameter
     * @param payCenterIds list of PayCenter Id parameter
     * @return returns List of Deduction object
     */
    public List<DeductionWithAssociateId> getPayrollDeductions(List<String> associateIds,
                                                List<String> payrollRunDates,
                                                List<String> payCenterIds){
        var associatePlaceHolders = getPlaceholdersForQuery(associateIds);
        var runDatePlaceHolders = getPlaceholdersForQuery(payrollRunDates);
        var payCenterPlaceHolders = getPlaceholdersForQuery(payCenterIds);
        List<Object> params = new ArrayList<>(associateIds);
        params.addAll(payrollRunDates);
        params.addAll(payCenterIds);

        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateDeductionQuery(),
                        associatePlaceHolders, runDatePlaceHolders, payCenterPlaceHolders),
                params.toArray(),
                new PayrollDeductionsMapper(sqlHelper));
    }

    /**
     * This method used to get the Payroll Hours for the List of associates
     * @param associateIds list of Associate Win Number parameter
     * @param payrollRunDates list of Pay Period Run Date parameter
     * @param payCenterIds list of PayCenter Id parameter
     * @return returns List of PayrollWorkHours object
     */
    public List<PayrollWorkHoursWithAssociateId> getPayrollHours(List<String> associateIds,
                                                  List<String> payrollRunDates,
                                                  List<String> payCenterIds){
        var associatePlaceHolders = getPlaceholdersForQuery(associateIds);
        var runDatePlaceHolders = getPlaceholdersForQuery(payrollRunDates);
        var payCenterPlaceHolders = getPlaceholdersForQuery(payCenterIds);
        List<Object> params = new ArrayList<>(associateIds);
        params.addAll(payrollRunDates);
        params.addAll(payCenterIds);

        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociateHoursQuery(),
                        associatePlaceHolders, runDatePlaceHolders, payCenterPlaceHolders),
                params.toArray(),
                new PayrollHoursMapper(sqlHelper));
    }

    /**
     * This method used to get the Payroll Pay Center details for the List of
     * Associates
     * @param associateIds List of Associate Win Number parameter
     * @return returns List of PayrollBasicDetails object
     */
    public List<PayrollBasicDetails> getPayrollPayCenter(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getAssociatePayCenterQuery(),
                        placeholders, placeholders, placeholders),
                associateIds.toArray(),
                new PayrollPayCenterMapper(sqlHelper));
    }

    /**
     * This method used to get the associate Hire Rescind indicator for the associate
     * @param associateIds List of Associate Win Number details
     * @return returns Hire Rescind indicator details
     */
    public List<HireRescindDetails> getHireRescindIndicator(List<String> associateIds){
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getHireRescindQuery(),
                        placeholders),
                associateIds.toArray(),
                new HireRescindMapper(sqlHelper));
    }

    /**
     * Checks if an associate is a management trainee
     * @param associateIds The associate ID to check
     * @return Boolean indicating if the associate is a management trainee
     */
    public List<ManagementTraineeDetails> isManagementTrainee(List<String> associateIds) {
        String placeholders = getPlaceholdersForQuery(associateIds);
        return db2JdbcTemplate.query(
                String.format(sqlHelper.getManagementTraineeQuery(), placeholders),
                associateIds.toArray(),
                new ManagementTraineeMapper(sqlHelper));
    }

    @NotNull
    private static String getPlaceholdersForQuery(List<String> values) {
        return String.join(",", values.stream().map(value -> "?").toList());
    }
}
