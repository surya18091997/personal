package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.PayrollPayPeriodDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

@AllArgsConstructor
@Component
public class PayrollPayPeriodDetailsMapper implements RowMapper<PayrollPayPeriodDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to PayrollPayPeriodDetails object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns PayrollPayPeriodDetails object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public PayrollPayPeriodDetails mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var payPeriod = new PayrollPayPeriodDetails();
        payPeriod.setCurrencyCode(sqlHelper.getTextOrDefault(
                ColumnConstants.CURRENCY_CODE, rs));
        payPeriod.setBiweeklyPayPeriodStartDate(sqlHelper.getTextOrDefault(
                ColumnConstants.BI_WEEKLY_START_DATE, rs));
        payPeriod.setBiweeklyPayPeriodEndDate(sqlHelper.getTextOrDefault(
                ColumnConstants.BI_WEEKLY_END_DATE, rs));
        payPeriod.setWeeklyPayPeriodStartDate(sqlHelper.getTextOrDefault(
                ColumnConstants.WEEKLY_START_DATE, rs));
        payPeriod.setWeeklyPayPeriodEndDate(sqlHelper.getTextOrDefault(
                ColumnConstants.WEEKLY_END_DATE, rs));
        return payPeriod;
    }
}
