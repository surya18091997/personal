package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.model.PayrollWorkHoursWithAssociateId;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollWorkHours;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class PayrollHoursMapper implements RowMapper<PayrollWorkHoursWithAssociateId> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to PayrollWorkHours object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns PayrollWorkHours object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public PayrollWorkHoursWithAssociateId mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var hours = new PayrollWorkHoursWithAssociateId();
        hours.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        hours.setPayCenterId(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_CENTER_ID, rs));
        hours.setPayrollRunDate(sqlHelper.getTextOrDefault(
                ColumnConstants.RUN_DATE, rs));

        hours.setPayrollWorkHours(new PayrollWorkHours());
        hours.getPayrollWorkHours().setType(sqlHelper.getTextOrDefault(
                ColumnConstants.HOUR_TYPE_CODE, rs));
        hours.getPayrollWorkHours().setHours(rs.getDouble(ColumnConstants.HOURS_QTY));
        return hours;
    }
}
