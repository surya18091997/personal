package com.walmart.benefits.connector.api.common;

import java.util.List;

public class CommonConstants {

    private CommonConstants() {
    }

    public static final String EXCLUDED_HOURS_TYPE = "05,12,13,15,25,26,27,16";
    public static final String ASSOCIATE_ID_ERROR = "Associate id must be greater than 0";
    public static final String ASSOCIATE_IDS_ERROR = "Associate id list " +
            "cannot be empty";
    public static final String ASSOCIATE_IDS_COUNT_ERROR = "Associate id list" +
            " size cannot be greater than %s";
    public static final String UNEXPECTED_ERROR = "An unexpected error " +
            "occurred.";
    public static final String BAD_REQUEST_ERROR = "Could not process the " +
            "request due to some invalid input.";
    public static final String WEEKLY_PAY_FREQUENCY_CODE = "W";
    public static final String BI_WEEKLY_PAY_FREQUENCY_CODE = "B";
    public static final String DOE_FREQUENCY_CODE_AUTO = "A";
    public static final String SSN = "SSN";
    public static final String ASYNC_THREAD_NAME = "Async-Api-";
    public static final String ZERO = "0";
    public static final String ASSOCIATE_NOT_FOUND = "Associate(s) not found";
    public static final String PAYROLL_DETAILS_NOT_FOUND = "Payroll details " +
            "not found for the given associate(s)";
    public static final String PAY_PERIOD_NOT_FOUND = "Pay period not found";
    public static final String COMPLETION_EXCEPTION = "CompletionException";
    public static final String RESOURCE_NOT_FOUND_EXCEPTION =
            "ResourceNotFoundException";
    public static final String ILLEGAL_ARGUMENT_EXCEPTION = "IllegalArgumentException";
    public static final String YES = "Y";
    public static final String STRING_EMPTY = "";
    public static final String PERCENTAGE_METHOD_CODE = "0,2,3,4,5,9";
    public static final Double ZERO_DOUBLE = 0.0;
    public static final long ZERO_LONG = 0;
    public static final int MAX_ASSOCIATE_COUNT = 20;
    public static final String EARNING_TYPE_REGULAR = "1";
    public static final String EARNING_TYPE_OT = "2";
    public static final int DEFAULT_RETRY_DELAY = 100;
    public static final String PAYROLL_INFO="payrollInfo";
    public static final String ASSOCIATE_INFO="associateInfo";

    public static final String UTC_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSX";
    public static final String DB2_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final int ZERO_INT = 0;
    public static final int ONE_INT = 1;
    public static final int MAX_WIDTH = 9;
    public static final String BIWEEKLY_PAY_CENTER_1 = "1";
    public static final String BIWEEKLY_PAY_CENTER_2 = "2";
    public static final String WEEKLY_PAY_CENTER_4 = "4";

    public static final List<String> BIWEEKLY_PAY_CENTERS =
            List.of(BIWEEKLY_PAY_CENTER_1, BIWEEKLY_PAY_CENTER_2);
}
