package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.intradomain.profile.Address;
import lombok.Data;

@Data
public class AddressWithAssociateId {
    private String associateId;
    private Address address;
}
