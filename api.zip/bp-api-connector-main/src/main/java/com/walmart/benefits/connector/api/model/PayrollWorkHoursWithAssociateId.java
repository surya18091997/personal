package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollWorkHours;
import lombok.Data;

@Data
public class PayrollWorkHoursWithAssociateId {
    private String associateId;
    private String payCenterId;
    private String payrollRunDate;
    private PayrollWorkHours payrollWorkHours;
}
