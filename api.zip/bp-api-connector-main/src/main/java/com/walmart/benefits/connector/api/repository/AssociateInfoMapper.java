package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.*;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollFrequency;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@AllArgsConstructor
@Component
public class AssociateInfoMapper implements RowMapper<AssociateInfo> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to AssociateInfo object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns AssociateInfo object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public AssociateInfo mapRow(ResultSet rs, int rowNum) throws SQLException, EmptyResultDataAccessException {
        var profile = new AssociateInfo();
        profile.setAssociateId(rs.getString(ColumnConstants.WIN_NBR));
        mapPersonalInfo(rs, profile);
        var employment = new Employment();
        mapEmploymentInfo(rs, employment);
        mapStoreInfo(rs, employment, profile);
        mapLeaveInfo(rs, employment, profile);
        mapContactInfo(rs, profile);
        mapGovernmentIdDetails(rs, profile);
        return profile;
    }

    private void mapContactInfo(ResultSet rs, AssociateInfo profile) throws SQLException {
        var contactInfo = new Contact();
        contactInfo.setPhoneNumber(sqlHelper.getTextOrDefault(ColumnConstants.HOME_PHONE_NBR, rs));
        profile.setContact(contactInfo);
    }

    private void mapPersonalInfo(ResultSet rs, AssociateInfo profile) throws SQLException {
        var personalInfo = new PersonalInfo();
        personalInfo.setFirstName(sqlHelper.getTextOrDefault(ColumnConstants.FIRST_NAME, rs));
        personalInfo.setLastName(sqlHelper.getTextOrDefault(ColumnConstants.LAST_NAME
                , rs));
        personalInfo.setMiddleName(sqlHelper.getTextOrDefault(ColumnConstants.MIDDLE_INITIAL, rs));
        personalInfo.setGender(sqlHelper.getTextOrDefault(ColumnConstants.GENDER_CODE, rs));
        personalInfo.setBirthDate(sqlHelper.getTextOrDefault(ColumnConstants.BIRTH_DATE, rs));
        personalInfo.setMaritalStatus(sqlHelper.getTextOrDefault(ColumnConstants.MARITAL_CODE,
                rs));
        personalInfo.setStateCode(sqlHelper.getTextOrDefault(ColumnConstants.STATE_PROV_CODE, rs));
        personalInfo.setCountryCode(sqlHelper.getTextOrDefault(ColumnConstants.COUNTRY_CODE, rs));
        profile.setPersonalInfo(personalInfo);
    }

    private void mapEmploymentInfo(ResultSet rs, Employment employment) throws SQLException {
        employment.setStatusCode(sqlHelper.getTextOrDefault(ColumnConstants.EMP_STATUS_CODE
                , rs));
        employment.setPayRateType(sqlHelper.getTextOrDefault(ColumnConstants.PAY_TYPE_CODE, rs));
        employment.setPositionType(sqlHelper.getTextOrDefault(ColumnConstants.ASC_TYPE_CODE, rs));
        employment.setHireDate(sqlHelper.getTextOrDefault(ColumnConstants.HIRE_DATE,
                rs));
        employment.setOriginalHireDate(sqlHelper.getTextOrDefault(
                ColumnConstants.ORIGINAL_HIRE_DATE,
                rs));
        employment.setTermDate(sqlHelper.getTextOrDefault(ColumnConstants.TERMINATION_DATE,
                rs));
        employment.setTermReason(sqlHelper.getTextOrDefault(ColumnConstants.TERM_REASON_CODE,
                rs));
        employment.setPayrollFrequency(getPayrollFrequency(sqlHelper.getTextOrDefault(ColumnConstants.COMP_FREQ_CODE,
                rs)));
        employment.setReportingTo(sqlHelper.getTextOrDefault(ColumnConstants.MGR_WIN_NBR,
                rs));
    }

    private PayrollFrequency getPayrollFrequency(String frequencyCode){
        var freqCode = StringUtils.hasText(frequencyCode) ? frequencyCode :
                CommonConstants.BI_WEEKLY_PAY_FREQUENCY_CODE;
        if(freqCode.trim().equals(CommonConstants.WEEKLY_PAY_FREQUENCY_CODE)){
            return PayrollFrequency.WEEKLY;
        }
        else{
            return PayrollFrequency.BI_WEEKLY;
        }
    }

    private void mapStoreInfo(ResultSet rs, Employment employment, AssociateInfo profile) throws SQLException {
        var storeInfo = new StoreInfo();
        storeInfo.setStoreNumber(sqlHelper.getTextOrDefault(ColumnConstants.STORE_NBR
                , rs));
        storeInfo.setChargeStoreNumber(sqlHelper.getTextOrDefault(ColumnConstants.ASC_STORE_NBR, rs));
        storeInfo.setStoreStateProvCd(sqlHelper.getTextOrDefault(ColumnConstants.STORE_STATE_PROV_CD, rs));
        storeInfo.setChargeDivisionNumber(sqlHelper.getTextOrDefault(ColumnConstants.CHRG_DIV_NBR, rs));
        employment.setStoreInfo(storeInfo);
        profile.setEmployment(employment);
    }

    private void mapLeaveInfo(ResultSet rs, Employment employment,
                          AssociateInfo profile) throws SQLException {
        var leaveInfo = new LeaveInfo();
        leaveInfo.setLoaCode(sqlHelper.getTextOrDefault(ColumnConstants.LOA_CODE
                , rs));
        leaveInfo.setLeaveStartDate(sqlHelper.getTextOrDefault(ColumnConstants.LOA_EFF_DATE,
                rs));
        leaveInfo.setLeaveReturnDate(sqlHelper.getTextOrDefault(ColumnConstants.LOA_RETURN_DATE, rs));
        employment.setLeaveInfo(leaveInfo);
        profile.setEmployment(employment);
    }

    private void mapGovernmentIdDetails(ResultSet rs, AssociateInfo profile) throws SQLException {
        var governmentId = new GovernmentId();
        governmentId.setActive(true);
        governmentId.setId(sqlHelper.getTextOrDefault(ColumnConstants.NATIONAL_ID, rs));
        governmentId.setIdType(CommonConstants.SSN);
        var governmentIdList = new ArrayList<GovernmentId>();
        governmentIdList.add(governmentId);
        profile.setGovernmentId(governmentIdList);
    }
}
