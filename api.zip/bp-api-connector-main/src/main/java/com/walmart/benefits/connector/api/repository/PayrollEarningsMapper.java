package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.EarningWithAssociateId;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Earning;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.EarningType;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class PayrollEarningsMapper implements RowMapper<EarningWithAssociateId> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to Earning object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns Earning object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public EarningWithAssociateId mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var earning = new EarningWithAssociateId();
        earning.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        earning.setPayCenterId(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_CENTER_ID, rs));
        earning.setPayrollRunDate(sqlHelper.getTextOrDefault(
                ColumnConstants.RUN_DATE, rs));
        earning.setEarning(new Earning());
        earning.getEarning().setPaySequenceId(sqlHelper.getTextOrDefault(
                        ColumnConstants.PAY_SEQ_CODE, rs));
        earning.getEarning().setType(getEarningType(sqlHelper.getTextOrDefault(
                ColumnConstants.EARNING_TYPE_CODE, rs)));
        earning.getEarning().setAmount(rs.getDouble(ColumnConstants.EARN_AMT));
        earning.getEarning().setYtdAmount(rs.getDouble(ColumnConstants.YTD_TOT_EARN_AMT));
        return earning;
    }

    private EarningType getEarningType(String earningType) {
        return switch (earningType) {
            case CommonConstants.EARNING_TYPE_REGULAR -> EarningType.REGULAR;
            case CommonConstants.EARNING_TYPE_OT -> EarningType.OT;
            default -> EarningType.OTHER;
        };
    }
}
