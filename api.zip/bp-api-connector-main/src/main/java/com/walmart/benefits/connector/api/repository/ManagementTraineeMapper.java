package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.ManagementTraineeDetails;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@AllArgsConstructor
@Component
public class ManagementTraineeMapper implements RowMapper<ManagementTraineeDetails> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps the management trainee indicator result
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns Boolean indicating if the associate is a management trainee
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    @Override
    public ManagementTraineeDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

            var managementTraineeDetails = new ManagementTraineeDetails();
            managementTraineeDetails.setAssociateId(sqlHelper.getTextOrDefault(
                    ColumnConstants.WIN_NBR, rs));
            managementTraineeDetails.setIsManagementTrainee(
                    rs.getInt(ColumnConstants.IS_MANAGEMENT_TRAINEE) == CommonConstants.ONE_INT);
            return managementTraineeDetails;
        }
    }