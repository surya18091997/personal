package com.walmart.benefits.connector.api.repository;

import com.walmart.benefits.connector.api.common.ColumnConstants;
import com.walmart.benefits.connector.api.common.CommonConstants;
import com.walmart.benefits.connector.api.model.DeductionWithAssociateId;
import com.walmart.benefits.connector.api.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.Deduction;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.DeductionFrequency;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

@AllArgsConstructor
@Component
public class PayrollDeductionsMapper implements RowMapper<DeductionWithAssociateId> {

    private final SQLHelper sqlHelper;

    /**
     * This method maps to Deduction object
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns Deduction object
     * @throws SQLException throws SQLException
     * @throws EmptyResultDataAccessException throws EmptyResultDataAccessException
     */
    public DeductionWithAssociateId mapRow(ResultSet rs, int rowNum) throws SQLException,
            EmptyResultDataAccessException {
        var deduction = new DeductionWithAssociateId();
        deduction.setAssociateId(sqlHelper.getTextOrDefault(
                ColumnConstants.WIN_NBR, rs));
        deduction.setPayCenterId(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_CENTER_ID, rs));
        deduction.setPayrollRunDate(sqlHelper.getTextOrDefault(
                ColumnConstants.RUN_DATE, rs));
        deduction.setDeduction(new Deduction());
        deduction.getDeduction().setPaySequenceId(sqlHelper.getTextOrDefault(
                ColumnConstants.PAY_SEQ_CODE, rs));
        deduction.getDeduction().setPlanCode(sqlHelper.getTextOrDefault(
                ColumnConstants.DOE_CODE, rs));
        deduction.getDeduction().setType(sqlHelper.getTextOrDefault(
                ColumnConstants.DOE_CODE, rs));
        deduction.getDeduction().setCurrentAmount(rs.getDouble(ColumnConstants.DEDUCTION_AMT));
        deduction.getDeduction().setYtdAmount( rs.getDouble(ColumnConstants.YTD_TOT_DOE_AMT));
        deduction.getDeduction().setMethod(sqlHelper.getTextOrDefault(
                ColumnConstants.METHOD, rs));
        deduction.getDeduction().setFrequency(getDeductionFrequencyValue(sqlHelper.getTextOrDefault(
                ColumnConstants.DOE_FREQUENCY_CODE, rs)));
        deduction.getDeduction().setNetLimitAmount(rs.getDouble(ColumnConstants.NET_LIMIT_AMT));
        deduction.getDeduction().setArrearsAmount(rs.getDouble(ColumnConstants.ARREAR_DOE_AMT));
        deduction.getDeduction().setArrearsYtd(rs.getDouble(ColumnConstants.YTD_TOT_ARREAR_AMT));
        deduction.getDeduction().setStartDate(sqlHelper.getTextOrDefault(
                ColumnConstants.DOE_START_DT, rs));
        deduction.getDeduction().setEndDate(sqlHelper.getTextOrDefault(
                ColumnConstants.DOE_END_DT, rs));

        setAmountOrPercentage(rs, deduction.getDeduction());

        return deduction;
    }

    private void setAmountOrPercentage(ResultSet rs, Deduction deduction) throws SQLException {
        if(isPercentage(deduction.getMethod())){
            deduction.setPercentage(Double.parseDouble(sqlHelper.getTextOrDefault(
                    ColumnConstants.PERCENTAGE, rs)));
            deduction.setAmount(CommonConstants.ZERO_DOUBLE);
        }
        else {
            deduction.setAmount(Double.parseDouble(sqlHelper.getTextOrDefault(
                    ColumnConstants.PERCENTAGE, rs)));
            deduction.setPercentage(CommonConstants.ZERO_DOUBLE);
        }
    }

    private DeductionFrequency getDeductionFrequencyValue(String frequencyCode){
        if(frequencyCode.equals(CommonConstants.DOE_FREQUENCY_CODE_AUTO)){
            return DeductionFrequency.AUTOMATIC;
        }
        else {
            return DeductionFrequency.ONE_TIME;
        }
    }

    private boolean isPercentage(String methodCode){
        String[] values = CommonConstants.PERCENTAGE_METHOD_CODE.split(",");
        return Arrays.asList(values).contains(methodCode);
    }
}
