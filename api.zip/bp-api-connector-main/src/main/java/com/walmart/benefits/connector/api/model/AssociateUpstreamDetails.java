package com.walmart.benefits.connector.api.model;

import com.walmart.benefitsplatformentitymodel.interdomain.gta.GtaInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.payroll.PayrollInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssociateUpstreamDetails {
    private AssociateInfo associateInfo;
    private GtaInfo gtaInfo;
    private List<PayrollInfo> payrollInfo;
}
