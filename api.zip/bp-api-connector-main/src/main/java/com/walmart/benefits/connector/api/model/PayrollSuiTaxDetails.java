package com.walmart.benefits.connector.api.model;

import lombok.Data;

@Data
public class PayrollSuiTaxDetails {
    private String associateId;
    private String payCenterId;
    private String payrollRunDate;
    private String payrollSuiTax;
}
