export const getSrvcWidoutInp : string = "/BOSS/getSrvcWithoutInp/";
export const postSrvc2 = "/BOSS/postSrvc2/";
export const postSrvcWidInp = "/BOSS/postSrvcWidInp/";