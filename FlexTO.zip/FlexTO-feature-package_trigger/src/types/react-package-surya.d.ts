// src/types/react-package-surya.d.ts

declare module 'react-package-surya' {
    // Add the types for the exports of 'react-package-surya' here
    // For example, if it exports a component named `Base`, you could declare it like this:
  
    import { FC } from 'react';
  
    export interface BaseProps {
      angularRouter: any;
      userAccess: any;
    }
  
    export const Base: FC<BaseProps>;
}
 