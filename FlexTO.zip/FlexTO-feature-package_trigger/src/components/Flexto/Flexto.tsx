import React, { useState, useEffect } from 'react';
import PrimaryTab from '../Primary/PrimaryTab';
import SecondaryTab from '../Secondary/SecondaryTab';
import EligibleTab from '../EligibleCostCenters/EligibleTab';
import * as Icon from "@livingdesign/icons";
import { ErrorMessage, Heading, Divider, IconButton, LivingDesignProvider} from "@walmart-web/livingdesign-components";
import axios from 'axios';
import { getSrvcWidoutInp, postSrvcWidInp } from 'src/utils/Constants';
import './Flexto.css';

interface Rule {
  ruleId: number;
  ruleName: string;
  ruleType: string;
}

interface SecRule {
  id: number,
  costCenter: number;
  ruleId: number;
  ruleName: string
}

interface CostCenter {
  seqNumber: number,
  storeNumber: number,
  stateProvCode: string,
  countryCode: string,
  effectiveDate: Date,
  obsoleteDate: Date,
  historyFlag: boolean,
  status: string
}

interface BaseProps{
  angularRouter : any,
  userAccess : any,
}

const Base:React.FC<BaseProps> = ({angularRouter, userAccess}) => {
  const admin = userAccess.includes('19_UPDATE');
  const [activeTab, setActiveTab] = useState<string>("Eligibility Rules");
  const [addEligOpen, setAddEligOpen] = useState<boolean>(false);
  const [exceptionSubPage, setExceptionSubPage] = useState<boolean>(false);
  const [rules, setRules] = useState<Rule[]>([]);
  const [secRules, setSecRules] = useState<SecRule[]>([]);
  const [secRulesFiltered, setSecRulesFiltered] = useState<SecRule[]>([]);
  const [EligibleCostCenters, setEligibleCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [apiErrored, setApiErrored] = useState<boolean>(false);

  const fetchRules = async () => {
    const response = await axios.get(getSrvcWidoutInp+'12'+'/eligibility_rules'); 
    const data: Rule[] = response.data.data; // parse JSON
    setRules(data); // Set the rules in state
  };

  const fetchSecRules = async () => {
    const response = await axios.get(getSrvcWidoutInp+'12'+'/exception'); 
    const data: SecRule[] = response.data.data; // parse JSON
    setSecRules(data); // Set the rules in state
  };

  const fetchEligCostCenters = async () => {
    const response = await axios.get(getSrvcWidoutInp+'12'+'/cost_centers_eligibility_summary'); 
    const data: any = response.data.data; // parse JSON
    let newData = data.map(item => {
      return {
        ...item,
        effectiveDate: new Date(item.effectiveDate),
        obsoleteDate: item.obsoleteDate ? new Date(item.obsoleteDate) : null
      };
    });
    setEligibleCostCenters(newData); // Set the rules in state
  };

  useEffect(() => {
    const fetchData = async () => {
      try{
        // Await the completion of all API calls using Promise.all
        await Promise.all([fetchRules(), fetchSecRules(), fetchEligCostCenters()]);
        // Set state after all calls have completed
      } catch(err: any){
        setApiErrored(true);
        console.log(err);
      }
      finally {
        // Set loading to false after API calls (either success or failure)
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const showTab = (tab: string) => {
    setAddEligOpen(false);
    setActiveTab(tab);
  }

  function filterRulesById(ruleId: number) {
    // Use the filter method to get all rules with the specified ruleId
    return secRules.filter(rule => rule.ruleId === ruleId);
  }

  const eligibleSubPageOpen = (ruleId: number) => {
    setSecRulesFiltered(filterRulesById(ruleId));
    setExceptionSubPage(!exceptionSubPage);
    setActiveTab("Exception");
  }

  const eligibleSubPageBackHandler = () =>{
    setActiveTab("Eligibility Rules");
    setExceptionSubPage(!exceptionSubPage);
  }

  const deletePriRuleHandler = async(ruleId: number) =>{
    const res = await axios.post(postSrvcWidInp + '12' + `/eligibility_rules/delete/${ruleId}`);
    return res;
  }

  const deleteSecRuleHandler = async(ruleId: number) =>{
    const res = await axios.post(postSrvcWidInp + '12' + `/exception/delete/${ruleId}`);
    return res;
  }

  const breadcrumbClickHandler = (crumb: string) => {
    if(crumb!==activeTab){
      if(crumb=="BOSS"){
        angularRouter.navigateByUrl('/landingDomain');
      }
      else if(exceptionSubPage){
        setActiveTab("Eligibility Rules");
        setExceptionSubPage(!exceptionSubPage);
      }
    }
  }

  return (
    <>
    <LivingDesignProvider>
    {!apiErrored ? (
    <div className="flexto-div">
      <div className="table-container">
        <div className="page-container">
          <div className='bcrumb-container'>
            <a className='breadcrumb' onClick={()=>{breadcrumbClickHandler("BOSS")}}><span>BOSS</span></a>
            <span className='bdivider'>/</span>
            {exceptionSubPage &&
              (
              <><a className='breadcrumb' onClick={()=>{breadcrumbClickHandler("Eligibility Rules")}}><span>Eligibility Rules</span></a>
              <span className='bdivider'>/</span>
              </>)}
            <a className='breadcrumb bactive' onClick={()=>{breadcrumbClickHandler(activeTab)}}><span>{activeTab}</span></a>
        </div>
          {!exceptionSubPage && (
            <>
            <div className="header-container marginBottom20">
              <Heading size="large">FlexTO Eligibility Tool</Heading>
            </div>
            </>
          )}
          {exceptionSubPage && (
            <div className='subpage-header'>
              <div className="back-div margin-horizontal">
            <IconButton size='medium' a11yLabel='ChevronLeft' onClick={()=>{eligibleSubPageBackHandler()}}>
            <Icon.ChevronLeft />
            </IconButton>
            <p className='font17 marginLeft10'><strong>Partially include</strong> for <strong>Other Operational</strong></p>
          </div>
            </div>
          )}
          <div className="flex-page">
            {/* </div><div className={`inner-tab-container tab-${activeTab}`}> */}
            <div className={`inner-tab-container`}>
            {!exceptionSubPage && (
              <>
              <div className="mat-tab-group-container">
                <div>
                  <button className={`button-flex-tab ${activeTab === "Eligibility Rules" ? 'active' : ''}`} id="defaultOpen" onClick={() => showTab("Eligibility Rules")}>
                    Eligibility Rules
                  </button>
                </div>
                <div>
                  <button className={`button-flex-tab ${activeTab === "Exception" ? 'active' : ''}`} onClick={() => showTab("Exception")}>
                    Exception
                  </button>
                </div>
                <div>
                  <button className={`button-flex-tab ${activeTab === "Cost Center Eligibility Summary" ? 'active' : ''}`} onClick={() => showTab("Cost Center Eligibility Summary")}>
                    Cost Center Eligibility Summary
                  </button>
                </div>
              </div>
              <Divider />
              </>
            )}  
                <div className='marginTop20'>
                {activeTab === "Eligibility Rules" && <PrimaryTab isAdmin={admin} rules={rules} toSec={eligibleSubPageOpen} deletePriRuleHandler={deletePriRuleHandler} isLoading={loading} fetchRules={fetchRules}/>}
                {activeTab === "Exception" && <SecondaryTab isAdmin={admin} secRules={exceptionSubPage ? secRulesFiltered : secRules} deleteSecRuleHandler={deleteSecRuleHandler} isLoading={loading} fetchSecRules={fetchSecRules}/>}
                {activeTab === "Cost Center Eligibility Summary" && <EligibleTab costCenters={EligibleCostCenters}isLoading={loading}/>}
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    ):(
          <ErrorMessage
      title="Service details aren’t available right now"
      // media={
      //   <img alt="" height="200" src="/SearchNotFoundCircle.svg" width="200" />
      // }
        >
      Refresh this page to try again.
    </ErrorMessage>
    )}
    </LivingDesignProvider>
  </>
  );
};

export default Base;
