import React, {useState} from 'react';
import {
  DataTable,
  DataTableCell,
  DataTableCellActions,
  DataTableHead,
  DataTableHeader,
  DataTableBody,
  DataTableRow,
  IconButton,
  Modal,
  Button,
  ButtonGroup,
  Panel,
  TextField,
  Spinner,
  Caption,
  Divider,
  DataTableHeaderProps
} from "@walmart-web/livingdesign-components";
import SelectWrapper from '../SelectWrapper/SelectWrapper';
import SkeletonTableWrapper from '../SkeletonWrapper/SkeletonTableWrapper';
import * as Icon from "@livingdesign/icons";
import axios from 'axios';
import { postSrvc2 } from 'src/utils/Constants';

// Sleep function using Promise
const sleep = (ms:any) => new Promise(resolve => setTimeout(resolve, ms));

interface SecRule {
    id : number,
    costCenter: number;
    ruleId: number;
    ruleName: string
}

interface SecondaryTabProps {
    isAdmin: boolean,
    secRules: SecRule[];
    deleteSecRuleHandler: any,
    isLoading: boolean,
    fetchSecRules: any
}

const SecondaryTab:React.FC<SecondaryTabProps> = ({isAdmin, secRules, deleteSecRuleHandler, isLoading, fetchSecRules}) => {
  const orgValues = [...new Set(secRules.map(obj => obj.ruleName))];
  const [filteredSecRules, setFilteredSecRules] = useState<SecRule[]>(secRules);
  const [isDeleteClicked, setIsDeleteClicked] = useState<boolean>(false);
  const [deleteRuleId, setDeleteRuleId] = useState<number>(0);
  const [addEligOpen, setAddEligOpen] = useState<boolean>(false);
  const [costCenter, setCostCenter] = useState<string>("");
  const [ruleType, setRuleType] = useState<string>('Overheads');
  const [isFormLoading, setIsFormLoading] = useState<boolean>(false);
  const [costCenterError, setCostCenterError] = useState<string>("");
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);
  const [sortDirection, setSortDirection] = useState<DataTableHeaderProps['sort']>("ascending");
  const [isFilterClicked, setIsFilterClicked] = useState<boolean>(false);
  const [orgFiltered, setOrgFiltered] = useState<string>("");

  const deleteClicked = (id:number) =>{
    setIsDeleteClicked(true);
    setDeleteRuleId(id);
  }

  const deleteSubmitHandler = async(id:number) =>{
    try{
      setIsFormLoading(true);
      const res = await deleteSecRuleHandler(id);
      fetchSecRules();
      setIsDeleteClicked(false);
    }
    catch (error: any) {
      // Handle error
      console.error('Error during deleting:', error);
    } finally {
      setIsFormLoading(false);
    }
  }

  const defaultValues = ()=>{
    setCostCenter("");
    setRuleType('Overheads');
    setCostCenterError("");
  }


  const addExceptionHandler = async()=>{
    try {
      if (costCenter==null){
        setCostCenterError('Cost center is not available or does not match.');
        return
      }
      setIsFormLoading(true);
      const data = {
        ruleId: 1,
        costCenter: Number(costCenter)
      }
      console.log(data);
      //submit data
      const response = await axios.post(postSrvc2+'12'+'/exception/insert', data);
      //Handle success
      console.log('Response from API:', response.data);
      fetchSecRules();
      setFormSubmitted(true);
      defaultValues();
    } catch (error: any) {
      // Handle error
      console.error('Error during form submission:', error);
    } finally {
      setIsFormLoading(false);
    }
  }

  const closeHandler = ()=>{
    if(isFormLoading){
      return;
    }
    setFormSubmitted(false);
    defaultValues();
    setAddEligOpen(false);
  }

  const sortHandler = ()=>{
    let sortedSecRules = [...filteredSecRules];
    if (sortDirection==="ascending"){
    sortedSecRules.sort((a, b) =>  b.costCenter - a.costCenter);
    setSortDirection("descending")}
    else{
      sortedSecRules.sort((a, b) =>  a.costCenter - b.costCenter);
      setSortDirection("ascending");
    }
    setFilteredSecRules(sortedSecRules);
  }

  const filterHandler = ()=>{
    let newFilteredCostCenters = [...secRules];
    if(orgFiltered!==""){
      newFilteredCostCenters = newFilteredCostCenters.filter((item) => {
        return item.ruleName === orgFiltered;
      });
      setFilteredSecRules(newFilteredCostCenters);
    }
    setIsFilterClicked(false);
    setOrgFiltered("");
  }

  return (
    <>
    <Panel onClose={() => setIsFilterClicked(false)} title="Select Filters" isOpen={isFilterClicked}
    position='right'
    size='medium'
    actions={
      <ButtonGroup>
        <Button variant="tertiary" onClick={defaultValues} size='medium' disabled={isFormLoading}>Cancel</Button>
        {isFormLoading?(<Button variant="primary" size='medium' disabled>
          <Spinner size='small' color='white'/>
          <span className='marginLeft5'>Filtering</span></Button>):(
          <Button variant="primary" onClick={filterHandler} size='medium'>Filter</Button>
        )}
      </ButtonGroup>}
    closeButtonProps={{ "aria-label": "Close Panel" }}>
      <SelectWrapper
        label="Organization name"
        onChange={(e)=>{setOrgFiltered(e.target.value)}}
        value={orgFiltered}
        disabled={isFormLoading}>
        <option value={"Select"}>{"Select"}</option>
        {orgValues.map((value)=>(
          <option value={value}>{value}</option>
        ))}
      </SelectWrapper>
    </Panel>

    {/* Add Cost Center Button */}
    <div className='button-container'>
    <Button variant="tertiary" size="medium" onClick={()=>{setIsFilterClicked(!isFilterClicked)}} disabled={!isAdmin||isLoading}>Filter</Button>
    <Button variant="primary" size="medium" onClick={()=>{setAddEligOpen(true)}} disabled={!isAdmin||isLoading}>Add Cost Center</Button>
    </div>

    {/* Add Cost Center Popup Form */}
      <Panel
      actions={
        formSubmitted ? (
          <Button variant="primary" onClick={closeHandler} size='medium' isFullWidth={true}>Done</Button>
        ):(
        <ButtonGroup>
          <Button variant="tertiary" onClick={defaultValues} size='medium' disabled={isFormLoading}>Cancel</Button>
          {isFormLoading?(<Button variant="primary" size='medium' disabled>
            <Spinner size='small' color='white'/>
            <span className='marginLeft5'>Submitting</span></Button>):(
            <Button variant="primary" onClick={addExceptionHandler} size='medium'>Submit</Button>
          )}
        </ButtonGroup>
        )
      }
      closeButtonProps={{ "aria-label": "Close Panel" }}
      isOpen={addEligOpen}
      onClose={()=>{closeHandler()}}
      title="Add Cost Center"
      position='right'
      size="medium"
    >
      {formSubmitted ? (
          <div className='panel-success'>
            <Icon.CheckCircle size='large'/>
            <br/>
          <p className='bold'>Exception added successfully!</p>
          <p className='marginTop20 padding20'>Added exception rule will be effective by next 11PM.</p>
          </div>
        ):(
          <>
      {/* Cost Center Number */}
      <div className='marginDown15'>
      <TextField
            helperText="Please provide correct cost center number"
            label="Cost Center Number"
            onChange={(e) => setCostCenter(e.target.value)}
            value={costCenter}
            type="number"
            placeholder='786'
            error={costCenterError!=null ? costCenterError : null}
            disabled={isFormLoading}
          />
      </div>
      {/* Organization Name Dropdown */}
      <SelectWrapper
        label="Choose a Organization Name"
        onChange={(e) => setRuleType(e.target.value)}
        value={ruleType}
        disabled={isFormLoading}
      >
        <option value="Overheads">Overheads</option>
        <option value="Other Operational">Other Operational</option>
        <option value="SupplyChain">SupplyChain</option>
        <option value="WFP_Operational">WFP_Operational</option>
        <option value="Store - Club">Store - Club</option>
      </SelectWrapper>
      </>
        )}
    </Panel>
    <div className='data-table-container marginTop20 marginBottom20'>
    <DataTable>
      <DataTableHead>
        <DataTableRow>
          <DataTableHeader
          onSort={sortHandler}
          sort={sortDirection}
          >Cost Center</DataTableHeader>
          <DataTableHeader>Organisation</DataTableHeader>
          <DataTableHeader>Actions</DataTableHeader>
        </DataTableRow>
      </DataTableHead>
      <DataTableBody>
      {isLoading ? <SkeletonTableWrapper columnCount={3}/>:(
        filteredSecRules.map((rule) => (
          <DataTableRow key={rule.ruleId}>
            <DataTableCell>{rule.costCenter}</DataTableCell>
            <DataTableCell>{rule.ruleName}</DataTableCell>
            <DataTableCell>
            <IconButton a11yLabel="Delete" onClick={() => deleteClicked(rule.id)} disabled={!isAdmin}>
              <Icon.TrashCan />
            </IconButton>
            </DataTableCell>
          </DataTableRow>
        )))}
      </DataTableBody>
    </DataTable>
    </div>
    <div className='align-right marginBottom20'><Caption>**Scroll to view the complete data.</Caption></div>
    {/* slide pop up for add elig */}
    <Modal isOpen={isDeleteClicked} size="medium" onClose={() => setIsDeleteClicked(false)} title="Delete Eligibility File">
      <p className='popup-cont'>
      <p className='popuptext'>Every organization must have an eligibility rule. If you delete this rule, you must add a new one.</p>
      <p className='delete-pop bold'>Are you sure you want to delete this rule?</p>
      <p><Divider/></p>
      <div className='buttonright'>
        <ButtonGroup>
          <Button variant="tertiary" size="medium" onClick={()=>{setIsDeleteClicked(false)}} disabled={isFormLoading?true:false}>Cancel</Button>
          {isFormLoading?(
          <Button size="medium" variant="destructive" disabled>
            <Spinner size='small'/><span className='marginLeft5'>Deleting</span></Button>
          ):(<Button size="medium" variant="destructive" onClick={()=>deleteSubmitHandler(deleteRuleId)}>Delete</Button>)}
        </ButtonGroup>
      </div>
      </p>
    </Modal>
    </>
  );
};

export default SecondaryTab;