import React from 'react';
import { Select,SelectProps } from '@walmart-web/livingdesign-components';

interface SelectWrapperProps extends SelectProps{
  marginBottom?: string;
}

const SelectWrapper: React.FC<SelectWrapperProps> = ({ marginBottom = '10px', ...props }) => {

  return (
    <div style={{ marginBottom }}>
      <Select {...props} />
    </div>
  );
};

export default SelectWrapper;