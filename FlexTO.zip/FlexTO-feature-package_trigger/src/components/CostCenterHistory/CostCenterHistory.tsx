import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { Modal,Tag, DataTable,DataTableBody,DataTableCell,DataTableHead,DataTableHeader,DataTableRow,DataTableCellStatus} from "@walmart-web/livingdesign-components";
import SkeletonTableWrapper from '../SkeletonWrapper/SkeletonTableWrapper';

interface CostCenterHistoryProps {
    costCenterId : number | undefined,
    onModalCloseHandler : any
}

interface History{
    storeNumber : number,
    stateProvCode : string,
    countryCode : string,
    effectiveDate : string,
    obsoleteDate : string,
    seqNumber : number,
    historyFlag : boolean,
    status : string
}

const CostCenterHistory : React.FC<CostCenterHistoryProps> = ({costCenterId, onModalCloseHandler}) => {

    const [historyData, setHistoryData] = useState<History[]>([]);
    const [apiErrored, setApiErrored] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(() => {
        const fetchData = async () => {
          try{
            setLoading(true);
            const response = await axios.get(`api/flexto/cost_center_history/${costCenterId}`); 
            const data: History[] = response.data.data; // parse JSON
            setHistoryData(data); // Set the rules in state
          } catch(err: any){
            setApiErrored(true);
            console.log(err);
          }
          finally {
            // Set loading to false after API calls (either success or failure)
            setLoading(false);
          }
        }
        fetchData();
      }, []);

return (
    <>
    <Modal isOpen={true} size="large" title="Cost Center Eligibility History" onClose={onModalCloseHandler}>
    <DataTable>
      <DataTableHead>
        <DataTableRow>
          <DataTableHeader>Store Number</DataTableHeader>
          <DataTableHeader>Status</DataTableHeader>
          <DataTableHeader>Effective Date</DataTableHeader>
          <DataTableHeader>Obsolete Date</DataTableHeader>
        </DataTableRow>
      </DataTableHead>
      <DataTableBody>
      {loading ? <SkeletonTableWrapper columnCount={4}/>:(
        historyData.map((history) => (
          <DataTableRow key={history.seqNumber}>
            <DataTableCell>{history.storeNumber}</DataTableCell>
            <DataTableCellStatus>
              <Tag color={history.status=="Eligible"?"green":"blue"} variant="tertiary">{history.status}</Tag></DataTableCellStatus>
            <DataTableCell>{history.effectiveDate}</DataTableCell>
            <DataTableCell>{history.obsoleteDate==null ? "-":history.obsoleteDate}</DataTableCell>
          </DataTableRow>
        )))}
      </DataTableBody>
    </DataTable>
    </Modal>
    </>
);
}

export default CostCenterHistory;