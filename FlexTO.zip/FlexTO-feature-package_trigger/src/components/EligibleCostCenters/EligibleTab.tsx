import React, {useState} from 'react';
import {
  DataTable,
  DataTableCell,
  DataTableHead,
  DataTableHeader,
  DataTableBody,
  DataTableRow,
  Button,
  Spinner,
  Caption,
  DataTableCellStatus,
  Tag,
  IconButton,
  Panel,
  ButtonGroup,
  DataTableHeaderProps,
  Chip,
  ChipGroup
} from "@walmart-web/livingdesign-components";
import SkeletonTableWrapper from '../SkeletonWrapper/SkeletonTableWrapper';
import * as Icon from "@livingdesign/icons";
import CostCenterHistory from '../CostCenterHistory/CostCenterHistory';
import SelectWrapper from '../SelectWrapper/SelectWrapper';
import Papa from 'papaparse';

interface CostCenter {
  seqNumber: number,
  storeNumber: number,
  stateProvCode: string,
  countryCode: string,
  effectiveDate: Date,
  obsoleteDate: Date,
  historyFlag: boolean,
  status: string
}

interface CostCenterTabProps {
  costCenters: CostCenter[],
  isLoading: boolean
}

interface SortObjProps {
  effectiveDate: DataTableHeaderProps['sort'],
  storeNumber: DataTableHeaderProps['sort']
}

interface chipSelected{
  Eligible:boolean,
  "Not Eligible": boolean
}

const EligibleTab : React.FC<CostCenterTabProps> = ({costCenters, isLoading}) => {
  let sortInitialObj : SortObjProps = {
    "effectiveDate": "descending",
    "storeNumber": "none"
  }
  const [isDataLoading, setIsDataLoading] = useState<boolean>(isLoading);
  const [filteredCostCenters, setFilteredCostCenters] = useState<CostCenter[]>(costCenters);
  const stateValues = [...new Set(costCenters.map(obj => obj.stateProvCode))];
  const countryValues = [...new Set(costCenters.map(obj => obj.countryCode))];
  const [isExportLoading, setIsExportLoading] = useState<boolean>(false);
  const [isHistoryClicked, setIsHistoryClicked] = useState<boolean>(false);
  const [historyId, setHistoryId] = useState<number| undefined>();
  const [isFilterClicked, setIsFilterClicked] = useState<boolean>(false);
  const [isFormLoading, setIsFormLoading] = useState<boolean>(false);
  const [statusFiltered, setStatusFiltered] = useState<string>("Eligible");
  const [stateFiltered, setStateFiltered] = useState<string>("");
  const [countryFiltered, setCountryFiltered] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<SortObjProps>(sortInitialObj);
  const [chipSelected, setChipSelected] = useState<chipSelected>({"Eligible":false, "Not Eligible":false})

  const openHistoryComp = (costCenterId : number) =>{
    setIsHistoryClicked(true);
    setHistoryId(costCenterId);
  }

  const onModalCloseHandler = ()=>{
    setIsHistoryClicked(false);
  }

  const defaultValues = ()=>{
    setStatusFiltered('Eligible');
  }

  const filterHandler = ()=>{
    let newFilteredCostCenters:CostCenter[] = [];
    // if(statusFiltered!==""){
    //   newFilteredCostCenters = newFilteredCostCenters.filter((item) => {
    //     return item.status === statusFiltered;
    //   });
    // }
    if(stateFiltered!==""){
      newFilteredCostCenters = costCenters.filter((item) => {
        return item.stateProvCode === stateFiltered;
      });
    }
    if(countryFiltered!==""){
      newFilteredCostCenters = costCenters.filter((item) => {
        return item.countryCode === countryFiltered;
      });
    }
    setFilteredCostCenters(newFilteredCostCenters);
    setIsFilterClicked(false);
    setCountryFiltered("");
    setStateFiltered("");
  }

  const handleExportClick = () => {
    try {
      setIsExportLoading(true);
      // Use json2csv's parse method to convert the data into CSV format
      const csv = Papa.unparse(costCenters);

      // Create a Blob from the CSV string
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });

      // Create a link element to trigger the download
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'cost_centers.csv'; // Set the download filename
      // Trigger the click event to initiate the download
      link.click();
    } catch (err) {
      console.error('Error exporting data to CSV:', err);
    }
    finally{
      setIsExportLoading(false);
    }
  };

  const sortHandler = (field:string) => {
    let sortedCostCenters = [...filteredCostCenters];
    let sortDirectionCopy = {...sortDirection};
    console.log(sortDirectionCopy[field]);
    if(sortDirectionCopy[field]=="descending"||sortDirectionCopy[field]=="none"){
      if(field=="effectiveDate"){
        sortedCostCenters.sort((a, b) => a[field].getTime() - b[field].getTime());
      }
      else{
        sortedCostCenters.sort((a, b) => a[field] - b[field]);
      }
    setFilteredCostCenters(sortedCostCenters);
    }
    else{
      if(field=="effectiveDate"){
      sortedCostCenters.sort((a, b) => b[field].getTime() - a[field].getTime());}
      else{
        sortedCostCenters.sort((a, b) => b[field] - a[field]);
      }
    setFilteredCostCenters(sortedCostCenters);
    }
    function toggleField(field:string) {
      for (let key in sortDirectionCopy) {
          if (key === field) {
            if(sortDirectionCopy[key]=="ascending"){
              sortDirectionCopy[key] = "descending";
            }
            else if(sortDirectionCopy[key] == "descending"||sortDirectionCopy[key] == "none"){
              sortDirectionCopy[key] = "ascending";
            } 
          } else {
            sortDirectionCopy[key] = 'none';
          }
      }
      return sortDirectionCopy;
    }
    setSortDirection(toggleField(field));
  }

  function formatDate(date: Date): string {
    let day = date.getDate();
    let month = date.toLocaleString('default', { month: 'short' });
    let year = date.getFullYear();
    return `${day} ${month} ${year}`;
  }

  function chipClickHandler(name:string){
    setIsDataLoading(true);
    const newFilteredCostCenters = costCenters.filter((item) => {
      return item.status === name;
    });
    setFilteredCostCenters(newFilteredCostCenters);
    setChipSelected({
      "Eligible": name === "Eligible",
      "Not Eligible": name !== "Eligible"
    });
    setIsDataLoading(false);
  }

  return (
    <>
    <Panel onClose={() => setIsFilterClicked(false)} title="Select Filters" isOpen={isFilterClicked}
    position='right'
    size='medium'
    actions={
      <ButtonGroup>
        <Button variant="tertiary" onClick={defaultValues} size='medium' disabled={isFormLoading}>Cancel</Button>
        {isFormLoading?(<Button variant="primary" size='medium' disabled>
          <Spinner size='small' color='white'/>
          <span className='marginLeft5'>Filtering</span></Button>):(
          <Button variant="primary" onClick={filterHandler} size='medium'>Filter</Button>
        )}
      </ButtonGroup>}
    closeButtonProps={{ "aria-label": "Close Panel" }}>
      {/* <SelectWrapper
        label="Status"
        onChange={(e)=>{setStatusFiltered(e.target.value)}}
        value={statusFiltered}
        disabled={isFormLoading}
      >
        <option value="Eligible">Eligible</option>
        <option value="Not Eligible">Not Eligible</option>
      </SelectWrapper> */}
      <SelectWrapper
        label="State"
        onChange={(e)=>{setStateFiltered(e.target.value)}}
        value={stateFiltered}
        disabled={isFormLoading}>
        <option value={"Select"}>{"Select"}</option>
        {stateValues.map((value)=>(
          <option value={value}>{value}</option>
        ))}
      </SelectWrapper>
      <SelectWrapper
        label="Country"
        onChange={(e)=>{setCountryFiltered(e.target.value)}}
        value={countryFiltered}
        disabled={isFormLoading}>
        <option value={"Select"}>{"Select"}</option>
        {countryValues.map((value)=>(
          <option value={value}>{value}</option>
        ))}
      </SelectWrapper>
    </Panel>

    {isExportLoading && 
    <div className='loading-overlay'>
      <Spinner color='white'/>
    </div>}
    <div className='options-container'>
      <div>
        <ChipGroup>
          <Chip
            selected={chipSelected['Eligible']}
            onClick={() => chipClickHandler('Eligible')}
            placeholder="Status"   // Default placeholder
            disabled={isLoading}
            onPointerEnterCapture={() => {}}  // Empty default function
            onPointerLeaveCapture={() => {}}  // Empty default function
          >
            Eligible
          </Chip>
          <Chip
            selected={chipSelected['Not Eligible']}
            onClick={() => chipClickHandler('Not Eligible')}
            placeholder="Status"   // Default placeholder
            disabled={isLoading}
            onPointerEnterCapture={() => {}}  // Empty default function
            onPointerLeaveCapture={() => {}}  // Empty default function
          >
            Not Eligible
          </Chip>
        </ChipGroup></div>
      <div className="button-container">
        <Button variant="tertiary" size="medium" onClick={()=>{setIsFilterClicked(!isFilterClicked)}} disabled={isLoading}>Filter</Button>
        <Button variant="primary" size="medium" onClick={handleExportClick} disabled={isLoading}>Export</Button>
      </div>
    </div>
    <div className={`data-table-container marginTop20 marginBottom20 ${!isLoading ? 'table-scroll' : ''}`}>
    <DataTable>
      <DataTableHead>
        <DataTableRow>
          <DataTableHeader
          onSort={()=>{sortHandler("storeNumber")}}
          sort={sortDirection["storeNumber"]}>
          Store Number</DataTableHeader>
          <DataTableHeader>Status</DataTableHeader>
          <DataTableHeader>State</DataTableHeader>
          <DataTableHeader>Country</DataTableHeader>
          <DataTableHeader
          onSort={()=>{sortHandler("effectiveDate")}}
          sort={sortDirection["effectiveDate"]}>
          Effective Date</DataTableHeader>
          <DataTableHeader>Obsolete Date</DataTableHeader>
          <DataTableHeader>Actions</DataTableHeader>
        </DataTableRow>
      </DataTableHead>
      <DataTableBody>
      {isDataLoading ? <SkeletonTableWrapper columnCount={7}/>:(
        filteredCostCenters.map((costCenter) => (
          <DataTableRow key={costCenter.seqNumber}>
            <DataTableCell>{costCenter.storeNumber}</DataTableCell>
            <DataTableCellStatus>
              <Tag color={costCenter.status=="Eligible"?"green":"blue"} variant="tertiary">{costCenter.status}</Tag></DataTableCellStatus>
            <DataTableCell>{costCenter.stateProvCode}</DataTableCell>
            <DataTableCell>{costCenter.countryCode}</DataTableCell>
            <DataTableCell>{formatDate(costCenter.effectiveDate)}</DataTableCell>
            <DataTableCell>{costCenter.obsoleteDate==null ? "-":formatDate(costCenter.obsoleteDate)}</DataTableCell>
            <DataTableCell>
              <IconButton a11yLabel='history' onClick={()=>{openHistoryComp(costCenter.storeNumber)}}>
              <Icon.History />
              </IconButton>
            </DataTableCell>
          </DataTableRow>
        )))}
      </DataTableBody>
    </DataTable>
    </div>
    <div className='align-right marginBottom20'><Caption>**Scroll to view the complete data.</Caption></div>
    {isHistoryClicked && <CostCenterHistory costCenterId={historyId} onModalCloseHandler={onModalCloseHandler} />}
    </>
  );
};

export default EligibleTab;