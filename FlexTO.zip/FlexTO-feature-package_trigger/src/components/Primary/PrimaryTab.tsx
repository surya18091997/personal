import React, { useState } from 'react';
import {
  DataTable,
  DataTableCell,
  DataTableHead,
  DataTableHeader,
  DataTableBody,
  DataTableRow,
  IconButton,
  TextField,
  Modal,
  Button,
  ButtonGroup,
  Panel,
  Spinner,
  Divider,
  useSnackbar
} from "@walmart-web/livingdesign-components";
import SelectWrapper from '../SelectWrapper/SelectWrapper';
import SkeletonTableWrapper from '../SkeletonWrapper/SkeletonTableWrapper';
import * as Icon from "@livingdesign/icons";
import axios from 'axios';
import { getSrvcWidoutInp, postSrvc2 } from 'src/utils/Constants';

interface Rule {
  ruleId: number;
  ruleName: string;
  ruleType: string;
}

interface PrimaryTabProps {
  isAdmin: boolean,
  rules: Rule[],
  toSec: any,
  deletePriRuleHandler: any
  isLoading: boolean,
  fetchRules : any
}

interface AddEligRule {
  ruleName: string;
  ruleType: string;
}
// Sleep function using Promise
const sleep = (ms:any) => new Promise(resolve => setTimeout(resolve, ms));

const PrimaryTab: React.FC<PrimaryTabProps> = ({isAdmin, rules, toSec, deletePriRuleHandler, isLoading, fetchRules}) => {
  const {addSnack} = useSnackbar();
  const [isDeleteClicked, setIsDeleteClicked] = useState<boolean>(false);
  const [deleteRuleId, setDeleteRuleId] = useState<number>();
  const [addEligOpen, setAddEligOpen] = useState<boolean>(false);
  const [isFormLoading, setIsFormLoading] = useState<boolean>(false);
  const [ruleName, setRuleName] = useState<string>('Overheads');
  const [ruleType, setRuleType] = useState<string>('Fully Ineligible');
  const [newRuleName, setNewRuleName] = useState<string>("");
  const [textFieldError, setTextFieldError] = useState<string>("");
  const [orgFieldError, setOrgFieldError] = useState<string>("");
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);
  // const [choosenSearch, setChoosenSearch] = useState<string>("")

  const deleteClicked = (id:number) =>{
    setIsDeleteClicked(true);
    setDeleteRuleId(id);
  }

  const deleteSubmitHandler = async() =>{
    setIsFormLoading(true);
    try{
    const res = await deletePriRuleHandler(deleteRuleId);
    console.log(res.data);
    fetchRules();
    setIsDeleteClicked(false);
    }
    catch (error: any) {
      // Handle error
      console.error('Error during deleting:', error);
    } finally {
      setIsFormLoading(false);
    }
  }

  const defaultValues = () => {
    setRuleName('Overheads');
    setNewRuleName("");
    setRuleType('Fully Ineligible');
    setTextFieldError("");
    setOrgFieldError("");
  }

  const handleSubmit = async () => {
    setIsFormLoading(true);
    if (await checkDisable()){
      setIsFormLoading(false);
      return
    }
    const ruleNameFinal = ruleName=="Add New Organization" ? newRuleName : ruleName;
    const data: AddEligRule = {
      ruleName: ruleNameFinal,
      ruleType: ruleType
    }
    console.log(data);
    try {
      //submit data
      const response = await axios.post(postSrvc2+'12'+'/eligibility_rules/insert', data);
      //Handle success
      console.log('Response from API:', response.data);
      if (response.data.statusCode==201){
        setOrgFieldError('Organization name already exists.');
      }
      else{
      defaultValues();
      setFormSubmitted(true);
      fetchRules();
      }
    } catch (error: any) {
      addSnack({actionButtonProps: {
        children: "OK"},
        message: "Error occured while submitting, retry after sometime."})
      console.error('Error during form submission:', error);
    } finally {
      setIsFormLoading(false);
    }
  }

  const validateOrgType = async() =>{
      const data = {
        ruleName: newRuleName,
        ruleType: ruleType
      }
      console.log(data);
      const res = await axios.post(postSrvc2+'12'+'/eligibility_rules/validat',data);;
      return res.data.data;
    }
  
  const checkDisable = async() => {
    if (ruleName=="Add New Organization"){
      if (newRuleName==null){
        setTextFieldError('Please provide the organization name.');
        return true
      }
      else{
        if(! await validateOrgType()){
          setTextFieldError('Please provide the correct organization name.');
          return true
        }
      }
    }
    setTextFieldError("");
    return false
  }

  const closeHandler = ()=>{
    if (isFormLoading){
      return;
    }
    defaultValues();
    setFormSubmitted(false);
    setAddEligOpen(false);
  }

  const setNewRuleNameHandler = (ruleName:string)=>{
    setTextFieldError("");
    setNewRuleName(ruleName);
  }

  const setRuleNameHandler = (ruleName:string)=>{
    setOrgFieldError("");
    setRuleName(ruleName);
  }

  return (
    <>
    {/* Button to open Add Eligibility Form */}
        <div className="button-container">
          <Button variant="primary" size="medium" onClick={()=>{setAddEligOpen(true)}} disabled={!isAdmin||isLoading}>Add Eligibility Rule</Button>
        </div>
    <div className='marginTop20 marginBottom20'>
    <DataTable>
      <DataTableHead>
        <DataTableRow>
          <DataTableHeader>S.No</DataTableHeader>
          <DataTableHeader>Organisation</DataTableHeader>
          <DataTableHeader>Rule Type</DataTableHeader>
          <DataTableHeader>Actions</DataTableHeader>
        </DataTableRow>
      </DataTableHead>
      <DataTableBody>
        {isLoading ? (<SkeletonTableWrapper columnCount={4}/>) : (
          rules.map((rule, index) => (
              <DataTableRow key={rule.ruleId}>
                <DataTableCell>{index + 1}</DataTableCell>
                <DataTableCell>{rule.ruleName}</DataTableCell>
                <DataTableCell>{rule.ruleType}</DataTableCell>
                <DataTableCell>
                  <IconButton a11yLabel="Delete" onClick={() => deleteClicked(rule.ruleId)} disabled={!isAdmin}>
                    <Icon.TrashCan />
                  </IconButton>
                  <span className='marginLeft15'>
                  <IconButton a11yLabel="Move" onClick={() => toSec(rule.ruleId)}>
                    <Icon.ChevronRight/>
                  </IconButton>
                  </span>
                </DataTableCell>
              </DataTableRow>
            )))}
    </DataTableBody>
    </DataTable>
    </div>
    <Modal isOpen={isDeleteClicked} size="medium" onClose={()=>{setIsDeleteClicked(false)}} title="Delete Eligibility File">
      <p className='popup-cont'>
      <p className='popuptext'>Every organization must have an eligibility rule. If you delete this rule, you must add a new one.</p>
      <p className='delete-pop bold'>Are you sure you want to delete this rule?</p>
      <p><Divider/></p>
      <div className='buttonright'>
        <ButtonGroup>
          <Button variant="tertiary" size="medium" onClick={()=>{setIsDeleteClicked(false)}} disabled={isFormLoading?true:false}>Cancel</Button>
          {isFormLoading?(
          <Button size="medium" variant="destructive" disabled>
            <Spinner size='small'/><span className='marginLeft5'>Deleting</span></Button>
          ):(<Button size="medium" variant="destructive" onClick={()=>deleteSubmitHandler()}>Delete</Button>)}
        </ButtonGroup>
        </div>
      </p>
    </Modal>

      {/* Add Eligibility Form */}
        <Panel
        actions={
          formSubmitted ? (
            <Button variant="primary" onClick={closeHandler} size='medium' isFullWidth={true}>Done</Button>
          ):(
          <ButtonGroup>
            <Button variant="tertiary" onClick={defaultValues} size='medium' disabled={isFormLoading}>Cancel</Button>
            {isFormLoading?(<Button variant="primary" size='medium' disabled>
              <Spinner size='small' color='white'/>
              <span className='marginLeft5'>Submitting</span></Button>):(
              <Button variant="primary" onClick={handleSubmit} size='medium'>Submit</Button>
            )}
          </ButtonGroup>
          )
        }
        closeButtonProps={{ "aria-label": "Close Panel" }}
        isOpen={addEligOpen}
        onClose={()=>{closeHandler()}}
        title="Add Eligibility Rule"
        position='right'
        size='medium'
      >
        {formSubmitted ? (
          <div className='panel-success'>
            <Icon.CheckCircle size='large'/>
            <br/>
          <p className='bold'>Eligibility rule added successfully!</p>
          <p className='marginTop20 padding20'>Add exceptions for the organization in the exceptions tab based on the rule type if any.</p>
          </div>
        ):(
          <>
          <SelectWrapper
                marginBottom="15px"
                label="Organization Name"
                onChange={(e)=>{setRuleNameHandler(e.target.value)}}
                value={ruleName}
                disabled={isFormLoading||ruleName=="Add New Organization"}
                error={orgFieldError != "" ? orgFieldError : null}
              >
                <option value="Overheads">Overheads</option>
                <option value="Other Operational">Other Operational</option>
                <option value="SupplyChain">SupplyChain</option>
                <option value="WFP_Operational">WFP_Operational</option>
                <option value="Store - Club">Store - Club</option>
                <option value="Add New Organization">Add New Organization</option>
              </SelectWrapper>
        {ruleName=="Add New Organization" &&
        <div className='marginDown15'>
          <TextField
          helperText="Org name must match Finance Cost Center."
          label="New Organization Name"
          onChange={(e) => {setNewRuleNameHandler(e.target.value)}}
          value={newRuleName}
          error={textFieldError!="" ? textFieldError : null}
          disabled={isFormLoading}
        />
        </div>}
              <SelectWrapper
                label="Rule Type"
                onChange={(e:any)=>{setRuleType(e.target.value)}}
                value={ruleType}
                disabled={isFormLoading}
              >
                <option value="Fully Ineligible">Fully Ineligible</option>
                <option value="Partially Include">Partially Include</option>
                <option value="Partially Exclude">Partially Exclude</option>
              </SelectWrapper>
              </>
        )}
      </Panel>
    </>
  );
};

export default PrimaryTab;