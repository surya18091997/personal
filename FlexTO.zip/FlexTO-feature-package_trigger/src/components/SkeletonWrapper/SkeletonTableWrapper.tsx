import React from 'react';
import { DataTable, DataTableBody,DataTableHead,DataTableCell,DataTableRow,DataTableHeader,Skeleton} from '@walmart-web/livingdesign-components';

interface SkeletonProps{
  columnCount: any;
}

const SkeletonTableWrapper: React.FC<SkeletonProps> = ({columnCount}) => {
    const skeletonRowCount:number = 5;

  return (
    <>
      {Array.from({ length: skeletonRowCount}).map((_, index) => (
        <DataTableRow key={index}>
          {Array.from({ length: columnCount}).map((_, index) => (
            <DataTableCell key={index}><Skeleton variant="rectangle" /></DataTableCell>
          ))}
        </DataTableRow>
      ))}
    </>
  );
};

export default SkeletonTableWrapper;