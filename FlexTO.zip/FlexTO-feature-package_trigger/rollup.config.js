// rollup.config.js
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import peerDepsExternal from 'rollup-plugin-peer-deps-external';
import typescript from 'rollup-plugin-typescript2';
import replace from '@rollup/plugin-replace';
import { terser } from 'rollup-plugin-terser';
import css from 'rollup-plugin-css-only';

export default {
  input: 'src/components/Flexto/Flexto.tsx',
  output: [
    {
      file: 'dist/esm/Flexto.js',
      format: 'esm',
      sourcemap: true,
    },
    {
      file: 'dist/cjs/Flexto.js',
      format: 'cjs',
      sourcemap: true,
    },
  ],
  external: ['react', 'react-dom','util',   // Exclude core modules from the bundle
  'stream', 
  'path', 
  'http', 
  'https', 
  'url', 
  'fs', 
  'assert', 
  'tty', 
  'os', 
  'zlib'],
  plugins: [
    css({
      output: 'styles.css', 
    }),
    peerDepsExternal(),
    resolve({
      browser: true,  // Enable browser-specific resolution
      extensions: ['.js', '.ts', '.tsx'],
      dedupe: ['react', 'react-dom'],
    }),
    commonjs(),
    typescript({ tsconfig: './tsconfig.json' }),
    replace({
      preventAssignment: true,
      'process.env.NODE_ENV': JSON.stringify('production'),
    }),
    terser(),
  ],
};
