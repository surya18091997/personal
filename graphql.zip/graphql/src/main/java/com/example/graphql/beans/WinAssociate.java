package com.example.graphql.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WinAssociate {
    private int winNbr;
    private int nationalId;
    private String firstName;
    private String lastName;
    private String countryCode;
    private String maritalCode;
    private String employStatCode;

    public void setFirstName(String firstName){
        this.firstName = firstName.trim();
    }

    public void setLastName(String lastName){
        this.lastName = lastName.trim();
    }
}
