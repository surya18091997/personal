package com.example.graphql.beans;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
public class BenefitsDetails {
    private List<BenefitEnrollment> benefitEnrollment; 
}
