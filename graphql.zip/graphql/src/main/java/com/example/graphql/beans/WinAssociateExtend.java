package com.example.graphql.beans;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WinAssociateExtend {
    private String companyName;
    private String wdPositionId;
    private String wdWorkTypeId;
    private String wdPosTimeType;
    private String defWorkHourQty;
}
