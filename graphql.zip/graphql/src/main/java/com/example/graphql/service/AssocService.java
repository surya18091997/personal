package com.example.graphql.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.graphql.beans.AssocDetails;
import com.example.graphql.beans.BenefitEnrollment;
import com.example.graphql.beans.BenefitsDetails;
import com.example.graphql.beans.WinAssociate;
import com.example.graphql.beans.WinAssociateExtend;
import com.example.graphql.repository.AssocRepository;
import com.example.graphql.utils.Constants;
import java.util.List;
import java.util.Set;


import org.springframework.stereotype.Service;

@Service
public class AssocService {
    
    @Autowired
    private AssocRepository assocRepository;

    public AssocDetails assocDetailsByWinNbr(int winNbr, Set<String> queryFields) {
        AssocDetails assocDetails = new AssocDetails();
        if (queryFields.stream().anyMatch(Constants.WIN_ASSOCIATE_FIELDS::contains)){
            System.out.println("in 1");
            WinAssociate winDetails = assocRepository.getWinAssociateDetailsByWin(winNbr);
            assocDetails.setWinAssociate(winDetails);
        }
        if (queryFields.stream().anyMatch(Constants.WIN_ASSOCIATE_EXTEND_FIELDS::contains)){
            System.out.println("in 2");
            WinAssociateExtend winExtendDetails = assocRepository.getWinAssociateExtendDetailsByWin(winNbr);
            assocDetails.setWinAssociateExtend(winExtendDetails);
        }
        return assocDetails;
    }

    public BenefitsDetails assocBenefitsDataBySSN(int ssn, Set<String> queryFields) {
        List<BenefitEnrollment> benefits = assocRepository.getBenefitEnrollmentDetailsBySSN(ssn);
        BenefitsDetails benefitsDetails = new BenefitsDetails();
        benefitsDetails.setBenefitEnrollment(benefits);
        return benefitsDetails;
    }
}
