package com.example.graphql.utils;
import java.util.Arrays;
import java.util.List;

public final class Constants {

    private Constants() {
    }

    public static final List<String> WIN_ASSOCIATE_FIELDS = Arrays.asList("winNbr", "nationalId", "firstName", "lastName", "countryCode", "maritalCode", "employStatCode");
    public static final List<String> WIN_ASSOCIATE_EXTEND_FIELDS = Arrays.asList("companyName", "wdPositionId", "wdWorkTypeId", "wdPosTimeType", "defWorkHourQty");

}
