package com.example.graphql.controller;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import com.example.graphql.beans.*;
import com.example.graphql.service.AssocService;

import graphql.schema.DataFetchingEnvironment;
import graphql.schema.SelectedField;

@Controller
class AssocController {

    @Autowired
    private AssocService assocService;

    @QueryMapping
    public AssocDetails getAssocDetailsByWinNbr(@Argument int winNbr, DataFetchingEnvironment env) {
        Set<String> requestedFields = env.getSelectionSet().getFields().stream().map(SelectedField::getName).collect(Collectors.toSet());
        return assocService.assocDetailsByWinNbr(winNbr, requestedFields);
    }

    @QueryMapping
    public BenefitsDetails getAssocBenefitsDataBySSN(@Argument int ssn, DataFetchingEnvironment env) {
        Set<String> requestedFields = env.getSelectionSet().getFields().stream().map(SelectedField::getName).collect(Collectors.toSet());
        return assocService.assocBenefitsDataBySSN(ssn, requestedFields);
    }
}
