package com.example.graphql.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.graphql.beans.BenefitEnrollment;
import com.example.graphql.beans.WinAssociate;
import com.example.graphql.beans.WinAssociateExtend;
import java.util.List;
// PreparedStatementSetter pss = new PreparedStatementSetter() {
        //     @Override
        //     public void setValues(PreparedStatement ps) throws SQLException{
        //         ps.setInt(1, winNbr);
        //     }
        // };

@Repository
public class AssocRepository {
    @Autowired
    private JdbcTemplate db2JdbcTemplate;

    public WinAssociate getWinAssociateDetailsByWin(int winNbr){
        String query = "select WIN_NBR, NATIONAL_ID, FIRST_NAME, LAST_NAME,COUNTRY_CODE, ACT_MARITAL_CODE,EMPLOY_STAT_CODE from LIGBLASC.WIN_ASSOCIATE where WIN_NBR = ? ;";
        
        RowMapper<WinAssociate> rowMapper = (rs, rowNum) -> {
            WinAssociate associate = new WinAssociate();
            associate.setWinNbr(rs.getInt("WIN_NBR"));
            associate.setNationalId(rs.getInt("NATIONAL_ID"));
            associate.setFirstName(rs.getString("FIRST_NAME"));
            associate.setLastName(rs.getString("LAST_NAME"));
            associate.setCountryCode(rs.getString("COUNTRY_CODE"));
            associate.setMaritalCode(rs.getString("ACT_MARITAL_CODE"));
            associate.setEmployStatCode(rs.getString("EMPLOY_STAT_CODE"));
            return associate;
        };
        
        WinAssociate associate = db2JdbcTemplate.queryForObject(query, rowMapper, winNbr); 
        return associate;
    }

    public WinAssociateExtend getWinAssociateExtendDetailsByWin(int winNbr){
        String query = "SELECT COMPANY_NAME, WD_POSITION_ID, WD_WRKR_TYPE_CD, WD_POS_TIME_TYPE, DFLT_WORK_HR_QTY FROM LIGBLASC.WIN_ASSOCIATE_EXTEND WHERE WIN_NBR = ? ;";
        
        RowMapper<WinAssociateExtend> rowMapper = (rs, rowNum) -> {
            WinAssociateExtend associate = new WinAssociateExtend();
            associate.setCompanyName(rs.getString("COMPANY_NAME"));
            associate.setWdPositionId(rs.getString("WD_POSITION_ID"));
            associate.setWdWorkTypeId(rs.getString("WD_WRKR_TYPE_CD"));
            associate.setWdPosTimeType(rs.getString("WD_POS_TIME_TYPE"));
            associate.setDefWorkHourQty(rs.getString("DFLT_WORK_HR_QTY"));
            return associate;
        };
        
        WinAssociateExtend associate = db2JdbcTemplate.queryForObject(query, rowMapper, winNbr); 
        return associate;
    }

    public List<BenefitEnrollment> getBenefitEnrollmentDetailsBySSN(int ssn){
        String query = "SELECT SSN, PLAN_NAME, PLAN_YEAR FROM LIINSUR0.BENEFIT_ENROLLMENT WHERE SSN = ? AND HISTORY_TYPE_CD = 'E';";
        
        RowMapper<BenefitEnrollment> rowMapper = (rs, rowNum) -> {
            BenefitEnrollment ben = new BenefitEnrollment();
            ben.setSsn(rs.getInt("SSN"));
            ben.setPlanName(rs.getString("PLAN_NAME"));
            ben.setPlanYear(rs.getInt("PLAN_YEAR"));
            return ben;
        };
        
        List<BenefitEnrollment> benefits = db2JdbcTemplate.query(query, rowMapper, ssn); 
        return benefits;
    }
}
