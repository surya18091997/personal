package com.example.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Value;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class GraphqlApplication {

	@Value("#{'${ssl.wmtCAtruststore.path}'}")
    private String trustStoreFileName;

	public static void main(String[] args) {
		SpringApplication.run(GraphqlApplication.class, args);
	}

	@PostConstruct
    public void init() {
        try {
            System.setProperty("javax.net.ssl.trustStore", trustStoreFileName);

        } catch (Exception e) {
        	System.out.println("Error while initializing truststore - " );

        }
    }

}
