package com.example.graphql.beans;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssocDetails {
    private WinAssociate winAssociate;
    private WinAssociateExtend winAssociateExtend;
}
