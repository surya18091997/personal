package com.example.graphql.beans;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BenefitEnrollment {
    private int ssn;
    private String planName;
    private int planYear;
}
