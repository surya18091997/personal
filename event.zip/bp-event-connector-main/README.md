# Benefits-Event-Connector
Benefits Event Connector service provides the option to produce and consume events from upstream and downstream systems.
