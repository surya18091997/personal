package com.walmart.benefits.connector.event.utils;

import org.junit.jupiter.api.Test;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class AESTest {

    private static final String SKEY = "BRGhEh1UEkRBLJYB";

    @Test
    void testEncryptDecrypt() {
        byte[] plainText = "Hello, World!".getBytes();

        byte[] encrypted = AES.encrypt(plainText, SKEY);
        byte[] decrypted = AES.decrypt(encrypted, SKEY);

        assertArrayEquals(plainText, decrypted);
    }

    @Test
    void testEncryptDecryptWithInvalidSecret() {
        byte[] plainText = "Hello, World!".getBytes();

        byte[] encrypted = AES.encrypt(plainText, "SKEY");
        byte[] decrypted = AES.decrypt(encrypted, "SKEY");

        assertNotEquals(plainText, decrypted);
    }

    @Test
    void testEncryptDecryptWithEmptyData() {
        byte[] plainText = new byte[0];

        byte[] encrypted = AES.encrypt(plainText, SKEY);
        byte[] decrypted = AES.decrypt(encrypted, SKEY);

        assertArrayEquals(plainText, decrypted);
    }
}