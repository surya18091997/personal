package com.walmart.benefits.connector.event.validator;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import java.time.DateTimeException;
import java.time.LocalDate;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class EventValidatorTest {

    @InjectMocks
    private EventValidator eventValidator;

    /**
     * Test case for the `validateDateInputs` method with valid dates.
     *
     * This test verifies that the method does not throw any exceptions when
     * valid date inputs are provided.
     *
     * @throws DateTimeException if the date format is invalid
     */
    @Test
    public void testValidateDateInputs_ValidDates_NoException() {
        eventValidator.validateDateInputs(LocalDate.parse("2022-01-01"),
                LocalDate.parse("2022-01-15"));
    }

    /**
     * Test case for the `validateDateInputs` method when invalid dates are provided.
     *
     * @throws DateTimeException if the date format is invalid
     */
    @Test
    public void testValidateDateInputs_InvalidDates_ThrowsException() {
        var fromDate = LocalDate.parse("2022-01-31");
        var toDate = LocalDate.parse("2022-01-01");
        assertThrows(DateTimeException.class, () -> {
            eventValidator.validateDateInputs(fromDate,
                    toDate);
        });
    }

    /**
     * Test case for the `validateDateInputs` method when an invalid date range is provided.
     *
     * @throws DateTimeException if the date format is invalid
     */
    @Test
    public void testValidateDateInputs_InvalidDateRange_ThrowsException() {
        var fromDate = LocalDate.parse("2022-01-01");
        var toDate = LocalDate.parse("2022-02-01");
        assertThrows(DateTimeException.class, () -> {
            eventValidator.validateDateInputs(fromDate,
                    toDate);
        });
    }
}