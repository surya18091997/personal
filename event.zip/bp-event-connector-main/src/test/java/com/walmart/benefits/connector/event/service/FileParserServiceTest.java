package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.config.HardshipConfig;
import com.walmart.benefits.connector.event.config.LoanConfig;
import com.walmart.benefits.connector.event.config.RateChange401kConfig;
import com.walmart.benefits.connector.event.exception.FileParserException;
import com.walmart.benefits.connector.event.model.HardshipFileParseResult;
import com.walmart.benefits.connector.event.model.LoanFileParseResult;
import com.walmart.benefits.connector.event.model.RateChangeFileParseResult;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static java.nio.file.Files.createTempFile;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class FileParserServiceTest {

    @TempDir
    Path tempDir;

    @Test
    void testParseRateChange401KFile_ValidFile() throws IOException {
        // Arrange
        Path filePath = createTempFile("test", null);
        Files.writeString(filePath, "6094500018229062024110409520983133100140");
        RateChange401kConfig rateChange401kConfig = new RateChange401kConfig();
        rateChange401kConfig.setMlRateCode401k("831146,831479,831331,831334");
        rateChange401kConfig.setUsPlanNumber("609450");
        rateChange401kConfig.setPrPlanNumber("609577");
        rateChange401kConfig.setPlanNumberStart(0);
        rateChange401kConfig.setPlanNumberEnd(6);
        rateChange401kConfig.setPartNumberStart(6);
        rateChange401kConfig.setPartNumberEnd(15);
        rateChange401kConfig.setCreationDateStart(15);
        rateChange401kConfig.setCreationDateEnd(23);
        rateChange401kConfig.setCreationTimeStart(23);
        rateChange401kConfig.setCreationTimeEnd(29);
        rateChange401kConfig.setTransactionIdStart(29);
        rateChange401kConfig.setTransactionIdEnd(35);
        rateChange401kConfig.setRateStart(35);
        rateChange401kConfig.setRateEnd(40);
        rateChange401kConfig.setRateWholeNumberStart(0);
        rateChange401kConfig.setRateWholeNumberEnd(2);
        rateChange401kConfig.setRateDecimalNumberStart(2);
        rateChange401kConfig.setRateDecimalNumberEnd(5);

        FileParserService fileParserService = new FileParserService();

        // Act
        RateChangeFileParseResult result =
                fileParserService.parseRateChange401KFile(filePath,
                        rateChange401kConfig);

        // Assert
        assertEquals(1, result.getRateChanges().size());
        assertEquals(1, result.getNationalIdHashSet().size());
    }

    @Test
    void testParseRateChange401KFile_EmptyFile() throws IOException {
        // Arrange
        Path filePath = createTempFile("test", null);
        RateChange401kConfig rateChange401kConfig = new RateChange401kConfig();
        rateChange401kConfig.setMlRateCode401k("831146,831479,831331,831334");
        rateChange401kConfig.setPlanNumberStart(0);
        rateChange401kConfig.setPlanNumberEnd(6);
        rateChange401kConfig.setPartNumberStart(6);
        rateChange401kConfig.setPartNumberEnd(15);
        rateChange401kConfig.setCreationDateStart(15);
        rateChange401kConfig.setCreationDateEnd(23);
        rateChange401kConfig.setCreationTimeStart(23);
        rateChange401kConfig.setCreationTimeEnd(29);
        rateChange401kConfig.setTransactionIdStart(29);
        rateChange401kConfig.setTransactionIdEnd(35);
        rateChange401kConfig.setRateStart(35);
        rateChange401kConfig.setRateEnd(40);
        rateChange401kConfig.setRateWholeNumberStart(0);
        rateChange401kConfig.setRateWholeNumberEnd(2);
        rateChange401kConfig.setRateDecimalNumberStart(2);
        rateChange401kConfig.setRateDecimalNumberEnd(5);

        FileParserService fileParserService = new FileParserService();

        // Act
        RateChangeFileParseResult result =
                fileParserService.parseRateChange401KFile(filePath,
                        rateChange401kConfig);

        // Assert
        assertEquals(0, result.getRateChanges().size());
        assertEquals(0, result.getNationalIdHashSet().size());
    }

    @Test
    void testParseRateChange401KFile_InvalidFile() throws IOException {
        // Arrange
        Path filePath = createTempFile("test", null);
        Files.writeString(filePath, "invalid_line");
        RateChange401kConfig rateChange401kConfig = new RateChange401kConfig();
        rateChange401kConfig.setMlRateCode401k("831146,831479,831331,831334");
        rateChange401kConfig.setPlanNumberStart(0);
        rateChange401kConfig.setPlanNumberEnd(6);
        rateChange401kConfig.setPartNumberStart(6);
        rateChange401kConfig.setPartNumberEnd(15);
        rateChange401kConfig.setCreationDateStart(15);
        rateChange401kConfig.setCreationDateEnd(23);
        rateChange401kConfig.setCreationTimeStart(23);
        rateChange401kConfig.setCreationTimeEnd(29);
        rateChange401kConfig.setTransactionIdStart(29);
        rateChange401kConfig.setTransactionIdEnd(35);
        rateChange401kConfig.setRateStart(35);
        rateChange401kConfig.setRateEnd(40);
        rateChange401kConfig.setRateWholeNumberStart(0);
        rateChange401kConfig.setRateWholeNumberEnd(2);
        rateChange401kConfig.setRateDecimalNumberStart(2);
        rateChange401kConfig.setRateDecimalNumberEnd(5);

        FileParserService fileParserService = new FileParserService();

        // Act
        RateChangeFileParseResult result =
                fileParserService.parseRateChange401KFile(filePath,
                        rateChange401kConfig);

        // Assert
        assertEquals(0, result.getRateChanges().size());
        assertEquals(0, result.getNationalIdHashSet().size());
    }

    @Test
    void testParseLoan401kFile_ValidFile() throws IOException {
        // Arrange
        Path filePath = createTempFile("test", null);
        Files.writeString(filePath, "UHDR\n600603350201141959001  00000016168" +
                "                                  0    00002101840B         " +
                "                              02634\n" +
                "\n60060335020114195900s  00000016168"+
                "                \"                                  0    00002101840B         " +
                "                \"                              02634\n" +
                "600603350201141959001  00000016168" +
                "                \"                                  2    " +
                "00002101840B         " +
                "                \"                              02634\n" +
                "600603350201141959001  0000001616s" +
                "                \"                                  0    00002101840B         " +
                "                \"                              02634\nUTRL");
        LoanConfig loanConfig = new LoanConfig();
        loanConfig.setSsnStart(0);
        loanConfig.setSsnEnd(9);
        loanConfig.setEmpNumberStart(9);
        loanConfig.setEmpNumberEnd(18);
        loanConfig.setLoanNumberStart(18);
        loanConfig.setLoanNumberEnd(21);
        loanConfig.setLoanTypeStart(68);
        loanConfig.setLoanTypeEnd(69);
        loanConfig.setPayrollIdStart(69);
        loanConfig.setPayrollIdEnd(73);
        loanConfig.setStoreLocationCodeStart(124);
        loanConfig.setStoreLocationCodeEnd(129);
        loanConfig.setPayrollFrequencyStart(84);
        loanConfig.setPayrollFrequencyEnd(85);
        loanConfig.setLoanDedAmountWholeStart(23);
        loanConfig.setLoanDedAmountWholeEnd(32);
        loanConfig.setLoanDedAmountDecimalStart(32);
        loanConfig.setLoanDedAmountDecimalEnd(34);
        loanConfig.setGoalAmountWholeStart(73);
        loanConfig.setGoalAmountWholeEnd(82);
        loanConfig.setGoalAmountDecimalStart(82);
        loanConfig.setGoalAmountDecimalEnd(84);
        FileParserService fileParserService = new FileParserService();

        // Act
        LoanFileParseResult result =
                fileParserService.parseLoan401kFile(filePath, loanConfig);

        // Assert
        assertEquals(4, result.getLoanBnfts().size());
    }

    @Test
    void testParseLoan401kFile_EmptyFile() throws IOException {
        // Arrange
        Path filePath = createTempFile("test", null);
        LoanConfig loanConfig = new LoanConfig();
        loanConfig.setSsnStart(0);
        loanConfig.setSsnEnd(9);
        loanConfig.setEmpNumberStart(9);
        loanConfig.setEmpNumberEnd(18);
        loanConfig.setLoanNumberStart(18);
        loanConfig.setLoanNumberEnd(21);
        loanConfig.setLoanTypeStart(68);
        loanConfig.setLoanTypeEnd(69);
        loanConfig.setPayrollIdStart(69);
        loanConfig.setPayrollIdEnd(73);
        loanConfig.setStoreLocationCodeStart(124);
        loanConfig.setStoreLocationCodeEnd(129);
        loanConfig.setPayrollFrequencyStart(84);
        loanConfig.setPayrollFrequencyEnd(85);
        loanConfig.setLoanDedAmountWholeStart(23);
        loanConfig.setLoanDedAmountWholeEnd(32);
        loanConfig.setLoanDedAmountDecimalStart(32);
        loanConfig.setLoanDedAmountDecimalEnd(34);
        loanConfig.setGoalAmountWholeStart(73);
        loanConfig.setGoalAmountWholeEnd(82);
        loanConfig.setGoalAmountDecimalStart(82);
        loanConfig.setGoalAmountDecimalEnd(84);

        FileParserService fileParserService = new FileParserService();

        // Act
        LoanFileParseResult result =
                fileParserService.parseLoan401kFile(filePath, loanConfig);

        // Assert
        assertEquals(0, result.getLoanBnfts().size());
        assertEquals(0, result.getNationalIdHashSet().size());
    }

    @Test
    void testParseLoan401kFile_IOException() {
        // Arrange
        Path filePath = tempDir.resolve("non_existent_file.txt");
        LoanConfig loanConfig = new LoanConfig();
        FileParserService fileParserService = new FileParserService();

        // Act & Assert
        Assertions.assertThrows(FileParserException.class, () -> {
            fileParserService.parseLoan401kFile(filePath, loanConfig);
        });
    }
    @Test
    void parseHardship401kFile_ValidContent_ReturnsValidResult() throws IOException {
        // Arrange
        String fileContent =
                "UHDR250403232554609577SAVINGS CHANGES     250403    2025040320250403\n" +
                        "50571146753770918066    2025012820260128\n" +
                        "50852748993135141608    2025042820260428\n";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();

        try {
            // Act
            FileParserService service = new FileParserService();
            HardshipFileParseResult result = service.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertNotNull(result.getHardships());
            assertEquals(2, result.getHardships().size());

            // Verify first record
            assertEquals("50", result.getHardships().get(0).getRecordType());
            assertEquals("571146753", result.getHardships().get(0).getSsnId());
            assertEquals("2025-01-28", result.getHardships().get(0).getStartDate());
            assertEquals("2026-01-28", result.getHardships().get(0).getResumeDate());

            // Verify second record
            assertEquals("50", result.getHardships().get(1).getRecordType());
            assertEquals("852748993", result.getHardships().get(1).getSsnId());

            // Verify SSN set
            assertEquals(2, result.getNationalIdHashSet().size());
            assertTrue(result.getNationalIdHashSet().contains("571146753"));
            assertTrue(result.getNationalIdHashSet().contains("852748993"));
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void parseHardship401kFile_Type10Record_SkipsProcessing() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "50571146753770918066    2025012820260128\n"+
                        "10SS123456720230601E                            \n" +
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(1, result.getHardships().size());
            assertEquals("50", result.getHardships().get(0).getRecordType());
            assertEquals("571146753", result.getHardships().get(0).getSsnId());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void parseHardship401kFile_FileNotFound_ThrowsFileParserException() {
        // Arrange
        Path nonExistentFile = Paths.get("non_existent_file.txt");
        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        // Act & Assert
        Assertions.assertThrows(FileParserException.class,
                () -> fileParserService.parseHardship401kFile(nonExistentFile, config));
    }

    @Test
    void parseHardship401kFile_InvalidRecord_SkipsInvalidRecord() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "10SS123456720230601E                            \n" + // Type 10 should be skipped
                        "75SS987654301122023050120230515                 \n" + // Invalid record type
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(0, result.getHardships().size());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }
    @Test
    void parseHardship401kFile_OnlyType10Records_ReturnsEmptyResult() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "10123456789123456789    20230601E                \n" +
                        "10987654321987654321    20230515N                \n" +
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(0, result.getHardships().size());
            assertEquals(0, result.getNationalIdHashSet().size());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void parseHardship401kFile_MixedRecordTypes_OnlyProcessesType50() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "10123456789123456789    20230601E                \n" +
                        "50571146753770918066    2025012820260128         \n" +
                        "10987654321987654321    20230515N                \n" +
                        "50852748993135141608    2025042820260428         \n" +
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(2, result.getHardships().size());
            assertEquals(2, result.getNationalIdHashSet().size());

            // Verify first Type 50 record
            assertEquals("50", result.getHardships().get(0).getRecordType());
            assertEquals("571146753", result.getHardships().get(0).getSsnId());

            // Verify second Type 50 record
            assertEquals("50", result.getHardships().get(1).getRecordType());
            assertEquals("852748993", result.getHardships().get(1).getSsnId());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void parseHardship401kFile_MalformedType10Record_ContinuesProcessing() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "10INVALID                                        \n" + // Malformed Type 10
                        "50571146753770918066    2025012820260128         \n" +
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(1, result.getHardships().size());
            assertEquals("50", result.getHardships().get(0).getRecordType());
            assertEquals("571146753", result.getHardships().get(0).getSsnId());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void parseHardship401kFile_HeaderTrailerType10Records_ReturnsEmptyResult() throws IOException {
        // Arrange
        String fileContent =
                "UHDR                                             \n" +
                        "10123456789123456789    20230601E                \n" +
                        "UTRL                                             ";

        Path tempFile = Files.createTempFile("hardship_test", ".txt");
        Files.write(tempFile, fileContent.getBytes());

        HardshipConfig config = createHardshipConfig();
        FileParserService fileParserService = new FileParserService();

        try {
            // Act
            HardshipFileParseResult result = fileParserService.parseHardship401kFile(tempFile, config);

            // Assert
            assertNotNull(result);
            assertEquals(0, result.getHardships().size());
            assertTrue(result.getNationalIdHashSet().isEmpty());
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    private HardshipConfig createHardshipConfig() {
        HardshipConfig config = mock(HardshipConfig.class);

        // Configure record type positions
        when(config.getRecordTypeStart()).thenReturn(0);
        when(config.getRecordTypeEnd()).thenReturn(2);

        // Configure SSN positions
        when(config.getSsnStart()).thenReturn(2);
        when(config.getSsnEnd()).thenReturn(11);

        // Type 10 specific fields
        when(config.getMerMatchEligDateStart()).thenReturn(51);
        when(config.getMerMatchEligDateEnd()).thenReturn(59);
        when(config.getMerMatchEligIndStart()).thenReturn(59);
        when(config.getMerMatchEligIndEnd()).thenReturn(60);

        // Type 50 specific fields - Start date
        when(config.getMerStartCentStart()).thenReturn(24);
        when(config.getMerStartCentEnd()).thenReturn(26);
        when(config.getMerStartYyStart()).thenReturn(26);
        when(config.getMerStartYyEnd()).thenReturn(28);
        when(config.getMerStartMmStart()).thenReturn(28);
        when(config.getMerStartMmEnd()).thenReturn(30);
        when(config.getMerStartDdStart()).thenReturn(30);
        when(config.getMerStartDdEnd()).thenReturn(32);

        // Type 50 specific fields - Resume date
        when(config.getMerResumeCentStart()).thenReturn(32);
        when(config.getMerResumeCentEnd()).thenReturn(34);
        when(config.getMerResumeYyStart()).thenReturn(34);
        when(config.getMerResumeYyEnd()).thenReturn(36);
        when(config.getMerResumeMmStart()).thenReturn(36);
        when(config.getMerResumeMmEnd()).thenReturn(38);
        when(config.getMerResumeDdStart()).thenReturn(38);
        when(config.getMerResumeDdEnd()).thenReturn(40);

        return config;
    }
}