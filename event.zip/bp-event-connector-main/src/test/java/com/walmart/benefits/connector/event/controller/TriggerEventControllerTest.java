package com.walmart.benefits.connector.event.controller;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.service.ConnectorService;
import com.walmart.benefits.connector.event.validator.EventValidator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.DateTimeException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TriggerEventControllerTest {
    @Mock
    private ConnectorService service;

    @Mock
    private EventValidator validator;

    @InjectMocks
    private TriggerEventController controller;

    /**
     * Test case for the `testTriggerHrData_Valid` method.
     * This test case verifies the behavior of the `triggerHrData` method
     * when valid `fromDate` and `toDate` values are provided.
     */
    @Test
    public void testTriggerHrData_Valid() {
        // Test case: Valid fromDate and toDate
        String fromDate = "2022-01-01";
        String toDate = "2022-01-31";
        String expectedResult = "Event(s) Creation Initiated";
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getNewHireHrEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        String response = controller.triggerNewHireEvent(fromDate, toDate);

        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerHrData_Invalid` method.
     * This test case verifies the behavior of the `triggerHrData` method
     * when invalid `fromDate` and `toDate` values are provided.
     *
     * @throws IllegalArgumentException if the date format is invalid
     */
    @Test
    public void testTriggerHrData_Invalid() {
        // Test case: Invalid fromDate and toDate
        String fromDate = "2022-02-01";
        String toDate = "2022-01-31";
        doThrow(new DateTimeException(Constants.FROM_DATE_EXCEPTION)).when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));

        // ACT and Assert
        Assertions.assertThrows(DateTimeException.class, () -> {
            controller.triggerNewHireEvent(fromDate, toDate);
        });
    }

    /**
     * Test case for the `testTriggerStateTransferEvent_ValidDates_Success` method.
     *
     * This test verifies the behavior of the `triggerStateTransferEvent` method
     * when called with valid `fromDate` and `toDate` values. It checks that the
     * `service.getStateTransferEventDetailsAndSendMessage` method is called with the
     * correct parameters, and that the method returns the expected result.
     *
     */
    @Test
    public void testTriggerStateTransferEvent_ValidDates_Success() {
        // Arrange
        String fromDate = "2022-01-01";
        String toDate = "2022-01-31";
        String expectedResult = "Event(s) Creation Initiated";
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getStateTransferEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        // Act
        String response = controller.triggerStateTransferEvent(fromDate, toDate);

        // Assert
        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerStateTransferEvent_WithoutDates_Success` method.
     *
     * This test verifies the behavior of the `triggerStateTransferEvent` method
     * when called without `fromDate` and `toDate` parameters. It checks that the
     * `service.getStateTransferEventDetailsAndSendMessage` method is called with the
     * correct parameters, and that the method returns the expected result.
     */
    @Test
    public void testTriggerStateTransferEvent_WithoutDates_Success() {
        // Arrange
        String fromDate = LocalDate.now().toString();
        String toDate = LocalDate.now().toString();
        String expectedResult = "Event(s) Creation Initiated";
        ReflectionTestUtils.setField(controller,
                "stateTransferTriggerDays", "0");
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getStateTransferEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        // Act
        String response =
                controller.triggerStateTransferEvent(null, null);

        // Assert
        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerStateTransferEvent_WithoutDates_Success` method.
     *
     * This test verifies the behavior of the `triggerStateTransferEvent` method
     * when called without `fromDate` and `toDate` parameters. It checks that the
     * `service.getStateTransferEventDetailsAndSendMessage` method is called with the
     * correct parameters, and that the method returns the expected result.
     */
    @Test
    public void testTriggerStateTransferEvent_WithoutDatesAndTriggerDays_Success() {
        // Arrange
        String fromDate = LocalDate.now().toString();
        String toDate = LocalDate.now().toString();
        String expectedResult = "Event(s) Creation Initiated";
        ReflectionTestUtils.setField(controller,
                "stateTransferTriggerDays", null);
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getStateTransferEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        // Act
        String response =
                controller.triggerStateTransferEvent(null, null);

        // Assert
        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerStateTransferEvent_InvalidDates_Failure` method.
     *
     * This test case verifies the behavior of the `triggerStateTransferEvent` method
     * when called with invalid `fromDate` and `toDate` values. It checks that the
     * `validator.validateDateInputs` method is called with the correct parameters,
     * and that the method throws a `DateTimeException` with the expected message.
     *
     * @throws DateTimeException if the `fromDate` is after the `toDate`
     */
    @Test
    public void testTriggerStateTransferEvent_InvalidDates_Failure() {
        // Arrange
        String fromDate = "2022-02-01";
        String toDate = "2022-01-31";
        doThrow(new DateTimeException(Constants.FROM_DATE_EXCEPTION)).when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));

        // ACT and Assert
        Assertions.assertThrows(DateTimeException.class, () -> {
            controller.triggerNewHireEvent(fromDate, toDate);
        });
    }

    /**
     * Test case for the `testTriggerRateChange401kEvent_Success` method.
     *
     * This test verifies the behavior of the `triggerRateChange401kEvent` method
     * when it is successful. It checks that the `service.processRateChange401kFileAndSendMessage`
     * method is called and returns the expected result. It also asserts that the response
     * status code is `HttpStatus.OK` and the response body matches the expected result.
     *
     */
    @Test
    public void testTriggerRateChange401kEvent_Success() {
        // Arrange
        String expectedResult = "Event(s) Creation Initiated";
        when(service.processRateChange401kFileAndSendMessage()).thenReturn(expectedResult);
        // Act
        String response = controller.triggerRateChange401kEvent();
        // Assert
        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerReHireEvent_Valid` method.
     * This test case verifies the behavior of the `triggerReHireEvent` method
     * when valid `fromDate` and `toDate` values are provided.
     */
    @Test
    public void testTriggerReHireEvent_Valid() {
        // Test case: Valid fromDate and toDate
        String fromDate = "2022-01-01";
        String toDate = "2022-01-31";
        String expectedResult = "Event(s) Creation Initiated";
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getReHireEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        String response = controller.triggerReHireEvent(fromDate, toDate);

        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerReHireEvent_Invalid` method.
     * This test case verifies the behavior of the `triggerReHireEvent` method
     * when invalid `fromDate` and `toDate` values are provided.
     *
     * @throws IllegalArgumentException if the date format is invalid
     */
    @Test
    public void testTriggerReHireEvent_Invalid() {
        // Test case: Invalid fromDate and toDate
        String fromDate = "2022-02-01";
        String toDate = "2022-01-31";
        doThrow(new DateTimeException(Constants.FROM_DATE_EXCEPTION)).when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));

        // ACT and Assert
        Assertions.assertThrows(DateTimeException.class, () -> {
            controller.triggerReHireEvent(fromDate, toDate);
        });
    }

    /**
     * Test case for the `testTriggerTerminationEvent_WithoutDates_Success`
     * method.
     *
     * This test verifies the behavior of the `triggerTerminationEvent` method
     * when called without `fromDate` and `toDate` parameters. It checks that the
     * `service.getTerminationEventDetailsAndSendMessage` method is called with the
     * correct parameters, and that the method returns the expected result.
     */
    @Test
    public void testTriggerTerminationEvent_WithoutDates_Success() {
        // Arrange
        String fromDate = LocalDate.now().toString();
        String toDate = LocalDate.now().toString();
        String expectedResult = "Event(s) Creation Initiated";
        ReflectionTestUtils.setField(controller,
                "terminationTriggerDays", "0");
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getTerminationEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        // Act
        String response =
                controller.triggerTerminationEvent(null, null);

        // Assert
        assertEquals(expectedResult, response);
    }

    /**
     * Test case for the `testTriggerTerminationEvent_Invalid` method.
     * This test case verifies the behavior of the `triggerTerminationEvent` method
     * when invalid `fromDate` and `toDate` values are provided.
     *
     * @throws IllegalArgumentException if the date format is invalid
     */
    @Test
    public void testTriggerTerminationEvent_Invalid() {
        // Test case: Invalid fromDate and toDate
        String fromDate = "2022-02-01";
        String toDate = "2022-01-31";
        doThrow(new DateTimeException(Constants.FROM_DATE_EXCEPTION)).when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));

        // ACT and Assert
        Assertions.assertThrows(DateTimeException.class, () -> {
            controller.triggerTerminationEvent(fromDate, toDate);
        });
    }

    /**
     * Test case for the `testTriggerTerminationEvent_ValidDates_Success`
     * method.
     *
     * This test verifies the behavior of the `triggerTerminationEvent` method
     * when called with valid `fromDate` and `toDate` values. It checks that the
     * `service.getTerminationEventDetailsAndSendMessage` method is called with the
     * correct parameters, and that the method returns the expected result.
     *
     */
    @Test
    public void testTriggerTerminationEvent_ValidDates_Success() {
        // Arrange
        String fromDate = "2022-01-01";
        String toDate = "2022-01-31";
        String expectedResult = "Event(s) Creation Initiated";
        doNothing().when(validator).validateDateInputs(LocalDate.parse(fromDate), LocalDate.parse(toDate));
        when(service.getTerminationEventDetailsAndSendMessage(fromDate, toDate)).thenReturn(expectedResult);

        // Act
        String response = controller.triggerTerminationEvent(fromDate, toDate);

        // Assert
        assertEquals(expectedResult, response);
    }

    @Test
    void testTriggerLoan401kUsEvent_Success() {
        // Arrange
        String expectedResult = "Event(s) Creation Initiated";
        when(service.processLoan401kUsFileAndSendMessage()).thenReturn(expectedResult);

        // Act
        String response = controller.triggerLoan401kUsEvent();

        // Assert
        assertEquals(expectedResult, response);
        verify(service, times(1)).processLoan401kUsFileAndSendMessage();
    }

    @Test
    void testTriggerLoan401kPrEvent_Success() {
        // Arrange
        String expectedResult = "Event(s) Creation Initiated";
        when(service.processLoan401kPrFileAndSendMessage()).thenReturn(expectedResult);

        // Act
        String response = controller.triggerLoan401kPrEvent();

        // Assert
        assertEquals(expectedResult, response);
        verify(service, times(1)).processLoan401kPrFileAndSendMessage();
    }
    @Test
    void testTriggerHardship401kUsEvent_Success() {
        // Arrange
        String expectedResult = "Event(s) Creation Initiated";
        when(service.processHardship401kUsFileAndSendMessage()).thenReturn(expectedResult);

        // Act
        String response = controller.triggerHardship401kUsEvent();

        // Assert
        assertEquals(expectedResult, response);
        verify(service, times(1)).processHardship401kUsFileAndSendMessage();
    }

    @Test
    void testTriggerHardship401kPrEvent_Success() {
        // Arrange
        String expectedResult = "Event(s) Creation Initiated";
        when(service.processHardship401kPrFileAndSendMessage()).thenReturn(expectedResult);

        // Act
        String response = controller.triggerHardship401kPrEvent();

        // Assert
        assertEquals(expectedResult, response);
        verify(service, times(1)).processHardship401kPrFileAndSendMessage();
    }

}