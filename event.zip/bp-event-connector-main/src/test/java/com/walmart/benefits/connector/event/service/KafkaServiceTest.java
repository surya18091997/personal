package com.walmart.benefits.connector.event.service;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.TestPropertySource;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
class KafkaServiceTest {

    @Mock
    private KafkaTemplate<String, AssociateEvent> kafkaTemplate;

    @InjectMocks
    private KafkaService kafkaService;

    @Value("${kafka.events-queue.name}")
    private String topic;


    /**
     * Test the asynchronous message sending functionality.
     *
     * @throws Exception if any error occurs during the test
     */
    @Test
    void testSendMessage() throws NoSuchFieldException, IllegalAccessException {
        // Given
        AssociateEvent event = getAssociateEvent();
        setPartitions();

        // When
        when(kafkaTemplate.send(eq(topic), anyInt(), isNull(), eq(event))).thenReturn(null);
        kafkaService.sendMessage(event);

        // Then
        verify(kafkaTemplate).send(eq(topic), anyInt(), isNull(), eq(event));
    }

    @Test
    void testSendMessageWithError() throws NoSuchFieldException, IllegalAccessException {
        // Given
        AssociateEvent event = getAssociateEvent();
        setPartitions();

        // When
        when(kafkaTemplate.send(eq(topic), anyInt(), isNull(), eq(event))).thenThrow(new RuntimeException());
        kafkaService.sendMessage(event);

        // Then
        verify(kafkaTemplate).send(eq(topic), anyInt(), isNull(), eq(event));
    }

    @Test
    void testSendMessageForListOfEvents() throws NoSuchFieldException, IllegalAccessException {
        // Given
        List<AssociateEvent> events = new ArrayList<>();
        events.add(getAssociateEvent());
        setPartitions();

        // When
        when(kafkaTemplate.send(eq(topic), anyInt(), isNull(),
                eq(events.get(0)))).thenReturn(null);
        kafkaService.sendMessage(events);

        // Then
        verify(kafkaTemplate).send(eq(topic), anyInt(), isNull(),
                eq(events.get(0)));
    }

    private void setPartitions() throws NoSuchFieldException, IllegalAccessException {
        Field partitionsField = KafkaService.class.getDeclaredField("partitions");
        partitionsField.setAccessible(true);
        partitionsField.set(kafkaService, "3");
    }

    private AssociateEvent getAssociateEvent(){
        var event = new AssociateEvent();
        event.setAssociateId(String.valueOf(12345671));
        event.setId(UUID.randomUUID());
        event.setEventType(EventType.NEW_HIRE);
        event.setOrigin(EventOrigin.CORE_HR);
        event.setTimeStamp(LocalDate.now().toString());
        return event;
    }
}
