package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.config.*;
import com.walmart.benefits.connector.event.model.*;
import com.walmart.benefits.connector.event.repository.ConnectorRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class FileToEventsProcessorServiceTest {

    @Mock
    private FileParserService fileParserService;

    @Mock
    private RateChange401kConfig rateChange401kConfig;

    @Mock
    private LoanUsConfig loanUsConfig;

    @Mock
    private LoanPrConfig loanPrConfig;

    @Mock
    private HardshipUsConfig hardshipUsConfig;

    @Mock
    private HardshipPrConfig hardshipPrConfig;

    @Mock
    private FileService fileService;

    @Mock
    private ConnectorRepository dao;

    @Mock
    private KafkaService kafkaService;

    @InjectMocks
    private FileToEventsProcessorService fileToEventsProcessorService;

    @Test
    void testProcess401kRateChangeFileAndSendMessage_fileExists_success() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        Files.writeString(filePath, "6094500018229062024110409520983133100140");
        when(rateChange401kConfig.getRateChangeFileName()).thenReturn(filePath.getFileName().toString());
        when(rateChange401kConfig.getFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(rateChange401kConfig.getFileArchivePath()).thenReturn(filePath.getParent().toString());
        RateChangeFileParseResult rateChangeFileParseResult =
                new RateChangeFileParseResult(
                List.of(RateChangeMLModel.builder()
                        .planNumber("609450")
                        .creationDate("20241104")
                        .creationTime("095209")
                        .transactionId("0983133100140")
                        .partNumber("001822906")
                        .build(),
                        RateChangeMLModel.builder()
                        .planNumber("609450")
                        .creationDate("2024-11-04")
                        .creationTime("095209")
                        .transactionId("0983133100140")
                        .partNumber("001822906")
                        .build()),
                new HashSet<>(List.of("001822906"))
        );
        when(fileParserService.parseRateChange401KFile(eq(filePath),
                eq(rateChange401kConfig))).thenReturn(rateChangeFileParseResult);
        Map<String, String> ssnWinIdMap = Map.of("001822906", "123456789");
        when(dao.getAssociateIdListFromSsnList(any())).thenReturn(ssnWinIdMap);

        // Act
        fileToEventsProcessorService.process401kRateChangeFileAndSendMessage();

        // Assert
        verify(fileParserService, times(1)).parseRateChange401KFile(eq(filePath), eq(rateChange401kConfig));
        verify(dao, times(1)).getAssociateIdListFromSsnList(any());
        verify(kafkaService, times(1)).sendMessage(anyList());
    }

    @Test
    void testProcess401kRateChangeFileAndSendMessage_fileNotExists_failure() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        when(rateChange401kConfig.getRateChangeFileName()).thenReturn("test1");
        when(rateChange401kConfig.getFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(rateChange401kConfig.getFileArchivePath()).thenReturn(filePath.getParent().toString());
        doThrow(new IOException("File not found")).when(fileService).checkIfFileExists(anyString(), anyString());

        // Act & Assert
        Assertions.assertThrows(RuntimeException.class, () -> {
            fileToEventsProcessorService.process401kRateChangeFileAndSendMessage();
        });

        verify(fileParserService, times(0)).parseRateChange401KFile(any(),
                any());
        verify(kafkaService, times(0)).sendMessage(anyList());
    }

    @Test
    void testProcessLoanUsFileAndSendMessage_fileExists_success() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        Files.writeString(filePath, "header" +
                "\n12345678901234567890123456789012345678901234567890123456789012345678901234567890\ntrailer");
        when(loanUsConfig.getLoanUsFileName()).thenReturn(filePath.getFileName().toString());
        when(loanUsConfig.getLoanFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(loanUsConfig.getLoanFileArchivePath()).thenReturn(filePath.getParent().toString());
        LoanFileParseResult loanFileParseResult = new LoanFileParseResult(
                List.of(LoanModelFromML
                        .builder()
                        .loanNumber("001")
                        .ssnId("123456789")
                        .empNumber("123456789")
                        .deductionAmount("123.45")
                        .loanType("0")
                        .payrollId("1234")
                        .goalAmount("123.45")
                        .payrollFrequency("W")
                        .storeLocationCode("1234")
                        .build()),
                new HashSet<>(List.of("123456789"))
        );
        when(fileParserService.parseLoan401kFile(eq(filePath),
                eq(loanUsConfig))).thenReturn(loanFileParseResult);
        Map<String, String> ssnWinIdMap = Map.of("123456789", "123456789");
        when(dao.getAssociateIdListFromSsnList(any())).thenReturn(ssnWinIdMap);

        // Act
        fileToEventsProcessorService.processLoanUsFileAndSendMessage();

        // Assert
        verify(fileParserService, times(1)).parseLoan401kFile(eq(filePath),
                eq(loanUsConfig));
        verify(dao, times(1)).getAssociateIdListFromSsnList(any());
        verify(kafkaService, times(1)).sendMessage(anyList());
    }

    @Test
    void testProcessLoanUsFileAndSendMessage_fileNotExists_failure() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        when(loanUsConfig.getLoanUsFileName()).thenReturn("test1");
        when(loanUsConfig.getLoanFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(loanUsConfig.getLoanFileArchivePath()).thenReturn(filePath.getParent().toString());
        doThrow(new IOException("File not found")).when(fileService).checkIfFileExists(anyString(), anyString());

        // Act & Assert
        Assertions.assertThrows(RuntimeException.class, () -> {
            fileToEventsProcessorService.processLoanUsFileAndSendMessage();
        });

        verify(fileParserService, times(0)).parseLoan401kFile(any(), any());
        verify(kafkaService, times(0)).sendMessage(anyList());
    }

    @Test
    void testProcessLoanPrFileAndSendMessage_fileExists_success() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        Files.writeString(filePath, "header" +
                "\n12345678901234567890123456789012345678901234567890123456789012345678901234567890\ntrailer");
        when(loanPrConfig.getLoanPrFileName()).thenReturn(filePath.getFileName().toString());
        when(loanPrConfig.getLoanFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(loanPrConfig.getLoanFileArchivePath()).thenReturn(filePath.getParent().toString());
        LoanFileParseResult loanFileParseResult = new LoanFileParseResult(
                List.of((LoanModelFromML
                            .builder()
                            .loanNumber("001")
                            .ssnId("123456789")
                            .empNumber("123456789")
                            .deductionAmount("123.45")
                            .loanType("0")
                            .payrollId("1234")
                            .goalAmount("123.45")
                            .payrollFrequency("W")
                            .storeLocationCode("1234")
                            .build()),
                        LoanModelFromML
                            .builder()
                            .loanNumber("001")
                            .ssnId("123456789")
                            .empNumber("123456788")
                            .deductionAmount("123.45")
                            .loanType("0")
                            .payrollId("1234")
                            .goalAmount("123.45")
                            .payrollFrequency("W")
                            .storeLocationCode("1234")
                            .build()),
                new HashSet<>(List.of("123456789"))
        );
        when(fileParserService.parseLoan401kFile(eq(filePath),
                eq(loanPrConfig))).thenReturn(loanFileParseResult);
        Map<String, String> ssnWinIdMap = Map.of("123456789", "123456789");
        when(dao.getAssociateIdListFromSsnList(any())).thenReturn(ssnWinIdMap);

        // Act
        fileToEventsProcessorService.processLoanPrFileAndSendMessage();

        // Assert
        verify(fileParserService, times(1)).parseLoan401kFile(eq(filePath),
                eq(loanPrConfig));
        verify(dao, times(1)).getAssociateIdListFromSsnList(any());
        verify(kafkaService, times(1)).sendMessage(anyList());
    }

    @Test
    void testProcessLoanPrFileAndSendMessage_fileNotExists_failure() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        when(loanPrConfig.getLoanPrFileName()).thenReturn("test1");
        when(loanPrConfig.getLoanFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(loanPrConfig.getLoanFileArchivePath()).thenReturn(filePath.getParent().toString());
        doThrow(new IOException("File not found")).when(fileService).checkIfFileExists(anyString(), anyString());

        // Act & Assert
        Assertions.assertThrows(RuntimeException.class, () -> {
            fileToEventsProcessorService.processLoanPrFileAndSendMessage();
        });

        verify(fileParserService, times(0)).parseLoan401kFile(any(), any());
        verify(kafkaService, times(0)).sendMessage(anyList());
    }
    @Test
    void testProcessHardshipUsFileAndSendMessage_fileExists_success() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        Files.writeString(filePath, "header\n12345678901234567890123456789012345678901234567890123456789012345678901234567890\ntrailer");
        when(hardshipUsConfig.getHardshipUsFileName()).thenReturn(filePath.getFileName().toString());
        when(hardshipUsConfig.getHardshipFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(hardshipUsConfig.getHardshipFileArchivePath()).thenReturn(filePath.getParent().toString());
        HardshipFileParseResult hardshipFileParseResult = new HardshipFileParseResult(
                List.of(HardshipModelFromML.builder()
                        .ssnId("123456789")
                        .recordType("10")
                        .merMatchEligDate("2023-01-01")
                        .merMatchEligInd("Y")
                        .build()),
                new HashSet<>(List.of("123456789"))
        );
        when(fileParserService.parseHardship401kFile(eq(filePath.toAbsolutePath()), eq(hardshipUsConfig))).thenReturn(hardshipFileParseResult);
        Map<String, String> ssnWinIdMap = Map.of("123456789", "123456789");
        when(dao.getAssociateIdListFromSsnList(any())).thenReturn(ssnWinIdMap);

        // Act
        fileToEventsProcessorService.processHardshipUsFileAndSendMessage();

        // Assert
        verify(fileParserService, times(1)).parseHardship401kFile(eq(filePath), eq(hardshipUsConfig));
        verify(dao, times(1)).getAssociateIdListFromSsnList(any());
        verify(kafkaService, times(1)).sendMessage(anyList());
    }

    @Test
    void testProcessHardshipUsFileAndSendMessage_fileNotExists_failure() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        when(hardshipUsConfig.getHardshipUsFileName()).thenReturn("test1");
        when(hardshipUsConfig.getHardshipFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(hardshipUsConfig.getHardshipFileArchivePath()).thenReturn(filePath.getParent().toString());
        doThrow(new IOException("File not found")).when(fileService).checkIfFileExists(anyString(), anyString());

        // Act & Assert
        Assertions.assertThrows(RuntimeException.class, () -> {
            fileToEventsProcessorService.processHardshipUsFileAndSendMessage();
        });

        verify(fileParserService, times(0)).parseHardship401kFile(any(), any());
        verify(kafkaService, times(0)).sendMessage(anyList());
    }
    @Test
    void testProcessHardshipPrFileAndSendMessage_fileNotExists_failure() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        when(hardshipPrConfig.getHardshipPrFileName()).thenReturn("test1");
        when(hardshipPrConfig.getHardshipFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(hardshipPrConfig.getHardshipFileArchivePath()).thenReturn(filePath.getParent().toString());
        doThrow(new IOException("File not found")).when(fileService).checkIfFileExists(anyString(), anyString());

        // Act & Assert
        Assertions.assertThrows(RuntimeException.class, () -> {
            fileToEventsProcessorService.processHardshipPrFileAndSendMessage();
        });

        verify(fileParserService, times(0)).parseHardship401kFile(any(), any());
        verify(kafkaService, times(0)).sendMessage(anyList());
    }

    @Test
    void testProcessHardshipPrFileAndSendMessage_fileExists_success() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        Files.writeString(filePath, "header\n12345678901234567890123456789012345678901234567890123456789012345678901234567890\ntrailer");
        when(hardshipPrConfig.getHardshipPrFileName()).thenReturn(filePath.getFileName().toString());
        when(hardshipPrConfig.getHardshipFileSharedPath()).thenReturn(filePath.getParent().toString());
        when(hardshipPrConfig.getHardshipFileArchivePath()).thenReturn(filePath.getParent().toString());
        HardshipFileParseResult hardshipFileParseResult = new HardshipFileParseResult(
                List.of(HardshipModelFromML.builder()
                        .ssnId("123456789")
                        .recordType("50")
                        .startDate("2023-01-01")
                        .resumeDate("2023-06-01")
                        .build()),
                new HashSet<>(List.of("123456789"))
        );
        when(fileParserService.parseHardship401kFile(eq(filePath.toAbsolutePath()), eq(hardshipPrConfig))).thenReturn(hardshipFileParseResult);
        Map<String, String> ssnWinIdMap = Map.of("123456789", "123456789");
        when(dao.getAssociateIdListFromSsnList(any())).thenReturn(ssnWinIdMap);

        // Act
        fileToEventsProcessorService.processHardshipPrFileAndSendMessage();

        // Assert
        verify(fileParserService, times(1)).parseHardship401kFile(eq(filePath), eq(hardshipPrConfig));
        verify(dao, times(1)).getAssociateIdListFromSsnList(any());
        verify(kafkaService, times(1)).sendMessage(anyList());
    }


}