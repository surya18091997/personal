package com.walmart.benefits.connector.event.repository;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.TableResult;
import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ConnectorRepository focusing on retry logic verification using spy methods.
 * This test class verifies that the RetryTemplate is properly invoked for database operations
 * and that retry behavior works correctly when exceptions occur.
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings({"unchecked", "rawtypes"})
class ConnectorRepositoryRetryTest {

    @Mock
    private JdbcTemplate db2JdbcTemplate;

    @Mock
    private SQLHelper sqlHelper;

    @Mock
    private BigQuery bigQuery;

    @Spy
    private RetryTemplate retryTemplate;

    private ConnectorRepository connectorRepository;

    @BeforeEach
    void setUp() {
        connectorRepository = new ConnectorRepository(db2JdbcTemplate, sqlHelper, bigQuery);
        // Inject the spy RetryTemplate using reflection
        try {
            var field = ConnectorRepository.class.getDeclaredField("retryTemplate");
            field.setAccessible(true);
            field.set(connectorRepository, retryTemplate);
        } catch (Exception e) {
            throw new RuntimeException("Failed to inject spy RetryTemplate", e);
        }
        // Set a real backoff policy for timing tests
        FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(2000); // 2 seconds
        retryTemplate.setBackOffPolicy(backOffPolicy);
    }

    @Test
    void testGetNewHireAssociateEventsFromHr_RetryLogic() throws Exception {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-31");
        List<AssociateEvent> expectedEvents = createMockAssociateEvents(EventType.NEW_HIRE);

        when(sqlHelper.getNewHireAssociateEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s");
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any()))
                .thenReturn(expectedEvents);

        // Act
        List<AssociateEvent> result = connectorRepository.getNewHireAssociateEventsFromHr(fromDate, toDate);

        // Assert
        assertNotNull(result);
        assertEquals(expectedEvents.size(), result.size());

        // Capture and verify the query arguments
        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<RowMapper> rowMapperCaptor = ArgumentCaptor.forClass(RowMapper.class);
        ArgumentCaptor<Object> arg1Captor = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<Object> arg2Captor = ArgumentCaptor.forClass(Object.class);
        verify(db2JdbcTemplate, times(1)).query(sqlCaptor.capture(), rowMapperCaptor.capture(), arg1Captor.capture(), arg2Captor.capture());
        // Relaxed assertion: just check the query starts with the expected prefix
        assertTrue(sqlCaptor.getValue().startsWith("SELECT * FROM hr_events WHERE"));
        assertEquals(fromDate, arg1Captor.getValue());
        assertEquals(toDate, arg2Captor.getValue());

        // Verify that retryTemplate.execute() was called exactly once
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
    }

    @Test
    void testGetNewHireAssociateEventsFromHr_RetryOnException() throws Exception {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-31");
        List<AssociateEvent> expectedEvents = createMockAssociateEvents(EventType.NEW_HIRE);

        when(sqlHelper.getNewHireAssociateEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s");
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any()))
                .thenThrow(new DataIntegrityViolationException("Connection failed"))
                .thenThrow(new DataIntegrityViolationException("Timeout"))
                .thenReturn(expectedEvents);

        // Act
        List<AssociateEvent> result = connectorRepository.getNewHireAssociateEventsFromHr(fromDate, toDate);

        // Assert
        assertNotNull(result);
        assertEquals(expectedEvents.size(), result.size());

        // Capture and verify the query arguments (last call)
        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<RowMapper> rowMapperCaptor = ArgumentCaptor.forClass(RowMapper.class);
        ArgumentCaptor<Object> arg1Captor = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<Object> arg2Captor = ArgumentCaptor.forClass(Object.class);
        verify(db2JdbcTemplate, times(3)).query(sqlCaptor.capture(), rowMapperCaptor.capture(), arg1Captor.capture(), arg2Captor.capture());
        List<String> allSqls = sqlCaptor.getAllValues();
        assertTrue(allSqls.get(0).startsWith("SELECT * FROM hr_events WHERE"));
        assertTrue(allSqls.get(1).startsWith("SELECT * FROM hr_events WHERE"));
        assertTrue(allSqls.get(2).startsWith("SELECT * FROM hr_events WHERE"));
        assertEquals(fromDate, arg1Captor.getValue());
        assertEquals(toDate, arg2Captor.getValue());

        // Verify retryTemplate.execute() was called once (but executed the callback 3 times internally)
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
    }

    @Test
    void testGetNewHireAssociateEventsFromHr_RetryExceedsMaxAttempts() {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-31");

        when(sqlHelper.getNewHireAssociateEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s");
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any()))
                .thenThrow(new DataIntegrityViolationException("Persistent database error"));

        // Act & Assert
        assertThrows(DataIntegrityViolationException.class, () ->
                connectorRepository.getNewHireAssociateEventsFromHr(fromDate, toDate));

        // Capture and verify the query arguments (all attempts)
        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<RowMapper> rowMapperCaptor = ArgumentCaptor.forClass(RowMapper.class);
        ArgumentCaptor<Object> arg1Captor = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<Object> arg2Captor = ArgumentCaptor.forClass(Object.class);
        verify(db2JdbcTemplate, times(3)).query(sqlCaptor.capture(), rowMapperCaptor.capture(), arg1Captor.capture(), arg2Captor.capture());
        List<String> allSqls = sqlCaptor.getAllValues();
        assertEquals(3, allSqls.size());
        assertTrue(allSqls.get(0).startsWith("SELECT * FROM hr_events WHERE"));
        assertTrue(allSqls.get(1).startsWith("SELECT * FROM hr_events WHERE"));
        assertTrue(allSqls.get(2).startsWith("SELECT * FROM hr_events WHERE"));
        assertEquals(fromDate, arg1Captor.getValue());
        assertEquals(toDate, arg2Captor.getValue());

        // Verify retryTemplate.execute() was called once
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
    }

    @Test
    void testGetNewHireBackDatedHireDateAssociateEventsFromHr_RetryLogic() {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        List<AssociateEvent> expectedEvents = createMockAssociateEvents(EventType.NEW_HIRE);

        when(sqlHelper.getNewHireBackDatedEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s AND %s");
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any(), any()))
                .thenReturn(expectedEvents);

        // Act
        List<AssociateEvent> result = connectorRepository.getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate);

        // Assert
        assertNotNull(result);
        assertEquals(expectedEvents.size(), result.size());

        // Verify retry template was used
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(db2JdbcTemplate, times(1)).query(anyString(), any(RowMapper.class), eq(fromDate), eq(fromDate), eq(fromDate));
    }

    @Test
    void testGetReHireAssociateEventsFromHr_RetryLogic() throws Exception {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-31");
        List<AssociateEvent> expectedEvents = createMockAssociateEvents(EventType.RE_HIRE);

        when(sqlHelper.getReHireAssociateEventQuery()).thenReturn("SELECT * FROM bq_events WHERE %s AND %s AND %s AND %s");

        // Mock BigQuery components
        TableResult mockTableResult = mock(TableResult.class);
        FieldValueList mockRow = mock(FieldValueList.class);

        when(bigQuery.query(any(QueryJobConfiguration.class))).thenReturn(mockTableResult);
        when(mockTableResult.iterateAll()).thenReturn(Arrays.asList(mockRow));
        when(mockRow.get(Constants.WIN_NBR_COLUMN)).thenReturn(mock(com.google.cloud.bigquery.FieldValue.class));
        when(mockRow.get(Constants.WIN_NBR_COLUMN).getStringValue()).thenReturn("123456789");

        // Act
        List<AssociateEvent> result = connectorRepository.getReHireAssociateEventsFromHr(fromDate, toDate);

        // Assert
        assertNotNull(result);

        // Verify retry template was used twice (once for main method, once for helper method)
        verify(retryTemplate, times(2)).execute(any(RetryCallback.class));
        verify(bigQuery, times(1)).query(any(QueryJobConfiguration.class));
    }

    @Test
    void testGetTerminationAssociateEventsFromHr_RetryLogic() throws Exception {
        // Arrange
        Timestamp fromDate = Timestamp.valueOf("2022-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2022-01-31 23:59:59");

        when(sqlHelper.getTerminationAssociateEventQuery()).thenReturn("SELECT * FROM bq_events WHERE %s AND %s AND %s AND %s AND %s");

        // Mock BigQuery components
        TableResult mockTableResult = mock(TableResult.class);
        FieldValueList mockRow = mock(FieldValueList.class);

        when(bigQuery.query(any(QueryJobConfiguration.class))).thenReturn(mockTableResult);
        when(mockTableResult.iterateAll()).thenReturn(Arrays.asList(mockRow));
        when(mockRow.get(Constants.WIN_NBR_COLUMN)).thenReturn(mock(com.google.cloud.bigquery.FieldValue.class));
        when(mockRow.get(Constants.WIN_NBR_COLUMN).getStringValue()).thenReturn("123456789");

        // Act
        List<AssociateEvent> result = connectorRepository.getTerminationAssociateEventsFromHr(fromDate, toDate);

        // Assert
        assertNotNull(result);

        // Verify retry template was used twice (once for main method, once for helper method)
        verify(retryTemplate, times(2)).execute(any(RetryCallback.class));
        verify(bigQuery, times(1)).query(any(QueryJobConfiguration.class));
    }

    @Test
    void testGetStateTransferAssociateEventsFromHr_RetryLogic() {
        // Arrange
        Timestamp fromDate = Timestamp.valueOf("2022-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2022-01-31 23:59:59");
        List<AssociateEvent> expectedEvents = createMockAssociateEvents(EventType.STATE_TRANSFER);

        when(sqlHelper.getStateTransferAssociateEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s AND %s AND %s AND %s");
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any()))
                .thenReturn(expectedEvents);

        // Act
        List<AssociateEvent> result = connectorRepository.getStateTransferAssociateEventsFromHr(fromDate, toDate);

        // Assert
        assertNotNull(result);
        assertEquals(expectedEvents.size(), result.size());

        // Verify retry template was used
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(db2JdbcTemplate, times(1)).query(anyString(), any(RowMapper.class), eq(fromDate), eq(toDate));
    }

    @Test
    void testGetAssociateIdListFromSsnList_RetryLogic() {
        // Arrange
        List<String> ssnList = Arrays.asList("123456789", "987654321");
        Map<String, String> expectedMap = Map.of("123456789", "WIN123", "987654321", "WIN456");
        List<Map.Entry<String, String>> queryResult = Arrays.asList(
                Map.entry("123456789", "WIN123"),
                Map.entry("987654321", "WIN456")
        );

        when(sqlHelper.getNationalIdMappingQuery()).thenReturn("SELECT ssn, win_nbr FROM mapping WHERE ssn IN (?,?)");
        when(db2JdbcTemplate.query(eq("SELECT ssn, win_nbr FROM mapping WHERE ssn IN (?,?)"), any(RowMapper.class), eq("123456789"), eq("987654321")))
                .thenReturn(queryResult);

        // Act
        Map<String, String> result = connectorRepository.getAssociateIdListFromSsnList(ssnList);

        // Assert
        assertNotNull(result);
        assertEquals(expectedMap.size(), result.size());
        assertEquals("WIN123", result.get("123456789"));
        assertEquals("WIN456", result.get("987654321"));

        // Verify retry template was used
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(db2JdbcTemplate, times(1)).query(eq("SELECT ssn, win_nbr FROM mapping WHERE ssn IN (?,?)"), any(RowMapper.class), eq("123456789"), eq("987654321"));
    }

    @Test
    void testGetAssociateIdListFromSsnList_RetryOnException() {
        // Arrange
        List<String> ssnList = Arrays.asList("123456789");
        Map<String, String> expectedMap = Map.of("123456789", "WIN123");
        List<Map.Entry<String, String>> queryResult = Arrays.asList(Map.entry("123456789", "WIN123"));

        when(sqlHelper.getNationalIdMappingQuery()).thenReturn("SELECT ssn, win_nbr FROM mapping WHERE ssn IN (%s)");

        // Simulate failure then success
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any()))
                .thenThrow(new DataAccessException("Database connection failed") {})
                .thenReturn(queryResult);

        // Act
        Map<String, String> result = connectorRepository.getAssociateIdListFromSsnList(ssnList);

        // Assert
        assertNotNull(result);
        assertEquals(expectedMap.size(), result.size());

        // Verify retry template was used and underlying method was called twice
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(db2JdbcTemplate, times(2)).query(anyString(), any(RowMapper.class), any());
    }

    @Test
    void testGetStateTransferAssociatesFromBigQuery_RetryLogic() throws Exception {
        // Arrange
        Timestamp fromDate = Timestamp.valueOf("2022-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2022-01-31 23:59:59");

        when(sqlHelper.getStateTransferBgQuery()).thenReturn("SELECT * FROM state_transfer WHERE %s AND %s AND %s");

        // Mock BigQuery components
        TableResult mockTableResult = mock(TableResult.class);
        FieldValueList mockRow = mock(FieldValueList.class);

        when(bigQuery.query(any(QueryJobConfiguration.class))).thenReturn(mockTableResult);
        when(mockTableResult.iterateAll()).thenReturn(Arrays.asList(mockRow));

        // Mock all required fields
        com.google.cloud.bigquery.FieldValue mockFieldValue = mock(com.google.cloud.bigquery.FieldValue.class);
        when(mockRow.get(Constants.WIN_NBR_COLUMN)).thenReturn(mockFieldValue);
        when(mockRow.get(Constants.TO_STATE_COLUMN)).thenReturn(mockFieldValue);
        when(mockRow.get(Constants.FROM_STATE_COLUMN)).thenReturn(mockFieldValue);
        when(mockRow.get(Constants.HIRE_DATE_COLUMN)).thenReturn(mockFieldValue);
        when(mockFieldValue.getStringValue()).thenReturn("123456789", "TX", "CA", "2022-01-01");

        // Act
        List<AssociateEvent> result = connectorRepository.getStateTransferAssociatesFromBigQuery(fromDate, toDate);

        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());

        // Verify retry template was used
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(bigQuery, times(1)).query(any(QueryJobConfiguration.class));
    }

    @Test
    void testGetStateTransferAssociatesFromBigQuery_RetryOnException() throws Exception {
        // Arrange
        Timestamp fromDate = Timestamp.valueOf("2022-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2022-01-31 23:59:59");

        when(sqlHelper.getStateTransferBgQuery()).thenReturn("SELECT * FROM state_transfer WHERE %s AND %s AND %s");

        // Mock BigQuery components for successful call
        TableResult mockTableResult = mock(TableResult.class);
        when(mockTableResult.iterateAll()).thenReturn(Collections.emptyList());

        // Simulate failure then success
        when(bigQuery.query(any(QueryJobConfiguration.class)))
                .thenThrow(new RuntimeException("BigQuery service unavailable"))
                .thenReturn(mockTableResult);

        // Act
        List<AssociateEvent> result = connectorRepository.getStateTransferAssociatesFromBigQuery(fromDate, toDate);

        // Assert
        assertNotNull(result);

        // Verify retry template was used and BigQuery was called twice
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));
        verify(bigQuery, times(2)).query(any(QueryJobConfiguration.class));
    }

    @Test
    void testRetryTemplateBackoffBehavior() throws Exception {
        // Arrange
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-31");

        when(sqlHelper.getNewHireAssociateEventQuery()).thenReturn("SELECT * FROM hr_events WHERE %s");

        // Simulate multiple failures
        when(db2JdbcTemplate.query(anyString(), any(RowMapper.class), any(), any()))
                .thenThrow(new DataIntegrityViolationException("Failure 1"))
                .thenThrow(new DataIntegrityViolationException("Failure 2"))
                .thenReturn(createMockAssociateEvents(EventType.NEW_HIRE));

        long startTime = System.currentTimeMillis();

        // Act
        List<AssociateEvent> result = connectorRepository.getNewHireAssociateEventsFromHr(fromDate, toDate);

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        // Assert
        assertNotNull(result);

        // Verify retry template was used
        verify(retryTemplate, times(1)).execute(any(RetryCallback.class));

        // Verify the underlying query was called 3 times (2 failures + 1 success)
        verify(db2JdbcTemplate, times(3)).query(anyString(), any(RowMapper.class), eq(fromDate), eq(toDate));

        // Verify that some backoff time was applied (should be at least 4 seconds for 2 retries with 2-second backoff)
        // Note: This is a rough check since the actual backoff might vary slightly
        assertTrue(executionTime >= 3900, "Expected backoff time not observed. Execution time: " + executionTime + "ms");
    }

    /**
     * Helper method to create mock AssociateEvent objects for testing
     */
    private List<AssociateEvent> createMockAssociateEvents(EventType eventType) {
        List<AssociateEvent> events = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            AssociateEvent event = new AssociateEvent();
            event.setAssociateId("ASSOC" + (i + 1));
            event.setEventType(eventType);
            event.setId(UUID.randomUUID());
            event.setTimeStamp(LocalDate.now().toString());
            events.add(event);
        }
        return events;
    }
}
