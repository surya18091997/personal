package com.walmart.benefits.connector.event.utils;

import org.apache.kafka.common.errors.SerializationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AESSerializerTest {

    @InjectMocks
    private AESSerializer serializer;

    @Test
    void testConfigure_withNullSecret_throwsException() {
        Map<String, Object> configs = new HashMap<>();

        assertThrows(SerializationException.class, () -> serializer.configure(configs, false));
    }

    @Test
    void testConfigure_withValidConfigs_doesNotThrowException() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AESSerializer.AES_SECRET_KEY, "secret");

        serializer.configure(configs, false);
        assertEquals("secret", configs.get(AESSerializer.AES_SECRET_KEY));
    }

    @Test
    void testSerialize_withValidData_returnsEncryptedData() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AESSerializer.AES_SECRET_KEY, "secret");

        AESSerializer<String> serializer = new AESSerializer<>();
        serializer.configure(configs, false);

        String data = "test data";
        byte[] expected = AES.encrypt(data.getBytes(), "secret");

        byte[] actual = serializer.serialize("topic", data);

        assertArrayEquals(expected, actual);
    }
}
