package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CoreHrServiceTest {

    @Mock
    private ConnectorRepository dao;

    @Mock
    private KafkaService kafkaService;

    @InjectMocks
    private CoreHrService coreHrService;

    @Test
    public void testGetNewHireAssociateEventsAndSendMessageAsync() {
        // Given
        Date fromDate = Date.valueOf("2022-01-01");
        Date toDate = Date.valueOf("2022-01-03");
        List<AssociateEvent> associateEvents = getAssociateEvents(EventType.NEW_HIRE);

        // When
        when(dao.getNewHireAssociateEventsFromHr(fromDate, toDate)).thenReturn(associateEvents);

        //Act
        coreHrService.getNewHireAssociateEventsAndSendMessageAsync(fromDate, toDate);

        // Then
        verify(dao, times(1)).getNewHireAssociateEventsFromHr(fromDate, toDate);
        verify(kafkaService, times(1)).sendMessage(associateEvents);
    }

    @Test
    public void testGetNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync() {
        // Given
        Date fromDate = Date.valueOf("2022-01-01");
        List<AssociateEvent> associateEvents = getAssociateEvents(EventType.NEW_HIRE);

        // When
        when(dao.getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate)).thenReturn(associateEvents);

        //Act
        coreHrService.getNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync(fromDate);

        // Then
        verify(dao, times(1)).getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate);
        verify(kafkaService, times(1)).sendMessage(associateEvents);
    }

    @Test
    public void test_GetNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync_exception() {
        // Arrange
        ConnectorRepository mockDao = mock(ConnectorRepository.class);
        KafkaService mockKafkaService = mock(KafkaService.class);
        CoreHrService coreHrService = new CoreHrService(mockDao, mockKafkaService);

        Date fromDate = Date.valueOf("2023-01-01");

        when(mockDao.getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate))
                .thenThrow(new RuntimeException("Database query failed"));

        coreHrService.getNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync(fromDate);


        verify(mockDao).getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate);
        verify(mockKafkaService, never()).sendMessage(anyList());
    }

    @Test
    public void testGetStateTransferAssociateEventsAndSendMessageAsync() {
        // Given
        var fromDateTs = Timestamp.valueOf(LocalDate.parse("2022-01-01").atStartOfDay());
        var toDateTs = Timestamp.valueOf(LocalDate.parse("2022-01-03").plusDays(1).atStartOfDay());
        List<AssociateEvent> associateEvents = getAssociateEvents(EventType.STATE_TRANSFER);

        // When
        when(dao.getStateTransferAssociatesFromBigQuery(fromDateTs, toDateTs)).thenReturn(associateEvents);

        //Act
        coreHrService.getStateTransferAssociateEventsAndSendMessageAsync(fromDateTs, toDateTs);

        // Then
        verify(dao, times(1)).getStateTransferAssociatesFromBigQuery(fromDateTs, toDateTs);
        verify(kafkaService, times(1)).sendMessage(associateEvents);
    }


    private List<AssociateEvent> getAssociateEvents(EventType eventType) {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        for(var i=0; i<3; i++){
            var event = new AssociateEvent();
            event.setAssociateId(String.valueOf(12345671 + i));
            event.setId(UUID.randomUUID());
            event.setEventType(eventType);
            event.setOrigin(EventOrigin.CORE_HR);
            event.setTimeStamp(LocalDate.now().toString());
            associateEvents.add(event);
        }
        return associateEvents;
    }

    @Test
    public void test_get_new_hire_events_and_send_to_kafka_success() {

        Date fromDate = Date.valueOf("2023-01-01");
        Date toDate = Date.valueOf("2023-01-31");

        List<AssociateEvent> mockEvents = Arrays.asList(
                new AssociateEvent(),
                new AssociateEvent()
        );

        when(dao.getNewHireAssociateEventsFromHr(fromDate, toDate))
                .thenReturn(mockEvents);

        doNothing().when(kafkaService).sendMessage(mockEvents);
        coreHrService.getNewHireAssociateEventsAndSendMessageAsync(fromDate, toDate);

        verify(dao).getNewHireAssociateEventsFromHr(fromDate, toDate);
        verify(kafkaService, times(1)).sendMessage(mockEvents);
    }

    @Test
    public void test_exception_during_database_query() {
        // Arrange
        ConnectorRepository mockDao = mock(ConnectorRepository.class);
        KafkaService mockKafkaService = mock(KafkaService.class);
        CoreHrService coreHrService = new CoreHrService(mockDao, mockKafkaService);

        Date fromDate = Date.valueOf("2023-01-01");
        Date toDate = Date.valueOf("2023-01-31");

        when(mockDao.getNewHireAssociateEventsFromHr(fromDate, toDate))
                .thenThrow(new RuntimeException("Database query failed"));

        coreHrService.getNewHireAssociateEventsAndSendMessageAsync(fromDate, toDate);


        verify(mockDao).getNewHireAssociateEventsFromHr(fromDate, toDate);
        verify(mockKafkaService, never()).sendMessage(anyList());
    }

    @Test
    public void test_exception_logging_when_error_occurs() {
        ConnectorRepository dao = mock(ConnectorRepository.class);
        KafkaService kafkaService = mock(KafkaService.class);
        CoreHrService coreHrService = new CoreHrService(dao, kafkaService);

        Timestamp fromDate = Timestamp.valueOf("2023-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2023-01-31 23:59:59");

        when(dao.getStateTransferAssociatesFromBigQuery(fromDate, toDate)).thenThrow(new RuntimeException(
                "Database error"));

        coreHrService.getStateTransferAssociateEventsAndSendMessageAsync(fromDate, toDate);

        verify(dao).getStateTransferAssociatesFromBigQuery(fromDate, toDate);

    }

    @Test
    public void testGetReHireAssociateEventsAndSendMessageAsync() {
        // Given
        Date fromDate = new Date(System.currentTimeMillis());
        Date toDate = new Date(System.currentTimeMillis() + 1000);
        List<AssociateEvent> associateEvents = new ArrayList<>();

        // When
        when(dao.getReHireAssociateEventsFromHr(fromDate, toDate)).thenReturn(associateEvents);
        coreHrService.getReHireAssociateEventsAndSendMessageAsync(fromDate, toDate);

        // Then
        verify(dao).getReHireAssociateEventsFromHr(fromDate, toDate);
    }

    @Test
    public void testGetReHireAssociateEventsAndSendMessageAsync_ExceptionThrown_ErrorLogged() {
        // Arrange
        Date fromDate = new Date(System.currentTimeMillis());
        Date toDate = new Date(System.currentTimeMillis() + 1000);

        // Mock the behavior of the dao.getReHireAssociateEventsFromHr method
        when(dao.getReHireAssociateEventsFromHr(fromDate, toDate)).thenThrow(new RuntimeException("Test exception"));

        // Act
        coreHrService.getReHireAssociateEventsAndSendMessageAsync(fromDate, toDate);

        // Assert
        verify(dao).getReHireAssociateEventsFromHr(fromDate, toDate);
    }

    @Test
    public void testGetTerminationAssociateEventsAndSendMessageAsync() {
        // Given
        var fromDateTs = Timestamp.valueOf(LocalDate.parse("2022-01-01").atStartOfDay());
        var toDateTs = Timestamp.valueOf(LocalDate.parse("2022-01-03").plusDays(1).atStartOfDay());
        List<AssociateEvent> associateEvents =
                getAssociateEvents(EventType.TERMINATION);

        // When
        when(dao.getTerminationAssociateEventsFromHr(fromDateTs, toDateTs)).thenReturn(associateEvents);

        //Act
        coreHrService.getTerminationAssociateEventsAndSendMessageAsync(fromDateTs,
                toDateTs);

        // Then
        verify(dao, times(1)).getTerminationAssociateEventsFromHr(fromDateTs, toDateTs);
        verify(kafkaService, times(1)).sendMessage(associateEvents);
    }

    @Test
    public void testGetTerminationAssociateEventsAndSendMessageAsync_ExceptionThrown_ErrorLogged() {
        // Arrange
        Timestamp fromDate = Timestamp.valueOf("2023-01-01 00:00:00");
        Timestamp toDate = Timestamp.valueOf("2023-01-31 23:59:59");

        // Mock the behavior of the dao.getTerminationAssociateEventsFromHr method
        when(dao.getTerminationAssociateEventsFromHr(fromDate, toDate)).thenThrow(new RuntimeException("Test exception"));

        // Act
        coreHrService.getTerminationAssociateEventsAndSendMessageAsync(fromDate, toDate);

        // Assert
        verify(dao).getTerminationAssociateEventsFromHr(fromDate, toDate);
    }

}
