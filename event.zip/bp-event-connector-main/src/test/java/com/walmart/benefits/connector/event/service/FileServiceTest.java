package com.walmart.benefits.connector.event.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class FileServiceTest {

    @InjectMocks
    private FileService fileService;

    @Test
    void testCheckIfFileExists_FileExists() throws IOException {
        // Arrange
        Path filePath = Files.createTempFile("test", null);
        String directory = filePath.getParent().toString();
        String fileName = filePath.getFileName().toString();

        // Act & Assert
        fileService.checkIfFileExists(directory, fileName);
    }

    @Test
    void testCheckIfFileExists_FileDoesNotExist() {
        // Arrange
        String directory = "non_existent_directory";
        String fileName = "non_existent_file.txt";

        // Act & Assert
        assertThrows(IOException.class, () -> {
            fileService.checkIfFileExists(directory, fileName);
        });
    }
}