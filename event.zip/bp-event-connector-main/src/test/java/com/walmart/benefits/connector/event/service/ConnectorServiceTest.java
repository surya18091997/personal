package com.walmart.benefits.connector.event.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.walmart.benefits.connector.event.common.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ConnectorServiceTest {

    @Mock
    private CoreHrService coreHrService;

    @InjectMocks
    private ConnectorService connectorService;

    @Mock
    private FileToEventsProcessorService fileToEventsProcessorService;

    /**
     * Test case for the `getNewHireHrEventDetailsAndSendMessage` method.
     *
     * This test verifies the behavior of the method when called with valid `fromDate` and `toDate` values.
     * It checks that the `coreHrService.getNewHireAssociateEventsAndSendMessageAsync` method is called
     * the correct number of times, and that the method returns the expected result.
     */
    @Test
    public void testGetNewHireHrEventDetailsAndSendMessage() {
        String fromDate = "2022-01-01";
        String toDate = "2022-01-03";
        LocalDate localFromDate = LocalDate.parse(fromDate, DateTimeFormatter.ISO_DATE);
        LocalDate localToDate = LocalDate.parse(toDate, DateTimeFormatter.ISO_DATE);

        // Call the method under test
        String result = connectorService.getNewHireHrEventDetailsAndSendMessage(fromDate, toDate);

        // Verify that the coreHrService.getNewHireAssociateEventsAndSendMessageAsync method is called the correct number of times
        verify(coreHrService, times(3)).getNewHireAssociateEventsAndSendMessageAsync(
                ArgumentMatchers.any(Date.class),
                ArgumentMatchers.any(Date.class));

        // Verify that the method returns the correct result
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
    }

    /**
     * Test case for the `getStateTransferEventDetailsAndSendMessage` method.
     *
     * This test verifies that the method returns the expected result when
     * called with valid `fromDate` and `toDate` values.
     *
     * @throws AssertionError if the expected result is not equal to the actual result
     */
    @Test
    public void testGetStateTransferEventDetailsAndSendMessage_ValidDates_Success() {
        // Arrange
        String fromDate = "2022-01-01";
        String toDate = "2022-01-15";
        String expectedResult = Constants.EVENT_CREATION_INITIATED;

        // Act
        String result = connectorService.getStateTransferEventDetailsAndSendMessage(fromDate, toDate);

        // Assert
        assertEquals(expectedResult, result);
    }

    /**
     * Test case for the `processRateChange401kFileAndSendMessage` method.
     *
     * This test verifies that the method returns the expected result and
     * that the `process401kRateChangeFileAndSendMessage` method of the
     * `fileToEventsProcessorService` is called once.
     */
    @Test
    public void testProcessRateChange401kFileAndSendMessage() {

        // Act
        String result = connectorService.processRateChange401kFileAndSendMessage();

        // Assert
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
        verify(fileToEventsProcessorService, times(1)).process401kRateChangeFileAndSendMessage();
    }

    @Test
    public void testProcessLoan401kUsFileAndSendMessage() {

        // Act
        String result = connectorService.processLoan401kUsFileAndSendMessage();

        // Assert
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
        verify(fileToEventsProcessorService, times(1)).processLoanUsFileAndSendMessage();
    }

    @Test
    public void testProcessLoan401kPrFileAndSendMessage() {

        // Act
        String result = connectorService.processLoan401kPrFileAndSendMessage();

        // Assert
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
        verify(fileToEventsProcessorService, times(1)).processLoanPrFileAndSendMessage();
    }
    @Test
    public void testProcessHardship401kUsFileAndSendMessage() {
        // Act
        String result = connectorService.processHardship401kUsFileAndSendMessage();

        // Assert
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
        verify(fileToEventsProcessorService, times(1)).processHardshipUsFileAndSendMessage();
    }

    @Test
    public void testProcessHardship401kPrFileAndSendMessage() {
        // Act
        String result = connectorService.processHardship401kPrFileAndSendMessage();

        // Assert
        assertEquals(Constants.EVENT_CREATION_INITIATED, result);
        verify(fileToEventsProcessorService, times(1)).processHardshipPrFileAndSendMessage();
    }

    @Test
    public void testGetReHireEventDetailsAndSendMessage_ValidDates_Success() {
        // Arrange
        String fromDate = "2022-01-01";
        String toDate = "2022-01-31";
        String expectedResult = Constants.EVENT_CREATION_INITIATED;

        // Act
        String result = connectorService.getReHireEventDetailsAndSendMessage(fromDate, toDate);

        // Assert
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTerminationEventDetailsAndSendMessage_ValidDates_Success() {
        // Arrange
        String fromDate = "2022-01-01";
        String toDate = "2022-01-15";
        String expectedResult = Constants.EVENT_CREATION_INITIATED;

        // Act
        String result =
                connectorService.getTerminationEventDetailsAndSendMessage(fromDate, toDate);

        // Assert
        assertEquals(expectedResult, result);
    }
}