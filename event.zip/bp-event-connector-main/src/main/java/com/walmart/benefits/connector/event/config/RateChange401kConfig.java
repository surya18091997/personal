package com.walmart.benefits.connector.event.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@PropertySource("classpath:ratechange401k.properties")
@ConfigurationProperties
@Validated
@Data
public class RateChange401kConfig {
    @NotNull
    private String rateChangeFileName;

    @NotNull
    private int planNumberStart;

    @NotNull
    private int planNumberEnd;

    @NotNull
    private int partNumberStart;

    @NotNull
    private int partNumberEnd;

    @NotNull
    private int creationDateStart;

    @NotNull
    private int creationDateEnd;

    @NotNull
    private int creationTimeStart;

    @NotNull
    private int creationTimeEnd;

    @NotNull
    private int transactionIdStart;

    @NotNull
    private int transactionIdEnd;

    @NotNull
    private int rateStart;

    @NotNull
    private int rateEnd;

    @NotNull
    private String mlRateCode401k;

    @NotNull
    private String usPlanNumber;

    @NotNull
    private String prPlanNumber;

    @NotNull
    private int rateWholeNumberStart;

    @NotNull
    private int rateWholeNumberEnd;

    @NotNull
    private int rateDecimalNumberStart;

    @NotNull
    private int rateDecimalNumberEnd;

    @NotNull
    private int timestampDeductionInHour;

    @NotNull
    private String mlRateCode401kRegular;

    @NotNull
    private String mlRateCode401kCatchUp;

    @NotNull
    private String mlRateCode401kRoth;

    @NotNull
    private String mlRateCode401kCatchUpRoth;

    @NotNull
    private String fileSharedPath;

    @NotNull
    private String fileArchivePath;
}