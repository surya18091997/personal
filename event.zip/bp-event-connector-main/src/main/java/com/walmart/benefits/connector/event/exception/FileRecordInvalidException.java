package com.walmart.benefits.connector.event.exception;

public class FileRecordInvalidException extends RuntimeException {

    public FileRecordInvalidException(String message) {
        super(message);
    }

    public FileRecordInvalidException(String message, Throwable cause) {
        super(message, cause);
    }

}
