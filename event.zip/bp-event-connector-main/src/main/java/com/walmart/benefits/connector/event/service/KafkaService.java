package com.walmart.benefits.connector.event.service;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class KafkaService {

    private final KafkaTemplate<String, AssociateEvent> kafkaTemplate;

    @Value("${kafka.events-queue.name}")
    private String TOPIC;

    @Value("${kafka.events-queue.partitions:3}")
    private String partitions;

    public KafkaService(KafkaTemplate<String, AssociateEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * This method used to send the message to the given topic asynchronously
     * @param event event message parameter
     */
    public void sendMessage(AssociateEvent event) {
        try{
            int partition =
                    getPartitionNumber(Integer.parseInt(event.getAssociateId()));
            this.kafkaTemplate.send(TOPIC, partition, null, event);
            log.debug("Message sent to topic {}", TOPIC);
        }
        catch(Exception e){
            log.error("Error in sending message to Topic {}, Error Message: {}", TOPIC, e.getMessage());
        }
    }

    /**
     * This method used to send the message to the given topic asynchronously
     * as batch
     * @param events List of event message parameter
     */
    public void sendMessage(List<AssociateEvent> events) {
        for(AssociateEvent event : events){
            int partition =
                    getPartitionNumber(Integer.parseInt(event.getAssociateId()));
            this.kafkaTemplate.send(TOPIC, partition, null, event);
        }
        Map<EventType, Long> eventTypeCounts = events.stream()
                .collect(Collectors.groupingBy(AssociateEvent::getEventType, Collectors.counting()));
        eventTypeCounts.forEach((type, count) ->
                log.info("{} Number of {} events sent to topic {}", count, type, TOPIC));
    }

    private int getPartitionNumber(int associateId) {
        return associateId % Integer.parseInt(partitions);
    }
}
