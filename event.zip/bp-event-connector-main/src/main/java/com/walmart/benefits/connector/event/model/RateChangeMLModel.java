package com.walmart.benefits.connector.event.model;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RateChangeMLModel {
    private String planNumber;
    private String partNumber;
    private String creationDate;
    private String creationTime;
    private String transactionId;
    private double rate = Constants.ZERO_DOUBLE;
}
