package com.walmart.benefits.connector.event.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.HashSet;
import java.util.List;

@AllArgsConstructor
@Data
public class RateChangeFileParseResult implements FileParseResult  {
    private List<RateChangeMLModel> rateChanges;
    private HashSet<String> nationalIdHashSet;
}
