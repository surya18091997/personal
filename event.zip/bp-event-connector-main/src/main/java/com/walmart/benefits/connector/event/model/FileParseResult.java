package com.walmart.benefits.connector.event.model;

import java.util.HashSet;

public interface FileParseResult {
    HashSet<String> getNationalIdHashSet();
}
