package com.walmart.benefits.connector.event.model;

import lombok.Data;

import java.util.Arrays;
import java.util.Map;

@Data
public class XmatterPayload {

    private String[] recipients;
    private Map<String,String> properties;

    @Override
    public String toString() {
        return "XmatterPayload [recipients=" + Arrays.toString(recipients)
                + ", properties=" + properties + "]";
    }

}