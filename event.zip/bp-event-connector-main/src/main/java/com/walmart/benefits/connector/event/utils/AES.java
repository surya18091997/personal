package com.walmart.benefits.connector.event.utils;

import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
@Slf4j
public class AES {

    private static final String AES_ALGORITHM = "AES";
    private static final String AES_PADDING = "AES/GCM/NoPadding";
    private static final int IV_SIZE = 12; // Recommended size for GCM IV
    private static final int TAG_LENGTH = 128; // Authentication tag length in bits

    private AES() {
    }

    public static byte[] encrypt(byte[] values, String secret){
        try {
            // Generate random IV
            byte[] iv = new byte[IV_SIZE];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(iv);

            // Create Cipher
            Cipher cipher = Cipher.getInstance(AES_PADDING);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);

            // Create SecretKey from the provided secret string
            SecretKey secretKey = new SecretKeySpec(secret.getBytes(), AES_ALGORITHM);

            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmParameterSpec);

            // Perform encryption
            byte[] encryptedData = cipher.doFinal(values);

            // Combine IV and encrypted data (IV needs to be sent with the ciphertext)
            byte[] encryptedWithIv = new byte[iv.length + encryptedData.length];
            System.arraycopy(iv, 0, encryptedWithIv, 0, iv.length);
            System.arraycopy(encryptedData, 0, encryptedWithIv, iv.length, encryptedData.length);

            return encryptedWithIv;
        } catch (Exception e) {
            log.error("Error while encrypting: {}", e.getMessage());
        }

        return new byte[0];
    }

    public static byte[] decrypt(byte[] values, String secret){
        try {
            // Extract IV from the input
            byte[] iv = new byte[IV_SIZE];
            System.arraycopy(values, 0, iv, 0, IV_SIZE);

            // Extract encrypted data
            byte[] encryptedData = new byte[values.length - IV_SIZE];
            System.arraycopy(values, IV_SIZE, encryptedData, 0, encryptedData.length);

            // Create Cipher
            Cipher cipher = Cipher.getInstance(AES_PADDING);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);

            // Create SecretKey from the provided secret string
            SecretKey secretKey = new SecretKeySpec(secret.getBytes(), AES_ALGORITHM);

            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmParameterSpec);

            // Perform decryption
            return cipher.doFinal(encryptedData);
        } catch (Exception e) {
            log.error("Error while decrypting: {}", e.getMessage());
        }

        return new byte[0];
    }
}