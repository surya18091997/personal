package com.walmart.benefits.connector.event.model;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RateChange {
    private String planNumber;
    private String transactionId;
    private double rateChanged = Constants.ZERO_DOUBLE;
}
