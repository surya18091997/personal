package com.walmart.benefits.connector.event.repository;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.model.StateChange;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.UUID;


@Component
public class AssociateStateTransferEventMapper implements RowMapper<AssociateEvent> {
    /**
     * This method is used to map the Sql result set to Associate Event model
     * @param rs the {@code ResultSet} to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return returns the AssociateEvent
     * @throws SQLException throws SQL Exception
     * @throws EmptyResultDataAccessException throws Empty Result Data Access
     * Exception
     */
    public AssociateEvent mapRow(ResultSet rs, int rowNum) throws SQLException, EmptyResultDataAccessException {

        var event = new AssociateEvent();
        event.setAssociateId(rs.getString(Constants.WIN_NBR_COLUMN));
        event.setId(UUID.randomUUID());
        event.setOrigin(EventOrigin.CORE_HR);
        event.setTimeStamp(Instant.now().toString());
        event.setEventType(EventType.STATE_TRANSFER);
        event.setAdditionalInfo(getChangedState(rs));

        return event;
    }

    private StateChange getChangedState(ResultSet rs)  throws SQLException, EmptyResultDataAccessException {
        return StateChange.builder()
                .stateStoreProvCd(rs.getString(Constants.STATE_CODE_COLUMN))
                .prevStateStoreProvCd(rs.getString(Constants.PREVIOUS_STATE_CODE_COLUMN))
                .hireDate(rs.getString(Constants.HIRE_DATE_COLUMN))
                .build();
    }
}
