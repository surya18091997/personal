package com.walmart.benefits.connector.event.config;

import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@Validated
@Data
public class LoanConfig {

    @NotNull
    private int ssnStart;

    @NotNull
    private int ssnEnd;

    @NotNull
    private int empNumberStart;

    @NotNull
    private int empNumberEnd;

    @NotNull
    private int loanNumberStart;

    @NotNull
    private int loanNumberEnd;

    @NotNull
    private int loanDedAmountWholeStart;

    @NotNull
    private int loanDedAmountWholeEnd;

    @NotNull
    private int loanDedAmountDecimalStart;

    @NotNull
    private int loanDedAmountDecimalEnd;

    @NotNull
    private int loanTypeStart;

    @NotNull
    private int loanTypeEnd;

    @NotNull
    private int payrollIdStart;

    @NotNull
    private int payrollIdEnd;

    @NotNull
    private int goalAmountWholeStart;

    @NotNull
    private int goalAmountWholeEnd;

    @NotNull
    private int goalAmountDecimalStart;

    @NotNull
    private int goalAmountDecimalEnd;

    @NotNull
    private int payrollFrequencyStart;

    @NotNull
    private int payrollFrequencyEnd;

    @NotNull
    private int storeLocationCodeStart;

    @NotNull
    private int storeLocationCodeEnd;

    @NotNull
    private int countryCodeStart;

    @NotNull
    private int countryCodeEnd;

    @NotNull
    private String loanFileSharedPath;

    @NotNull
    private String loanFileArchivePath;
}