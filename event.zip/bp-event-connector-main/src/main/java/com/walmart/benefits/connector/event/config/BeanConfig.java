package com.walmart.benefits.connector.event.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;

import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.NeverRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.util.HashMap;
import java.util.Map;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.exception.FileRecordInvalidException;
import com.walmart.benefits.connector.event.exception.FileReaderException;
import com.walmart.benefits.connector.event.exception.FileParserException;

@Configuration
public class BeanConfig {

    /**
     * Configure a RetryTemplate with a backoff of 2 seconds and a maximum of 3 retries,
     * excluding retries for ResourceNotFoundException and ResourceAlreadyExistsException.
     * @return RetryTemplate
     */
    @Bean
    public RetryTemplate retryTemplate(LoggingRetryListener loggingRetryListener) {
        RetryTemplate retryTemplate = new RetryTemplate();

        // Configure exponential backoff policy
        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(Constants.RETRY_BACKOFF_PERIOD_MS); // initial backoff
        backOffPolicy.setMultiplier(Constants.RETRY_BACKOFF_MULTIPLIER); // exponential factor
        backOffPolicy.setMaxInterval(Constants.RETRY_BACKOFF_PERIOD_MS * Constants.RETRY_BACKOFF_MAX_FACTOR); // cap max backoff
        retryTemplate.setBackOffPolicy(backOffPolicy);

        // Configure retry policy for only transient exceptions (most specific first)
        ExceptionClassifierRetryPolicy retryPolicy = new ExceptionClassifierRetryPolicy();
        Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<>();
        // Most specific transient exceptions first
        policyMap.put(org.springframework.jdbc.CannotGetJdbcConnectionException.class, new SimpleRetryPolicy(Constants.RETRY_MAX_ATTEMPTS));
        policyMap.put(java.sql.SQLTransientException.class, new SimpleRetryPolicy(Constants.RETRY_MAX_ATTEMPTS));
        policyMap.put(java.sql.SQLException.class, new SimpleRetryPolicy(Constants.RETRY_MAX_ATTEMPTS));
        // Never retry on business exceptions
        policyMap.put(FileRecordInvalidException.class, new NeverRetryPolicy());
        policyMap.put(FileReaderException.class, new NeverRetryPolicy());
        policyMap.put(FileParserException.class, new NeverRetryPolicy());
        policyMap.put(NullPointerException.class, new NeverRetryPolicy());
        policyMap.put(IllegalArgumentException.class, new NeverRetryPolicy());
        // Fallback: never retry on all other exceptions
        policyMap.put(Exception.class, new NeverRetryPolicy());
        retryPolicy.setPolicyMap(policyMap);

        retryTemplate.setRetryPolicy(retryPolicy);

        // Register the logging listener
        retryTemplate.registerListener(loggingRetryListener);

        return retryTemplate;
    }
}