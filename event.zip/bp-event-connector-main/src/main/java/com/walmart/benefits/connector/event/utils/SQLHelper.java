package com.walmart.benefits.connector.event.utils;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@PropertySource("classpath:sql.properties")
@ConfigurationProperties
@Validated
@Data
public class SQLHelper {
    @NotNull
    private String newHireAssociateEventQuery ;

    @NotNull
    private String newHireBackDatedEventQuery;

    @NotNull
    private String stateTransferAssociateEventQuery;

    @NotNull
    private String nationalIdMappingQuery;

    @NotNull
    private String reHireAssociateEventQuery;

    @NotNull
    private String terminationAssociateEventQuery;

    @NotNull
    private String stateTransferBgQuery;
}
