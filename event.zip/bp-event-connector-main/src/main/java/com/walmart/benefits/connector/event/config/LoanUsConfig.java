package com.walmart.benefits.connector.event.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@PropertySource("classpath:loan401kUs.properties")
@ConfigurationProperties(prefix = "loan-us")
@Validated
@Data
public class LoanUsConfig extends LoanConfig {
    @NotNull
    private String loanUsFileName;
}