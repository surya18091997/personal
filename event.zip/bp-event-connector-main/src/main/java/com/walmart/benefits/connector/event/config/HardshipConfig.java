package com.walmart.benefits.connector.event.config;

import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@Validated
@Data
public class HardshipConfig {
    @NotNull
    private int recordTypeStart;

    @NotNull
    private int recordTypeEnd;

    @NotNull
    private int ssnStart;
    @NotNull
    private int ssnEnd;

    @NotNull
    private int merMatchEligDateStart;
    @NotNull
    private int merMatchEligDateEnd;

    @NotNull
    private int merMatchEligIndStart;
    @NotNull
    private int merMatchEligIndEnd;

    @NotNull
    private int merStartCentStart;
    @NotNull
    private int merStartCentEnd;
    @NotNull
    private int merStartYyStart;
    @NotNull
    private int merStartYyEnd;
    @NotNull
    private int merStartMmStart;
    @NotNull
    private int merStartMmEnd;
    @NotNull
    private int merStartDdStart;
    @NotNull
    private int merStartDdEnd;

    @NotNull
    private int merResumeCentStart;
    @NotNull
    private int merResumeCentEnd;
    @NotNull
    private int merResumeYyStart;
    @NotNull
    private int merResumeYyEnd;
    @NotNull
    private int merResumeMmStart;
    @NotNull
    private int merResumeMmEnd;
    @NotNull
    private int merResumeDdStart;
    @NotNull
    private int merResumeDdEnd;

    @NotNull
    private String hardshipFileSharedPath;
    @NotNull
    private String hardshipFileArchivePath;

}
