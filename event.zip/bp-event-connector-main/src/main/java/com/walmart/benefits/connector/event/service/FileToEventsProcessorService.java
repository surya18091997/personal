package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.config.*;
import com.walmart.benefits.connector.event.exception.FileReaderException;
import com.walmart.benefits.connector.event.exception.FileRecordInvalidException;
import com.walmart.benefits.connector.event.model.*;
import com.walmart.benefits.connector.event.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;

@Slf4j
@Service
public class FileToEventsProcessorService {

    private final ConnectorRepository dao;
    private final FileParserService fileParserService;
    private final KafkaService kafkaService;
    private final RateChange401kConfig rateChange401kConfig;
    private final LoanPrConfig loanPrConfig;
    private final LoanUsConfig loanUsConfig;
    private final FileService fileService;
    private final HardshipUsConfig hardshipUsConfig;
    private final HardshipPrConfig hardshipPrConfig;
    private final EventType eventType;


    public FileToEventsProcessorService(ConnectorRepository dao,
                                        FileParserService fileParserService,
                                        KafkaService kafkaService,
                                        RateChange401kConfig rateChange401kConfig, LoanPrConfig loanPrConfig, LoanUsConfig loanUsConfig, HardshipUsConfig hardshipUsConfig, FileService fileService, HardshipPrConfig hardshipPrConfig, EventType eventType) {
        this.dao = dao;
        this.fileParserService = fileParserService;
        this.kafkaService = kafkaService;
        this.rateChange401kConfig = rateChange401kConfig;
        this.loanPrConfig = loanPrConfig;
        this.loanUsConfig = loanUsConfig;
        this.fileService = fileService;
        this.hardshipUsConfig = hardshipUsConfig;
        this.hardshipPrConfig = hardshipPrConfig;
        this.eventType = eventType;
    }


    /**
     * Processes a Rate Change 401K file and sends its contents as messages to
     * Kafka.
     */
    @Async("asyncTaskExecutor")
    public void process401kRateChangeFileAndSendMessage() {
        log.info("File processing started for the Rate Change 401K file");
        processFileAndSendMessage(rateChange401kConfig.getFileSharedPath(),
                rateChange401kConfig.getRateChangeFileName(),
                rateChange401kConfig.getFileArchivePath(),
                path -> fileParserService.parseRateChange401KFile(path,
                        rateChange401kConfig), false);
    }

    /**
     * Processes a Loan US 401K file and sends its contents as messages to
     * Kafka.
     */
    @Async("asyncTaskExecutor")
    public void processLoanUsFileAndSendMessage() {
        log.info("File processing started for the Loan US 401K file");
        processFileAndSendMessage(loanUsConfig.getLoanFileSharedPath(),
                loanUsConfig.getLoanUsFileName(),
                loanUsConfig.getLoanFileArchivePath(),
                path -> fileParserService.parseLoan401kFile(path,
                        loanUsConfig), true);
    }

    /**
     * Processes a Loan PR 401K file and sends its contents as messages to
     * Kafka.
     */
    @Async("asyncTaskExecutor")
    public void processLoanPrFileAndSendMessage() {
        log.info("File processing started for the Loan PR 401K file");
        processFileAndSendMessage(loanPrConfig.getLoanFileSharedPath(),
                loanPrConfig.getLoanPrFileName(),
                loanPrConfig.getLoanFileArchivePath(),
                path -> fileParserService.parseLoan401kFile(path,
                        loanPrConfig), false);
    }

    @Async("asyncTaskExecutor")
    public void processHardshipUsFileAndSendMessage() {
        log.info("File processing started for the Hardship US 401K file");
        processFileAndSendMessage(hardshipUsConfig.getHardshipFileSharedPath(),
                hardshipUsConfig.getHardshipUsFileName(),
                hardshipUsConfig.getHardshipFileArchivePath(),
                path -> fileParserService.parseHardship401kFile(path, hardshipUsConfig), true);//bool variable is if it is US or not
    }

    @Async("asyncTaskExecutor")
    public void processHardshipPrFileAndSendMessage() {
        log.info("File processing started for the Hardship PR 401K file");
        processFileAndSendMessage(hardshipPrConfig.getHardshipFileSharedPath(),
                hardshipPrConfig.getHardshipPrFileName(),
                hardshipPrConfig.getHardshipFileArchivePath(),
                path -> fileParserService.parseHardship401kFile(path, hardshipPrConfig), false);//bool variable is if it is US or not
    }

    private void processFileAndSendMessage(String filePath, String fileName,
                                           String archivePath, Function<Path,
                    FileParseResult> parseFunction, boolean isLoanUs) {
        Path path = Paths.get(filePath, fileName);

        try {
            fileService.checkIfFileExists(filePath, fileName);
        } catch (IOException e) {
            log.error("Error reading the file - {}, from the file path - {}. " +
                    "All retries exhausted.", fileName, filePath);
            throw new FileReaderException(e.getMessage());
        }

        log.info("File - {}, available on the path - {}. Processing the file" +
                "..", fileName, filePath);
        var fileParseResult = parseFunction.apply(path);
        var winIdSsnMap = getSsnAndWinMappings(fileParseResult.getNationalIdHashSet());
        sendMessage(getAssociateEvents(fileParseResult, isLoanUs, winIdSsnMap));

        log.info("File processed successfully: {}. Moving the file to Archive" +
                " path", path);
        moveFileToArchivePath(path, archivePath, fileName);
    }


    private void moveFileToArchivePath(Path filePath, String archivePath,
                                       String fileName) {
        try {
            var archivalPath = Paths.get(archivePath,
                    fileName
                            + Constants.HYPHEN
                            + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constants.DATE_FORMAT))
                            + Constants.ARCHIVE_FILE_SUFFIX);
            Files.move(filePath, archivalPath,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            log.error("Error while moving file: {} to archival path",
                    ex.getMessage());
        }
    }

    private void sendMessage(List<AssociateEvent> associateEvents) {
        log.info("Kafka message initiated count - {}",
                (long) associateEvents.size());
        this.kafkaService.sendMessage(associateEvents);
    }

    private Map<String, String> getSsnAndWinMappings(HashSet<String> ssnHashSet) {
        Map<String, String> ssnWinMap = new HashMap<>();
        var ssnList = ssnHashSet.stream().toList();
        for (int i = 0; i < ssnList.size(); i += Constants.SQL_BATCH_SIZE) {
            ssnWinMap.putAll(dao.getAssociateIdListFromSsnList(ssnList.subList(i, Math.min(i + Constants.SQL_BATCH_SIZE, ssnList.size()))));
        }

        return ssnWinMap;
    }


    private List<AssociateEvent> getAssociateEvents(FileParseResult fileParseResult, boolean isLoanUs, Map<String, String> ssnWinIdMap) {
        if (fileParseResult instanceof RateChangeFileParseResult rateChangeResult) {
            return getAssociateEventsFromRateChanges(rateChangeResult.getRateChanges(), ssnWinIdMap);
        } else if (fileParseResult instanceof LoanFileParseResult loanResult) {
            return getAssociateEventsFromLoanData(loanResult.getLoanBnfts(),
                    isLoanUs, ssnWinIdMap);
        } else if(fileParseResult instanceof HardshipFileParseResult hardshipResult) {
            return getAssociateEventsFromHardshipData(hardshipResult.getHardships(),isLoanUs,ssnWinIdMap);
        }
        else {
            throw new IllegalArgumentException("Unsupported FileParseResult " +
                    "type");
        }
    }

    private List<AssociateEvent> getAssociateEventsFromRateChanges(List<RateChangeMLModel> rateChanges, Map<String, String> ssnWinIdMap) {
        List<AssociateEvent> events = new ArrayList<>();
        List<RateChangeMLModel> erroredRecords = new ArrayList<>();
        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern(Constants.DATE_FORMAT);
        DateTimeFormatter utcFormatter =
                DateTimeFormatter.ofPattern(Constants.UTC_DATE_FORMAT);
        ZoneId estZone = ZoneId.of(Constants.ZONE_EST);
        rateChanges.forEach(rateChange -> {
            try {
                AssociateEvent event = new AssociateEvent();
                event.setId(UUID.randomUUID());
                event.setAssociateId(ssnWinIdMap.get(rateChange.getPartNumber()));
                event.setEventType(EventType.RATE_CHANGE);
                event.setOrigin(EventOrigin.ML);
                var dateStringInEST =
                        rateChange.getCreationDate() + rateChange.getCreationTime();
                LocalDateTime localDateTime =
                        LocalDateTime.parse(dateStringInEST, formatter);
                // Convert LocalDateTime to EST ZonedDateTime
                ZonedDateTime estZonedDateTime = localDateTime.atZone(estZone);
                // Convert to UTC
                ZonedDateTime utcZonedDateTime =
                        estZonedDateTime.withZoneSameInstant(ZoneId.of(Constants.ZONE_UTC));
                var utcTimestamp = utcZonedDateTime.format(utcFormatter);

                event.setTimeStamp(utcTimestamp);
                event.setPlanType(getPlanTypeForRateChange401k(rateChange.getTransactionId(),
                        rateChange.getPlanNumber()));
                event.setAdditionalInfo(RateChange.builder()
                        .planNumber(rateChange.getPlanNumber())
                        .transactionId(rateChange.getTransactionId())
                        .rateChanged(rateChange.getRate()).build());
                events.add(event);
            } catch (Exception e) {
                // ignore the error record and add to the errored records list
                log.debug("Parsing error on rate change record: {}",
                        e.getMessage());
                erroredRecords.add(rateChange);
            }
        });

        logErroredRecords(rateChanges.size(), erroredRecords.size(),
                Constants.RATE_CHANGE);
        return events;
    }

    private PlanType getPlanTypeForRateChange401k(String rateCode,
                                                  String planNumber) {
        if (rateCode.equals(rateChange401kConfig.getMlRateCode401kRegular())) {
            return planNumber.equals(rateChange401kConfig.getUsPlanNumber())
                    ? PlanType.RETIREMENT_401K_REGULAR_US :
                    PlanType.RETIREMENT_401K_REGULAR_PR;
        } else if (rateCode.equals(rateChange401kConfig.getMlRateCode401kCatchUp())) {
            return planNumber.equals(rateChange401kConfig.getUsPlanNumber())
                    ? PlanType.RETIREMENT_401K_CATCHUP_REGULAR_US :
                    PlanType.RETIREMENT_401K_CATCHUP_REGULAR_PR;
        } else if (rateCode.equals(rateChange401kConfig.getMlRateCode401kRoth())) {
            return planNumber.equals(rateChange401kConfig.getUsPlanNumber())
                    ? PlanType.RETIREMENT_401K_ROTH_US : PlanType.NONE;
        } else if (rateCode.equals(rateChange401kConfig.getMlRateCode401kCatchUpRoth())) {
            return planNumber.equals(rateChange401kConfig.getUsPlanNumber())
                    ? PlanType.RETIREMENT_401K_CATCHUP_ROTH_US : PlanType.NONE;
        } else {
            return PlanType.NONE;
        }
    }

    private List<AssociateEvent> getAssociateEventsFromLoanData(List<LoanModelFromML> loanModelFromMLList, boolean isLoanUs, Map<String, String> ssnWinIdMap) {
        List<AssociateEvent> events = new ArrayList<>();
        var currentTimeStampUTC = Instant.now().toString();
        List<LoanModelFromML> erroredRecords = new ArrayList<>();

        loanModelFromMLList.forEach(loanModelFromML -> processLoanModel(loanModelFromML, isLoanUs, ssnWinIdMap, currentTimeStampUTC, events, erroredRecords));

        logErroredRecords(loanModelFromMLList.size(), erroredRecords.size(), Constants.LOAN);
        return events;
    }

    private List<AssociateEvent> getAssociateEventsFromHardshipData(List<HardshipModelFromML> hardshipModelFromMLList, boolean isUs, Map<String, String> ssnWinIdMap) {
        List<AssociateEvent> events = new ArrayList<>();
        var currentTimeStampUTC = Instant.now().toString();
        List<HardshipModelFromML> erroredRecords = new ArrayList<>();

        hardshipModelFromMLList.forEach(hardshipModelFromML -> processHardshipModel(hardshipModelFromML, isUs, ssnWinIdMap, currentTimeStampUTC, events, erroredRecords));

        logErroredRecords(hardshipModelFromMLList.size(), erroredRecords.size(), Constants.HARDSHIP);
        return events;
    }

    private void processLoanModel(LoanModelFromML loanModelFromML, boolean isLoanUs, Map<String, String> ssnWinIdMap, String currentTimeStampUTC, List<AssociateEvent> events, List<LoanModelFromML> erroredRecords) {
        try {
            AssociateEvent event = createAssociateEvent(loanModelFromML, isLoanUs, currentTimeStampUTC);
            events.add(event);
        } catch (Exception e) {
            // ignore the error record and add to the errored records list
            log.debug("Parsing error on LOAN record: {}", e.getMessage());
            erroredRecords.add(loanModelFromML);
        }
    }
    private void processHardshipModel(HardshipModelFromML hardshipModelFromML, boolean isUs, Map<String, String> ssnWinIdMap, String currentTimeStampUTC, List<AssociateEvent> events, List<HardshipModelFromML> erroredRecords) {
        try {
            validateSsnWinId(ssnWinIdMap, hardshipModelFromML);
            AssociateEvent event = createAssociateEvent(hardshipModelFromML, isUs, currentTimeStampUTC,ssnWinIdMap);
            events.add(event);
        }
        catch (Exception e) {
            // ignore the error record and add to the errored records list
            log.info("Parsing error on hardship record: {}", e.getMessage());
            erroredRecords.add(hardshipModelFromML);
        }
    }

    private void validateSsnWinId(Map<String, String> ssnWinIdMap, LoanModelFromML loanModelFromML) throws FileRecordInvalidException {
        if (!ssnWinIdMap.get(loanModelFromML.getSsnId()).equals(loanModelFromML.getEmpNumber())) {
//            throw new FileRecordInvalidException("Associate Win number not matching with SSN on " +
//                    "the ML Loan File.");
            log.warn("Associate Win number not matching with SSN on " +
                    "the ML Loan File.");
        }
    }

    private void validateSsnWinId(Map<String, String> ssnWinIdMap, HardshipModelFromML hardshipModelFromML) throws FileRecordInvalidException {
        if(ssnWinIdMap.get(hardshipModelFromML.getSsnId()) == null) {
            throw new FileRecordInvalidException("Associate Win number is not present for this SSN in ML Hardship File.Skipping this record.");
        }
        if (ssnWinIdMap.get(hardshipModelFromML.getSsnId()).equals("999999999")) {
            throw new FileRecordInvalidException("Bad win number in " +
                    "the ML Hardship File.");
        }
        if(ssnWinIdMap.get(hardshipModelFromML.getSsnId()).equals("0")){
            throw new FileRecordInvalidException("Bad Win Number.Skipping this record");
        }
    }

    private AssociateEvent createAssociateEvent(LoanModelFromML loanModelFromML, boolean isLoanUs, String currentTimeStampUTC) {
        AssociateEvent event = new AssociateEvent();
        event.setId(UUID.randomUUID());
        event.setAssociateId(loanModelFromML.getEmpNumber());
        event.setEventType(EventType.LOAN);
        event.setOrigin(EventOrigin.ML);
        event.setTimeStamp(currentTimeStampUTC);
        event.setPlanType(determinePlanType(loanModelFromML, isLoanUs));
        event.setAdditionalInfo(createLoanModel(loanModelFromML, isLoanUs));
        return event;
    }

    private AssociateEvent createAssociateEvent(HardshipModelFromML hardshipModelFromML, boolean isLoanUs, String currentTimeStampUTC,Map<String, String> ssnWinIdMap) {
        AssociateEvent event = new AssociateEvent();
        event.setId(UUID.randomUUID());
        event.setAssociateId(ssnWinIdMap.get(hardshipModelFromML.getSsnId()));//Getting it from win ID SSN MAP
        if(hardshipModelFromML.getRecordType().equals(Constants.TYPE_50)){
            event.setPlanType(determinePlanType(isLoanUs));
            event.setEventType(EventType.HARDSHIP);
        }
        else{
            event.setEventType(EventType.MATCH_ELIGIBILITY);
            event.setPlanType(PlanType.NONE);
        }
        event.setOrigin(EventOrigin.ML);
        event.setTimeStamp(currentTimeStampUTC);
        event.setAdditionalInfo(createHardshipModel(hardshipModelFromML,isLoanUs));
        return event;
    }

    private PlanType determinePlanType(LoanModelFromML loanModelFromML, boolean isLoanUs) {
        if (isLoanUs) {
            return loanModelFromML.getLoanType().equals(Constants.LOAN_GENERAL) ? PlanType.RETIREMENT_401K_LOAN_GENERAL_US : PlanType.RETIREMENT_401K_LOAN_RESIDENTIAL_US;
        } else {
            return loanModelFromML.getLoanType().equals(Constants.LOAN_GENERAL) ? PlanType.RETIREMENT_401K_LOAN_GENERAL_PR : PlanType.RETIREMENT_401K_LOAN_RESIDENTIAL_PR;
        }
    }
    private PlanType determinePlanType(boolean isUs) {
        if(isUs){
            return PlanType.RETIREMENT_401K_HARDSHIP_US;
        }
        return PlanType.RETIREMENT_401K_HARDSHIP_PR;
    }

    private LoanModel createLoanModel(LoanModelFromML loanModelFromML, boolean isLoanUs) {
        return LoanModel.builder()
                .ssnId(loanModelFromML.getSsnId())
                .loanNumber(loanModelFromML.getLoanNumber())
                .deductionAmount(loanModelFromML.getDeductionAmount())
                .loanType(loanModelFromML.getLoanType())
                .payrollId(loanModelFromML.getPayrollId())
                .goalAmount(loanModelFromML.getGoalAmount())
                .payrollFrequency(loanModelFromML.getPayrollFrequency())
                .storeLocationCode(loanModelFromML.getStoreLocationCode())
                .countryCode(isLoanUs ? Constants.US : Constants.PR)
                .build();
    }
    private HardshipModel createHardshipModel(HardshipModelFromML hardshipModelFromML,boolean isUs) {
        String recordType = hardshipModelFromML.getRecordType();
        String ssnId = hardshipModelFromML.getSsnId();

        if (Constants.TYPE_10.equals(recordType)) {
            return HardshipModelType10.builder()
                    .recordType(recordType)
                    .ssnId(ssnId)
                    .merMatchEligDate(hardshipModelFromML.getMerMatchEligDate())
                    .merMatchEligInd(hardshipModelFromML.getMerMatchEligInd())
                    .countryCode(isUs ? Constants.US : Constants.PR)
                    .build();
        } else if (Constants.TYPE_50.equals(recordType)) {
            return HardshipModelType50.builder()
                    .recordType(recordType)
                    .ssnId(ssnId)
                    .startDate(hardshipModelFromML.getStartDate())
                    .resumeDate(hardshipModelFromML.getResumeDate())
                    .build();
        } else {
            throw new IllegalArgumentException("Unsupported record type: " + recordType);
        }
    }

    private void logErroredRecords(int totalRecords, int erroredRecords,
                                   String fileType) {
        log.info("Total Records came from ML for {} : {}, Errored " +
                "Records: {}", fileType, totalRecords, erroredRecords);
        if (erroredRecords > 0) {
            var errorMessage =
                    String.format(Constants.ERROR_RECORDS_AVAILABLE,
                            erroredRecords, fileType);
            log.warn(errorMessage);
        }
    }

}