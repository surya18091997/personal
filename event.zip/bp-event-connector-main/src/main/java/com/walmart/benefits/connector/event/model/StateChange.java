package com.walmart.benefits.connector.event.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StateChange {
    private String stateStoreProvCd = "";
    private String prevStateStoreProvCd = "";
    private String hireDate = "";
}
