package com.walmart.benefits.connector.event.model;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HardshipModelFromML {
    private String recordType;
    private String ssnId;
    private String merMatchEligDate;
    private String merMatchEligInd;
    private String startDate;
    private String resumeDate;
}
