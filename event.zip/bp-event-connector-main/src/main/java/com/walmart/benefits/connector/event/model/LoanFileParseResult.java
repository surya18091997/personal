package com.walmart.benefits.connector.event.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.HashSet;
import java.util.List;

@AllArgsConstructor
@Data
public class LoanFileParseResult implements FileParseResult {
    private List<LoanModelFromML> loanBnfts;
    private HashSet<String> nationalIdHashSet;
}
