package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.config.HardshipConfig;
import com.walmart.benefits.connector.event.config.LoanConfig;
import com.walmart.benefits.connector.event.config.RateChange401kConfig;
import com.walmart.benefits.connector.event.exception.FileParserException;
import com.walmart.benefits.connector.event.model.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Stream;

import static com.walmart.benefits.connector.event.common.Constants.*;

@Slf4j
@AllArgsConstructor
@Service
public class FileParserService {

    /**
     * Parses a file containing rate change information for a 401K plan.
     *
     * @param filePath the path of the file to be parsed
     * @param rateChange401kConfig the rate change configurations
     * @return a rate change parse result
     */
    public RateChangeFileParseResult parseRateChange401KFile(Path filePath,
                                                             RateChange401kConfig rateChange401kConfig) {
        List<RateChangeMLModel> rateChanges = new ArrayList<>();
        HashSet<String> ssnHashSet = new HashSet<>();
        var mlRateCodes =
                Arrays.stream(rateChange401kConfig.getMlRateCode401k().split(
                        ",")).toList();

        try (BufferedReader reader = Files.newBufferedReader(filePath,
                StandardCharsets.ISO_8859_1);
             Stream<String> lines = reader.lines()) {

            lines.forEach(line -> {
                try {
                    var rateChange = parseLine(line, mlRateCodes, rateChange401kConfig);
                    if (rateChange != null) {
                        ssnHashSet.add(rateChange.getPartNumber());
                        rateChanges.add(rateChange);
                    }

                } catch (Exception e) {
                    // Log the error as warning and proceed to the next row
                    // of the file.
                    log.warn("Error parsing the line in the rate change " +
                                    "401k file:" +
                                    " {}, error: {}",
                            filePath, e.getMessage());
                }
            });
        } catch (IOException e) {
            log.error("Error reading the rate change 401k file: {}", filePath);
            throw new FileParserException(e.getMessage());
        }

        return new RateChangeFileParseResult(rateChanges, ssnHashSet);
    }

    /**
     * Parses a file containing loan information for a 401K plan.
     *
     * @param filePath   the path of the file to be parsed
     * @param loanConfig the configuration for the loan
     * @return a Loan File Parse result
     */
    public LoanFileParseResult parseLoan401kFile(Path filePath,
                                                 LoanConfig loanConfig) {
        List<LoanModelFromML> loanModelFromMlList = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath,
                StandardCharsets.ISO_8859_1);
             Stream<String> lines = reader.lines()) {
            lines.forEach(line -> {
                try {
                    var loanModelFromML = parseLoanLine(line, loanConfig);
                    if (loanModelFromML != null) {
                        loanModelFromMlList.add(loanModelFromML);
                    }
                } catch (Exception e) {
                    log.warn("Error parsing the line in the loan 401k file: " +
                                    "{}, error: {}",
                            filePath, e.getMessage());
                }
            });
        } catch (IOException e) {
            log.error("Error reading the loan 401k file: {}", filePath);
            throw new FileParserException(e.getMessage());
        }

        return new LoanFileParseResult(loanModelFromMlList, new HashSet<>());
    }

    /**
     * Parses a file containing hardship information for a 401K plan.
     *
     * @param filePath   the path of the file to be parsed
     * @param hardshipConfig the configuration for the hardship
     * @return a Hardship File Parse result
     */
    public HardshipFileParseResult parseHardship401kFile(Path filePath,
                                                         HardshipConfig hardshipConfig) {
        List<HardshipModelFromML> hardshipModelFromMlList = new ArrayList<>();
        HashSet<String> ssnHashSet = new HashSet<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath,
                StandardCharsets.ISO_8859_1);
             Stream<String> lines = reader.lines()) {
            lines.forEach(line -> {
                try {
                    var hardshipModelFromML = parseHardshipLine(line, hardshipConfig);
                    if (hardshipModelFromML != null) {
                        ssnHashSet.add(hardshipModelFromML.getSsnId());
                        hardshipModelFromMlList.add(hardshipModelFromML);
                    }
                } catch (Exception e) {
                    log.warn("Error parsing the line in the hardship 401k file: " +
                                    "{}, error: {}",
                            filePath, e.getMessage());
                }
            });
        } catch (IOException e) {
            log.error("Error reading the hardship 401k file: {}", filePath);
            throw new FileParserException(e.getMessage());
        }

        return new HardshipFileParseResult(hardshipModelFromMlList, ssnHashSet);
    }

    private HardshipModelFromML parseHardshipLine(String line, HardshipConfig config) {
        HardshipModelFromML hardshipModelFromML = new HardshipModelFromML();
        var fileHeaderOrTrailer =
                line.substring(Constants.FILE_HEADER_TRAILER_START,
                        Constants.FILE_HEADER_TRAILER_END);
        if (fileHeaderOrTrailer.equalsIgnoreCase(Constants.FILE_HEADER) ||
                fileHeaderOrTrailer.equalsIgnoreCase(Constants.FILE_TRAILER)) {
            return null;
        }

        String recordType = line.substring(config.getRecordTypeStart(),
                config.getRecordTypeEnd()).trim();
        if(!recordType.equalsIgnoreCase(Constants.TYPE_10) && !recordType.equalsIgnoreCase(Constants.TYPE_50)) {
            return null;
        }
        hardshipModelFromML.setRecordType(recordType);
        hardshipModelFromML.setSsnId(line.substring(config.getSsnStart(),
                config.getSsnEnd()).trim());

        if(recordType.equalsIgnoreCase(Constants.TYPE_10)) {
            String merMatchEligDate = line.substring(
                    config.getMerMatchEligDateStart(),
                    config.getMerMatchEligDateEnd()).trim();
            String merMatchEligInd = line.substring(
                    config.getMerMatchEligIndStart(),
                    config.getMerMatchEligIndEnd()).trim();
            if(merMatchEligInd.isEmpty() && merMatchEligDate.isEmpty()) {
                return null;
            }
            if (merMatchEligInd.isEmpty()) {
                merMatchEligInd = NOT_MATCH_ELIGIBLE;
            } else if (merMatchEligDate.isEmpty() && MATCH_ELIGIBLE.equals(merMatchEligInd)) {
                merMatchEligInd = NOT_MATCH_ELIGIBLE;
            }
            if (merMatchEligDate.isEmpty()) {
                merMatchEligDate = MATCH_ELIGIBLE_DATE_DEFAULT;
            } else {
                if (merMatchEligDate.length() == 8) {
                    merMatchEligDate = merMatchEligDate.substring(0, 4) + "-" +
                            merMatchEligDate.substring(4, 6) + "-" +
                            merMatchEligDate.substring(6, 8);
                }
            }
            hardshipModelFromML.setMerMatchEligDate(merMatchEligDate);
            hardshipModelFromML.setMerMatchEligInd(merMatchEligInd);
        }

        else {
            String startCent = line.substring(config.getMerStartCentStart(), config.getMerStartCentEnd()).trim();
            String startYy = line.substring(config.getMerStartYyStart(), config.getMerStartYyEnd()).trim();
            String startMm = line.substring(config.getMerStartMmStart(), config.getMerStartMmEnd()).trim();
            String startDd = line.substring(config.getMerStartDdStart(), config.getMerStartDdEnd()).trim();
            String rawStartDate = startCent + startYy + startMm + startDd;

            if (rawStartDate.length() == STANDARD_DATE_LENGTH) {
                hardshipModelFromML.setStartDate(rawStartDate.substring(YEAR_START, YEAR_END) + DATE_SEPARATOR +
                        rawStartDate.substring(MONTH_START, MONTH_END) + DATE_SEPARATOR +
                        rawStartDate.substring(DAY_START, DAY_END));
            } else {
                hardshipModelFromML.setStartDate(rawStartDate);
            }

            String resumeCent = line.substring(config.getMerResumeCentStart(), config.getMerResumeCentEnd()).trim();
            String resumeYy = line.substring(config.getMerResumeYyStart(), config.getMerResumeYyEnd()).trim();
            String resumeMm = line.substring(config.getMerResumeMmStart(), config.getMerResumeMmEnd()).trim();
            String resumeDd = line.substring(config.getMerResumeDdStart(), config.getMerResumeDdEnd()).trim();
            String rawResumeDate = resumeCent + resumeYy + resumeMm + resumeDd;

            if (rawResumeDate.length() == STANDARD_DATE_LENGTH) {
                hardshipModelFromML.setResumeDate(rawResumeDate.substring(YEAR_START, YEAR_END) + DATE_SEPARATOR +
                        rawResumeDate.substring(MONTH_START, MONTH_END) + DATE_SEPARATOR +
                        rawResumeDate.substring(DAY_START, DAY_END));
            } else {
                hardshipModelFromML.setResumeDate(rawResumeDate);
            }
        }

        return hardshipModelFromML;
    }

    private LoanModelFromML parseLoanLine(String line, LoanConfig config) {
        LoanModelFromML loanModelFromML = new LoanModelFromML();
        var FileHeaderOrTrailer =
                line.substring(Constants.FILE_HEADER_TRAILER_START,
                        Constants.FILE_HEADER_TRAILER_END);
        if (FileHeaderOrTrailer.equalsIgnoreCase(Constants.FILE_HEADER) || FileHeaderOrTrailer.equalsIgnoreCase(Constants.FILE_TRAILER)) {
            // Ignore the Header and Trailer records from the file.
            return null;
        }

        loanModelFromML.setEmpNumber(line.substring(config.getEmpNumberStart(),
                config.getEmpNumberEnd()).trim());
        loanModelFromML.setSsnId(line.substring(config.getSsnStart(),
                config.getSsnEnd()).trim());

        loanModelFromML.setLoanNumber(line.substring(config.getLoanNumberStart(), config.getLoanNumberEnd()).trim());

        loanModelFromML.setLoanType(line.substring(config.getLoanTypeStart(),
                config.getLoanTypeEnd()).trim());

        loanModelFromML.setPayrollId(line.substring(config.getPayrollIdStart(),
                config.getPayrollIdEnd()).trim());
        loanModelFromML.setStoreLocationCode(line.substring(config.getStoreLocationCodeStart(), config.getStoreLocationCodeEnd()).trim());
        var payrollFrequency =
                line.substring(config.getPayrollFrequencyStart(),
                        config.getPayrollFrequencyEnd()).trim();

        if (payrollFrequency.equals(Constants.WEEKLY)) {
            loanModelFromML.setPayrollFrequency(Constants.WEEKLY_NUMBER);
        } else if (payrollFrequency.equals(Constants.BI_WEEKLY)) {
            loanModelFromML.setPayrollFrequency(Constants.BI_WEEKLY_NUMBER);
        } else {
            log.debug("Payroll frequency is not weekly or bi-weekly, " +
                    "setting with what we have in the file");
            loanModelFromML.setPayrollFrequency(payrollFrequency);
        }

        var deductionAmountString =
                line.substring(config.getLoanDedAmountWholeStart(),
                        config.getLoanDedAmountWholeEnd()).trim() + "." + line.substring(config.getLoanDedAmountDecimalStart(), config.getLoanDedAmountDecimalEnd()).trim();

        loanModelFromML.setDeductionAmount(deductionAmountString);

        var goalAmountString = line.substring(config.getGoalAmountWholeStart(),
                config.getGoalAmountWholeEnd()).trim() + "." + line.substring(config.getGoalAmountDecimalStart(), config.getGoalAmountDecimalEnd()).trim();
        loanModelFromML.setGoalAmount(goalAmountString);

        return loanModelFromML;
    }


    private RateChangeMLModel parseLine(String line, List<String> mlRateCodes
            , RateChange401kConfig rateChange401kConfig) {
        RateChangeMLModel rateChange = new RateChangeMLModel();
        rateChange.setPlanNumber(line.substring(rateChange401kConfig.getPlanNumberStart(), rateChange401kConfig.getPlanNumberEnd()).trim());

        if (!rateChange.getPlanNumber().equals(rateChange401kConfig.getUsPlanNumber()) &&
                !rateChange.getPlanNumber().equals(rateChange401kConfig.getPrPlanNumber())) {
            return null;
        }

        rateChange.setPartNumber(line.substring(rateChange401kConfig.getPartNumberStart(), rateChange401kConfig.getPartNumberEnd()).trim());
        rateChange.setCreationDate(line.substring(rateChange401kConfig.getCreationDateStart(), rateChange401kConfig.getCreationDateEnd()).trim());
        rateChange.setCreationTime(line.substring(rateChange401kConfig.getCreationTimeStart(), rateChange401kConfig.getCreationTimeEnd()).trim());
        rateChange.setTransactionId(line.substring(rateChange401kConfig.getTransactionIdStart(),
                rateChange401kConfig.getTransactionIdEnd()).trim());

        if (!mlRateCodes.contains(rateChange.getTransactionId())) {
            return null;
        }

        String amountStr = line.substring(rateChange401kConfig.getRateStart()
                , rateChange401kConfig.getRateEnd()).trim();
        double amount =
                Integer.parseInt(amountStr.substring(rateChange401kConfig.getRateWholeNumberStart(), rateChange401kConfig.getRateWholeNumberEnd())) +
                        Integer.parseInt(amountStr.substring(rateChange401kConfig.getRateDecimalNumberStart(), rateChange401kConfig.getRateDecimalNumberEnd())) / Constants.THOUSAND_DOUBLE;
        DecimalFormat df = new DecimalFormat(Constants.DECIMAL_FORMAT);
        double formattedValue =
                Double.parseDouble(df.format(amount * Constants.PERCENT_CONVERSION));
        rateChange.setRate(formattedValue);

        return rateChange;
    }
}
