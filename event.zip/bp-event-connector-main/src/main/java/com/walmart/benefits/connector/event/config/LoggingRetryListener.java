package com.walmart.benefits.connector.event.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryListener;
import org.springframework.stereotype.Component;

@Component
public class LoggingRetryListener implements RetryListener {
    private static final Logger log = LoggerFactory.getLogger(LoggingRetryListener.class);

    @Override
    public <T, E extends Throwable> boolean open(RetryContext context, RetryCallback<T, E> callback) {
        // Called before the first attempt
        return true;
    }

    @Override
    public <T, E extends Throwable> void close(RetryContext context, RetryCallback<T, E> callback, Throwable throwable) {
        // Called after all attempts (success or exhausted)
        if (context.getRetryCount() > 0) {
            if (throwable == null) {
                log.info("Retry succeeded after {} attempt(s).", context.getRetryCount());
            } else {
                log.error("Retry failed after {} attempt(s). Last exception: {}", context.getRetryCount(), throwable.getMessage());
            }
        }
    }

    @Override
    public <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback, Throwable throwable) {
        // Called after a failed attempt, before the next retry
        log.warn("Retry attempt {} failed due to: {}", context.getRetryCount(), throwable.getMessage());
    }
}
