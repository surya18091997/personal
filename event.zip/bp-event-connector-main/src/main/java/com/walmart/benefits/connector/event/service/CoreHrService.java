package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.repository.ConnectorRepository;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@AllArgsConstructor
@Slf4j
@Service
public class CoreHrService {
    private final ConnectorRepository dao;
    private final KafkaService kafkaService;

    /**
     * This method get the Core Hr New Hire Events and send message to Kafka
     * topic
     * @param fromDate the From Date for getting data
     * @param toDate the To Date for getting data
     */
    @Async("asyncTaskExecutor")
    public void getNewHireAssociateEventsAndSendMessageAsync(Date fromDate,
                                                             Date toDate){
        try {
            var associateEvents = dao.getNewHireAssociateEventsFromHr(fromDate, toDate);
            log.info("Associate New Hire events from {} to {} - Kafka message initiated count - {}", fromDate,
                    toDate, associateEvents.size());
            this.SendMessage(associateEvents);
        } catch (Exception e) {
            log.error("Error while generating and sending New Hire events from {} to {}. Error details - {}", fromDate, toDate, e.getMessage());
        }
    }

    /**
     * This method get the Core Hr New Hire BackDated Hire Date Events and send
     * message to Kafka
     * topic
     * @param fromDate the From Date for getting data
     */
    @Async("asyncTaskExecutor")
    public void getNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync(Date fromDate){
        try {
            var associateEvents = dao.getNewHireBackDatedHireDateAssociateEventsFromHr(fromDate);
            log.info("Associate New Hire events - Backdated Hire Date - from " +
                    "{} - Kafka message initiated count - {}", fromDate, associateEvents.size());
            this.SendMessage(associateEvents);
        } catch (Exception e) {
            log.error("Error while generatingNew Hire " +
                    "Back Dated Hire Date" +
                    " events from {}. Error details - {}", fromDate, e.getMessage());
        }
    }

    /**
     * This method get the Core Hr State Transfer Events and send message to
     * Kafka topic
     * @param fromDate the From Date for getting data
     * @param toDate the To Date for getting data
     */
    @Async("asyncTaskExecutor")
    public void getStateTransferAssociateEventsAndSendMessageAsync(Timestamp fromDate,
                                                                   Timestamp toDate){
        try {
            var associateEvents = dao.getStateTransferAssociatesFromBigQuery(fromDate,
                            toDate);
            log.info("Associate State Transfer events from {} to {} - Kafka message initiated count - {}", fromDate,
                    toDate, associateEvents.size());
            this.SendMessage(associateEvents);
        } catch (Exception e) {
            log.error("Error while generating and sending State Transfer " +
                    "events from {} to {}. Error details - {}", fromDate, toDate, e.getMessage());
        }

    }

    /**
     * This method get the Core Hr Re-Hire Events and send message to Kafka
     * topic
     * @param fromDate the From Date for getting data
     * @param toDate the To Date for getting data
     */
    @Async("asyncTaskExecutor")
    public void getReHireAssociateEventsAndSendMessageAsync(Date fromDate,
                                                             Date toDate){
        try {
            var associateEvents = dao.getReHireAssociateEventsFromHr(fromDate, toDate);
            log.info("Associate Re-Hire events from {} to {} - Kafka message initiated count - {}", fromDate,
                    toDate, associateEvents.size());
            this.SendMessage(associateEvents);
        } catch (Exception e) {
            log.error("Error while generating and sending Re-Hire events from" +
                    " {} to {}. Error details - {}", fromDate, toDate, e.getMessage());
        }
    }

    /**
     * This method get the Core Hr Termination Events and send message to Kafka
     * topic
     * @param fromDate the From Date for getting data
     * @param toDate the To Date for getting data
     */
    @Async("asyncTaskExecutor")
    public void getTerminationAssociateEventsAndSendMessageAsync(Timestamp fromDate,
                                                                 Timestamp toDate){
        try {
            var associateEvents = dao.getTerminationAssociateEventsFromHr(fromDate, toDate);
            log.info("Associate Termination events from {} to {} - Kafka " +
                            "message initiated count - {}", fromDate,
                    toDate, associateEvents.size());
            this.SendMessage(associateEvents);
        } catch (Exception e) {
            log.error("Error while generating and sending Termination events " +
                    "from" +
                    " {} to {}. Error details - {}", fromDate, toDate, e.getMessage());
        }
    }

    private void SendMessage(List<AssociateEvent> associateEvents){
        this.kafkaService.sendMessage(associateEvents);
    }

}
