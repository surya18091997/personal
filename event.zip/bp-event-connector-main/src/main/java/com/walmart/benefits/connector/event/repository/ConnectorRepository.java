package com.walmart.benefits.connector.event.repository;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.TableResult;
import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.model.StateChange;
import com.walmart.benefits.connector.event.utils.SQLHelper;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Repository
public class ConnectorRepository {
    private final JdbcTemplate db2JdbcTemplate;
    private final SQLHelper sqlHelper;
    private final BigQuery bigQuery;

    @Autowired
    private RetryTemplate retryTemplate;

    /**
     * Constructor for Connector Repository
     * @param db2JdbcTemplate DB2 JDBC Template object
     * @param sqlHelper SQL Helper object
     */
    public ConnectorRepository(@Qualifier("db2JdbcTemplate") JdbcTemplate db2JdbcTemplate, SQLHelper sqlHelper, BigQuery bigQuery) {
        this.db2JdbcTemplate = db2JdbcTemplate;
        this.sqlHelper = sqlHelper;
        this.bigQuery = bigQuery;
    }

    /**
     * This method is used to get the New Hire Core Hr events
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the list of Associate Events.
     */
    public List<AssociateEvent> getNewHireAssociateEventsFromHr(Date fromDate
            , Date toDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> events = db2JdbcTemplate.query(
                    String.format(sqlHelper.getNewHireAssociateEventQuery(),
                            Constants.INCLUDED_COUNTRY_CODE),
                    new AssociateEventMapper(EventType.NEW_HIRE),
                    fromDate, toDate);
            return events;
        });
    }

    /**
     * This method is used to get the New Hire - Back dated Hire date - Core Hr
     * events
     * @param fromDate From Date parameter
     * @return returns the list of Associate Events.
     */
    public List<AssociateEvent> getNewHireBackDatedHireDateAssociateEventsFromHr(Date fromDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> events = db2JdbcTemplate.query(
                    String.format(sqlHelper.getNewHireBackDatedEventQuery(),
                            Constants.INCLUDED_COUNTRY_CODE, Constants.EXCLUDED_EMP_STATUS_CODE),
                    new AssociateEventMapper(EventType.NEW_HIRE),
                    fromDate, fromDate, fromDate);
            return events;
        });
    }

    /**
     * This method is used to get the Re Hire Core Hr events
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the list of Associate Events.
     */
    public List<AssociateEvent> getReHireAssociateEventsFromHr(Date fromDate
            , Date toDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> events = new ArrayList<>();
            var fromDateTs =
                    Timestamp.valueOf(LocalDate.parse(fromDate.toString()).atStartOfDay());
            var toDateTs =
                    Timestamp.valueOf(LocalDate.parse(toDate.toString()).plusDays(1).atStartOfDay());
            String query = String.format(sqlHelper.getReHireAssociateEventQuery(),
                    fromDateTs, toDateTs,
                    Constants.EXCLUDED_EMP_STATUS_CODE, Constants.EXCLUDED_EMP_STATUS_CODE);

            return getAssociateEventsFromBQ(query, EventType.RE_HIRE, events);
        });
    }

    /**
     * This method is used to get the Termination Core Hr events
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the list of Associate Events.
     */
    public List<AssociateEvent> getTerminationAssociateEventsFromHr(Timestamp fromDate,
                                                                    Timestamp toDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> results = new ArrayList<>();
            String query = String.format(sqlHelper.getTerminationAssociateEventQuery(),
                    fromDate, fromDate, toDate,
                    Constants.EXCLUDED_EMP_STATUS_CODE, Constants.EXCLUDED_EMP_STATUS_CODE);

            return getAssociateEventsFromBQ(query, EventType.TERMINATION, results);
        });
    }

    private List<AssociateEvent> getAssociateEventsFromBQ(String query,
                                                    EventType eventType,
                                                    List<AssociateEvent> results) {
        return retryTemplate.execute(context -> {
            QueryJobConfiguration config = QueryJobConfiguration.newBuilder(query).build();

            try {
                TableResult result = bigQuery.query(config);

                for (FieldValueList row : result.iterateAll()) {
                    AssociateEvent model = new AssociateEvent();
                    model.setId(UUID.randomUUID());
                    model.setAssociateId(row.get(Constants.WIN_NBR_COLUMN).getStringValue());
                    model.setPlanType(PlanType.NONE);
                    model.setEventType(eventType);
                    model.setOrigin(EventOrigin.CORE_HR);
                    model.setTimeStamp(Instant.now().toString());
                    results.add(model);
                }

            } catch (InterruptedException e) {
                throw new RuntimeException("BigQuery query interrupted for " +
                        eventType.toString(), e);
            }

            return results;
        });
    }


    /**
     * This method is used to get the State Transfer Core Hr events
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the list of Associate Events.
     */
    public List<AssociateEvent> getStateTransferAssociateEventsFromHr(Timestamp fromDate
            , Timestamp toDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> events = db2JdbcTemplate.query(
                    String.format(sqlHelper.getStateTransferAssociateEventQuery(),
                            Constants.INCLUDED_COUNTRY_CODE,
                            Constants.EXCLUDED_EMP_STATUS_CODE,
                            Constants.EXCLUDED_EMP_STATUS_CODE,Constants.EXCLUDED_EMP_STATUS_CODE),
                    new AssociateStateTransferEventMapper(),
                    fromDate, toDate);
            return events;
        });
    }

    /**
     * Retrieves a map of associate IDs and their corresponding SSNs from the database.
     *
     * @param  ssnList   a list of SSNs in a comma separated to retrieve
     *                   associate IDs
     * @return            a map of associate IDs and their corresponding SSNs
     */
    public Map<String, String> getAssociateIdListFromSsnList(List<String> ssnList) {
        return retryTemplate.execute(context -> {
            String placeholders = String.join(",", ssnList.stream().map(id -> "?").toList());

            var queryResult = db2JdbcTemplate.query(
                    String.format(sqlHelper.getNationalIdMappingQuery(),
                            placeholders),
                    (rs, rowNum) -> Map.entry(
                            rs.getString(Constants.SSN_COLUMN),
                            rs.getString(Constants.WIN_NBR_COLUMN)
                    ),
                    ssnList.toArray());
            if (queryResult != null && !queryResult.isEmpty()) {
                return queryResult.stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (existing, replacement) -> replacement));
            }
            return Map.of();
        });
    }

    public List<AssociateEvent> getStateTransferAssociatesFromBigQuery(Timestamp fromDate,
                                                                       Timestamp toDate) {
        return retryTemplate.execute(context -> {
            List<AssociateEvent> results = new ArrayList<>();
            String query = String.format(sqlHelper.getStateTransferBgQuery(),
                    fromDate, toDate, fromDate);

            QueryJobConfiguration config = QueryJobConfiguration.newBuilder(query).build();

            try {
                TableResult result = bigQuery.query(config);

                for (FieldValueList row : result.iterateAll()) {
                    AssociateEvent model = new AssociateEvent();
                    model.setId(UUID.randomUUID());
                    model.setAssociateId(row.get(Constants.WIN_NBR_COLUMN).getStringValue());
                    model.setPlanType(PlanType.NONE);
                    model.setEventType(EventType.STATE_TRANSFER);
                    model.setOrigin(EventOrigin.CORE_HR);
                    model.setTimeStamp(Instant.now().toString());
                    model.setAdditionalInfo(StateChange.builder()
                            .stateStoreProvCd(row.get(Constants.TO_STATE_COLUMN).getStringValue())
                            .prevStateStoreProvCd(row.get(Constants.FROM_STATE_COLUMN).getStringValue())
                            .hireDate(row.get(Constants.HIRE_DATE_COLUMN).getStringValue())
                            .build());
                    results.add(model);
                }

            } catch (InterruptedException e) {
                throw new RuntimeException("BigQuery query interrupted", e);
            }

            return results;
        });
    }
}
