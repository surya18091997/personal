package com.walmart.benefits.connector.event.service;
import com.walmart.benefits.connector.event.common.Constants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.function.BiConsumer;

@AllArgsConstructor
@Slf4j
@Service
public class ConnectorService {

    private final CoreHrService coreHrService;
    private final FileToEventsProcessorService fileToEventsProcessorService;

    /**
     * This method used to initiate the New Hire Core Hr event
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure message
     */
    public String getNewHireHrEventDetailsAndSendMessage(String fromDate, String toDate) {
        return processEventDetailsForEachDayAndSendMessage(fromDate, toDate, this::getNewHireAssociateEventsAndSendMessageAsync);
    }

    /**
     * This method used to initiate the State Transfer event
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure message
     */
    public String getStateTransferEventDetailsAndSendMessage(String fromDate,
                                                         String toDate){
        return processEventDetailsAndSendMessage(fromDate, toDate, this::getStateTransferAssociateEventsAndSendMessageAsync);
    }

    /**
     * This method used to initiate the Re Hire event
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure message
     */
    public String getReHireEventDetailsAndSendMessage(String fromDate, String toDate) {
        return processEventDetailsForEachDayAndSendMessage(fromDate, toDate, this::getReHireAssociateEventsAndSendMessageAsync);
    }

    /**
     * This method used to initiate the Termination event
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure message
     */
    public String getTerminationEventDetailsAndSendMessage(String fromDate,
                                                      String toDate){
        return processEventDetailsAndSendMessage(fromDate, toDate, this::getTerminationAssociateEventsAndSendMessageAsync);
    }

    /**
     * This method used to initiate the Rate Change File process and send event
     * @return returns the success or failure message
     */
    public String processRateChange401kFileAndSendMessage(){
        this.fileToEventsProcessorService.process401kRateChangeFileAndSendMessage();
        return Constants.EVENT_CREATION_INITIATED;
    }

    /**
     * This method used to initiate the Loan Us File process and send event
     * @return returns the success or failure message
     */
    public String processLoan401kUsFileAndSendMessage(){
        this.fileToEventsProcessorService.processLoanUsFileAndSendMessage();
        return Constants.EVENT_CREATION_INITIATED;
    }

    /**
     * This method used to initiate the Loan Pr File process and send event
     * @return returns the success or failure message
     */
    public String processLoan401kPrFileAndSendMessage(){
        this.fileToEventsProcessorService.processLoanPrFileAndSendMessage();
        return Constants.EVENT_CREATION_INITIATED;
    }

    public String processHardship401kUsFileAndSendMessage(){
        this.fileToEventsProcessorService.processHardshipUsFileAndSendMessage();
        return Constants.EVENT_CREATION_INITIATED;
    }

    public String processHardship401kPrFileAndSendMessage(){
        this.fileToEventsProcessorService.processHardshipPrFileAndSendMessage();
        return Constants.EVENT_CREATION_INITIATED;
    }

    private String processEventDetailsForEachDayAndSendMessage(String fromDate,
                                                               String toDate, BiConsumer<Date, Date> eventProcessor) {
        var localFromDate = LocalDate.parse(fromDate);
        var localToDate = LocalDate.parse(toDate);

        for (var date = localFromDate; !date.isAfter(localToDate); date = date.plusDays(1)) {
            var reqFromDate = Date.valueOf(date);
            var reqToDate = Date.valueOf(date);
            eventProcessor.accept(reqFromDate, reqToDate);
        }

        return Constants.EVENT_CREATION_INITIATED;
    }

    private void getNewHireAssociateEventsAndSendMessageAsync(Date fromDate, Date toDate) {
        this.coreHrService.getNewHireAssociateEventsAndSendMessageAsync(fromDate, toDate);
        this.coreHrService.getNewHireBackDatedHireDateAssociateEventsAndSendMessageAsync(fromDate);
    }

    private void getReHireAssociateEventsAndSendMessageAsync(Date fromDate, Date toDate) {
        this.coreHrService.getReHireAssociateEventsAndSendMessageAsync(fromDate, toDate);
    }

    private String processEventDetailsAndSendMessage(String fromDate,
                                                               String toDate, BiConsumer<Timestamp, Timestamp> eventProcessor) {
        var reqFromDate = Timestamp.valueOf(LocalDate.parse(fromDate).atStartOfDay());
        var reqToDate = Timestamp.valueOf(LocalDate.parse(toDate).plusDays(1).atStartOfDay());
        eventProcessor.accept(reqFromDate, reqToDate);
        return Constants.EVENT_CREATION_INITIATED;
    }

    private void getStateTransferAssociateEventsAndSendMessageAsync(Timestamp fromDate, Timestamp toDate) {
        this.coreHrService.getStateTransferAssociateEventsAndSendMessageAsync(fromDate, toDate);
    }

    private void getTerminationAssociateEventsAndSendMessageAsync(Timestamp fromDate, Timestamp toDate) {
        this.coreHrService.getTerminationAssociateEventsAndSendMessageAsync(fromDate, toDate);
    }
}