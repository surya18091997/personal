package com.walmart.benefits.connector.event.exception;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.time.DateTimeException;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * This method used to handle the DateTimeException
     * @param ex DateTimeException parameter
     * @return returns string
     */
    @ExceptionHandler(DateTimeException.class)
    public ResponseEntity<String> handleDateTimeException(DateTimeException ex) {
        String errorMessage = ex.getMessage();
        log.error(errorMessage, ex);
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles the NoResourceFoundException and logs the error message.
     *
     * @param  ex the NoResourceFoundException to be handled
     * @return     a ResponseEntity with the error message and a NOT_FOUND status
     */
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<String> handleNoResourceFoundException(NoResourceFoundException ex) {
        String errorMessage = ex.getMessage();
        log.error(errorMessage, ex);
        return new ResponseEntity<>(errorMessage, HttpStatus.NOT_FOUND);
    }

    /**
     * This method used to handle the Generic Exceptions
     * @param ex Exception parameter
     * @return returns string
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGlobalException(Exception ex) {
        String errorMessage = Constants.UNEXPECTED_ERROR + ex.getMessage();
        log.error(errorMessage, ex);
        return new ResponseEntity<>(Constants.UNEXPECTED_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
