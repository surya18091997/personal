package com.walmart.benefits.connector.event.config;

import com.walmart.benefits.connector.event.utils.RetryRejectedExecutionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

import static com.walmart.benefits.connector.event.common.Constants.ASYNC_THREAD_NAME;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Value("#{'${async.corePoolSize}'}")
    private Integer corePoolSize;

    @Value("#{'${async.maxPoolSize}'}")
    private Integer maxPoolSize;

    @Value("#{'${async.maxQueueSize}'}")
    private Integer maxQueueSize;

    @Value("#{'${async.retryDelay}'}")
    private Integer retryDelay;

    /**
     * This method used to handle the Async task executor
     * @return returns the Executor
     */
    @Bean(name = "asyncTaskExecutor")
    public Executor asyncTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(maxQueueSize);
        executor.setThreadNamePrefix(ASYNC_THREAD_NAME);
        executor.setRejectedExecutionHandler(new RetryRejectedExecutionHandler(retryDelay));
        executor.initialize();
        return executor;
    }
}