package com.walmart.benefits.connector.event.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoanModel {
    private String ssnId;
    private String loanNumber;
    private String deductionAmount;
    private String loanType;
    private String payrollId;
    private String goalAmount;
    private String payrollFrequency;
    private String storeLocationCode;
    private String countryCode;
}
