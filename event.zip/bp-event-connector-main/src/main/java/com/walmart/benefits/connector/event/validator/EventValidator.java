package com.walmart.benefits.connector.event.validator;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@NoArgsConstructor
@Component
public class EventValidator {

    /**
     * This method used to validate the FromDate and ToDate inputs and throws
     * error in-case of any invalid data.
     * @param fromDate From Date Parameter
     * @param toDate To Date Parameter
     */
    public void validateDateInputs(LocalDate fromDate, LocalDate toDate) {
        if(fromDate.isAfter(toDate)){
            throw new DateTimeException(Constants.FROM_DATE_EXCEPTION);
        }
        else if (ChronoUnit.DAYS.between(fromDate, toDate) > Constants.MAX_DATE_RANGE) {
            throw new DateTimeException(Constants.DATE_RANGE_EXCEPTION);
        }
    }
}
