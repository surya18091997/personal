package com.walmart.benefits.connector.event.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Component
@PropertySource("classpath:loan401kPr.properties")
@ConfigurationProperties(prefix = "loan-pr")
@Validated
@Data
public class LoanPrConfig extends LoanConfig {
    @NotNull
    private String loanPrFileName;
}