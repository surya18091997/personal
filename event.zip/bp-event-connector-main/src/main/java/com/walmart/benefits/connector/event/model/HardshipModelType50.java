package com.walmart.benefits.connector.event.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class HardshipModelType50 extends HardshipModel {
    private String startDate;
    private String resumeDate;
}
