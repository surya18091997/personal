package com.walmart.benefits.connector.event.config;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public EventType eventType() {
        return EventType.NONE;
    }
}