package com.walmart.benefits.connector.event.controller;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.service.ConnectorService;
import com.walmart.benefits.connector.event.validator.EventValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;

@Slf4j
@RestController
@RequestMapping("api/trigger")
public class TriggerEventController {
    
    @Value("#{'${trigger.state-transfer}'}")
    String stateTransferTriggerDays;

    @Value("#{'${trigger.new-hire}'}")
    String newHireTriggerDays;

    @Value("#{'${trigger.re-hire}'}")
    String reHireTriggerDays;

    @Value("#{'${trigger.termination}'}")
    String terminationTriggerDays;

    private final ConnectorService service;
    private final EventValidator validator;

    public TriggerEventController(ConnectorService service, EventValidator validator) {
        this.service = service;
        this.validator = validator;
    }

    /**
     * This method used to trigger the Core Hr New Hire events for the given
     * date range or else it will take the current date as toDate and
     * fromDate as minus of given configured value from toDate.
     * @param fromDate From Date parameter (optional)
     * @param toDate To Date parameter (optional)
     * @return returns the success or failure of initiating the events to
     * kafka topic
     */
    @GetMapping("new-hire-event")
    public String triggerNewHireEvent(@RequestParam(required = false) String fromDate
            , @RequestParam(required = false) String toDate){
        log.info("New Hire value from Airflow Job -> from date - {}, to Date - {}", fromDate, toDate);
        var validatedDates = parseDateAndValidate(fromDate, toDate, newHireTriggerDays);
        return service.getNewHireHrEventDetailsAndSendMessage(validatedDates.fromDate(),
                validatedDates.toDate());
    }

    /**
     * This method used to trigger the State Transfer events as per given
     * date range or else it will take the current date as toDate and
     * fromDate as minus of given configured value from toDate.
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure of initiating the events to
     * kafka topic
     */
    @GetMapping("state-transfer-event")
    public String triggerStateTransferEvent(@RequestParam(required = false) String fromDate
            , @RequestParam(required = false) String toDate){
        log.info("State transfer value from Airflow Job -> from date - {}, to Date - {}", fromDate, toDate);
        var validatedDates = parseDateAndValidate(fromDate, toDate, stateTransferTriggerDays);
        return service.getStateTransferEventDetailsAndSendMessage(validatedDates.fromDate(),
                validatedDates.toDate());
    }

    /**
     * Triggers the rate change event for a 401k.
     *
     * @return          the response entity with the result of the operation and the HTTP status
     */
    @GetMapping("rate-change-401k-event")
    public String triggerRateChange401kEvent(){
        return service.processRateChange401kFileAndSendMessage();
    }

    /**
     * This method used to trigger the Re-Hire events as per given
     * date range or else it will take the current date as toDate and
     * fromDate as minus of given configured value from toDate.
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure of initiating the events to
     * kafka topic
     */
    @GetMapping("re-hire-event")
    public String triggerReHireEvent(@RequestParam(required =
            false) String fromDate
            , @RequestParam(required = false) String toDate){
        log.info("Re-Hire value from Airflow Job -> from date - {}, to Date -" +
                " {}", fromDate, toDate);
        var validatedDates = parseDateAndValidate(fromDate, toDate, reHireTriggerDays);
        return service.getReHireEventDetailsAndSendMessage(validatedDates.fromDate(),
                validatedDates.toDate());
    }

    /**
     * This method used to trigger the Termination events as per given
     * date range or else it will take the current date as toDate and
     * fromDate as minus of given configured value from toDate.
     * @param fromDate From Date parameter
     * @param toDate To Date parameter
     * @return returns the success or failure of initiating the events to
     * kafka topic
     */
    @GetMapping("termination-event")
    public String triggerTerminationEvent(@RequestParam(required =
            false) String fromDate
            , @RequestParam(required = false) String toDate){
        log.info("Termination value from Airflow Job -> from date - {}, to " +
                "Date -" +
                " {}", fromDate, toDate);
        var validatedDates = parseDateAndValidate(fromDate, toDate, terminationTriggerDays);
        return service.getTerminationEventDetailsAndSendMessage(validatedDates.fromDate(),
                validatedDates.toDate());
    }

    /**
     * Triggers the Loan event for a 401k US File.
     *
     * @return          the response entity with the result of the operation and the HTTP status
     */
    @GetMapping("loan-401k-us-event")
    public String triggerLoan401kUsEvent(){
        return service.processLoan401kUsFileAndSendMessage();
    }

    /**
     * Triggers the Loan event for a 401k PR File.
     *
     * @return          the response entity with the result of the operation and the HTTP status
     */
    @GetMapping("loan-401k-pr-event")
    public String triggerLoan401kPrEvent(){
        return service.processLoan401kPrFileAndSendMessage();
    }

    @GetMapping("hardship-401k-us-event")
    public String triggerHardship401kUsEvent(){
        return service.processHardship401kUsFileAndSendMessage();
    }
    @GetMapping("hardship-401k-pr-event")
    public String triggerHardship401kPrEvent(){
        return service.processHardship401kPrFileAndSendMessage();
    }

    private ValidatedDates parseDateAndValidate(String fromDate,
                                                String toDate,
                                                String triggerDays) {
        var parsedToDate = StringUtils.hasText(toDate) ?
                LocalDate.parse(toDate) :
                LocalDate.now();

        LocalDate parsedFromDate;
        if(!StringUtils.hasText(fromDate)) {
            parsedFromDate = parsedToDate.minusDays(Long.parseLong(StringUtils.hasText(triggerDays)? triggerDays : Constants.ZERO));
        }
        else{
            parsedFromDate = LocalDate.parse(fromDate);
        }

        fromDate = parsedFromDate.toString();
        toDate = parsedToDate.toString();
        this.validator.validateDateInputs(parsedFromDate, parsedToDate);
        return new ValidatedDates(fromDate, toDate);
    }

    private record ValidatedDates(String fromDate, String toDate) {
    }
}
