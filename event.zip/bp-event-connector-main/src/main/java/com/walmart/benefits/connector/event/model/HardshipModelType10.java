package com.walmart.benefits.connector.event.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class HardshipModelType10 extends HardshipModel {
    private String merMatchEligDate;
    private String merMatchEligInd;
    private String countryCode;
}
