package com.walmart.benefits.connector.event.config;

import com.walmart.benefits.connector.event.common.Constants;
import com.walmart.benefits.connector.event.utils.AESSerializer;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaProducerConfig {

    @Value("${kafka.events-queue.bootstrap-servers}")
    private String kafkaServer;
    @Value("#{'${kafka.security.keystore-location}'}")
    String keyStoreLocation;
    @Value("#{'${kafka.security.keystore-password}'}")
    String keyStorePassword;
    @Value("#{'${kafka.security.truststore-location}'}")
    String trustStoreLocation;
    @Value("#{'${kafka.security.truststore-password}'}")
    String trustStorePassword;
    @Value("#{'${kafka.security.key-password}'}")
    String keyPassword;
    @Value("#{'${kafka.security.protocol}'}")
    String protocol;
    @Value("#{'${kafka.security.truststore-type}'}")
    String trustStoreType;
    @Value("#{'${kafka.security.aes-secret}'}")
    String aesSecretKey;
    @Value("#{'${kafka.events.linger-ms}'}")
    String lingerMs;
    @Value("#{'${kafka.events.batch-size}'}")
    String batchSize;
    @Value("#{'${kafka.events.buffer-memory}'}")
    String bufferMemory;
    @Value("#{'${kafka.events.retries}'}")
    String retries;


    @Bean
    public ProducerFactory<String, AssociateEvent> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServer);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, AESSerializer.class);
        config.put(AESSerializer.AES_SECRET_KEY, aesSecretKey);
        config.put(Constants.SECURITY_PROTOCOL, protocol);
        config.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, trustStoreType);
        config.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, trustStoreLocation);
        config.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keyStoreLocation);
        config.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustStorePassword);
        config.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keyStorePassword);
        config.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keyPassword);
        config.put(ProducerConfig.BATCH_SIZE_CONFIG, batchSize);
        config.put(ProducerConfig.LINGER_MS_CONFIG, lingerMs);
        config.put(ProducerConfig.BUFFER_MEMORY_CONFIG, bufferMemory);
        config.put(ProducerConfig.RETRIES_CONFIG, retries);
        config.put("spring.json.add.type.headers", false);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, AssociateEvent> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}
