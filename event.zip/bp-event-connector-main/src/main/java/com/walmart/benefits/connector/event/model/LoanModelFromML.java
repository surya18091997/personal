package com.walmart.benefits.connector.event.model;


import com.walmart.benefits.connector.event.common.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoanModelFromML {
    private String ssnId;
    private String empNumber;
    private String loanNumber;
    private String deductionAmount;
    private String loanType;
    private String payrollId;
    private String goalAmount;
    private String payrollFrequency;
    private String storeLocationCode;
    private String countryCode;
}
