package com.walmart.benefits.connector.event.service;

import com.walmart.benefits.connector.event.common.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@Service
public class FileService {

    @Retryable(
            value = IOException.class,
            maxAttempts = Constants.MAX_FILE_RETRY,
            backoff = @Backoff(delay = Constants.FILE_RETRY_DELAY_IN_MS)
    )
    public void checkIfFileExists(String filePath, String fileName) throws IOException {
        Path path = Paths.get(filePath, fileName);
        if (!Files.exists(path)) {
            log.warn("File does not exist: {}, retrying...",
                    filePath + fileName);
            throw new IOException(Constants.FILE_DOES_NOT_EXIST);
        }
    }
}
