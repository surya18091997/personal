package com.walmart.benefits.connector.event.common;

public class Constants {

    private Constants() {
    }

    public static final String SECURITY_PROTOCOL = "security.protocol";
    public static final String CORE_HR_ORIGIN = "CORE_HR";
    public static final String MERILL_LYNCH_ORIGIN = "ML";
    public static final String EVENT_CREATION_INITIATED = "Event(s) Creation Initiated";
    public static final String EVENT_FAILED = "Event Creation Failed";
    public static final String WIN_NBR_COLUMN = "WIN_NBR";
    public static final String SSN_COLUMN = "SSN";
    public static final String ASYNC_THREAD_NAME = "Async-Event-";
    public static final String INCLUDED_COUNTRY_CODE = "'US'";
    public static final String EXCLUDED_EMP_STATUS_CODE = "'T', 'D'";
    public static final String FROM_DATE_EXCEPTION = "FromDate should not be " +
            "greater than ToDate";
    public static final String UNEXPECTED_ERROR = "An unexpected error " +
            "occurred: ";
    public static final String STATE_CODE_COLUMN = "STATE_CODE";
    public static final String PREVIOUS_STATE_CODE_COLUMN =
            "PREVIOUS_STATE_CODE";
    public static final String HIRE_DATE_COLUMN = "HIRE_DATE";
    public static final String ZERO = "0";
    public static final Double ZERO_DOUBLE = 0.0;
    public static final Double THOUSAND_DOUBLE = 1000.0;
    public static final Integer SQL_BATCH_SIZE = 1000;
    public static final String DATE_FORMAT = "yyyyMMddHHmmss";
    public static final String UTC_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSX";
    public static final String ZONE_EST = "America/New_York";
    public static final String ZONE_UTC = "UTC";
    public static final String ARCHIVE_FILE_SUFFIX = ".archive";
    public static final String HYPHEN = "_";
    public static final String FILE_DOES_NOT_EXIST = "File does not exist.";
    public static final String ERROR_RECORDS_AVAILABLE = "There were %s " +
            "error record(s) while parsing the %s file.";
    public static final String DATE_RANGE_EXCEPTION = "Date range cannot be " +
            "greater than 15 days.";
    public static final int MAX_DATE_RANGE = 15;
    public static final int DEFAULT_RETRY_DELAY = 100;
    public static final double PERCENT_CONVERSION = 100;
    public static final String DECIMAL_FORMAT = "#.###";
    public static final String LOCAL_ENV = "http://localhost:8080";
    public static final String DEV= "http://benefits-platform-event-connector-dev.walmart.com";
    public static final String US = "US";
    public static final String PR = "PR";
    public static final String REGEX_INTEGER = "\\d+";
    public static final String REGEX_DECIMAL = ".*\\d+\\.\\d+.*";
    public static final int LOAN_NUMBER_LENGTH = 3;
    public static final String WEEKLY = "W";
    public static final String BI_WEEKLY = "B";
    public static final String WEEKLY_NUMBER = "1";
    public static final String BI_WEEKLY_NUMBER = "2";
    public static final int THOUSAND_INT = 1000;
    public static final int ZERO_INT = 0;
    public static final String LOAN_GENERAL = "0";
    public static final String LOAN_RESIDENTIAL = "1";
    public static final String FILE_HEADER = "UHDR";
    public static final String FILE_TRAILER = "UTRL";
    public static final int FILE_HEADER_TRAILER_START = 0;
    public static final int FILE_HEADER_TRAILER_END = 4;
    public static final int MAX_FILE_RETRY = 3;
    public static final int FILE_RETRY_DELAY_IN_MS = 120000;
    public static final String RATE_CHANGE = "Rate Change";
    public static final String LOAN = "Loan";
    public static final String HARDSHIP="Hardship";
    public static final String TYPE_10 = "10";
    public static final String TYPE_50 = "50";
    public static final String TO_STATE_COLUMN = "to_state";
    public static final String FROM_STATE_COLUMN = "from_state";
    public static final String MATCH_ELIGIBLE = "E";
    public static final String NOT_MATCH_ELIGIBLE = "N";
    public static final String MATCH_ELIGIBLE_DATE_DEFAULT = "0001-01-01";
    public static final int YEAR_START = 0;
    public static final int YEAR_END = 4;
    public static final int MONTH_START = 4;
    public static final int MONTH_END = 6;
    public static final int DAY_START = 6;
    public static final int DAY_END = 8;
    public static final int STANDARD_DATE_LENGTH = 8;
    public static final String DATE_SEPARATOR = "-";
    public static final int RETRY_BACKOFF_PERIOD_MS = 2000;
    public static final int RETRY_MAX_ATTEMPTS = 5;
    public static final double RETRY_BACKOFF_MULTIPLIER = 2.0;
    public static final int RETRY_BACKOFF_MAX_FACTOR = 8;
}
