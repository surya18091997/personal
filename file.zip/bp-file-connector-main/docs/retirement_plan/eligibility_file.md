# Eligibility File Documentation 

## Overview
The eligibility file flow handles the extraction, processing, and transfer of eligibility-related data from various sources to Google Cloud Storage (GCS). The class implements a direct export approach to handle large datasets effectively.

## Execution Requirements

### Required Parameters
1. **Configuration ID**: `01` - US `04` - PR
   - Mandatory parameter for initializing the eligibility file generation
   - Used to fetch specific flow configuration from CCM


2. **Start and End Date Retrieval**:      
- Condition 1: If start_date and end_date are provided, it uses these dates to filter logs.
- Condition 2: If a timestamp exists in the flow configuration ('last_processed_timestamp' format : '0000-00-00 00:00:00.000000').
- Condition 3: If neither date range nor timestamp is available, it fetches the maximum timestamp from a PostgreSQL database.
