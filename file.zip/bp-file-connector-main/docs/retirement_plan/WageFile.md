# Eligible Wages Documentation

## Overview
Eligible wages flow handles the extraction, processing, and transfer of wage-related data from BigQuery to 
Google Cloud Storage (GCS). The class implements a memory-efficient batch processing approach to handle large datasets effectively.

## Execution Requirements

### Required Parameters
1. **Configuration ID**: `21`
   - Mandatory parameter for initializing the wage file generation
   - Used to fetch specific flow configuration from CCM

2. **Run Date**:
   - Format: YYYY-MM-DD
   - Used as the payroll run date for data extraction
   - If not provided, the process will fall back to the maximum run date from the earnings table

  
## Configuration Details

### Flow Configuration for ID 21
The following configuration is automatically loaded when using configuration ID 21:

```python
flow_config = {
    "gcp_project": "<project_identifier>",
    "bigquery_dataset": "<dataset_name>",
    "bucket_name": "<gcs_bucket_name>",
    "destination_file_path": "<gcs_path>",
    "doe_codes": "<specific_doe_codes>",
    "earn_type_codes": "<specific_earn_codes>",
    "row_limit": None  # Optional limit for number of rows. Entire table will be fetched if it is not specified
}
```

### Processing Flow
- Direct export of data from BigQuery to GCS
- Real-time performance metrics:
  - Records processed
  - Processing speed (records/second)
  - Elapsed time
  - Batch completion status

### Memory Management
- Iterative row processing
- DataFrame cleanup after each batch
- Progress tracking every 10,000 records

## Error Handling
- Comprehensive error logging
- Exception propagation to caller
- Batch-level error tracking
- Transaction rollback on failures

## File Output
- CSV format
- Temporary storage in working directory
- Automatic transfer to GCS bucket

## Dependencies
- pandas
- Google Cloud BigQuery
- Google Cloud Storage
- FileGenerator base class
- Custom SQL queries (ELIGIBLE_WAGES_QUERY)

