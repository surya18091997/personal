# Retirement flows


## 1. Rate Change Outbound Flow

## Overview
Rate Change Outbound flow handles the extraction, processing, and transfer of rate-change related data from to 
Google Cloud Storage (GCS).The Rate Change Outbound files are generated daily and sent to Merrill Lynch. 
Two separate files will be created:
- **US Associates File**
- **PR Associates File**

## Execution Requirements

### Required Parameters
1. **Configuration ID**: `12`
   - Mandatory parameter for initializing the US_RATE_CHANGE_OUTBOUND file generation
   - Used to fetch specific flow configuration from CCM
 
   **Configuration ID**: `13`
   - Mandatory parameter for initializing the PR_RATE_CHANGE_OUTBOUND file generation
   - Used to fetch specific flow configuration from CCM

2. **Start Date**:
   - Format: YYYY-MM-DD

3. **End Date**:
   - Format: YYYY-MM-DD
### Sample Input Format
```json
{
  "configurationId": 12,
  "fromDate": "",
  "toDate": ""
}
```

## Configuration Details

### Flow Configuration for ID 12
The following configuration is automatically loaded when using configuration ID 12:

```python
flow_config={
  "flow_name": "RATE_CHANGE",
  "source_file_path": "",
  "destination_file_path": "outgoing/rate_change/us",
  "dest_file": "US_RATE_CHANGE_File",
  "plan_number": 609450,
  "plan_file": "WMRATECHANGEFILE",
  "primary_key": "associate_id",
  "bucket_name": "benefits-platform-file-connector",
  "record_types": ["r01", "r02"],
  "region": "US",
  "plan_stat_code": "06",
  "file_gen_func": "US_RATE_CHANGE_File",
  "plan_id": ["Retirement_401k_Regular_US", "Retirement_401k_Catchup_US"]
}
```

### Flow Configuration for ID 13
The following configuration is automatically loaded when using configuration ID 13:

```python
flow_config={
  "flow_name": "RATE_CHANGE",
  "source_file_path": "",
  "destination_file_path": "outgoing/rate_change/pr",
  "dest_file": "PR_RATE_CHANGE_File",
  "plan_number": 609577,
  "plan_file": "WMRATECHANGEFILE",
  "primary_key": "associate_id",
  "bucket_name": "benefits-platform-file-connector",
  "record_types": ["r01", "r02"],
  "region": "PR",
  "plan_stat_code": "06",
  "file_gen_func": "PR_RATE_CHANGE_File",
  "plan_id": ["Retirement_401k_Regular_US", "Retirement_401k_Catchup_US"],
}

```

### File Generation Flow

1. **Fetch Transaction Logs**
   - Retrieve all transaction logs with the activity: `RATE_CHANGE` from the database.

2. **Fetch Associate Information**
   - Retrieve associate information from Core HR for the relevant associates.

3. **Fetch Latest Contribution Rates**
   - Fetch the latest changed contributions (rates) from the `coverages` collection in the database.

4. **Fetch Consent Data**
   - Retrieve consent information from the `profile` collection in the database.

5. **Generate File**
   - Compile the data into the required file format.

6. **Transfer File**
   - Transfer the generated file to the GCS bucket.

   
### File Output
- Temporary storage in working directory
- Automatic transfer to GCS bucket

### Google Cloud Storage (GCS) Path
/benefits-platform-file-connector/outgoing/rate_change/

## Confluence reference
https://confluence.walmart.com/pages/viewpage.action?pageId=2416342505

## Dependencies
- pandas
- Google Cloud Storage
- FileGenerator base class
