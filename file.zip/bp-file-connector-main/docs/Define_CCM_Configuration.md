[CCM Portal](https://admin.tunr.non-prod.walmart.com/services/BENEFITS-FILECONNECTOR/service-configs/NON-PROD-1.0)

All the configurations are defined in CCM portal:
- At this time of writing there are 3 configuration files that are defined:
    1. **Application** - Contains application specific properties
    2. **File Layout** - Contains layouts of different files that are used in generation module
    3. **Flow Configuration** - Contains the flow configuration map , for each configuration id - what file needs to be generated, transferred and its respective attributes. 

# How the configuration(s) are defined in CCM 

The delivery type defines, how the configuration files are made available. For this project, the `deliveryType` is chosen as JSON, as properties `deliveryType` is in deprecation phase. [Link](https://confluence.walmart.com/pages/viewpage.action?pageId=1069149430#HowtochangeCCMdeliverytype?-Howtooverridethefiletypefromkitt.ymlfile?)

The  application configuration holds, key-value pair properties. 
The `file_layouts` and `flow_config_map` configuration holds, key-Json (represented in string format) properties. 

Current, CCM allows (Integer, Boolean, String, Decimal, Duration)  types, for a JSON value. 
To add a JSON property, append special character tilde(~) at the beginning and ending. 
The module will parse the json accordingly. Also, all double quotes are escaped when delivered to pod. 

Example : 

    ~{"flow_name":"NEW_HIRE","dest_file":"US_Eligibility_File","plan_number":609450,"plan_file":"ELIGIBILITY","primary_key":"associate_id","bucket_name":"benefits-platform-file-connector","record_types":["r01","r02","r05","r62"],"file_gen_func":"US_Eligibility_File"}~  


# How the configuration will be read from CCM

When the K8`s pod spins up, the configuration files are delivered to "/etc/config" directory. 
- `application.json`
- `file_layouts.json`
- `flow_config_map.json`

All the configurations are read in `app_config` module / program. 
    - The config are read with the following config_names:
        - Config Name - `app`, `flow_config`, `file_layout`. 
    - To read a configuration we will need Config Name and Key Name, use the method get_config_value( config_name, key)

# Local Setup 
Go to https://admin.tunr.non-prod.walmart.com/services/BENEFITS-FILECONNECTOR
Navigate to Version ( Current Version - NON-PROD-1.0)
     - Click on Work offline, provide and envName, envProfile as desired. 
     - Download the configuration directory and extract the configuration files and copy to local folder path, preferable '/etc/config'
     - Edit the configurations as needed.
     

# Additional reading about the Tunr 

- [Troubleshooting Guide](https://confluence.walmart.com/display/STRTUNR/Troubleshooting+Guide)
- [How To Docs](https://confluence.walmart.com/display/STRTUNR/How+To+Docs)
- [How to read configurations](https://confluence.walmart.com/pages/viewpage.action?spaceKey=STRTUNR&title=CCM2+Onboarding#5110670601e87016ea842475ea2ebc65ca3704841)
- [Tunr Git Integration Algorithm](https://confluence.walmart.com/display/STRTUNR/Tunr+Git+Integration+Algorithm)