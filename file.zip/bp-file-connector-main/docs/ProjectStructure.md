# Project Title

This is a brief description of what this project is about and what it does.

## Table of Contents

- [Directory Structure](#directory-structure)
- [Code Overview](#code-overview)
- [Contributing](#contributing)


## Directory Structure

- The `src/` directory contains all the code related to the application. 
- The `src/controllers` directory includes all the controllers that are used in the application.
- The `src/file_connector/` module contains the modules related to file transfer.
- The `src/file_processor_factory/` module contains the processor factory to create a processor based on the configuration id that is passed .
- The `src/generate_file/` module contains the common methods for creating files in various formats.
- The `src/integrations/` module contains the utility methods to connect to different databases, storage accounts. 
- The `src/load_file/` module contains the methods for parsing a file and loading it into the database.
- The `src/retirement_plan/` module contains different processors that handle 401k specific events.
- The `src/telemetry/` directory contains all the helper functions that are used for generating telemetry components.
- The `src/utils/` module contains all the utility methods for logging, app configuration, connecting to sftp, sql queries that are used.
- The `tests/` directory contains all the unit test cases for different modules.
- The `repo_utils/` directory contains an initial integration proof of concept, that can be used in the actual application.


## Code Overview
The file connector application, on high level is categorized in 2 parts.
1. [Accepting Requests](#accepting-requests) - Accepting Requests from the client - This is done via a REST API. 
2. [Processing Requests](#processing-requests) - Process the requests, as per the configuration id and request parameters in the requests. 


## Code Overview
The file connector application, on high level is categorized in 2 parts.
1. Accepting Requests from the client - This is done via a REST API. 
2. Process the requests, as per the configuration id and request parameters in the requests. 


### Part 1 - Accepting Requests
A REST API is hosted on port 8080 by default, and has following URI`s to accept requests:
- /api/v1/file/transfer --> Accepts file transfer request
- /api/v1/file/generate --> Accepts file generation request
- /api/v1/file/load --> Accepts file parse and load request

Once a request is accepted, a UUID(4) is generated for the request. <br>
And logged to a postgres DB, to track the request for the subsequent steps.
A parallel thread is created, and [File Processor Factory](#file-processor-factory) processor factory will kick off as per the defined configuration.  

### Part 2 - Processing the Requests
The application has 3 types of processors:
- [File Transfer Processor](#file-transfer-processor) - Responsible to transfer the file from one location to another
- [File Generation Processor](#file-generation-processor) - Responsible to generate files in a specific format. 
- [File Load Processor](#file-load-processor) - Responsible to parse a file and load to database.

#### File Transfer Processor
This processor module contains utility methods 
- transfer to / from GCS Bucket 
- transfer to / from Azure storage location
- transfer from mainframe (at the time of this writeup, this is needed, for full developed project this should be decommissioned)
- transfer from MFT server (at the time of this writeup , it is not available)
- transfer to / from EDI mailbox and/or non-EDI mailbox (at the time of this writeup , it is not available)

#### File Generation Processor
This processor module contains utility, processor methods
- Get data from cosmos DB
- Get data from data lake
- Get eligibility data for a specified plan
- Get data from big-query
- Get data from DB2
- Common methods - These methods are processor method used by different flow configurations. <br>
  Example data fetch methods: fetch_core_hr_data, fetch_division_numbers, get_transaction_logs <br>
  Example data processor methods: process_core_hr_df, generate_df_by_record_type, generate_record_dict <br> 


#### Generate Flat File 
Data preparation is a pre-requisite step for flat file generation process.

### Data preparation,
- Determine all the data elements that will need to be filled in. <br>
  Example: List all the elements from coreHR and create a DataFrame. 
- Format the source data elements to the target state.( we get data from coreHR, benefits datalake, etc. , this data will need to be formatted into respective record types, so as to match the columns in the file format)<br>
  Example: coreHR attributes are required in record set 01, record set 02, ... etc.
- In generate_record_dict, a dictionary of data frames are generated for each record type, using the source data frames. <br>
  The column names in the data frame , should exactly match with the column names defined in the file format. <br>
  Example: In coreHR DB, the month in birthdate month is retrieved as birthdate, and then formatted as specific HR attribute "R01-BDAY-MM". 
- We have static column list as well, where static / default values are defined. 
- By the end of this method, for the list of record types that are defined in configuration , we will have dictionary of record-set with data populated. <br>

### Data Generation,
- This step we will use file layout map, this is a configuration defined in CCM, that specifies, which column should be populated, where in the file. 
- The final file has 3 sections
  - Header --> Has metadata details , such as plan number, file type, create date and time
  - Records --> A list of records, for each associate, plug in the values from formatted data frame, as defined in file layout configuration. ( Refer to the flat_file_layout in CCM search for respective record set names r01, r02, r05, r62 etc.) 
  - Trailer --> Calculates the total number of records by each record type, and writes it to the trailer record as per layout defined in CCM ( Refer to the flat_file_layout in CCM search for trailer_record)


#### File Load Processor
At the time of this writing the only need was for reading the contents of a file and write to payroll database
Most of the file load and write is written directly in PayrollTransactionsWriter, this is not an ideal case. 
Due to prioritization, this is left out, but this should be refactored so as the core modules are written in file_loader.py


#### File Processor factory

The `FileProcessorFactory` class contains three private properties:
- `_generator_map` 
- `_loader_map`
- `_run_date_map`

These properties map configuration IDs to their corresponding classes.

#### Properties

`_generator_map` <br>
This dictionary maps configuration IDs to their corresponding generator classes. The IDs and classes are:
- 1: `Eligibility` (Eligibility_US)


`_loader_map`<br>
This dictionary maps configuration IDs to their corresponding loader classes. The ID and class is:
- 31: `PayrollTransactionsWriter`

`_run_date_map`<br>
This dictionary maps configuration IDs to their corresponding run date classes. The IDs and classes are:
- 21: `WageFile` (WageFile_US)
- 'WageFile': `WageFile`

#### create_processor method
This static method creates a file processor based on the given configuration ID. <br>
The method checks in which map the configuration ID is present and creates an instance of the corresponding class. <br>
If the configuration ID is not present in any of the maps, it throws a ValueError. <br>
The method will log the name of the class that is being instantiated and return the instance of the class.



The configuration details are available in CCM portal
- Non Production [CCM-Non-Prod](https://admin.tunr.non-prod.walmart.com/services/BENEFITS-FILECONNECTOR)
- Production [CCM-Prod](https://admin.tunr.prod.walmart.com/services/BENEFITS-FILECONNECTOR)

Please refer to How to Define Configuration in CCM in [page](/Define_CCM_Configuration.md)


## Contributing
If you'd like to contribute, please follow [BranchingStrategy](/docs/BranchingStrategy.md)



