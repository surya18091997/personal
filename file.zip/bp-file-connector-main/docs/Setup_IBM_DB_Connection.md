Here is the reformatted data for a GitHub markup page:

**Installing ibm_db on macOS M1/M2 Chip Systems**
=====================================================

Reference link: https://github.com/ibmdb/python-ibmdb/issues/835#issuecomment-1503772903

This document provides a step-by-step guide on how to install the `ibm_db` package on macOS M1/M2 chip systems with arm64 architecture.

### Step 1: Check the current Homebrew installation

Open a new terminal and run the following command to check if Homebrew is installed in the arm64/M1 path:
```
$ which brew
```
The output should show the current arm64/M1 brew installed path:
```
/opt/homebrew/bin/brew
```

### Step 2: Install x86_64 Homebrew

Run the following command to install x86_64 Homebrew under `/usr/local/bin/brew`:
```
arch -x86_64 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
```

### Step 3: Create an alias for x86_64 Homebrew

Create an alias for the x86_64 brew:
```
# brew hack for x86_64

alias brew64='arch -x86_64 /usr/local/bin/brew'

```

### Step 4: Install gcc@12 using x86_64 Homebrew

Use the x86_64 Homebrew alias to install gcc@12:
```
brew64 install gcc@12
```

### Step 5: Set the DYLD_LIBRARY_PATH environment variable

In the project IDE, open a terminal and activate the environment in which the current project is running. Then, run the following command to set the DYLD_LIBRARY_PATH environment variable:
```
export DYLD_LIBRARY_PATH=/usr/local/lib/gcc/12
```

### Step 6: Install ibm_db using pip

Finally, install the `ibm_db` package using pip:
```
pip3 install ibm_db
```
The installation should now be successful.

By following these steps, you can successfully install the `ibm_db` package on macOS M1/M2 chip systems with arm64 architecture.