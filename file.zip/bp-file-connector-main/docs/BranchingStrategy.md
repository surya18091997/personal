The following is a list of recommended practices when implementing new features in our codebase. This aims to facilitate collaboration, make the review process easier and more efficient, and to ensure that the final code is of the highest quality.

![BranchingStrategy](../docs/BranchingStrategy.png)

## 1. Branch Creation for Feature Implementation

Start working on a new feature by creating a new branch from the 'develop' branch. The branch could be named something like `feature/<JiraRequest>-newFeature`.

## 2. Creating Small and Concise Pull Requests

As soon as you have some working code, create a PR from your feature branch to the 'develop' branch. Keep your PRs concise to around 500 lines of code to make them easier to review and prevent overlooked mistakes.

## 3. Breaking Down Complex Tasks

If your feature requires more than 500 lines of code, break it down into smaller unit tasks. For each task, create a new branch from your feature branch named like `feature/newFeatureTaskXYZ`.

## 4. PR Checklist

Address all items in the PR checklist, including:

- Add the JIRA ticket number in the PR title
- Write a brief description of the changes
- Ensure unit/e2e (UI code changes) test cases with coverage of at least 80%
- Verify no major/critical/blocked sonar issues and No Synk Container Vulnerabilities
Example:
```
<JIRA TICKET> | DEV / BUG | < One line description > 
```

## 5. PR Review

Share your PR with the reviewers as early as possible for feedback. 
The final PRs should be shared with the reviewers at least 7 to 14 days before the planned release date to allow them time to thoroughly review and approve the changes.

## 6. Updating Your Branch

Periodically pull the latest code from 'develop' into your feature branch to keep it updated and avoid any future merge conflicts.

## 7. Handling Legacy Code

Avoid making unnecessary changes to the legacy code like auto indentation corrections which can complicate the review process.

## 8. Communication

Use teams channel (Benefits Code review) to post PRs ready for review, discuss progress, issues, ask for help, and post updates after PR is merged so that others can pull the new changes.

## 9. PR Approval

Enforce a rule that no PR can be merged without at least one or two approvals. This ensures that every line of code is checked by another set of eyes before it gets merged.

## 10. Post-Merge Actions

Remove old developer branch as part of cleanup after the merge. Validate the code in the team's namespace dev environment after merging the code.

## 11. Code Cleanliness

Remove any extra files in PR which have only changes like extra spaces. Add proper comments in all necessary code changes.

## 12. Feature Branch

Clear the feature branch once code merged to dev branch. 

Remember, the goal of this strategy is to facilitate collaboration, make the review process easier and more efficient, and to ensure that the final code is of the highest quality.
