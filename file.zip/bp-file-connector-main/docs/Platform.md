
This page intends to talk about the decisions, clarifications and confirmation. 

### Benefits Platform Entity Model
https://gecgithub01.walmart.com/GBS-PeopleBenefitsDomain/benefits-platform-entity-model

### For Plan ID and Plan Name ENUM
https://gecgithub01.walmart.com/GBS-PeopleBenefitsDomain/benefits-platform-entity-model/blob/main/src/main/java/com/walmart/benefitsplatformentitymodel/intradomain/planconfig/PlanType.java

## Why did we choose UUID(4) over UUID(1)?
Detailed Explanation : https://stackoverflow.com/questions/703035/when-are-you-truly-forced-to-use-uuid-as-part-of-the-design/786541#786541

This page intends to talk about the decisions and clarifications and confirmation. 

Benefits Platform Entity Model
https://gecgithub01.walmart.com/GBS-PeopleBenefitsDomain/benefits-platform-entity-model

For Plan ID and Plan Name ENUM
https://gecgithub01.walmart.com/GBS-PeopleBenefitsDomain/benefits-platform-entity-model/blob/main/src/main/java/com/walmart/benefitsplatformentitymodel/intradomain/planconfig/PlanType.java

Why did we choose UUID(4) over UUID(1)?
Detailed Explanation : https://stackoverflow.com/questions/703035/when-are-you-truly-forced-to-use-uuid-as-part-of-the-design/786541#786541

uuid1() is guaranteed to not produce any collisions (under the assumption you do not create too many of them at the same time). 
We wouldn't use it if it's important that there's no connection between the uuid and the computer, as the mac address gets used to make it unique across computers.

You can create duplicates by creating more than 214 uuid1 in less than 100ns, but this is not a problem for most use cases.

uuid4() generates, a random UUID. The chance of a collision is really, really, really small. 
Small enough, that you shouldn't worry about it. 
The problem is, that a bad random-number generator makes it more likely to have collisions.

