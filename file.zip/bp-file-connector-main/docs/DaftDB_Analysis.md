# Performance Analysis: DaftDB
**Date:** January 16, 2025

## File System Overview

### Source Data Format
- **File Type:** Apache Parquet
- **Storage Location:** Google Cloud Storage (GCS)
- **Path Pattern:** `gs://benefits-data-lake/comparison/mongo_documents/associate_benefit_profile_dm5/*parquet`
- **Structure:** Apache Hudi Dataset
- **Total Records:** 66,865,332

## Version used

### DaftDB
- **Version:** 0.4.0
- **Implementation:** Using NativeRunner (default configuration)
- **Primary Functions:**
  - Parquet file reading
  - Initial data loading
  - Record counting
  - Chunk limiting
- **Performance:**
  - Efficient memory management for large datasets
  - Streaming capabilities for parquet files
  - Native integration with GCS

### Pandas Integration
- **Conversion Strategy:** Chunk-based conversion
- **Chunk Size used:** 1,000,000 records
- **Memory Impact:**
  - Initial Load: ~577 MB
  - Average Usage: ~744 MB
  - Peak Usage: 876 MB
- **Performance Metrics:**
  - Average Conversion Time per Chunk: 29.54 seconds
  - Processing Rate: ~33,850 records/second
