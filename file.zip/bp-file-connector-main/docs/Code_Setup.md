
# Developer Setting Up Code Guide

This guide is designed to assist developers in setting up code with navigable sections for setting up secrets, setting up configuration, and setting up environment variables. Please note that this document is customized for a macOS.

## Contents 

- [Setup Python Environment](#setup-python-environment-using-pycharm)
- [Setting Up Secrets](#setting-up-secrets)
- [Setting Up Configuration](#setting-up-configuration)
- [Define the Debug Configuration](#define-the-debug-configuration)


## Setting Up Secrets

1. Create a folder `/etc/secrets` in your local machine.
2. Refer to the KITT file, akeyless section.
3. Ensure to use the same filename in destination.
4. Copy all the files from Akeyless to this folder , from the location `/Prod/WCNP/homeoffice/BenefitsAzureDev/FileConnector/{stage}`
5. Update the constant `CERTIFICATE_PATH` with the path to the certificate.

Example:

```bash
- destination: bpi_cosmos_connection       #--> output file name
  content: FileConnector/{{$.kittExec.currentStage.name}}/Cosmos_Connection 
```
Create a file `bpi_cosmos_connection` and copy the credential information from `/Prod/WCNP/homeoffice/BenefitsAzureDev/FileConnector/{stage}/Cosmos_Connection`.

## Setting Up Configuration

1. Create a folder `/etc/config` in your local machine.
2. Navigate to `https://admin.tunr.non-prod.walmart.com/services/BENEFITS-FILECONNECTOR`
3. Click on the Service Config Version that is applicable (Example - (NON-PROD-1.0))
4. The page will redirect to Service Config Metadata.
5. Click on Work offline link and provide, `envName` and `envProfile` download the configurations (For NonProd, you can provide Dev / Stage as applicable).
6. This will download a folder - `BENEFITS-FILECONNECTOR-<Service Config Version>.zip`
7. Unzip the folder and copy the json file to `/etc/config
8. Update the value `working_dir` key with the path to the working dir in config `application.json`
9. Update the constant `ROOT DIR` in `src/constants.py` with the path to the working dir.

**Note:** The ccm generated configurations are string formatted, all the double quotes are escaped. 
You can use the [ccm_config_file_parser.py](../repo_utils/ccm_config_file_parser.py) to parse it into a json to a directory of your choice. 
This script will format the json file into a directory of your choice.

## Define the Debug Configuration

If you are using PyCharm, provide the following in ENV variables:

```bash
PYTHONUNBUFFERED=1;DYLD_LIBRARY_PATH=/usr/local/lib/gcc/12:$DYLD_LIBRARY_PATH;export http_proxy=http://sysproxy.wal-mart.com:8080;export https_proxy=$http_proxy
```

# Setup Python Environment using PyCharm

This guide will walk you through the process of setting up a Python environment using PyCharm. 

## Setting Up Virtual Environment

A virtual environment is a self-contained directory tree that contains a Python installation for a particular version of Python, plus a number of additional packages. It's often used to create isolated Python environments for different projects. 

Here are the steps to setup a virtual environment:

```bash

# Install Homebrew
arch -x86_64 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"

# Change ownership of the directory
sudo chown -R $(whoami) /usr/local/share/zsh/site-functions

# Reinstall Homebrew
arch -x86_64 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"

# Create an alias for brew
alias brew64='arch -x86_64 /usr/local/bin/brew'

# Install gcc@12 with the new alias
Brew64 install gcc@12

# Change ownership of the directory
sudo chown -R s0k02kj /usr/local/share/zsh

# Install gcc@12
brew64 install gcc@12

# Set the library path
export DYLD_LIBRARY_PATH=/usr/local/lib/gcc/12

# Install Python version 3.11
brew64 install python@3.11
```

## Installing Requirements

Once the virtual environment is setup, you can install the required packages. Here is how you can do it:

```bash
# Set the proxy
export http_proxy=http://sysproxy.wal-mart.com:8080                                       
export https_proxy=$http_proxy

# Set the library path
export DYLD_LIBRARY_PATH=/usr/local/lib/gcc/12

# Install ibm_db package
pip install ibm_db

# Activate the virtual environment
source .venv/bin/activate

# Check the installed packages
pip list

# Install required packages from requirements.txt
pip install -r requirements.txt
```

Once all these steps are completed, your Python environment in PyCharm should be ready to use. You can start developing your Python projects in this environment.
