import sys
import unittest
from unittest.mock import MagicMock
sys.modules['ibm_db'] = MagicMock()
sys.modules['ibm_db_dbi'] = MagicMock()
import pytest
from datetime import datetime
import pandas as pd
from unittest.mock import MagicMock, patch, Mock, mock_open
from pandas.testing import assert_frame_equal
from src.constants import F_ERROR, FG_FILE_FROM_COSMOS_CREATED, FG_FILE_COSMOS_ERROR

#  Mock external service dependencies to isolate tests
mock_modules = {
    'ibm_db': Mock(),
    'ibm_db_dbi': Mock(),
    'pymongo': Mock(),
    'pymongo.errors': Mock(),
    'google': Mock(),
    'google.cloud': Mock(),
    'google.cloud.storage': Mock(),
    'google.cloud.bigquery': Mock(),
    'google.api_core.exceptions': Mock(),
    'psycopg2': Mock()
}

for module_name, mock_obj in mock_modules.items():
    sys.modules[module_name] = mock_obj
from src.generate_file.file_generator import FileGenerator

CONST_TEST_EXCEPTION = 'Test exception'
CONST_TEST_DIR = '/test/working_dir'

@pytest.mark.usefixtures('mock_dependencies')
class TestFileGenerator(unittest.TestCase):
    @patch('src.integrations.db2_conn_helper.DB2IDatabase')
    def setUp(self, mock_db2):

        # Mock DB2 instance with empty DataFrame returns
        self.mock_db2_instance = MagicMock()
        self.mock_db2_instance.testset = 'TEST'
        self.mock_db2_instance.fetchall.return_value = []
        mock_db2.return_value = self.mock_db2_instance

        # Configure mock configuration values with detailed structure
        def mock_get_config_value(section, key=None):
            configs = {
                "app": {
                    "mongodb_connection_file_path": "/mock/path/mongodb_connection.json",
                    "gcs_connection_file_path": "/mock/path/gcs_connection.json",
                    "db2_connection_file_path": "/mock/path/db2_connection.yaml",
                    "defaultFileStorage": "/tmp/test",
                    "working_dir": "/test/working/dir"
                },
                "flow_config": {
                    'flow_name': 'Test Flow',
                    'dest_file': 'test.txt',
                    'destination_file_path': 'test/path',
                    'plan_number': '609450',
                    'plan_file': 'test.csv',
                    'primary_key': 'id',
                    'bucket_name': 'test-bucket',
                    'file_gen_func': 'generate_test_file',
                    'source_file_path': '',
                    'record_types': ['r01', 'r02', 'r05', 'r62'],
                    'region': 'us',
                    'plan_stat_code': '1234567890'
                },
                "file_layout": {
                    "static_col_record_set": {
                        "r01": {"R01-RECORD-TYPE": "01"},
                        "r02": {"R02-RECORD-TYPE": "02"},
                        "r05": {"R05-RECORD-TYPE": "05"},
                        "r62": {"R62-RECORD-TYPE": "62"}
                    },
                    "corehr_columns_by_recordtype": {
                        "r01": ["WIN_NBR", "NATIONAL_ID", "LAST_NAME", "FIRST_NAME",
                                "BIRTH_DATE", "GENDER_CODE", "ACT_MARITAL_CODE", "COMP_FREQ_CODE"],
                        "r02": ["WIN_NBR", "NATIONAL_ID", "HOME_ADDR_LINE_1", "CITY_NAME",
                                "STATE_PROV_CODE", "POSTAL_CODE", "STR_STATE_PROV_CD"],
                        "r05": ["WIN_NBR", "NATIONAL_ID"],
                        "r62": ["WIN_NBR", "NATIONAL_ID", "STORE_NBR", "DIV_NBR",
                                "CHRG_STORE_NBR", "CHRG_MDSE_DIV_NBR", "PAY_TYPE_CODE",
                                "TERMINATION_DATE"]
                    }
                }
            }
            return configs.get(section, {}).get(key, configs.get(section, {}))

        # Mock DB2 configuration
        mock_yaml_content = """
            db2_region:
                db2_database: testdb
                db2_hostname: testhost
                db2_protocol: tcpip
                db2_userid: testuser
                db2_port: 50000
            """
        # Set up all required patches
        self.patches = [
            patch('src.utils.app_config.get_config_value', side_effect=mock_get_config_value),
            patch('builtins.open', mock_open(read_data=mock_yaml_content)),
            patch('os.path.exists', return_value=True),
            patch('os.makedirs', return_value=True),
            patch('src.integrations.gcs_utils.GCSUtils.upload_folder', return_value=True),
            patch('yaml.full_load', return_value={'db2_region': {
                'db2_database': 'testdb',
                'db2_hostname': 'testhost',
                'db2_protocol': 'tcpip',
                'db2_userid': 'testuser',
                'db2_port': 50000
            }})
        ]
        for patcher in self.patches:
            patcher.start()
            self.addCleanup(patcher.stop)

            # Initialize FileGenerator
        self.fileGenerator = FileGenerator(1, MagicMock(), 'test_request_id',
                                           datetime(2024, 11, 4), datetime(2024, 11, 28))
        self.fileGenerator.db2_connection = self.mock_db2_instance
        self.fileGenerator.logger = MagicMock()

    # @patch('src.generate_file.file_generator.FileGenerator.set_file_flow_config_parameters')
    # def test_init(self, mock_set_file_flow_config_parameters):
    #     file_generator = FileGenerator(1, MagicMock(), 'test_request_id', datetime(2024, 11, 4), datetime(2024, 11, 28))
    #     mock_set_file_flow_config_parameters.assert_called_once_with(1)
    #
    # def test_set_file_flow_config_parameters(self):
    #     self.fileGenerator.set_file_flow_config_parameters(1)
    #
    #     assert self.fileGenerator.flow_name == "Test Flow"
    #     assert self.fileGenerator.dest_file == "test.txt"
    #     assert self.fileGenerator.plan_number == "609450"
    #     assert self.fileGenerator.plan_file == "test.csv"
    #     assert self.fileGenerator.primary_key == "id"
    #     assert self.fileGenerator.bucket_name == "test-bucket"
    #     assert self.fileGenerator.file_gen_func == "generate_test_file"
    #     assert self.fileGenerator.record_types == ['r01', 'r02', 'r05', 'r62']
    #     assert self.fileGenerator.region == "us"
    #     assert self.fileGenerator.plan_stat_code == "1234567890"
    #
    # def test_set_file_flow_config_parameters_exception(self):
    #     with patch.object(self.fileGenerator.logger, 'error') as mock_logger_error:
    #         with patch('src.generate_file.file_generator.app_config.get_config_value',
    #                    side_effect=Exception('Unexpected Error')):
    #             self.fileGenerator.set_file_flow_config_parameters(1)
    #             mock_logger_error.assert_called_with(
    #                 'Error while retrieving flow configuration details Unexpected Error')
    #
    # # @patch('src.generate_file.file_generator.create_dir_if_not_exists')
    # @patch('src.generate_file.file_generator.app_config')
    # def test_create_working_directory(self, mock_app_config, mock_create_dir_if_not_exists):
    #     mock_app_config.get_config_value.return_value = "/test/working/dir"
    #     self.fileGenerator.create_working_directory('test_request')
    #     mock_create_dir_if_not_exists.assert_called_with('/test/working/dir/test_request', self.fileGenerator.logger)
    #     self.assertEqual(self.fileGenerator.request_id_dir, '/test/working/dir/test_request')
    #
    # @patch('src.generate_file.file_generator.create_dir_if_not_exists')
    # @patch('src.generate_file.file_generator.app_config')
    # def test_create_working_directory_exception(self, mock_app_config, mock_create_dir_if_not_exists):
    #     mock_app_config.get_config_value.return_value = "/test/working/dir"
    #     with patch.object(self.fileGenerator.logger, 'error') as mock_logger_error:
    #         mock_create_dir_if_not_exists.side_effect = Exception('Unexpected Error')
    #         self.fileGenerator.create_working_directory('test_request')
    #         mock_logger_error.assert_called_with('Error while creating working directory Unexpected Error')
    #
    # @patch.object(FileGenerator, 'get_data_from_cosmos')
    # def test_get_data_from_cosmos(self, mock_get_data_from_cosmos):
    #     """
    #     Test data retrieval from Cosmos DB collections.
    #     """
    #     mock_get_data_from_cosmos.return_value = [{'id': '123', 'name': 'test'}]
    #     result = self.fileGenerator.get_data_from_cosmos('test_db', 'test_collection', {}, {})
    #     self.assertEqual(result, [{'id': '123', 'name': 'test'}])
    #
    # @patch('src.integrations.cosmos_utils.CosmosUtils.get_structured_data')
    # def test_get_data_from_cosmos_with_no_return_value(self, mock_get_data_from_cosmos):
    #     mock_get_data_from_cosmos.return_value = None
    #     with patch.object(self.fileGenerator.logger, 'info') as mock_logger_info:
    #         result = self.fileGenerator.get_data_from_cosmos('test_db', 'test_collection', {}, {})
    #         mock_logger_info.assert_called_with(FG_FILE_FROM_COSMOS_CREATED.format(
    #             collection='test_collection',
    #             dir=None
    #         ))
    #         self.assertIsNone(result)
    #
    # @patch('src.integrations.cosmos_utils.CosmosUtils.get_structured_data')
    # def test_get_data_from_cosmos_exception(self, mock_get_data_from_cosmos):
    #     mock_get_data_from_cosmos.side_effect = Exception('Unexpected error')
    #     with patch.object(self.fileGenerator.logger, 'error') as mock_logger_error:
    #         result = self.fileGenerator.get_data_from_cosmos('test_db', 'test_collection', {}, {})
    #         mock_logger_error.assert_called_with(FG_FILE_COSMOS_ERROR.format(error_message='Unexpected error'))
    #         self.assertIsNone(result)
    #
    # @patch('src.generate_file.file_generator.write_list_to_file')
    # @patch('src.generate_file.file_generator.cosmos_utils.get_structured_data')
    # def test_get_eligible_data_from_cosmos(self, mock_get_structured_data, mock_write_list_to_file):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR  # Add this line
    #     mock_get_structured_data.return_value = [{'associateId': '123'}, {'associateId': '456'}]
    #     mock_write_list_to_file.return_value = ''
    #     result = self.fileGenerator.get_eligible_data_from_cosmos('test_db', 'test_collection', {}, {})
    #     self.assertCountEqual(result, ['123', '456'])
    #
    # @patch('src.generate_file.file_generator.write_list_to_file')
    # @patch('src.generate_file.file_generator.cosmos_utils.get_structured_data')
    # def test_get_eligible_data_from_cosmos_empty(self, mock_get_structured_data, mock_write_list_to_file):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR
    #     mock_get_structured_data.return_value = []
    #     mock_write_list_to_file.return_value = ''
    #     result = self.fileGenerator.get_eligible_data_from_cosmos('test_db', 'test_collection', {}, {})
    #     self.assertEqual(result, [])
    #
    # @patch('src.generate_file.file_generator.write_list_to_file')
    # @patch('src.generate_file.file_generator.cosmos_utils.get_structured_data')
    # def test_get_eligible_data_from_cosmos_none(self, mock_get_structured_data, mock_write_list_to_file):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR
    #     mock_get_structured_data.return_value = None
    #     mock_write_list_to_file.return_value = ''
    #
    #     self.fileGenerator.get_eligible_data_from_cosmos('test_db', 'test_collection', {}, {})
    #
    #     self.fileGenerator.logger.error.assert_called_with('Error in get_structured_data: \'NoneType\' object is not iterable')
    # @patch('src.generate_file.file_generator.write_list_to_file')
    # @patch('src.generate_file.file_generator.cosmos_utils.get_structured_data')
    # def test_get_eligible_data_from_cosmos_exception(self, mock_get_structured_data,
    #                                                  mock_write_list_to_file):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR
    #     mock_get_structured_data.side_effect = Exception(CONST_TEST_EXCEPTION)
    #     mock_write_list_to_file.return_value = ''
    #
    #     self.fileGenerator.get_eligible_data_from_cosmos('test_db', 'test_collection', {}, {})
    #
    #     self.fileGenerator.logger.error.assert_called_with('Error in get_structured_data: Test exception')
    # @patch('src.generate_file.file_generator.BigQueryDatabase.get_df_from_query')
    # def test_get_data_from_bigquery_empty_store_list(self, mock_get_df_from_query):
    #     store_list_df = pd.DataFrame()
    #     result = self.fileGenerator.get_data_from_bigquery(store_list_df)
    #     self.assertIsNone(result)
    #
    # @patch('src.generate_file.file_generator.BigQueryDatabase.get_df_from_query')
    # def test_get_data_from_bigquery_exception(self, mock_get_df_from_query):
    #     mock_get_df_from_query.side_effect = Exception('BigQuery Error')
    #     store_list_df = pd.DataFrame({'store': ['1', '2', '3']})
    #     self.fileGenerator.get_data_from_bigquery(store_list_df)
    #     self.fileGenerator.logger.error.assert_called_with('Error in get_data_from_bigquery: BigQuery Error')
    #
    # @patch('src.generate_file.file_generator.BigQueryDatabase.get_df_from_query')
    # def test_get_data_from_bigquery_no_division(self, mock_get_df_from_query):
    #     store_list_df = pd.DataFrame({'store': ['1', '2', '3']})
    #     mock_get_df_from_query.return_value = pd.DataFrame()
    #     result = self.fileGenerator.get_data_from_bigquery(store_list_df)
    #     self.assertIsNone(result)
    #
    # @patch('src.generate_file.file_generator.BigQueryDatabase.get_df_from_query')
    # def test_get_data_from_bigquery_with_data(self, mock_get_df_from_query):
    #     store_list_df = pd.DataFrame({'store': ['1', '2', '3']})
    #     mock_get_df_from_query.return_value = pd.DataFrame({'division': ['1', '2', '3']})
    #     result = self.fileGenerator.get_data_from_bigquery(store_list_df)
    #     self.assertIsNotNone(result)
    #     self.assertEqual(len(result), 3)
    #
    #
    # @patch('src.generate_file.file_generator.DB2IDatabase.fetchall')
    # @patch('src.generate_file.file_generator.write_dataframe_to_file')
    # def test_get_data_from_db2(self, mock_write_dataframe, mock_fetchall):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR
    #     mock_fetchall.return_value = [('1', '2', '3')]
    #
    #     # Mock write_dataframe_to_file to not actually write
    #     mock_write_dataframe.return_value = None
    #
    #     # Create a mock DB2 connection
    #     self.fileGenerator.db2_connection = MagicMock()
    #     self.fileGenerator.db2_connection.fetchall = mock_fetchall
    #
    #     result = self.fileGenerator.get_data_from_db2(['a', 'b', 'c'], 'SELECT * FROM table', 'table')
    #     expected_df = pd.DataFrame([('1', '2', '3')], columns=['a', 'b', 'c'])
    #     pd.testing.assert_frame_equal(result, expected_df)
    #     mock_write_dataframe.assert_called_once()
    #
    # @patch('src.generate_file.file_generator.DB2IDatabase.fetchall')
    # def test_get_data_from_db2_exception(self, mock_fetchall):
    #     self.fileGenerator.request_id_dir = CONST_TEST_DIR
    #
    #     # Create a specific DB2 error
    #     mock_fetchall.side_effect = Exception('DB2 Error')
    #
    #     # Create a mock DB2 connection
    #     self.fileGenerator.db2_connection = MagicMock()
    #     self.fileGenerator.db2_connection.fetchall = mock_fetchall
    #
    #     self.fileGenerator.get_data_from_db2(['a', 'b', 'c'], 'SELECT * FROM table', 'table')
    #     self.fileGenerator.logger.error.assert_called_with(
    #         'An error occurred while generating table file from db2 data: DB2 Error'
    #     )
    #
    # @patch('src.generate_file.file_generator.FileGenerator.get_data_from_bigquery')
    # def test_fetch_division_numbers(self, mock_get_data_from_bigquery):
    #     # Test that division numbers are fetched properly
    #     store_nums_df = pd.DataFrame({'store': ['1', '2', '3']})
    #     mock_get_data_from_bigquery.return_value = pd.DataFrame({'division': ['222', '333', '444']})
    #     result = self.fileGenerator.fetch_division_numbers(store_nums_df)
    #     self.assertIsNotNone(result)
    #
    #     # Assert that the returned DataFrame has the correct division numbers
    #     expected_df = pd.DataFrame({'division': ['222', '333', '444']})
    #     assert_frame_equal(result, expected_df)
    #
    #     # Assert that get_data_from_bigquery was called with the correct argument
    #     mock_get_data_from_bigquery.assert_called_once_with(store_nums_df)
    #
    # @patch('src.generate_file.file_generator.FileGenerator.get_data_from_db2')
    # def test_fetch_core_hr_dataa(self, mock_get_data_from_db2):
    #     # Define the sample columns
    #     sample_columns = ['WIN_NBR', 'NATIONAL_ID', 'LAST_NAME', 'FIRST_NAME', 'BIRTH_DATE',
    #                       'GENDER_CODE', 'ACT_MARITAL_CODE', 'HIRE_DATE', 'COMP_FREQ_CODE', 'HOME_ADDR_LINE_1',
    #                       'CITY_NAME', 'STATE_PROV_CODE', 'POSTAL_CODE', 'STR_STATE_PROV_CD',
    #                       'STORE_NBR', 'CHRG_STORE_NBR', 'PAY_TYPE_CODE', 'TERMINATION_DATE', 'CHRG_MDSE_DIV_NBR']
    #
    #     # Define some sample data
    #     sample_data = [
    #         ['123', '456', 'Doe', 'John', '2000-01-01',
    #          'M', 'S', '2020-01-01', 'A', '123 Street',
    #          'City', 'ST', '12345', 'ST',
    #          '1', '1', 'F', '2021-01-01', '1']
    #     ]
    #
    #     # Create a DataFrame for the sample data
    #     df = pd.DataFrame(sample_data, columns=sample_columns)
    #
    #     # Mock the get_data_from_db2 method to return the DataFrame
    #     mock_get_data_from_db2.return_value = df
    #
    #     associate_list = ['test']
    #     # Call the method
    #     result = self.fileGenerator.fetch_core_hr_data(associate_list)
    #
    #     # Assert that the result is a DataFrame
    #     self.assertIsInstance(result, pd.DataFrame)
    #
    #     # Assert that the result DataFrame has the correct values
    #     pd.testing.assert_frame_equal(result, df)
    #
    # @patch('src.generate_file.file_generator.FileGenerator.get_eligible_data_from_cosmos')
    # def test_get_transaction_logs(self, mock_get_eligible_data_from_cosmos):
    #     mock_cosmos_data = [{"associateId": "12345"}]
    #     expected_start = self.fileGenerator.start_date.replace(hour=0, minute=0, second=1).isoformat()
    #     expected_end = self.fileGenerator.end_date.replace(hour=23, minute=59, second=59).isoformat()
    #
    #     expected_search_criteria = {
    #         "activity": self.fileGenerator.flow_name,
    #         "createdAt": {
    #             "$gte": expected_start,
    #             "$lte": expected_end
    #         }
    #     }
    #
    #     mock_get_eligible_data_from_cosmos.return_value = mock_cosmos_data
    #
    #     result = self.fileGenerator.get_transaction_logs()
    #
    #     self.assertIsNotNone(result)
    #     self.assertEqual(result, mock_cosmos_data)
    #
    #     mock_get_eligible_data_from_cosmos.assert_called_once_with(
    #         cosmos_database='benefits-platform',
    #         cosmos_collection='transaction-logs',
    #         cosmos_projection={'_id': 0, 'associateId': 1},
    #         cosmos_search_criteria=expected_search_criteria
    #     )
    #
    # @patch('src.utils.common_utils.PostgresGCPConnection')
    # @patch('src.generate_file.file_generator.FileGenerator.get_eligible_data_from_cosmos')
    # def test_get_transaction_logs_no_data(self, mock_get_eligible_data_from_cosmos, mock_postgres):
    #     # Arrange
    #     mock_get_eligible_data_from_cosmos.return_value = None
    #
    #     # Mock PostgreSQL connection
    #     mock_postgres_instance = MagicMock()
    #     mock_postgres.return_value = mock_postgres_instance
    #     mock_postgres_instance.__enter__.return_value = mock_postgres_instance
    #     mock_postgres_instance.execute_query.return_value = None
    #
    #     # Mock update_request_status
    #     with patch('src.generate_file.file_generator.update_request_status') as mock_update_status:
    #         # Act
    #         result = self.fileGenerator.get_transaction_logs()
    #
    #         # Assert
    #         self.assertIsNone(result)
    #         self.fileGenerator.logger.info.assert_called_with('No eligible associate list found.')
    #         mock_update_status.assert_called_once_with(
    #             self.fileGenerator.request_id,
    #             F_ERROR,
    #             self.fileGenerator.logger,
    #             "No eligible associate list found."
    #         )
    #
    # @patch('src.generate_file.file_generator.file_transfer')
    # def test_transfer_file_to_gcs(self, mock_file_transfer):
    #     mock_file_transfer_instance = Mock()
    #     mock_file_transfer.return_value = mock_file_transfer_instance
    #     self.fileGenerator.transfer_file_to_gcs()
    #     mock_file_transfer_instance.transfer_file_to_gcs.assert_called_once_with(
    #         self.fileGenerator.bucket_name,
    #         self.fileGenerator.request_id_dir,
    #         self.fileGenerator.destination_file_path,
    #         self.fileGenerator.dest_file
    #     )
    #
    # @patch('src.generate_file.file_generator.file_transfer')
    # def test_transfer_file_to_azure_directory(self, mock_file_transfer):
    #     mock_file_transfer_instance = Mock()
    #     mock_file_transfer.return_value = mock_file_transfer_instance
    #     self.fileGenerator.transfer_file_to_azure_directory()
    #     mock_file_transfer_instance.transfer_to_azure_directory.assert_called_once_with(
    #         self.fileGenerator.request_id_dir,
    #         self.fileGenerator.destination_file_path,
    #         self.fileGenerator.dest_file
    #     )
    #
    # @patch('src.generate_file.file_generator.file_transfer')
    # def test_get_file_from_mainframe(self, mock_file_transfer):
    #     mock_file_transfer_instance = Mock()
    #     mock_file_transfer.return_value = mock_file_transfer_instance
    #     self.fileGenerator.get_file_from_mainframe()
    #     mock_file_transfer_instance.transfer_file_from_mainframe.assert_called_once_with(
    #         self.fileGenerator.source_file_path,
    #         self.fileGenerator.request_id_dir,
    #         self.fileGenerator.dest_file
    #     )
    #
    # @patch('src.generate_file.file_generator.file_transfer')
    # def test_get_file_from_mainframe_exception(self, mock_file_transfer):
    #     mock_file_transfer_instance = Mock()
    #     mock_file_transfer_instance.transfer_file_from_mainframe.side_effect = Exception(CONST_TEST_EXCEPTION)
    #     mock_file_transfer.return_value = mock_file_transfer_instance
    #     with self.assertRaises(Exception) as context:
    #         self.fileGenerator.get_file_from_mainframe()
    #     self.assertTrue(CONST_TEST_EXCEPTION in str(context.exception))
    #     mock_file_transfer_instance.transfer_file_from_mainframe.assert_called_once_with(
    #         self.fileGenerator.source_file_path,
    #         self.fileGenerator.request_id_dir,
    #         self.fileGenerator.dest_file
    #     )
    #
    # def test_process_core_hr_df(self):
    #     # Create a test DataFrame with corrected date format
    #     data = {
    #         'LAST_NAME': ['Doe', 'Smith'],
    #         'FIRST_NAME': ['John', 'Jane'],
    #         'BIRTH_DATE': ['2000-01-01', '1990-31-12'],  # changed here
    #         'HIRE_DATE': ['2019-01-01', '2018-31-12'],  # changed here
    #         'TERMINATION_DATE': ['2021-01-01', '2020-12-31'],
    #         'STORE_NBR': [1, 10],
    #         'CHRG_STORE_NBR': [11, 100],
    #         'DIV_NBR': [2, 20],
    #         'CHRG_MDSE_DIV_NBR': [22, 200]
    #     }
    #     df = pd.DataFrame(data)
    #
    #     # Convert 'TERMINATION_DATE' to datetime
    #     df['TERMINATION_DATE'] = pd.to_datetime(df['TERMINATION_DATE'])
    #
    #     processed_df = self.fileGenerator.process_core_hr_df(df)
    #
    #     # Check if 'NAME' column is properly formatted
    #     self.assertEqual(processed_df['NAME'][1], 'Smith, Jane')
    #
    #     # Check if birthdate is properly split.
    #     self.assertEqual(processed_df['R01-BDAY-DD'][0], '01')
    #     self.assertEqual(processed_df['R01-BDAY-MM'][0], '01')
    #     self.assertEqual(processed_df['R01-BDAY-YY'][0], '2000')
    #
    #     # Check if hire dates are properly split.
    #     self.assertEqual(processed_df['R01-HDAY-DD'][0], '01')
    #     self.assertEqual(processed_df['R01-HDAY-MM'][0], '01')
    #     self.assertEqual(processed_df['R01-HDAY-YY'][0], '2019')
    #
    #     # Check if termination dates are properly formatted.
    #     self.assertEqual(processed_df['TERMINATION_DATE'][0], '01012021')
    #
    #     # Check if store numbers are properly formatted.
    #     self.assertEqual(processed_df['STORE_NBR'][0], '00001')
    #     self.assertEqual(processed_df['CHRG_STORE_NBR'][0], '00011')
    #
    #     # Check if division numbers are properly formatted.
    #     self.assertEqual(processed_df['DIV_NBR'][0], '002')
    #     self.assertEqual(processed_df['CHRG_MDSE_DIV_NBR'][0], '022')







