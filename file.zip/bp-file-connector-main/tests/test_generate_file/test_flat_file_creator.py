import unittest
from datetime import datetime
from unittest.mock import Mock, patch, mock_open, call
import pandas as pd
from src.generate_file.flat_file_creator import gen_flat_file

class TestGenFlatFile(unittest.TestCase):

    def setUp(self):
        self.file_path = "/path/to/file"
        self.invalid_records_path = "/path/to/invalid/records/file"
        self.layouts = {}
        self.logger = Mock()
        self.gen_flat_file = gen_flat_file(self.file_path, self.invalid_records_path, self.layouts, self.logger)

    def test_open_files(self):
        with patch("builtins.open", mock_open()) as mock_file:
            self.gen_flat_file.open_files()
            mock_file.assert_called()
            self.logger.info.assert_called_with("Files opened for writing")

    def test_close_files(self):
        self.gen_flat_file.file_pointer = Mock()
        self.gen_flat_file.invalid_records = Mock()
        self.gen_flat_file.close_files()
        self.gen_flat_file.file_pointer.close.assert_called()
        self.gen_flat_file.invalid_records.close.assert_called()
        self.logger.info.assert_called_with("File pointer closed for writing")

    def test_prepare_id_sets(self):
        dataframes_dict = {"type1": pd.DataFrame({"associate_id": [1, 2, 3]}), "type2": pd.DataFrame({"associate_id": [2, 3, 4]})}
        result = self.gen_flat_file.prepare_id_sets(dataframes_dict)
        expected = {"type1": {"1", "2", "3"}, "type2": {"2", "3", "4"}}
        self.assertEqual(result, expected)

    def test_prepare_id_sets_exception(self):
        # Mock DataFrame `astype` method to simulate an exception
        dataframes_dict = {"type1": pd.DataFrame({"associate_id": [1, 2, 3]})}
        with patch.object(pd.Series, 'astype', side_effect=Exception("Test Exception")):
            result = self.gen_flat_file.prepare_id_sets(dataframes_dict)
            self.assertIsNone(result)  # The method should return None
            self.logger.error.assert_called_with("Exception in prepare_id_sets method: Test Exception")

    def test_write_header(self):
        with patch("builtins.open", mock_open()) as mock_file:
            self.gen_flat_file.file_pointer = mock_file()
            payroll_end_date = datetime(2024, 12, 31)
            self.gen_flat_file.write_header(123, "file_type", "file_data_type", "file_filler", payroll_end_date)
            self.gen_flat_file.file_pointer.write.assert_called()
            self.logger.info.assert_called_with("Header record written successfully")

    def test_write_trailer(self):
        with patch("builtins.open", mock_open()) as mock_file:
            self.gen_flat_file.file_pointer = mock_file()
            row_count_dict = {"type1": 5, "type2": 3}
            self.gen_flat_file.layouts = {
                "trailer_record": {
                    "TOTAL-TYPE1": {'default': '0', 'positions': [(5, 13)]},
                    "TOTAL-TYPE2": {'default': '0', 'positions': [(13, 21)]}
                }
            }
            self.gen_flat_file.write_trailer(row_count_dict, "file_type")
            self.gen_flat_file.file_pointer.write.assert_called()
            self.logger.info.assert_called_with("Trailer record written successfully")

    def test_generate_fixed_length_row(self):
        row = {"col1": "value1", "col2": "value2"}
        layout = {"col1": [(0, 6)], "col2": [(6, 12)]}
        result = self.gen_flat_file.generate_fixed_length_row(row, layout)
        expected = "value1value2".ljust(250)  # 250 is max length
        self.assertEqual(result, expected)

    def test_generate_fixed_length_row_exception(self):
        row = {"col1": "value1"}  # Missing 'col2'
        layout = {"col1": [(0, 6)], "col2": [(6, 12)]}
        result = self.gen_flat_file.generate_fixed_length_row(row, layout)
        self.assertIsNone(result)
        self.logger.error.assert_called_with("Exception in generate_fixed_length_row method: 'col2'")

    def test_write_record_types(self):
        dataframes_dict = {
            "type1": pd.DataFrame({"associate_id": ["1", "2"], "column1": ["value1", "value2"]}),
            "type2": pd.DataFrame({"associate_id": ["1", "3"], "column2": ["value3", "value4"]})
        }
        self.gen_flat_file.layouts = {
            "type1": {"column1": [(0, 6)]},
            "type2": {"column2": [(6, 12)]}
        }

        with (patch("builtins.open", mock_open()) as mock_file,
              patch.object(self.gen_flat_file, "prepare_id_sets",
              return_value={"type1": {"1", "2"}, "type2": {"1", "3"}}),
              patch("pandas.DataFrame.to_csv") as mock_to_csv):
            self.gen_flat_file.file_pointer = mock_file()
            self.gen_flat_file.invalid_records = mock_file()

            row_count_dict = self.gen_flat_file.write_record_types(dataframes_dict, "associate_id")

            expected_calls = [
                call("ID 2 is missing from: type2. Present in: type1\n"),
                call("ID 3 is missing from: type1. Present in: type2\n")
            ]
            self.gen_flat_file.invalid_records.write.assert_has_calls(expected_calls, any_order=True)

            self.assertEqual(row_count_dict, {"type1": 1, "type2": 1})
            self.logger.info.assert_called_with("Record types written successfully")

    def test_start_process(self):
        with patch.object(self.gen_flat_file, 'open_files') as mock_open_files, \
             patch.object(self.gen_flat_file, 'write_header') as mock_write_header, \
             patch.object(self.gen_flat_file, 'write_record_types') as mock_write_record_types, \
             patch.object(self.gen_flat_file, 'write_trailer') as mock_write_trailer, \
             patch.object(self.gen_flat_file, 'close_files') as mock_close_files:

            dataframes_dict = Mock()
            plan_number = Mock()
            file_type = Mock()
            file_data_type = Mock()
            file_filler = Mock()
            primary_key = Mock()
            payroll_end_date = Mock()

            self.gen_flat_file.start_process(dataframes_dict, plan_number, file_type, file_data_type, file_filler, payroll_end_date, primary_key)

            mock_open_files.assert_called()
            mock_write_header.assert_called_with(plan_number, file_type, file_data_type, file_filler, payroll_end_date)
            mock_write_record_types.assert_called_with(dataframes_dict, primary_key)
            mock_write_trailer.assert_called()
            mock_close_files.assert_called()

    def test_start_process_exception(self):
        with patch.object(self.gen_flat_file, 'open_files', side_effect=Exception("Open Files Exception")):
            self.gen_flat_file.start_process({}, 123, "file_type", "file_data_type", "file_filler", "2024-12-31", "associate_id")
            self.logger.error.assert_called_with("Exception in start_process method: Open Files Exception")

if __name__ == '__main__':
    unittest.main()