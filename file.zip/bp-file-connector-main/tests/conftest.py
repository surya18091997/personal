import sys
from unittest.mock import MagicMock, patch, mock_open

sys.modules['ibm_db'] = MagicMock()
sys.modules['ibm_db_dbi'] = MagicMock()
import pytest

# Create mock exceptions
class MockGoogleAPIError(Exception):
    pass

# Create mock classes
class MockExceptions:
    GoogleAPIError = MockGoogleAPIError

class MockDataprocJob:
    def __init__(self):
        self.state = MagicMock()
        self.state.name = "RUNNING"
        self.create_time = "2024-01-01T00:00:00Z"
        self.completion_time = "2024-01-01T01:00:00Z"
        self.uuid = "test-uuid"

class MockBatchControllerClient:
    def __init__(self, client_options=None):
        self.client_options = client_options
        # Make create_batch a MagicMock
        self.create_batch = MagicMock()
        self.get_batch = MagicMock()

class MockBatch:
    def __init__(self):
        self.state = MagicMock()
        self.create_time = "2024-01-01T00:00:00Z"
        self.completion_time = "2024-01-01T01:00:00Z"
        self.uuid = "test-uuid"

class MockBatchOperationMetadata:
    def __init__(self):
        self.batch = MagicMock()
        self.create_time = "2024-01-01T00:00:00Z"
        self.done_time = "2024-01-01T01:00:00Z"
        self.state = "SUCCEEDED"

class MockEnvironmentConfig:
    def __init__(self):
        self.execution_config = MagicMock()
        self.peripherals_config = MagicMock()

class MockRuntimeConfig:
    def __init__(self):
        self.version = "1.0"
        self.properties = {}
        self.container_image = MagicMock()

class MockPySparkBatch:
    def __init__(self):
        self.main_python_file_uri = None
        self.python_file_uris = []
        self.file_uris = []
        self.args = []
        self.jar_file_uris = []
        self.archive_uris = []

class MockSparkBatch:
    def __init__(self):
        self.main_jar_file_uri = None
        self.main_class = None
        self.jar_file_uris = []
        self.file_uris = []
        self.args = []
        self.archive_uris = []

class MockBigQuery:
    def __init__(self):
        self.Client = MagicMock()
        self.query_job = MagicMock()
        self.dataset = MagicMock()
        self.table = MagicMock()

class MockDataprocTypes:
    BatchOperationMetadata = MockBatchOperationMetadata
    Batch = MockBatch
    BatchControllerClient = MockBatchControllerClient
    EnvironmentConfig = MockEnvironmentConfig
    RuntimeConfig = MockRuntimeConfig
    PySparkBatch = MockPySparkBatch
    SparkBatch = MockSparkBatch
    bigquery = MockBigQuery()

class MockDataprocV1:
    BatchControllerClient = MockBatchControllerClient
    types = MockDataprocTypes

# Update MockOperation to be a class containing Operation
class MockOperation:
    class Operation:
        def __init__(self, operation=None, **kwargs):
            self._operation = operation or MagicMock()
            self._done = False
            for key, value in kwargs.items():
                setattr(self, key, value)

        def done(self):
            return self._done

        def cancelled(self):
            return False

        def result(self):
            return self._operation

        def cancel(self):
            return MagicMock()

# Update MockGoogleCloud class
class MockGoogleCloud:
    class exceptions:
        NotFound = Exception
    storage = MagicMock()
    bigquery = MagicMock()
    dataproc_v1 = MockDataprocV1

# Update MockApiCore to include operation
class MockApiCore:
    class exceptions:
        GoogleAPIError = MockGoogleAPIError
    retry = MagicMock()
    operation = MockOperation

class MockGoogle:
    cloud = MockGoogleCloud
    api_core = MockApiCore

# Update mock_module_structure
mock_module_structure = {
    'google': MockGoogle,
    'google.cloud': MockGoogle.cloud,
    'google.cloud.dataproc_v1': MockDataprocV1,
    'google.cloud.dataproc_v1.types': MockDataprocTypes,
    'google.api_core': MockApiCore,
    'google.api_core.exceptions': MockGoogle.api_core.exceptions,
    'google.api_core.operation': MockOperation
}

def setup_mock_modules():
    """Set up all mock modules in sys.modules"""
    for module_path, mock_obj in mock_module_structure.items():
        sys.modules[module_path] = mock_obj
        # Split path and create parent modules if they don't exist
        parts = module_path.split('.')
        for i in range(1, len(parts)):
            parent_path = '.'.join(parts[:i])
            if parent_path not in sys.modules:
                sys.modules[parent_path] = type(parts[i-1], (), {})
            # Set the child module as an attribute of the parent
            setattr(sys.modules[parent_path], parts[i], mock_obj)

# Initialize mock modules
setup_mock_modules()

@pytest.fixture(autouse=True)
def mock_google_imports():
    """Fixture to ensure Google imports are mocked for each test"""
    with patch.dict(sys.modules, mock_module_structure):
        yield

class MockDB2Database:
    """Mock DB2 Database for testing"""
    def __init__(self, logger=None, key="db2_region"):
        self.testset = 'TEST'
        self.conn = MagicMock()
        self.cursor = MagicMock()
        self.logger = logger or MagicMock()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def fetchall(self, query, params=None):
        return [('1', '2', '3')]

    def fetch_chunk(self, query, chunk_size=1000, params=None):
        return [[('1', '2', '3')]]

    def close(self):
        pass

@pytest.fixture(autouse=True)
def mock_dependencies(monkeypatch):
    """Mock all external dependencies"""
    monkeypatch.setattr('src.integrations.db2_conn_helper.DB2IDatabase', MockDB2Database)
    monkeypatch.setattr('src.integrations.bigquery_conn.BigQueryDatabase', MagicMock())
    monkeypatch.setattr('pymongo.MongoClient', MagicMock())

@pytest.fixture
def mock_logger():
    """Create a mock logger for testing"""
    logger = MagicMock()
    logger.info = MagicMock()
    logger.error = MagicMock()
    logger.warning = MagicMock()
    logger.debug = MagicMock()
    return logger

@pytest.fixture
def mock_config():
    """Mock configuration values"""
    return {
        'logging': {'level': 'INFO'},
        'db2_connection_file_path': '/mock/path/db2_connection.yaml',
        'gcs_connection_file_path': '/mock/path/gcs_connection.json',
        'mongodb_connection_file_path': '/mock/path/mongodb_connection.json'
    }

@pytest.fixture(autouse=True)
def mock_postgres():
    with patch('src.utils.common_utils.PostgresGCPConnection') as mock:
        mock_instance = MagicMock()
        mock_instance.__enter__.return_value = mock_instance
        mock_instance.__exit__.return_value = None
        mock_instance.execute_query.return_value = []
        mock_instance.execute_nonquery.return_value = None
        mock_instance.commit.return_value = None
        mock.return_value = mock_instance
        yield mock

# Also add PostgreSQL config mock
@pytest.fixture(autouse=True)
def mock_postgres_config():
    with patch('os.path.exists') as mock_exists, \
         patch('builtins.open', mock_open(read_data='{"sqlDbConfig": {"host": "test"}}')):
        mock_exists.return_value = True
        yield