class MockPostgresConnection:
    def __init__(self, logger=None):
        self.logger = logger

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def execute_nonquery(self, query, values):
        return True

    def commit(self):
        pass