import pytest
from unittest.mock import patch, MagicMock
from dataclasses import dataclass
from enum import Enum

from src.report_generator.input_configuration import (
    FlatFileReadConfiguration,
    FileType
)


class TestFileType:
    """Test suite for the FileType enum"""

    def test_file_type_enum_values(self):
        """Test that FileType enum has correct values"""
        assert FileType.GCS.value == 1
        assert FileType.AZURE.value == 2

    def test_file_type_enum_members(self):
        """Test FileType enum members"""
        file_types = list(FileType)
        assert len(file_types) == 2
        assert FileType.GCS in file_types
        assert FileType.AZURE in file_types

    def test_file_type_enum_names(self):
        """Test FileType enum names"""
        assert FileType.GCS.name == "GCS"
        assert FileType.AZURE.name == "AZURE"

    def test_file_type_enum_equality(self):
        """Test FileType enum equality"""
        assert FileType.GCS.value == 1
        assert FileType.AZURE.value == 2
        assert FileType.GCS != FileType.AZURE

    def test_file_type_enum_string_representation(self):
        """Test string representation of FileType enum"""
        assert str(FileType.GCS) == "FileType.GCS"
        assert str(FileType.AZURE) == "FileType.AZURE"


class TestFlatFileReadConfiguration:
    """Test suite for the FlatFileReadConfiguration dataclass"""

    def test_flat_file_read_configuration_creation_minimal(self):
        """Test creation with minimal required parameters"""
        config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=100
        )
        
        assert config.bucket == "test-bucket"
        assert config.remote_file == "test-file.dat"
        assert config.layout == "layout.json"
        assert config.file == "local-file.txt"
        assert config.fixed_size == 100
        assert config.ignore_errors is False  # Default value
        assert config.type == FileType.GCS  # Default value

    def test_flat_file_read_configuration_creation_full(self):
        """Test creation with all parameters specified"""
        config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=250,
            ignore_errors=True,
            type=FileType.AZURE
        )
        
        assert config.bucket == "test-bucket"
        assert config.remote_file == "test-file.dat"
        assert config.layout == "layout.json"
        assert config.file == "local-file.txt"
        assert config.fixed_size == 250
        assert config.ignore_errors is True
        assert config.type == FileType.AZURE

    def test_flat_file_read_configuration_default_values(self):
        """Test default values for optional parameters"""
        config = FlatFileReadConfiguration(
            bucket="bucket",
            remote_file="remote",
            layout="layout",
            file="file",
            fixed_size=100
        )
        
        # Test default values
        assert config.ignore_errors is False
        assert config.type == FileType.GCS

    def test_flat_file_read_configuration_with_gcs_type(self):
        """Test configuration with GCS file type"""
        config = FlatFileReadConfiguration(
            bucket="gcs-bucket",
            remote_file="path/to/gcs/file.dat",
            layout="layouts/gcs_layout.json",
            file="local_gcs_file.txt",
            fixed_size=150,
            ignore_errors=False,
            type=FileType.GCS
        )
        
        assert config.type == FileType.GCS
        assert config.bucket == "gcs-bucket"
        assert "gcs" in config.remote_file
        assert config.ignore_errors is False

    def test_flat_file_read_configuration_with_azure_type(self):
        """Test configuration with Azure file type"""
        config = FlatFileReadConfiguration(
            bucket="azure-container",
            remote_file="path/to/azure/file.dat",
            layout="layouts/azure_layout.json",
            file="local_azure_file.txt",
            fixed_size=200,
            ignore_errors=True,
            type=FileType.AZURE
        )
        
        assert config.type == FileType.AZURE
        assert config.bucket == "azure-container"
        assert "azure" in config.remote_file
        assert config.ignore_errors is True

    def test_flat_file_read_configuration_equality(self):
        """Test equality comparison of FlatFileReadConfiguration instances"""
        config1 = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=100,
            ignore_errors=False,
            type=FileType.GCS
        )
        
        config2 = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=100,
            ignore_errors=False,
            type=FileType.GCS
        )
        
        config3 = FlatFileReadConfiguration(
            bucket="different-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=100,
            ignore_errors=False,
            type=FileType.GCS
        )
        
        assert config1 == config2
        assert config1 != config3

    def test_flat_file_read_configuration_attribute_access(self):
        """Test direct attribute access and modification"""
        config = FlatFileReadConfiguration(
            bucket="initial-bucket",
            remote_file="initial-file.dat",
            layout="initial-layout.json",
            file="initial-file.txt",
            fixed_size=100
        )
        
        # Test initial values
        assert config.bucket == "initial-bucket"
        assert config.remote_file == "initial-file.dat"
        assert config.layout == "initial-layout.json"
        assert config.file == "initial-file.txt"
        assert config.fixed_size == 100
        
        # Test attribute modification
        config.bucket = "modified-bucket"
        config.remote_file = "modified-file.dat"
        config.layout = "modified-layout.json"
        config.file = "modified-file.txt"
        config.fixed_size = 200
        config.ignore_errors = True
        config.type = FileType.AZURE
        
        assert config.bucket == "modified-bucket"
        assert config.remote_file == "modified-file.dat"
        assert config.layout == "modified-layout.json"
        assert config.file == "modified-file.txt"
        assert config.fixed_size == 200
        assert config.ignore_errors is True
        assert config.type == FileType.AZURE

    def test_flat_file_read_configuration_with_none_values(self):
        """Test FlatFileReadConfiguration with None values"""
        config = FlatFileReadConfiguration(
            bucket=None,
            remote_file=None,
            layout=None,
            file=None,
            fixed_size=None
        )
        
        assert config.bucket is None
        assert config.remote_file is None
        assert config.layout is None
        assert config.file is None
        assert config.fixed_size is None
        # Defaults should still apply
        assert config.ignore_errors is False
        assert config.type == FileType.GCS

    def test_flat_file_read_configuration_with_empty_strings(self):
        """Test FlatFileReadConfiguration with empty string values"""
        config = FlatFileReadConfiguration(
            bucket="",
            remote_file="",
            layout="",
            file="",
            fixed_size=0
        )
        
        assert config.bucket == ""
        assert config.remote_file == ""
        assert config.layout == ""
        assert config.file == ""
        assert config.fixed_size == 0

    def test_flat_file_read_configuration_with_long_values(self):
        """Test FlatFileReadConfiguration with very long string values"""
        long_path = "/very/long/path/that/represents/a/real/world/scenario/with/deep/directory/structure/and/long/filenames/that/might/be/encountered/in/production/environments/file.dat"
        
        config = FlatFileReadConfiguration(
            bucket="bucket-with-very-long-name-that-might-exist-in-real-world-scenarios",
            remote_file=long_path,
            layout="layouts/with/deep/structure/layout_file_with_long_name.json",
            file="local_files/with/deep/structure/local_file_with_long_name.txt",
            fixed_size=999999
        )
        
        assert len(config.bucket) > 50
        assert len(config.remote_file) > 100
        assert len(config.layout) > 50
        assert len(config.file) > 50
        assert config.fixed_size == 999999

    def test_flat_file_read_configuration_with_special_characters(self):
        """Test FlatFileReadConfiguration with special characters"""
        config = FlatFileReadConfiguration(
            bucket="bucket-with-special-chars_123",
            remote_file="path/with spaces/file-name_2023.dat",
            layout="layouts/layout_file-v2.json",
            file="local files/output_file-2023.txt",
            fixed_size=100
        )
        
        assert "special-chars" in config.bucket
        assert " " in config.remote_file
        assert "-" in config.layout
        assert " " in config.file

    def test_flat_file_read_configuration_dataclass_properties(self):
        """Test that FlatFileReadConfiguration behaves as a proper dataclass"""
        # Test that it's a dataclass
        assert hasattr(FlatFileReadConfiguration, '__dataclass_fields__')
        
        # Test field names
        field_names = set(FlatFileReadConfiguration.__dataclass_fields__.keys())
        expected_fields = {'bucket', 'remote_file', 'layout', 'file', 'fixed_size', 'ignore_errors', 'type'}
        assert field_names == expected_fields
        
        # Test field types
        fields = FlatFileReadConfiguration.__dataclass_fields__
        assert fields['bucket'].type == str
        assert fields['remote_file'].type == str
        assert fields['layout'].type == str
        assert fields['file'].type == str
        assert fields['fixed_size'].type == int
        assert fields['ignore_errors'].type == bool
        assert fields['type'].type == FileType

    def test_flat_file_read_configuration_default_values_behavior(self):
        """Test default values behavior in detail"""
        config = FlatFileReadConfiguration(
            bucket="test",
            remote_file="test",
            layout="test",
            file="test",
            fixed_size=100
        )
        
        # Test default values
        assert config.ignore_errors is False
        assert isinstance(config.ignore_errors, bool)
        assert config.type == FileType.GCS
        assert isinstance(config.type, FileType)

    def test_flat_file_read_configuration_repr(self):
        """Test the repr representation of FlatFileReadConfiguration"""
        config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="layout.json",
            file="local-file.txt",
            fixed_size=100,
            ignore_errors=True,
            type=FileType.AZURE
        )
        
        repr_str = repr(config)
        assert "FlatFileReadConfiguration" in repr_str
        assert "test-bucket" in repr_str
        assert "test-file.dat" in repr_str
        assert "layout.json" in repr_str
        assert "local-file.txt" in repr_str
        assert "100" in repr_str
        assert "True" in repr_str
        assert "AZURE" in repr_str

    def test_flat_file_read_configuration_integration_scenarios(self):
        """Test FlatFileReadConfiguration in various integration scenarios"""
        # Scenario 1: Eligibility file processing
        eligibility_config = FlatFileReadConfiguration(
            bucket="eligibility-bucket",
            remote_file="outgoing/eligibility/US_Eligibility_File",
            layout="src/report_generator/flat_file_layouts/OUTGOING_ELIGIBILITY_FILE_LAYOUT.json",
            file="src/report_generator/flat_files/OUTGOING_US_ELIGIBILITY_FILE.txt",
            fixed_size=250,
            ignore_errors=False,
            type=FileType.GCS
        )
        
        assert "eligibility" in eligibility_config.bucket.lower()
        assert "eligibility" in eligibility_config.remote_file.lower()
        assert eligibility_config.fixed_size == 250
        assert eligibility_config.type == FileType.GCS
        
        # Scenario 2: Loan file processing with error tolerance
        loan_config = FlatFileReadConfiguration(
            bucket="loan-bucket",
            remote_file="outgoing/loan/us/US_LOAN_File",
            layout="src/report_generator/flat_file_layouts/OUTBOUND_LOAN_FILE_LAYOUT.json",
            file="src/report_generator/flat_files/OUTBOUND_LOAN_FILE_US.txt",
            fixed_size=150,
            ignore_errors=True,
            type=FileType.GCS
        )
        
        assert "loan" in loan_config.bucket.lower()
        assert loan_config.ignore_errors is True
        assert loan_config.fixed_size == 150
        
        # Scenario 3: Azure hardship file processing
        hardship_config = FlatFileReadConfiguration(
            bucket="hardship-container",
            remote_file="/mnt/azure/incoming/hardship/archive/HARDSHIP_US_INBOUND.txt",
            layout="src/report_generator/flat_file_layouts/INBOUND_HARDSHIP_FILE_LAYOUT.json",
            file="src/report_generator/flat_files/INBOUND_HARDSHIP_FILE_US.txt",
            fixed_size=100,
            ignore_errors=True,
            type=FileType.AZURE
        )
        
        assert hardship_config.type == FileType.AZURE
        assert "azure" in hardship_config.remote_file
        assert hardship_config.ignore_errors is True

    def test_flat_file_read_configuration_with_numeric_values(self):
        """Test FlatFileReadConfiguration with various numeric values"""
        test_cases = [
            {"fixed_size": 0, "description": "zero size"},
            {"fixed_size": 1, "description": "minimum size"},
            {"fixed_size": 100, "description": "typical size"},
            {"fixed_size": 1000, "description": "large size"},
            {"fixed_size": 999999, "description": "maximum realistic size"}
        ]
        
        for case in test_cases:
            config = FlatFileReadConfiguration(
                bucket="test",
                remote_file="test",
                layout="test",
                file="test",
                fixed_size=case["fixed_size"]
            )
            
            assert config.fixed_size == case["fixed_size"]
            assert isinstance(config.fixed_size, int)

    def test_flat_file_read_configuration_boolean_combinations(self):
        """Test all combinations of boolean ignore_errors values"""
        configs = [
            (True, "should ignore errors"),
            (False, "should not ignore errors")
        ]
        
        for ignore_errors, description in configs:
            config = FlatFileReadConfiguration(
                bucket="test",
                remote_file="test",
                layout="test",
                file="test",
                fixed_size=100,
                ignore_errors=ignore_errors
            )
            
            assert config.ignore_errors == ignore_errors
            assert isinstance(config.ignore_errors, bool)

    def test_flat_file_read_configuration_file_type_combinations(self):
        """Test all FileType combinations"""
        for file_type in FileType:
            config = FlatFileReadConfiguration(
                bucket="test",
                remote_file="test",
                layout="test",
                file="test",
                fixed_size=100,
                type=file_type
            )
            
            assert config.type == file_type
            assert isinstance(config.type, FileType)
