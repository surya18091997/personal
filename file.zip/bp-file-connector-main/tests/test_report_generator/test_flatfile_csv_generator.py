import pytest
from unittest.mock import patch, MagicMock, mock_open
import os
import tempfile
import logging

from src.report_generator.flatfile_csv_generator import (
    FlatFileToCSVGenerator, 
    FlatFileProcessingError
)
from src.report_generator.input_configuration import FlatFileReadConfiguration, FileType


class TestFlatFileToCSVGenerator:
    """Test suite for the FlatFileToCSVGenerator class"""

    @pytest.fixture
    def generator(self):
        """Create a FlatFileToCSVGenerator instance for testing"""
        return FlatFileToCSVGenerator()

    @pytest.fixture
    def sample_config(self):
        """Create a sample FlatFileReadConfiguration for testing"""
        return FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="test-layout.json",
            file="test-input.txt",
            fixed_size=100,
            ignore_errors=False,
            type=FileType.GCS
        )

    @pytest.fixture
    def sample_config_ignore_errors(self):
        """Create a sample config with ignore_errors=True"""
        return FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="test-layout.json",
            file="test-input.txt",
            fixed_size=100,
            ignore_errors=True,
            type=FileType.GCS
        )

    def test_generator_initialization(self, generator):
        """Test FlatFileToCSVGenerator initialization"""
        assert isinstance(generator, FlatFileToCSVGenerator)
        assert hasattr(generator, 'logger')
        assert isinstance(generator.logger, logging.Logger)

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_generate_successful_processing(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test successful file processing"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 0

        # Create mock files
        with patch('os.makedirs'):
            result = generator.generate(sample_config)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_run.assert_called_once()

    @patch('os.path.exists')
    def test_generate_file_not_found(self, mock_exists, generator, sample_config):
        """Test error handling when input file doesn't exist"""
        mock_exists.return_value = False

        with pytest.raises(FlatFileProcessingError, match="Input file does not exist"):
            generator.generate(sample_config)

    @patch('os.path.exists')
    def test_generate_layout_not_found(self, mock_exists, generator, sample_config):
        """Test error handling when layout file doesn't exist"""
        def exists_side_effect(path):
            return path == sample_config.file  # Only input file exists
        
        mock_exists.side_effect = exists_side_effect

        with pytest.raises(FlatFileProcessingError, match="Layout file does not exist"):
            generator.generate(sample_config)

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_generate_conversion_failure(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test error handling when conversion fails"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 1  # Simulate failure

        with patch('os.makedirs'):
            result = generator.generate(sample_config)

        assert result == "None"  # Returns "None" on failure

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_generate_conversion_failure_ignore_errors(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config_ignore_errors):
        """Test conversion failure with ignore_errors=True"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 1  # Simulate failure

        with patch('os.makedirs'):
            result = generator.generate(sample_config_ignore_errors)

        assert result == "None"  # Still returns "None" on failure even with ignore_errors

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_empty_file_handling(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test handling of empty input files"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 0  # Empty file
        mock_run.return_value = 0

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'warning') as mock_warning:
                result = generator.generate(sample_config)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_warning.assert_called_with("File test-input.txt is empty")

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_file_size_error_handling(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test handling of file size retrieval errors"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.side_effect = OSError("Permission denied")
        mock_run.return_value = 0

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'warning') as mock_warning:
                result = generator.generate(sample_config)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_warning.assert_called_with("Could not get file size for test-input.txt: Permission denied")

    def test_validate_config_none(self, generator):
        """Test validation with None config"""
        with pytest.raises(FlatFileProcessingError, match="Configuration cannot be None"):
            generator._validate_config(None)

    @patch('os.path.exists')
    def test_validate_config_missing_file(self, mock_exists, generator, sample_config):
        """Test validation with missing input file"""
        mock_exists.return_value = False

        with pytest.raises(FlatFileProcessingError, match="Input file does not exist"):
            generator._validate_config(sample_config)

    @patch('os.path.exists')
    def test_validate_config_missing_layout(self, mock_exists, generator, sample_config):
        """Test validation with missing layout file"""
        def exists_side_effect(path):
            return path == sample_config.file  # Only input file exists
        
        mock_exists.side_effect = exists_side_effect

        with pytest.raises(FlatFileProcessingError, match="Layout file does not exist"):
            generator._validate_config(sample_config)

    @patch('os.path.exists')
    def test_validate_config_success(self, mock_exists, generator, sample_config):
        """Test successful config validation"""
        mock_exists.return_value = True

        with patch.object(generator.logger, 'info') as mock_info:
            generator._validate_config(sample_config)

        mock_info.assert_any_call("Input file validation successful: test-input.txt")
        mock_info.assert_any_call("Layout file validation successful: test-layout.json")
        mock_info.assert_any_call("All configuration validations passed successfully")

    @patch('os.makedirs')
    def test_ensure_output_directory_success(self, mock_makedirs, generator):
        """Test successful output directory creation"""
        generator._ensure_output_directory("/test/output")
        mock_makedirs.assert_called_once_with("/test/output", exist_ok=True)

    @patch('os.makedirs')
    def test_ensure_output_directory_failure(self, mock_makedirs, generator):
        """Test output directory creation failure"""
        mock_makedirs.side_effect = PermissionError("Permission denied")

        with pytest.raises(FlatFileProcessingError, match="Failed to create output directory"):
            generator._ensure_output_directory("/test/output")

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_unexpected_exception_propagation(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test handling of unexpected exceptions"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.side_effect = Exception("Unexpected error")

        with patch('os.makedirs'):
            with pytest.raises(FlatFileProcessingError, match="Unexpected error processing file"):
                generator.generate(sample_config)

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_unexpected_exception_ignore_errors(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config_ignore_errors):
        """Test handling of unexpected exceptions with ignore_errors=True"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.side_effect = Exception("Unexpected error")

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'warning') as mock_warning:
                result = generator.generate(sample_config_ignore_errors)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_warning.assert_called()

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_validation_error_ignore_errors(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config_ignore_errors):
        """Test validation error handling with ignore_errors=True"""
        # Setup mocks to cause validation error
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = False  # File doesn't exist

        with patch.object(generator.logger, 'warning') as mock_warning:
            result = generator.generate(sample_config_ignore_errors)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_warning.assert_called()

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_logging_messages(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test that appropriate logging messages are generated"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 0

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'info') as mock_info:
                generator.generate(sample_config)

        # Verify info messages
        mock_info.assert_any_call("Processing file test-input.txt with layout test-layout.json")
        mock_info.assert_any_call("Ignore errors setting: False")
        mock_info.assert_any_call("File size of test-input.txt: 1000 bytes")
        mock_info.assert_any_call("Starting conversion with ignoreConversionErrors=False")
        mock_info.assert_any_call("Conversion completed with return code: 0")
        mock_info.assert_any_call("Successfully processed file test-input.txt")

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_ebcdic_parser_parameters(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test that ebcdic_parser.run is called with correct parameters"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 0

        with patch('os.makedirs'):
            generator.generate(sample_config)

        # Verify run was called with correct parameters
        mock_run.assert_called_once_with(
            inputFile="test-input.txt",
            outputFolder="/test/path/src/report_generator/output_temp",
            layoutFile="test-layout.json",
            encodingName="utf_8",
            outputDelimiter="#####",  # Actual DELIMITER value
            ignoreConversionErrors=False,
            outputFileExtension=".csv",
            debug=False,
            stripDelimiterValues=False,
            logfolder="/test/path/src/report_generator/output_temp"
        )

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_directory_creation_calls(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test that directories are created appropriately"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 0

        with patch('os.makedirs') as mock_makedirs:
            generator.generate(sample_config)

        # Should be called twice - once for output folder, once for log folder
        assert mock_makedirs.call_count == 2
        expected_path = "/test/path/src/report_generator/output_temp"
        mock_makedirs.assert_any_call(expected_path, exist_ok=True)

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_large_file_processing(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test processing of large files"""
        # Setup mocks for large file
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000000000  # 1GB file
        mock_run.return_value = 0

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'info') as mock_info:
                result = generator.generate(sample_config)

        assert result == "/test/path/src/report_generator/output_temp"
        mock_info.assert_any_call("File size of test-input.txt: 1000000000 bytes")

    def test_azure_file_type_processing(self, generator):
        """Test processing with Azure file type"""
        azure_config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test-file.dat",
            layout="test-layout.json",
            file="test-input.txt",
            fixed_size=100,
            ignore_errors=False,
            type=FileType.AZURE
        )

        with patch('os.path.exists', return_value=True):
            with patch('os.getcwd', return_value="/test/path"):
                with patch('os.path.getsize', return_value=1000):
                    with patch('src.report_generator.flatfile_csv_generator.run', return_value=0):
                        with patch('os.makedirs'):
                            result = generator.generate(azure_config)

        assert result == "/test/path/src/report_generator/output_temp"

    @patch('src.report_generator.flatfile_csv_generator.run')
    @patch('os.path.getsize')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_error_logging_on_failure(self, mock_getcwd, mock_exists, mock_getsize, mock_run, generator, sample_config):
        """Test error logging when conversion fails"""
        # Setup mocks
        mock_getcwd.return_value = "/test/path"
        mock_exists.return_value = True
        mock_getsize.return_value = 1000
        mock_run.return_value = 1  # Simulate failure

        with patch('os.makedirs'):
            with patch.object(generator.logger, 'error') as mock_error:
                result = generator.generate(sample_config)

        assert result == "None"
        mock_error.assert_called_with(
            "Failed to process file test-input.txt and layout test-layout.json with return code 1"
        )
