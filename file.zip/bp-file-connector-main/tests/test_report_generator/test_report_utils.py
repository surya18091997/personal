import pytest
import os
from unittest.mock import patch, MagicMock
from enum import Enum

from src.report_generator.report_utils import (
    ReportFileType,
    file_type_dict,
    file_path_layout,
    file_path_flat,
    file_path,
    reverse_integer_lastbyte_conversion,
    convert_digits_to_decimal
)


class TestReportFileType:
    """Test suite for the ReportFileType enum"""

    def test_report_file_type_enum_values(self):
        """Test that ReportFileType enum has correct values"""
        assert ReportFileType.FLAT.value == 1
        assert ReportFileType.LAYOUT.value == 2

    def test_report_file_type_enum_members(self):
        """Test ReportFileType enum members"""
        file_types = list(ReportFileType)
        assert len(file_types) == 2
        assert ReportFileType.FLAT in file_types
        assert ReportFileType.LAYOUT in file_types

    def test_report_file_type_enum_names(self):
        """Test ReportFileType enum names"""
        assert ReportFileType.FLAT.name == "FLAT"
        assert ReportFileType.LAYOUT.name == "LAYOUT"

    def test_report_file_type_enum_equality(self):
        """Test ReportFileType enum equality"""
        assert ReportFileType.FLAT.value == 1
        assert ReportFileType.LAYOUT.value == 2
        assert ReportFileType.FLAT != ReportFileType.LAYOUT

    def test_file_type_dict_structure(self):
        """Test file_type_dict has correct structure"""
        assert isinstance(file_type_dict, dict)
        assert len(file_type_dict) == 2
        assert ReportFileType.FLAT in file_type_dict
        assert ReportFileType.LAYOUT in file_type_dict
        
        assert file_type_dict[ReportFileType.FLAT] == "src/report_generator/flat_files"
        assert file_type_dict[ReportFileType.LAYOUT] == "src/report_generator/flat_file_layouts"


class TestFilePathFunctions:
    """Test suite for file path utility functions"""

    @patch('os.getcwd')
    def test_file_path_layout(self, mock_getcwd):
        """Test file_path_layout function"""
        mock_getcwd.return_value = "/test/directory"
        
        result = file_path_layout("test_layout.json")
        expected = "/test/directory/src/report_generator/flat_file_layouts/test_layout.json"
        assert result == expected

    @patch('os.getcwd')
    def test_file_path_flat(self, mock_getcwd):
        """Test file_path_flat function"""
        mock_getcwd.return_value = "/test/directory"
        
        result = file_path_flat("test_file.txt")
        expected = "/test/directory/src/report_generator/flat_files/test_file.txt"
        assert result == expected

    @patch('os.getcwd')
    def test_file_path_with_flat_type(self, mock_getcwd):
        """Test file_path function with FLAT type"""
        mock_getcwd.return_value = "/test/directory"
        
        result = file_path(ReportFileType.FLAT, "test_file.txt")
        expected = "/test/directory/src/report_generator/flat_files/test_file.txt"
        assert result == expected

    @patch('os.getcwd')
    def test_file_path_with_layout_type(self, mock_getcwd):
        """Test file_path function with LAYOUT type"""
        mock_getcwd.return_value = "/test/directory"
        
        result = file_path(ReportFileType.LAYOUT, "test_layout.json")
        expected = "/test/directory/src/report_generator/flat_file_layouts/test_layout.json"
        assert result == expected

    @patch('os.getcwd')
    def test_file_path_with_different_filenames(self, mock_getcwd):
        """Test file_path functions with various filename patterns"""
        mock_getcwd.return_value = "/base"
        
        test_cases = [
            "simple.txt",
            "file_with_underscores.json",
            "file-with-dashes.xml",
            "FILE_UPPERCASE.TXT",
            "file.with.dots.csv",
            "file with spaces.txt",
            "very_long_filename_that_might_be_used_in_real_scenarios.dat",
            "123_numeric_prefix.txt",
            "file_123_numeric_suffix.json"
        ]
        
        for filename in test_cases:
            flat_result = file_path_flat(filename)
            layout_result = file_path_layout(filename)
            
            assert filename in flat_result
            assert filename in layout_result
            assert "flat_files" in flat_result
            assert "flat_file_layouts" in layout_result

    @patch('os.getcwd')
    def test_file_path_empty_filename(self, mock_getcwd):
        """Test file_path functions with empty filename"""
        mock_getcwd.return_value = "/test"
        
        flat_result = file_path_flat("")
        layout_result = file_path_layout("")
        
        assert flat_result.endswith("flat_files/")
        assert layout_result.endswith("flat_file_layouts/")

    @patch('os.getcwd')
    def test_file_path_different_working_directories(self, mock_getcwd):
        """Test file_path functions with different working directories"""
        test_directories = [
            "/",
            "/home/user",
            "/opt/application",
            "/var/lib/app",
            "C:\\Windows\\System32",  # Windows path
            "/very/deep/directory/structure/that/might/exist"
        ]
        
        for directory in test_directories:
            mock_getcwd.return_value = directory
            
            result = file_path_flat("test.txt")
            assert result.startswith(directory)
            assert "test.txt" in result


class TestReverseIntegerLastbyteConversion:
    """Test suite for reverse_integer_lastbyte_conversion function"""

    def test_reverse_integer_lastbyte_conversion_basic_cases(self):
        """Test basic conversion cases"""
        # Test with overpunch character '{'
        assert reverse_integer_lastbyte_conversion("123{") == 1230
        
        # Test with other overpunch characters (assuming standard EBCDIC mapping)
        # Note: The actual mapping depends on ord(overpunch_char) - 64
        test_cases = [
            ("12{", 120),  # '{' should map to '0'
            ("0{", 0),
            ("100{", 1000)
        ]
        
        for input_str, expected in test_cases:
            result = reverse_integer_lastbyte_conversion(input_str)
            assert result == expected

    def test_reverse_integer_lastbyte_conversion_with_integers(self):
        """Test conversion with integer input"""
        test_cases = [0, 42, 123, 999, 1000000]
        
        for test_int in test_cases:
            result = reverse_integer_lastbyte_conversion(test_int)
            assert result == str(test_int)

    def test_reverse_integer_lastbyte_conversion_edge_cases(self):
        """Test edge cases"""
        # Test with None
        assert reverse_integer_lastbyte_conversion(None) == 0
        
        # Test with empty string
        assert reverse_integer_lastbyte_conversion("") == 0
        
        # Test with "0" string
        assert reverse_integer_lastbyte_conversion("0") == 0

    def test_reverse_integer_lastbyte_conversion_invalid_input(self):
        """Test error handling for invalid input"""
        # Test with non-string, non-integer input - function returns 0 for invalid input
        result = reverse_integer_lastbyte_conversion([1, 2, 3])
        assert result == 0
        
        result = reverse_integer_lastbyte_conversion({"key": "value"})
        assert result == 0

    def test_reverse_integer_lastbyte_conversion_single_character(self):
        """Test conversion with single character input"""
        result = reverse_integer_lastbyte_conversion("{")
        # Single character case: empty number_part + digit '0' = int("0") = 0
        assert result == 0

    def test_reverse_integer_lastbyte_conversion_various_overpunch_chars(self):
        """Test with various overpunch characters"""
        # Test different overpunch characters
        # Note: The actual behavior depends on the specific EBCDIC character mapping
        test_chars = ["A", "B", "C", "D", "E", "F", "G", "H", "I"]
        
        for char in test_chars:
            input_str = f"123{char}"
            try:
                result = reverse_integer_lastbyte_conversion(input_str)
                # Should return an integer
                assert isinstance(result, int)
            except Exception:
                # Some characters might not be valid overpunch characters
                pass

    def test_reverse_integer_lastbyte_conversion_long_numbers(self):
        """Test conversion with long number strings"""
        test_cases = [
            "1234567890{",
            "999999999{",
            "000000001{"
        ]
        
        for test_case in test_cases:
            result = reverse_integer_lastbyte_conversion(test_case)
            assert isinstance(result, int)
            # The result should be based on the number part + converted last character

    def test_reverse_integer_lastbyte_conversion_exception_handling(self):
        """Test that exceptions are properly raised when conversion fails"""
        # Create a scenario that would cause an exception in ord() function
        # by patching ord to raise an exception
        with patch('builtins.ord', side_effect=ValueError("Invalid character")):
            with pytest.raises(ValueError):
                reverse_integer_lastbyte_conversion("123A")


class TestConvertDigitsToDecimal:
    """Test suite for convert_digits_to_decimal function"""

    def test_convert_digits_to_decimal_zero(self):
        """Test conversion of zero"""
        assert convert_digits_to_decimal(0) == "0.00"

    def test_convert_digits_to_decimal_basic_cases(self):
        """Test basic conversion cases"""
        test_cases = [
            (100, "1.00"),
            (12345, "123.45"),
            (1234567, "12345.67"),
            (999999, "9999.99")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_less_than_100(self):
        """Test conversion for values less than 100"""
        test_cases = [
            (1, "0.01"),
            (10, "0.10"),
            (50, "0.50"),
            (99, "0.99")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_exactly_100(self):
        """Test conversion for exactly 100"""
        assert convert_digits_to_decimal(100) == "1.00"

    def test_convert_digits_to_decimal_large_numbers(self):
        """Test conversion for large numbers"""
        test_cases = [
            (1000000, "10000.00"),
            (9999999, "99999.99"),
            (12345678, "123456.78"),
            (100000000, "1000000.00")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_single_digits(self):
        """Test conversion for single digit numbers"""
        test_cases = [
            (1, "0.01"),
            (2, "0.02"),
            (5, "0.05"),
            (9, "0.09")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_two_digits(self):
        """Test conversion for two digit numbers"""
        test_cases = [
            (10, "0.10"),
            (25, "0.25"),
            (50, "0.50"),
            (75, "0.75"),
            (99, "0.99")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_three_digits(self):
        """Test conversion for three digit numbers"""
        test_cases = [
            (100, "1.00"),
            (150, "1.50"),
            (250, "2.50"),
            (999, "9.99")
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected

    def test_convert_digits_to_decimal_decimal_precision(self):
        """Test that decimal precision is always maintained"""
        test_cases = [
            (1, "0.01"),      # Should have 2 decimal places
            (10, "0.10"),     # Should maintain trailing zero
            (100, "1.00"),    # Should maintain trailing zeros
            (101, "1.01"),    # Should show both decimal digits
            (110, "1.10")     # Should maintain one trailing zero
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected
            # Verify it always has exactly 2 decimal places
            decimal_part = result.split('.')[1]
            assert len(decimal_part) == 2

    def test_convert_digits_to_decimal_return_type(self):
        """Test that function always returns a string"""
        test_cases = [0, 1, 100, 12345, 9999999]
        
        for input_val in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert isinstance(result, str)

    def test_convert_digits_to_decimal_format_consistency(self):
        """Test that format is consistent across different inputs"""
        test_cases = [1, 10, 100, 1000, 10000]
        
        for input_val in test_cases:
            result = convert_digits_to_decimal(input_val)
            # Should always contain exactly one decimal point
            assert result.count('.') == 1
            # Should always have format X.XX or XX.XX etc.
            parts = result.split('.')
            assert len(parts) == 2
            assert len(parts[1]) == 2  # Always 2 decimal places

    def test_convert_digits_to_decimal_negative_numbers(self):
        """Test behavior with negative numbers (if supported)"""
        # Note: The function might not be designed for negative numbers
        # This test documents the current behavior
        try:
            result = convert_digits_to_decimal(-100)
            # If it doesn't raise an error, document the behavior
            assert isinstance(result, str)
        except Exception:
            # If it raises an error, that's also valid behavior to test
            pass

    def test_convert_digits_to_decimal_real_world_scenarios(self):
        """Test with real-world financial scenarios"""
        # Scenarios that might occur in financial/payroll systems
        test_cases = [
            (125050, "1250.50"),  # $1,250.50
            (50000, "500.00"),    # $500.00
            (175, "1.75"),        # $1.75
            (25, "0.25"),         # $0.25
            (500000, "5000.00"),  # $5,000.00
            (1, "0.01")           # $0.01
        ]
        
        for input_val, expected in test_cases:
            result = convert_digits_to_decimal(input_val)
            assert result == expected


class TestReportUtilsIntegration:
    """Integration tests for report_utils module"""

    @patch('os.getcwd')
    def test_file_path_functions_integration(self, mock_getcwd):
        """Test that file path functions work together correctly"""
        mock_getcwd.return_value = "/app"
        
        # Test that both functions use the same base structure
        flat_path = file_path_flat("test.txt")
        layout_path = file_path_layout("test.json")
        
        assert flat_path.startswith("/app/src/report_generator/")
        assert layout_path.startswith("/app/src/report_generator/")
        assert "flat_files" in flat_path
        assert "flat_file_layouts" in layout_path

    def test_conversion_functions_integration(self):
        """Test that conversion functions work with typical data flow"""
        # Simulate a typical data processing scenario
        original_value = 125050
        
        # Convert to decimal format
        decimal_result = convert_digits_to_decimal(original_value)
        assert decimal_result == "1250.50"
        
        # Test that the decimal format is suitable for further processing
        parts = decimal_result.split('.')
        whole_part = int(parts[0])
        decimal_part = int(parts[1])
        
        assert whole_part == 1250
        assert decimal_part == 50

    def test_module_constants_consistency(self):
        """Test that module constants are consistent"""
        # Verify that file_type_dict keys match ReportFileType enum values
        for file_type in ReportFileType:
            assert file_type in file_type_dict
        
        # Verify that all dict values are strings
        for path in file_type_dict.values():
            assert isinstance(path, str)
            assert path.startswith("src/report_generator/")

    def test_error_handling_consistency(self):
        """Test that error handling is consistent across functions"""
        # Test reverse_integer_lastbyte_conversion error handling - returns 0 for invalid input
        result = reverse_integer_lastbyte_conversion({"invalid": "input"})
        assert result == 0
        
        # File path functions should handle various inputs gracefully
        # (they rely on string concatenation, so most inputs should work)
        result = file_path_flat("123")  # Should convert to string
        assert "123" in result
