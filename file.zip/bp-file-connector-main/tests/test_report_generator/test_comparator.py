import pytest
import os
import tempfile
from unittest.mock import patch, mock_open, MagicMock
import pandas as pd

from src.report_generator.comparator import (
    compare_files, 
    HEADER_FOOTER_PATTERNS,
    REPORT_DEFINITIONS,
    comparables
)


class TestComparator:
    """Test suite for the comparator module"""

    @pytest.fixture
    def sample_data_files(self):
        """Create temporary test files with sample data"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create left-hand side file
            lhs_file = os.path.join(temp_dir, "lhs_test.txt")
            with open(lhs_file, 'w') as f:
                f.write("001123456789Jane Doe             123 Main St         City    ST12345  12345  01/01/2023 01/01/1990 01/01/2023          01/01/2025 40  05\n")
                f.write("002987654321Bob Smith            456 Oak Ave         Town    CA54321  54321  02/01/2023 02/01/1985 02/01/2023          02/01/2025 35  10\n")

            # Create right-hand side file with modifications
            rhs_file = os.path.join(temp_dir, "rhs_test.txt")
            with open(rhs_file, 'w') as f:
                f.write("001123456789Jane Doe             456 New St          City    ST12345  12345  01/01/2023 01/01/1990 01/01/2023          01/01/2025 40  05\n")  # Modified address
                f.write("003111222333Alice Johnson        789 Pine Rd         Village NY67890  67890  03/01/2023 03/01/1992 03/01/2023          03/01/2025 45  03\n")  # New record

            yield lhs_file, rhs_file, temp_dir

    @pytest.fixture
    def sample_eligibility_config(self):
        """Sample configuration for eligibility report"""
        return {
            "column_widths": [3, 10, 10, 20, 25, 25, 20, 2, 5, 10, 10, 10, 10, 10, 10, 5, 3],
            "column_names": [
                "HCE", "SSN", "WIN", "FIRST_NAME", "LAST_NAME", "ADDRESS", "CITY", "ST", "ZIP",
                "WRK_STR_NBR", "HIRE_DATE", "BIRTH_DATE", "EFF_DATE", "TERM_DATE", "PAYOUT_DT", "ELIG_HRS", "YOS"
            ],
            "unique_keys": ["SSN", "WIN"],
            "report_type": "401K ELIGIBILITY FILE(BIWEEKLY) PR"
        }

    def test_header_footer_patterns_valid(self):
        """Test that header/footer patterns are properly defined"""
        assert len(HEADER_FOOTER_PATTERNS) == 5
        assert any("RUN ON" in pattern for pattern in HEADER_FOOTER_PATTERNS)
        assert any("HCE" in pattern for pattern in HEADER_FOOTER_PATTERNS)
        assert any("TOTAL ASSOCS" in pattern for pattern in HEADER_FOOTER_PATTERNS)
        assert any("PAGE-NO." in pattern for pattern in HEADER_FOOTER_PATTERNS)
        assert any("END-OF-JOB" in pattern for pattern in HEADER_FOOTER_PATTERNS)

    def test_report_definitions_structure(self):
        """Test that REPORT_DEFINITIONS has proper structure"""
        assert isinstance(REPORT_DEFINITIONS, dict)
        assert len(REPORT_DEFINITIONS) > 0
        
        for report_name, definition in REPORT_DEFINITIONS.items():
            assert "column_widths" in definition
            assert "column_names" in definition
            assert isinstance(definition["column_widths"], list)
            assert isinstance(definition["column_names"], list)
            
            # For reports with data, column_widths and column_names should match
            if definition["column_widths"]:
                assert len(definition["column_widths"]) == len(definition["column_names"])

    def test_report_definitions_known_reports(self):
        """Test that known report types are defined"""
        expected_reports = [
            "401K ELIGIBILITY FILE(BIWEEKLY) PR",
            "401K TERMINATION FILE(WEEKLY) PR",
            "401K LOAN FILE(BIWEEKLY) PR",
            "401K RE HIRE FILE(WEEKLY) PR",
            "401K STATE TRANSFER FILE(WEEKLY)"
        ]
        
        for report in expected_reports:
            assert report in REPORT_DEFINITIONS

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    @patch('os.path.exists', return_value=True)
    def test_compare_files_basic_comparison(self, mock_exists, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test basic file comparison functionality"""
        # Mock DataFrames
        lhs_data = pd.DataFrame({
            'SSN': ['123456789', '987654321'],
            'WIN': ['Jane Doe', 'Bob Smith'],
            'ADDRESS': ['123 Main St', '456 Oak Ave'],
            'CITY': ['City', 'Town']
        })
        
        rhs_data = pd.DataFrame({
            'SSN': ['123456789', '111222333'],
            'WIN': ['Jane Doe', 'Alice Johnson'],
            'ADDRESS': ['456 New St', '789 Pine Rd'],
            'CITY': ['City', 'Village']
        })
        
        mock_read_fwf.side_effect = [lhs_data, rhs_data]
        
        result = compare_files(
            "lhs_file.txt",
            "rhs_file.txt",
            sample_eligibility_config["column_widths"],
            sample_eligibility_config["column_names"],
            sample_eligibility_config["unique_keys"],
            sample_eligibility_config["report_type"]
        )
        
        assert "report_name" in result
        assert "total_rows" in result
        assert "total_cells" in result
        assert "match_percent" in result
        assert "added" in result
        assert "removed" in result
        assert "modified" in result
        assert result["report_name"] == sample_eligibility_config["report_type"]

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    def test_compare_files_identical_files(self, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test comparison of identical files"""
        # Mock identical DataFrames
        data = pd.DataFrame({
            'SSN': ['123456789', '987654321'],
            'WIN': ['Jane Doe', 'Bob Smith'],
            'ADDRESS': ['123 Main St', '456 Oak Ave'],
            'CITY': ['City', 'Town']
        })
        
        mock_read_fwf.side_effect = [data.copy(), data.copy()]
        
        result = compare_files(
            "lhs_file.txt",
            "rhs_file.txt",
            sample_eligibility_config["column_widths"],
            sample_eligibility_config["column_names"],
            sample_eligibility_config["unique_keys"],
            sample_eligibility_config["report_type"]
        )
        
        assert result["match_percent"] == 100.0
        assert result["added"] == 0
        assert result["removed"] == 0
        assert len(result["modified"]) == 0

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    def test_compare_files_with_modifications(self, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test comparison with modified records"""
        lhs_data = pd.DataFrame({
            'SSN': ['123456789'],
            'WIN': ['Jane Doe'],
            'ADDRESS': ['123 Main St'],
            'CITY': ['City']
        })
        
        rhs_data = pd.DataFrame({
            'SSN': ['123456789'],
            'WIN': ['Jane Doe'],
            'ADDRESS': ['456 New St'],  # Modified address
            'CITY': ['City']
        })
        
        mock_read_fwf.side_effect = [lhs_data, rhs_data]
        
        result = compare_files(
            "lhs_file.txt",
            "rhs_file.txt",
            sample_eligibility_config["column_widths"],
            sample_eligibility_config["column_names"],
            sample_eligibility_config["unique_keys"],
            sample_eligibility_config["report_type"]
        )
        
        assert len(result["modified"]) == 1
        assert result["added"] == 0
        assert result["removed"] == 0
        assert "ADDRESS" in result["modified"][0]["modified_columns"]

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    def test_compare_files_with_additions_and_removals(self, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test comparison with added and removed records"""
        lhs_data = pd.DataFrame({
            'SSN': ['123456789', '987654321'],
            'WIN': ['Jane Doe', 'Bob Smith'],
            'ADDRESS': ['123 Main St', '456 Oak Ave'],
            'CITY': ['City', 'Town']
        })
        
        rhs_data = pd.DataFrame({
            'SSN': ['123456789', '111222333'],
            'WIN': ['Jane Doe', 'Alice Johnson'],
            'ADDRESS': ['123 Main St', '789 Pine Rd'],
            'CITY': ['City', 'Village']
        })
        
        mock_read_fwf.side_effect = [lhs_data, rhs_data]
        
        result = compare_files(
            "lhs_file.txt",
            "rhs_file.txt",
            sample_eligibility_config["column_widths"],
            sample_eligibility_config["column_names"],
            sample_eligibility_config["unique_keys"],
            sample_eligibility_config["report_type"]
        )
        
        assert result["added"] == 1
        assert result["removed"] == 1
        assert len(result["added_records"]) == 1
        assert len(result["removed_records"]) == 1

    def test_compare_files_invalid_unique_keys(self, sample_eligibility_config):
        """Test error handling for invalid unique keys"""
        with patch('builtins.open', mock_open()):
            with patch('pandas.read_fwf') as mock_read_fwf:
                # Mock DataFrame without the required unique key columns
                data = pd.DataFrame({
                    'INVALID_COL': ['123456789'],
                    'ANOTHER_COL': ['Jane Doe']
                })
                mock_read_fwf.return_value = data
                
                with pytest.raises(ValueError, match="Both files must contain the unique key columns"):
                    compare_files(
                        "lhs_file.txt",
                        "rhs_file.txt",
                        sample_eligibility_config["column_widths"],
                        sample_eligibility_config["column_names"],
                        sample_eligibility_config["unique_keys"],
                        sample_eligibility_config["report_type"]
                    )

    @patch('builtins.open', new_callable=mock_open)
    def test_extract_valid_rows_filters_headers_footers(self, mock_file):
        """Test that header and footer lines are properly filtered"""
        # Mock file content with headers and footers
        file_content = [
            "RUN ON 01/01/2023\n",
            "HCE   SSN        WIN\n",
            "001123456789Jane Doe\n",
            "002987654321Bob Smith\n",
            "TOTAL ASSOCS: 2\n",
            "PAGE-NO. 1\n",
            "** END-OF-JOB **\n"
        ]
        
        mock_file.return_value.readlines.return_value = file_content
        
        with patch('pandas.read_fwf') as mock_read_fwf:
            # Create separate DataFrames for each call to avoid column modification issues
            def create_mock_df():
                return pd.DataFrame({
                    'HCE': ['001', '002'],
                    'SSN': ['123456789', '987654321'],
                    'WIN': ['Jane Doe', 'Bob Smith']
                })
            
            mock_read_fwf.side_effect = [create_mock_df(), create_mock_df()]
            
            # This should filter out header/footer lines
            result = compare_files(
                "test_file.txt", "test_file.txt",
                [3, 10, 10], ["HCE", "SSN", "WIN"],
                ["HCE"], "401K ELIGIBILITY FILE(BIWEEKLY) PR"  # Use HCE as unique key
            )
            
            # Verify that pandas.read_fwf was called with filtered content
            assert mock_read_fwf.called
            assert isinstance(result, dict)

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    def test_compare_files_empty_dataframes(self, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test comparison with empty DataFrames"""
        # Create empty dataframes with the required columns including unique keys
        empty_data = pd.DataFrame(columns=sample_eligibility_config["column_names"])
        mock_read_fwf.side_effect = [empty_data, empty_data]
        
        with pytest.raises(KeyError):
            # Empty dataframes will fail when trying to set index with missing columns
            compare_files(
                "lhs_file.txt",
                "rhs_file.txt",
                sample_eligibility_config["column_widths"],
                sample_eligibility_config["column_names"],
                sample_eligibility_config["unique_keys"],
                sample_eligibility_config["report_type"]
            )

    @patch('builtins.open', new_callable=mock_open)
    @patch('pandas.read_fwf')
    def test_data_normalization(self, mock_read_fwf, mock_file, sample_eligibility_config):
        """Test that data is properly normalized (stripped of whitespace)"""
        # Create test data with whitespace differences but same content after normalization
        lhs_data = pd.DataFrame({
            'HCE': ['001'],
            'SSN': [' 123456789 '],  # With whitespace
            'WIN': [' Jane Doe '],
            'FIRST_NAME': ['Jane'],
            'LAST_NAME': ['Doe'],
            'ADDRESS': [' 123 Main St '],
            'CITY': [' City '],
            'ST': ['NY'],
            'ZIP': ['12345'],
            'WRK_STR_NBR': ['100'],
            'HIRE_DATE': ['01/01/2020'],
            'BIRTH_DATE': ['01/01/1980'],
            'EFF_DATE': ['01/01/2020'],
            'TERM_DATE': [''],
            'PAYOUT_DT': [''],
            'ELIG_HRS': ['40'],
            'YOS': ['03']
        })
        
        rhs_data = pd.DataFrame({
            'HCE': ['001'],
            'SSN': ['123456789'],  # Without whitespace
            'WIN': ['Jane Doe'],
            'FIRST_NAME': ['Jane'],
            'LAST_NAME': ['Doe'],
            'ADDRESS': ['123 Main St'],
            'CITY': ['City'],
            'ST': ['NY'],
            'ZIP': ['12345'],
            'WRK_STR_NBR': ['100'],
            'HIRE_DATE': ['01/01/2020'],
            'BIRTH_DATE': ['01/01/1980'],
            'EFF_DATE': ['01/01/2020'],
            'TERM_DATE': [''],
            'PAYOUT_DT': [''],
            'ELIG_HRS': ['40'],
            'YOS': ['03']
        })
        
        mock_read_fwf.side_effect = [lhs_data, rhs_data]
        
        result = compare_files(
            "lhs_file.txt",
            "rhs_file.txt",
            sample_eligibility_config["column_widths"],
            sample_eligibility_config["column_names"],
            sample_eligibility_config["unique_keys"],
            sample_eligibility_config["report_type"]
        )
        
        # After normalization, most cells should match but there may be some formatting differences
        # Check that comparison was successful and result contains expected fields
        assert isinstance(result["match_percent"], float)
        assert result["match_percent"] > 0  # Some percentage should match after normalization
        assert "modified" in result
        assert "total_cells" in result

    def test_match_percentage_calculation(self):
        """Test match percentage calculation logic"""
        with patch('builtins.open', mock_open()):
            with patch('pandas.read_fwf') as mock_read_fwf:
                lhs_data = pd.DataFrame({
                    'SSN': ['123456789', '987654321'],
                    'WIN': ['Jane Doe', 'Bob Smith'],
                    'COL3': ['Val1', 'Val2'],
                    'COL4': ['Val3', 'Val4']
                })
                
                rhs_data = pd.DataFrame({
                    'SSN': ['123456789', '111222333'],
                    'WIN': ['Jane Doe', 'Alice Johnson'],
                    'COL3': ['Val1', 'NewVal2'],
                    'COL4': ['Val3', 'NewVal4']
                })
                
                mock_read_fwf.side_effect = [lhs_data, rhs_data]
                
                result = compare_files(
                    "lhs_file.txt", "rhs_file.txt",
                    [10, 10, 10, 10], ["SSN", "WIN", "COL3", "COL4"],
                    ["SSN", "WIN"], "401K ELIGIBILITY FILE(BIWEEKLY) PR"
                )
                
                # Verify percentage calculation
                assert isinstance(result["match_percent"], float)
                assert 0 <= result["match_percent"] <= 100
                assert result["total_cells"] > 0
                assert result["non_matching_cells"] >= 0

    @patch('os.remove')
    def test_temporary_file_cleanup(self, mock_remove):
        """Test that temporary files are cleaned up"""
        with patch('builtins.open', mock_open()):
            with patch('pandas.read_fwf') as mock_read_fwf:
                # Create separate DataFrames for each call to avoid column modification issues
                def create_mock_data():
                    return pd.DataFrame({'SSN': ['123'], 'WIN': ['Test']})
                
                mock_read_fwf.side_effect = [create_mock_data(), create_mock_data()]
                
                result = compare_files(
                    "lhs_file.txt", "rhs_file.txt",
                    [10, 10], ["SSN", "WIN"],
                    ["WIN"], "401K ELIGIBILITY FILE(BIWEEKLY) PR"  # Use WIN as unique key
                )
                
                # Note: The actual implementation should clean up temp files
                # This test ensures we're aware of the cleanup requirement
                assert isinstance(result, dict)

    def test_compare_files_edge_case_single_column(self):
        """Test comparison with single column data"""
        with patch('builtins.open', mock_open()):
            with patch('pandas.read_fwf') as mock_read_fwf:
                lhs_data = pd.DataFrame({'SSN': ['123456789', '987654321']})
                rhs_data = pd.DataFrame({'SSN': ['123456789', '111222333']})
                
                mock_read_fwf.side_effect = [lhs_data, rhs_data]
                
                result = compare_files(
                    "lhs_file.txt", "rhs_file.txt",
                    [10], ["SSN"], ["SSN"],
                    "401K ELIGIBILITY FILE(BIWEEKLY) PR"
                )
                
                assert result["added"] == 1
                assert result["removed"] == 1
                assert len(result["modified"]) == 0

    @patch('src.report_generator.comparator.compare_files')
    @patch('os.getcwd')
    def test_main_function_execution(self, mock_getcwd, mock_compare_files):
        """Test the __main__() function execution"""
        from src.report_generator.comparator import __main__, comparables
        
        # Mock the current working directory
        mock_getcwd.return_value = "/test/path"
        
        # Mock the compare_files function
        mock_compare_files.return_value = {
            'report_name': '401K STATE TRANSFER FILE(WEEKLY)',
            'total_rows': 10,
            'match_percent': 95.0,
            'differences': []
        }
        
        # Execute the main function
        __main__()
        
        # Verify compare_files was called with expected parameters
        assert mock_compare_files.called
        call_args = mock_compare_files.call_args[0]
        assert "/test/path/src/report_generator/output_temp/for_comparison/US_STATE_TRANSFER_RPT" in call_args[0]
        assert "/test/path/src/report_generator/output_temp/for_comparison/401K STATE TRANSFER FILE(WEEKLY) US.report" in call_args[1]

    def test_main_function_invalid_report_type(self):
        """Test __main__() function with invalid report type"""
        from src.report_generator.comparator import __main__
        
        # Temporarily modify comparables to have invalid report type
        original_comparables = comparables.copy()
        comparables[0]["report_type"] = "INVALID_REPORT_TYPE"
        
        try:
            with pytest.raises(ValueError, match="Report type 'INVALID_REPORT_TYPE' is not supported"):
                __main__()
        finally:
            # Restore original comparables
            comparables.clear()
            comparables.extend(original_comparables)

    def test_comparables_data_structure(self):
        """Test that comparables data structure is properly defined"""
        from src.report_generator.comparator import comparables
        
        assert isinstance(comparables, list)
        assert len(comparables) > 0
        
        for comparable in comparables:
            assert "lhs_file" in comparable
            assert "rhs_file" in comparable
            assert "report_type" in comparable
            assert "unique_keys" in comparable
            assert isinstance(comparable["unique_keys"], list)
