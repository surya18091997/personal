import pytest
from unittest.mock import patch, MagicMock
from dataclasses import dataclass

from src.report_generator.flat_file_reader_output import FlatFileReaderOutput


class TestFlatFileReaderOutput:
    """Test suite for the FlatFileReaderOutput dataclass"""

    def test_flat_file_reader_output_creation(self):
        """Test creation of FlatFileReaderOutput instance"""
        output = FlatFileReaderOutput(
            generated="/path/to/output.csv",
            status="SUCCESS",
            code=0
        )
        
        assert output.generated == "/path/to/output.csv"
        assert output.status == "SUCCESS"
        assert output.code == 0

    def test_flat_file_reader_output_str_representation(self):
        """Test string representation of FlatFileReaderOutput"""
        output = FlatFileReaderOutput(
            generated="/path/to/output.csv",
            status="SUCCESS",
            code=0
        )
        
        expected_str = "generated path: /path/to/output.csv, status: SUCCESS, code: 0"
        assert str(output) == expected_str

    def test_flat_file_reader_output_different_values(self):
        """Test FlatFileReaderOutput with different values"""
        test_cases = [
            {
                "generated": "/tmp/report_001.csv",
                "status": "COMPLETED",
                "code": 0,
                "expected_str": "generated path: /tmp/report_001.csv, status: COMPLETED, code: 0"
            },
            {
                "generated": "/output/error_report.csv",
                "status": "FAILED",
                "code": 1,
                "expected_str": "generated path: /output/error_report.csv, status: FAILED, code: 1"
            },
            {
                "generated": "",
                "status": "PENDING",
                "code": -1,
                "expected_str": "generated path: , status: PENDING, code: -1"
            }
        ]
        
        for case in test_cases:
            output = FlatFileReaderOutput(
                generated=case["generated"],
                status=case["status"],
                code=case["code"]
            )
            
            assert output.generated == case["generated"]
            assert output.status == case["status"]
            assert output.code == case["code"]
            assert str(output) == case["expected_str"]

    def test_flat_file_reader_output_equality(self):
        """Test equality comparison of FlatFileReaderOutput instances"""
        output1 = FlatFileReaderOutput(
            generated="/path/to/output.csv",
            status="SUCCESS",
            code=0
        )
        
        output2 = FlatFileReaderOutput(
            generated="/path/to/output.csv",
            status="SUCCESS",
            code=0
        )
        
        output3 = FlatFileReaderOutput(
            generated="/different/path.csv",
            status="SUCCESS",
            code=0
        )
        
        assert output1 == output2
        assert output1 != output3

    def test_flat_file_reader_output_attribute_access(self):
        """Test direct attribute access"""
        output = FlatFileReaderOutput(
            generated="/test/output.csv",
            status="PROCESSING",
            code=100
        )
        
        # Test direct attribute access
        assert hasattr(output, 'generated')
        assert hasattr(output, 'status')
        assert hasattr(output, 'code')
        
        # Test attribute modification
        output.generated = "/new/path.csv"
        output.status = "UPDATED"
        output.code = 200
        
        assert output.generated == "/new/path.csv"
        assert output.status == "UPDATED"
        assert output.code == 200

    def test_flat_file_reader_output_with_none_values(self):
        """Test FlatFileReaderOutput with None values"""
        output = FlatFileReaderOutput(
            generated=None,
            status=None,
            code=None
        )
        
        assert output.generated is None
        assert output.status is None
        assert output.code is None
        
        expected_str = "generated path: None, status: None, code: None"
        assert str(output) == expected_str

    def test_flat_file_reader_output_with_special_characters(self):
        """Test FlatFileReaderOutput with special characters in strings"""
        output = FlatFileReaderOutput(
            generated="/path/with spaces/output_file-2023.csv",
            status="SUCCESS_WITH_WARNINGS",
            code=0
        )
        
        assert output.generated == "/path/with spaces/output_file-2023.csv"
        assert output.status == "SUCCESS_WITH_WARNINGS"
        
        expected_str = "generated path: /path/with spaces/output_file-2023.csv, status: SUCCESS_WITH_WARNINGS, code: 0"
        assert str(output) == expected_str

    def test_flat_file_reader_output_with_long_paths(self):
        """Test FlatFileReaderOutput with very long file paths"""
        long_path = "/very/long/path/that/might/represent/a/real/world/scenario/with/deep/directory/structure/output_file_with_long_name_2023_01_01.csv"
        
        output = FlatFileReaderOutput(
            generated=long_path,
            status="SUCCESS",
            code=0
        )
        
        assert output.generated == long_path
        assert long_path in str(output)

    def test_flat_file_reader_output_with_numeric_strings(self):
        """Test FlatFileReaderOutput with string values that look like numbers"""
        output = FlatFileReaderOutput(
            generated="12345",
            status="200",
            code=404
        )
        
        assert output.generated == "12345"
        assert output.status == "200"
        assert output.code == 404
        
        expected_str = "generated path: 12345, status: 200, code: 404"
        assert str(output) == expected_str

    def test_flat_file_reader_output_dataclass_properties(self):
        """Test that FlatFileReaderOutput behaves as a proper dataclass"""
        # Test that it's a dataclass
        assert hasattr(FlatFileReaderOutput, '__dataclass_fields__')
        
        # Test field names
        field_names = set(FlatFileReaderOutput.__dataclass_fields__.keys())
        expected_fields = {'generated', 'status', 'code'}
        assert field_names == expected_fields
        
        # Test field types
        fields = FlatFileReaderOutput.__dataclass_fields__
        assert fields['generated'].type == str
        assert fields['status'].type == str
        assert fields['code'].type == int

    def test_flat_file_reader_output_immutability_expectations(self):
        """Test behavior related to dataclass mutability (default behavior)"""
        output = FlatFileReaderOutput(
            generated="/initial/path.csv",
            status="INITIAL",
            code=0
        )
        
        # Dataclass is mutable by default, so these should work
        original_generated = output.generated
        output.generated = "/modified/path.csv"
        
        assert output.generated != original_generated
        assert output.generated == "/modified/path.csv"

    def test_flat_file_reader_output_repr(self):
        """Test the repr representation of FlatFileReaderOutput"""
        output = FlatFileReaderOutput(
            generated="/test/path.csv",
            status="TEST",
            code=42
        )
        
        # The dataclass should provide a meaningful repr
        repr_str = repr(output)
        assert "FlatFileReaderOutput" in repr_str
        assert "/test/path.csv" in repr_str
        assert "TEST" in repr_str
        assert "42" in repr_str

    def test_flat_file_reader_output_integration_scenarios(self):
        """Test FlatFileReaderOutput in various integration scenarios"""
        # Scenario 1: Successful processing
        success_output = FlatFileReaderOutput(
            generated="/output/reports/eligibility_2023_01_01.csv",
            status="SUCCESS",
            code=0
        )
        
        assert success_output.code == 0
        assert "SUCCESS" in success_output.status
        assert success_output.generated.endswith(".csv")
        
        # Scenario 2: Processing with warnings
        warning_output = FlatFileReaderOutput(
            generated="/output/reports/partial_data.csv",
            status="SUCCESS_WITH_WARNINGS",
            code=1
        )
        
        assert warning_output.code == 1
        assert "WARNING" in warning_output.status
        
        # Scenario 3: Failed processing
        error_output = FlatFileReaderOutput(
            generated="",
            status="FAILED",
            code=500
        )
        
        assert error_output.code == 500
        assert error_output.status == "FAILED"
        assert error_output.generated == ""

    def test_flat_file_reader_output_string_formatting(self):
        """Test string formatting with different approaches"""
        output = FlatFileReaderOutput(
            generated="/test/output.csv",
            status="COMPLETE",
            code=0
        )
        
        # Test f-string formatting
        f_string = f"Result: {output}"
        assert "generated path: /test/output.csv, status: COMPLETE, code: 0" in f_string
        
        # Test format method
        format_string = "Processing result: {}".format(output)
        assert "generated path: /test/output.csv, status: COMPLETE, code: 0" in format_string

    def test_flat_file_reader_output_with_unicode_characters(self):
        """Test FlatFileReaderOutput with unicode characters"""
        output = FlatFileReaderOutput(
            generated="/path/with/üñîçødé/characters.csv",
            status="SÜCCESS",
            code=0
        )
        
        assert "üñîçødé" in output.generated
        assert "SÜCCESS" in output.status
        
        # String representation should handle unicode properly
        str_repr = str(output)
        assert "üñîçødé" in str_repr
        assert "SÜCCESS" in str_repr

    def test_flat_file_reader_output_type_validation(self):
        """Test type validation behavior (dataclass doesn't enforce types by default)"""
        # This test documents current behavior - dataclass doesn't enforce types
        # unless additional validation is added
        output = FlatFileReaderOutput(
            generated=123,  # Wrong type, but allowed
            status=["not", "a", "string"],  # Wrong type, but allowed
            code="should_be_int"  # Wrong type, but allowed
        )
        
        # These will work because dataclass doesn't enforce types by default
        assert output.generated == 123
        assert output.status == ["not", "a", "string"]
        assert output.code == "should_be_int"
