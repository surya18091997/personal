import pytest
from unittest.mock import patch, MagicMock
from dataclasses import dataclass

from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject


class MockDataObject(DataObject):
    """Mock data object for testing"""
    
    def __init__(self, template_name="test_template.txt", include_newline=True, data=None):
        self._template_name = template_name
        self._include_newline = include_newline
        self._data = data or {"field1": "value1", "field2": "value2"}
    
    def template_name(self) -> str:
        return self._template_name
    
    def include_new_line(self) -> bool:
        return self._include_newline
    
    def to_dict(self) -> dict:
        return self._data


class TestTransformerConfig:
    """Test suite for the TransformerConfig dataclass"""

    def test_transformer_config_creation_minimal(self):
        """Test creation with minimal required parameters"""
        config = TransformerConfig(
            output_file_name="test_output.txt",
            page_size=100,
            report_id="TEST001"
        )
        
        assert config.output_file_name == "test_output.txt"
        assert config.page_size == 100
        assert config.report_id == "TEST001"
        assert config.data_objects is None  # Default value

    def test_transformer_config_creation_full(self):
        """Test creation with all parameters specified"""
        data_objects = [
            MockDataObject("header.txt", True, {"title": "Test Report"}),
            MockDataObject("data.txt", True, {"record": "001"}),
            MockDataObject("footer.txt", False, {"total": "1"})
        ]
        
        config = TransformerConfig(
            output_file_name="full_output.txt",
            page_size=250,
            report_id="FULL001",
            data_objects=data_objects
        )
        
        assert config.output_file_name == "full_output.txt"
        assert config.page_size == 250
        assert config.report_id == "FULL001"
        assert config.data_objects == data_objects
        assert len(config.data_objects) == 3

    def test_transformer_config_default_values(self):
        """Test default values for optional parameters"""
        config = TransformerConfig(
            output_file_name="default_test.txt",
            page_size=50,
            report_id="DEFAULT"
        )
        
        # Test default value
        assert config.data_objects is None

    def test_transformer_config_equality(self):
        """Test equality comparison of TransformerConfig instances"""
        data_objects = [MockDataObject("test.txt", True)]
        
        config1 = TransformerConfig(
            output_file_name="test.txt",
            page_size=100,
            report_id="TEST001",
            data_objects=data_objects
        )
        
        config2 = TransformerConfig(
            output_file_name="test.txt",
            page_size=100,
            report_id="TEST001",
            data_objects=data_objects
        )
        
        config3 = TransformerConfig(
            output_file_name="different.txt",
            page_size=100,
            report_id="TEST001",
            data_objects=data_objects
        )
        
        assert config1 == config2
        assert config1 != config3

    def test_transformer_config_attribute_access(self):
        """Test direct attribute access and modification"""
        config = TransformerConfig(
            output_file_name="initial.txt",
            page_size=100,
            report_id="INITIAL"
        )
        
        # Test initial values
        assert config.output_file_name == "initial.txt"
        assert config.page_size == 100
        assert config.report_id == "INITIAL"
        assert config.data_objects is None
        
        # Test attribute modification
        new_data_objects = [MockDataObject("modified.txt")]
        config.output_file_name = "modified.txt"
        config.page_size = 200
        config.report_id = "MODIFIED"
        config.data_objects = new_data_objects
        
        assert config.output_file_name == "modified.txt"
        assert config.page_size == 200
        assert config.report_id == "MODIFIED"
        assert config.data_objects == new_data_objects

    def test_transformer_config_with_empty_data_objects(self):
        """Test TransformerConfig with empty data objects list"""
        config = TransformerConfig(
            output_file_name="empty_data.txt",
            page_size=100,
            report_id="EMPTY",
            data_objects=[]
        )
        
        assert config.data_objects == []
        assert len(config.data_objects) == 0

    def test_transformer_config_with_single_data_object(self):
        """Test TransformerConfig with single data object"""
        data_object = MockDataObject("single.txt", True, {"data": "single"})
        
        config = TransformerConfig(
            output_file_name="single_data.txt",
            page_size=100,
            report_id="SINGLE",
            data_objects=[data_object]
        )
        
        assert len(config.data_objects) == 1
        assert config.data_objects[0] == data_object

    def test_transformer_config_with_multiple_data_objects(self):
        """Test TransformerConfig with multiple data objects"""
        data_objects = [
            MockDataObject("header.txt", True, {"title": "Report Header"}),
            MockDataObject("data1.txt", True, {"record1": "data1"}),
            MockDataObject("data2.txt", True, {"record2": "data2"}),
            MockDataObject("data3.txt", True, {"record3": "data3"}),
            MockDataObject("footer.txt", False, {"summary": "Report Footer"})
        ]
        
        config = TransformerConfig(
            output_file_name="multi_data.txt",
            page_size=100,
            report_id="MULTI",
            data_objects=data_objects
        )
        
        assert len(config.data_objects) == 5
        assert all(isinstance(obj, MockDataObject) for obj in config.data_objects)

    def test_transformer_config_with_mixed_data_objects(self):
        """Test TransformerConfig with mixed data objects including None"""
        data_objects = [
            MockDataObject("valid1.txt", True),
            None,
            MockDataObject("valid2.txt", False),
            None
        ]
        
        config = TransformerConfig(
            output_file_name="mixed_data.txt",
            page_size=100,
            report_id="MIXED",
            data_objects=data_objects
        )
        
        assert len(config.data_objects) == 4
        assert config.data_objects[0] is not None
        assert config.data_objects[1] is None
        assert config.data_objects[2] is not None
        assert config.data_objects[3] is None

    def test_transformer_config_page_size_variations(self):
        """Test TransformerConfig with various page sizes"""
        test_cases = [
            {"page_size": 1, "description": "minimum page size"},
            {"page_size": 50, "description": "small page size"},
            {"page_size": 100, "description": "standard page size"},
            {"page_size": 500, "description": "large page size"},
            {"page_size": 1000, "description": "very large page size"},
            {"page_size": 99999, "description": "maximum page size"}
        ]
        
        for case in test_cases:
            config = TransformerConfig(
                output_file_name="page_test.txt",
                page_size=case["page_size"],
                report_id="PAGE_TEST"
            )
            
            assert config.page_size == case["page_size"]
            assert isinstance(config.page_size, int)

    def test_transformer_config_output_file_name_variations(self):
        """Test TransformerConfig with various output file names"""
        test_cases = [
            "simple.txt",
            "report_with_underscores.txt",
            "report-with-dashes.txt",
            "UPPERCASE_REPORT.TXT",
            "MixedCase_Report.txt",
            "report_with_numbers_123.txt",
            "very_long_report_name_that_might_be_used_in_real_scenarios.txt",
            "report with spaces.txt",
            "report.special@chars#.txt"
        ]
        
        for filename in test_cases:
            config = TransformerConfig(
                output_file_name=filename,
                page_size=100,
                report_id="FILE_TEST"
            )
            
            assert config.output_file_name == filename

    def test_transformer_config_report_id_variations(self):
        """Test TransformerConfig with various report IDs"""
        test_cases = [
            "A123",
            "PS719101US",
            "BE208801PR",
            "ELIGIBILITY_001",
            "LOAN-FILE-123",
            "STATE.TRANSFER.001",
            "12345",
            "VERY_LONG_REPORT_ID_THAT_MIGHT_EXIST",
            "Mixed_Case_ID_123"
        ]
        
        for report_id in test_cases:
            config = TransformerConfig(
                output_file_name="test.txt",
                page_size=100,
                report_id=report_id
            )
            
            assert config.report_id == report_id

    def test_transformer_config_dataclass_properties(self):
        """Test that TransformerConfig behaves as a proper dataclass"""
        # Test that it's a dataclass
        assert hasattr(TransformerConfig, '__dataclass_fields__')
        
        # Test field names
        field_names = set(TransformerConfig.__dataclass_fields__.keys())
        expected_fields = {'output_file_name', 'page_size', 'report_id', 'data_objects'}
        assert field_names == expected_fields
        
        # Test field types
        fields = TransformerConfig.__dataclass_fields__
        assert fields['output_file_name'].type == str
        assert fields['page_size'].type == int
        assert fields['report_id'].type == str
        # data_objects field type is list[DataObject] = None

    def test_transformer_config_repr(self):
        """Test the repr representation of TransformerConfig"""
        config = TransformerConfig(
            output_file_name="test_repr.txt",
            page_size=150,
            report_id="REPR_TEST",
            data_objects=[MockDataObject("test.txt")]
        )
        
        repr_str = repr(config)
        assert "TransformerConfig" in repr_str
        assert "test_repr.txt" in repr_str
        assert "150" in repr_str
        assert "REPR_TEST" in repr_str

    def test_transformer_config_with_none_values(self):
        """Test TransformerConfig with None values where possible"""
        # Note: output_file_name, page_size, and report_id are required
        # Only data_objects can be None by default
        config = TransformerConfig(
            output_file_name="none_test.txt",
            page_size=100,
            report_id="NONE_TEST",
            data_objects=None
        )
        
        assert config.data_objects is None

    def test_transformer_config_with_empty_strings(self):
        """Test TransformerConfig with empty string values"""
        config = TransformerConfig(
            output_file_name="",
            page_size=0,
            report_id="",
            data_objects=[]
        )
        
        assert config.output_file_name == ""
        assert config.page_size == 0
        assert config.report_id == ""
        assert config.data_objects == []

    def test_transformer_config_integration_scenarios(self):
        """Test TransformerConfig in various integration scenarios"""
        # Scenario 1: Eligibility report configuration
        eligibility_config = TransformerConfig(
            output_file_name="401K_ELIGIBILITY_FILE_US.report",
            page_size=100,
            report_id="PS719101US",
            data_objects=[]
        )
        
        assert "ELIGIBILITY" in eligibility_config.output_file_name
        assert "US" in eligibility_config.report_id
        assert eligibility_config.page_size == 100
        
        # Scenario 2: Loan report configuration
        loan_config = TransformerConfig(
            output_file_name="401K_LOAN_FILE_PR.report",
            page_size=250,
            report_id="LN208801PR"
        )
        
        assert "LOAN" in loan_config.output_file_name
        assert "PR" in loan_config.report_id
        assert loan_config.page_size == 250
        assert loan_config.data_objects is None
        
        # Scenario 3: State transfer report configuration
        transfer_config = TransformerConfig(
            output_file_name="401K_STATE_TRANSFER_FILE.report",
            page_size=50,
            report_id="ST401K001",
            data_objects=[
                MockDataObject("header.txt", True, {"report_title": "State Transfer"}),
                MockDataObject("footer.txt", False, {"total_transfers": "10"})
            ]
        )
        
        assert "TRANSFER" in transfer_config.output_file_name
        assert transfer_config.page_size == 50
        assert len(transfer_config.data_objects) == 2

    def test_transformer_config_data_objects_manipulation(self):
        """Test manipulation of data_objects list"""
        config = TransformerConfig(
            output_file_name="manipulation_test.txt",
            page_size=100,
            report_id="MANIP",
            data_objects=[]
        )
        
        # Test adding objects
        obj1 = MockDataObject("obj1.txt")
        obj2 = MockDataObject("obj2.txt")
        
        config.data_objects.append(obj1)
        assert len(config.data_objects) == 1
        
        config.data_objects.append(obj2)
        assert len(config.data_objects) == 2
        
        # Test removing objects
        config.data_objects.remove(obj1)
        assert len(config.data_objects) == 1
        assert config.data_objects[0] == obj2
        
        # Test clearing objects
        config.data_objects.clear()
        assert len(config.data_objects) == 0

    def test_transformer_config_data_objects_types(self):
        """Test data_objects with different types of objects"""
        # Test with actual DataObject subclasses
        data_objects = [
            MockDataObject("template1.txt", True, {"data": "test1"}),
            MockDataObject("template2.txt", False, {"data": "test2"})
        ]
        
        config = TransformerConfig(
            output_file_name="types_test.txt",
            page_size=100,
            report_id="TYPES",
            data_objects=data_objects
        )
        
        assert all(hasattr(obj, 'template_name') for obj in config.data_objects)
        assert all(hasattr(obj, 'include_new_line') for obj in config.data_objects)
        assert all(hasattr(obj, 'to_dict') for obj in config.data_objects)

    def test_transformer_config_immutability_expectations(self):
        """Test behavior related to dataclass mutability (default behavior)"""
        config = TransformerConfig(
            output_file_name="immutable_test.txt",
            page_size=100,
            report_id="IMMUTABLE"
        )
        
        # Dataclass is mutable by default, so these should work
        original_filename = config.output_file_name
        config.output_file_name = "modified_test.txt"
        
        assert config.output_file_name != original_filename
        assert config.output_file_name == "modified_test.txt"

    def test_transformer_config_complex_scenarios(self):
        """Test complex real-world scenarios"""
        # Complex scenario with large dataset
        large_data_objects = [MockDataObject(f"template_{i}.txt", i % 2 == 0) for i in range(100)]
        
        complex_config = TransformerConfig(
            output_file_name="COMPLEX_ELIGIBILITY_REPORT_2023_Q4.txt",
            page_size=500,
            report_id="COMPLEX_PS719101US_2023Q4",
            data_objects=large_data_objects
        )
        
        assert len(complex_config.data_objects) == 100
        assert complex_config.page_size == 500
        assert "2023" in complex_config.output_file_name
        assert "2023" in complex_config.report_id

    def test_transformer_config_string_formatting(self):
        """Test string formatting with TransformerConfig"""
        config = TransformerConfig(
            output_file_name="format_test.txt",
            page_size=100,
            report_id="FORMAT_TEST"
        )
        
        # Test f-string formatting
        f_string = f"Config: {config.output_file_name}, Page Size: {config.page_size}, ID: {config.report_id}"
        assert "format_test.txt" in f_string
        assert "100" in f_string
        assert "FORMAT_TEST" in f_string
