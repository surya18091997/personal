import pytest
from unittest.mock import MagicMock, patch, mock_open
from datetime import datetime
import pandas as pd
import struct

from src.report_generator.transformers.loan_file_transformer import LoanFileTransformer
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.loan_data_object import LoanDataObject
from src.report_generator.templates.data_objects.loan_trailer_object import LoanTrailerObject
from src.report_generator.transformers.report_types import ReportType


@pytest.fixture(scope='function', autouse=True)
def mock_spark():
    """Mock PySpark SparkSession for all tests."""
    with patch('pyspark.sql.SparkSession') as mock_spark:
        # Create mock for SparkSession.builder.appName().getOrCreate()
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        yield mock_session


# Create a more sophisticated mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestLoanFileTransformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208801US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('pyspark.sql.functions'),
            patch('struct.unpack', return_value=(0,)),
            patch('pandas.read_csv'),
            patch('src.report_generator.transformers.loan_file_transformer.pd.read_csv')
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = LoanFileTransformer(config_mock, ReportType.US, logger_mock)

            # Mock any additional attributes needed for testing
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_header(self, transformer):
        # Mock the pay_end_date method which is used by _header
        transformer.pay_end_date = MagicMock(return_value='01/01/25')

        header = transformer._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == '01/01/25'
        assert header.run_at == '10:00:00'
        assert header.report_number == 'BE208801US'
        assert header.page_no == '1'
        assert header.pay_period_date == '01/01/25'
        assert header.report_name == '401K LOANS OUTBOUND FILE(WEEKLY)'

    def test_dynamic_trailer(self, transformer):
        # Create sample records with loan amounts using the correct parameters
        # LoanDataObject takes: ssn, win, loan_number, loan_amount, pay_end_date, loan_cr_date
        records = [
            LoanDataObject(
                ssn="123-45-6789",
                win="WIN123456",
                loan_number="12345",
                loan_amount="1000",
                pay_end_date="20250101",
                loan_cr_date="20250101"
            ),
            LoanDataObject(
                ssn="234-56-7890",
                win="WIN234567",
                loan_number="23456",
                loan_amount="2000",
                pay_end_date="20250102",
                loan_cr_date="20250102"
            )
        ]

        trailer = transformer._dynamic_trailer(records)

        assert isinstance(trailer, LoanTrailerObject)
        assert trailer.total == 2
        assert trailer.total_loan_amount == 3000  # Sum of 1000 + 2000

    def test_trailer(self, transformer):
        with patch('src.report_generator.transformers.loan_file_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = transformer._trailer()

            assert isinstance(trailer, TrailerObject)
            assert trailer.run_on == '01/01/25'
            assert trailer.run_at == '10:00:00'
            assert trailer.report_number == 'BE208801US'
            assert trailer.pay_period_date == '01/01/25'

    def test_pay_end_date(self, transformer):
        # Mock pandas.read_csv to return a sample dataframe
        mock_data = [['FILLER1', '2025123', 'FILLER2', 'FILLER3']]  # Day 123 of 2025 (May 3rd, 2025)

        with patch('pandas.read_csv', return_value=pd.DataFrame(mock_data)):
            with patch('builtins.open', mock_open()) as mock_file:
                # Test with different date formats
                result_ymd = transformer.pay_end_date('%Y-%m-%d')
                result_mdy = transformer.pay_end_date('%m/%d/%y')

                # Verify open() was called with the correct file path
                mock_file.assert_called_with(transformer.configs[ReportType.US]['uhdr'], 'r')

                # Check the conversion from Julian to Gregorian
                assert result_ymd == '2025-05-03'
                assert result_mdy == '05/03/25'

    def test_create_loan_object(self, transformer):
        from src.report_generator.transformers.loan_file_transformer import create_loan_object
        from datetime import date

        # Create a mock row with the required fields
        mock_row = {
            'WIN_NBR': 'WIN123456',
            'SSN': '123-45-6789',
            'LOAN_NUMBER': 'L12345',
            'LOAN_AMOUNT': 5000,
            'startDate': date(2025, 5, 15)  # Example date
        }

        # Call the function with a formatted date string
        result = create_loan_object(mock_row, "2025-06-10")

        # Verify the LoanDataObject was created correctly
        assert isinstance(result, LoanDataObject)
        assert result.win == 'WIN123456'
        assert result.ssn == '123-45-6789'
        assert result.loan_number == 'L12345'
        assert result.loan_amount == '00000005000'  # Should be padded to 11 characters with leading zeros
        assert result.pay_end_date == '2025-06-08'  # Should be 2 days before the provided date
        assert result.loan_cr_date == '2025-05-15'  # Should match the startDate from the row
    
    def test_data_template_name(self, transformer):
        # Test the data_template_name method
        expected_name = 'loan_data.template'
        assert transformer.data_template_name() == expected_name

    def test_identifier(self, transformer):
        # Test the identifier method
        expected_id = 'loan'
        assert transformer.identifier() == expected_id
        
    def test_transform_method_valid_data(self, transformer):
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-01')
        transformer.db2_frame = MagicMock()
        transformer.cosmos_dataframe = MagicMock()
        with patch('src.report_generator.transformers.loan_file_transformer.F', MagicMock()):
            # Mock Spark DataFrames
            mock_outbound_df = MagicMock()
            mock_db2_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_file_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock Spark read
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_outbound_df
            mock_reader.option.return_value = mock_option
            transformer.spark.read = mock_reader

            # Mock DataFrame methods
            mock_outbound_df.repartition.return_value.persist.return_value = mock_outbound_df
            mock_outbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['123456789']

            transformer.db2_frame.return_value = mock_db2_df
            mock_db2_df.select.return_value.withColumn.return_value.filter.return_value.filter.return_value.cache.return_value = mock_db2_df

            mock_outbound_df.join.return_value.select.return_value.cache.return_value = mock_file_df
            mock_file_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN123']

            transformer.cosmos_dataframe.return_value.load.return_value.filter.return_value.filter.return_value.filter.return_value.select.return_value.cache.return_value = mock_cosmos_df

            mock_file_df.join.return_value.select.return_value = mock_result_df

            # Mock RDD transformation
            # Sample row data: SSN, LOAN_NUMBER, LOAN_AMOUNT, WIN_NBR, startDate
            mock_row = MagicMock()
            mock_row.__getitem__ = lambda _, key: {
                'SSN': '123456789',
                'LOAN_NUMBER': 'L001',
                'LOAN_AMOUNT': 5000,
                'WIN_NBR': 'WIN123',
                'startDate': datetime(2025, 1, 1)
            }[key]
            mock_result_df.rdd.map.return_value.collect.return_value = [
                LoanDataObject(ssn='123456789', win='WIN123', loan_number='L001', loan_amount='00000005000', pay_end_date='2025-05-30', loan_cr_date='2025-01-01')
            ]

            # Call the method
            results = transformer._transform()

            # Assertions
            assert len(results) == 1
            assert isinstance(results[0], LoanDataObject)
            assert results[0].ssn == '123456789'
            assert results[0].loan_amount == '00000005000'
            transformer.logger.info.assert_any_call("Starting loan file transformation process")
            transformer.logger.info.assert_any_call("Outbound dataframe loaded and persisted")
            transformer.logger.info.assert_any_call("DB2 dataframe loaded and filtered based on outbound_df['SSN']")
            transformer.logger.info.assert_any_call("First join completed and intermediates cleaned")
            transformer.logger.info.assert_any_call("Cosmos dataframe loaded and cached")
            transformer.logger.info.assert_any_call("Processing final results")
            transformer.logger.info.assert_any_call("Loan transformation completed, returning 1 records")

    def test_transform_method_empty_outbound_df(self, transformer):
        transformer.pay_end_date = MagicMock(return_value='2025-06-01')
        transformer.db2_frame = MagicMock()
        transformer.cosmos_dataframe = MagicMock()
        with patch('src.report_generator.transformers.loan_file_transformer.F', MagicMock()):
            mock_outbound_df = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_outbound_df
            mock_reader.option.return_value = mock_option
            transformer.spark.read = mock_reader

            mock_outbound_df.repartition.return_value.persist.return_value = mock_outbound_df
            # Simulate empty SSN list from outbound_df
            mock_outbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = []

            results = transformer._transform()
            assert len(results) == 0
            transformer.logger.info.assert_any_call("SSN numbers collected for filtering db2 data: 0")
            # No assert_not_called for db2_frame or cosmos_dataframe

    def test_transform_method_no_matching_db2_data(self, transformer):
        transformer.pay_end_date = MagicMock(return_value='2025-06-01')
        transformer.db2_frame = MagicMock()
        transformer.cosmos_dataframe = MagicMock()
        with patch('src.report_generator.transformers.loan_file_transformer.F', MagicMock()):
            mock_outbound_df = MagicMock()
            mock_db2_df = MagicMock()
            mock_file_df = MagicMock()

            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_outbound_df
            mock_reader.option.return_value = mock_option
            transformer.spark.read = mock_reader

            mock_outbound_df.repartition.return_value.persist.return_value = mock_outbound_df
            mock_outbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['123456789']

            transformer.db2_frame.return_value = mock_db2_df
            mock_db2_df.select.return_value.withColumn.return_value.filter.return_value.filter.return_value.cache.return_value = mock_db2_df
            # Simulate no join results with db2_df
            mock_outbound_df.join.return_value.select.return_value.cache.return_value = mock_file_df
            # Simulate empty WIN_NBR list from file_df (outbound_df joined with db2_df)
            mock_file_df.select.return_value.rdd.flatMap.return_value.collect.return_value = []

            results = transformer._transform()
            assert len(results) == 0
            transformer.logger.info.assert_any_call("Win numbers collected for filtering cosmos data: 0")
            # No assert_not_called for cosmos_dataframe

    def test_transform_method_no_matching_cosmos_data(self, transformer):
        transformer.pay_end_date = MagicMock(return_value='2025-06-01')
        transformer.db2_frame = MagicMock()
        transformer.cosmos_dataframe = MagicMock()
        with patch('src.report_generator.transformers.loan_file_transformer.F', MagicMock()):
            mock_outbound_df = MagicMock()
            mock_db2_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_file_df = MagicMock()
            mock_result_df = MagicMock()

            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_outbound_df
            mock_reader.option.return_value = mock_option
            transformer.spark.read = mock_reader

            mock_outbound_df.repartition.return_value.persist.return_value = mock_outbound_df
            mock_outbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['123456789']

            transformer.db2_frame.return_value = mock_db2_df
            mock_db2_df.select.return_value.withColumn.return_value.filter.return_value.filter.return_value.cache.return_value = mock_db2_df

            mock_outbound_df.join.return_value.select.return_value.cache.return_value = mock_file_df
            mock_file_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN123']

            transformer.cosmos_dataframe.return_value.load.return_value.filter.return_value.filter.return_value.filter.return_value.select.return_value.cache.return_value = mock_cosmos_df

            # Simulate no join results with cosmos_df
            mock_file_df.join.return_value.select.return_value = mock_result_df
            mock_result_df.rdd.map.return_value.collect.return_value = []

            results = transformer._transform()
            assert len(results) == 0
            transformer.logger.info.assert_any_call("Loan transformation completed, returning 0 records")

    def test_transform_data_integrity_and_format(self, transformer):
        transformer.pay_end_date = MagicMock(return_value='2025-03-15') # YYYY-MM-DD
        transformer.db2_frame = MagicMock()
        transformer.cosmos_dataframe = MagicMock()
        with patch('src.report_generator.transformers.loan_file_transformer.F', MagicMock()):
            mock_outbound_df = MagicMock()
            mock_db2_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_file_df = MagicMock()
            mock_result_df = MagicMock()

            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_outbound_df
            mock_reader.option.return_value = mock_option
            transformer.spark.read = mock_reader

            mock_outbound_df.repartition.return_value.persist.return_value = mock_outbound_df
            mock_outbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['987654321']

            transformer.db2_frame.return_value = mock_db2_df
            mock_db2_df.select.return_value.withColumn.return_value.filter.return_value.filter.return_value.cache.return_value = mock_db2_df

            mock_outbound_df.join.return_value.select.return_value.cache.return_value = mock_file_df
            mock_file_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN456']

            transformer.cosmos_dataframe.return_value.load.return_value.filter.return_value.filter.return_value.filter.return_value.select.return_value.cache.return_value = mock_cosmos_df

            mock_file_df.join.return_value.select.return_value = mock_result_df

            # Mock row data for create_loan_object
            mock_row_data = {
                'WIN_NBR': 'WIN456',
                'SSN': '987654321',
                'LOAN_NUMBER': 'L002',
                'LOAN_AMOUNT': 12345, # Integer, should be formatted to string with leading zeros
                'startDate': datetime(2025, 2, 10) # datetime.date object
            }
            # Wrap mock_row_data in a mock that behaves like a Spark Row
            mock_spark_row = MagicMock()
            mock_spark_row.__getitem__ = lambda _, key: mock_row_data[key]

            # Simulate the map operation calling create_loan_object
            # The create_loan_object function is imported and called directly in the real _transform
            from src.report_generator.transformers.loan_file_transformer import create_loan_object

            # We need to ensure that the lambda row: create_loan_object(row, pay_end_date) is correctly simulated
            # The collect method will return a list of what create_loan_object returns
            mock_result_df.rdd.map.return_value.collect.return_value = [
                 create_loan_object(mock_spark_row, '2025-03-15') # Call with the same pay_end_date
            ]

            results = transformer._transform()
            assert len(results) == 1
            loan_obj = results[0]

            assert isinstance(loan_obj, LoanDataObject)
            assert loan_obj.win == 'WIN456'
            assert loan_obj.ssn == '987654321'
            assert loan_obj.loan_number == 'L002'
            assert loan_obj.loan_amount == '00000012345' # Check zfill
            assert loan_obj.pay_end_date == '2025-03-13' # pay_end_date - 2 days
            assert loan_obj.loan_cr_date == '2025-02-10' # startDate formatted
