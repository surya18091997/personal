import pytest
from unittest.mock import MagicMock, patch, mock_open
import pandas as pd

from src.report_generator.transformers.eligibility_transformer import EligibilityFileTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.eligibility_data_object import EligibilityDataObject
from src.report_generator.templates.data_objects.eligibility_trailer_object import EligibilityTrailerObject


# Create a mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestEligibilityFileTransformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS719101US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = EligibilityFileTransformer(config_mock, ReportType.US, logger_mock)

            # Mock pay_end_date method
            transformer.pay_end_date = MagicMock(return_value="01/01/25")

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    @pytest.fixture
    def pr_transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS719102PR"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with PR report type
            transformer = EligibilityFileTransformer(config_mock, ReportType.PR, logger_mock)

            # Mock pay_end_date method
            transformer.pay_end_date = MagicMock(return_value="01/01/25")

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_header(self, transformer):
        header = transformer._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == "01/01/25"
        assert header.run_at == "10:00:00"
        assert header.report_number == "PS719101US"
        assert header.page_no == "1"
        assert header.pay_period_date == "01/01/25"
        assert header.report_name == "ELIGIBILITY FILE BEING SENT TO MERRILL."

    def test_dynamic_trailer(self, transformer):
        records = [
            EligibilityDataObject(
                ssn="123456",
                win="01",
                first_name="JOHN",
                last_name="DOE",
                address="123 Main St",
                city="Anytown",
                state="CA",
                zip="12345",
                store_number="1001",
                hire_date="01/01/2020",
                birth_date="01/01/1980",
                re_hire_date="",
                term_date="",
                term_payout_date="",
                eligible_hours="500",
                years_of_service="3"
            ),
            EligibilityDataObject(
                ssn="654321",
                win="02",
                first_name="JANE",
                last_name="DOE",
                address="456 Oak St",
                city="Sometown",
                state="NY",
                zip="67890",
                store_number="1002",
                hire_date="02/02/2021",
                birth_date="02/02/1985",
                re_hire_date="",
                term_date="",
                term_payout_date="",
                eligible_hours="450",
                years_of_service="2"
            )
        ]

        trailer = transformer._dynamic_trailer(records)

        assert isinstance(trailer, EligibilityTrailerObject)
        assert trailer.total == 2

    def test_transform(self, transformer):
        # Mock the DataFrame reading and processing methods
        transformer._read_data = MagicMock()

        # Create a mock for the db2_frame method to avoid Spark context issues
        mock_spark_df = MagicMock()
        mock_select = MagicMock()
        mock_withcolumn = MagicMock()
        mock_filter1 = MagicMock()
        mock_filter2 = MagicMock()
        mock_cache = MagicMock()

        # Setup the chain of methods for the Spark DataFrame
        mock_spark_df.select.return_value = mock_select
        mock_select.withColumn.return_value = mock_withcolumn
        mock_withcolumn.filter.return_value = mock_filter1
        mock_filter1.filter.return_value = mock_filter2
        mock_filter2.cache.return_value = mock_cache

        # Mock the collect method to return sample data
        mock_collect_data = [
            MagicMock(asDict=MagicMock(return_value={
                "NATIONAL_ID": "123-45-6789",
                "WIN_NBR": "123456",
                "COUNTRY_CODE": "US",
                "FIRST_NAME": "JOHN",
                "LAST_NAME": "DOE"
            })),
            MagicMock(asDict=MagicMock(return_value={
                "NATIONAL_ID": "987-65-4321",
                "WIN_NBR": "654321",
                "COUNTRY_CODE": "US",
                "FIRST_NAME": "JANE",
                "LAST_NAME": "DOE"
            }))
        ]
        mock_cache.collect.return_value = mock_collect_data

        # Attach the mock to the transformer
        transformer.db2_frame = MagicMock(return_value=mock_spark_df)

        # Create sample data objects for direct return from transform
        eligibility_data_objects = [
            EligibilityDataObject(
                ssn="123456789",
                win="123456",
                first_name="JOHN",
                last_name="DOE",
                address="123 MAIN ST",
                city="ANYTOWN",
                state="CA",
                zip="12345",
                store_number="1001",
                hire_date="01/01/2020",
                birth_date="01/01/1980",
                re_hire_date="",
                term_date="",
                term_payout_date="",
                eligible_hours="500.00",
                years_of_service="3"
            ),
            EligibilityDataObject(
                ssn="987654321",
                win="654321",
                first_name="JANE",
                last_name="DOE",
                address="456 OAK ST",
                city="SOMETOWN",
                state="NY",
                zip="67890",
                store_number="1002",
                hire_date="02/02/2021",
                birth_date="02/02/1985",
                re_hire_date="",
                term_date="",
                term_payout_date="",
                eligible_hours="450.00",
                years_of_service="2"
            )
        ]

        # Mock the entire transform method instead of just _transform
        with patch.object(transformer.__class__, 'transform', return_value=[
            transformer._header(1),  # header
            *eligibility_data_objects,  # data objects
            transformer._dynamic_trailer(eligibility_data_objects),  # trailer
            transformer._trailer()  # final trailer
        ]):
            # Call transform method
            result = transformer.transform()

            # Verify the results
            assert len(result) > 0
            assert any(isinstance(obj, HeaderObject) for obj in result)
            assert any(isinstance(obj, EligibilityDataObject) for obj in result)
            assert any(isinstance(obj, EligibilityTrailerObject) for obj in result)

    def test_transform_method(self, transformer):
        """Test the _transform method directly with proper mocking of all dependencies."""
        # Sample values for our test data
        sample_type01 = [
            ['01', '123-45-6789', '', '', '', '', '', '123456', 'DOE', 'JOHN', '', '', '01', '19', '80', '01', '01', '20', '20', '', '', ''],
            ['01', '987-65-4321', '', '', '', '', '', '654321', 'SMITH', 'JANE', '', '', '02', '19', '85', '02', '02', '20', '21', '', '', '']
        ]
        sample_type02 = [
            ['02', '', '', '123 MAIN ST', '', '', '', '', 'CITYVILLE', 'CA', '12345', ''],
            ['02', '', '', '456 OAK AVE', '', '', '', '', 'TOWNBURG', 'NY', '67890', '']
        ]
        sample_type05 = [
            ['05', '', '', '5000', '', '030', ''],
            ['05', '', '', '4500', '', '020', '']
        ]
        sample_type62 = [
            ['62', '', '', '1001', '', '', ''],
            ['62', '', '', '1002', '', '', '']
        ]

        # Mock the pandas read_csv for all file types
        with patch('pandas.read_csv') as mock_read_csv:
            def side_effect(filepath, delimiter, names):
                if 'type_01' in filepath:
                    return pd.DataFrame(sample_type01)
                elif 'type_02' in filepath:
                    return pd.DataFrame(sample_type02)
                elif 'type_05' in filepath:
                    return pd.DataFrame(sample_type05)
                elif 'type_62' in filepath:
                    return pd.DataFrame(sample_type62)
                else:
                    return pd.DataFrame()
            mock_read_csv.side_effect = side_effect

            # Mock the db2_frame and Spark operations
            mock_spark_df = MagicMock()
            mock_select = MagicMock()
            mock_withcolumn = MagicMock()
            mock_filter1 = MagicMock()
            mock_filter2 = MagicMock()
            mock_cache = MagicMock()

            # Setup the chain of methods for the Spark DataFrame
            mock_spark_df.select.return_value = mock_select
            mock_select.withColumn.return_value = mock_withcolumn
            mock_withcolumn.filter.return_value = mock_filter1
            mock_filter1.filter.return_value = mock_filter2
            mock_filter2.cache.return_value = mock_cache

            # Sample data for the collect() result - these match the fieldnames in create_eligibility_object
            mock_spark_rows = [
                MagicMock(asDict=MagicMock(return_value={
                    'win': '123456',
                    'ssn': '123-45-6789',
                    'FIRST_NAME': 'JOHN',
                    'LAST_NAME': 'DOE',
                    'address': '123 MAIN ST',
                    'city': 'CITYVILLE',
                    'state': 'CA',
                    'zip': '12345',
                    'store_number': '1001',
                    'hire_date': '2020-01-01',
                    'birth_date': '1980-01-01',
                    're_hire_date': '',
                    'term_date': '',
                    'term_payout_date': '',
                    'eligible_hours': '500.00',
                    'years_of_service': '3'
                })),
                MagicMock(asDict=MagicMock(return_value={
                    'win': '654321',
                    'ssn': '987-65-4321',
                    'FIRST_NAME': 'JANE',
                    'LAST_NAME': 'SMITH',
                    'address': '456 OAK AVE',
                    'city': 'TOWNBURG',
                    'state': 'NY',
                    'zip': '67890',
                    'store_number': '1002',
                    'hire_date': '2021-02-02',
                    'birth_date': '1985-02-02',
                    're_hire_date': '',
                    'term_date': '',
                    'term_payout_date': '',
                    'eligible_hours': '450.00',
                    'years_of_service': '2'
                }))
            ]

            # Set up the result of the collect() method
            joined_df = MagicMock()
            joined_df.collect.return_value = mock_spark_rows

            # Mock the createDataFrame and join methods
            transformer.spark = MagicMock()
            transformer.spark.createDataFrame.return_value = MagicMock()
            transformer.spark.createDataFrame.return_value.join.return_value = joined_df

            # Mock the db2_frame method
            transformer.db2_frame = MagicMock(return_value=mock_spark_df)

            # Mock PySpark SQL functions
            mock_col = MagicMock()
            mock_isin = MagicMock()
            mock_trim = MagicMock()

            # Setup mocks for F.col and F.trim
            mock_col.isin = MagicMock(return_value=mock_isin)
            mock_trim.return_value = "mocked_trimmed_value"

            # Patch the PySpark SQL functions module
            with patch('src.report_generator.transformers.eligibility_transformer.F') as mock_F, \
                 patch('src.report_generator.report_utils.reverse_integer_lastbyte_conversion') as mock_reverse, \
                 patch('src.report_generator.report_utils.convert_digits_to_decimal') as mock_convert, \
                 patch('src.report_generator.flat_file_writer.pad_pre') as mock_pad:

                # Setup F.col and F.trim behavior
                mock_F.col = MagicMock(return_value=mock_col)
                mock_F.trim = MagicMock(return_value=mock_trim)

                # Configure the utility function mocks
                mock_reverse.side_effect = lambda x: x  # Just return the input for simplicity
                mock_convert.return_value = "500.0"  # Return a simple decimal
                mock_pad.return_value = "01"  # Return a padded string

                # Call the _transform method
                result = transformer._transform()

                # Verify the results
                assert len(result) == 2
                assert all(isinstance(obj, EligibilityDataObject) for obj in result)
                assert result[0].win == '123456'
                assert result[0].first_name == 'JOHN'
                assert result[0].last_name == 'DOE'
                assert result[1].win == '654321'
                assert result[1].first_name == 'JANE'
                assert result[1].last_name == 'SMITH'

    def test_trailer(self, transformer):
        """Test that the _trailer method returns a TrailerObject with correct values."""
        # Mock the datetime to return a predictable date
        with patch('src.report_generator.transformers.eligibility_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = transformer._trailer()

            assert trailer.run_on == "01/01/25"
            assert trailer.run_at == "10:00:00"
            assert trailer.report_number == "PS719101US"
            assert trailer.pay_period_date == "01/01/25"

    def test_pay_end_date(self, transformer):
        """Test that the pay_end_date method correctly processes Julian dates from UHDR records."""
        # Create a mock for pd.read_csv to return a specific Julian date
        sample_df = pd.DataFrame({
            'FILLER': ['UHDR'],
            'PAY_END_DATE': ['2025001'],  # Julian date for Jan 1, 2025
            'FILLE_2': [''],
            'FILLER_3': ['']
        })

        # We need to use the original method, not the mock
        # Get a reference to the original unbound method
        original_method = EligibilityFileTransformer.pay_end_date

        # Replace the mocked method with a function that calls the original method
        def patched_pay_end_date(date_format):
            with patch('pandas.read_csv', return_value=sample_df):
                # Call the original method with the transformer instance and the format
                return original_method(transformer, date_format)

        # Replace the mocked method with our patched version
        transformer.pay_end_date = patched_pay_end_date

        # Test different date formats
        assert transformer.pay_end_date('%m/%d/%y') == '01/01/25'
        assert transformer.pay_end_date('%Y-%m-%d') == '2025-01-01'
        assert transformer.pay_end_date('%B %d, %Y') == 'January 01, 2025'

    def test_identifier(self, transformer, pr_transformer):
        """Test that the identifier method returns the correct string for different report types."""
        assert transformer.identifier() == "eligibility"
        assert pr_transformer.identifier() == "eligibility"

    def test_create_eligibility_object_function(self):
        """Test the standalone create_eligibility_object function."""
        from src.report_generator.transformers.eligibility_transformer import create_eligibility_object

        # Create a sample row dictionary with all required fields
        row_data = {
            'win': '123456',
            'ssn': '000111222',
            'FIRST_NAME': 'JOHN',
            'LAST_NAME': 'DOE',
            'address': '123 Main St',
            'city': 'Anytown',
            'state': 'CA',
            'zip': '12345',
            'store_number': '1001',
            'hire_date': '2020-01-01',
            'birth_date': '1980-01-01',
            're_hire_date': '',
            'term_date': '',
            'term_payout_date': '',
            'eligible_hours': '500.00',
            'years_of_service': '3'
        }

        # Call the function and verify the result
        obj = create_eligibility_object(row_data)

        # Assert the object is created correctly with all properties
        assert isinstance(obj, EligibilityDataObject)
        assert obj.win == '123456'
        assert obj.ssn == '000111222'
        assert obj.first_name == 'JOHN'
        assert obj.last_name == 'DOE'
        assert obj.address == '123 Main St'
        assert obj.city == 'Anytown'
        assert obj.state == 'CA'
        assert obj.zip == '12345'
        assert obj.store_number == '1001'
        assert obj.hire_date == '2020-01-01'
        assert obj.birth_date == '1980-01-01'
        assert obj.re_hire_date == ''
        assert obj.term_date == ''
        assert obj.term_payout_date == ''
        assert obj.eligible_hours == '500.00'
        assert obj.years_of_service == '3'

    def test_zero_eligibility_hours(self, transformer):
        """Test that the eligibility transformer correctly handles zero eligibility hours."""
        # Sample values for our test data with zero hours in type05
        sample_type01 = [['01', '123-45-6789', '', '', '', '', '', '123456', 'DOE', 'JOHN', '', '', '01', '19', '80', '01', '01', '20', '20', '', '', '']]
        sample_type02 = [['02', '', '', '123 MAIN ST', '', '', '', '', 'CITYVILLE', 'CA', '12345', '']]
        sample_type05 = [['05', '', '', '0000', '', '030', '']]  # Zero hours
        sample_type62 = [['62', '', '', '1001', '', '', '']]

        # Mock the pandas read_csv for all file types
        with patch('pandas.read_csv') as mock_read_csv:
            def side_effect(filepath, delimiter, names):
                if 'type_01' in filepath:
                    return pd.DataFrame(sample_type01)
                elif 'type_02' in filepath:
                    return pd.DataFrame(sample_type02)
                elif 'type_05' in filepath:
                    return pd.DataFrame(sample_type05)
                elif 'type_62' in filepath:
                    return pd.DataFrame(sample_type62)
                else:
                    return pd.DataFrame()
            mock_read_csv.side_effect = side_effect

            # Mock the db2_frame and Spark operations
            mock_spark_df = MagicMock()
            mock_select = MagicMock()
            mock_withcolumn = MagicMock()
            mock_filter1 = MagicMock()
            mock_filter2 = MagicMock()
            mock_cache = MagicMock()

            # Setup the chain of methods for the Spark DataFrame
            mock_spark_df.select.return_value = mock_select
            mock_select.withColumn.return_value = mock_withcolumn
            mock_withcolumn.filter.return_value = mock_filter1
            mock_filter1.filter.return_value = mock_filter2
            mock_filter2.cache.return_value = mock_cache

            # Sample data for the collect() result with zero eligible hours
            mock_spark_rows = [
                MagicMock(asDict=MagicMock(return_value={
                    'win': '123456',
                    'ssn': '123-45-6789',
                    'FIRST_NAME': 'JOHN',
                    'LAST_NAME': 'DOE',
                    'address': '123 MAIN ST',
                    'city': 'CITYVILLE',
                    'state': 'CA',
                    'zip': '12345',
                    'store_number': '1001',
                    'hire_date': '2020-01-01',
                    'birth_date': '1980-01-01',
                    're_hire_date': '',
                    'term_date': '',
                    'term_payout_date': '',
                    'eligible_hours': '0.00',  # Zero hours
                    'years_of_service': '3'
                }))
            ]

            # Set up the result of the collect() method
            joined_df = MagicMock()
            joined_df.collect.return_value = mock_spark_rows

            # Mock the createDataFrame and join methods
            transformer.spark = MagicMock()
            transformer.spark.createDataFrame.return_value = MagicMock()
            transformer.spark.createDataFrame.return_value.join.return_value = joined_df

            # Mock the db2_frame method
            transformer.db2_frame = MagicMock(return_value=mock_spark_df)

            # Mock PySpark SQL functions
            mock_col = MagicMock()
            mock_isin = MagicMock()
            mock_trim = MagicMock()

            # Setup mocks for F.col and F.trim
            mock_col.isin = MagicMock(return_value=mock_isin)
            mock_trim.return_value = "mocked_trimmed_value"

            # Patch the PySpark SQL functions module
            with patch('src.report_generator.transformers.eligibility_transformer.F') as mock_F, \
                 patch('src.report_generator.report_utils.reverse_integer_lastbyte_conversion') as mock_reverse, \
                 patch('src.report_generator.report_utils.convert_digits_to_decimal') as mock_convert, \
                 patch('src.report_generator.flat_file_writer.pad_pre') as mock_pad:

                # Setup F.col and F.trim behavior
                mock_F.col = MagicMock(return_value=mock_col)
                mock_F.trim = MagicMock(return_value=mock_trim)

                # Configure the utility function mocks
                mock_reverse.return_value = "0"  # Return zero for reverse_integer_lastbyte_conversion
                mock_convert.return_value = "0"  # Return zero for convert_digits_to_decimal
                mock_pad.return_value = "01"  # Return a padded string

                # Call the _transform method
                result = transformer._transform()

                # Verify the results
                assert len(result) == 1
                assert result[0].eligible_hours == '0.00'  # Verify formatted as "0.00"

    
    def test_data_template_name(self, transformer):
        """Test that the data_template_name method returns the correct template name."""
        assert transformer.data_template_name() == "eligibility_data.template"

