import pytest
from unittest.mock import MagicMock, patch, mock_open
from pyspark.sql import SparkSession, Row
from pyspark.sql.types import StructType, StructField, StringType
import pandas as pd
import struct

from src.report_generator.transformers.loan_inbound_transformer import (
    LoaninFileTransformer,
    create_loan_inbound_object,
    default_if_nan
)
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.loan_inbound_data_object import LoanInboundDataObject
from src.report_generator.templates.data_objects.loan_inbound_trailer_object import LoanInboundTrailerObject
from src.report_generator.transformers.report_types import ReportType


def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


@pytest.fixture(scope='function', autouse=True)
def mock_spark():
    """Mock PySpark SparkSession for all tests."""
    with patch('pyspark.sql.SparkSession') as mock_spark:
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        yield mock_session

class TestLoaninFileTransformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208801US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = LoaninFileTransformer(config_mock, ReportType.US, logger_mock)

            # Mock any additional attributes needed for testing
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_header(self, transformer):
        transformer.pay_end_date = MagicMock(return_value='01/01/25')

        header = transformer._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == '01/01/25'
        assert header.run_at == '10:00:00'
        assert header.report_number == 'BE208801US'
        assert header.page_no == '1'
        assert header.pay_period_date == '01/01/25'
        assert header.report_name == '401K LOANS INBOUND FILE(WEEKLY)'

    def test_dynamic_trailer(self, transformer):
        records = [
            LoanInboundDataObject(
            win="WIN123",
            loan_number="L001",
            deducted_amount="1000",
            loan_type="TypeA",
            payroll_id="P001",
            goal_amount="2000",
            pay_frequency="Monthly",
            store_location_code="LOC001",
            country_code="US"
            ),
            LoanInboundDataObject(
            win="WIN456",
            loan_number="L002",
            deducted_amount="1500",
            loan_type="TypeB",
            payroll_id="P002",
            goal_amount="2500",
            pay_frequency="Weekly",
            store_location_code="LOC002",
            country_code="US"
            )
        ]

        trailer = transformer._dynamic_trailer(records)

        assert isinstance(trailer, LoanInboundTrailerObject)
        assert trailer.total == 2
        assert trailer.total_deducted_amount == 2500
        assert trailer.total_goal_amount == 4500

    def test_trailer(self, transformer):
        with patch('src.report_generator.transformers.loan_inbound_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = transformer._trailer()

            assert isinstance(trailer, TrailerObject)
            assert trailer.run_on == '01/01/25'
            assert trailer.run_at == '10:00:00'
            assert trailer.report_number == 'BE208801US'
            assert trailer.pay_period_date == '01/01/25'

    def test_data_template_name(self, transformer):
        """Test the data_template_name method returns the correct template name."""
        assert transformer.data_template_name() == "loan_inbound_data.template"

    def test_pay_end_date_success(self, transformer):
        """Test pay_end_date method with valid data."""
        # Mock data for pandas.read_fwf return value
        mock_df = pd.DataFrame({"LOAN-IN-DATE": ["250615"], "LOAN-DETAIL-0": ["Some random content"]})

        with patch('pandas.read_fwf', return_value=mock_df):
            # Test with default format
            result = transformer.pay_end_date()
            assert result == "2025-06-15"

            # Test with custom format
            result = transformer.pay_end_date('%m/%d/%y')
            assert result == "06/15/25"

    def test_pay_end_date_empty_data(self, transformer):
        """Test pay_end_date method with empty data."""
        # Mock empty DataFrame return
        with patch('pandas.read_fwf', return_value=pd.DataFrame()):
            result = transformer.pay_end_date()
            assert result == ""

    def test_pay_end_date_invalid_data(self, transformer):
        """Test pay_end_date method with invalid date format."""
        # Mock data with invalid date format
        mock_df = pd.DataFrame({"LOAN-IN-DATE": ["ABCDEF"], "LOAN-DETAIL-0": ["Some random content"]})

        with patch('pandas.read_fwf', return_value=mock_df):
            result = transformer.pay_end_date()
            assert result == ""

    def test_pay_end_date_exception(self, transformer):
        """Test pay_end_date method when an exception occurs."""
        with patch('pandas.read_fwf', side_effect=Exception("Test exception")):
            result = transformer.pay_end_date()
            assert result == ""

    def test_create_loan_inbound_object_with_all_values(self):
        """Test create_loan_inbound_object function with all values provided."""
        # Create a mock Row as dictionary with all values
        row = {
            'WIN': "WIN123",
            'LOAN_NUMBER': "L001",
            'DEDUCTED_AMOUNT': "5000",
            'LOAN_TYPE': "TypeA",
            'PAYROLL_ID': "P001",
            'GOAL_AMOUNT': "10000",
            'PAYROLL_FREQUENCY': "Monthly",
            'STORE_LOCATION_CODE': "LOC001"
        }

        # Call function with country code
        result = create_loan_inbound_object(row, "US")

        # Verify result
        assert isinstance(result, LoanInboundDataObject)
        assert result.win == "WIN123"
        assert result.loan_number == "L001"
        assert result.deducted_amount == "5000"
        assert result.loan_type == "TypeA"
        assert result.payroll_id == "P001"
        assert result.goal_amount == "10000"
        assert result.pay_frequency == "Monthly"
        assert result.store_location_code == "LOC001"
        assert result.country_code == "US"

    def test_create_loan_inbound_object_with_missing_values(self):
        """Test create_loan_inbound_object function with missing optional values."""
        # Create a mock Row as dictionary with missing values
        row = {
            'WIN': "WIN456",
            'LOAN_NUMBER': "L002",
            'DEDUCTED_AMOUNT': "1500",
            'LOAN_TYPE': "TypeB",
            'PAYROLL_ID': None,
            'GOAL_AMOUNT': None,
            'PAYROLL_FREQUENCY': None,
            'STORE_LOCATION_CODE': "LOC002"
        }

        # Call function with country code
        result = create_loan_inbound_object(row, "PR")

        # Verify result
        assert isinstance(result, LoanInboundDataObject)
        assert result.win == "WIN456"
        assert result.loan_number == "L002"
        assert result.deducted_amount == "1500"
        assert result.loan_type == "TypeB"
        assert result.payroll_id == " "  # Default when None
        assert result.goal_amount == "0"  # Default when None
        assert result.pay_frequency == " "  # Default when None
        assert result.store_location_code == "LOC002"
        assert result.country_code == "PR"

    def test_default_if_nan(self):
        """Test default_if_nan function with various inputs."""
        # Test with NaN values
        assert default_if_nan(pd.NA, "default") == "default"
        assert default_if_nan(pd.NaT, "default") == "default"
        assert default_if_nan(float('nan'), "default") == "default"
        assert default_if_nan(None, "default") == "default"  # Testing None values

        # Test with non-NaN values
        assert default_if_nan("actual", "default") == "actual"
        assert default_if_nan(123, "default") == 123
        assert default_if_nan(0, "default") == 0
        assert default_if_nan(False, "default") == False
        assert default_if_nan("", "default") == ""  # Empty string is not NaN

    def test_identifier(self, transformer):
        """Test identifier method returns the correct identifier."""
        assert transformer.identifier() == "loanin"
    
    def test_transform_method_valid_data(self, transformer):
        """Test the _transform method with valid input data."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock Spark DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            transformer.spark = mock_spark

            # Mock DataFrame operations
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN123456']

            # Mock cosmos query
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df

            expected_loan = LoanInboundDataObject(
            win='WIN123456',
            loan_number='L12345',
            deducted_amount='1500',
            loan_type='General',
            payroll_id='P001',
            goal_amount='3000',
            pay_frequency='Bi-weekly',
            store_location_code='LOC123',
            country_code='US'
            )

            mock_result_df.rdd.map.return_value.collect.return_value = [expected_loan]

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions
            assert len(results) == 1
            assert isinstance(results[0], LoanInboundDataObject)
            assert results[0].win == 'WIN123456'
            assert results[0].loan_number == 'L12345'
            assert results[0].deducted_amount == '1500'
            assert results[0].loan_type == 'General'
            assert results[0].country_code == 'US'

            # Verify method calls
            transformer.pay_end_date.assert_called_once_with('%Y-%m-%d')
            transformer.cosmos_query.assert_called_once()
            mock_inbound_df.unpersist.assert_called_once()
            mock_cosmos_df.unpersist.assert_called_once()

    def test_transform_method_empty_inbound_df(self, transformer):
        """Test the _transform method when inbound dataframe is empty."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock empty inbound DataFrame
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            transformer.spark = mock_spark

            # Mock empty WIN values collection
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = []

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock empty join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df
            mock_result_df.rdd.map.return_value.collect.return_value = []

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions
            assert isinstance(results, list)
            assert len(results) == 0

            # Verify logging calls
            transformer.logger.info.assert_any_call("Win numbers collected for filtering cosmos data: 0")
            transformer.logger.info.assert_any_call("Loan transformation completed, returning 0 records")

    def test_transform_method_no_matching_cosmos_data(self, transformer):
        """Test the _transform method when no matching data is found in cosmos."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            transformer.spark = mock_spark

            # Mock inbound DataFrame with data but no cosmos matches
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN123456']

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock empty join result (no matches)
            mock_inbound_df.join.return_value.select.return_value = mock_result_df
            mock_result_df.rdd.map.return_value.collect.return_value = []

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions
            assert isinstance(results, list)
            assert len(results) == 0

            # Verify logging calls
            transformer.logger.info.assert_any_call("Win numbers collected for filtering cosmos data: 1")
            transformer.logger.info.assert_any_call("Loan transformation completed, returning 0 records")

    def test_transform_method_data_integrity_and_format(self, transformer):
        """Test the _transform method ensures data integrity and proper formatting."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-03-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            # Mock DataFrame operations
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN987654']

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df

            # Mock row data for create_loan_inbound_object
            mock_row_data = {
                'WIN': 'WIN987654',
                'LOAN_NUMBER': 'L67890',
                'DEDUCTED_AMOUNT': '2750',
                'LOAN_TYPE': 'Residential',
                'PAYROLL_ID': 'P123',
                'GOAL_AMOUNT': '5500',
                'PAYROLL_FREQUENCY': 'Monthly',
                'STORE_LOCATION_CODE': 'LOC456'
            }

            # Mock the result collection with create_loan_inbound_object call
            mock_result_df.rdd.map.return_value.collect.return_value = [
            create_loan_inbound_object(mock_row_data, 'US')
            ]

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions for data integrity
            assert len(results) == 1
            loan_obj = results[0]
            assert isinstance(loan_obj, LoanInboundDataObject)
            assert loan_obj.win == 'WIN987654'
            assert loan_obj.loan_number == 'L67890'
            assert loan_obj.deducted_amount == '2750'
            assert loan_obj.loan_type == 'Residential'
            assert loan_obj.payroll_id == 'P123'
            assert loan_obj.goal_amount == '5500'
            assert loan_obj.pay_frequency == 'Monthly'
            assert loan_obj.store_location_code == 'LOC456'
            assert loan_obj.country_code == 'US'

    def test_transform_method_with_pr_report_type(self, transformer):
        """Test the _transform method with PR report type to ensure country code handling."""
        # Mock transformer for PR report type
        transformer.report_type = ReportType.PR
        transformer.configs[ReportType.PR]['country_code'] = 'PR'
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            # Mock DataFrame operations
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN789123']

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df

            # Mock row data
            mock_row_data = {
                'WIN': 'WIN789123',
                'LOAN_NUMBER': 'L11111',
                'DEDUCTED_AMOUNT': '1200',
                'LOAN_TYPE': 'Emergency',
                'PAYROLL_ID': None,  # Test None handling
                'GOAL_AMOUNT': None,  # Test None handling
                'PAYROLL_FREQUENCY': None,  # Test None handling
                'STORE_LOCATION_CODE': 'LOCPR1'
            }

            # Mock the result collection
            mock_result_df.rdd.map.return_value.collect.return_value = [
            create_loan_inbound_object(mock_row_data, 'PR')
            ]

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions for PR report type
            assert len(results) == 1
            loan_obj = results[0]
            assert isinstance(loan_obj, LoanInboundDataObject)
            assert loan_obj.win == 'WIN789123'
            assert loan_obj.loan_number == 'L11111'
            assert loan_obj.deducted_amount == '1200'
            assert loan_obj.loan_type == 'Emergency'
            assert loan_obj.payroll_id == ' '  # Default for None
            assert loan_obj.goal_amount == '0'  # Default for None
            assert loan_obj.pay_frequency == ' '  # Default for None
            assert loan_obj.store_location_code == 'LOCPR1'
            assert loan_obj.country_code == 'PR'

    def test_transform_method_multiple_records(self, transformer):
        """Test the _transform method with multiple records to ensure scalability."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark

            # Mock DataFrame operations for multiple WIN values
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN111', 'WIN222', 'WIN333']

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df

            # Create multiple loan objects
            expected_loans = [
                    LoanInboundDataObject(
                        win='WIN111', loan_number='L001', deducted_amount='1000',
                        loan_type='General', payroll_id='P001', goal_amount='2000',
                        pay_frequency='Weekly', store_location_code='LOC1', country_code='US'
                    ),
                    LoanInboundDataObject(
                        win='WIN222', loan_number='L002', deducted_amount='1500',
                        loan_type='Residential', payroll_id='P002', goal_amount='3000',
                        pay_frequency='Bi-weekly', store_location_code='LOC2', country_code='US'
                    ),
                    LoanInboundDataObject(
                        win='WIN333', loan_number='L003', deducted_amount='2000',
                        loan_type='Emergency', payroll_id='P003', goal_amount='4000',
                        pay_frequency='Monthly', store_location_code='LOC3', country_code='US'
                    )
                ]

            mock_result_df.rdd.map.return_value.collect.return_value = expected_loans

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions for multiple records
            assert len(results) == 3
            assert all(isinstance(loan, LoanInboundDataObject) for loan in results)
            assert results[0].win == 'WIN111'
            assert results[1].win == 'WIN222'
            assert results[2].win == 'WIN333'

            # Verify logging calls
            transformer.logger.info.assert_any_call("Win numbers collected for filtering cosmos data: 3")
            transformer.logger.info.assert_any_call("Loan transformation completed, returning 3 records")

    def test_transform_method_exception_handling(self, transformer):
        """Test the _transform method handles exceptions gracefully."""
        # Mock pay_end_date to raise an exception
        transformer.pay_end_date = MagicMock(side_effect=Exception("Date parsing error"))

        # Call the method and expect an exception to be raised
        with pytest.raises(Exception) as exc_info:
            transformer._transform()

        assert "Date parsing error" in str(exc_info.value)

    def test_transform_method_spark_read_exception(self, transformer):
        """Test the _transform method when Spark read operation fails."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')

        # Mock the entire spark object to raise an exception
        mock_spark = MagicMock()
        mock_reader = MagicMock()
        mock_reader.option.side_effect = Exception("Spark read error")
        mock_spark.read = mock_reader
        transformer.spark = mock_spark

        # Call the method and expect an exception to be raised
        with pytest.raises(Exception) as exc_info:
            transformer._transform()

        assert "Spark read error" in str(exc_info.value)

    def test_transform_method_cosmos_query_exception(self, transformer):
        """Test the _transform method when cosmos query fails."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock(side_effect=Exception("Cosmos query error"))

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock inbound DataFrame
            mock_inbound_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark
            # Mock DataFrame operations
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = ['WIN123']

            # Call the method and expect an exception to be raised
            with pytest.raises(Exception) as exc_info:
                    transformer._transform()

            assert "Cosmos query error" in str(exc_info.value)

    def test_transform_method_edge_case_empty_win_values(self, transformer):
        """Test the _transform method with edge case of empty WIN values from formatting."""
        # Mock pay_end_date
        transformer.pay_end_date = MagicMock(return_value='2025-06-15')
        transformer.cosmos_query = MagicMock()

        with patch('src.report_generator.transformers.loan_inbound_transformer.F', MagicMock()):
            # Mock DataFrames
            mock_inbound_df = MagicMock()
            mock_cosmos_df = MagicMock()
            mock_result_df = MagicMock()

            # Mock the entire spark object
            mock_spark = MagicMock()
            mock_reader = MagicMock()
            mock_option = MagicMock()
            mock_option.csv.return_value.toDF.return_value = mock_inbound_df
            mock_reader.option.return_value = mock_option
            mock_spark.read = mock_reader
            transformer.spark = mock_spark
            # Mock empty WIN values (edge case)
            mock_inbound_df.show.return_value = None
            mock_inbound_df.select.return_value.rdd.flatMap.return_value.collect.return_value = []

            # Mock cosmos operations
            transformer.cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.select.return_value = mock_cosmos_df
            mock_cosmos_df.cache.return_value = mock_cosmos_df

            # Mock empty join result
            mock_inbound_df.join.return_value.select.return_value = mock_result_df
            mock_result_df.rdd.map.return_value.collect.return_value = []

            # Mock unpersist methods
            mock_inbound_df.unpersist.return_value = None
            mock_cosmos_df.unpersist.return_value = None

            # Call the method
            results = transformer._transform()

            # Assertions
            assert isinstance(results, list)
            assert len(results) == 0

            # Verify that cosmos query was called with NULL formatted_ids
            cosmos_query_call = transformer.cosmos_query.call_args[0][0]
            assert "IN (NULL)" in cosmos_query_call