import pytest
from unittest.mock import MagicMock, patch, mock_open
import pandas as pd
from datetime import datetime

from src.report_generator.transformers.eligible_hours_transformer import EligibleHoursTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.eligible_hours_data_object import EligibleHoursDataObject


# Create a mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestEligibleHoursTransformer:
    @pytest.fixture
    def transformer_us(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS085611US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = EligibleHoursTransformer(config_mock, ReportType.US, logger_mock)
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    @pytest.fixture
    def transformer_pr(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS085611PR"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = EligibleHoursTransformer(config_mock, ReportType.PR, logger_mock)
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_initialization_us(self, transformer_us):
        """Test that the US transformer initializes with the correct properties."""
        assert transformer_us.report_id == "PS085611US"
        assert transformer_us.report_name == "401(K) HOURS FILE SENT TO MERRILL LYNCH FOR US"
        assert transformer_us.configs[ReportType.US]['type05'] == 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_US.txt_type_05.csv'

    def test_initialization_pr(self, transformer_pr):
        """Test that the PR transformer initializes with the correct properties."""
        assert transformer_pr.report_id == "PS085611PR"
        assert transformer_pr.report_name == "401(K) HOURS FILE SENT TO MERRILL LYNCH FOR PUERTO RICO"
        assert transformer_pr.configs[ReportType.PR]['type05'] == 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_PR.txt_type_05.csv'

    def test_trailer_returns_none(self, transformer_us):
        """Test that the _trailer method returns None to prevent duplicate trailer."""
        assert transformer_us._trailer() is None

    def test_dynamic_trailer_returns_none(self, transformer_us):
        """Test that the _dynamic_trailer method returns None."""
        records = [MagicMock()]
        assert transformer_us._dynamic_trailer(records) is None

    @patch('src.report_generator.transformers.eligible_hours_transformer.datetime')
    def test_header_us(self, mock_datetime, transformer_us):
        """Test that the header for US report is created correctly."""
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '10:30:45'

        header = transformer_us._header(page=1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == '01/01/25'
        assert header.run_at == '10:30:45'
        assert header.report_number == 'PS085611US'
        assert header.page_no == '1'
        assert header.pay_period_date == '01/01/25'
        assert header.report_name == '401(K) HOURS FILE SENT TO MERRILL LYNCH FOR US'

    @patch('pandas.read_csv')
    def test_transform_with_data(self, mock_read_csv, transformer_us):
        """Test the transform method when data is successfully read from the CSV file."""
        # Create mock DataFrame with 5 records
        mock_df = MagicMock()
        mock_df.__len__.return_value = 5
        mock_read_csv.return_value = mock_df

        result = transformer_us._transform()

        # Verify read_csv was called with correct path
        mock_read_csv.assert_called_once_with(transformer_us.configs[ReportType.US]['type05'])

        # Verify result
        assert len(result) == 1
        data_object = result[0]
        assert isinstance(data_object, EligibleHoursDataObject)
        assert data_object.total_header == 1
        assert data_object.total_trailer == 1
        assert data_object.record_type_01 == 0
        assert data_object.record_type_02 == 0
        assert data_object.record_type_05 == "5"  # formatted count
        assert data_object.record_type_08 == 0
        assert data_object.record_type_10 == 0
        assert data_object.record_type_62 == 0
        assert data_object.total_count == "7"  # 5 records + 2 (header+trailer)

    @patch('pandas.read_csv')
    def test_transform_with_exception(self, mock_read_csv, transformer_us):
        """Test the transform method when an exception occurs while reading the CSV file."""
        # Make read_csv raise an exception
        mock_read_csv.side_effect = Exception("File not found")

        result = transformer_us._transform()

        # Verify logger was called
        transformer_us.logger.error.assert_called_once()

        # Verify result
        assert len(result) == 1
        data_object = result[0]
        assert isinstance(data_object, EligibleHoursDataObject)
        assert data_object.record_type_05 == "0"
        assert data_object.total_count == "2"  # 0 records + 2 (header+trailer)

    def test_format_count_simple(self, transformer_us):
        """Test the format_count method with a simple number."""
        assert transformer_us.format_count(123) == "123"

    def test_format_count_thousands(self, transformer_us):
        """Test the format_count method with a number in thousands."""
        assert transformer_us.format_count(1234) == "1,234"

    def test_format_count_millions(self, transformer_us):
        """Test the format_count method with a number in millions."""
        assert transformer_us.format_count(1234567) == "1,234,567"

    def test_format_count_zero(self, transformer_us):
        """Test the format_count method with zero."""
        assert transformer_us.format_count(0) == "0"

    def test_format_count_float(self, transformer_us):
        """Test the format_count method with a float number."""
        assert transformer_us.format_count(123.45) == "123"  # should truncate to integer

    def test_identifier(self, transformer_us):
        """Test that the identifier method returns the correct string."""
        assert transformer_us.identifier() == "eligible_hours"

    def test_data_template_name(self, transformer_us):
        """Test that the data_template_name method returns the correct template name."""
        assert transformer_us.data_template_name() == "eligible_hours_data.template"