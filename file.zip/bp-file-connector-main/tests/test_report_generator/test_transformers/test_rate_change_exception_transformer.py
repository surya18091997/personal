from unittest.mock import MagicMock, patch, mock_open
import pytest
from datetime import datetime

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.rate_change_exception_data_object import RateChangeExceptionDataObject
from src.report_generator.templates.data_objects.rate_change_exception_trailer_object import RateChangeExceptionTrailerObject
from src.report_generator.transformers.rate_change_exception_transformer import RateChangeExceptionTransformer
from src.report_generator.transformers.report_types import ReportType, ExceptionMessageType


def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestRateChangeExceptionTransformer:
    @pytest.fixture
    def transformer_us(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208802US"
        config_mock.page_size = 25
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = RateChangeExceptionTransformer(config_mock, ReportType.US, logger_mock)

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()
    
    @pytest.fixture
    def transformer_pr(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208802PR"
        config_mock.page_size = 25
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = RateChangeExceptionTransformer(config_mock, ReportType.PR, logger_mock)

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    @patch('src.report_generator.transformers.rate_change_exception_transformer.datetime')
    def test_header_us(self, mock_datetime, transformer_us):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        header = transformer_us._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == "01/01/25"
        assert header.run_at == "12:00:00"
        assert header.report_number == "BE208802US"
        assert header.page_no == "1"
        assert header.pay_period_date == "01/01/25"
        assert header.report_name == "US EXCEPTION REPORT"
    
    @patch('src.report_generator.transformers.rate_change_exception_transformer.datetime')
    def test_header_pr(self, mock_datetime, transformer_pr):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        header = transformer_pr._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == "01/01/25"
        assert header.run_at == "12:00:00"
        assert header.report_number == "BE208802PR"
        assert header.page_no == "1"
        assert header.pay_period_date == "01/01/25"
        assert header.report_name == "PR EXCEPTION REPORT"

    @patch('src.report_generator.transformers.rate_change_exception_transformer.datetime')
    def test_trailer_us(self, mock_datetime, transformer_us):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        trailer = transformer_us._trailer()

        assert isinstance(trailer, TrailerObject)
        assert trailer.run_on == "01/01/25"
        assert trailer.run_at == "12:00:00"
        assert trailer.report_number == "BE208802US"
        assert trailer.pay_period_date == "01/01/25"

    @patch('src.report_generator.transformers.rate_change_exception_transformer.datetime')
    def test_trailer_pr(self, mock_datetime, transformer_pr):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        trailer = transformer_pr._trailer()

        assert isinstance(trailer, TrailerObject)
        assert trailer.run_on == "01/01/25"
        assert trailer.run_at == "12:00:00"
        assert trailer.report_number == "BE208802PR"
        assert trailer.pay_period_date == "01/01/25"
    
    def test_dynamic_trailer_empty_data(self, transformer_us):
        # Test with empty records
        empty_records = []
        trailer = transformer_us._dynamic_trailer(empty_records)
        
        assert isinstance(trailer, RateChangeExceptionTrailerObject)
        assert trailer.assoc_not_eligible == 0
        assert trailer.assoc_terminated == 0
        assert trailer.assoc_not_elig_for_cuc == 0
        assert trailer.exceeded_max_regular_rate_nhce_us == 0
        assert trailer.exceeded_max_regular_rate_hce_us == 0
        assert trailer.exceeded_max_catchup_rate_us == 0
        assert trailer.assoc_is_on_hardship == 0
    
    def test_dynamic_trailer_with_data(self, transformer_us):
        # Create test records with various message types
        records = [
            RateChangeExceptionDataObject(
                ssn='123456789', win_nbr='W12345', asc_first_name='John',
                asc_last_name='Doe', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='5', cuc_rate='', message=ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value
            ),
            RateChangeExceptionDataObject(
                ssn='987654321', win_nbr='W67890', asc_first_name='Jane',
                asc_last_name='Smith', asc_status='T', elig_status='N',
                elig_date='', cntry_code='US', hardship_stdate='',
                reg_rate='', cuc_rate='', message=ExceptionMessageType.ASSOC_TERMINATED.value
            ),
            RateChangeExceptionDataObject(
                ssn='555555555', win_nbr='W55555', asc_first_name='Bob',
                asc_last_name='Johnson', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='12', cuc_rate='10', message=ExceptionMessageType.ASSOC_NOT_ELIG_FOR_CUC.value
            ),
            RateChangeExceptionDataObject(
                ssn='111111111', win_nbr='W11111', asc_first_name='Alice',
                asc_last_name='Brown', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='20', cuc_rate='', message=ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_NHCE_US.value
            ),
            RateChangeExceptionDataObject(
                ssn='222222222', win_nbr='W22222', asc_first_name='Charlie',
                asc_last_name='White', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='15', cuc_rate='', message=ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_HCE_US.value
            ),
            RateChangeExceptionDataObject(
                ssn='333333333', win_nbr='W33333', asc_first_name='Dave',
                asc_last_name='Green', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='10', cuc_rate='6', message=ExceptionMessageType.EXCEEDED_MAX_CATCHUP_RATE_US.value
            ),
            RateChangeExceptionDataObject(
                ssn='444444444', win_nbr='W44444', asc_first_name='Eve',
                asc_last_name='Black', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='2025-02-01',
                reg_rate='', cuc_rate='', message=ExceptionMessageType.ASSOC_IS_ON_HARDSHIP.value
            ),
        ]
        
        trailer = transformer_us._dynamic_trailer(records)
        
        assert isinstance(trailer, RateChangeExceptionTrailerObject)
        assert trailer.assoc_not_eligible == 1
        assert trailer.assoc_terminated == 1
        assert trailer.assoc_not_elig_for_cuc == 1
        assert trailer.exceeded_max_regular_rate_nhce_us == 1
        assert trailer.exceeded_max_regular_rate_hce_us == 1
        assert trailer.exceeded_max_catchup_rate_us == 1
        assert trailer.assoc_is_on_hardship == 1

    def test_identifier(self, transformer_us, transformer_pr):
        # The identifier should be the same for both US and PR transformers
        assert transformer_us.identifier() == "rate_change_exception"
        assert transformer_pr.identifier() == "rate_change_exception"

    def test_transform_mock(self, transformer_us):
        # Mock the _transform method to return a list of data objects
        mock_data = [
            RateChangeExceptionDataObject(
                ssn='123456789', win_nbr='W12345', asc_first_name='John',
                asc_last_name='Doe', asc_status='A', elig_status='Y',
                elig_date='2025-01-01', cntry_code='US', hardship_stdate='',
                reg_rate='5', cuc_rate='', message=ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value
            ),
        ]
        
        # Patch the _transform method to return mock data
        with patch.object(transformer_us, '_transform', return_value=mock_data) as mock_transform:
            # Call the original transform method (this will use the mocked _transform)
            result = transformer_us.transform()
            
            # Verify the results
            assert len(result) == 4  # Header, DataObjectWrapper with data, Dynamic Trailer, and Trailer
            assert isinstance(result[0], HeaderObject)  # Page header
            assert isinstance(result[2], RateChangeExceptionTrailerObject)  # Dynamic trailer
            assert isinstance(result[3], TrailerObject)  # Regular trailer
            
            # Check that _transform was called
            mock_transform.assert_called_once()

    def test_transform_empty_data_mock(self, transformer_us):
        # Mock the _transform method to return empty list
        mock_data = []
        
        # Patch the _transform method to return empty mock data
        with patch.object(transformer_us, '_transform', return_value=mock_data) as mock_transform:
            # Call the original transform method (this will use the mocked _transform)
            result = transformer_us.transform()
            
            # Verify the results - when data is empty, the base transform method adds an empty DataObjectWrapper
            assert len(result) == 4  # Header, Empty DataObjectWrapper, Dynamic Trailer, and Trailer
            assert isinstance(result[0], HeaderObject)  # Page header
            assert isinstance(result[2], RateChangeExceptionTrailerObject)  # Dynamic trailer
            assert isinstance(result[3], TrailerObject)  # Regular trailer
            
            # Check that _transform was called
            mock_transform.assert_called_once()

    def test_classify_error_messages(self):
        # Import the _classify_error_messages function from the module
        from src.report_generator.transformers.rate_change_exception_transformer import _classify_error_messages
        
        # Mock the PySpark SQL functions that are used in _classify_error_messages
        with patch('src.report_generator.transformers.rate_change_exception_transformer.when') as mock_when, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.lower') as mock_lower, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.col') as mock_col, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.lit') as mock_lit:
            
            # Create a mock DataFrame with error messages
            mock_df = MagicMock()
            mock_with_column = MagicMock()
            mock_df.withColumn.return_value = mock_with_column
            
            # Setup the mock returns for the SQL functions
            mock_col.return_value = MagicMock()
            mock_lower.return_value = MagicMock()
            mock_lit.return_value = MagicMock()
            mock_when.return_value = MagicMock()
            
            # Call the function with the mock DataFrame
            result = _classify_error_messages(mock_df)
            
            # Check that withColumn was called
            mock_df.withColumn.assert_called_once()
            
            # Assert that the result is the return value from withColumn
            assert result == mock_with_column

    def test_data_template_name(self, transformer_us):
        # Test the data_template_name method
        assert transformer_us.data_template_name() == "rate_change_exception_data.template"

    def test_transform_method_actual_execution(self, transformer_us):
        """Test the actual _transform method execution with all dependencies mocked."""
        from src.report_generator.templates.data_objects.rate_change_exception_data_object import RateChangeExceptionDataObject
        from src.report_generator.transformers.report_types import ExceptionMessageType
        
        # Mock all the external dependencies
        with patch.object(transformer_us, 'postgres_frame') as mock_postgres_frame, \
             patch.object(transformer_us, 'db2_query') as mock_db2_query, \
             patch.object(transformer_us, 'cosmos_query') as mock_cosmos_query, \
             patch('src.report_generator.transformers.rate_change_exception_transformer._classify_error_messages') as mock_classify, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.col') as mock_col, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.explode_outer') as mock_explode, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.first') as mock_first:
            
            # Create mock DataFrames
            mock_archive_events_df = MagicMock()
            mock_event_status_df = MagicMock()
            mock_joined_df = MagicMock()
            mock_classified_df = MagicMock()
            mock_win_associate_df = MagicMock()
            mock_associate_df = MagicMock()
            mock_result_df = MagicMock()
            
            # Setup postgres_frame mock
            mock_postgres_frame.side_effect = [mock_archive_events_df, mock_event_status_df]
            
            # Setup filter chains for archive_events_df
            mock_archive_events_df.filter.return_value = mock_archive_events_df
            mock_archive_events_df.createOrReplaceTempView.return_value = None
            
            # Setup filter chains for event_status_df  
            mock_event_status_df.filter.return_value = mock_event_status_df
            mock_event_status_df.createOrReplaceTempView.return_value = None
            
            # Setup spark.sql mock
            transformer_us.spark.sql.return_value = mock_joined_df
            
            # Setup _classify_error_messages mock
            mock_classify.return_value = mock_classified_df
            mock_classified_df.cache.return_value = mock_classified_df
            
            # Create mock rows for associate_ids collection
            mock_row1 = MagicMock()
            mock_row1.associate_id = "WIN123456"
            mock_row2 = MagicMock() 
            mock_row2.associate_id = "WIN789012"
            
            mock_classified_df.select.return_value.distinct.return_value.collect.return_value = [mock_row1, mock_row2]
            mock_classified_df.show.return_value = None
            
            # Setup db2_query mock
            mock_db2_query.return_value = mock_win_associate_df
            
            # Setup join between classified_df and win_associate_df
            mock_classified_df.join.return_value = mock_win_associate_df  # Reuse for simplicity
            
            # Setup cosmos_query mock and its chain
            mock_cosmos_df = MagicMock()
            mock_cosmos_query.return_value = mock_cosmos_df
            mock_cosmos_df.withColumn.return_value = mock_cosmos_df
            mock_cosmos_df.filter.return_value = mock_cosmos_df
            mock_cosmos_df.orderBy.return_value = mock_associate_df
            mock_associate_df.cache.return_value = mock_associate_df
            mock_associate_df.groupBy.return_value.agg.return_value = mock_associate_df
            
            # Setup final join and result
            mock_win_associate_df.join.return_value = mock_result_df
            mock_result_df.show.return_value = None
            
            # Create mock result rows with all required attributes
            mock_result_row = MagicMock()
            mock_result_row.NATIONAL_ID = "123456789"
            mock_result_row.WIN_NBR = "WIN123456"
            mock_result_row.FIRST_NAME = "John"
            mock_result_row.LAST_NAME = "Doe"
            mock_result_row.EMPLOY_STAT_CODE = "A"
            mock_result_row.isEligible = True
            mock_result_row.eligibleDate = "2025-01-01"
            mock_result_row.COUNTRY_CODE = "US"
            mock_result_row.LOA_EFF_DATE = ""
            mock_result_row.classification = ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value
            
            mock_result_df.collect.return_value = [mock_result_row]
            
            # Setup mock_col to return objects with the required methods
            mock_col_obj = MagicMock()
            mock_col.return_value = mock_col_obj
            mock_explode.return_value = mock_col_obj
            mock_first.return_value = mock_col_obj
            
            # Call the actual _transform method
            result = transformer_us._transform()
            
            # Verify the results
            assert len(result) == 1
            assert isinstance(result[0], RateChangeExceptionDataObject)
            assert result[0].ssn == "123456789"
            assert result[0].win_nbr == "WIN123456"
            assert result[0].asc_first_name == "John"
            assert result[0].asc_last_name == "Doe"
            assert result[0].asc_status == "A"
            assert result[0].elig_status == True
            assert result[0].elig_date == "2025-01-01"
            assert result[0].cntry_code == "US"
            assert result[0].message == ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value
            
            # Verify that key methods were called
            assert mock_postgres_frame.call_count == 2
            mock_postgres_frame.assert_any_call("core_engine.archive_events")
            mock_postgres_frame.assert_any_call("core_engine.event_status")
            
            transformer_us.spark.sql.assert_called_once()
            mock_classify.assert_called_once_with(mock_joined_df)
            mock_db2_query.assert_called_once()
            mock_cosmos_query.assert_called_once()

    def test_transform_method_empty_result_set(self, transformer_us):
        """Test the _transform method when no data is returned from the queries."""
        # Mock all the external dependencies to return empty results
        with patch.object(transformer_us, 'postgres_frame') as mock_postgres_frame, \
             patch.object(transformer_us, 'db2_query') as mock_db2_query, \
             patch.object(transformer_us, 'cosmos_query') as mock_cosmos_query, \
             patch('src.report_generator.transformers.rate_change_exception_transformer._classify_error_messages') as mock_classify, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.col') as mock_col, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.explode_outer') as mock_explode, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.first') as mock_first:
            
            # Create mock DataFrames
            mock_df = MagicMock()
            mock_postgres_frame.side_effect = [mock_df, mock_df]
            mock_df.filter.return_value = mock_df
            mock_df.createOrReplaceTempView.return_value = None
            
            # Setup empty results
            transformer_us.spark.sql.return_value = mock_df
            mock_classify.return_value = mock_df
            mock_df.cache.return_value = mock_df
            mock_df.select.return_value.distinct.return_value.collect.return_value = []  # Empty associate_ids
            mock_df.show.return_value = None
            
            mock_db2_query.return_value = mock_df
            mock_df.join.return_value = mock_df
            
            mock_cosmos_query.return_value = mock_df
            mock_df.withColumn.return_value = mock_df
            mock_df.orderBy.return_value = mock_df
            mock_df.groupBy.return_value.agg.return_value = mock_df
            mock_df.collect.return_value = []  # Empty result set
            
            # Setup mock returns
            mock_col.return_value = MagicMock()
            mock_explode.return_value = MagicMock()
            mock_first.return_value = MagicMock()
            
            # Call the actual _transform method
            result = transformer_us._transform()
            
            # Verify empty result
            assert result == []
            
            # Verify that methods were still called
            assert mock_postgres_frame.call_count == 2
            transformer_us.spark.sql.assert_called_once()
            mock_classify.assert_called_once()

    def test_transform_method_with_ineligible_associate(self, transformer_us):
        """Test the _transform method when an associate is not eligible (isEligible=False)."""
        from src.report_generator.templates.data_objects.rate_change_exception_data_object import RateChangeExceptionDataObject
        from src.report_generator.transformers.report_types import ExceptionMessageType
        
        # Mock all the external dependencies
        with patch.object(transformer_us, 'postgres_frame') as mock_postgres_frame, \
             patch.object(transformer_us, 'db2_query') as mock_db2_query, \
             patch.object(transformer_us, 'cosmos_query') as mock_cosmos_query, \
             patch('src.report_generator.transformers.rate_change_exception_transformer._classify_error_messages') as mock_classify, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.col') as mock_col, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.explode_outer') as mock_explode, \
             patch('src.report_generator.transformers.rate_change_exception_transformer.first') as mock_first:
            
            # Create mock DataFrames - simplified setup
            mock_df = MagicMock()
            mock_postgres_frame.side_effect = [mock_df, mock_df]
            mock_df.filter.return_value = mock_df
            mock_df.createOrReplaceTempView.return_value = None
            
            transformer_us.spark.sql.return_value = mock_df
            mock_classify.return_value = mock_df
            mock_df.cache.return_value = mock_df
            
            # Create mock associate_id
            mock_row = MagicMock()
            mock_row.associate_id = "WIN999999"
            mock_df.select.return_value.distinct.return_value.collect.return_value = [mock_row]
            mock_df.show.return_value = None
            
            mock_db2_query.return_value = mock_df
            mock_df.join.return_value = mock_df
            mock_cosmos_query.return_value = mock_df
            mock_df.withColumn.return_value = mock_df
            mock_df.orderBy.return_value = mock_df
            mock_df.groupBy.return_value.agg.return_value = mock_df
            
            # Create mock result row with isEligible=False to test the edge case
            mock_result_row = MagicMock()
            mock_result_row.NATIONAL_ID = "987654321"
            mock_result_row.WIN_NBR = "WIN999999"
            mock_result_row.FIRST_NAME = "Jane"
            mock_result_row.LAST_NAME = "Smith"
            mock_result_row.EMPLOY_STAT_CODE = "T"
            mock_result_row.isEligible = False  # This should result in empty elig_date
            mock_result_row.eligibleDate = "2025-01-01"  # This should be ignored due to isEligible=False
            mock_result_row.COUNTRY_CODE = "US"
            mock_result_row.LOA_EFF_DATE = "2025-02-01"
            mock_result_row.classification = ExceptionMessageType.ASSOC_TERMINATED.value
            
            mock_df.collect.return_value = [mock_result_row]
            
            # Setup mock returns
            mock_col.return_value = MagicMock()
            mock_explode.return_value = MagicMock()
            mock_first.return_value = MagicMock()
            
            # Call the actual _transform method
            result = transformer_us._transform()
            
            # Verify the results - specifically that elig_date is empty when isEligible=False
            assert len(result) == 1
            assert isinstance(result[0], RateChangeExceptionDataObject)
            assert result[0].ssn == "987654321"
            assert result[0].elig_status == False
            assert result[0].elig_date == ""  # Should be empty because isEligible=False
            assert result[0].hardship_stdate == "2025-02-01"  # Should be converted to string
            assert result[0].message == ExceptionMessageType.ASSOC_TERMINATED.value
