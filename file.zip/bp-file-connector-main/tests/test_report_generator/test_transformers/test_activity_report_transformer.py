import pytest
from unittest.mock import MagicMock, patch, mock_open
from datetime import datetime
import struct
from src.report_generator.transformers.activity_report_transformer import ActivityReportTransformer
from src.report_generator.templates.data_objects.rate_change_activity_data_object import RateChangeActivityDataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.rate_change_activity_trailer_object import RateChangeActivityTrailerObject
from src.report_generator.transformers.report_types import ReportType


# Create a more sophisticated mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestActivityReportTransformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208801US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = ActivityReportTransformer(config_mock, ReportType.US, logger_mock)

            # Mock any additional attributes needed for testing
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_header(self, transformer):
        with patch('src.report_generator.transformers.activity_report_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            header = transformer._header(1)

            assert isinstance(header, HeaderObject)
            assert header.run_on == '01/01/25'
            assert header.run_at == '00:00:00'
            assert header.report_number == 'BE208801US'
            assert header.page_no == '1'
            assert header.pay_period_date == '01/01/25'
            assert header.report_name == 'ACTIVITY REPORT'

    def test_trailer(self, transformer):
        with patch('src.report_generator.transformers.activity_report_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = transformer._trailer()

            assert isinstance(trailer, TrailerObject)
            assert trailer.run_on == '01/01/25'
            assert trailer.run_at == '00:00:00'
            assert trailer.report_number == 'BE208801US'
            assert trailer.pay_period_date == '01/01/25'

    def test_dynamic_trailer(self, transformer):
        records = [
            RateChangeActivityDataObject("US", "REG", "WAL-MART", "10", "5", "3", "7", "2", "27"),
            RateChangeActivityDataObject("US", "CUC", "WAL-MART", "5", "2", "1", "3", "1", "12")
        ]

        trailer = transformer._dynamic_trailer(records)

        assert isinstance(trailer, RateChangeActivityTrailerObject)
        assert trailer.enrolled_count == 15
        assert trailer.change_to_0_count == 7
        assert trailer.decreased_count == 4
        assert trailer.increased_count == 10
        assert trailer.corrected_count == 3
        assert trailer.total == 39
        assert trailer.percent_grand_total == "100"

    def test_transform(self, transformer):
        result = transformer._transform()

        assert isinstance(result, list)
        assert all(isinstance(item, RateChangeActivityDataObject) for item in result)
        assert len(result) == 8  # Based on the implementation which returns 8 dummy items

    def test_identifier(self, transformer):
        assert transformer.identifier() == "activity_report"

    def test_data_template_name(self, transformer):
        assert transformer.data_template_name() == "rate_change_activity_data.template"
