import pytest
from unittest.mock import MagicMock, patch, mock_open
from datetime import datetime
import pandas as pd
import numpy as np
import struct

from src.report_generator.transformers.loa_file_transformer import LoaFileTransformer, create_loa_object
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.loa_data_object import LoaDataObject
from src.report_generator.templates.data_objects.loa_trailer_object import LoaTrailerObject
from src.report_generator.transformers.report_types import ReportType


# Create a more sophisticated mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestLoaFileTransformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208801US"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,)),
            patch('pandas.read_csv'),
            patch('src.report_generator.transformers.loa_file_transformer.pd.read_csv')
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = LoaFileTransformer(config_mock, ReportType.US, logger_mock)

            # Mock any additional attributes needed for testing
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()
                
    @pytest.fixture
    def pr_transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "BE208801PR"
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,)),
            patch('pandas.read_csv'),
            patch('src.report_generator.transformers.loa_file_transformer.pd.read_csv')
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = LoaFileTransformer(config_mock, ReportType.PR, logger_mock)

            # Mock any additional attributes needed for testing
            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    def test_header(self, transformer):
        # Mock the pay_end_date method which is used by _header
        transformer.pay_end_date = MagicMock(return_value='01/01/25')

        header = transformer._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == '01/01/25'
        assert header.run_at == '10:00:00'
        assert header.report_number == 'BE208801US'
        assert header.page_no == '1'
        assert header.pay_period_date == '01/01/25'
        assert header.report_name == '401(K) LOA INFORMATION FILE.'

    def test_dynamic_trailer(self, transformer):
        # Create sample records using actual LoaDataObject instances with the correct parameters
        records = [
            LoaDataObject(
                win="123456789",
                leave_type="FMLA",
                start_date="20250101",
                end_date="20250601"
            ),
            LoaDataObject(
                win="987654321",
                leave_type="Medical",
                start_date="20250215",
                end_date="20250815"
            ),
            LoaDataObject(
                win="456789123",
                leave_type="Disability",
                start_date="20250305",
                end_date="20251205"
            )
        ]

        trailer = transformer._dynamic_trailer(records)

        assert isinstance(trailer, LoaTrailerObject)
        assert trailer.total == 3

    def test_trailer(self, transformer):
        with patch('src.report_generator.transformers.loa_file_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = transformer._trailer()

            assert isinstance(trailer, TrailerObject)
            assert trailer.run_on == '01/01/25'
            assert trailer.run_at == '10:00:00'
            assert trailer.report_number == 'BE208801US'
            assert trailer.pay_period_date == '01/01/25'
            
    def test_transform(self, transformer):
        # Create mock data for type01 and type02
        type01_data = [
            ["1", "2", "42", "4", "123456789", "6", "7"],  # Non-military
            ["1", "2", "52", "4", "987654321", "6", "7"],  # Military
        ]
        type02_data = [
            ["1", "2", "20250101", "20250201", "20250301", "20250401", "7", "8"],
            ["1", "2", "20250501", "20250601", "20250701", "20250801", "7", "8"]
        ]

        # Configure the mocks
        pd.read_csv = MagicMock()
        pd.read_csv.side_effect = lambda file_path, delimiter, names: MagicMock(values=MagicMock(tolist=MagicMock(return_value=type01_data if file_path == transformer.configs[ReportType.US]['type01'] else type02_data)))

        # Replace the actual read_csv with our mock
        with patch('src.report_generator.transformers.loa_file_transformer.pd.read_csv') as mock_read_csv:
            mock_read_csv.side_effect = lambda file_path, delimiter, names: MagicMock(values=MagicMock(tolist=MagicMock(return_value=type01_data if file_path == transformer.configs[ReportType.US]['type01'] else type02_data)))
            
            result = transformer._transform()

            # Verify the results
            assert isinstance(result, list)
            assert len(result) == 2
            assert all(isinstance(item, LoaDataObject) for item in result)
            
            # Check specific values
            assert result[0].win == "123456789"
            assert result[0].leave_type == "NON-MILT"
            assert result[0].start_date == "2025-03-01"  # Format is transformed by create_loa_object
            assert result[0].end_date == "2025-04-01"    # Format is transformed by create_loa_object
            
            assert result[1].win == "987654321"
            assert result[1].leave_type == "MILITARY"
            assert result[1].start_date == "2025-05-01"  # Format is transformed by create_loa_object
            assert result[1].end_date == "2025-06-01"    # Format is transformed by create_loa_object

    def test_pay_end_date(self, transformer):
        # Mock pandas.read_csv to return a specific Julian date
        mock_df_data = [["Filler", "2025180", "Filler2", "Filler3"]]  # Julian date for June 29, 2025
        
        with patch('src.report_generator.transformers.loa_file_transformer.pd.read_csv') as mock_read_csv:
            mock_read_csv.return_value = MagicMock(values=MagicMock(tolist=MagicMock(return_value=mock_df_data)))
            
            # Test with different date formats
            result_mdy = transformer.pay_end_date('%m/%d/%y')
            assert result_mdy == "06/29/25"
            
            mock_read_csv.return_value = MagicMock(values=MagicMock(tolist=MagicMock(return_value=mock_df_data)))
            result_ymd = transformer.pay_end_date('%Y-%m-%d')
            assert result_ymd == "2025-06-29"

    def test_identifier(self, transformer):
        assert transformer.identifier() == "loa"

    def test_create_loa_object_with_valid_dates(self):
        # Test with valid date strings
        row = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': '20250101',
            'end_date': '20250630'
        }
        
        result = create_loa_object(row)
        
        assert isinstance(result, LoaDataObject)
        assert result.win == '123456789'
        assert result.leave_type == 'MILITARY'
        assert result.start_date == '2025-01-01'
        assert result.end_date == '2025-06-30'

    def test_create_loa_object_with_float_dates(self):
        # Test with dates as floats (with decimal points)
        row = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': 20250101.0,
            'end_date': 20250630.0
        }
        
        result = create_loa_object(row)
        
        assert isinstance(result, LoaDataObject)
        assert result.win == '123456789'
        assert result.leave_type == 'MILITARY'
        assert result.start_date == '2025-01-01'
        assert result.end_date == '2025-06-30'

    def test_create_loa_object_with_missing_dates(self):
        # Test with None, NaN, and empty dates
        row = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': None,
            'end_date': np.nan
        }
        
        result = create_loa_object(row)
        
        assert isinstance(result, LoaDataObject)
        assert result.win == '123456789'
        assert result.leave_type == 'MILITARY'
        assert result.start_date == ' '
        assert result.end_date == ' '

        # Test with empty string
        row = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': "",
            'end_date': ""
        }
        
        result = create_loa_object(row)
        
        assert isinstance(result, LoaDataObject)
        assert result.start_date == ' '
        assert result.end_date == ' '

    def test_create_loa_object_with_invalid_date_format(self):
        # Test with invalid date format
        row = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': 'invalid-date',
            'end_date': '01-01-2025'  # Wrong format
        }
        
        result = create_loa_object(row)
        
        assert isinstance(result, LoaDataObject)
        assert result.win == '123456789'
        assert result.leave_type == 'MILITARY'
        assert result.start_date == 'invalid-date'  # Should keep original if conversion fails
        assert result.end_date == '01-01-2025'      # Should keep original if conversion fails
        
    def test_create_loa_object_exception_scenarios(self):
        """Test various exception scenarios in date conversion"""
        # Test with date string of incorrect length
        row1 = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': '202501',  # Too short
            'end_date': '2025063012'  # Too long
        }
        result1 = create_loa_object(row1)
        assert result1.start_date == '202501'  # Should keep original
        assert result1.end_date == '2025063012'  # Should keep original
        
        # Test with non-numeric characters in date string
        row2 = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': '2025X101',
            'end_date': '20250A30'
        }
        result2 = create_loa_object(row2)
        assert result2.start_date == '2025-X1-01'  # Converted despite non-numeric char
        assert result2.end_date == '2025-0A-30'  # Converted despite non-numeric char
        
        # Test with boolean value
        row3 = {
            'win': '123456789',
            'leave_type': 'MILITARY',
            'start_date': True,
            'end_date': False
        }
        result3 = create_loa_object(row3)
        assert result3.start_date == True  # String conversion of boolean
        assert result3.end_date == False  # String conversion of boolean

    def test_configs_for_different_report_types(self, transformer, pr_transformer):
        # Verify US configuration paths
        assert transformer.configs[ReportType.US]['uhdr'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_UHDR.csv'
        assert transformer.configs[ReportType.US]['type01'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_01.csv'
        assert transformer.configs[ReportType.US]['type02'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_02.csv'
        
        # Verify PR configuration paths
        assert pr_transformer.configs[ReportType.PR]['uhdr'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_UHDR.csv'
        assert pr_transformer.configs[ReportType.PR]['type01'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_01.csv'
        assert pr_transformer.configs[ReportType.PR]['type02'] == 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_02.csv'

    def test_data_template_name(self, transformer):
        assert transformer.data_template_name() == "loa_data.template"