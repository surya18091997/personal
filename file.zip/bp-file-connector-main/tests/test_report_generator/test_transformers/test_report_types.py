import pytest
from src.report_generator.transformers.report_types import ReportType, ExceptionMessageType


def test_report_type_enum():
    assert ReportType.US.value == 1
    assert ReportType.PR.value == 2
    assert ReportType.WV.value == 3
    assert ReportType.NY.value == 4
    assert len(ReportType) == 4


def test_exception_message_type_enum():
    assert ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value == "ASSOC NOT ELIGIBLE"
    assert ExceptionMessageType.ASSOC_TERMINATED.value == "ASSOC TERMINATED"
    assert ExceptionMessageType.ASSOC_NOT_ELIG_FOR_CUC.value == "ASSOC NOT ELIG FOR CUC"
    assert ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_NHCE_US.value == "EXCEEDED MAX REGULAR RATE NHCE US"
    assert ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_HCE_US.value == "EXCEEDED MAX REGULAR RATE HCE US"
    assert ExceptionMessageType.EXCEEDED_MAX_CATCHUP_RATE_US.value == "EXCEEDED MAX CATCHUP RATE US"
    assert ExceptionMessageType.ASSOC_IS_ON_HARDSHIP.value == "ASSOC IS ON HARDSHIP"
    assert len(ExceptionMessageType) == 7
