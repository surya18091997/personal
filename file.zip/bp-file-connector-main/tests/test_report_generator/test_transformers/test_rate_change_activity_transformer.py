import unittest
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock, mock_open
import pandas as pd

from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformers.rate_change_activity_transformer import RateChangeActivityTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.rate_change_activity_data_object import RateChangeActivityDataObject


# Create a mock for open() to handle different types of file operations
def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestRateChangeActivityTransformer(unittest.TestCase):
    """Test cases for the RateChangeActivityTransformer class."""

    @patch('src.report_generator.transformer.BigQueryDatabase')
    @patch('src.report_generator.transformer.SparkSession')
    @patch('src.utils.app_config.get_config_value')
    @patch('builtins.open', new_callable=mock_open_with_binary_support)
    def setUp(self, mock_file_open, mock_app_config, mock_spark, mock_bigquery):
        """Set up test fixtures."""
        self.logger = MagicMock()
        self.config = TransformerConfig(
            output_file_name="test_rate_change_activity.txt",
            page_size=60,
            report_id="PS719702US"
        )
        # Configure mock app_config
        mock_app_config.return_value = "dummy_path"
        
        # Configure mock BigQueryDatabase
        mock_bigquery_instance = MagicMock()
        mock_bigquery.return_value = mock_bigquery_instance
        
        # Configure mock SparkSession
        mock_spark_instance = MagicMock()
        mock_spark.builder.appName.return_value.config.return_value.getOrCreate.return_value = mock_spark_instance
        
        self.transformer = RateChangeActivityTransformer(self.config, ReportType.US, self.logger)

    @patch('src.report_generator.transformers.rate_change_activity_transformer.CosmosUtils')
    def test_transform_no_transaction_logs(self, mock_cosmos_utils):
        """Test transform method when no transaction logs are found."""
        # Setup mock
        mock_cosmos_instance = MagicMock()
        mock_cosmos_utils.return_value = mock_cosmos_instance
        
        # Mock the cosmos_query method to return empty DataFrame
        mock_df = MagicMock()
        mock_df.empty = True
        mock_df.toPandas.return_value = pd.DataFrame()
        self.transformer.cosmos_query = MagicMock(return_value=mock_df)
        
        # Execute
        results = self.transformer._transform()
    
        # Assert
        self.assertEqual(len(results), 10)  # 8 group entries + 2 subtotals
        self.transformer.cosmos_query.assert_called()
        
    @patch('src.report_generator.transformers.rate_change_activity_transformer.CosmosUtils')
    def test_transform_with_data(self, mock_cosmos_utils):
        """Test transform method with transaction logs and coverages data."""
        # Setup mock
        mock_cosmos_instance = MagicMock()
        mock_cosmos_utils.return_value = mock_cosmos_instance
        
        # Mock transaction logs
        yesterday = datetime.now() - timedelta(days=1)
        
        mock_transaction_logs_data = [
            # US Regular Walmart
            {'id': '1', 'associateId': 'A001', 'planId': 'retirement_401k_regular_us', 'createdBy': 'API', 'createdAt': yesterday.isoformat()},
            # US Regular Merrill Lynch
            {'id': '2', 'associateId': 'A002', 'planId': 'retirement_401k_regular_us', 'createdBy': 'ML', 'createdAt': yesterday.isoformat()},
            # PR Catchup Walmart - Multiple records for same associate/plan (should only count most recent)
            {'id': '3', 'associateId': 'A003', 'planId': 'retirement_401k_catchup_pr', 'createdBy': 'API', 'createdAt': (yesterday - timedelta(hours=2)).isoformat()},
            {'id': '4', 'associateId': 'A003', 'planId': 'retirement_401k_catchup_pr', 'createdBy': 'API', 'createdAt': yesterday.isoformat()}
        ]
        
        # Mock coverages
        mock_coverages_data = [
            # A001 - New enrollment (version 1)
            {'id': 'c1', 'associateId': 'A001', 'planId': 'retirement_401k_regular_us', 'version': 1, 
             'contribution': {'type': 'PERCENTAGE', 'value': 5.0}, 'isLatest': True},
            
            # A002 - Change to 0 (version 2)
            {'id': 'c2', 'associateId': 'A002', 'planId': 'retirement_401k_regular_us', 'version': 1, 
             'contribution': {'type': 'PERCENTAGE', 'value': 10.0}, 'isLatest': False},
            {'id': 'c3', 'associateId': 'A002', 'planId': 'retirement_401k_regular_us', 'version': 2, 
             'contribution': {'type': 'PERCENTAGE', 'value': 0.0}, 'isLatest': True},
             
            # A003 - Increased (version 2)
            {'id': 'c4', 'associateId': 'A003', 'planId': 'retirement_401k_catchup_pr', 'version': 1, 
             'contribution': {'type': 'PERCENTAGE', 'value': 3.0}, 'isLatest': False},
            {'id': 'c5', 'associateId': 'A003', 'planId': 'retirement_401k_catchup_pr', 'version': 2, 
             'contribution': {'type': 'PERCENTAGE', 'value': 5.0}, 'isLatest': True},
        ]
        
        # Create mock transaction logs DataFrame
        mock_logs_df = pd.DataFrame(mock_transaction_logs_data)
        mock_logs_df['createdAt'] = pd.to_datetime(mock_logs_df['createdAt'])
        
        # Create mock coverages DataFrame
        mock_coverages_df = pd.DataFrame(mock_coverages_data)
        # Convert contribution to tuples as expected by the implementation
        def convert_contribution(row):
            if isinstance(row['contribution'], dict):
                return ('PERCENTAGE', row['contribution']['value'])
            return row['contribution']
        mock_coverages_df['contribution'] = mock_coverages_df.apply(convert_contribution, axis=1)
        
        mock_coverages_spark = MagicMock()
        mock_coverages_spark.isEmpty.return_value = False
        mock_coverages_spark.toPandas.return_value = mock_coverages_df
        
        # Mock the cosmos_query method to return our test data
        def mock_cosmos_query(query, collection):
            if collection == 'transaction-logs':
                mock_df = MagicMock()
                mock_df.empty = False if mock_logs_df.shape[0] > 0 else True
                mock_df.toPandas.return_value = mock_logs_df
                return mock_df
            elif collection == 'coverages':
                return mock_coverages_spark
            return MagicMock()
        
        self.transformer.cosmos_query = MagicMock(side_effect=mock_cosmos_query)
        
        # Execute
        results = self.transformer._transform()
        
        # Assert
        self.assertEqual(len(results), 11)  # 8 group entries + 2 subtotals + 1 grand total
        
        # Check for all required groups
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        
        self.assertEqual(results[1].country_code, 'US')
        self.assertEqual(results[1].retirement_plan_type, 'CUC')
        self.assertEqual(results[1].rate_change_source, 'WAL-MART')
        
        # Check WAL-MART subtotal
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        
        # Check MERRILL LYNCH subtotal
        self.assertEqual(results[9].rate_change_source, 'MERRILL LYNCH SUBTOTAL')
        
        # Verify data for specific entries
        us_reg_walmart_idx = 0  # First entry
        self.assertEqual(results[us_reg_walmart_idx].enrolled, 1)
        
        us_reg_ml_idx = 5  # First MERRILL LYNCH entry
        self.assertEqual(results[us_reg_ml_idx].changed_to_0, 1)
        
        pr_cuc_walmart_idx = 3  # PR CUC WAL-MART entry
        self.assertEqual(results[pr_cuc_walmart_idx].increased, 1)
        
        # Check percentages in subtotals
        self.assertIn('%', results[4].total_percentage)  # WAL-MART subtotal
        self.assertIn('%', results[9].total_percentage)  # MERRILL LYNCH subtotal
        
    def test_dynamic_trailer(self):
        """Test the dynamic_trailer method."""
        # The _dynamic_trailer method returns None in the current implementation
        # This is intentional as the grand total is added separately in _transform
        records = [
            RateChangeActivityDataObject(
                country_code='US', retirement_plan_type='REG', rate_change_source='WAL-MART',
                enrolled=10, changed_to_0=5, decreased=2, increased=3, corrected=1, total=21
            ),
            RateChangeActivityDataObject(
                country_code='', retirement_plan_type='', rate_change_source='WAL-MART SUBTOTAL',
                enrolled=10, changed_to_0=5, decreased=2, increased=3, corrected=1, total=21
            ),
            RateChangeActivityDataObject(
                country_code='US', retirement_plan_type='REG', rate_change_source='MERRILL LYNCH',
                enrolled=5, changed_to_0=3, decreased=1, increased=4, corrected=0, total=13
            )
        ]
        
        # Call method
        trailer = self.transformer._dynamic_trailer(records)
        
        # Verify the method returns None
        self.assertIsNone(trailer)

    @patch('src.report_generator.transformers.rate_change_activity_transformer.CosmosUtils')
    def test_transform_exception_handling(self, mock_cosmos_utils):
        """Test exception handling in transform method."""
        # Setup mock to raise an exception
        mock_cosmos_instance = MagicMock()
        mock_cosmos_utils.return_value = mock_cosmos_instance
        self.transformer.cosmos_query = MagicMock(side_effect=Exception("Test exception"))
        
        # Execute and assert
        with self.assertRaises(Exception):
            self.transformer._transform()
        
        # Verify error was logged
        self.logger.error.assert_called()
        
    def test_create_empty_report_structure(self):
        """Test the creation of an empty report structure."""
        results = self.transformer._create_empty_report_structure()
        
        # Check structure
        self.assertEqual(len(results), 10)  # 8 data rows + 2 subtotal rows
        
        # Check first row (US REG WAL-MART)
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 0)
        
        # Check WAL-MART subtotal
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].total, 0)
        self.assertEqual(results[4].total_percentage, '000%')
        
        # Check MERRILL LYNCH subtotal
        self.assertEqual(results[9].rate_change_source, 'MERRILL LYNCH SUBTOTAL')
        self.assertEqual(results[9].total, 0)
        self.assertEqual(results[9].total_percentage, '000%')

    def test_process_source_data(self):
        """Test the _process_source_data helper method specifically."""
        # Create test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary with all scenarios
        # Using tuples as keys as in the _transform method
        results_dict = {
            ('US', 'REG', 'WAL-MART'): {
                'enrolled': 5, 'changed_to_0': 2, 'decreased': 3, 'increased': 4, 'corrected': 1
            },
            ('US', 'CUC', 'WAL-MART'): {
                'enrolled': 0, 'changed_to_0': 1, 'decreased': 0, 'increased': 2, 'corrected': 0
            },
            ('PR', 'REG', 'WAL-MART'): {
                'enrolled': 3, 'changed_to_0': 1, 'decreased': 0, 'increased': 0, 'corrected': 0
            },
            ('PR', 'CUC', 'WAL-MART'): {
                'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0
            },
            ('US', 'REG', 'MERRILL LYNCH'): {
                'enrolled': 2, 'changed_to_0': 1, 'decreased': 0, 'increased': 3, 'corrected': 0
            },
            ('US', 'CUC', 'MERRILL LYNCH'): {
                'enrolled': 1, 'changed_to_0': 0, 'decreased': 1, 'increased': 0, 'corrected': 3
            },
            ('PR', 'REG', 'MERRILL LYNCH'): {
                'enrolled': 0, 'changed_to_0': 2, 'decreased': 1, 'increased': 1, 'corrected': 1
            },
            ('PR', 'CUC', 'MERRILL LYNCH'): {
                'enrolled': 2, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 2
            }
        }
        
        # Initialize empty results list and subtotals
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        merrill_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process WAL-MART data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Process MERRILL LYNCH data
        merrill_total = self.transformer._process_source_data(
            'MERRILL LYNCH', countries, plan_types, results_dict, merrill_subtotal, results
        )
        
        # Verify results
        # Check totals first
        self.assertEqual(walmart_total, 22)  # Sum of all WAL-MART entries: 5+2+3+4+1+0+1+0+2+3+1+0+0+0
        self.assertEqual(merrill_total, 20)  # Sum of all MERRILL LYNCH entries: 2+1+0+3+0+1+0+1+0+3+0+2+1+1+1+2+0+0+0+2
        
        # Check subtotals for WAL-MART
        self.assertEqual(walmart_subtotal['enrolled'], 8)  # 5+0+3+0
        self.assertEqual(walmart_subtotal['changed_to_0'], 4)  # 2+1+1+0
        self.assertEqual(walmart_subtotal['decreased'], 3)  # 3+0+0+0
        self.assertEqual(walmart_subtotal['increased'], 6)  # 4+2+0+0
        self.assertEqual(walmart_subtotal['corrected'], 1)  # 1+0+0+0
        
        # Check subtotals for MERRILL LYNCH
        self.assertEqual(merrill_subtotal['enrolled'], 5)  # 2+1+0+2
        self.assertEqual(merrill_subtotal['changed_to_0'], 3)  # 1+0+2+0
        self.assertEqual(merrill_subtotal['decreased'], 2)  # 0+1+1+0
        self.assertEqual(merrill_subtotal['increased'], 4)  # 3+0+1+0
        self.assertEqual(merrill_subtotal['corrected'], 6)  # 0+3+1+2
        
        # Verify results structure
        self.assertEqual(len(results), 10)  # 8 data rows + 2 subtotals
        
        # Check WAL-MART entries
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 5)
        self.assertEqual(results[0].changed_to_0, 2)
        self.assertEqual(results[0].decreased, 3)
        self.assertEqual(results[0].increased, 4)
        self.assertEqual(results[0].corrected, 1)
        self.assertEqual(results[0].total, 15)  # 5+2+3+4+1
        
        # Check WAL-MART subtotal row (index 4)
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].enrolled, 8)
        self.assertEqual(results[4].changed_to_0, 4)
        self.assertEqual(results[4].decreased, 3)
        self.assertEqual(results[4].increased, 6)
        self.assertEqual(results[4].corrected, 1)
        self.assertEqual(results[4].total, 22)  # Total
        self.assertEqual(results[4].total_percentage, '000%')  # Placeholder percentage
        
        # Check MERRILL LYNCH entries (index 5-8)
        self.assertEqual(results[5].country_code, 'US')
        self.assertEqual(results[5].retirement_plan_type, 'REG')
        self.assertEqual(results[5].rate_change_source, 'MERRILL LYNCH')
        self.assertEqual(results[5].enrolled, 2)
        self.assertEqual(results[5].total, 6)  # 2+1+0+3+0
        
        # Check MERRILL LYNCH subtotal (index 9)
        self.assertEqual(results[9].rate_change_source, 'MERRILL LYNCH SUBTOTAL')
        self.assertEqual(results[9].enrolled, 5)
        self.assertEqual(results[9].changed_to_0, 3)
        self.assertEqual(results[9].decreased, 2)
        self.assertEqual(results[9].increased, 4)
        self.assertEqual(results[9].corrected, 6)
        self.assertEqual(results[9].total, 20)  # Correct total
        self.assertEqual(results[9].total_percentage, '000%')  # Placeholder percentage

    def test_process_source_data_with_string_keys(self):
        """Test the _process_source_data method with string keys in the dictionary."""
        # Create test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary with string keys
        # Note: The current implementation only processes tuple keys, not string keys
        results_dict = {
            "US_REG_WAL-MART": {
                'enrolled': 3, 'changed_to_0': 1, 'decreased': 2, 'increased': 1, 'corrected': 0
            },
            "US_CUC_WAL-MART": {
                'enrolled': 2, 'changed_to_0': 0, 'decreased': 1, 'increased': 0, 'corrected': 1
            },
            "PR_REG_WAL-MART": {
                'enrolled': 1, 'changed_to_0': 2, 'decreased': 0, 'increased': 0, 'corrected': 2
            },
            "PR_CUC_WAL-MART": {
                'enrolled': 0, 'changed_to_0': 1, 'decreased': 1, 'increased': 0, 'corrected': 0
            }
        }
        
        # Initialize empty results list and subtotal
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process WAL-MART data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Since the implementation only uses tuple keys, string keys are ignored
        # Verify results should have zeros for all entries
        self.assertEqual(walmart_total, 0)  # Should be 0 since string keys aren't processed
        
        # Check subtotals (should all be 0)
        self.assertEqual(walmart_subtotal['enrolled'], 0)
        self.assertEqual(walmart_subtotal['changed_to_0'], 0)
        self.assertEqual(walmart_subtotal['decreased'], 0)
        self.assertEqual(walmart_subtotal['increased'], 0)
        self.assertEqual(walmart_subtotal['corrected'], 0)
        
        # Verify structure
        self.assertEqual(len(results), 5)  # 4 data rows + 1 subtotal
        
        # Check first data row - should have zeros
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 0)
        self.assertEqual(results[0].changed_to_0, 0)
        
        # Check WAL-MART subtotal
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].total, 0)
        self.assertEqual(results[4].total_percentage, '000%')
    
    def test_identifier(self):
        # The identifier method should return the report ID
        self.assertEqual(self.transformer.identifier(), "rate_change_activity")

    def test_data_template(self):
        # The data_template method should return the RateChangeActivityDataObject class
        self.assertEqual(self.transformer.data_template_name(), "rate_change_activity_data.template")

    def test_header(self):
        with patch('src.report_generator.transformers.rate_change_activity_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            header = self.transformer._header(1)

            assert isinstance(header, HeaderObject)
            assert header.run_on == '01/01/25'
            assert header.report_number == 'BE208801US'
            assert header.page_no == '1'
            assert header.pay_period_date == '01/01/25'
            assert header.report_name == '401K DOWNLOAD ACTIVITY(DAILY)'

    def test_trailer(self):
        with patch('src.report_generator.transformers.rate_change_activity_transformer.datetime') as mock_datetime:
            mock_date = MagicMock()
            mock_date.strftime.return_value = '01/01/25'
            mock_datetime.now.return_value = mock_date

            trailer = self.transformer._trailer()

            assert trailer.run_on == '01/01/25'
            assert trailer.report_number == 'BE208801US'
            assert trailer.pay_period_date == '01/01/25'


if __name__ == '__main__':
    unittest.main()
