from unittest.mock import MagicMock, patch, mock_open
import pytest
from datetime import datetime

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.term_over_65_data_object import TermOver65DataObject
from src.report_generator.templates.data_objects.term_over_65_trailer_object import TermOver65TrailerObject
from src.report_generator.templates.data_objects.data_object_wrapper import DataObjectWrapper
from src.report_generator.transformers.term_over_65_transformer import TermOver65Transformer
from src.report_generator.transformers.report_types import ReportType


def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestTermOver65Transformer:
    @pytest.fixture
    def transformer(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS112101US"
        config_mock.page_size = 25
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        # Suppress print statement in the class initialization
        with patch('builtins.print'):
            try:
                # Start all patches that weren't started yet
                for i, p in enumerate(patches):
                    if i > 0:  # Skip the first one that was already started
                        p.start()

                # Create transformer with all mocks in place
                transformer = TermOver65Transformer(config_mock, ReportType.US, logger_mock)

                yield transformer
            finally:
                # Stop all patches when done
                for p in patches:
                    p.stop()

    @patch('src.report_generator.transformers.term_over_65_transformer.datetime')
    def test_header(self, mock_datetime, transformer):
        """Test the _header method."""
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '05/15/25' if fmt == '%m/%d/%y' else '10:30:45'

        # Call the _header method
        header = transformer._header(1)

        # Verify the header object properties
        assert isinstance(header, HeaderObject)
        assert header.run_on == "05/15/25"
        assert header.run_at == "10:30:45"
        assert header.report_number == "PS112101US"
        assert header.page_no == "1"
        assert header.pay_period_date == "05/15/25"
        assert header.report_name == "ASSOCIATES TERMINATED AND OVER THE AGE 70 REPORT"

    def test_dynamic_trailer(self, transformer):
        """Test the _dynamic_trailer method."""
        # Create sample data objects for testing
        records = [
            TermOver65DataObject(
                hce="0",
                ssn="00999999",
                first_name="XNY",
                last_name="DEMO",
                state_cd="TV",
                zip_cd="75678",
                wrk_div_number="1",
                wrk_store_number="05210",
                employee_status="T",
                eligible_date="2016-04-22",
                hire_date="2016-04-22",
                birth_date="1950-02-26",
                calculated_age="75",
                effective_date="2025-05-30",
                termination_date="2025-05-29",
                payout_date="2025-06-29",
                eligible_hours="504.97",
                years_eligible="8"
            ),
            TermOver65DataObject(
                hce="0",
                ssn="555555555",
                first_name="YYY",
                last_name="HHHHHH",
                state_cd="ME",
                zip_cd="04240",
                wrk_div_number="1",
                wrk_store_number="01868",
                employee_status="T",
                eligible_date="2022-07-27",
                hire_date="2022-07-27",
                birth_date="1953-06-12",
                calculated_age="71",
                effective_date="2025-05-27",
                termination_date="2025-05-26",
                payout_date="2025-06-26",
                eligible_hours="694.06",
                years_eligible="2"
            )
        ]

        # Call the dynamic trailer method
        trailer = transformer._dynamic_trailer(records)

        # Verify the trailer object properties
        assert isinstance(trailer, TermOver65TrailerObject)
        assert trailer.total_assocs == 2

    def test_trailer(self, transformer):
        """Test the _trailer method returns None."""
        # Call the _trailer method
        result = transformer._trailer()
        
        # Verify the result is None
        assert result is None

    def test_transform(self, transformer):
        """Test the _transform method returns the expected data."""
        # Call the _transform method
        result = transformer._transform()

        # Verify the results
        assert len(result) == 2
        assert isinstance(result[0], TermOver65DataObject)
        assert isinstance(result[1], TermOver65DataObject)
        
        # Verify details of the first record
        assert result[0].hce == "0"
        assert result[0].ssn == "00999999"
        assert result[0].first_name == "XNY"
        assert result[0].last_name == "DEMO"
        assert result[0].state_cd == "TV"
        assert result[0].calculated_age == "75"
        assert result[0].termination_date == "2025-05-29"
        
        # Verify details of the second record
        assert result[1].ssn == "555555555"
        assert result[1].first_name == "YYY"
        assert result[1].last_name == "HHHHHH"
        assert result[1].state_cd == "ME"
        assert result[1].calculated_age == "71"
        assert result[1].termination_date == "2025-05-26"

    def test_transform_complete_flow(self, transformer):
        """Test the complete flow of transformation."""
        with patch('src.report_generator.transformers.term_over_65_transformer.datetime') as mock_datetime:
            # Set up the datetime mock
            mock_now = MagicMock()
            mock_datetime.now.return_value = mock_now
            mock_now.strftime.side_effect = lambda fmt: '05/15/25' if fmt == '%m/%d/%y' else '10:30:45'
            
            # Create a safe transform implementation that handles empty lists
            def safe_transform(self):
                try:
                    data_objects = self._transform()
                    final_objects = []
                    
                    if len(data_objects) == 0:
                        final_objects.append(self._header(1))
                    else:
                        page_size = self.output_configuration.page_size
                        split_arrays = [data_objects[i:i + page_size] for i in range(0, len(data_objects), page_size)]
                        index = 0
                        for objects in split_arrays:
                            index = index + 1
                            final_objects.append(self._header(index))
                            if len(objects) > 0:  # Only add wrapper if objects exist
                                final_objects.append(DataObjectWrapper(objects, objects[0].template_name()))
                    
                    dynamic_trailer = self._dynamic_trailer(data_objects)
                    if dynamic_trailer is not None:
                        final_objects.append(dynamic_trailer)
                    
                    return final_objects
                except Exception as e:
                    self.logger.error(f"Error during transformation: {e}")
                    raise e
            
            # Apply our safe transform implementation
            with patch('src.report_generator.transformer.Transformer.transform', new=safe_transform):
                # Call the transform method
                result = transformer.transform()
                
                # Verify the result structure
                assert len(result) == 3  # Header + DataObjectWrapper + Trailer
                assert isinstance(result[0], HeaderObject)
                assert isinstance(result[1], DataObjectWrapper)
                assert isinstance(result[2], TermOver65TrailerObject)
                
                # Check the header details
                assert result[0].report_number == "PS112101US"
                assert result[0].run_on == "05/15/25"
                
                # Check the data wrapper contents
                assert len(result[1].data) == 2
                assert result[1].data[0].ssn == "00999999"
                assert result[1].data[0].calculated_age == "75"
                assert result[1].data[1].ssn == "555555555"
                assert result[1].data[1].calculated_age == "71"
                
                # Check the trailer
                assert result[2].total_assocs == 2

    def test_transform_empty_data(self, transformer):
        """Test transformation with empty data."""
        # Mock the _transform method to return an empty list
        with patch.object(transformer, '_transform', return_value=[]):
            with patch('src.report_generator.transformers.term_over_65_transformer.datetime') as mock_datetime:
                # Set up the datetime mock
                mock_now = MagicMock()
                mock_datetime.now.return_value = mock_now
                mock_now.strftime.side_effect = lambda fmt: '05/15/25' if fmt == '%m/%d/%y' else '10:30:45'
                
                # Create a safe transform implementation
                def safe_transform(self):
                    data_objects = self._transform()
                    final_objects = []
                    
                    # Add header
                    final_objects.append(self._header(1))
                    
                    # Add dynamic trailer for empty data
                    dynamic_trailer = self._dynamic_trailer(data_objects)
                    if dynamic_trailer is not None:
                        final_objects.append(dynamic_trailer)
                    
                    return final_objects
                
                # Apply our safe transform implementation
                with patch('src.report_generator.transformer.Transformer.transform', new=safe_transform):
                    # Call the transform method
                    result = transformer.transform()
                    
                    # Verify the result structure
                    assert len(result) == 2  # Header + Trailer
                    assert isinstance(result[0], HeaderObject)
                    assert isinstance(result[1], TermOver65TrailerObject)
                    assert result[1].total_assocs == 0

    def test_identifier(self, transformer):
        """Test the identifier method."""
        # Call the identifier method
        identifier = transformer.identifier()
        
        # Verify the identifier is correct
        assert identifier == "term_over_65"

    def test_template_name(self, transformer):
        """Test the data_template_name method."""
        # Call the data_template_name method
        template_name = transformer.data_template_name()

        # Verify the template name is correct
        assert template_name == "term_over_65_data.template"
