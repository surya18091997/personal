from unittest.mock import MagicMock, patch, mock_open
import pytest
import pandas as pd
from datetime import datetime

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.rate_change_outbound_summary_data_object import RateChangeOutboundSummaryDataObject
from src.report_generator.transformers.rate_change_outbound_summary_transformer import RateChangeOutboundSummaryTransformer
from src.report_generator.transformers.report_types import ReportType


def mock_open_with_binary_support(*args, **kwargs):
    m = mock_open(*args, **kwargs)
    m.return_value.read.side_effect = lambda size=None: b'\x00\x00\x00\x00' if size == 4 else "dummy_connection_data"
    return m


class TestRateChangeOutboundSummaryTransformer:
    @pytest.fixture
    def transformer_us(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS719701US"
        config_mock.page_size = 25
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = RateChangeOutboundSummaryTransformer(config_mock, ReportType.US, logger_mock)

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()
    
    @pytest.fixture
    def transformer_pr(self):
        config_mock = MagicMock()
        config_mock.report_id = "PS719701PR"
        config_mock.page_size = 25
        logger_mock = MagicMock()

        # Mock SparkSession directly at the module level
        pyspark_context_patch = patch('src.report_generator.transformer.SparkSession')
        mock_spark_session = pyspark_context_patch.start()

        # Create a complete mock for the SparkSession builder chain
        mock_session = MagicMock()
        mock_builder = MagicMock()
        mock_builder_app = MagicMock()

        mock_spark_session.builder = mock_builder
        mock_builder.appName = MagicMock(return_value=mock_builder_app)
        mock_builder_app.config = MagicMock(return_value=mock_builder_app)
        mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)

        # Setup other required patches
        patches = [
            pyspark_context_patch,
            patch('src.report_generator.transformer.BigQueryDatabase'),
            patch('src.utils.app_config.get_config_value'),
            patch('builtins.open', mock_open_with_binary_support()),
            patch('pyspark.sql.SparkSession'),
            patch('struct.unpack', return_value=(0,))
        ]

        # Configure app_config mock
        from src.utils import app_config
        app_config.get_config_value.return_value = "dummy_path"

        try:
            # Start all patches that weren't started yet
            for i, p in enumerate(patches):
                if i > 0:  # Skip the first one that was already started
                    p.start()

            # Create transformer with all mocks in place
            transformer = RateChangeOutboundSummaryTransformer(config_mock, ReportType.PR, logger_mock)

            yield transformer
        finally:
            # Stop all patches when done
            for p in patches:
                p.stop()

    @patch('src.report_generator.transformers.rate_change_outbound_summary_transformer.datetime')
    def test_header_us(self, mock_datetime, transformer_us):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        header = transformer_us._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == "01/01/25"
        assert header.run_at == "12:00:00"
        assert header.report_number == "PS719701US"
        assert header.page_no == "1"
        assert header.pay_period_date == "01/01/25"
        assert header.report_name == "SAVINGS RATE RECORD SENT TO MERRILL LYNCH FOR UNITED STATES"
    
    @patch('src.report_generator.transformers.rate_change_outbound_summary_transformer.datetime')
    def test_header_pr(self, mock_datetime, transformer_pr):
        # Set up mock for datetime.now()
        mock_now = MagicMock()
        mock_datetime.now.return_value = mock_now
        mock_now.strftime.side_effect = lambda fmt: '01/01/25' if fmt == '%m/%d/%y' else '12:00:00'

        header = transformer_pr._header(1)

        assert isinstance(header, HeaderObject)
        assert header.run_on == "01/01/25"
        assert header.run_at == "12:00:00"
        assert header.report_number == "PS719701PR"
        assert header.page_no == "1"
        assert header.pay_period_date == "01/01/25"
        assert header.report_name == "SAVING RATE FILE RECORD SENT TO MERRILL LYNCH FOR PUERTO RICO"

    def test_dynamic_trailer(self, transformer_us):
        # The dynamic trailer is not used in this transformer
        records = []
        result = transformer_us._dynamic_trailer(records)
        assert result is None

    def test_trailer(self, transformer_us):
        # The trailer is not used in this transformer
        result = transformer_us._trailer()
        assert result is None

    @patch('pandas.read_csv')
    def test_transform_us(self, mock_read_csv, transformer_us):
        # Mock pd.read_csv to return a DataFrame with 10 rows for type01 and 5 rows for type02
        mock_df_type01 = pd.DataFrame({'data': list(range(10))})
        mock_df_type02 = pd.DataFrame({'data': list(range(5))})
        
        mock_read_csv.side_effect = [mock_df_type01, mock_df_type02]
        
        result = transformer_us._transform()
        
        # Check that read_csv was called twice with the correct file paths
        assert mock_read_csv.call_count == 2
        
        # Check that the result is a list containing a single RateChangeOutboundSummaryDataObject
        assert len(result) == 1
        assert isinstance(result[0], RateChangeOutboundSummaryDataObject)
        
        # Check that the counts are correct
        summary = result[0]
        assert summary.header_count == 1
        assert summary.trailer_count == 1
        assert summary.record_type_01 == 10
        assert summary.record_type_02 == 5
        assert summary.record_type_05 == 0
        assert summary.record_type_08 == 0
        assert summary.record_type_10 == 0
        assert summary.record_type_62 == 0
        assert summary.total_count == 17  # 1 header + 1 trailer + 10 type01 + 5 type02

    @patch('pandas.read_csv')
    def test_transform_error_handling(self, mock_read_csv, transformer_us):
        # Mock pd.read_csv to raise an exception for the first call
        mock_read_csv.side_effect = Exception("File not found")
        
        # The transformer should raise the exception since it doesn't handle them
        with pytest.raises(Exception, match="File not found"):
            transformer_us._transform()
        
        # Check that read_csv was called once before the exception
        assert mock_read_csv.call_count == 1

    def test_identifier(self, transformer_us, transformer_pr):
        # Test the identifier for both US and PR transformers
        assert transformer_us.identifier() == "rate_change_compare"
        assert transformer_pr.identifier() == "rate_change_compare"

    @patch('pandas.read_csv')
    def test_transform_complete_flow_safe(self, mock_read_csv, transformer_us):
        # Mock pd.read_csv to return DataFrames with specific row counts
        mock_df_type01 = pd.DataFrame({'data': list(range(15))})
        mock_df_type02 = pd.DataFrame({'data': list(range(8))})
        mock_read_csv.side_effect = [mock_df_type01, mock_df_type02]
        
        # Create a safe transform function that handles empty data properly
        def safe_transform():
            try:
                data_objects = transformer_us._transform()
                final_objects = []
                
                if not data_objects:  # Handle empty data properly
                    final_objects.append(transformer_us._header(1))
                else:
                    page_size = transformer_us.output_configuration.page_size
                    split_arrays = [data_objects[i:i + page_size] for i in range(0, len(data_objects), page_size)]
                    index = 0
                    for objects in split_arrays:
                        index = index + 1
                        final_objects.append(transformer_us._header(index))
                        # Only add DataObjectWrapper if objects is not empty
                        if objects:
                            from src.report_generator.templates.data_objects.data_object_wrapper import DataObjectWrapper
                            final_objects.append(DataObjectWrapper(objects, objects[0].template_name()))

                # Add dynamic trailer and trailer only if they are not None
                dynamic_trailer = transformer_us._dynamic_trailer(data_objects)
                if dynamic_trailer is not None:
                    final_objects.append(dynamic_trailer)
                
                trailer = transformer_us._trailer()
                if trailer is not None:
                    final_objects.append(trailer)
                
                return final_objects
            except Exception as e:
                transformer_us.logger.error(f"Error during safe transformation: {e}")
                raise e
        
        # Patch the transform method to use our safe implementation
        with patch.object(transformer_us, 'transform', safe_transform):
            result = transformer_us.transform()
            
            # Verify the results
            assert len(result) == 2  # Header and DataObjectWrapper with data
            assert isinstance(result[0], HeaderObject)  # Page header
            
            # Check that read_csv was called twice
            assert mock_read_csv.call_count == 2

    def test_data_template_name(self, transformer_us):
        # Test the data template name for US transformer
        assert transformer_us.data_template_name() == "rate_change_outbound_summary_data.template"