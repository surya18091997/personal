import pytest
import os
import datetime
from unittest.mock import patch, MagicMock, mock_open, call
import tempfile
import shutil

from src.report_generator.orchestrator import Orchestrator
from src.report_generator.input_configuration import FlatFileReadConfiguration, FileType
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType


def mock_all_transformers():
    """Decorator to mock all transformer classes"""
    def decorator(func):
        import functools
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with patch('src.report_generator.orchestrator.ActivityReportTransformer') as mock_activity, \
                 patch('src.report_generator.orchestrator.EligibilityFileTransformer') as mock_eligibility, \
                 patch('src.report_generator.orchestrator.HardshipInboundTransformer') as mock_hardship, \
                 patch('src.report_generator.orchestrator.LoaFileTransformer') as mock_loa, \
                 patch('src.report_generator.orchestrator.LoanFileTransformer') as mock_loan_file, \
                 patch('src.report_generator.orchestrator.LoaninFileTransformer') as mock_loan_inbound, \
                 patch('src.report_generator.orchestrator.RateChangeActivityTransformer') as mock_rate_activity, \
                 patch('src.report_generator.orchestrator.RateChangeCompareTransformer') as mock_rate_compare, \
                 patch('src.report_generator.orchestrator.RateChangeExceptionTransformer') as mock_rate_exception, \
                 patch('src.report_generator.orchestrator.RateChangeHardshipCompareTransformer') as mock_rate_hardship, \
                 patch('src.report_generator.orchestrator.RateChangeOutboundSummaryTransformer') as mock_rate_outbound, \
                 patch('src.report_generator.orchestrator.ReHireTransformer') as mock_rehire, \
                 patch('src.report_generator.orchestrator.StateTransferDoeChangeTransformer') as mock_state_doe, \
                 patch('src.report_generator.orchestrator.StateTransferTransformer') as mock_state_transfer, \
                 patch('src.report_generator.orchestrator.TermOver65Transformer') as mock_term_over65, \
                 patch('src.report_generator.orchestrator.TerminationTransformer') as mock_termination, \
                 patch('src.report_generator.transformer.BigQueryDatabase'), \
                 patch('builtins.open', mock_open(read_data='mock_config')), \
                 patch('src.utils.app_config.get_config_value') as mock_config, \
                 patch('pyspark.sql.SparkSession.builder') as mock_spark_builder:
                
                # Configure app_config mock to return appropriate values
                def config_side_effect(section, key):
                    config_map = {
                        ('app', 'gcs_connection_file_path'): '/mock/path/to/credentials.json',
                        ('app', 'DB2BAUS'): '/mock/path/to/db2_config.txt',
                        ('app', 'cosmos_connection_string'): '/mock/path/to/cosmos_config.txt',
                        ('app', 'core_sql_cosmos_url'): 'mock://cosmos.url',
                        ('app', 'reporting_gcs_bucket'): 'test-bucket'
                    }
                    return config_map.get((section, key), "mock_config_path")
                
                mock_config.side_effect = config_side_effect
                
                # Mock Spark Session
                mock_spark_session = MagicMock()
                mock_spark_builder.appName.return_value = mock_spark_builder
                mock_spark_builder.config.return_value = mock_spark_builder
                mock_spark_builder.master.return_value = mock_spark_builder
                mock_spark_builder.getOrCreate.return_value = mock_spark_session
                
                # Mock transformer instances
                mock_activity.return_value = MagicMock()
                mock_eligibility.return_value = MagicMock()
                mock_hardship.return_value = MagicMock()
                mock_loa.return_value = MagicMock()
                mock_loan_file.return_value = MagicMock()
                mock_loan_inbound.return_value = MagicMock()
                mock_rate_activity.return_value = MagicMock()
                mock_rate_compare.return_value = MagicMock()
                mock_rate_exception.return_value = MagicMock()
                mock_rate_hardship.return_value = MagicMock()
                mock_rate_outbound.return_value = MagicMock()
                mock_rehire.return_value = MagicMock()
                mock_state_doe.return_value = MagicMock()
                mock_state_transfer.return_value = MagicMock()
                mock_term_over65.return_value = MagicMock()
                mock_termination.return_value = MagicMock()
                
                return func(*args, **kwargs)
        return wrapper
    return decorator


class TestOrchestrator:
    """Test suite for the Orchestrator class"""

    @pytest.fixture
    def mock_dependencies(self):
        """Mock all external dependencies"""
        with patch('src.report_generator.orchestrator.GCSUtils') as mock_gcs_utils, \
             patch('src.report_generator.orchestrator.setup_request_logger') as mock_logger, \
             patch('src.utils.app_config.get_config_value') as mock_config, \
             patch('pyspark.sql.SparkSession.builder') as mock_spark_builder, \
             patch('src.integrations.bigquery_conn.BigQueryDatabase') as mock_bigquery, \
             patch('builtins.open', mock_open(read_data='mock_config')):
            
            # Configure app_config mock to return appropriate values
            def config_side_effect(section, key):
                config_map = {
                    ('app', 'gcs_connection_file_path'): '/mock/path/to/credentials.json',
                    ('app', 'DB2BAUS'): '/mock/path/to/db2_config.txt',
                    ('app', 'cosmos_connection_string'): '/mock/path/to/cosmos_config.txt',
                    ('app', 'core_sql_cosmos_url'): 'mock://cosmos.url',
                    ('app', 'gcs_bucket_name'): 'test-bucket'
                }
                return config_map.get((section, key), "test-bucket")
            
            mock_config.side_effect = config_side_effect
            mock_logger.return_value = MagicMock()
            mock_gcs_utils.return_value = MagicMock()
            
            # Mock Spark Session
            mock_spark_session = MagicMock()
            mock_spark_builder.appName.return_value = mock_spark_builder
            mock_spark_builder.config.return_value = mock_spark_builder
            mock_spark_builder.master.return_value = mock_spark_builder
            mock_spark_builder.getOrCreate.return_value = mock_spark_session
            
            # Mock BigQuery
            mock_bigquery_instance = MagicMock()
            mock_bigquery.return_value = mock_bigquery_instance
            
            yield {
                'gcs_utils': mock_gcs_utils,
                'logger': mock_logger,
                'config': mock_config,
                'spark_builder': mock_spark_builder,
                'bigquery': mock_bigquery
            }

    @pytest.fixture
    def orchestrator(self, mock_dependencies):
        """Create an Orchestrator instance with mocked dependencies"""
        return Orchestrator()

    def test_orchestrator_initialization(self, mock_dependencies):
        """Test Orchestrator initialization"""
        orchestrator = Orchestrator()
        
        assert orchestrator.bucket_name == "test-bucket"
        assert orchestrator.logger is not None
        assert orchestrator.gcs_utils is not None

    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    @mock_all_transformers()
    def test_start_directory_creation(self, mock_getcwd, mock_exists, mock_makedirs, orchestrator):
        """Test that required directories are created"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = False
        
        with patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[]):
            
            orchestrator.start()
            
            # Verify directories are created
            # expected_calls = [
            #     call("/test/app/src/report_generator/output_temp", exist_ok=True),
            #     call("/test/app/src/report_generator/output_temp/reports", exist_ok=True),
            #     call("/test/app/src/report_generator/flat_files", exist_ok=True)
            # ]
            
            # Check that makedirs was called for required directories
            assert mock_makedirs.called

    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    @mock_all_transformers()
    def test_start_directories_already_exist(self, mock_getcwd, mock_exists, mock_makedirs, orchestrator):
        """Test behavior when directories already exist"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        with patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[]):
            
            orchestrator.start()
            
            # Directories should NOT be created when they already exist
            assert not mock_makedirs.called

    def test_get_flat_file_configs_structure(self, orchestrator):
        """Test the structure of flat file configurations"""
        configs = orchestrator._Orchestrator__get_flat_file_configs()
        
        assert isinstance(configs, list)
        # Currently most configs are commented out, so we expect a small number
        assert len(configs) == 0 | len(configs) > 0
        
        for config in configs:
            assert isinstance(config, FlatFileReadConfiguration)
            assert hasattr(config, 'bucket')
            assert hasattr(config, 'remote_file')
            assert hasattr(config, 'layout')
            assert hasattr(config, 'file')
            assert hasattr(config, 'fixed_size')

    @mock_all_transformers()
    def test_get_transformer_configs_structure(self, orchestrator):
        """Test the structure of transformer configurations"""
        transformers = orchestrator._Orchestrator__get_transformer_configs(orchestrator.logger)
        
        assert isinstance(transformers, list)
        assert len(transformers) > 0

    @mock_all_transformers()
    @patch('builtins.open', new_callable=mock_open, read_data="test line\n")
    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_start_with_gcs_file_processing(self, mock_getcwd, mock_exists, mock_makedirs, mock_file, orchestrator):
        """Test file processing with GCS files"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        # Mock flat file config
        mock_config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test/file.dat",
            layout="layout.json",
            file="test_file.txt",
            fixed_size=100,
            type=FileType.GCS
        )
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[mock_config]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.FlatFileToCSVGenerator') as mock_generator:
            
            mock_generator_instance = MagicMock()
            mock_generator.return_value = mock_generator_instance
            
            orchestrator.start()
            
            # Verify GCS download was attempted
            orchestrator.gcs_utils.download_file.assert_called_once()
            call_args = orchestrator.gcs_utils.download_file.call_args
            assert call_args[0][0] == mock_config.bucket
            assert call_args[0][1] == mock_config.remote_file
            assert call_args[0][2] == "test_file.txt"  # should be called with original filename

    @mock_all_transformers()
    @patch('builtins.open', new_callable=mock_open, read_data="test line\n")
    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    @patch('shutil.copy2')
    def test_start_with_azure_file_processing(self, mock_copy, mock_getcwd, mock_exists, mock_makedirs, mock_file, orchestrator):
        """Test file processing with Azure files"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        # Mock Azure file config
        mock_config = FlatFileReadConfiguration(
            bucket="test-container",
            remote_file="/mnt/azure/test/file.dat",
            layout="layout.json",
            file="test_file.txt",
            fixed_size=100,
            type=FileType.AZURE
        )
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[mock_config]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.FlatFileToCSVGenerator') as mock_generator:
            
            mock_generator_instance = MagicMock()
            mock_generator.return_value = mock_generator_instance
            
            orchestrator.start()
            
            # Verify Azure file copy was attempted
            assert mock_copy.called

    def test_pad_to_bytes_static_method(self):
        """Test the pad_to_bytes static method"""
        # Test basic padding
        result = Orchestrator.pad_to_bytes("test", 10)
        assert len(result) == 10
        assert result.startswith(b"test")
        
        # Test with exact size
        result = Orchestrator.pad_to_bytes("test", 4)
        assert len(result) == 4
        assert result == b"test"
        
        # Test with larger input than needed
        result = Orchestrator.pad_to_bytes("testing", 4)
        assert len(result) == 4
        assert result == b"test"

    @mock_all_transformers()
    @patch('builtins.open', new_callable=mock_open, read_data="test line\n")
    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_start_with_file_processing_error(self, mock_getcwd, mock_exists, mock_makedirs, mock_file, orchestrator):
        """Test error handling during file processing"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        # Mock config that will cause an error
        mock_config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test/file.dat",
            layout="layout.json",
            file="test_file.txt",
            fixed_size=100,
            type=FileType.GCS
        )
        
        # Make GCS download raise an exception
        orchestrator.gcs_utils.download_file.side_effect = Exception("Download failed")
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[mock_config]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[]):
            
            # Should not raise exception, but should log error
            orchestrator.start()
            
            # Verify error was logged
            assert orchestrator.logger.error.called

    @mock_all_transformers()
    @patch('builtins.open', new_callable=mock_open, read_data="test line\n")
    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_start_with_transformer_processing(self, mock_getcwd, mock_exists, mock_makedirs, mock_file, orchestrator):
        """Test transformer processing"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.return_value = []
        mock_transformer.output_configuration = TransformerConfig(
            output_file_name="test_output.txt",
            page_size=100,
            report_id="TEST001"
        )
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[mock_transformer]), \
             patch('src.report_generator.orchestrator.FlatFileWriter') as mock_writer:
            
            mock_writer_instance = MagicMock()
            mock_writer.return_value = mock_writer_instance
            
            orchestrator.start()
            
            # Verify transformer was called
            mock_transformer.transform.assert_called_once()
            
            # Verify file writer was created and used
            mock_writer.assert_called_once()
            mock_writer_instance.write.assert_called_once()
            
            # Verify transformer was called
            mock_transformer.transform.assert_called_once()
            
            # Verify writer was called
            mock_writer_instance.write.assert_called_once()
            
            # Verify GCS upload was attempted
            assert orchestrator.gcs_utils.upload_file.called

    @mock_all_transformers()
    def test_start_with_identifier_filtering(self, orchestrator):
        """Test transformer filtering by identifiers"""
        # Mock transformers with different identifiers
        mock_transformer1 = MagicMock()
        mock_transformer1.identifier.return_value = "TRANSFORMER_1"
        mock_transformer1.output_configuration = MagicMock()
        mock_transformer1.output_configuration.output_file_name = "test1.txt"
        mock_transformer1.output_configuration.report_id = "REPORT1"
        mock_transformer1.transform.return_value = []
        
        mock_transformer2 = MagicMock()
        mock_transformer2.identifier.return_value = "TRANSFORMER_2"
        mock_transformer2.output_configuration = MagicMock()
        mock_transformer2.output_configuration.output_file_name = "test2.txt"
        mock_transformer2.output_configuration.report_id = "REPORT2" 
        mock_transformer2.transform.return_value = []
        
        mock_transformer3 = MagicMock()
        mock_transformer3.identifier.return_value = "TRANSFORMER_3"
        mock_transformer3.output_configuration = MagicMock()
        mock_transformer3.output_configuration.output_file_name = "test3.txt"
        mock_transformer3.output_configuration.report_id = "REPORT3"
        mock_transformer3.transform.return_value = []
        
        transformers = [mock_transformer1, mock_transformer2, mock_transformer3]
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=transformers), \
             patch('src.report_generator.orchestrator.FlatFileWriter') as mock_writer, \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            mock_writer_instance = MagicMock()
            mock_writer.return_value = mock_writer_instance
            
            # Test filtering by specific identifiers
            orchestrator.start(identifiers=["TRANSFORMER_1", "TRANSFORMER_3"])
            
            # Verify only filtered transformers were processed
            mock_transformer1.transform.assert_called_once()
            mock_transformer2.transform.assert_not_called()
            mock_transformer3.transform.assert_called_once()
            
            # Should only process transformers with matching identifiers
            mock_transformer1.identifier.assert_called()
            mock_transformer3.identifier.assert_called()

    @mock_all_transformers()
    def test_start_with_empty_identifier_list(self, orchestrator):
        """Test with empty identifier list"""
        mock_transformer = MagicMock()
        mock_transformer.identifier.return_value = "TEST_TRANSFORMER"
        mock_transformer.output_configuration = MagicMock()
        mock_transformer.output_configuration.output_file_name = "test.txt"
        mock_transformer.output_configuration.report_id = "REPORT1"
        mock_transformer.transform.return_value = []
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[mock_transformer]), \
             patch('src.report_generator.orchestrator.FlatFileWriter') as mock_writer, \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            mock_writer_instance = MagicMock()
            mock_writer.return_value = mock_writer_instance
            
            # Empty list should process all transformers
            orchestrator.start(identifiers=[])
            
            # Verify transformer was processed
            mock_transformer.transform.assert_called_once()
            
            # With an empty list, the filtering logic is skipped, so identifier() is not called
            assert not mock_transformer.identifier.called

    @mock_all_transformers()
    def test_start_with_no_matching_identifiers(self, orchestrator):
        """Test with identifiers that don't match any transformers"""
        mock_transformer = MagicMock()
        mock_transformer.identifier.return_value = "EXISTING_TRANSFORMER"
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[mock_transformer]), \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            # Non-matching identifiers should result in no transformers being processed
            orchestrator.start(identifiers=["NON_EXISTING_TRANSFORMER"])
            
            # Verify transformer was not processed
            mock_transformer.transform.assert_not_called()
            
            # Should log error about no matching transformers
            assert orchestrator.logger.error.called

    @mock_all_transformers()
    @patch('builtins.open', new_callable=mock_open, read_data="test line\n")
    @patch('os.makedirs')
    @patch('os.path.exists')
    @patch('os.getcwd')
    def test_start_with_transformer_error(self, mock_getcwd, mock_exists, mock_makedirs, mock_file, orchestrator):
        """Test error handling in transformer processing"""
        mock_getcwd.return_value = "/test/app"
        mock_exists.return_value = True
        
        # Mock transformer that raises an exception
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = Exception("Transform failed")
        mock_transformer.__class__.__name__ = "TestTransformer"
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[mock_transformer]):
            
            orchestrator.start()
            
            # Should log the error
            assert orchestrator.logger.error.called

    def test_get_absolute_first_path_from_prefix(self, orchestrator):
        """Test get_absolute_first_path_from_prefix method - successful case"""
        with patch('os.listdir') as mock_listdir, \
             patch('os.path.exists') as mock_exists, \
             patch('os.path.abspath') as mock_abspath, \
             patch('os.path.join') as mock_join:
            
            mock_exists.return_value = True
            mock_listdir.return_value = ['file1.txt', 'file2.txt', 'test_prefix_20230101.txt']
            mock_join.return_value = '/test/path/test_prefix_20230101.txt'
            mock_abspath.return_value = '/test/path/test_prefix_20230101.txt'
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'test_prefix')
            
            assert result is not None
            assert result == '/test/path/test_prefix_20230101.txt'
            mock_exists.assert_called_once_with('/test/path')
            mock_listdir.assert_called_once_with('/test/path')

    def test_get_absolute_first_path_from_prefix_no_matches(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with no matching files"""
        with patch('os.listdir') as mock_listdir, \
             patch('os.path.exists') as mock_exists:
            
            mock_exists.return_value = True
            mock_listdir.return_value = ['file1.txt', 'file2.txt']
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'nonexistent_prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_directory_not_found(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with non-existent directory"""
        with patch('os.path.exists') as mock_exists:
            mock_exists.return_value = False
            
            result = orchestrator.get_absolute_first_path_from_prefix('/nonexistent/path', 'prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_empty_directory(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with empty directory"""
        with patch('os.listdir') as mock_listdir, \
             patch('os.path.exists') as mock_exists:
            
            mock_exists.return_value = True
            mock_listdir.return_value = []
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_multiple_matches(self, orchestrator):
        """Test get_absolute_first_path_from_prefix returns first matching file"""
        with patch('os.listdir') as mock_listdir, \
             patch('os.path.exists') as mock_exists, \
             patch('os.path.abspath') as mock_abspath, \
             patch('os.path.join') as mock_join:
            
            mock_exists.return_value = True
            mock_listdir.return_value = ['prefix_file1.txt', 'other.txt', 'prefix_file2.txt']
            mock_join.return_value = '/test/path/prefix_file1.txt'
            mock_abspath.return_value = '/test/path/prefix_file1.txt'
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result == '/test/path/prefix_file1.txt'

    def test_get_absolute_first_path_from_prefix_permission_error(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with permission denied"""
        with patch('os.path.exists') as mock_exists, \
             patch('os.listdir') as mock_listdir:
            
            mock_exists.return_value = True
            mock_listdir.side_effect = PermissionError("Permission denied")
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_file_not_found_error(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with FileNotFoundError during listdir"""
        with patch('os.path.exists') as mock_exists, \
             patch('os.listdir') as mock_listdir:
            
            mock_exists.return_value = True
            mock_listdir.side_effect = FileNotFoundError("Directory not found")
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_os_error(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with OSError"""
        with patch('os.path.exists') as mock_exists, \
             patch('os.listdir') as mock_listdir:
            
            mock_exists.return_value = True
            mock_listdir.side_effect = OSError("I/O error")
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result is None

    def test_get_absolute_first_path_from_prefix_general_exception(self, orchestrator):
        """Test get_absolute_first_path_from_prefix with unexpected exception"""
        with patch('os.path.exists') as mock_exists, \
             patch('os.listdir') as mock_listdir:
            
            mock_exists.return_value = True
            mock_listdir.side_effect = RuntimeError("Unexpected error")
            
            result = orchestrator.get_absolute_first_path_from_prefix('/test/path', 'prefix')
            
            assert result is None

    @mock_all_transformers()
    @patch('datetime.datetime')
    def test_gcs_upload_path_format(self, mock_datetime, orchestrator):
        """Test GCS upload path format"""
        mock_datetime.now.return_value.strftime.return_value = "23-01-01"
        
        mock_transformer = MagicMock()
        mock_transformer.transform.return_value = []
        mock_transformer.output_configuration = TransformerConfig(
            output_file_name="test_report.txt",
            page_size=100,
            report_id="TEST001"
        )
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[mock_transformer]), \
             patch('src.report_generator.orchestrator.FlatFileWriter'), \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            orchestrator.start()
            
            # Verify upload path format
            expected_path = "reports/TEST001/23-01-01/test_report.txt"
            orchestrator.gcs_utils.upload_file.assert_called()
            call_args = orchestrator.gcs_utils.upload_file.call_args
            assert expected_path in str(call_args)

    @mock_all_transformers()
    def test_file_processing_with_binary_conversion(self, orchestrator):
        """Test file processing with binary conversion"""
        mock_config = FlatFileReadConfiguration(
            bucket="test-bucket",
            remote_file="test/file.dat",
            layout="layout.json",
            file="test_file.txt",
            fixed_size=100,
            type=FileType.GCS
        )
        
        with patch('builtins.open', mock_open(read_data="test line\n")) as mock_file, \
             patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[mock_config]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.FlatFileToCSVGenerator') as mock_generator, \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            mock_generator_instance = MagicMock()
            mock_generator.return_value = mock_generator_instance
            
            orchestrator.start()
            
            # Verify binary file was created
            binary_calls = [call for call in mock_file.call_args_list if 'wb' in str(call)]
            assert len(binary_calls) > 0

    @mock_all_transformers()
    def test_logging_throughout_process(self, orchestrator):
        """Test that appropriate logging occurs throughout the process"""
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch.object(orchestrator, '_Orchestrator__get_transformer_configs', return_value=[]), \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            orchestrator.start()
            
            # Verify completion message is logged
            info_calls = [call for call in orchestrator.logger.info.call_args_list]
            completion_logged = any("completed" in str(call).lower() for call in info_calls)
            assert completion_logged

    @mock_all_transformers()
    def test_error_collection_and_logging(self, orchestrator):
        """Test that errors are collected and logged"""
        # Mock transformer that raises an exception
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = Exception("Test error")
        mock_transformer.__class__.__name__ = "TestTransformer"
        mock_transformer.output_configuration = MagicMock()
        mock_transformer.output_configuration.output_file_name = "test.txt"
        mock_transformer.output_configuration.report_id = "TEST001"
        
        with patch.object(orchestrator, '_Orchestrator__get_flat_file_configs', return_value=[]), \
             patch('src.report_generator.orchestrator.Orchestrator._Orchestrator__get_transformer_configs', return_value=[mock_transformer]), \
             patch('os.makedirs'), \
             patch('os.path.exists', return_value=True), \
             patch('os.getcwd', return_value="/test"):
            
            orchestrator.start()
            
            # Verify errors are logged
            error_calls = [call for call in orchestrator.logger.error.call_args_list]
            assert len(error_calls) > 0
            
            # Check that error collection happens
            assert any("Error in transformer" in str(call) for call in error_calls)

    @mock_all_transformers()
    def test_integration_with_real_transformer_types(self, orchestrator):
        """Test integration with actual transformer types"""
        # This tests that the orchestrator can work with real transformer classes
        # even if they're mocked at the constructor level
        
        with patch('src.report_generator.orchestrator.EligibilityFileTransformer') as mock_eligibility, \
             patch('src.report_generator.orchestrator.TerminationTransformer') as mock_termination, \
             patch('src.report_generator.orchestrator.ReHireTransformer') as mock_rehire:
            
            # Mock the constructors to return mock instances
            mock_eligibility.return_value = MagicMock()
            mock_termination.return_value = MagicMock()
            mock_rehire.return_value = MagicMock()
            
            transformers = orchestrator._Orchestrator__get_transformer_configs(orchestrator.logger)
            
            # Should return a list of transformer instances
            assert isinstance(transformers, list)
            assert len(transformers) > 0
