import pytest
from unittest.mock import patch, MagicMock, mock_open
from abc import ABC, abstractmethod
import yaml

from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.data_object import DataObject


class MockDataObject(DataObject):
    """Mock data object for testing"""
    
    def __init__(self, template_name="test_template.txt", include_newline=True, data=None):
        self._template_name = template_name
        self._include_newline = include_newline
        self._data = data or {"field1": "value1", "field2": "value2"}
    
    def template_name(self) -> str:
        return self._template_name
    
    def include_new_line(self) -> bool:
        return self._include_newline
    
    def to_dict(self) -> dict:
        return self._data


class ConcreteTransformer(Transformer):
    """Concrete implementation of Transformer for testing"""
    
    def __init__(self, config, report_type, logger):
        super().__init__(config, report_type, logger)
        self._test_data = []
    
    def _header(self, page: int) -> DataObject:
        return MockDataObject("header.txt", True, {"page": page, "title": "Test Header"})
    
    def _dynamic_trailer(self, records: list[DataObject]) -> DataObject:
        return MockDataObject("trailer.txt", True, {"count": len(records)})
    
    def _trailer(self) -> DataObject:
        return MockDataObject("footer.txt", False, {"end": "Report End"})
    
    def _transform(self) -> list[MockDataObject]:
        return self._test_data
    
    def identifier(self) -> str:
        return "TEST_TRANSFORMER"
    
    def data_template_name(self) -> str:
        return "data_template.txt"
    
    def set_test_data(self, data):
        """Helper method to set test data"""
        self._test_data = data


class TestTransformer:
    """Test suite for the Transformer base class"""

    @pytest.fixture
    def mock_dependencies(self):
        """Mock all external dependencies"""
        with patch('src.report_generator.transformer.SparkSession') as mock_spark, \
             patch('src.report_generator.transformer.BigQueryDatabase') as mock_bq, \
             patch('src.utils.app_config.get_config_value') as mock_config, \
             patch('builtins.open', mock_open(read_data="test_connection_string")):
            
            # Mock SparkSession builder chain
            mock_session = MagicMock()
            mock_builder = MagicMock()
            mock_builder_app = MagicMock()
            
            mock_spark.builder = mock_builder
            mock_builder.appName = MagicMock(return_value=mock_builder_app)
            mock_builder_app.config = MagicMock(return_value=mock_builder_app)
            mock_builder_app.master = MagicMock(return_value=mock_builder_app)
            mock_builder_app.getOrCreate = MagicMock(return_value=mock_session)
            
            mock_config.return_value = "test_path"
            mock_bq.return_value = MagicMock()
            
            yield {
                'spark': mock_spark,
                'bigquery': mock_bq,
                'config': mock_config,
                'session': mock_session
            }

    @pytest.fixture
    def sample_config(self):
        """Create a sample TransformerConfig"""
        return TransformerConfig(
            output_file_name="test_output.txt",
            page_size=100,
            report_id="TEST001"
        )

    @pytest.fixture
    def transformer(self, mock_dependencies, sample_config):
        """Create a ConcreteTransformer instance"""
        logger = MagicMock()
        return ConcreteTransformer(sample_config, ReportType.US, logger)

    def test_transformer_initialization(self, transformer, mock_dependencies):
        """Test Transformer initialization"""
        assert transformer.output_configuration is not None
        assert transformer.logger is not None
        assert transformer.report_type == ReportType.US
        assert transformer.spark is not None
        assert transformer.gcp_connection is not None

    def test_transformer_cosmos_config(self, transformer):
        """Test _cosmos_config method"""
        config = transformer._cosmos_config()
        
        assert isinstance(config, dict)
        assert "spark.cosmos.accountEndpoint" in config
        assert "spark.cosmos.accountKey" in config
        assert "spark.cosmos.database" in config
        assert config["spark.cosmos.database"] == "benefits-platform"
        assert "spark.cosmos.read.maxItemCount" in config
        assert "spark.cosmos.read.partitioning.strategy" in config

    @patch('yaml.full_load')
    def test_transformer_postgres_config_missing_config(self, mock_yaml_load, transformer):
        """Test _postgres_config with missing configuration"""
        mock_yaml_load.return_value = {}
        
        with patch('builtins.open', mock_open(read_data="yaml_content")):
            with pytest.raises(AttributeError, match="'NoneType' object has no attribute 'get'"):
                transformer._postgres_config()

    def test_transformer_postgres_config_covers_exception_handling(self, transformer):
        """Test _postgres_config exception handling lines 84-85"""
        # Mock get_config_value to raise an exception
        with patch('src.utils.app_config.get_config_value', side_effect=Exception("Config error")):
            with pytest.raises(Exception, match="Config error"):
                transformer._postgres_config()

    def test_transformer_cosmos_dataframe(self, transformer):
        """Test cosmos_dataframe method"""
        container_name = "test-container"
        
        dataframe = transformer.cosmos_dataframe(container_name)
        
        # Verify Spark read format was set up correctly
        transformer.spark.read.format.assert_called_with("cosmos.oltp")

    def test_transformer_db2_frame(self, transformer):
        """Test db2_frame method"""
        table_name = "test_table"
        
        dataframe = transformer.db2_frame(table_name)
        
        # Verify JDBC connection was set up
        transformer.spark.read.option.assert_called_with("fetchsize", "100000")

    def test_transformer_cosmos_query(self, transformer):
        """Test cosmos_query method"""
        query = "SELECT * FROM c WHERE c.id = 'test'"
        container_name = "test-container"
        
        result = transformer.cosmos_query(query, container_name)
        
        # Verify format and options were set
        transformer.spark.read.format.assert_called_with("cosmos.oltp")

    def test_transformer_db2_query(self, transformer):
        """Test db2_query method"""
        query = "SELECT * FROM test_table"
        
        result = transformer.db2_query(query)
        
        # Verify JDBC format was used
        transformer.spark.read.format.assert_called_with('jdbc')

    def test_transformer_bigquery_extract(self, transformer):
        """Test bigquery_extract method"""
        query = "SELECT * FROM test_dataset.test_table"
        
        result = transformer.bigquery_extract(query)
        
        # Verify BigQuery connection was used
        transformer.gcp_connection.get_df_from_query.assert_called_with(query)

    @patch('yaml.full_load')
    def test_transformer_postgres_frame(self, mock_yaml_load, transformer):
        """Test postgres_frame method"""
        # Mock YAML configuration
        mock_config = {
            "sqlDbConfig": {
                "host": "test-host",
                "port": "5432",
                "database": "test-db",
                "user": "test-user",
                "pass": "test-pass",
                "currentSchema": "test-schema"
            }
        }
        mock_yaml_load.return_value = mock_config
        
        with patch('builtins.open', mock_open(read_data="yaml_content")):
            table_name = "test_table"
            result = transformer.postgres_frame(table_name)
        
        # Verify JDBC connection was set up
        transformer.spark.read.option.assert_called_with("fetchsize", "100000")

    def test_transformer_transform_with_empty_data(self, transformer):
        """Test transform method with no data"""
        transformer.set_test_data([])
        
        result = transformer.transform()
        
        assert isinstance(result, list)
        assert len(result) == 4  # header, empty data wrapper, dynamic trailer, trailer
        
        # Verify header is created with page 1
        header = result[0]
        assert hasattr(header, 'to_dict')

    def test_transformer_transform_with_single_page_data(self, transformer):
        """Test transform method with single page of data"""
        test_data = [
            MockDataObject("data1.txt", True, {"id": "1"}),
            MockDataObject("data2.txt", True, {"id": "2"}),
            MockDataObject("data3.txt", True, {"id": "3"})
        ]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        assert isinstance(result, list)
        assert len(result) == 4  # header, data wrapper, dynamic trailer, trailer
        
        # Verify data wrapper contains the test data
        data_wrapper = result[1]
        assert hasattr(data_wrapper, 'data')

    def test_transformer_transform_with_multiple_pages(self, transformer):
        """Test transform method with multiple pages of data"""
        # Create more data than page size (100)
        test_data = [MockDataObject(f"data{i}.txt", True, {"id": str(i)}) for i in range(150)]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        # Should have: header1, data1, header2, data2, dynamic_trailer, trailer
        assert len(result) == 6
        
        # First page header
        assert result[0].to_dict()["page"] == 1
        # Second page header  
        assert result[2].to_dict()["page"] == 2

    def test_transformer_transform_with_exact_page_size(self, transformer):
        """Test transform method with exactly page size data"""
        # Create exactly page size (100) data objects
        test_data = [MockDataObject(f"data{i}.txt", True, {"id": str(i)}) for i in range(100)]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        # Should have: header, data, dynamic_trailer, trailer
        assert len(result) == 4

    def test_transformer_transform_error_handling(self, transformer):
        """Test transform method error handling"""
        # Mock _transform to raise an exception
        def failing_transform():
            raise Exception("Transform failed")
        
        transformer._transform = failing_transform
        
        with pytest.raises(Exception, match="Transform failed"):
            transformer.transform()
        
        # Verify Spark cache was cleared
        transformer.spark.catalog.clearCache.assert_called()

    def test_transformer_abstract_methods_enforcement(self):
        """Test that abstract methods are properly enforced"""
        # Attempting to instantiate Transformer directly should fail
        with pytest.raises(TypeError):
            config = TransformerConfig("test.txt", 100, "TEST")
            logger = MagicMock()
            
            # This should fail because Transformer has abstract methods
            with patch('src.report_generator.transformer.SparkSession'), \
                 patch('src.report_generator.transformer.BigQueryDatabase'), \
                 patch('src.utils.app_config.get_config_value'), \
                 patch('builtins.open', mock_open(read_data="test")):
                transformer = Transformer(config, ReportType.US, logger)

    def test_transformer_logging_during_transform(self, transformer):
        """Test that appropriate logging occurs during transform"""
        test_data = [MockDataObject("data.txt", True, {"id": "1"})]
        transformer.set_test_data(test_data)
        
        transformer.transform()
        
        # Verify logging calls
        log_calls = [str(call) for call in transformer.logger.info.call_args_list]
        
        starting_logged = any("Starting transformation" in call for call in log_calls)
        completed_logged = any("Transformation completed" in call for call in log_calls)
        
        assert starting_logged
        assert completed_logged

    def test_transformer_page_size_configuration(self, transformer):
        """Test that page size configuration is respected"""
        # Set a small page size for testing
        transformer.output_configuration.page_size = 2
        
        test_data = [
            MockDataObject("data1.txt", True, {"id": "1"}),
            MockDataObject("data2.txt", True, {"id": "2"}),
            MockDataObject("data3.txt", True, {"id": "3"}),
            MockDataObject("data4.txt", True, {"id": "4"}),
            MockDataObject("data5.txt", True, {"id": "5"})
        ]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        # Should have multiple pages: header1, data1, header2, data2, header3, data3, dynamic_trailer, trailer
        assert len(result) == 8  # 3 headers + 3 data wrappers + 1 dynamic trailer + 1 trailer

    def test_transformer_data_object_wrapper_creation(self, transformer):
        """Test that DataObjectWrapper is created correctly"""
        test_data = [MockDataObject("data.txt", True, {"id": "1"})]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        # Check data wrapper
        data_wrapper = result[1]
        assert hasattr(data_wrapper, 'data')
        assert hasattr(data_wrapper, 'template_name')

    def test_transformer_dynamic_trailer_receives_all_records(self, transformer):
        """Test that dynamic trailer receives all original records"""
        test_data = [
            MockDataObject("data1.txt", True, {"id": "1"}),
            MockDataObject("data2.txt", True, {"id": "2"}),
            MockDataObject("data3.txt", True, {"id": "3"})
        ]
        transformer.set_test_data(test_data)
        
        result = transformer.transform()
        
        # Find dynamic trailer
        dynamic_trailer = result[-2]  # Second to last element
        
        # Should contain count of all records
        trailer_data = dynamic_trailer.to_dict()
        assert trailer_data["count"] == 3

    def test_transformer_spark_session_configuration(self, transformer, mock_dependencies):
        """Test Spark session configuration"""
        session = mock_dependencies['session']
        spark_builder = mock_dependencies['spark']
        
        # Verify Spark configuration calls
        spark_builder.builder.appName.assert_called_with("ReportGeneratorSparkSession")
        
        # Verify various config options were set
        config_calls = spark_builder.builder.appName.return_value.config.call_args_list
        config_dict = {call[0][0]: call[0][1] for call in config_calls}
        
        assert "spark.driver.memory" in config_dict
        assert "spark.executor.memory" in config_dict
        assert "spark.jars.packages" in config_dict

    def test_transformer_connection_string_reading(self, transformer):
        """Test that connection strings are read correctly"""
        # DB2 connection should be read
        assert hasattr(transformer, 'db2_connection')
        
        # Cosmos connection should be read
        assert hasattr(transformer, 'cosmos_connection_string')
        assert hasattr(transformer, 'cosmos_connection_url')

    def test_transformer_error_logging_during_transform(self, transformer):
        """Test error logging during transform"""
        # Make _transform raise an exception
        def failing_transform():
            raise ValueError("Test error")
        
        transformer._transform = failing_transform
        
        with pytest.raises(ValueError):
            transformer.transform()
        
        # Verify error was logged
        transformer.logger.error.assert_called()
        error_args = transformer.logger.error.call_args[0]
        assert "Error during transformation" in error_args[0]

    def test_transformer_with_different_report_types(self, mock_dependencies, sample_config):
        """Test transformer with different report types"""
        logger = MagicMock()
        
        # Test with different report types
        report_types = [ReportType.US, ReportType.PR]
        
        for report_type in report_types:
            transformer = ConcreteTransformer(sample_config, report_type, logger)
            assert transformer.report_type == report_type

    def test_transformer_spark_cleanup_on_error(self, transformer):
        """Test that Spark cache is cleared on error"""
        def failing_transform():
            raise RuntimeError("Simulated error")
        
        transformer._transform = failing_transform
        
        with pytest.raises(RuntimeError):
            transformer.transform()
        
        # Verify cache was cleared
        transformer.spark.catalog.clearCache.assert_called_once()

    def test_transformer_integration_with_real_config_files(self, transformer):
        """Test integration with configuration file reading"""
        # This tests the file reading parts of the constructor
        # The files are mocked, but the structure should be correct
        
        assert transformer.db2_connection is not None
        assert transformer.cosmos_connection_string is not None
        assert transformer.cosmos_connection_url is not None

    def test_transformer_postgres_connection_error_handling(self, transformer):
        """Test PostgreSQL connection error handling"""
        with patch('builtins.open', mock_open()) as mock_file:
            mock_file.side_effect = FileNotFoundError("Config file not found")
            
            with pytest.raises(FileNotFoundError):
                transformer._postgres_config()

    def test_transformer_postgres_frame_error_handling(self, transformer):
        """Test postgres_frame error handling"""
        with patch.object(transformer, '_postgres_config', side_effect=Exception("Connection error")):
            with pytest.raises(ConnectionError):
                transformer.postgres_frame("test_table")
