import pytest
from unittest.mock import MagicMock, patch, mock_open
from jinja2 import Environment, TemplateNotFound

from src.report_generator.flat_file_writer import FlatFileWriter, pad_pre, pad_post
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject


class MockDataObject(DataObject):
    """Mock data object for testing"""
    
    def __init__(self, template_name="test_template.txt", include_newline=True, data=None):
        self._template_name = template_name
        self._include_newline = include_newline
        self._data = data or {"field1": "value1", "field2": "value2"}
    
    def template_name(self) -> str:
        return self._template_name
    
    def include_new_line(self) -> bool:
        return self._include_newline
    
    def to_dict(self) -> dict:
        return self._data


class TestFlatFileWriter:
    """Test suite for the FlatFileWriter class"""

    @pytest.fixture
    def writer(self):
        """Create a FlatFileWriter instance for testing"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env:
            writer = FlatFileWriter()
            writer.env = mock_env.return_value
            return writer

    @pytest.fixture
    def sample_config(self):
        """Create a sample TransformerConfig for testing"""
        data_objects = [
            MockDataObject("header.txt", True, {"title": "Test Report"}),
            MockDataObject("data.txt", True, {"record_id": "001", "name": "John Doe"}),
            MockDataObject("footer.txt", False, {"total_records": "1"})
        ]
        
        config = TransformerConfig(
            output_file_name="test_report.txt",
            page_size=100,
            report_id="TEST001",
            data_objects=data_objects
        )
        return config

    def test_pad_pre_function(self):
        """Test the pad_pre utility function"""
        # Test normal padding
        assert pad_pre("123", "0", 5) == "00123"
        assert pad_pre("hello", " ", 10) == "     hello"
        
        # Test exact width
        assert pad_pre("12345", "0", 5) == "12345"
        
        # Test truncation when value is longer than width
        assert pad_pre("123456789", "0", 5) == "12345"
        
        # Test with numbers
        assert pad_pre(42, "0", 4) == "0042"
        
        # Test with zero width
        assert pad_pre("test", "0", 0) == ""

    def test_pad_post_function(self):
        """Test the pad_post utility function"""
        # Test normal padding
        assert pad_post("123", "0", 5) == "12300"
        assert pad_post("hello", " ", 10) == "hello     "
        
        # Test exact width
        assert pad_post("12345", "0", 5) == "12345"
        
        # Test truncation when value is longer than width
        assert pad_post("123456789", "0", 5) == "12345"
        
        # Test with numbers
        assert pad_post(42, "0", 4) == "4200"
        
        # Test default width (10)
        assert pad_post("test", " ") == "test      "

    def test_flat_file_writer_initialization(self):
        """Test FlatFileWriter initialization"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            # Verify Environment was created with correct parameters
            mock_env_class.assert_called_once()
            call_args = mock_env_class.call_args
            
            # Check if filters were added
            assert mock_env.filters.__setitem__.called
            
            # Verify folder path
            assert writer.folder == "src/report_generator/output_temp/reports"

    @patch('builtins.open', new_callable=mock_open)
    def test_write_single_data_object(self, mock_file):
        """Test writing a single data object"""
        # Setup
        mock_template = MagicMock()
        mock_template.render.return_value = "Rendered content"
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            data_object = MockDataObject("test_template.txt", True, {"field": "value"})
            config = TransformerConfig(
                output_file_name="test.txt",
                page_size=100,
                report_id="TEST",
                data_objects=[data_object]
            )
            
            # Execute
            writer.write(config)
            
            # Verify template was retrieved and rendered
            mock_env.get_template.assert_called_with("test_template.txt")
            mock_template.render.assert_called_with({"field": "value"})
            
            # Verify file operations
            expected_path = "src/report_generator/output_temp/reports/test.txt"
            mock_file.assert_called()

    @patch('builtins.open', new_callable=mock_open)
    def test_write_multiple_data_objects(self, mock_file):
        """Test writing multiple data objects"""
        mock_template = MagicMock()
        mock_template.render.side_effect = ["Header content", "Data content", "Footer content"]
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            data_objects = [
                MockDataObject("header.txt", True, {"title": "Report"}),
                MockDataObject("data.txt", True, {"record": "001"}),
                MockDataObject("footer.txt", False, {"count": "1"})
            ]
            
            config = TransformerConfig(
                output_file_name="multi_test.txt",
                page_size=100,
                report_id="MULTI",
                data_objects=data_objects
            )
            
            # Execute
            writer.write(config)
            
            # Verify multiple template calls
            assert mock_env.get_template.call_count == 3
            assert mock_template.render.call_count == 3

    @patch('builtins.open', new_callable=mock_open)
    def test_write_with_newlines(self, mock_file):
        """Test that newlines are added correctly based on data object settings"""
        mock_template = MagicMock()
        mock_template.render.return_value = "Content"
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            # Data object that includes newline
            data_with_newline = MockDataObject("template.txt", True, {"data": "test"})
            
            config = TransformerConfig(
                output_file_name="newline_test.txt",
                page_size=100,
                report_id="NL",
                data_objects=[data_with_newline]
            )
            
            writer.write(config)
            
            # Verify write operations included newline
            mock_file.return_value.write.assert_called()

    @patch('builtins.open', new_callable=mock_open)
    def test_write_without_newlines(self, mock_file):
        """Test writing without newlines when data object specifies not to include them"""
        mock_template = MagicMock()
        mock_template.render.return_value = "Content"
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            # Data object that doesn't include newline
            data_without_newline = MockDataObject("template.txt", False, {"data": "test"})
            
            config = TransformerConfig(
                output_file_name="no_newline_test.txt",
                page_size=100,
                report_id="NNL",
                data_objects=[data_without_newline]
            )
            
            writer.write(config)

            # Check that newline was not written for this object
            write_calls = mock_file.return_value.write.call_args_list
            newline_calls = [call for call in write_calls if '\n' in str(call)]
            # Should have no explicit newline calls for this test
            # (the actual implementation may vary, this tests the logic)

    @patch('builtins.open', new_callable=mock_open)
    def test_write_with_none_data_objects(self, mock_file):
        """Test handling of None data objects"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="none_test.txt",
                page_size=100,
                report_id="NONE",
                data_objects=[None, MockDataObject("valid.txt", True, {"data": "test"}), None]
            )
            
            writer.write(config)
            
            # Should only process non-None objects
            assert mock_env.get_template.call_count == 1

    @patch('builtins.open', new_callable=mock_open)
    def test_file_truncation(self, mock_file):
        """Test that file is truncated before writing"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="truncate_test.txt",
                page_size=100,
                report_id="TRUNC",
                data_objects=[]
            )
            
            writer.write(config)
            
            # Verify file was opened and truncated
            mock_file.return_value.truncate.assert_called_with(0)

    @patch('builtins.open', new_callable=mock_open)
    def test_template_error_handling(self, mock_file):
        """Test error handling when template is not found"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.side_effect = TemplateNotFound("template.txt")
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="error_test.txt",
                page_size=100,
                report_id="ERR",
                data_objects=[MockDataObject("missing_template.txt", True, {})]
            )
            
            # Should raise TemplateNotFound exception
            with pytest.raises(TemplateNotFound):
                writer.write(config)

    @patch('builtins.open', new_callable=mock_open)
    def test_template_render_error(self, mock_file):
        """Test error handling when template rendering fails"""
        mock_template = MagicMock()
        mock_template.render.side_effect = Exception("Render error")
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="render_error_test.txt",
                page_size=100,
                report_id="RENDER_ERR",
                data_objects=[MockDataObject("template.txt", True, {"bad_data": None})]
            )
            
            with pytest.raises(Exception, match="Render error"):
                writer.write(config)

    def test_filter_registration(self):
        """Test that custom filters are properly registered"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env

            writer = FlatFileWriter()

            # Verify filters were registered
            expected_calls = [
                (('pad_pre', pad_pre),),
                (('pad_post', pad_post),)
            ]

            # Check that filters were set
            assert mock_env.filters.__setitem__.called

    @patch('builtins.open')
    def test_file_write_operations(self, mock_open_func):
        """Test the sequence of file operations"""
        mock_file = MagicMock()
        mock_open_func.return_value.__enter__.return_value = mock_file
        
        mock_template = MagicMock()
        mock_template.render.return_value = "Test content"
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env.get_template.return_value = mock_template
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="operations_test.txt",
                page_size=100,
                report_id="OPS",
                data_objects=[MockDataObject("template.txt", True, {"data": "test"})]
            )
            
            writer.write(config)

            # Verify file operations sequence
            expected_path = "src/report_generator/output_temp/reports/operations_test.txt"

            # Check that file was opened multiple times (once for truncate, once for append)
            assert mock_open_func.called

    def test_config_validation(self):
        """Test that config object is properly used"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class, \
             patch('builtins.open', mock_open()) as mock_open_func:
            
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            # Test with minimal config
            minimal_config = TransformerConfig(
                output_file_name="minimal.txt",
                page_size=50,
                report_id="MIN",
                data_objects=[]
            )
            
            # Should not raise any errors
            writer.write(minimal_config)
            
            # Verify output file name is used correctly
            expected_path = f"{writer.folder}/minimal.txt"
            assert "minimal.txt" in expected_path
            
            # Verify file was opened
            mock_open_func.assert_called()

    @patch('builtins.open', new_callable=mock_open)
    def test_empty_data_objects_list(self, mock_file):
        """Test behavior with empty data objects list"""
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            mock_env = MagicMock()
            mock_env_class.return_value = mock_env
            
            writer = FlatFileWriter()
            
            config = TransformerConfig(
                output_file_name="empty.txt",
                page_size=100,
                report_id="EMPTY",
                data_objects=[]
            )
            
            writer.write(config)
            
            # Should still truncate file but not process any templates
            mock_file.return_value.truncate.assert_called_with(0)
            assert not mock_env.get_template.called

    def test_complex_data_object_integration(self):
        """Test integration with complex data objects"""
        complex_data = {
            "header": {"title": "Complex Report", "date": "2023-01-01"},
            "records": [
                {"id": "001", "name": "John", "amount": 1000.50},
                {"id": "002", "name": "Jane", "amount": 2000.75}
            ],
            "summary": {"total": 3001.25, "count": 2}
        }
        
        mock_template = MagicMock()
        mock_template.render.return_value = "Complex rendered content"
        
        with patch('src.report_generator.flat_file_writer.Environment') as mock_env_class:
            with patch('builtins.open', new_callable=mock_open):
                mock_env = MagicMock()
                mock_env.get_template.return_value = mock_template
                mock_env_class.return_value = mock_env
                
                writer = FlatFileWriter()
                
                config = TransformerConfig(
                    output_file_name="complex.txt",
                    page_size=100,
                    report_id="COMPLEX",
                    data_objects=[MockDataObject("complex_template.txt", True, complex_data)]
                )
                
                writer.write(config)
                
                # Verify complex data was passed to template
                mock_template.render.assert_called_with(complex_data)
