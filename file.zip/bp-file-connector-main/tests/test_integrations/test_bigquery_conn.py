import pytest
from unittest.mock import Mock, patch, mock_open, call
import pandas as pd
from datetime import datetime
import time
from src.integrations.bigquery_conn import BigQueryDatabase
from src.utils.errors.app_errors import ApplicationError


class TestBigQueryBatchProcessing:
    @pytest.fixture
    def mock_logger(self):
        return Mock()

    @pytest.fixture
    def bq_db(self, mock_logger):
        with patch('google.cloud.bigquery.Client'), \
                patch('src.utils.app_config.get_config_value', return_value='/mock/path/gcs_connection.json'):
            return BigQueryDatabase(mock_logger)

    def test_process_bigquery_batch(self, bq_db, mock_logger):
        """Test successful batch processing"""
        mock_df = pd.DataFrame({'col1': [1, 2], 'col2': ['a', 'b']})

        with patch.multiple(bq_db,
                            _execute_batch_query=Mock(
                                return_value=[{'col1': 1, 'col2': 'a'}, {'col1': 2, 'col2': 'b'}]),
                            _create_batch_dataframe=Mock(return_value=mock_df),
                            _write_batch_to_file=Mock(),
                            _log_batch_metrics=Mock()
                            ):
            batch_params = (0, True, 'test.csv', None)
            result = bq_db.process_bigquery_batch(batch_params, "SELECT * FROM test", {})

            assert result == 2
            bq_db._execute_batch_query.assert_called_once()
            bq_db._create_batch_dataframe.assert_called_once()
            bq_db._write_batch_to_file.assert_called_once()
            bq_db._log_batch_metrics.assert_called_once()

    def test_process_bigquery_batch_error(self, bq_db, mock_logger):
        """Test error handling in batch processing"""
        with patch.object(bq_db, '_execute_batch_query', side_effect=Exception("Query failed")):
            with pytest.raises(ApplicationError) as exc_info:
                bq_db.process_bigquery_batch((0, True, 'test.csv', None), "SELECT * FROM test", {})

            assert "Error processing batch" in str(exc_info.value)
            mock_logger.error.assert_called_once()

    def test_write_batch_to_file_error(self, bq_db, mock_logger):
        """Test error handling in file writing"""
        df = pd.DataFrame({'col1': [1, 2]})

        with patch('builtins.open', side_effect=IOError("File error")):
            with pytest.raises(ApplicationError) as exc_info:
                bq_db._write_batch_to_file(df, 'test.csv', True)

            assert "Failed to write batch to file" in str(exc_info.value)
            mock_logger.error.assert_called_once()

    def test_fetch_and_write_data_error(self, bq_db, mock_logger):
        """Test error handling in fetch and write process"""
        with patch.object(bq_db, 'process_bigquery_batch', side_effect=Exception("Process failed")):
            with pytest.raises(ApplicationError) as exc_info:
                bq_db.fetch_and_write_data("SELECT * FROM test", {}, 'test.csv', 100)

            # Fixed assertion to match actual error message format
            assert "Error fetching and writing data: Process failed" in str(exc_info.value)
            mock_logger.error.assert_called_once()