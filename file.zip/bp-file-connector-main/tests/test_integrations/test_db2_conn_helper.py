import sys
import unittest
from unittest.mock import patch, MagicMock, Mock
from datetime import datetime, timezone

from src.utils.errors.db2_errors import DatabaseError, FetchDBError, InsertDBError, UpdateDBError, DeleteDBError

# Mock external service dependencies to isolate tests
mock_modules = {
    'ibm_db': Mock(),
    'ibm_db_dbi': Mock(),
    'pymongo': Mock(),
    'pymongo.errors': Mock(),
    'google': Mock(),
    'google.cloud': Mock(),
    'google.cloud.storage': Mock(),
    'google.cloud.bigquery': Mock(),
}

for module_name, mock_obj in mock_modules.items():
    sys.modules[module_name] = mock_obj

from src.integrations.db2_conn_helper import DB2IDatabase, create_dir_if_not_exists, formatted_today

CONST_TEST_SELECT_QUERY = 'SELECT * FROM test_table'
CONST_TEST_UPDATE_QUERY = 'UPDATE test_table SET col1 = ? WHERE col2 = ?'
class TestDB2ConnectionHelper(unittest.TestCase):

    def setUp(self):
        self.logger_mock = MagicMock()
        self.db_config = {
            'db2_region': {
                'db2_database': 'test_db',
                'db2_hostname': 'localhost',
                'db2_protocol': 'TCPIP',
                'db2_userid': 'user',
                'db2_port': '50000',
                'db2_ssl_client_label': 'ssl_label',
                'db2_ssl_client_keystoredb': '/path/to/keystore.db',
                'db2_ssl_client_keystash': '/path/to/keystash.sth',
                'db2_testset': 'testset'
            }
        }


        # Set up all required patches
        self.patches = [
            patch('src.utils.app_config.get_config_value', return_value='/path/to/config.yaml'),
            patch('builtins.open'),
            patch('yaml.full_load', return_value=self.db_config),
            patch('ibm_db_dbi.connect')
        ]
        self.mocks = []
        for patcher in self.patches:
            self.mocks.append(patcher.start())
            self.addCleanup(patcher.stop)
        self.mock_config, self.mock_open, self.mock_yaml, self.mock_connect = self.mocks
        self.db = DB2IDatabase(self.logger_mock, key="db2_region")

    def test_formatted_today(self):
        date_format = "%Y-%m-%d %H:%M:%S"
        result = formatted_today(date_format)
        expected = datetime.now(timezone.utc).strftime(date_format)
        self.assertEqual(result, expected)

    @patch('os.makedirs')
    @patch('os.path.exists')
    def test_create_dir_if_not_exists(self, mock_exists, mock_makedirs):
        mock_exists.return_value = False

        result = create_dir_if_not_exists('/test/dir', self.logger_mock)
        self.assertEqual(result, 1)
        mock_makedirs.assert_called_once_with('/test/dir')
        self.logger_mock.info.assert_called_with("Directory /test/dir created")

        # Test when directory exists
        mock_exists.return_value = True
        result = create_dir_if_not_exists('/test/dir', self.logger_mock)
        self.assertEqual(result, 0)
        self.logger_mock.info.assert_called_with("Directory /test/dir exists already")

    @patch('ibm_db_dbi.connect')
    def test_fetch_chunk(self, mock_connect):
        # Mock the cursor and fetchmany method
        mock_cursor = MagicMock()
        mock_cursor.fetchmany.side_effect = [[(1, 'row1')], [(2, 'row2')], []]
        self.db.cursor = mock_cursor

        query = CONST_TEST_SELECT_QUERY
        result = list(self.db.fetch_chunk(query, chunk_size=1))
        self.assertEqual(result, [[(1, 'row1')], [(2, 'row2')]])

    @patch('ibm_db_dbi.connect')
    def test_fetch_chunk_error(self, mock_connect):
        # Simulate an error during fetch_chunk
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Fetch failed")
        self.db.cursor = mock_cursor

        query = CONST_TEST_SELECT_QUERY
        with self.assertRaises(FetchDBError):
            list(self.db.fetch_chunk(query))

    @patch('ibm_db_dbi.connect')
    def test_fetchall(self, mock_connect):
        # Mock the cursor and the fetchall method
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1, 'row1'), (2, 'row2')]
        self.db.cursor = mock_cursor

        query = CONST_TEST_SELECT_QUERY
        result = self.db.fetchall(query)
        self.assertEqual(result, [(1, 'row1'), (2, 'row2')])

    @patch('ibm_db_dbi.connect')
    def test_fetchall_error(self, mock_connect):
        # Simulate an error during fetchall
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Fetchall failed")
        self.db.cursor = mock_cursor

        query = CONST_TEST_SELECT_QUERY
        with self.assertRaises(FetchDBError):
            self.db.fetchall(query)
    @patch('ibm_db_dbi.connect')
    def test_insert(self, mock_connect):
        # Mock the cursor and execute method
        mock_cursor = MagicMock()
        self.db.cursor = mock_cursor

        query = "INSERT INTO test_table (col1) VALUES (?)"
        params = (1,)
        self.db.insert(query, params)
        mock_cursor.execute.assert_called_with(query, params)

    @patch('ibm_db_dbi.connect')
    def test_insert_error(self, mock_connect):
        # Simulate an error during insert
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Insert failed")
        self.db.cursor = mock_cursor

        query = "INSERT INTO test_table (col1) VALUES (?)"
        params = (1,)
        with self.assertRaises(InsertDBError):
            self.db.insert(query, params)

    @patch('ibm_db_dbi.connect')
    def test_update(self, mock_connect):
        # Mock the cursor and execute method
        mock_cursor = MagicMock()
        self.db.cursor = mock_cursor

        query = CONST_TEST_UPDATE_QUERY
        params = (1, 2)
        row_count = self.db.update(query, params)
        self.assertEqual(row_count, mock_cursor.rowcount)
        mock_cursor.execute.assert_called_with(query, params)

    @patch('ibm_db_dbi.connect')
    def test_update_error(self, mock_connect):
        # Simulate an error during update
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Update failed")
        self.db.cursor = mock_cursor

        query = CONST_TEST_UPDATE_QUERY
        params = (1, 2)
        with self.assertRaises(UpdateDBError):
            self.db.update(query, params)
    @patch('ibm_db_dbi.connect')
    def test_delete(self, mock_connect):
        # Mock the cursor and execute method
        mock_cursor = MagicMock()
        self.db.cursor = mock_cursor

        query = "DELETE FROM test_table WHERE col1 = ?"
        params = (1,)
        self.db.delete(query, params)
        mock_cursor.execute.assert_called_with(query, params)

    @patch('ibm_db_dbi.connect')
    def test_delete_error(self, mock_connect):
        # Simulate an error during delete
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Delete failed")
        self.db.cursor = mock_cursor

        query = "DELETE FROM test_table WHERE col1 = ?"
        params = (1,)
        with self.assertRaises(DeleteDBError):
            self.db.delete(query, params)

    @patch('ibm_db_dbi.connect')
    def test_bulk_insert(self, mock_connect):
        # Mock the cursor and executemany method
        mock_cursor = MagicMock()
        self.db.cursor = mock_cursor

        columns = ['col1', 'col2']
        values = [(1, 'val1'), (2, 'val2')]
        self.db.bulk_insert("test_table", columns, values)
        mock_cursor.executemany.assert_called_with(
            "INSERT INTO test_table (col1, col2) VALUES (?, ?)", values)

    @patch('ibm_db_dbi.connect')
    def test_bulk_insert_error(self, mock_connect):
        # Simulate an error during bulk_insert
        mock_cursor = MagicMock()
        mock_cursor.executemany.side_effect = Exception("Bulk insert failed")
        self.db.cursor = mock_cursor

        columns = ['col1', 'col2']
        values = [(1, 'val1'), (2, 'val2')]
        with self.assertRaises(InsertDBError):
            self.db.bulk_insert("test_table", columns, values)
    @patch('ibm_db_dbi.connect')
    def test_update_many(self, mock_connect):
        # Mock the cursor and executemany method
        mock_cursor = MagicMock()
        self.db.cursor = mock_cursor

        query = CONST_TEST_UPDATE_QUERY
        params_list = [(1, 2), (3, 4)]
        row_count = self.db.update_many(query, params_list)
        self.assertEqual(row_count, mock_cursor.rowcount)
        mock_cursor.executemany.assert_called_with(query, params_list)

    @patch('ibm_db_dbi.connect')
    def test_update_many_error(self, mock_connect):
        # Simulate an error during update_many
        mock_cursor = MagicMock()
        mock_cursor.executemany.side_effect = Exception("Update many failed")
        self.db.cursor = mock_cursor

        query = CONST_TEST_UPDATE_QUERY
        params_list = [(1, 2), (3, 4)]
        with self.assertRaises(UpdateDBError):
            self.db.update_many(query, params_list)
    @patch('ibm_db_dbi.connect')
    def test_commit_db(self, mock_connect):
        # Mock the commit method
        mock_conn = MagicMock()
        self.db.conn = mock_conn
        self.db.commit_db()
        mock_conn.commit.assert_called_once()

    @patch('ibm_db_dbi.connect')
    def test_commit_db_rollback(self, mock_connect):
        # Simulate an error in commit and rollback
        mock_conn = MagicMock()
        mock_conn.commit.side_effect = Exception("Commit failed")
        self.db.conn = mock_conn
        with self.assertRaises(DatabaseError):
            self.db.commit_db()
        mock_conn.rollback.assert_called_once()

    @patch('ibm_db_dbi.connect')
    def test_close_connection(self, mock_connect):
        # Mock the close methods
        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        self.db.cursor = mock_cursor
        self.db.conn = mock_conn
        self.db.close_connection()
        mock_cursor.close.assert_called_once()
        mock_conn.close.assert_called_once()

    @patch('ibm_db_dbi.connect')
    def test_close_connection_error(self, mock_connect):
        # Simulate an error during connection closing
        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        mock_cursor.close.side_effect = Exception("Cursor close failed")
        mock_conn.close.side_effect = Exception("Connection close failed")
        self.db.cursor = mock_cursor
        self.db.conn = mock_conn
        with self.assertRaises(DatabaseError):
            self.db.close_connection()

    @patch('ibm_db_dbi.connect')
    def test_close_connection_no_connection(self, mock_connect):
        # Test the close_connection method of DB2IDatabase when no connection exists
        db = DB2IDatabase(self.logger_mock, key="db2_region")
        db.conn = None  # Explicitly setting connection to None
        db.close_connection()
        self.logger_mock.info.assert_called_with("DB Connection not created. Hence no closing is required")

    @patch('ibm_db_dbi.connect')
    def test_db2idatabase_enter(self, mock_connect):
        # Test the __enter__ method of DB2IDatabase
        db = DB2IDatabase(self.logger_mock, key="db2_region")
        self.assertEqual(db.__enter__(), db)

    @patch('ibm_db_dbi.connect')
    def test_db2idatabase_exit(self, mock_connect):
        # Test the __exit__ method of DB2IDatabase
        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        db = DB2IDatabase(self.logger_mock, key="db2_region")
        db.cursor = mock_cursor
        db.conn = mock_conn
        db.__exit__(None, None, None)
        mock_cursor.close.assert_called_once()
        mock_conn.close.assert_called_once()

    @patch('ibm_db_dbi.connect')
    def test_db2idatabase_exit_error(self, mock_connect):
        # Test the __exit__ method of DB2IDatabase with error
        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        mock_cursor.close.side_effect = Exception("Cursor close failed")
        mock_conn.close.side_effect = Exception("Connection close failed")
        db = DB2IDatabase(self.logger_mock, key="db2_region")
        db.cursor = mock_cursor
        db.conn = mock_conn
        with self.assertRaises(DatabaseError):
            db.__exit__(None, None, None)