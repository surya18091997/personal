import unittest
from unittest.mock import patch, Mock, call

import pytest

from src.integrations.gcs_utils import GCSUtils
from src.utils.errors.gcs_errors import GCSCreateFolderError, GCSCreateFileError, GCSUploadFileError, \
    GCSUploadFolderError, GCSDownloadFileError, GCSUploadChunkError, GCSResumableUploadError


class TestGCSUtils(unittest.TestCase):
    def setUp(self):
        """Setup test case"""
        self.logger = Mock()

        # Create the mock chain
        self.mock_blob = Mock()
        self.mock_bucket = Mock()
        self.mock_client = Mock()

        # Build the mock chain from bottom up
        self.mock_blob.exists = Mock(return_value=False)
        self.mock_blob.upload_from_string = Mock()

        self.mock_bucket.blob = Mock(return_value=self.mock_blob)
        self.mock_client.get_bucket = Mock(return_value=self.mock_bucket)

        # Create storage client mock
        self.mock_client_class = Mock()
        self.mock_client_class.from_service_account_json = Mock(return_value=self.mock_client)

        # Create storage mock
        self.mock_storage = Mock()
        self.mock_storage.Client = self.mock_client_class

        # Set up the patches
        self.patches = [
            patch('src.integrations.gcs_utils.storage', self.mock_storage),
            patch('src.utils.app_config.get_config_value', return_value='/mock/path/gcs_connection.json')
        ]

        # Start all patches
        for p in self.patches:
            p.start()

        # Create GCSUtils instance
        self.gcs = GCSUtils(self.logger)

        self.addCleanup(lambda: [p.stop() for p in self.patches])


    def test_create_folder(self):
        # Call the method
        self.gcs.create_folder('bucket_name', 'folder_name')

        # Assert the expected calls were made
        self.mock_client.get_bucket.assert_called_once_with('bucket_name')
        self.mock_bucket.blob.assert_called_once_with('folder_name/')
        self.mock_blob.upload_from_string.assert_called_once_with('')

    def test_create_folder_exception(self):

        # Configure the mock to simulate the expected behavior
        self.mock_client.return_value.get_bucket.return_value = self.mock_bucket
        self.mock_bucket.blob.return_value = self.mock_blob
        self.mock_blob.exists.side_effect = Exception('Error')

        # Call the method
        with self.assertRaises(GCSCreateFolderError):
            self.gcs.create_folder('bucket_name', 'folder_name')

    def test_create_file(self):
        self.gcs.create_file('bucket_name', 'folder_name', 'file_name', 'file_content')
        self.mock_client.get_bucket.assert_called_with('bucket_name')
        self.mock_bucket.blob.assert_called_with('folder_name/file_name')
        self.mock_blob.upload_from_string.assert_called_with('file_content')

    def test_create_file_exception(self):
        # Configure the mock to simulate the expected behavior
        self.mock_client.return_value.get_bucket.return_value = self.mock_bucket
        self.mock_bucket.blob.return_value = self.mock_blob
        self.mock_blob.upload_from_string.side_effect = Exception('Error')

        # Call the method
        with self.assertRaises(GCSCreateFileError):
            self.gcs.create_file('bucket_name', 'folder_name', 'file_name', 'file_content')


    def test_upload_file(self):
        self.gcs.upload_file('bucket_name', 'destination_file_path', 'source_file_path')
        self.mock_client.get_bucket.assert_called_with('bucket_name')
        self.mock_bucket.blob.assert_called_with('destination_file_path')
        self.mock_blob.upload_from_filename.assert_called_with('source_file_path')

    def test_upload_file_exception(self):
        # Configure the mock to simulate the expected behavior
        self.mock_client.return_value.get_bucket.return_value = self.mock_bucket
        self.mock_bucket.blob.return_value = self.mock_blob
        self.mock_blob.upload_from_filename.side_effect = Exception('Error')

        # Call the method
        with self.assertRaises(GCSUploadFileError):
            self.gcs.upload_file('bucket_name', 'destination_file_path', 'source_file_path')

    def test_upload_folder(self):
        with patch('os.listdir', return_value=['file1.txt', 'file2.txt']), \
             patch('os.path.isfile', return_value=True), \
             patch('os.path.join', side_effect=lambda *args: '/'.join(args)):

            self.gcs.upload_folder('bucket_name', 'destination_folder', 'path_to_folder')

            self.mock_client.get_bucket.assert_called_with('bucket_name')
            expected_blob_calls = [
                call('destination_folder/file1.txt'),
                call('destination_folder/file2.txt')
            ]
            assert self.mock_bucket.blob.call_args_list == expected_blob_calls

    def test_upload_folder_exception(self):
        self.mock_client.side_effect = Exception('Error')

        # Call the method
        with self.assertRaises(GCSUploadFolderError):
            self.gcs.upload_folder('bucket_name', 'destination_folder', 'path_to_folder')

    def test_download_file(self):
        with patch('src.utils.common_utils.create_dir_if_not_exists') as mock_create_dir:
            self.gcs.download_file('bucket_name', 'blob_name', 'destination_file_name')
            mock_create_dir.assert_called()
            self.mock_client.get_bucket.assert_called_with('bucket_name')
            self.mock_bucket.blob.assert_called_with('blob_name')
            self.mock_blob.download_to_filename.assert_called_with('destination_file_name')

    def test_download_file_exception(self):
        self.mock_blob.download_to_filename.side_effect = Exception('Error')

        with self.assertRaises(GCSDownloadFileError):
            self.gcs.download_file('bucket_name', 'blob_name', 'destination_file_name')

    def test_upload_chunk(self):
        mock_session = Mock()
        chunk = b"test data"
        offset = 0
        self.gcs.upload_chunk(mock_session, chunk, offset)
        mock_session.transmit_chunk.assert_called_with(chunk, offset)

    def test_upload_chunk_exception(self):
        mock_session = Mock()
        chunk = b"test data"
        offset = 0
        mock_session.transmit_chunk.side_effect = Exception('Error')

        with self.assertRaises(GCSUploadChunkError):
            self.gcs.upload_chunk(mock_session, chunk, offset)

    @pytest.fixture
    def mock_logger(self):
        return Mock()

    def test_create_resumable_upload_error(self):
        """Test error handling in create_resumable_upload when session creation fails"""
        # Create logger mock
        mock_logger = Mock()

        # Setup the test conditions
        mock_storage = Mock()
        mock_client = Mock()
        mock_bucket = Mock()
        mock_blob = Mock()

        # Configure mocks to raise an error
        mock_storage.Client = Mock(return_value=mock_client)
        mock_client.from_service_account_json = Mock(side_effect=Exception("GCS error"))
        mock_bucket.blob = Mock(return_value=mock_blob)

        gcs_utils = GCSUtils(mock_logger)

        # Mock Client creation
        with patch('src.integrations.gcs_utils.storage', mock_storage), \
                patch('src.integrations.gcs_utils.app_config.get_config_value', return_value='/path/to/creds.json'):
            with pytest.raises(GCSResumableUploadError) as exc_info:
                gcs_utils.create_resumable_upload("test-bucket", "test/path", chunk_size=1024)

            # Verify error was logged
            mock_logger.error.assert_called_once_with('Error creating resumable upload session: GCS error')

            # Verify correct error was raised with proper message
            assert "Error creating resumable upload session: GCS error" in str(exc_info.value)

    def test_download_single_file_content_with_prefix(self):
        # Configure the mock to simulate the expected behavior
        bucket_name = 'bucket_name'
        prefix = 'prefix'
        file_content = 'file_content'
        self.mock_client.return_value.get_bucket.return_value = self.mock_bucket
        self.mock_bucket.list_blobs.return_value = iter([self.mock_blob])
        self.mock_blob.download_as_string.return_value = file_content.encode('utf-8')

        # Call the method
        result = self.gcs.download_single_file_content_with_prefix(bucket_name, prefix)

        # Assert the expected calls were made
        self.mock_client.get_bucket.assert_called_once_with(bucket_name)
        self.mock_bucket.list_blobs.assert_called_once_with(prefix=prefix)
        self.mock_blob.download_as_string.assert_called_once()

        # Assert the result
        self.assertEqual(result, file_content)

    def test_download_single_file_content_with_prefix_no_files_found(self):
        # Configure the mock to simulate no files found
        bucket_name = 'bucket_name'
        prefix = 'prefix'
        self.mock_client.return_value.get_bucket.return_value = self.mock_bucket
        self.mock_bucket.list_blobs.return_value = iter([])

        # Call the method
        with self.assertRaises(GCSDownloadFileError):
            self.gcs.download_single_file_content_with_prefix(bucket_name, prefix)

        # Assert the expected calls were made
        self.mock_client.get_bucket.assert_called_once_with(bucket_name)
        self.mock_bucket.list_blobs.assert_called_once_with(prefix=prefix)
        