import unittest
from unittest.mock import patch, mock_open, MagicMock
from datetime import datetime, timedelta
import json
from src.integrations.cosmos_utils import CosmosUtils
from src.utils.errors.db2_errors import DatabaseError


class TestCosmosUtils(unittest.TestCase):

    def setUp(self):
        self.logger = MagicMock()

    @patch('os.path.exists')
    @patch('src.integrations.cosmos_utils.app_config.get_config_value')
    @patch('builtins.open', new_callable=mock_open)
    @patch('src.integrations.cosmos_utils.ClientSecretCredential')
    @patch('src.integrations.cosmos_utils.CosmosClient')
    def test_cosmos_utils_initialization_success(self, mock_cosmos_client, mock_credential,
                                                 mock_file_open, mock_get_config, mock_exists):
        # Setup mocks
        mock_get_config.side_effect = ['/path/to/config', 'cosmos_url']
        mock_exists.return_value = True

        # Create mock config with valid expiry dates
        future_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S.%f')
        mock_config = {
            'primary': {
                'expiryDate': future_date,
                'secText': 'primary_secret'
            },
            'secondary': {
                'expiryDate': future_date,
                'secText': 'secondary_secret'
            },
            'spnTenantId': 'tenant_id',
            'spnClientId': 'client_id'
        }

        mock_file_open().read.return_value = json.dumps(mock_config)

        # Initialize CosmosUtils
        cosmos_utils = CosmosUtils(self.logger)

        # Verify correct initialization
        mock_credential.assert_called_once_with(
            tenant_id='tenant_id',
            client_id='client_id',
            client_secret='primary_secret'
        )

        mock_cosmos_client.assert_called_once_with(
            url='cosmos_url',
            credential=mock_credential.return_value
        )

    @patch('os.path.exists')
    @patch('src.integrations.cosmos_utils.app_config.get_config_value')
    @patch('builtins.open', new_callable=mock_open)
    def test_cosmos_utils_expired_secrets(self, mock_file_open, mock_get_config, mock_exists):
        # Setup mocks
        mock_get_config.side_effect = ['/path/to/config', 'cosmos_url']
        mock_exists.return_value = True

        # Create mock config with expired dates
        past_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S.%f')
        mock_config = {
            'primary': {
                'expiryDate': past_date,
                'secText': 'primary_secret'
            },
            'secondary': {
                'expiryDate': past_date,
                'secText': 'secondary_secret'
            },
            'spnTenantId': 'tenant_id',
            'spnClientId': 'client_id'
        }

        mock_file_open().read.return_value = json.dumps(mock_config)

        # Verify exception is raised with expired secrets
        with self.assertRaises(DatabaseError):
            cosmos_utils = CosmosUtils(self.logger)

    @patch('os.path.exists')
    @patch('src.integrations.cosmos_utils.app_config.get_config_value')
    def test_cosmos_utils_config_not_found(self, mock_get_config, mock_exists):
        # Setup mocks
        mock_get_config.side_effect = ['/path/to/config', 'cosmos_url']
        mock_exists.return_value = False

        # Verify exception is raised when config file not found
        with self.assertRaises(DatabaseError):
            cosmos_utils = CosmosUtils(self.logger)

    @patch('src.integrations.cosmos_utils.CosmosUtils._get_azure_config')
    @patch('src.integrations.cosmos_utils.ClientSecretCredential')
    @patch('src.integrations.cosmos_utils.CosmosClient')
    def test_get_structured_data_success(self, mock_cosmos_client, mock_credential, mock_get_azure_config):
        # Setup mocks
        mock_get_azure_config.return_value = {
            'tenant_id': 'tenant_id',
            'client_id': 'client_id',
            'client_secret': 'client_secret',
            'cosmos_account_url': 'cosmos_url'
        }

        # Mock database and container clients
        mock_container = MagicMock()
        mock_container.query_items.return_value = [{'id': '1', 'data': 'test'}]

        mock_database = MagicMock()
        mock_database.get_container_client.return_value = mock_container

        mock_cosmos_client.return_value.get_database_client.return_value = mock_database

        # Initialize CosmosUtils and call get_structured_data
        cosmos_utils = CosmosUtils(self.logger)
        result = cosmos_utils.get_structured_data(
            'test_db',
            'test_collection',
            'c.id, c.data',
            {'where': "c.id = '1'"}
        )

        # Verify results
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['id'], '1')
        self.assertEqual(result[0]['data'], 'test')

        # Verify query was correctly formed
        mock_container.query_items.assert_called_once_with(
            query="SELECT c.id, c.data FROM c WHERE c.id = '1'",
            enable_cross_partition_query=True
        )
