import unittest
import pytest
import os
import json
import pandas as pd
from unittest.mock import patch, MagicMock, mock_open, call
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType
from src.integrations.datalake_hudi_conn import DataLakeHudiUtils
from src.utils.errors.db2_errors import DatabaseError
from src.utils.errors.gcs_errors import GCSHudiConnectionError
from src.constants import (
    DATALAKE_MAX_RETRY_COUNT, DATALAKE_RETRY_DELAY, APP_NAME, APP_CFG_HUDI_CONNECTION_KEY,
    APP_CFG_GCS_HUDI_BUCKET, APP_CFG_GCS_HUDI_DATA_PATH
)


class TestDataLakeHudiUtils(unittest.TestCase):

    def setUp(self):
        self.logger = MagicMock()

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_datalake_utils_initialization_success(self, mock_spark, mock_get_config, mock_file,
                                                                 mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)

        # Assert
        assert mock_get_config.call_count == 3
        mock_builder.appName.assert_called_once_with("HudiDataReader")
        mock_builder.master.assert_called_once_with("local[*]")
        assert mock_builder.config.call_count == 8
        assert hudi_utils.bucket_name == 'test-bucket'
        assert hudi_utils.hudi_data_path == 'test-path'

    @patch('os.path.exists', return_value=False)
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    def test_datalake_utils_initialization_fails_credentials(self, mock_get_config, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']

        # Execute & Assert
        with pytest.raises(GCSHudiConnectionError):
            DataLakeHudiUtils(self.logger)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    def test_datalake_utils_initialization_config_missing(self, mock_get_config, mock_open, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', None, 'test-path']

        # Execute & Assert
        with pytest.raises(GCSHudiConnectionError):
            DataLakeHudiUtils(self.logger)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('json.load')
    def test_datalake_utils_initialization_fails_credential_expired(self, mock_json_load, mock_get_config, mock_open,
                                                                    mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        past_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S.%f")
        mock_json_load.return_value = {'expiryDate': past_date}

        # Execute & Assert
        with pytest.raises(GCSHudiConnectionError):
            DataLakeHudiUtils(self.logger)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_read_hudi_snapshot_returns_data(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_df.count.return_value = 10
        mock_spark.return_value.read.format.return_value.load.return_value = mock_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.read_hudi_snapshot('test/table/path')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_spark.return_value.read.format.return_value.load.assert_called_with("gs://test-bucket/test/table/path")
        assert result == mock_df


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def test_read_hudi_snapshot_retries_on_failure(self, mock_sleep, mock_spark, mock_get_config,
                                                   mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_read = mock_spark.return_value.read
        mock_format = mock_read.format
        mock_format.return_value.load.side_effect = [Exception("Connection error"), MagicMock()]

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        hudi_utils.read_hudi_snapshot('test/table/path')

        # Assert
        assert mock_format.return_value.load.call_count == 2
        mock_sleep.assert_called_once_with(DATALAKE_RETRY_DELAY)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def test_read_hudi_snapshot_error_after_max_retries(self, mock_sleep, mock_spark, mock_get_config, mock_file,
                                                          mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_read = mock_spark.return_value.read
        mock_format = mock_read.format
        mock_format.return_value.load.side_effect = Exception("Connection error")

        # Execute & Assert
        hudi_utils = DataLakeHudiUtils(self.logger)
        with pytest.raises(DatabaseError):
            hudi_utils.read_hudi_snapshot('test/table/path')

        assert mock_format.return_value.load.call_count == DATALAKE_MAX_RETRY_COUNT
        assert mock_sleep.call_count == DATALAKE_MAX_RETRY_COUNT - 1


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_read_hudi_incremental_uses_correct_options(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_df.count.return_value = 5
        mock_option = MagicMock()
        mock_option.option.return_value = mock_option
        mock_option.load.return_value = mock_df
        mock_spark.return_value.read.format.return_value = mock_option

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.read_hudi_incremental('test/table/path', '20230101000000')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_option.option.assert_any_call("hoodie.datasource.query.type", "incremental")
        mock_option.option.assert_any_call("hoodie.datasource.read.begin.instanttime", "20230101000000")
        mock_option.load.assert_called_with("gs://test-bucket/test/table/path")
        assert result == mock_df


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_read_hudi_point_in_time_uses_correct_options(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_df.count.return_value = 7
        mock_option = MagicMock()
        mock_option.option.return_value = mock_option
        mock_option.load.return_value = mock_df
        mock_spark.return_value.read.format.return_value = mock_option

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.read_hudi_point_in_time('test/table/path', '20230101000000')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_option.option.assert_called_once_with("as.of.instant", "20230101000000")
        mock_option.load.assert_called_with("gs://test-bucket/test/table/path")
        assert result == mock_df

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_get_hudi_data_executes_sql_query_correctly(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side.effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_spark_df = MagicMock()
        mock_spark.return_value.read.format.return_value.load.return_value = mock_df
        mock_spark.return_value.sql.return_value = mock_spark_df

        # Mock pandas DataFrame
        mock_pandas_df = pd.DataFrame({'id': [1, 2], 'name': ['test1', 'test2']})
        mock_spark_df.toPandas.return_value = mock_pandas_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_data('test_table', 'id, name', 'id > 0')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_df.createOrReplaceTempView.assert_called_once_with("hudi_table_data")
        mock_spark.return_value.sql.assert_called_once_with("SELECT id, name FROM hudi_table_data WHERE id > 0")
        mock_spark_df.toPandas.assert_called_once()
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def test_get_hudi_data_retries_on_failure(self, mock_sleep, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_spark_df = MagicMock()
        mock_spark.return_value.read.format.return_value.load.side_effect = [Exception("Connection error"), mock_df]
        mock_spark.return_value.sql.return_value = mock_spark_df

        # Mock pandas DataFrame
        mock_pandas_df = pd.DataFrame({'id': [1, 2], 'name': ['test1', 'test2']})
        mock_spark_df.toPandas.return_value = mock_pandas_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_data('test_table', 'id, name', 'id > 0')

        # Assert
        assert mock_spark.return_value.read.format.return_value.load.call_count == 2
        mock_sleep.assert_called_once_with(DATALAKE_RETRY_DELAY)
        assert isinstance(result, pd.DataFrame)

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def test_get_hudi_data_error_after_max_retries(self, mock_sleep, mock_spark, mock_get_config,
                                                   mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_read = mock_spark.return_value.read
        mock_format = mock_read.format
        mock_format.return_value.load.side_effect = Exception("Connection error")

        # Execute & Assert
        hudi_utils = DataLakeHudiUtils(self.logger)
        with pytest.raises(DatabaseError):
            hudi_utils.get_hudi_data('test_table', 'id, name', 'id > 0')

        assert mock_format.return_value.load.call_count == DATALAKE_MAX_RETRY_COUNT
        assert mock_sleep.call_count == DATALAKE_MAX_RETRY_COUNT - 1


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_get_hudi_data_with_empty_results(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_spark_df = MagicMock()
        mock_spark.return_value.read.format.return_value.load.return_value = mock_df
        mock_spark.return_value.sql.return_value = mock_spark_df

        # Mock empty pandas DataFrame
        mock_pandas_df = pd.DataFrame()
        mock_spark_df.toPandas.return_value = mock_pandas_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_data('test_table', 'id, name', 'id > 0')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_df.createOrReplaceTempView.assert_called_once_with("hudi_table_data")
        mock_spark.return_value.sql.assert_called_once_with("SELECT id, name FROM hudi_table_data WHERE id > 0")
        mock_spark_df.toPandas.assert_called_once()
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_get_hudi_data_with_complex_query(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_spark_df = MagicMock()
        mock_spark.return_value.read.format.return_value.load.return_value = mock_df
        mock_spark.return_value.sql.return_value = mock_spark_df

        # Mock pandas DataFrame
        mock_pandas_df = pd.DataFrame({
            'id': [1, 2, 3],
            'name': ['test1', 'test2', 'test3'],
            'value': [100, 200, 300]
        })
        mock_spark_df.toPandas.return_value = mock_pandas_df

        # Execute with complex WHERE clause
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_data(
            'test_table',
            'id, name, value, (value/100) as ratio',
            'id > 0 AND name LIKE "test%" AND value BETWEEN 100 AND 300'
        )

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_df.createOrReplaceTempView.assert_called_once_with("hudi_table_data")
        mock_spark.return_value.sql.assert_called_once_with(
            'SELECT id, name, value, (value/100) as ratio FROM hudi_table_data WHERE id > 0 AND name LIKE "test%" AND value BETWEEN 100 AND 300'
        )
        mock_spark_df.toPandas.assert_called_once()
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def test_get_hudi_data_constructs_correct_table_path(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'custom/data/path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_spark_df = MagicMock()
        mock_spark.return_value.read.format.return_value.load.return_value = mock_df
        mock_spark.return_value.sql.return_value = mock_spark_df
        mock_spark_df.toPandas.return_value = pd.DataFrame({'id': [1]})

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        hudi_utils.get_hudi_data('specific_table', 'id', 'id = 1')

        # Assert
        expected_path = "gs://test-bucket/custom/data/path/specific_table"
        mock_spark.return_value.read.format.return_value.load.assert_called_with(expected_path)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def get_hudi_table_schema_returns_correct_schema(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_schema = StructType([
            StructField("id", StringType(), True),
            StructField("name", StringType(), True)
        ])
        mock_df.schema = mock_schema
        mock_spark.return_value.read.format.return_value.load.return_value.limit.return_value = mock_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_table_schema('test/table/path')

        # Assert
        mock_spark.return_value.read.format.assert_called_with("hudi")
        mock_spark.return_value.read.format.return_value.load.return_value.limit.assert_called_with(1)
        assert result == mock_schema


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def get_hudi_table_schema_retries_on_failure(self, mock_sleep, mock_spark, mock_get_config,
                                                 mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_schema = StructType([StructField("id", StringType(), True)])
        mock_df.schema = mock_schema

        mock_read = mock_spark.return_value.read
        mock_format = mock_read.format
        mock_format.return_value.load.side_effect = [Exception("Connection error"),
                                                     MagicMock(limit=lambda x: mock_df)]

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        result = hudi_utils.get_hudi_table_schema('test/table/path')

        # Assert
        assert mock_format.return_value.load.call_count == 2
        mock_sleep.assert_called_once_with(DATALAKE_RETRY_DELAY)
        assert result == mock_schema


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    @patch('time.sleep')
    def get_hudi_table_schema_error_after_max_retries(self, mock_sleep, mock_spark, mock_get_config,
                                                      mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_read = mock_spark.return_value.read
        mock_format = mock_read.format
        mock_format.return_value.load.side_effect = Exception("Connection error")

        # Execute & Assert
        hudi_utils = DataLakeHudiUtils(self.logger)
        with pytest.raises(DatabaseError):
            hudi_utils.get_hudi_table_schema('test/table/path')

        assert mock_format.return_value.load.call_count == DATALAKE_MAX_RETRY_COUNT
        assert mock_sleep.call_count == DATALAKE_MAX_RETRY_COUNT - 1


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def get_hudi_table_schema_constructs_correct_path(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'custom-bucket', 'custom/path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        mock_df = MagicMock()
        mock_schema = StructType([StructField("id", StringType(), True)])
        mock_df.schema = mock_schema
        mock_spark.return_value.read.format.return_value.load.return_value.limit.return_value = mock_df

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        hudi_utils.get_hudi_table_schema('specific/table/path')

        # Assert
        expected_path = "gs://custom-bucket/specific/table/path"
        mock_spark.return_value.read.format.return_value.load.assert_called_with(expected_path)


    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data='{"key": "value"}')
    @patch('src.integrations.datalake_hudi_conn.app_config.get_config_value')
    @patch('src.integrations.datalake_hudi_conn.SparkSession')
    def close_stops_spark_session_when_initialized(self, mock_spark, mock_get_config, mock_file, mock_exists):
        # Setup
        mock_get_config.side_effect = ['/path/to/credentials.json', 'test-bucket', 'test-path']
        mock_builder = mock_spark.builder
        mock_builder.appName.return_value = mock_builder
        mock_builder.master.return_value = mock_builder
        mock_builder.config.return_value = mock_builder
        mock_builder.getOrCreate.return_value = mock_spark.return_value

        # Execute
        hudi_utils = DataLakeHudiUtils(self.logger)
        hudi_utils.close()

        # Assert
        mock_spark.return_value.stop.assert_called_once()