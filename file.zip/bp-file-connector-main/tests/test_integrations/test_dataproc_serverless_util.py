from unittest.mock import MagicMock

import pytest
from google.api_core import operation

from src.integrations.dataproc_serverless_util import DataprocServerlessUtil
from tests.conftest import MockOperation, MockDataprocJob


def test_dataproc_serverless_util_init():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    assert util.project_id == "test-project"
    assert util.region == "us-central1"
    assert util.logger == logger
    assert util.parent == "projects/test-project/locations/us-central1"


def test_dataproc_serverless_util_submit_batch_pyspark_success():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    # Create a new mock operation instance
    mock_operation = MockOperation.Operation()
    mock_operation._done = True  # Set done to True
    mock_result = MockDataprocJob()
    mock_result.state.name = "SUCCEEDED"
    mock_operation._operation = mock_result

    # Set the return value for create_batch
    util.batch_client.create_batch.return_value = mock_operation
    util.get_batch_status = MagicMock(return_value={"state": "SUCCEEDED"})

    result = util.submit_batch(
        batch_id="test-batch",
        main_python_file_uri="gs://bucket/main.py",
        args=["arg1", "arg2"],
        runtime_version="1.2",
        service_account="sa@project.iam",
        properties={"spark.executor.memory": "4g"},
        timeout_minutes=5
    )

    util.batch_client.create_batch.assert_called_once()


def test_dataproc_serverless_util_submit_batch_spark_success():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    mock_operation = MagicMock(spec=operation.Operation)
    mock_operation.done.return_value = True
    mock_operation.cancelled.return_value = False
    mock_result = MagicMock()
    mock_result.state.name = "SUCCEEDED"
    mock_operation.result.return_value = mock_result

    util.batch_client.create_batch.return_value = mock_operation
    util.get_batch_status = MagicMock(return_value={"state": "SUCCEEDED"})

    result = util.submit_batch(
        batch_id="test-batch",
        main_jar_file_uri="gs://bucket/main.jar",
        main_class="com.example.Main",
        jar_file_uris=["gs://bucket/lib.jar"],
        timeout_minutes=5
    )

    util.batch_client.create_batch.assert_called_once()
    assert mock_operation.result.called


def test_dataproc_serverless_util_submit_batch_failure():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    util.get_batch_status = MagicMock(return_value={"state": "FAILED"})
    mock_operation = MagicMock(spec=operation.Operation)
    mock_operation.done.return_value = False
    util.batch_client.create_batch.return_value = mock_operation

    with pytest.raises(RuntimeError) as exc_info:
        util.submit_batch(
            batch_id="test-batch",
            main_python_file_uri="gs://bucket/main.py",
            timeout_minutes=5
        )
    assert "cancelled" in str(exc_info.value)


def test_dataproc_serverless_util_submit_batch_timeout():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    mock_operation = MagicMock(spec=operation.Operation)
    mock_operation.done.return_value = False
    mock_operation.cancelled.return_value = False
    util.batch_client.create_batch.return_value = mock_operation
    util.get_batch_status = MagicMock(return_value={"state": "RUNNING"})

    with pytest.raises(TimeoutError) as exc_info:
        util.submit_batch(
            batch_id="test-batch",
            main_python_file_uri="gs://bucket/main.py",
            timeout_minutes=0
        )
    assert "timed out" in str(exc_info.value)


def test_get_batch_status_success():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    mock_batch = MagicMock()
    mock_batch.state.name = "RUNNING"
    mock_batch.create_time = "2024-01-01T00:00:00Z"
    mock_batch.uuid = "test-uuid"

    util.batch_client.get_batch.return_value = mock_batch

    status = util.get_batch_status("test-batch")

    assert status["state"] == "RUNNING"
    assert status["create_time"] == "2024-01-01T00:00:00Z"
    assert status["uuid"] == "test-uuid"


def test_get_batch_status_failure():
    logger = MagicMock()
    util = DataprocServerlessUtil("test-project", "us-central1", logger)

    util.batch_client.get_batch.side_effect = Exception("Failed to get status")

    with pytest.raises(Exception) as exc_info:
        util.get_batch_status("test-batch")
    assert "Failed to get status" in str(exc_info.value)