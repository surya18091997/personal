# tests/test_file_connector/test_file_transfer.py

import unittest
from unittest.mock import Mock, patch, mock_open, MagicMock
from src.file_connector.file_transfer import file_transfer
from src.utils.errors.app_errors import ApplicationErrorMessage
from src.utils.errors.gcs_errors import GCSUploadChunkError
from src.constants import (
    CHUNK_GCS_UPLOAD_PROGRESS,
    CHUNK_GCS_UPLOAD,
    CHUNK_GCS_UPLOAD_COMPLETED
)

class TestFileTransfer(unittest.TestCase):
    def setUp(self):
        self.logger_mock = Mock()
        self.file_transfer_instance = file_transfer(self.logger_mock)
        self.bucket_name = "test-bucket"
        self.source_folder = "/source"
        self.dest_folder = "/dest"
        self.file_name = "test.txt"
        self.source_path = f"{self.source_folder}/{self.file_name}"
        self.dest_path = f"{self.dest_folder}/{self.file_name}"

        # Common mocks
        self.mock_gcs = Mock()
        self.mock_session = Mock()
        self.mock_session.transmit_chunk = Mock()
        self.mock_gcs.create_resumable_upload = Mock(return_value=self.mock_session)
        self.file_transfer_instance.gcs_connection = self.mock_gcs

    def test_transfer_file_to_gcs_success(self):
        """Test successful file transfer to GCS"""
        self.file_transfer_instance.transfer_file_to_gcs(
            self.bucket_name,
            self.source_folder,
            self.dest_folder,
            self.file_name
        )
        self.mock_gcs.upload_file.assert_called_once()

    @patch('builtins.open', new_callable=mock_open, read_data=b'test data')
    @patch('os.path.getsize', return_value=1024)
    @patch('time.sleep')  # To avoid actual delays in retries
    def test_transfer_file_to_gcs_in_chunks_success(self, mock_sleep, mock_getsize, mock_file):
        """Test successful chunked upload to GCS"""
        self.mock_session.transmit_chunk.return_value = None

        self.file_transfer_instance._transfer_file_to_gcs_in_chunks(
            self.bucket_name,
            self.source_path,
            self.dest_path
        )

        # Verify the correct calls were made
        self.mock_session.transmit_chunk.assert_called()
        self.logger_mock.info.assert_any_call(CHUNK_GCS_UPLOAD)
        self.logger_mock.info.assert_any_call(CHUNK_GCS_UPLOAD_COMPLETED)

    @patch('builtins.open', new_callable=mock_open, read_data=b'test data')
    @patch('os.path.getsize', return_value=1024)
    @patch('time.sleep')
    def test_transfer_file_to_gcs_in_chunks_retry_success(self, mock_sleep, mock_getsize, mock_file):
        """Test chunked upload with retry success"""
        self.mock_session.transmit_chunk.side_effect = [
            Exception("First attempt fails"),
            None  # Second attempt succeeds
        ]

        self.file_transfer_instance._transfer_file_to_gcs_in_chunks(
            self.bucket_name,
            self.source_path,
            self.dest_path
        )

        self.assertEqual(self.mock_session.transmit_chunk.call_count, 2)
        self.logger_mock.warning.assert_called_once()