import pytest
from unittest import mock
from src.utils.errors.db2_errors import DatabaseError
from src.integrations.bigquery_conn import BigQueryDatabase


class TestBigQueryDatabase:

    @pytest.fixture(scope='function')
    def mock_get_config_value(self):
        with mock.patch('src.utils.app_config.get_config_value') as mock_config:
            mock_config.return_value = '/mock/path/to/creds.json'
            yield mock_config

    @pytest.fixture
    def mock_bigquery_client(self):
        with mock.patch('google.cloud.bigquery.Client') as mock_client:
            yield mock_client

    @pytest.fixture
    def mock_logger(self):
        return mock.Mock()

    def test_initialization_missing_credentials(self, mock_logger):
        with mock.patch('src.utils.app_config.get_config_value', return_value=None):
            with pytest.raises(DatabaseError):
                BigQueryDatabase(mock_logger)
            mock_logger.error.assert_called_with("Error while getting to BigQuery Credential JSON file path")

    def test_execute_query(self, mock_logger, mock_get_config_value, mock_bigquery_client):
        db = BigQueryDatabase(mock_logger)
        mock_query = "SELECT * FROM dataset.table"
        mock_job = mock.Mock()
        db.client.query.return_value = mock_job
        result = db.execute(mock_query)
        db.client.query.assert_called_once_with(mock_query)
        assert result == mock_job

    def test_get_arr_from_sing_sel_query(self, mock_logger, mock_get_config_value, mock_bigquery_client):
        db = BigQueryDatabase(mock_logger)
        db.execute = mock.Mock()
        mock_query = "SELECT id FROM dataset.table"
        mock_job = mock.Mock()
        mock_job.result.return_value = [(1,), (2,), (3,)]
        db.execute.return_value = mock_job
        result = db.get_arr_from_sing_sel_query(mock_query)
        assert result == [1, 2, 3]

    def test_get_df_from_query(self, mock_logger, mock_get_config_value, mock_bigquery_client):
        db = BigQueryDatabase(mock_logger)
        db.execute = mock.Mock()
        mock_query = "SELECT id, name FROM dataset.table"
        mock_job = mock.Mock()
        mock_job.result.return_value = [{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}]
        db.execute.return_value = mock_job
        result_df = db.get_df_from_query(mock_query)
        import pandas as pd
        expected_df = pd.DataFrame(data=[{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}])
        pd.testing.assert_frame_equal(result_df, expected_df)

    def test_execute_with_query_kwargs(self, mock_logger, mock_get_config_value, mock_bigquery_client):
        db = BigQueryDatabase(mock_logger)
        mock_query = "SELECT * FROM dataset.table WHERE id = {id}"
        mock_query_kwargs = {"id": 1}
        mock_job = mock.Mock()
        db.client.query.return_value = mock_job
        result = db.execute(mock_query, mock_query_kwargs)
        db.client.query.assert_any_call("SELECT * FROM dataset.table WHERE id = 1")
        assert result == mock_job
