import unittest
from unittest.mock import patch, MagicMock

import src.utils.app_config as app_config
import os
import logging

from src.utils import logging_helper

class TestYourModule(unittest.TestCase):

    @patch.object(app_config, 'get_config_value')
    @patch.object(os, 'makedirs')
    def test_get_working_directory(self, mock_makedirs, mock_get_config_value):
        mock_get_config_value.return_value = '/tmp'
        result = logging_helper.get_working_directory()
        self.assertEqual(result, '/tmp')
        mock_get_config_value.assert_called_once_with("app", "working_dir")
        mock_makedirs.assert_called_once_with('/tmp', exist_ok=True)

    @patch.object(app_config, 'get_config_value')
    @patch.object(os, 'makedirs')
    @patch.object(os.path, 'join')
    @patch.object(logging, 'getLogger')
    @patch.object(logging, 'FileHandler')
    @patch.object(logging, 'StreamHandler')
    @patch.object(logging_helper, 'get_working_directory')
    def test_setup_request_logger(self, mock_get_working_directory, mock_stream_handler, mock_file_handler, mock_get_logger,
                                  mock_os_path_join, mock_makedirs, mock_get_config_value):
        mock_get_config_value.side_effect = ['INFO', '%(asctime)s - %(name)s - %(levelname)s - %(message)s']
        mock_get_logger.return_value = MagicMock()
        mock_get_working_directory.return_value = '/tmp'
        mock_os_path_join.return_value = '/tmp/id'
        mock_file_handler.return_value = MagicMock()
        mock_stream_handler.return_value = MagicMock()
        result = logging_helper.setup_request_logger('id')
        self.assertEqual(result, mock_get_logger.return_value)
        mock_get_config_value.assert_any_call("app", "log_level")
        mock_get_config_value.assert_any_call("app", "log_format")
        mock_get_logger.assert_called_once_with('id')
        mock_get_working_directory.assert_called_once()
        mock_os_path_join.assert_any_call('/tmp', 'id')
        mock_makedirs.assert_called_once_with('/tmp/id', exist_ok=True)


if __name__ == '__main__':
    unittest.main()