import csv
from unittest.mock import patch
import pytest
from unittest import mock
import pandas as pd
import re

from src.constants import F_ERROR
from src.utils.common_utils import create_dir_if_not_exists, write_list_to_file, write_dataframe_to_file, \
    read_file_to_dataframe, record_request_id, generate_request_id, update_request_status, create_json_response
from src.utils.errors.app_errors import ApplicationError, CreateJsonResponseError

CONST_BUILTINS_OPEN = "builtins.open"
CONST_TEST_DATAFRAME = "test_dataframe.csv"

class TestCommonUtils:

    @pytest.fixture
    def mock_logger(self):
        """Mock the logger for testing."""
        return mock.Mock()

    def test_create_dir_if_not_exists(self, mock_logger):
        dir_name = "test_directory"

        # Test when directory does not exist
        with mock.patch("os.path.exists", return_value=False), mock.patch("os.makedirs"):
            result = create_dir_if_not_exists(dir_name, mock_logger)
            assert result == 1
            mock_logger.info.assert_called_with(f"Directory {dir_name} created")

        # Test when directory exists
        with mock.patch("os.path.exists", return_value=True), mock.patch("os.makedirs"):
            result = create_dir_if_not_exists(dir_name, mock_logger)
            assert result == 0
            mock_logger.info.assert_called_with(f"Directory {dir_name} exists already")

    # Test for write_list_to_file
    def test_write_list_to_file(self, mock_logger):
        file_path = "test_file.txt"
        content = ["Hello", "World"]

        # Test file writing
        with mock.patch(CONST_BUILTINS_OPEN, mock.mock_open()) as mocked_file:
            mock_file_object = mocked_file.return_value
            write_list_to_file(file_path, content, mock_logger)
            mocked_file.assert_called_once_with(file_path, 'w')
            mock_file_object.write.assert_called_once_with("Hello,World\n")
            mock_logger.info.assert_called_with(f"File {file_path} created successfully")

    # Test for write_dataframe_to_file
    def test_write_dataframe_to_file(self, mock_logger):
        file_path = CONST_TEST_DATAFRAME
        data = {'name': ['Alice', 'Bob'], 'age': [25, 30]}
        df = pd.DataFrame(data)

        # Test file writing
        with mock.patch("pandas.DataFrame.to_csv") as mocked_to_csv:
            write_dataframe_to_file(file_path, df, mock_logger)
            mocked_to_csv.assert_called_once_with(file_path, index=False, quoting=csv.QUOTE_NONNUMERIC)
            mock_logger.info.assert_called_with(f"File {file_path} created successfully")

    # Test for read_file_to_dataframe
    def test_read_file_to_dataframe(self, mock_logger):
        file_path = CONST_TEST_DATAFRAME
        data = {'name': ['Alice', 'Bob'], 'age': [25.0, 30.0]}
        expected_df = pd.DataFrame(data)

        # Mock pandas.read_csv instead of open
        with mock.patch("pandas.read_csv", return_value=expected_df) as mocked_read_csv:
            df = read_file_to_dataframe(file_path, mock_logger)
            mocked_read_csv.assert_called_once_with(file_path, quoting=csv.QUOTE_NONNUMERIC)
            pd.testing.assert_frame_equal(df, expected_df)
            mock_logger.info.assert_called_with(f"File {file_path} loaded successfully")

    # Test for read_file_to_dataframe with error case
    def test_read_file_to_dataframe_with_error(self, mock_logger):
        file_path = CONST_TEST_DATAFRAME

        # Simulate an error when loading file using pandas.read_csv
        with mock.patch("pandas.read_csv", side_effect=Exception("File not found")):
            with pytest.raises(Exception):
                read_file_to_dataframe(file_path, mock_logger)
            mock_logger.error.assert_called_with(f"Error occurred while loading file {file_path}: File not found")

    @patch("src.utils.common_utils.PostgresGCPConnection")
    @patch("src.utils.common_utils.json.dumps", return_value="{}")
    def test_record_request_id(self, mock_json, mock_db, mock_logger):
        request_id = "request_1"
        request_body = mock_json
        module = "test_module"
        # Mock database connection
        mock_conn = mock_db.return_value.__enter__.return_value

        # Test request recording
        record_request_id(request_id, request_body, module, mock_logger)
        mock_db.assert_called_once()
        mock_conn.execute_nonquery.assert_called()
        mock_conn.commit.assert_called_once()
        mock_logger.info.assert_called_with("Request ID: request_1 recorded successfully in DB")

    @patch("src.utils.common_utils.PostgresGCPConnection")
    def test_record_request_id_with_error(self, mock_db, mock_logger):
        request_id = "request_1"
        request_body = {"configurationId": "config_1"}
        module = "test_module"
        # Simulate an error when executing database query
        mock_db.return_value.__enter__.return_value.execute_nonquery.side_effect = Exception("Database error")

        with pytest.raises(ApplicationError):
            record_request_id(request_id, request_body, module, mock_logger)
        mock_logger.error.assert_called()

    def test_generate_request_id(self):
        request_id = generate_request_id()
        # Check if the request_id is not None
        assert request_id is not None
        # Check if the request_id is of type string
        assert isinstance(request_id, str)
        # Check if the request_id matches the pattern of a UUID
        pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I)
        match = pattern.match(request_id)
        assert match is not None

    @patch('src.utils.common_utils.PostgresGCPConnection')
    def test_update_request_status_exception(self, mock_conn, mock_logger):
        # Set up the mock to raise an exception when execute_query is called
        mock_conn.return_value.__enter__.return_value.execute_query.side_effect = Exception('Test exception')

        with pytest.raises(ApplicationError):
            update_request_status('test_request_id', 'test_status', mock_logger)

        # Verify that the error log was called with the correct message
        mock_logger.error.assert_called_once_with('Error initializing request and generate ID: Test exception')

    @patch('src.utils.common_utils.jsonify', side_effect=Exception('Test exception'))
    def test_create_json_response_exception(self, mock_jsonify):
        # This test will pass if CreateJsonResponseError is raised
        with pytest.raises(CreateJsonResponseError):
            create_json_response('test_request_id', 'test_message', 'test_code')

    @patch('src.utils.common_utils.PostgresGCPConnection')
    def test_update_request_status_already_in_error_state(self, mock_db_connection, mock_logger):
        request_id = 1
        status = F_ERROR
        error_message = 'Some error'

        # Mock the execute_query method to return F_ERROR status
        mock_conn = mock_db_connection.return_value.__enter__.return_value
        mock_conn.execute_query.return_value = [(status,)]

        # Call the method
        update_request_status(request_id, status, mock_logger, error_message)

        # Verify logger.info was called with the expected message
        mock_logger.info.assert_called_once_with(f"Request {request_id} already in error state, skipping status update")

        # Verify execute_nonquery was never called since status was already F_ERROR
        mock_conn.execute_nonquery.assert_not_called()
