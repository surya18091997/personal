import json
from unittest.mock import patch, mock_open, MagicMock
from src.utils.app_config import (
    load_all_config_to_cache,
    load_config_to_cache,
    get_config_value,
    start_watcher,
    FileModifiedHandler,
    cache
)

#common constants
OS_PATH = "os.path.exists"
MOCK_APP_JSON_PATH = "/fake/path/application.json"
MODULE_APP_LOGGING_ERROR = "src.utils.app_config.logging.error"

class TestAppConfig:
    mock_app_config = {
        "configResolution": {
            "resolved": {
                "key1": "value1",
                "key2": "value2"
            }
        }
    }
    mock_flow_config = {
        "configResolution": {
            "resolved": {
                "flow1": "config1",
                "flow2": "config2"
            }
        }
    }
    mock_file_layout = {
        "configResolution": {
            "resolved": {
                "layout1": "layout_config1"
            }
        }
    }


    def setup_method(self):
        """Clear cache before each test."""
        cache.clear()

    @patch("builtins.open", new_callable=mock_open, read_data=json.dumps(mock_app_config))
    def test_load_config_to_cache(self, mock_file):
        config_name = "app"
        config_file = "/mock/path/application.json"

        with patch(OS_PATH, return_value=True):
            load_config_to_cache(config_name, config_file)

        assert cache["appkey1"] == "value1"
        assert cache["appkey2"] == "value2"
        mock_file.assert_called_once_with(config_file, 'r')

    @patch("builtins.open", side_effect=[mock_open(read_data=json.dumps(mock_app_config)).return_value,
                                         mock_open(read_data=json.dumps(mock_flow_config)).return_value,
                                         mock_open(read_data=json.dumps(mock_file_layout)).return_value])
    def test_load_all_config_to_cache(self, mock_file):
        with patch(OS_PATH, return_value=True):
            load_all_config_to_cache()

        assert cache["appkey2"] == "value2"
        assert cache["flow_configflow1"] == "config1"
        assert cache["file_layoutlayout1"] == "layout_config1"


    @patch("builtins.open", new_callable=mock_open, read_data=json.dumps(mock_app_config))
    def test_get_config_value(self, mock_file):
        with patch(OS_PATH, return_value=True):
            load_all_config_to_cache()
            value = get_config_value("app", "key1")

        assert value == "value1"
        mock_file.assert_called()

    @patch("os.path.isdir", return_value=True)
    @patch("src.utils.app_config.Observer")
    def test_start_watcher(self, mock_observer, mock_isdir):
        mock_event_handler = MagicMock()
        with patch("src.utils.app_config.FileModifiedHandler", return_value=mock_event_handler):
            start_watcher()

        mock_observer.return_value.schedule.assert_called_once_with(mock_event_handler, path="/etc/config", recursive=False)
        mock_observer.return_value.start.assert_called_once()

    @patch("builtins.open", new_callable=mock_open, read_data=json.dumps(mock_app_config))
    def test_file_modified_handler(self, mock_file):
        handler = FileModifiedHandler()

        with patch(OS_PATH, return_value=True):
            handler.on_modified(None)

        assert "appkey1" in cache
        assert cache["appkey1"] == "value1"

    @patch("builtins.open", new_callable=mock_open, read_data="invalid json")
    def test_load_config_to_cache_invalid_json(self, mock_file):
        config_name = "app"
        config_file = MOCK_APP_JSON_PATH

        with patch(OS_PATH, return_value=True):
            with patch(MODULE_APP_LOGGING_ERROR) as mock_log:
                load_config_to_cache(config_name, config_file)
                mock_log.assert_called_once_with(
                    f"Invalid JSON in configuration file: {config_file} and exception Expecting value: line 1 column 1 (char 0)"
                )

    @patch("builtins.open", side_effect=FileNotFoundError("File not found"))
    def test_load_config_to_cache_file_not_found(self, mock_file):
        config_name = "app"
        config_file = MOCK_APP_JSON_PATH

        with patch(MODULE_APP_LOGGING_ERROR) as mock_log:
            load_config_to_cache(config_name, config_file)
            mock_log.assert_called_with(
                f"Configuration file not found: {config_file} and exception File not found"
            )

    @patch("builtins.open", new_callable=mock_open, read_data=json.dumps(mock_app_config))
    def test_load_config_to_cache_exception(self, mock_file):
        """Test for any generic exception during loading configuration."""
        config_name = "app"
        config_file = MOCK_APP_JSON_PATH

        # Simulate an exception being raised
        with patch(MODULE_APP_LOGGING_ERROR) as mock_log:
            with patch("builtins.open", side_effect=Exception("Unexpected error")):
                load_config_to_cache(config_name, config_file)
                mock_log.assert_called_once_with("Error loading configuration: Unexpected error")

    def test_get_config_value_missing_key(self):
        with patch(OS_PATH, return_value=True):
            load_all_config_to_cache()
            value = get_config_value("app", "missing_key")
        assert value is None

