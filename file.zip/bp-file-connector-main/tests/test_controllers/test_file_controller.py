import unittest
from unittest.mock import patch, Mock, MagicMock
from flask import Flask
import logging
import datetime
from src.constants import LOAD_FILE, LOAD_REQUEST_ACCEPTED, GENERATE_FILE, TRANSFER_FILE, TRANSFER_REQUEST_ACCEPTED, \
    GENERATE_REQUEST_ACCEPTED, ERROR_FILE_PARSE, ERROR_FILE_GENERATE, ERROR_FILE_TRANSFER, REQUEST_ERROR_MESSAGE, \
    INVALID_REQUEST, F_COMPLETED, F_ERROR, FILE_LOAD_STARTED, FILE_GEN_STARTED, FILE_TRANSFER_STARTED, \
    FILE_TRANSFER_COMPLETED, FILE_GEN_COMPLETED, FILE_LOAD_COMPLETED, ERROR_FILE_GEN_PROCESS, ERROR_FILE_PARSE_PROCESS, \
    ERROR_FILE_TRANSFER_PROCESS, MISSING_CONFIGURATION, INVALID_CONFIGURATION_ID, FLOW_CONFIG_ELIGIBLE_WAGES, \
    RUN_DATE_VALIDATION, START_DT_GT_END_DT, FROM_AND_TO_DATE_VALIDATION
from http import HTTPStatus
from src.controllers.file_controller import get_accept_message, get_accept_error_message, \
    print_error_message, process_file, run_file_process, get_start_message, get_completion_message, \
    get_process_error_message, validate_request, validate_and_parse_dates, create_request_logger, \
    update_request_and_handle_error, load_file, transfer_file, generate_file
from src.utils.errors.app_errors import ApplicationErrorMessage
from tests.conftest import mock_module_structure

# Create Flask test app
app = Flask('bp_file_connector')


class FlaskTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()
        self.ctx = self.app.test_request_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()


class TestFileController(FlaskTestCase):
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()

        # Create logger mock
        self.mock_logger = Mock(spec=logging.Logger)
        self.mock_logger.info = Mock()
        self.mock_logger.error = Mock()
        self.mock_logger.warning = Mock()
        self.mock_logger.debug = Mock()

        # Create patches with their mock names
        self.patch_mapping = {
            'executor': patch('src.controllers.file_controller.executor'),
            'generate_request_id': patch('src.controllers.file_controller.generate_request_id',
                                         return_value="test-request-id"),
            'validate_request': patch('src.controllers.file_controller.validate_request'),
            'validate_and_parse_dates': patch('src.controllers.file_controller.validate_and_parse_dates'),
            'run_file_process': patch('src.controllers.file_controller.run_file_process'),
            'app_config': patch('src.controllers.file_controller.app_config'),
            'FileProcessorFactory': patch('src.controllers.file_controller.FileProcessorFactory'),
            'update_request_and_handle_error': patch('src.controllers.file_controller.update_request_and_handle_error'),
            'create_json_response': patch('src.controllers.file_controller.create_json_response'),
            'print_error_message': patch('src.controllers.file_controller.print_error_message'),
            'get_accept_error_message': patch('src.controllers.file_controller.get_accept_error_message'),
            'get_start_message': patch('src.controllers.file_controller.get_start_message'),
            'get_completion_message': patch('src.controllers.file_controller.get_completion_message'),
            'get_process_error_message': patch('src.controllers.file_controller.get_process_error_message'),
            'request': patch('flask.request')
        }

        # Create record_request_patch
        self.record_request_patch = patch('src.controllers.file_controller.record_request_id')
        self.mock_record_request = self.record_request_patch.start()

        # Start all patches and store mocks
        self.mocks = {}
        self.patches = []  # Keep this for backward compatibility
        for name, patcher in self.patch_mapping.items():
            self.mocks[name] = patcher.start()
            self.patches.append(patcher)

    def tearDown(self):
        """Clean up after each test."""
        for patcher in self.patch_mapping.values():
            patcher.stop()
        self.record_request_patch.stop()
        super().tearDown()

    def test_get_start_message_load_file(self):
        self.assertEqual(get_start_message(LOAD_FILE), FILE_LOAD_STARTED)

    def test_get_start_message_generate_file(self):
        self.assertEqual(get_start_message(GENERATE_FILE), FILE_GEN_STARTED)

    def test_get_start_message_transfer_file(self):
        self.assertEqual(get_start_message(TRANSFER_FILE), FILE_TRANSFER_STARTED)

    def test_get_start_message_invalid(self):
        with self.assertRaises(ValueError):
            get_start_message('INVALID')

    def test_get_completion_message_load_file(self):
        self.assertEqual(get_completion_message(LOAD_FILE), FILE_LOAD_COMPLETED)

    def test_get_completion_message_generate_file(self):
        self.assertEqual(get_completion_message(GENERATE_FILE), FILE_GEN_COMPLETED)

    def test_get_completion_message_transfer_file(self):
        self.assertEqual(get_completion_message(TRANSFER_FILE), FILE_TRANSFER_COMPLETED)

    def test_get_completion_message_invalid_process_type(self):
        with self.assertRaises(ValueError):
            get_completion_message('INVALID_PROCESS_TYPE')

    def test_get_process_error_message_load_file(self):
        self.assertEqual(get_process_error_message(LOAD_FILE), ERROR_FILE_PARSE_PROCESS)

    def test_get_process_error_message_generate_file(self):
        self.assertEqual(get_process_error_message(GENERATE_FILE), ERROR_FILE_GEN_PROCESS)

    def test_get_process_error_message_transfer_file(self):
        self.assertEqual(get_process_error_message(TRANSFER_FILE), ERROR_FILE_TRANSFER_PROCESS)

    def test_get_process_error_message_invalid_process(self):
        with self.assertRaises(ValueError):
            get_process_error_message("invalid_process_type")

    def test_get_accept_message_load_file(self):
        self.assertEqual(get_accept_message(LOAD_FILE), LOAD_REQUEST_ACCEPTED)

    def test_get_accept_message_generate_file(self):
        self.assertEqual(get_accept_message(GENERATE_FILE), GENERATE_REQUEST_ACCEPTED)

    def test_get_accept_message_transfer_file(self):
        self.assertEqual(get_accept_message(TRANSFER_FILE), TRANSFER_REQUEST_ACCEPTED)

    def test_get_accept_message_invalid_process(self):
        with self.assertRaises(ValueError):
            get_accept_message("invalid_process_type")

    def test_get_accept_error_message_load_file(self):
        self.assertEqual(get_accept_error_message(LOAD_FILE), ERROR_FILE_PARSE)

    def test_get_accept_error_message_generate_file(self):
        self.assertEqual(get_accept_error_message(GENERATE_FILE), ERROR_FILE_GENERATE)

    def test_get_accept_error_message_transfer_file(self):
        self.assertEqual(get_accept_error_message(TRANSFER_FILE), ERROR_FILE_TRANSFER)

    def test_get_accept_error_message_invalid_process(self):
        with self.assertRaises(ValueError):
            get_accept_error_message("invalid_process_type")

    def test_print_error_message(self):
        with patch('builtins.print') as mock_print:
            print_error_message('test-request-id', 'test-error-message')
            mock_print.assert_called_once_with(REQUEST_ERROR_MESSAGE.format(
                request_id='test-request-id', error_message='test-error-message'))

    def test_validate_request(self):
        """Tests configuration ID validation in requests"""
        # Case 1: No configuration ID
        data = {}
        error_message, config_id, start_date, end_date = validate_request(data, self.mock_logger, '')
        self.assertEqual(error_message, MISSING_CONFIGURATION)
        self.assertIsNone(config_id)
        self.assertIsNone(start_date)
        self.assertIsNone(end_date)

    @patch('src.controllers.file_controller.create_request_logger', new_callable=Mock)
    @patch('src.controllers.file_controller.request.get_json', new_callable=Mock)
    def test_invalid_process_file_request(self, mock_get_json, mock_create_request_logger):
        # Test case: Invalid request
        mock_get_json.return_value = None
        mock_create_request_logger.return_value = ('request_id', 'logger')
        self.mocks['validate_request'].return_value = ("error_message", 1, "2024-01-01", "2024-01-31")

        response = process_file('process_type')

        self.mocks['print_error_message'].assert_called_once_with('request_id', 'error_message')
        self.mocks['create_json_response'].assert_called_once_with('request_id', INVALID_REQUEST, HTTPStatus.BAD_REQUEST)
        self.assertEqual(response, self.mocks['create_json_response'].return_value)


    @patch('src.controllers.file_controller.create_request_logger')
    def test_process_file_exception_handling(self, mock_create_request_logger):
        # Test case: Exception handling
        mock_create_request_logger.side_effect = Exception('error_message')
        self.mocks['get_accept_error_message'].return_value = 'error_message'

        response = process_file('process_type')

        self.mocks['update_request_and_handle_error'].assert_called_once_with(None, None,
                                                                              'error_message',
                                                                              HTTPStatus.INTERNAL_SERVER_ERROR)
        self.assertIsNone(response)

    @patch('src.controllers.file_controller.update_request_status')
    def test_run_file_process_success(self, mock_update):
        mock_processor = Mock()
        self.mocks['FileProcessorFactory'].create_processor.return_value = mock_processor

        run_file_process('config_id', self.mock_logger, 'request_id',
                         'start_date', 'end_date', 'process_type', {})

        self.mocks['FileProcessorFactory'].create_processor.assert_called_once_with(
            'config_id', self.mock_logger, 'request_id', 'start_date', 'end_date', {})
        mock_processor.start_process.assert_called_once()
        mock_update.assert_called_once_with('request_id', F_COMPLETED, self.mock_logger)

    @patch('src.controllers.file_controller.update_request_status')
    def test_run_file_process_exception(self, mock_update):
        mock_processor = Mock()
        mock_processor.start_process.side_effect = Exception('Test exception')
        self.mocks['FileProcessorFactory'].create_processor.return_value = mock_processor

        run_file_process('config_id', self.mock_logger, 'request_id',
                         'start_date', 'end_date', 'process_type', {})

        self.mock_logger.error.assert_called()
        mock_update.assert_called_once_with('request_id', F_ERROR, self.mock_logger, 'Test exception')


    def test_validate_request_no_config_id(self):
        self.data = {}
        error_message, config_id, start_date, end_date = validate_request(self.data, self.mock_logger, '')
        self.assertEqual(error_message, MISSING_CONFIGURATION)
        self.assertIsNone(config_id)
        self.assertIsNone(start_date)
        self.assertIsNone(end_date)

    def test_validate_request_invalid_config_id(self):
        self.mocks['app_config'].get_config_value.return_value = ''
        self.data = {'configurationId': '123'}
        error_message, config_id, start_date, end_date = validate_request(self.data, self.mock_logger, '')
        self.assertEqual(error_message, INVALID_CONFIGURATION_ID.format(configuration_id='123'))
        self.assertEqual(config_id, '123')
        self.assertIsNone(start_date)
        self.assertIsNone(end_date)

    def test_validate_request_valid_config_id(self):
        self.mocks['app_config'].get_config_value.return_value = {"some": "config"}
        self.data = {'configurationId': '123'}
        error_message, config_id, start_date, end_date = validate_request(self.data, self.mock_logger, '')
        self.assertEqual(error_message, '')
        self.assertEqual(config_id, '123')
        self.assertIsNone(start_date)
        self.assertIsNone(end_date)

    def test_validate_request_generate_file_process_type(self):
        self.patches[3].stop() # Stop patching validate_and_parse_dates
        self.process_type = GENERATE_FILE
        self.data = {
            "configurationId": 1,
            "fromDate": "2024-01-01",
            "toDate": "2024-01-31"
        }
        self.mocks['app_config'].get_config_value.return_value = {"some": "config"}
        error_message, config_id, start_date, end_date = validate_request(self.data, self.mock_logger, GENERATE_FILE)
        self.assertEqual(error_message, '')
        self.assertEqual(config_id, 1)
        self.assertIsNotNone(start_date)
        self.assertIsNotNone(end_date)

    def test_validate_request_exception_raised(self):
        self.mocks['app_config'].get_config_value = Mock(side_effect=Exception('Test exception'))
        self.data = {'configurationId': '123'}
        error_message, config_id, start_date, end_date = validate_request(self.data, self.mock_logger, '')
        self.assertEqual(error_message, '')
        self.assertEqual(config_id, '123')
        self.assertIsNone(start_date)
        self.assertIsNone(end_date)
        self.mock_logger.error.assert_called_with(INVALID_CONFIGURATION_ID.format(configuration_id='Test exception'))

    # def test_validate_and_parse_dates_flow_config_run_date_present(self):
    #     self.patches[3].stop()  # Stop patching validate_and_parse_dates
    #     data = {'runDate': '2019-12-31'}
    #     configuration_id = FLOW_CONFIG_ELIGIBLE_WAGES
    #     errors = []
    #     start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
    #     self.assertEqual(start_date, datetime.datetime(2019, 12, 31))
    #     self.assertEqual(end_date, '2019-12-31')
    #     self.assertEqual(errors, [])

    # def test_validate_and_parse_dates_flow_config_run_date_not_present(self):
    #     self.patches[3].stop()  # Stop patching validate_and_parse_dates
    #     data = {}
    #     configuration_id = FLOW_CONFIG_ELIGIBLE_WAGES
    #     errors = []
    #     start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
    #     self.assertEqual(start_date, None)
    #     self.assertEqual(end_date, None)
    #     self.assertEqual(errors, [RUN_DATE_VALIDATION])

    def test_validate_and_parse_dates_start_end_date_valid(self):
        self.patches[3].stop()  # Stop patching validate_and_parse_dates
        data = {'fromDate': '2019-12-01', 'toDate': '2019-12-31'}
        configuration_id = 'some_other_config'
        errors = []
        start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
        self.assertEqual(start_date, datetime.datetime(2019, 12, 1))
        self.assertEqual(end_date, datetime.datetime(2019, 12, 31))
        self.assertEqual(errors, [])

    # def test_validate_and_parse_dates_start_date_greater_than_end_date(self, run_date=None):
    #     self.patches[3].stop()  # Stop patching validate_and_parse_dates
    #     data = {'fromDate': '2019-12-31', 'toDate': '2019-12-01', 'runDate': '2019-12-01'}
    #     configuration_id = 'some_other_config'
    #     errors = []
    #     start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
    #     self.assertEqual(start_date, datetime.datetime(2019, 12, 31))
    #     self.assertEqual(end_date, datetime.datetime(2019, 12, 1))
    #     self.assertEqual(run_date, datetime.datetime(2019, 12, 1))
    #     self.assertEqual(errors, [START_DT_GT_END_DT.format(start_date=start_date, end_date=end_date)])

    # def test_validate_and_parse_dates_one_date_missing(self):
    #     self.patches[3].stop()  # Stop patching validate_and_parse_dates
    #     data = {'fromDate': '2019-12-31'}
    #     configuration_id = 'some_other_config'
    #     errors = []
    #     start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
    #     self.assertEqual(start_date,'2019-12-31')
    #     self.assertIsNone(end_date)
    #     self.assertEqual(errors, [FROM_AND_TO_DATE_VALIDATION])

    def test_validate_and_parse_dates_invalid_date_format(self):
        self.patches[3].stop()  # Stop patching validate_and_parse_dates
        data = {'fromDate': '31-12-2019', 'toDate': '01-12-2019'}
        configuration_id = 'some_other_config'
        errors = []
        start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)
        self.assertIsNotNone(errors)

    @patch("src.controllers.file_controller.setup_request_logger")
    @patch("src.controllers.file_controller.END_POINT_ACCESSED")
    @patch("src.controllers.file_controller.ERROR_IN_LOG_CREATION")
    def test_create_request_logger(self, mock_error_msg, mock_end_point, mock_setup_logger):
        mock_request = MagicMock()
        mock_request.get_json.return_value = {"key": "value"}

        mock_setup_logger.return_value = self.mock_logger
        request_id, logger = create_request_logger(mock_request, "test_func")

        self.assertEqual(request_id, "test-request-id")
        self.assertEqual(logger, self.mock_logger)
        self.mock_logger.info.assert_called_once_with(
            mock_end_point.format(func_name="test_func", request_id="test-request-id", request_body={"key": "value"})
        )

    @patch("src.controllers.file_controller.setup_request_logger")
    @patch("src.controllers.file_controller.END_POINT_ACCESSED")
    @patch("src.controllers.file_controller.ERROR_IN_LOG_CREATION")
    def test_create_request_logger_exception(self, mock_error_msg, mock_end_point, mock_setup_logger):
        mock_request = MagicMock()
        mock_request.get_json.side_effect = Exception("Error")

        with self.assertRaises(ApplicationErrorMessage):
            create_request_logger(mock_request, "test_func")

        mock_error_msg.format.assert_called_with(request_id="test-request-id", error_message="Error")

    @patch('src.controllers.file_controller.update_request_status')
    def test_update_request_and_handle_error(self, mock_update_request_status):
        request_id = '123'
        error_message = 'Error'
        status_code = HTTPStatus.BAD_REQUEST

        self.mocks['create_json_response'].return_value = 'mock response'

        response = update_request_and_handle_error(request_id, self.mock_logger, error_message, status_code)

        mock_update_request_status.assert_called_once_with(request_id, F_ERROR, self.mock_logger, error_message)
        self.assertEqual(response, 'mock response')

    @patch('src.controllers.file_controller.update_request_status')
    def test_update_request_and_handle_error_without_logger(self, mock_update_request_status):
        self.patches[7].stop()  # Stop patching update_request_and_handle_error
        # Test case 1: Normal flow with logger
        request_id = '123'
        error_message = 'Error'
        status_code = HTTPStatus.BAD_REQUEST

        self.mocks['create_json_response'].return_value = 'mock response'
        mock_update_request_status.return_value = None

        response = update_request_and_handle_error(request_id, None, error_message, status_code)
        self.assertEqual(response, 'mock response')

    @patch('src.controllers.file_controller.update_request_status')
    def test_update_request_and_handle_error_exception_flow(self, mock_update_request_status):
        self.patches[7].stop()  # Stop patching update_request_and_handle_error
        # Test case 1: Normal flow with logger
        request_id = '123'
        error_message = 'Error'
        status_code = HTTPStatus.BAD_REQUEST

        self.mocks['create_json_response'].return_value = 'mock response'
        mock_update_request_status.side_effect = Exception('test exception')

        response = update_request_and_handle_error(request_id, self.mock_logger(), error_message, status_code)

        self.mocks['create_json_response'].assert_called_with(request_id, error_message, HTTPStatus.INTERNAL_SERVER_ERROR)
        self.assertEqual(response, 'mock response')

    @patch('src.controllers.file_controller.process_file')
    def test_load_file(self, mock_process_file):
        # Arrange
        mock_process_file.return_value = 'file parsed'

        # Act
        result = load_file()

        # Assert
        self.assertEqual(result, 'file parsed')
        mock_process_file.assert_called_once_with(LOAD_FILE)

    @patch('src.controllers.file_controller.process_file')
    def test_generate_file(self, mock_process_file):
        # Arrange
        mock_process_file.return_value = 'file generated'

        # Act
        result = generate_file()

        # Assert
        self.assertEqual(result, 'file generated')
        mock_process_file.assert_called_once_with(GENERATE_FILE)

    @patch('src.controllers.file_controller.process_file')
    def test_transfer_file(self, mock_process_file):
        # Arrange
        mock_process_file.return_value = 'file transferred'

        # Act
        result = transfer_file()

        # Assert
        self.assertEqual(result, 'file transferred')
        mock_process_file.assert_called_once_with(TRANSFER_FILE)


if __name__ == '__main__':
    unittest.main()