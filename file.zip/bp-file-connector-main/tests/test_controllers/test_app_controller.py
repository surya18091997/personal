from flask import Flask
import unittest
from unittest.mock import patch
from src.controllers.app_controller import app_health, app_metrics

class TestApp(unittest.TestCase):

    def setUp(self):
        self.app = Flask(__name__)
        self.app.route('/health', methods=['GET'])(app_health)
        self.app.route('/metrics', methods=['GET'])(app_metrics)
        self.client = self.app.test_client()

    def test_app_health(self):
        response = self.client.get('/health')
        self.assertEqual(response.status_code, 200)
        json_response = response.get_json()[0]  # Get first element since it returns a list
        self.assertEqual(json_response, {
            'request_id': 'Health Check',
            'status': 'service up and running'
        })

    def test_app_metrics(self):
        with patch('prometheus_client.generate_latest') as mock_metrics:
            mock_metrics.return_value = b'prometheus_client_info{version="0.9.0"} 1.0'
            response = self.client.get('/metrics')
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.get_json()[0], {
                'request_id': 'Metrics',
                'status': 'prometheus_client_info{version="0.9.0"} 1.0'
            })