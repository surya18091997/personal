import unittest
import logging
from unittest.mock import Mock, patch
from src.file_processor_factory.file_processor_factory import FileProcessorFactory

class MockFileGenerator:
    """
    Mock implementation of FileProcessor for testing.
    Purpose:
    - Simulates file generation operations
    - Provides controlled test environment
    - Enables verification of file handling logic
    Attributes:
        configuration_id (str): Unique identifier for config
        logger (Mock): Logging utility mock
        request_id (str): Request tracking ID
        start_date (datetime): Processing period start
        end_date (datetime): Processing period end
    Methods:
        create_working_directory: Simulates directory creation
        format_time: Utility for time string formatting
    """

    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        self.configuration_id = configuration_id
        self.logger = logger
        self.request_id = request_id
        self.start_date = start_date
        self.end_date = end_date
        self.request_id_dir = "/test/path"
        self.dest_file = "test_file.csv"
        self.gcp_connection = Mock()
        self.cosmos_connection = Mock()
        self.db2_connection = Mock()
        self.bucket_name = "test-bucket"
        self.destination_folder = "test/path"

class TestFileProcessorFactory(unittest.TestCase):
    @patch('src.generate_file.file_generator.FileGenerator', MockFileGenerator)
    @patch('src.integrations.db2_conn_helper.DB2IDatabase')
    def setUp(self, mock_db2):

        # Create logger mock
        self.mock_logger = Mock(spec=logging.Logger)
        self.mock_logger.info = Mock()
        self.mock_logger.error = Mock()
        self.mock_logger.warning = Mock()
        self.mock_logger.debug = Mock()

        self.request_id = '1234'
        self.start_date = '2022-01-01'
        self.end_date = '2022-12-31'

    def create_processor(self, configuration_id):
        return FileProcessorFactory.create_processor(configuration_id, self.mock_logger, self.request_id,
                                                     self.start_date, self.end_date)

    def test_create_processor_generator_map(self):
        mock_config_id = 1
        FileProcessorFactory._generator_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_loader_map(self):
        mock_config_id = 31
        FileProcessorFactory._loader_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_run_date_map(self):
        mock_config_id = 21
        FileProcessorFactory._run_date_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_invalid_config_id(self):
        mock_config_id = 0
        with self.assertRaises(ValueError):
            self.create_processor(mock_config_id)

    def test_create_processor_string_config_id(self):
        mock_config_id = 'StateTransfer'
        FileProcessorFactory._generator_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_generator_map_hardship_us(self):
        mock_config_id = 41
        FileProcessorFactory._generator_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_generator_map_hardship_pr(self):
        mock_config_id = 42
        FileProcessorFactory._generator_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))

    def test_create_processor_generator_map_contribution_us(self):
        mock_config_id = 43
        FileProcessorFactory._run_date_map = {mock_config_id: Mock()}
        result = self.create_processor(mock_config_id)
        self.mock_logger.debug.assert_called()
        self.assertTrue(isinstance(result, Mock))


if __name__ == '__main__':
    unittest.main()