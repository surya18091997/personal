import unittest
from unittest.mock import MagicMock, patch
from src.disability.hri_file_generator.hri_file_generator_biweekly import HRIFileGeneratorBiweekly
from src.disability.hri_file_generator.constants import HRI_FILE_LAYOUT
from src.constants import F_COMPLETED, F_ERROR

class TestHRIFileGeneratorBiweekly(unittest.TestCase):

    def setUp(self):
        mock_logger = MagicMock()
        mock_logger.info = MagicMock()
        mock_logger.error = MagicMock()

        with patch.object(HRIFileGeneratorBiweekly, '__init__', lambda x, *args, **kwargs: None):
            self.instance = HRIFileGeneratorBiweekly(
                configuration_id="config001",
                logger=mock_logger,
                request_id="req_123",
                start_date="2024-01-01",
                end_date="2024-01-31"
            )

        # Patch FileGenerator methods
        self.instance.request_id = "req_123"
        self.instance.logger = mock_logger
        self.instance.create_working_directory = MagicMock()
        self.instance.get_file_from_mainframe = MagicMock()
        self.instance.transfer_file_to_gcs = MagicMock()
        self.instance.get_spark_output = MagicMock()
        self.instance.get_spark_output.return_value = {
            "a" : [],
            "b" : []
        }
        self.instance.initiate_flat_file_generation = MagicMock()
    
    
    @patch("src.disability.hri_file_generator.hri_file_generator_biweekly.update_request_status")  
    def test_start_process_success(self, update_request_status):
        self.instance.start_process()
        
        self.instance.create_working_directory.assert_called_once_with(self.instance.request_id)
        self.instance.get_spark_output.assert_called_once()
        self.instance.initiate_flat_file_generation.assert_called_once_with({
            "a" : [],
            "b" : []
        }, file_layout=HRI_FILE_LAYOUT, max_line_length=1000)
        self.instance.transfer_file_to_gcs.assert_called_once()
        update_request_status.assert_called_once_with(self.instance.request_id, F_COMPLETED, self.instance.logger)
        
    @patch("src.disability.hri_file_generator.hri_file_generator_biweekly.update_request_status")  
    def test_start_process_failure(self, update_request_status):
        self.instance.get_spark_output.side_effect = Exception("Path not found")
        with self.assertRaises(Exception):
            self.instance.start_process()
        self.instance.create_working_directory.assert_called_once_with(self.instance.request_id)
        update_request_status.assert_called_once_with(self.instance.request_id, F_ERROR, self.instance.logger, "Path not found")
        self.instance.logger.error.assert_called()
        