import unittest
from unittest.mock import MagicMock, patch
from src.constants import F_COMPLETED, F_ERROR
from src.disability.hri_file_generator.get_hri_pre_dependencies import FetchHRIPreDependencies

class TestFetchHRIPreDependencies(unittest.TestCase):

    def setUp(self):
        mock_logger = MagicMock()
        mock_logger.info = MagicMock()
        mock_logger.error = MagicMock()

        with patch.object(FetchHRIPreDependencies, '__init__', lambda x, *args, **kwargs: None):
            self.instance = FetchHRIPreDependencies(
                configuration_id="config001",
                logger=mock_logger,
                request_id="req_123",
                start_date="2024-01-01",
                end_date="2024-01-31"
            )

        # Patch FileGenerator methods
        self.instance.request_id = "req_123"
        self.instance.logger = mock_logger
        self.instance.create_working_directory = MagicMock()
        self.instance.get_file_from_mainframe = MagicMock()
        self.instance.transfer_file_to_gcs = MagicMock()

    @patch("src.disability.hri_file_generator.get_hri_pre_dependencies.update_request_status")
    def test_start_process_success(self, mock_update_status):
        # Run the process
        self.instance.start_process()

        # Assert all steps called
        self.instance.create_working_directory.assert_called_once_with(self.instance.request_id)
        self.instance.get_file_from_mainframe.assert_called_once()
        self.instance.transfer_file_to_gcs.assert_called_once()

        # Assert success status update
        mock_update_status.assert_called_with(self.instance.request_id, F_COMPLETED, self.instance.logger)

        # Logger calls
        self.instance.logger.info.assert_any_call("Initiated HRI fetch pre requisites.")
        self.instance.logger.info.assert_any_call("HRI pre req file transfer process completed")

    @patch("src.disability.hri_file_generator.get_hri_pre_dependencies.update_request_status")
    def test_start_process_failure(self, mock_update_status):
        # Simulate failure in get_file_from_mainframe
        self.instance.get_file_from_mainframe.side_effect = Exception("Mainframe error")

        with self.assertRaises(Exception):
            self.instance.start_process()

        # Assert working directory was created
        self.instance.create_working_directory.assert_called_once_with(self.instance.request_id)

        # Assert failure status update
        mock_update_status.assert_called_with(
            self.instance.request_id, F_ERROR, self.instance.logger, "Mainframe error"
        )

        self.instance.logger.error.assert_called()
