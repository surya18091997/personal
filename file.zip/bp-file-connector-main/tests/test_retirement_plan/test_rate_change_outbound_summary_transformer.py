import unittest
from unittest.mock import patch, MagicMock, mock_open
from datetime import datetime
import pandas as pd

from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.rate_change_outbound_summary_transformer import RateChangeOutboundSummaryTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.rate_change_outbound_summary_data_object import RateChangeOutboundSummaryDataObject


class TestRateChangeOutboundSummaryTransformer(unittest.TestCase):
    """Test cases for the RateChangeOutboundSummaryTransformer class."""

    @patch('src.report_generator.transformer.BigQueryDatabase')
    @patch('src.report_generator.transformer.SparkSession')
    def setUp(self, mock_spark, mock_bigquery):
        """Set up test fixtures."""
        self.logger = MagicMock()
        self.config_us = TransformerConfig(
            output_file_name="test_rate_change_outbound_summary_us.txt",
            page_size=60,
            report_id="PS719701US"
        )
        self.config_pr = TransformerConfig(
            output_file_name="test_rate_change_outbound_summary_pr.txt",
            page_size=60,
            report_id="PS719701PR"
        )
        # Configure mock BigQueryDatabase
        mock_bigquery_instance = MagicMock()
        mock_bigquery.return_value = mock_bigquery_instance
        
        # Configure mock SparkSession
        mock_spark_instance = MagicMock()
        mock_spark.builder.appName.return_value.config.return_value.getOrCreate.return_value = mock_spark_instance
        
        # Create transformers for both US and PR reports
        self.transformer_us = RateChangeOutboundSummaryTransformer(self.config_us, ReportType.US, self.logger)
        self.transformer_pr = RateChangeOutboundSummaryTransformer(self.config_pr, ReportType.PR, self.logger)

    def test_initialization(self):
        """Test proper initialization of the transformer with different report types."""
        # Test US configuration
        self.assertEqual(self.transformer_us.report_id, "PS719701US")
        self.assertEqual(self.transformer_us.report_name, "SAVINGS RATE RECORD SENT TO MERRILL LYNCH FOR UNITED STATES")
        
        # Test PR configuration
        self.assertEqual(self.transformer_pr.report_id, "PS719701PR")
        self.assertEqual(self.transformer_pr.report_name, "SAVING RATE FILE RECORD SENT TO MERRILL LYNCH FOR PUERTO RICO")
        
        # Test configurations dictionary
        self.assertEqual(self.transformer_us.configs[ReportType.US]['report_id'], "PS719701US")
        self.assertEqual(self.transformer_pr.configs[ReportType.PR]['report_id'], "PS719701PR")
        
    def test_header(self):
        """Test the _header method creates a properly formatted header."""
        # Test US header
        header_us = self.transformer_us._header(1)
        
        # Verify header fields
        self.assertEqual(header_us.report_number, "PS719701US")
        self.assertEqual(header_us.page_no, "1")
        self.assertEqual(header_us.report_name, "SAVINGS RATE RECORD SENT TO MERRILL LYNCH FOR UNITED STATES")
        
        # Test PR header
        header_pr = self.transformer_pr._header(2)
        
        # Verify header fields
        self.assertEqual(header_pr.report_number, "PS719701PR")
        self.assertEqual(header_pr.page_no, "2")
        self.assertEqual(header_pr.report_name, "SAVING RATE FILE RECORD SENT TO MERRILL LYNCH FOR PUERTO RICO")
        
    def test_dynamic_trailer_and_trailer(self):
        """Test the _dynamic_trailer and _trailer methods both return None."""
        # Both methods should return None for this transformer
        self.assertIsNone(self.transformer_us._dynamic_trailer([]))
        self.assertIsNone(self.transformer_us._trailer())
        
    def test_identifier(self):
        """Test the identifier method returns the correct identifier."""
        self.assertEqual(self.transformer_us.identifier(), "rate_change_compare")
        self.assertEqual(self.transformer_pr.identifier(), "rate_change_compare")

    @patch('pandas.read_csv')
    def test_transform_us(self, mock_read_csv):
        """Test the _transform method for US report type."""
        # Mock the CSV read operations
        mock_type01_df = pd.DataFrame([1, 2, 3, 4, 5])  # 5 records
        mock_type02_df = pd.DataFrame([1, 2])  # 2 records
        mock_read_csv.side_effect = [mock_type01_df, mock_type02_df]
        
        # Execute transform
        results = self.transformer_us._transform()
        
        # Verify results
        self.assertEqual(len(results), 1)
        summary = results[0]
        
        # Check record counts
        self.assertEqual(summary.header_count, 1)
        self.assertEqual(summary.trailer_count, 1)
        self.assertEqual(summary.record_type_01, 5)
        self.assertEqual(summary.record_type_02, 2)
        self.assertEqual(summary.record_type_05, 0)
        self.assertEqual(summary.record_type_08, 0)
        self.assertEqual(summary.record_type_10, 0)
        self.assertEqual(summary.record_type_62, 0)
        self.assertEqual(summary.total_count, 9)  # 1 + 1 + 5 + 2 = 9
        
        # Verify correct CSV files were accessed
        mock_read_csv.assert_any_call(self.transformer_us.configs[ReportType.US]['type01'], header=None)
        mock_read_csv.assert_any_call(self.transformer_us.configs[ReportType.US]['type02'], header=None)

    @patch('pandas.read_csv')
    def test_transform_pr(self, mock_read_csv):
        """Test the _transform method for PR report type."""
        # Mock the CSV read operations
        mock_type01_df = pd.DataFrame([1, 2, 3])  # 3 records
        mock_type02_df = pd.DataFrame([1, 2, 3, 4])  # 4 records
        mock_read_csv.side_effect = [mock_type01_df, mock_type02_df]
        
        # Execute transform
        results = self.transformer_pr._transform()
        
        # Verify results
        self.assertEqual(len(results), 1)
        summary = results[0]
        
        # Check record counts
        self.assertEqual(summary.header_count, 1)
        self.assertEqual(summary.trailer_count, 1)
        self.assertEqual(summary.record_type_01, 3)
        self.assertEqual(summary.record_type_02, 4)
        self.assertEqual(summary.record_type_05, 0)
        self.assertEqual(summary.record_type_08, 0)
        self.assertEqual(summary.record_type_10, 0)
        self.assertEqual(summary.record_type_62, 0)
        self.assertEqual(summary.total_count, 9)  # 1 + 1 + 3 + 4 = 9
        
        # Verify correct CSV files were accessed
        mock_read_csv.assert_any_call(self.transformer_pr.configs[ReportType.PR]['type01'], header=None)
        mock_read_csv.assert_any_call(self.transformer_pr.configs[ReportType.PR]['type02'], header=None)
        
    def test_data_object_to_dict(self):
        """Test the RateChangeOutboundSummaryDataObject to_dict method formats numbers correctly."""
        # Create a test data object
        data_obj = RateChangeOutboundSummaryDataObject(
            header_count=1,
            trailer_count=1,
            record_type_01=1000,
            record_type_02=2000,
            record_type_05=0,
            record_type_08=0,
            record_type_10=0,
            record_type_62=0,
            total_count=3002
        )
        
        # Get dictionary representation
        result_dict = data_obj.to_dict()
        
        # Verify number formatting
        self.assertEqual(result_dict["header_count"], "1")
        self.assertEqual(result_dict["record_type_01"], "1,000")
        self.assertEqual(result_dict["record_type_02"], "2,000")
        self.assertEqual(result_dict["total_count"], "3,002")


if __name__ == '__main__':
    unittest.main()
