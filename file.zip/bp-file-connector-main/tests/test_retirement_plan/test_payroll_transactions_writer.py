from datetime import datetime, timedelta

import pytest
from unittest.mock import MagicMock, patch
import pandas as pd
import pytz

from src.constants import CREATION_CODE_RTMS, TRANSACTION_CODE, CORPORATION_CODE, COMPANY_CODE, CREATION_CODE_P787
from src.retirement_plan.payroll_transactions_writer import PayrollTransactionsWriter

class TestPayrollTransactionsWriter:
    @pytest.fixture(autouse=True)
    def setup(self, mocker):
        logger = MagicMock()
        self.configuration_id = 31
        self.request_id = 'test_request'
        self.writer = PayrollTransactionsWriter(self.configuration_id, logger, self.request_id)
        self.writer.cwd = '/test'
        self.writer.source_file_path = 'test_path'
        self.writer.db2_region = 'test_region'
        self.writer.output_table_name = 'test_table'
        self.writer.gcs_util = MagicMock()

    # Initialization Tests
    def test_initialization(self):
        assert self.writer.reference_output_file_name == "MSA_TRANSACTIONS_insertions.csv"

    # File Flow Configuration Tests
    @patch("src.utils.app_config.get_config_value")
    def test_set_file_flow_config_parameters_success(self, mock_get_config_value):
        mock_get_config_value.return_value = {
            "flow_name": "test_flow",
            "source_file_path": "test_path",
            "bucket_name": "test_bucket",
            "output_table_name": "test_table"
        }
        self.writer.set_file_flow_config_parameters(31)
        assert self.writer.flow_name == "test_flow"
        assert self.writer.source_file_path == "test_path"
        assert self.writer.bucket_name == "test_bucket"

    @patch("src.utils.app_config.get_config_value", side_effect=Exception("Config error"))
    def test_set_file_flow_config_parameters_failure(self, mock_get_config_value):
        with pytest.raises(Exception):
            self.writer.set_file_flow_config_parameters(31)

    @patch('src.integrations.gcs_utils.GCSUtils.download_file')
    @patch('src.retirement_plan.payroll_transactions_writer.read_file_to_dataframe')
    @patch('src.retirement_plan.payroll_transactions_writer.write_dataframe_to_file')
    @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.fetch_win_ssn_mapping')
    @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.insert_to_msa_transactions_table')
    @patch('pandas.merge')
    @patch('src.utils.common_utils.write_dataframe_to_file')  # patch the write_dataframe_to_file method
    @patch('pytz.timezone', return_value=pytz.UTC)
    def test_perform_file_load_success(self, mock_tz, mock_write_df, mock_merge, mock_insert,
                                       mock_fetch_ssn, mock_write, mock_read, mock_download):
        """Test the happy path of perform_file_load()"""
        # Mock behavior for file download, reading, and database insertion
        mock_read.return_value = MagicMock()  # Mock the dataframe returned from reading the file
        mock_fetch_ssn.return_value = MagicMock()  # Mock WIN-SSN mapping dataframe
        mock_insert.return_value = None  # Mock successful insert

        mock_merge.return_value = MagicMock()  # Mock the result of pd.merge()
        mock_write_df.return_value = None  # Mock the result of write_dataframe_to_file()

        # Call the method under test
        self.writer.start_process()

        # Assertions
        self.writer.gcs_util.download_file.assert_called_once()  # Verify that the download method is called
        mock_read.assert_called_once()  # Verify the file is read into a dataframe
        mock_fetch_ssn.assert_called_once()  # Verify WIN-SSN mapping is fetched
        # mock_insert.assert_called_once()  # Verify that the records are inserted

    @patch('src.integrations.gcs_utils.GCSUtils.download_file')
    @patch('src.retirement_plan.payroll_transactions_writer.read_file_to_dataframe')
    @patch('src.retirement_plan.payroll_transactions_writer.write_dataframe_to_file')
    @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.fetch_win_ssn_mapping')
    @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.insert_to_msa_transactions_table')
    def test_perform_file_load_invalid_file_format(self, mock_insert, mock_fetch_ssn, mock_write, mock_read,
                                                   mock_download):
        """Test when the file format is invalid and raises an exception"""
        # Mock download and invalid file reading
        mock_download.return_value = None
        mock_read.side_effect = Exception("Invalid file format")

        with pytest.raises(Exception):
            self.writer.start_process()
        mock_insert.assert_not_called()

    # @patch('src.retirement_plan.payroll_transactions_writer.read_file_to_dataframe')
    # @patch('src.retirement_plan.payroll_transactions_writer.write_dataframe_to_file')
    # @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.fetch_win_ssn_mapping')
    # @patch('src.retirement_plan.payroll_transactions_writer.PayrollTransactionsWriter.insert_to_msa_transactions_table')
    # @patch('pandas.merge')
    # @patch('pytz.timezone', return_value=pytz.UTC)
    # def test_perform_file_load_insert_failure(self, mock_tz, mock_merge, mock_insert,
    #                                           mock_fetch_ssn, mock_write, mock_read):
    #     """Test when database insertion fails"""
    #     # Mock successful download and file read
    #     mock_merge.return_value = MagicMock()
    #     mock_read.return_value = MagicMock()  # Valid dataframe
    #     mock_fetch_ssn.return_value = MagicMock()  # Valid WIN-SSN mapping
    #     mock_insert.side_effect = Exception("Database insertion failed")  # Simulate insertion failure
    #
    #     # Call the method under test and expect it to handle the exception
    #     with pytest.raises(Exception, match="Database insertion failed"):
    #         self.writer.start_process()
    #
    #     # Assertions
    #     mock_read.assert_called_once()
    #     mock_fetch_ssn.assert_called_once()
    #     mock_insert.assert_called_once()  # Ensure that insertion was attempted

    @patch('pytz.timezone', return_value=pytz.UTC)
    def test_transform_to_msa_transactions_format_stop_transaction(self, mock_tz):
        # Prepare input DataFrame
        input_df = pd.DataFrame({
            "NATIONAL_ID": [12345],
            "DOE_CODE": ["A1"],
            "RATE": [10.0],
            "LIMIT": [100.0],
            "STOP_IND": ["Y"],
            "STATE_CODE": ["WS"],
            "METHOD_TYPE": ["X"],
            "PERIOD_CODE": ["0"],
            "SECURE_2_0_FLAG" : ["N"]
        })

        # Capture the current central time before calling the function
        central_time_details = pytz.timezone('US/Central')
        current_datetime_central = datetime.now(central_time_details)
        effective_date = (current_datetime_central - timedelta(days=1)).date()
        current_time_str = current_datetime_central.strftime('%H:%M:%S')

        # Call the function
        msa_transaction_columns, transformed_values = self.writer.transform_to_msa_transactions_format(input_df)

        # Assertions
        assert len(transformed_values) == 1

        record = transformed_values[0]
        assert record[0] == CREATION_CODE_RTMS  # CREATION_CODE
        assert record[1] == effective_date  # CREATE_DATE
        assert record[2] >= current_time_str  # CREATE_TIME should match or be slightly after captured time
        assert record[3] == datetime(1, 1, 1)  # SENT_TO_PAYR_DATE
        assert record[4] == TRANSACTION_CODE  # TRANSACTION_CODE
        assert record[5] == CORPORATION_CODE  # CORPORATION_CODE
        assert record[6] == COMPANY_CODE  # COMPANY_CODE
        assert record[7] == 12345  # ASSOCIATE_SSN

        # Verify transaction data
        expected_transaction_data = "A1 X0N00000000000N00000000000".ljust(104, ' ')
        assert record[8] == expected_transaction_data  # TRANSACTION_DATA

        assert record[9] == effective_date  # EFFECTIVE_DATE

    @patch('pytz.timezone', return_value=pytz.UTC)
    def test_transform_to_msa_transactions_format_start_transaction(self, mock_tz):
        # Prepare input DataFrame
        input_df = pd.DataFrame({
            "NATIONAL_ID": [12345],
            "DOE_CODE": ["A1"],
            "RATE": [10.0],
            "LIMIT": [100.0],
            "STOP_IND": ["N"],
            "STATE_CODE": ["US"],
            "METHOD_TYPE": ["X"],
            "PERIOD_CODE": ["A"],
            "SECURE_2_0_FLAG": ["N"]
        })

        # Capture the current central time before calling the function
        central_time_details = pytz.timezone('US/Central')
        current_datetime_central = datetime.now(central_time_details)
        effective_date = (current_datetime_central - timedelta(days=1)).date()
        current_time_str = current_datetime_central.strftime('%H:%M:%S')

        # Call the function
        msa_transaction_columns, transformed_values = self.writer.transform_to_msa_transactions_format(input_df)

        # Assertions
        assert len(transformed_values) == 1

        record = transformed_values[0]
        assert record[0] == CREATION_CODE_RTMS  # CREATION_CODE
        assert record[1] == effective_date  # CREATE_DATE
        assert record[2] >= current_time_str  # CREATE_TIME should match or be slightly after captured time
        assert record[3] == datetime(1, 1, 1)  # SENT_TO_PAYR_DATE
        assert record[4] == TRANSACTION_CODE  # TRANSACTION_CODE
        assert record[5] == CORPORATION_CODE  # CORPORATION_CODE
        assert record[6] == COMPANY_CODE  # COMPANY_CODE
        assert record[7] == 12345  # ASSOCIATE_SSN

        # Verify transaction data
        expected_transaction_data = "A1 XAN00000001000N00000010000".ljust(104, ' ')
        assert record[8] == expected_transaction_data  # TRANSACTION_DATA

        assert record[9] == effective_date  # EFFECTIVE_DATE

    @patch('pytz.timezone', return_value=pytz.UTC)
    def test_transform_to_msa_transactions_format_loan_deduction(self, mock_tz):
        # Prepare input DataFrame
        input_df = pd.DataFrame({
            "NATIONAL_ID": [12345],
            "DOE_CODE": ["A1"],
            "RATE": [10.0],
            "LIMIT": [100.0],
            "STOP_IND": ["N"],
            "STATE_CODE": ["US"],
            "METHOD_TYPE": ["1"],
            "PERIOD_CODE": ["A"],
            "SECURE_2_0_FLAG": ["N"]
        })

        # Capture the current central time before calling the function
        central_time_details = pytz.timezone('US/Central')
        current_datetime_central = datetime.now(central_time_details)
        effective_date = (current_datetime_central - timedelta(days=1)).date()
        current_time_str = current_datetime_central.strftime('%H:%M:%S')

        # Call the function
        msa_transaction_columns, transformed_values = self.writer.transform_to_msa_transactions_format(input_df)

        # Assertions
        assert len(transformed_values) == 1

        record = transformed_values[0]
        assert record[0] == CREATION_CODE_P787  # CREATION_CODE
        assert record[1] == effective_date  # CREATE_DATE
        assert record[2] >= current_time_str  # CREATE_TIME should match or be slightly after captured time
        assert record[3] == datetime(1, 1, 1)  # SENT_TO_PAYR_DATE
        assert record[4] == TRANSACTION_CODE  # TRANSACTION_CODE
        assert record[5] == CORPORATION_CODE  # CORPORATION_CODE
        assert record[6] == COMPANY_CODE  # COMPANY_CODE
        assert record[7] == 12345  # ASSOCIATE_SSN

        # Verify transaction data
        expected_transaction_data = "A1 1AN00000001000".ljust(104, ' ')
        assert record[8] == expected_transaction_data  # TRANSACTION_DATA

        assert record[9] == effective_date  # EFFECTIVE_DATE

    # WIN-SSN Mapping Tests
    def test_fetch_win_ssn_mapping_success(self):
        self.writer.db2_connection = MagicMock()
        self.writer.db2_connection.fetchall.return_value = [(1, "12345")]
        result = self.writer.fetch_win_ssn_mapping("1")
        assert not result.empty
        assert result.iloc[0]["NATIONAL_ID"] == "12345"

    def test_fetch_win_ssn_mapping_failure(self):
        self.writer.db2_connection = MagicMock()
        self.writer.db2_connection.fetchall.side_effect = Exception("DB error")
        with pytest.raises(Exception):
            self.writer.fetch_win_ssn_mapping("1")

    # def test_insert_to_msa_transactions_table_success(self):
    #     self.writer.db2_connection = MagicMock()
    #     columns = ["col1", "col2"]
    #     values = [(1, "data1"), (2, "data2")]
    #     self.writer.insert_to_msa_transactions_table(columns, values)
    #     self.writer.db2_connection.bulk_insert.assert_called_once_with(
    #         self.writer.output_table_name, columns, values
    #     )

    def test_insert_to_msa_transactions_table_failure(self):
        self.writer.db2_connection = MagicMock()
        self.writer.db2_connection.bulk_insert.side_effect = Exception("Insert error")
        with pytest.raises(Exception):
            self.writer.insert_to_msa_transactions_table([], [])
