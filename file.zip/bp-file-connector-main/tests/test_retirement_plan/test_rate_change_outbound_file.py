import unittest
from unittest.mock import patch, MagicMock, Mock, mock_open
import pandas as pd
from datetime import datetime
from src.retirement_plan.rate_change_outbound_file import RateChangeOutbound

class MockFileGenerator:
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        self.configuration_id = configuration_id
        self.logger = logger
        self.request_id = request_id
        self.start_date = start_date
        self.end_date = end_date
        self.request_id_dir = "/test/path"
        self.dest_file = "test_file.csv"
        self.gcp_connection = Mock()
        self.cosmos_connection = Mock()
        self.db2_connection = Mock()
        self.bucket_name = "test-bucket"
        self.destination_folder = "test/path"
        self.flow_name = "RATE CHANGE OUTBOUND"


class TestRateChange(unittest.TestCase):
    @patch('src.generate_file.file_generator.FileGenerator', MockFileGenerator)
    def setUp(self):
        def mock_get_config_value(section, key=None):
            if section == "app":
                if key == "mongodb_connection_file_path":
                    return "/mock/path/mongodb_connection.json"
                elif key == "gcs_connection_file_path":
                    return "/mock/path/gcs_connection.json"
                elif key == "db2_connection_file_path":
                    return "/mock/path/db2_connection.yaml"
                elif key == "core_sql_api":
                    return "/mock/path/azure_ad.json"
                elif key == "core_sql_cosmos_url":
                    return "https://mock-cosmos-account.documents.azure.com:443/"
                else:
                    return "/tmp/test"
            elif section == "flow_config":
                return {
                    'flow_name': 'RATE CHANGE OUTBOUND',
                    'plan_number': '609450',
                    'record_types': ['r01', 'r02'],
                    'source_file_path': '',
                    'destination_file_path': 'test/path',
                    'bucket_name': 'test-bucket',
                    'plan_id': ['Regular', 'Catchup']
                }
            elif section == "file_layout":
                return {
                    "static_col_record_set": {
                        "r01": {"R01-RECORD-TYPE": "01"},
                        "r02": {"R02-RECORD-TYPE": "02"},
                    },
                    "corehr_columns_by_recordtype": {
                        "r01": ["WIN_NBR", "NATIONAL_ID", "LAST_NAME", "FIRST_NAME",
                                "BIRTH_DATE", "GENDER_CODE", "ACT_MARITAL_CODE", "COMP_FREQ_CODE"],
                        "r02": ["WIN_NBR", "NATIONAL_ID", "HOME_ADDR_LINE_1", "CITY_NAME",
                                "STATE_PROV_CODE", "POSTAL_CODE", "STR_STATE_PROV_CD"],
                        "r05": ["WIN_NBR", "NATIONAL_ID"],
                        "r62": ["WIN_NBR", "NATIONAL_ID", "STORE_NBR", "DIV_NBR",
                                "CHRG_STORE_NBR", "CHRG_MDSE_DIV_NBR", "PAY_TYPE_CODE",
                                "TERMINATION_DATE"]
                    }
                }
            return None

        mock_yaml_content = """
                        db2_region:
                            db2_database: testdb
                            db2_hostname: testhost
                            db2_protocol: tcpip
                            db2_userid: testuser
                            db2_port: 50000
                        """
        # Create detailed BigQuery client mock
        mock_bq_client = Mock()
        mock_bq_query_job = Mock()
        mock_bq_query_job.result.return_value = []
        mock_bq_client.query.return_value = mock_bq_query_job

        mock_datalake = Mock()

        # Mock cosmos query result with multiple transactions per associate
        # INCLUDING lastModifiedAt and lastModifiedBy fields
        mock_cosmos_result = [
            # Associate 1 - Latest is from OE (should be included)
            {'associateId': '100002821', 'createdAt': '2024-11-10T09:00:00Z', 'createdBy': 'OTHER', 'lastModifiedAt': None, 'lastModifiedBy': None},
            {'associateId': '100002821', 'createdAt': '2024-11-15T10:00:00Z', 'createdBy': 'OE', 'lastModifiedAt': None, 'lastModifiedBy': None},

            # Associate 2 - Latest is from ME_APP (should be included)
            {'associateId': '100008733', 'createdAt': '2024-11-12T08:00:00Z', 'createdBy': 'OTHER', 'lastModifiedAt': None, 'lastModifiedBy': None},
            {'associateId': '100008733', 'createdAt': '2024-11-15T14:00:00Z', 'createdBy': 'ME_APP', 'lastModifiedAt': None, 'lastModifiedBy': None},

            # Associate 3 - Latest is from OTHER (should NOT be included)
            {'associateId': '100010272', 'createdAt': '2024-11-05T12:00:00Z', 'createdBy': 'OE', 'lastModifiedAt': None, 'lastModifiedBy': None},
            {'associateId': '100010272', 'createdAt': '2024-11-20T16:00:00Z', 'createdBy': 'OTHER', 'lastModifiedAt': None, 'lastModifiedBy': None},

            # Associate 4 - Only has OTHER (should NOT be included)
            {'associateId': '100015555', 'createdAt': '2024-11-18T11:00:00Z', 'createdBy': 'OTHER', 'lastModifiedAt': None, 'lastModifiedBy': None},

            # Associate 5 - Only has OE (should be included)
            {'associateId': '100020000', 'createdAt': '2024-11-25T13:30:00Z', 'createdBy': 'OE', 'lastModifiedAt': None, 'lastModifiedBy': None},

            # Associate 6 - Has lastModified from ME_APP (should be included, demonstrating priority logic)
            {'associateId': '100030000', 'createdAt': '2024-11-20T10:00:00Z', 'createdBy': 'OTHER', 'lastModifiedAt': '2024-11-25T15:00:00Z', 'lastModifiedBy': 'ME_APP'},
        ]

        self.patches = [
            patch('src.utils.app_config.get_config_value', side_effect=mock_get_config_value),
            patch('builtins.open', mock_open(read_data=mock_yaml_content)),
            patch('json.load', return_value={
                'primary': {
                    'expiryDate': '2025-12-31 23:59:59.999',  # Correct format
                    'secText': 'primary_secret'
                },
                'secondary': {
                    'expiryDate': '2025-12-31 23:59:59.999',  # Correct format
                    'secText': 'secondary_secret'
                },
                'spnTenantId': '12345678-1234-5678-1234-567812345678',
                'spnClientId': '87654321-8765-4321-8765-432187654321'
            }),
            patch('src.integrations.cosmos_utils.ClientSecretCredential', return_value=Mock()),
            patch('src.integrations.cosmos_utils.CosmosClient', return_value=Mock()),
            patch('ibm_db.connect', return_value=Mock()),
            patch('ibm_db_dbi.connect', return_value=Mock()),
            patch('google.cloud.bigquery.Client', return_value=Mock()),
            patch('os.path.exists', return_value=True),
            patch('os.makedirs', return_value=True),
            patch('os.path.join', return_value='/mock/path'),
            patch('os.path.isdir', return_value=True),
            patch('src.integrations.gcs_utils.GCSUtils.upload_folder', return_value=True),
            patch('yaml.full_load', return_value={'db2_region': {
                'db2_database': 'testdb',
                'db2_hostname': 'testhost',
                'db2_protocol': 'tcpip',
                'db2_userid': 'testuser',
                'db2_port': 50000
            }}),
            patch('src.integrations.datalake_hudi_conn.DataLakeHudiUtils', MagicMock(return_value=mock_datalake)),
            patch('src.generate_file.file_generator.DataLakeHudiUtils', MagicMock(return_value=mock_datalake)),
            patch('src.integrations.datalake_hudi_conn.DataLakeHudiUtils.get_hudi_data', return_value=mock_datalake),
        ]
        for patcher in self.patches:
            patcher.start()
            self.addCleanup(patcher.stop)
        self.rate_change_outbound = RateChangeOutbound(1, Mock(), "test_request_id", datetime(2024, 11, 4),
                                                       datetime(2024, 11, 28))
        self.rate_change_outbound.logger = MagicMock()

        # Setup cosmos_connection mock to return test data
        self.rate_change_outbound.cosmos_connection.get_structured_data = MagicMock(return_value=mock_cosmos_result)

        self.record_dict = {
            'r01': pd.DataFrame({
                'associate_id': [100002821, 100008733, 100010272],
                'R01-RECORD-TYPE': ['01', '01', '01'],
                'R01-SAVINGS-RATES-INCLUDED': ['', '', ''],
                'R01-ELECT-BT-SAVE-RATE': ['', '', ''],
                'R01-ELECT-BT-CUC-SAVE-RATE': ['', '', ''],
                'LAST_NAME': ['Smith', 'Johnson', 'Brown'],
                'FIRST_NAME': ['John', 'Jane', 'Bob'],
            }),
            'r02': pd.DataFrame({
                'associate_id': [100002821, 100008733, 100010272],
                'R02-OPT-IN-OUT-FLAG': ['', '', ''],
                'R02-EMAIL-TYPE': ['', '', ''],
                'R02-EMAIL-ADDRESS': ['', '', ''],
            })
        }

        self.contribution_df = pd.DataFrame({
            'WIN_NBR': ['100002821', '100008733'],
            'R01-SAVINGS-RATES-INCLUDED': ['Y', 'Y'],
            'R01-ELECT-BT-SAVE-RATE': ['004B', '000{'],
            'R01-ELECT-BT-CUC-SAVE-RATE': ['003E', '003E']
        })

        self.consent_df = pd.DataFrame({
            'WIN_NBR': ['100002821', '100008733'],
            'R02-OPT-IN-OUT-FLAG': ['0', '0'],
            'R02-EMAIL-ADDRESS': ['', ''],
            'R02-EMAIL-TYPE': ['', '']
        })

    @patch.object(RateChangeOutbound, 'create_working_directory')
    @patch.object(RateChangeOutbound, 'get_associate_info', return_value=pd.DataFrame())
    @patch.object(RateChangeOutbound, 'process_core_hr_df', return_value=pd.DataFrame())
    @patch.object(RateChangeOutbound, 'generate_record_dict', return_value={})
    @patch.object(RateChangeOutbound, 'fetch_associate_contribution', return_value=pd.DataFrame())
    @patch.object(RateChangeOutbound, 'process_contribution_df', return_value=pd.DataFrame())
    @patch.object(RateChangeOutbound, 'update_contribution_data', return_value={})
    @patch.object(RateChangeOutbound, 'fetch_associate_consent', return_value=pd.DataFrame())
    @patch.object(RateChangeOutbound, 'apply_plan_specific_record_updates', return_value=None)
    @patch.object(RateChangeOutbound, 'apply_plan_detail_attributes', return_value={})
    @patch.object(RateChangeOutbound, 'initiate_flat_file_generation')
    @patch.object(RateChangeOutbound, 'transfer_file_to_gcs')
    @patch.object(RateChangeOutbound, 'transfer_file_to_mainframe')
    @patch('src.retirement_plan.rate_change_outbound_file.update_request_status')
    def test_start_process(self, mock_update_request_status, *mocks):
        # Testing the full process flow
        self.rate_change_outbound.start_process()

        # Verify update_request_status was called with the correct parameters
        mock_update_request_status.assert_called_with("test_request_id", 'COMPLETED',
                                                      self.rate_change_outbound.logger)

    def test_get_latest_approved_rate_changes(self):
        # Test that get_latest_approved_rate_changes returns the correct associates
        result = self.rate_change_outbound.get_latest_approved_rate_changes()

        # Should return 4 associates whose latest transactions are from OE or ME_APP
        # (including the one with lastModified from ME_APP)
        self.assertEqual(len(result), 4)
        self.assertIn('100002821', result)  # Latest from OE
        self.assertIn('100008733', result)  # Latest from ME_APP
        self.assertIn('100020000', result)  # Only has OE
        self.assertIn('100030000', result)  # lastModified from ME_APP

        # Should NOT include associates whose latest transactions are not from OE or ME_APP
        self.assertNotIn('100010272', result)  # Latest from OTHER
        self.assertNotIn('100015555', result)  # Only has OTHER

        # Verify cosmos_connection.get_structured_data was called with correct parameters
        expected_where_condition = (
                f"c.activity = 'RATE CHANGE OUTBOUND' " +
                f"AND SUBSTRING(c.createdAt, 0, 10) >= '2024-11-04' " +
                f"AND SUBSTRING(c.createdAt, 0, 10) <= '2024-11-28'" +
                f"AND c.planId in ('retirement_401k_regular_us','retirement_401k_regular_pr'," +
                f"'retirement_401k_catchup_regular_us','retirement_401k_catchup_regular_pr')"
        )

        self.rate_change_outbound.cosmos_connection.get_structured_data.assert_called_with(
            cosmos_database='benefits-platform',
            cosmos_collection='transaction-logs',
            cosmos_projection="c.associateId, c.createdAt, c.createdBy, c.lastModifiedAt, c.lastModifiedBy",
            cosmos_search_criteria={"where": expected_where_condition}
        )

    def test_apply_plan_specific_record_updates(self):
        # Create copies to avoid modifying original test data
        record_dict_copy = {
            'r01': self.record_dict['r01'].copy(),
            'r02': self.record_dict['r02'].copy()
        }
        consent_df_copy = self.consent_df.copy()

        # Call the method
        updated_dict = self.rate_change_outbound.apply_plan_specific_record_updates(record_dict_copy, consent_df_copy)

        # Verify r01 fields have been initialized if missing
        self.assertTrue('R01-SAVINGS-RATES-INCLUDED' in updated_dict['r01'].columns)
        self.assertTrue('R01-ELECT-BT-SAVE-RATE' in updated_dict['r01'].columns)
        self.assertTrue('R01-ELECT-BT-CUC-SAVE-RATE' in updated_dict['r01'].columns)

        # Assert that r02 dataframe was updated with values from consent_df
        # The logic converts empty strings to '0', so we expect '0' values
        expected_flag_values = ['0', '0', '0']  # Changed from ['', '', ''] to ['0', '0', '0']
        actual_flag_values = updated_dict['r02']['R02-OPT-IN-OUT-FLAG'].tolist()
        self.assertEqual(expected_flag_values[:2], actual_flag_values[:2])

        # Check that other columns were also updated correctly
        self.assertEqual(updated_dict['r02']['R02-EMAIL-TYPE'].tolist()[:2], ['', ''])
        self.assertEqual(updated_dict['r02']['R02-EMAIL-ADDRESS'].tolist()[:2], ['', ''])

        # Check that columns were overridden with spaces as required
        overridden_columns = [
            'LAST_NAME', 'FIRST_NAME'
        ]

        for col in overridden_columns:
            if col in updated_dict['r01'].columns:
                self.assertTrue(all(val == " " for val in updated_dict['r01'][col]))

if __name__ == '__main__':
    unittest.main()