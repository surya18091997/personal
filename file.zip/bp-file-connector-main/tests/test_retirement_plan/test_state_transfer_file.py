import unittest
from unittest.mock import Mock, patch, mock_open
import datetime
import logging
import sys
import pandas as pd
from src.utils.errors.db2_errors import DatabaseError

"""
Test Suite for StateTransfer Module

This module provides comprehensive testing for the StateTransfer class which handles:
- State transfer processing
- Data retrieval from multiple sources (DB2, Core HR, Cosmos DB)
- File generation and validation
- Record type specific transformations

Core Testing Areas:
1. Data Retrieval
   - Transaction log retrieval from Cosmos DB
   - Associate information from Core HR
   - Division data from DB2
   - State transfer eligibility checks

2. Data Processing
   - Record generation for different types (r01, r02, r05, r62)
   - State transfer attribute application
   - Data validation and transformation
   - Date handling and formatting

3. File Operations
   - Working directory management
   - Output file generation
   - Regional processing (US/PR)

4. Error Handling
   - Empty result sets
   - Missing data scenarios
   - Invalid configurations
   - Database errors

Execution Commands:
    python -m pytest --cov=src.retirement_plan.state_transfer_file tests/test_retirement_plan/test_state_transfer_file.py --cov-report=html
"""

# Set up logging for test execution
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Mock external service dependencies to isolate tests
mock_modules = {
    'ibm_db': Mock(),
    'ibm_db_dbi': Mock(),
    'pymongo': Mock(),
    'pymongo.errors': Mock(),
    'google': Mock(),
    'google.cloud': Mock(),
    'google.cloud.storage': Mock(),
    'google.cloud.bigquery': Mock(),
    'google.api_core': Mock(),
    'google.api_core.retry': Mock(),
    'google.api_core.exceptions': Mock()
}

retry_mock = Mock()
retry_mock.Retry = Mock(return_value=lambda x: x)
mock_modules['google.api_core'].retry = retry_mock

exceptions_mock = Mock()
exceptions_mock.GoogleAPIError = type('GoogleAPIError', (Exception,), {})
mock_modules['google.api_core.exceptions'].GoogleAPIError = exceptions_mock.GoogleAPIError

for module_name, mock_obj in mock_modules.items():
    sys.modules[module_name] = mock_obj

from src.retirement_plan.state_transfer_file import StateTransfer


class TestStateTransfer(unittest.TestCase):
    """
    Test suite for StateTransfer class functionality.

    Test Categories:
    1. Setup and Configuration
    2. Record Generation
    3. Data Retrieval
    4. State Transfer Processing
    5. Error Handling

    Each test method focuses on specific functionality
    with comprehensive validation and edge cases.
    """

    @patch('src.integrations.db2_conn_helper.DB2IDatabase')
    def setUp(self, mock_db2):
        """
        Set up test fixtures and mocks for each test.

        Setup Components:
        1. Logger configuration
        2. Date range setup
        3. Configuration mocking
        4. Database connections
        5. File system operations

        Args:
            mock_db2: Mocked DB2 database connection

        Mocks:
        - DB2 database operations
        - Configuration retrieval
        - File system operations
        - Cloud storage operations
        """
        self.logger = Mock()
        self.request_id = "test_request_123"
        self.start_date = datetime.datetime(2024, 1, 1)
        self.end_date = datetime.datetime(2024, 12, 31)
        self.configuration_id = "2"

        # Mock DB2 instance with empty DataFrame returns
        mock_db2_instance = Mock()
        mock_db2_instance.get_data_from_db2 = Mock(return_value=pd.DataFrame())
        mock_db2_instance.fetch_core_hr_data = Mock(return_value=pd.DataFrame())
        mock_db2_instance.fetch_division_numbers = Mock(return_value=pd.DataFrame())
        mock_db2.return_value = mock_db2_instance

        # Configure mock configuration values with detailed structure
        def mock_get_config_value(section, key=None):
            configs = {
                "app": {
                    "mongodb_connection_file_path": "/mock/path/mongodb_connection.json",
                    "gcs_connection_file_path": "/mock/path/gcs_connection.json",
                    "db2_connection_file_path": "/mock/path/db2_connection.yaml",
                    "defaultFileStorage": "/tmp/test"
                },
                "flow_config": {
                    'flow_name': 'STATE_TRANSFER',
                    'plan_number': '609450',
                    'record_types': ['r01', 'r02', 'r05', 'r62'],
                    'source_file_path': '',
                    'destination_file_path': 'test/path',
                    'bucket_name': 'test-bucket'
                },
                "file_layout": {
                    "static_col_record_set": {
                        "r01": {"R01-RECORD-TYPE": "01"},
                        "r02": {"R02-RECORD-TYPE": "02"},
                        "r05": {"R05-RECORD-TYPE": "05"},
                        "r62": {"R62-RECORD-TYPE": "62"}
                    },
                    "corehr_columns_by_recordtype": {
                        "r01": ["WIN_NBR", "NATIONAL_ID", "LAST_NAME", "FIRST_NAME",
                                "BIRTH_DATE", "GENDER_CODE", "ACT_MARITAL_CODE", "COMP_FREQ_CODE"],
                        "r02": ["WIN_NBR", "NATIONAL_ID", "HOME_ADDR_LINE_1", "CITY_NAME",
                                "STATE_PROV_CODE", "POSTAL_CODE", "STR_STATE_PROV_CD"],
                        "r05": ["WIN_NBR", "NATIONAL_ID"],
                        "r62": ["WIN_NBR", "NATIONAL_ID", "STORE_NBR", "DIV_NBR",
                                "CHRG_STORE_NBR", "CHRG_MDSE_DIV_NBR", "PAY_TYPE_CODE",
                                "TERMINATION_DATE"]
                    }
                }
            }
            return configs.get(section, {}).get(key, configs.get(section, {}))

        # Helper method for creating consistent test data
        def create_mock_df():
            """
            Creates mock DataFrame with test data.

            Returns:
                pandas.DataFrame: Test data with all required columns

            Data includes:
            - Personal information
            - Address details
            - Employment information
            - Dates and codes
            """
            return pd.DataFrame({
                'WIN_NBR': ['12345'],
                'NATIONAL_ID': ['123456789'],
                'FIRST_NAME': ['John'],
                'LAST_NAME': ['Doe'],
                'BIRTH_DATE': ['1990-01-01'],
                'HIRE_DATE': ['2020-01-01'],
                'STORE_NBR': ['12345'],
                'DIV_NBR': ['045'],
                'TERMINATION_DATE': [''],
                'CHRG_STORE_NBR': ['12345'],
                'CHRG_MDSE_DIV_NBR': ['045'],
                'GENDER_CODE': ['M'],
                'ACT_MARITAL_CODE': ['S'],
                'COMP_FREQ_CODE': ['B'],
                'PAY_TYPE_CODE': ['H'],
                'HOME_ADDR_LINE_1': ['123 Main St'],
                'CITY_NAME': ['Test City'],
                'STATE_PROV_CODE': ['NY'],
                'POSTAL_CODE': ['12345'],
                'STR_STATE_PROV_CD': ['NY'],
                'R01-BDAY-DD': ['01'],
                'R01-BDAY-MM': ['01'],
                'R01-BDAY-YY': ['1990'],
                'R01-HDAY-DD': ['01'],
                'R01-HDAY-MM': ['01'],
                'R01-HDAY-YY': ['2020']
            })

        self.create_mock_df = create_mock_df

        # Mock DB2 configuration
        mock_yaml_content = """
        db2_region:
            db2_database: testdb
            db2_hostname: testhost
            db2_protocol: tcpip
            db2_userid: testuser
            db2_port: 50000
        """

        # Set up all required patches
        self.patches = [
            patch('src.utils.app_config.get_config_value', side_effect=mock_get_config_value),
            patch('builtins.open', mock_open(read_data=mock_yaml_content)),
            patch('os.path.exists', return_value=True),
            patch('os.makedirs', return_value=True),
            patch('src.integrations.gcs_utils.GCSUtils.upload_folder', return_value=True),
            patch('yaml.full_load', return_value={'db2_region': {
                'db2_database': 'testdb',
                'db2_hostname': 'testhost',
                'db2_protocol': 'tcpip',
                'db2_userid': 'testuser',
                'db2_port': 50000
            }})
        ]

        # Start all patches
        for patcher in self.patches:
            patcher.start()
            self.addCleanup(patcher.stop)

        # Initialize StateTransfer instance with test configuration
        self.state_transfer = StateTransfer(
            configuration_id=self.configuration_id,
            logger=self.logger,
            request_id=self.request_id,
            start_date=self.start_date,
            end_date=self.end_date
        )

        # Set required attributes for testing
        self.state_transfer.record_types = ['r01', 'r02', 'r05', 'r62']
        self.state_transfer.bucket_name = "test-bucket"
        self.state_transfer.destination_file_path = "test/path"
        self.state_transfer.request_id_dir = "/tmp/test"
        self.state_transfer.plan_number = "609450"
        self.state_transfer.plan_stat_code = "06"
        self.state_transfer.region = "US"

    # def test_generate_record_dict(self):
    #     """
    #     Test record dictionary generation functionality.
    #
    #     Test Flow:
    #     1. Create mock data
    #     2. Generate record dictionary
    #     3. Verify all record types
    #     4. Validate key fields
    #
    #     Verifies:
    #     - All record types present
    #     - Correct data mapping
    #     - Key field preservation
    #     - Data type consistency
    #     """
    #     mock_df = self.create_mock_df()
    #     result = self.state_transfer.generate_record_dict(mock_df, ['12345'])
    #
    #     # Verify all record types are present
    #     for record_type in ['r01', 'r02', 'r05', 'r62']:
    #         self.assertIn(record_type, result)
    #
    #     # Verify key fields in each record type
    #     self.assertEqual(result['r01']['WIN_NBR'].iloc[0], '12345')
    #     self.assertEqual(result['r02']['WIN_NBR'].iloc[0], '12345')
    #     self.assertEqual(result['r05']['WIN_NBR'].iloc[0], '12345')
    #     self.assertEqual(result['r62']['WIN_NBR'].iloc[0], '12345')
    #
    # def test_get_associate_info(self):
    #     """
    #     Test associate information retrieval.
    #
    #     Test Flow:
    #     1. Setup mock core HR data
    #     2. Configure division data
    #     3. Execute retrieval
    #     4. Verify results
    #
    #     Verifies:
    #     - Data integration
    #     - Type conversion
    #     - Column mapping
    #     - Error handling
    #     """
    #     # Mock data setup with numeric types
    #     mock_data = pd.DataFrame({
    #         'WIN_NBR': [12345],
    #         'NATIONAL_ID': ['123456789'],
    #         'FIRST_NAME': ['John'],
    #         'LAST_NAME': ['Doe'],
    #         'BIRTH_DATE': ['1990-01-01'],
    #         'HIRE_DATE': ['2020-01-01'],
    #         'STORE_NBR': [12345],
    #         'DIV_NBR': [45],
    #         'TERMINATION_DATE': [''],
    #         'CHRG_STORE_NBR': [12345],
    #         'CHRG_MDSE_DIV_NBR': [45],
    #         'GENDER_CODE': ['M'],
    #         'ACT_MARITAL_CODE': ['S'],
    #         'COMP_FREQ_CODE': ['B'],
    #         'PAY_TYPE_CODE': ['H']
    #     })
    #     mock_data = mock_data.astype({'STORE_NBR': 'int64'})
    #
    #     # Mock division data
    #     division_df = pd.DataFrame({
    #         'STORE_NBR': [12345],
    #         'DIV_NBR': [45]
    #     }).astype('int64')
    #
    #     # Debug logging
    #     self.logger.debug(f"Mock data columns: {mock_data.columns}")
    #     self.logger.debug(f"Division df columns: {division_df.columns}")
    #     self.logger.debug(f"Mock data STORE_NBR dtype: {mock_data['STORE_NBR'].dtype}")
    #     self.logger.debug(f"Division df STORE_NBR dtype: {division_df['STORE_NBR'].dtype}")
    #
    #     with patch.object(self.state_transfer, 'fetch_core_hr_data', return_value=mock_data) as mock_core_hr, \
    #             patch.object(self.state_transfer, 'fetch_division_numbers', return_value=division_df) as mock_div:
    #
    #         result = self.state_transfer.get_associate_info(['12345'])
    #
    #         # Verify mock calls
    #         mock_core_hr.assert_called_once_with('12345')
    #         mock_div.assert_called_once_with([12345])
    #
    #         # Debug logging
    #         self.logger.debug(f"Result columns: {result.columns}")
    #         self.logger.debug(f"Result shape: {result.shape}")
    #         self.logger.debug(f"Result dtypes: {result.dtypes}")
    #
    #         # Results verification
    #         self.assertIsNotNone(result)
    #         self.assertGreater(len(result), 0)
    #         self.assertTrue({'STORE_NBR'}.issubset(set(result.columns)))
    #         self.assertTrue(any(col.startswith('DIV_NBR') for col in result.columns))
    #         self.assertEqual(result['STORE_NBR'].iloc[0], 12345)
    #
    #         # Check DIV_NBR in appropriate column
    #         if 'DIV_NBR_x' in result.columns:
    #             self.assertEqual(result['DIV_NBR_x'].iloc[0], 45)
    #         elif 'DIV_NBR_y' in result.columns:
    #             self.assertEqual(result['DIV_NBR_y'].iloc[0], 45)
    #         elif 'DIV_NBR' in result.columns:
    #             self.assertEqual(result['DIV_NBR'].iloc[0], 45)
    #
    # def test_get_associate_info_empty_core_hr(self):
    #     """
    #     Test handling of empty Core HR data response.
    #
    #     Test Flow:
    #     1. Setup mock empty DataFrame
    #     2. Attempt to get associate info
    #     3. Verify error handling
    #
    #     Verifies:
    #     - Proper error type raised (DatabaseError)
    #     - Correct error message content
    #     - Error code inclusion (DB0001)
    #     - Empty result set handling
    #
    #     Expected Outcome:
    #     - DatabaseError with empty result message
    #     - DB0001 error code in message
    #     """
    #     mock_empty_df = pd.DataFrame()
    #
    #     with patch.object(self.state_transfer, 'fetch_core_hr_data', return_value=mock_empty_df):
    #         with self.assertRaises(DatabaseError) as context:
    #             self.state_transfer.get_associate_info(['12345'])
    #
    #         error_message = str(context.exception)
    #         self.assertIn("Empty result set for the given query", error_message)
    #         self.assertIn("DB0001", error_message)
    #
    # def test_get_associate_info_no_divisions(self):
    #     """
    #     Test associate info retrieval with no division data.
    #
    #     Test Flow:
    #     1. Setup mock core HR data with types
    #     2. Create empty division DataFrame
    #     3. Execute retrieval
    #     4. Verify results
    #
    #     Mocks:
    #     - Core HR data with integer types
    #     - Empty division data with correct schema
    #
    #     Verifies:
    #     - Result structure
    #     - Data type preservation
    #     - Empty division handling
    #     - Key field presence
    #     """
    #     mock_data = pd.DataFrame({
    #         'WIN_NBR': [12345],
    #         'STORE_NBR': [12345],
    #         'DIV_NBR': [45]
    #     }).astype({'STORE_NBR': 'int64', 'DIV_NBR': 'int64'})
    #
    #     empty_division_df = pd.DataFrame({
    #         'STORE_NBR': [],
    #         'DIV_NBR': []
    #     }).astype('int64')
    #
    #     with patch.object(self.state_transfer, 'fetch_core_hr_data', return_value=mock_data), \
    #             patch.object(self.state_transfer, 'fetch_division_numbers', return_value=empty_division_df):
    #         result = self.state_transfer.get_associate_info(['12345'])
    #
    #         self.assertIsNotNone(result)
    #         self.assertEqual(len(result), 1)
    #         self.assertTrue('STORE_NBR' in result.columns)
    #         self.assertEqual(result['STORE_NBR'].iloc[0], 12345)
    #
    # def test_get_transaction_logs(self):
    #     """
    #     Test transaction log retrieval from Cosmos DB.
    #
    #     Test Flow:
    #     1. Setup mock Cosmos data
    #     2. Configure date range expectations
    #     3. Execute retrieval
    #     4. Verify results and calls
    #
    #     Verifies:
    #     - Search criteria construction
    #     - Date range formatting
    #     - Cosmos DB query parameters
    #     - Result validation
    #
    #     Expected Criteria:
    #     - Activity: STATE_TRANSFER
    #     - Date range: start to end
    #     - Projection: associateId only
    #     """
    #     mock_cosmos_data = [{"associateId": "12345"}]
    #     expected_start = self.start_date.replace(hour=0, minute=0, second=1).isoformat()
    #     expected_end = self.end_date.replace(hour=23, minute=59, second=59).isoformat()
    #
    #     expected_search_criteria = {
    #         "activity": "STATE_TRANSFER",
    #         "createdAt": {
    #             "$gte": expected_start,
    #             "$lte": expected_end
    #         }
    #     }
    #
    #     with patch.object(
    #             self.state_transfer,
    #             'get_eligible_data_from_cosmos',
    #             return_value=mock_cosmos_data
    #     ) as mock_cosmos:
    #         result = self.state_transfer.get_transaction_logs()
    #
    #         self.assertIsNotNone(result)
    #         self.assertEqual(result, mock_cosmos_data)
    #
    #         mock_cosmos.assert_called_once_with(
    #             cosmos_database='benefits-platform',
    #             cosmos_collection='transaction-logs',
    #             cosmos_projection={'_id': 0, 'associateId': 1},
    #             cosmos_search_criteria=expected_search_criteria
    #         )
    #
    # def test_get_transaction_logs_no_data(self):
    #     """
    #     Test transaction log retrieval with no data response.
    #
    #     Test Flow:
    #     1. Setup mock returning None
    #     2. Execute retrieval
    #     3. Verify null handling
    #
    #     Verifies:
    #     - Null response handling
    #     - Logging behavior
    #     - Return value
    #
    #     Expected Outcome:
    #     - None return value
    #     - Appropriate log message
    #     """
    #     with patch.object(
    #             self.state_transfer,
    #             'get_eligible_data_from_cosmos',
    #             return_value=None
    #     ) as mock_cosmos:
    #         result = self.state_transfer.get_transaction_logs()
    #         self.assertIsNone(result)
    #         self.logger.info.assert_any_call('No eligible associate list found.')
    #
    #
    # def test_handle_no_eligible_transfers(self):
    #     """
    #     Test handling of scenarios with no eligible transfers.
    #
    #     Test Flow:
    #     1. Setup mock with empty results
    #     2. Attempt file generation
    #     3. Verify exception handling
    #
    #     Mocks:
    #     - Empty transaction logs
    #     - Failed eligibility check
    #     - Mock associate info
    #
    #     Expected Outcome:
    #     - Exception raised
    #     - Proper error propagation
    #     - Clean error state
    #     """
    #     mock_df = self.create_mock_df()
    #
    #     with patch.multiple(
    #             self.state_transfer,
    #             get_transaction_logs=Mock(return_value=[]),
    #             eligible_state_transfers=Mock(side_effect=Exception("Empty result set")),
    #             get_associate_info=Mock(return_value=mock_df)):
    #         with self.assertRaises(Exception):
    #             self.state_transfer.start_process()
    #
    # def test_eligible_state_transfers_us(self):
    #     """
    #     Test state transfer eligibility for US region.
    #
    #     Test Flow:
    #     1. Setup US region test data
    #     2. Configure region setting
    #     3. Execute eligibility check
    #     4. Verify results
    #
    #     Test Data:
    #     - US state transfers
    #     - PR to US movement
    #     - Valid test dates
    #
    #     Verifies:
    #     - Column selection
    #     - Query formatting
    #     - Result filtering
    #     - Date handling
    #     """
    #     mock_df = pd.DataFrame({
    #         'WIN_NBR': ['12345'],
    #         'CURRENT_STATE': ['NY'],
    #         'PREVIOUS_STATE': ['PR']
    #     })
    #
    #     self.state_transfer.region = 'US'
    #
    #     with patch.object(self.state_transfer, 'get_data_from_db2', return_value=mock_df) as mock_db2:
    #         result = self.state_transfer.eligible_state_transfers(
    #             ['12345'],
    #             self.start_date,
    #             self.end_date
    #         )
    #
    #         expected_start = datetime.datetime.strftime(self.start_date, '%Y-%m-%d')
    #         expected_end = datetime.datetime.strftime(self.end_date, '%Y-%m-%d')
    #
    #         mock_db2.assert_called_once()
    #         call_args = mock_db2.call_args[1]
    #
    #         self.assertEqual(
    #             call_args['col_names'],
    #             ['WIN_NBR', 'CURRENT_STATE', 'PREVIOUS_STATE']
    #         )
    #
    #         self.assertEqual(result, ['12345'])
    #
    # def test_eligible_state_transfers_pr(self):
    #     """
    #     Test state transfer eligibility for PR region.
    #
    #     Test Flow:
    #     1. Setup PR region test data
    #     2. Configure PR region
    #     3. Execute eligibility check
    #     4. Verify results
    #
    #     Test Data:
    #     - PR state transfers
    #     - US to PR movement
    #     - Valid test dates
    #
    #     Verifies:
    #     - PR region handling
    #     - Query construction
    #     - Result validation
    #     """
    #     mock_df = pd.DataFrame({
    #         'WIN_NBR': ['12345'],
    #         'CURRENT_STATE': ['PR'],
    #         'PREVIOUS_STATE': ['NY']
    #     })
    #
    #     self.state_transfer.region = 'PR'
    #
    #     with patch.object(self.state_transfer, 'get_data_from_db2', return_value=mock_df) as mock_db2:
    #         result = self.state_transfer.eligible_state_transfers(
    #             ['12345'],
    #             self.start_date,
    #             self.end_date
    #         )
    #
    #         self.assertEqual(result, ['12345'])
    #
    # def test_eligible_state_transfers_empty_result(self):
    #     """
    #     Test handling of empty results in eligibility check.
    #
    #     Test Flow:
    #     1. Setup empty result DataFrame
    #     2. Attempt eligibility check
    #     3. Verify error handling
    #
    #     Verifies:
    #     - Empty result detection
    #     - Error message content
    #     - Exception handling
    #     - Clean error state
    #     """
    #     mock_df = pd.DataFrame(columns=['WIN_NBR', 'CURRENT_STATE', 'PREVIOUS_STATE'])
    #
    #     with patch.object(self.state_transfer, 'get_data_from_db2', return_value=mock_df):
    #         with self.assertRaises(Exception) as context:
    #             self.state_transfer.eligible_state_transfers(
    #                 ['12345'],
    #                 self.start_date,
    #                 self.end_date
    #             )
    #
    #         self.assertIn("Empty result set for the given query", str(context.exception))
    #
    # def test_eligible_state_transfers_multiple_associates(self):
    #     """
    #     Test eligibility check with multiple associates.
    #
    #     Test Flow:
    #     1. Setup multi-associate test data
    #     2. Execute eligibility check
    #     3. Verify unique results
    #
    #     Test Data:
    #     - Multiple associates
    #     - Duplicate entries
    #     - Valid state transfers
    #
    #     Verifies:
    #     - Duplicate handling
    #     - Result uniqueness
    #     - Complete result set
    #     """
    #     mock_df = pd.DataFrame({
    #         'WIN_NBR': ['12345', '67890', '12345'],  # Duplicate for uniqueness test
    #         'CURRENT_STATE': ['NY', 'NY', 'NY'],
    #         'PREVIOUS_STATE': ['PR', 'PR', 'PR']
    #     })
    #
    #     with patch.object(self.state_transfer, 'get_data_from_db2', return_value=mock_df):
    #         result = self.state_transfer.eligible_state_transfers(
    #             ['12345', '67890'],
    #             self.start_date,
    #             self.end_date
    #         )
    #
    #         self.assertEqual(set(result), {'12345', '67890'})
    #
    #
    # def test_process_core_hr_df(self):
    #     """
    #     Test processing of Core HR DataFrame.
    #
    #     Test Flow:
    #     1. Setup mock DataFrame
    #     2. Process through Core HR logic
    #     3. Verify transformations
    #
    #     Verifies:
    #     - Data transformations
    #     - Column mappings
    #     - Data type handling
    #
    #     Test Data:
    #     - Sample associate information
    #     - Required columns present
    #     """
    #
    #     def test_process_core_hr_df(self):
    #         """Test processing of Core HR DataFrame"""
    #         mock_df = pd.DataFrame({
    #             'WIN_NBR': ['12345'],
    #             'NATIONAL_ID': ['123456789'],
    #             'FIRST_NAME': ['John'],  # Add required name fields
    #             'LAST_NAME': ['Doe'],
    #             'DATE_FIELD': ['2024-01-01']
    #         })
    #
    #         result = self.state_transfer.process_core_hr_df(mock_df)
    #
    #         self.assertIsNotNone(result)
    #         self.assertIn('WIN_NBR', result.columns)
    #         self.assertEqual(result['WIN_NBR'].iloc[0], '12345')
    #         self.assertIn('NAME', result.columns)  # Check combined name field
    #         self.assertEqual(result['NAME'].iloc[0], 'Doe, John')
    #
    # def test_initiate_flat_file_generation(self):
    #     """
    #     Test flat file generation initiation.
    #
    #     Test Flow:
    #     1. Setup mock record dictionary
    #     2. Initiate file generation
    #     3. Verify file creation
    #
    #     Test Data:
    #     - Record dictionary with all types
    #     - Test data for each record type
    #
    #     Verifies:
    #     - File generation
    #     - Record processing
    #     - Error handling
    #     """
    #     mock_dict = {
    #         'r01': pd.DataFrame({'WIN_NBR': ['12345']}),
    #         'r02': pd.DataFrame({'WIN_NBR': ['12345']}),
    #         'r05': pd.DataFrame({'WIN_NBR': ['12345']}),
    #         'r62': pd.DataFrame({'WIN_NBR': ['12345']})
    #     }
    #
    #     self.state_transfer.dest_file = "test_output.txt"  # Set destination file name
    #
    #     with patch('builtins.open', mock_open()) as mock_file:
    #         self.state_transfer.initiate_flat_file_generation(mock_dict)
    #         mock_file.assert_called()
    #
    #
    #
    # def test_eligible_state_transfers_date_formatting(self):
    #     """
    #     Test date format handling in eligibility checks.
    #
    #     Test Flow:
    #     1. Setup test data
    #     2. Test multiple date formats
    #     3. Verify query formatting
    #
    #     Test Cases:
    #     - Start of day (00:00:00)
    #     - Middle of day (12:30:45)
    #     - End of day (23:59:59)
    #
    #     Verifies:
    #     - Date format consistency
    #     - Query parameter formatting
    #     - Time handling
    #     """
    #     mock_df = pd.DataFrame({
    #         'WIN_NBR': ['12345'],
    #         'CURRENT_STATE': ['NY'],
    #         'PREVIOUS_STATE': ['PR']
    #     })
    #
    #     test_dates = [
    #         datetime.datetime(2024, 1, 1),
    #         datetime.datetime(2024, 1, 1, 12, 30, 45),
    #         datetime.datetime(2024, 1, 1, 23, 59, 59),
    #     ]
    #
    #     for test_date in test_dates:
    #         with patch.object(self.state_transfer, 'get_data_from_db2', return_value=mock_df) as mock_db2:
    #             result = self.state_transfer.eligible_state_transfers(
    #                 ['12345'],
    #                 test_date,
    #                 test_date
    #             )
    #
    #             call_args = mock_db2.call_args[1]
    #             self.assertIn('query', call_args)
    #             formatted_date = datetime.datetime.strftime(test_date, '%Y-%m-%d')
    #             self.assertIn(formatted_date, call_args['query'])
    #
    # def test_generate_file_error_handling(self):
    #     """
    #     Test error handling in file generation workflow.
    #
    #     Test Flow:
    #     1. Setup mock failure
    #     2. Verify error propagation
    #     3. Check error logging
    #     """
    #     # Setup mock to fail at various steps
    #     with patch.multiple(
    #             self.state_transfer,
    #             create_working_directory=Mock(),
    #             get_transaction_logs=Mock(return_value=['12345']),
    #             eligible_state_transfers=Mock(side_effect=Exception("Test error")),
    #     ):
    #         # Execute & Assert
    #         with self.assertRaises(Exception) as context:
    #             self.state_transfer.start_process()
    #
    #         self.assertEqual(str(context.exception), "Test error")
    #         self.state_transfer.create_working_directory.assert_called_once()
    #         self.state_transfer.get_transaction_logs.assert_called_once()

if __name__ == '__main__':
    unittest.main()