from datetime import datetime
import pytest
from unittest.mock import MagicMock, patch
import pandas as pd

from src.constants import TRANSACTION_CODE, CORPORATION_CODE, COMPANY_CODE_PR, COMPANY_CODE_US
from src.retirement_plan.rk_transactions_writer import RKTransactionWriter


class TestRKTransactionWriter:
    @pytest.fixture(autouse=True)
    def setup(self, mocker):
        logger = MagicMock()
        self.configuration_id = 31
        self.request_id = 'test_request'
        self.writer = RKTransactionWriter(self.configuration_id, logger, self.request_id)
        self.writer.cwd = '/test'
        self.writer.source_file_path = 'test_path'
        self.writer.db2_region = 'test_region'
        self.writer.gcs_util = MagicMock()
        self.writer.bucket_name = 'test_bucket'

    def test_initialization(self):
        assert self.writer.reference_output_file_name == f"{datetime.today().date()}_RK_Transaction.csv"

    @patch('src.integrations.gcs_utils.GCSUtils.download_file')
    @patch('src.retirement_plan.rk_transactions_writer.read_file_to_dataframe')
    @patch('src.retirement_plan.rk_transactions_writer.write_dataframe_to_file')
    @patch('src.retirement_plan.rk_transactions_writer.RKTransactionWriter.fetch_win_ssn_mapping')
    @patch('pandas.merge')
    def test_start_process_success(self, mock_merge, mock_fetch_ssn, mock_write, mock_read, mock_download):
        # Mock input data
        test_data = pd.DataFrame({
            'WIN_NBR': [123],
            'STATE_CODE': ['US'],
            'DOE_CODE': ['D1'],
            'STOP_IND': ['N'],
            'PERIOD_CODE': ['M'],
            'RATE': [10.5]
        })

        mock_ssn_data = pd.DataFrame({
            'WIN_NBR': [123],
            'NATIONAL_ID': ['456789012']
        })

        # Set up mock returns
        mock_read.return_value = test_data
        mock_fetch_ssn.return_value = mock_ssn_data
        mock_merge.return_value = pd.DataFrame({
            'WIN_NBR': [123],
            'NATIONAL_ID': ['456789012'],
            'STATE_CODE': ['US'],
            'DOE_CODE': ['D1'],
            'STOP_IND': ['N'],
            'PERIOD_CODE': ['M'],
            'RATE': [10.5]
        })

        # Execute
        self.writer.start_process()

        # Verify data processing
        mock_read.assert_called_once()
        mock_fetch_ssn.assert_called_once_with('123')
        mock_merge.assert_called_once()

    def test_start_process_error(self):
        # Mocking the download method to raise an exception
        self.writer.gcs_util.download_file.side_effect = Exception("Download failed")

        with pytest.raises(Exception, match="Download failed"):
            self.writer.start_process()


    def test_transform_to_rk_transactions_format(self):
        # Test data
        input_df = pd.DataFrame({
            'NATIONAL_ID': ['123456789'],
            'STATE_CODE': ['US'],
            'DOE_CODE': ['D1'],
            'STOP_IND': ['N'],
            'PERIOD_CODE': ['M'],
            'RATE': [10.5]
        })

        # Expected format for rate: 10.5 * 100 * 100 = 105000
        expected_rate = "00000105000"

        result = self.writer.transform_to_rk_transactions_format(input_df)

        # Verify result contains the expected string format
        assert len(result) == 1
        assert TRANSACTION_CODE in result[0]
        assert CORPORATION_CODE in result[0]
        assert COMPANY_CODE_US in result[0]
        assert expected_rate in result[0]

    def test_transform_to_rk_transactions_format_error(self):
        # Invalid test data with missing required columns
        input_df = pd.DataFrame({
            'NATIONAL_ID': ['invalid'],  # Invalid SSN format
            'STATE_CODE': ['US'],
            'DOE_CODE': ['D1'],
            'STOP_IND': ['N'],
            'PERIOD_CODE': ['M'],
            'RATE': [10.5]
        })

        with pytest.raises(ValueError, match="invalid literal for int()"):
            self.writer.transform_to_rk_transactions_format(input_df)

    def test_fetch_win_ssn_mapping_success(self):
        self.writer.db2_connection = MagicMock()
        mock_data = [(123, '456789012')]
        self.writer.db2_connection.fetchall.return_value = mock_data

        result = self.writer.fetch_win_ssn_mapping('123')

        assert not result.empty
        assert list(result.columns) == ['WIN_NBR', 'NATIONAL_ID']
        assert result.iloc[0]['NATIONAL_ID'] == '456789012'

    def test_fetch_win_ssn_mapping_failure(self):
        self.writer.db2_connection = MagicMock()
        self.writer.db2_connection.fetchall.side_effect = Exception("Error while fetching WIN-National ID mapping")

        with pytest.raises(Exception, match="Error while fetching WIN-National ID mapping"):
            self.writer.fetch_win_ssn_mapping('123')

    @patch('src.retirement_plan.rk_transactions_writer.read_file_to_dataframe')
    def test_start_process_with_empty_dataframe(self, mock_read, mocker):
        mock_read.return_value = pd.DataFrame()
        self.writer.start_process()
        self.writer.logger.info.assert_any_call("Deduction driver output file is empty. No records to process.")
        self.writer.gcs_util.download_file.assert_called_once()
        mock_read.assert_called_once()