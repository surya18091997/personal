import unittest
from unittest.mock import patch, MagicMock
import pandas as pd

from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.rate_change_activity_transformer import RateChangeActivityTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.templates.data_objects.rate_change_activity_data_object import RateChangeActivityDataObject


class TestProcessSourceData(unittest.TestCase):
    """Test cases specifically for the _process_source_data method."""

    @patch('src.report_generator.transformer.BigQueryDatabase')
    @patch('src.report_generator.transformer.SparkSession')
    def setUp(self, mock_spark, mock_bigquery):
        """Set up test fixtures."""
        self.logger = MagicMock()
        self.config = TransformerConfig(
            output_file_name="test_rate_change_activity.txt",
            page_size=60,
            report_id="PS719702US"
        )
        # Configure mock BigQueryDatabase
        mock_bigquery_instance = MagicMock()
        mock_bigquery.return_value = mock_bigquery_instance
        
        # Configure mock SparkSession
        mock_spark_instance = MagicMock()
        mock_spark.builder.appName.return_value.config.return_value.getOrCreate.return_value = mock_spark_instance
        
        self.transformer = RateChangeActivityTransformer(self.config, ReportType.US, self.logger)
        
    def test_process_source_data_with_tuple_keys(self):
        """Test processing source data with tuple keys."""
        # Define test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary with tuple keys
        results_dict = {
            ('US', 'REG', 'WAL-MART'): {
                'enrolled': 5, 'changed_to_0': 2, 'decreased': 3, 'increased': 4, 'corrected': 1
            },
            ('US', 'CUC', 'WAL-MART'): {
                'enrolled': 0, 'changed_to_0': 1, 'decreased': 0, 'increased': 2, 'corrected': 0
            },
            ('PR', 'REG', 'WAL-MART'): {
                'enrolled': 3, 'changed_to_0': 1, 'decreased': 0, 'increased': 0, 'corrected': 0
            },
            ('PR', 'CUC', 'WAL-MART'): {
                'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0
            }
        }
        
        # Initialize empty results list and subtotals
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Verify results
        # Check total matches expected sum
        expected_total = 5 + 2 + 3 + 4 + 1 + 0 + 1 + 0 + 2 + 0 + 3 + 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0
        self.assertEqual(walmart_total, expected_total)
        
        # Check subtotals are correctly accumulated
        self.assertEqual(walmart_subtotal['enrolled'], 8)  # 5+0+3+0
        self.assertEqual(walmart_subtotal['changed_to_0'], 4)  # 2+1+1+0
        self.assertEqual(walmart_subtotal['decreased'], 3)  # 3+0+0+0
        self.assertEqual(walmart_subtotal['increased'], 6)  # 4+2+0+0
        self.assertEqual(walmart_subtotal['corrected'], 1)  # 1+0+0+0
        
        # Check that the results list contains 5 items (4 data rows + 1 subtotal)
        self.assertEqual(len(results), 5)
        
        # Check the first result item values
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 5)
        self.assertEqual(results[0].changed_to_0, 2)
        self.assertEqual(results[0].decreased, 3)
        self.assertEqual(results[0].increased, 4)
        self.assertEqual(results[0].corrected, 1)
        self.assertEqual(results[0].total, 15)  # 5+2+3+4+1
        
        # Check the subtotal row (last item)
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].enrolled, 8)
        self.assertEqual(results[4].changed_to_0, 4)
        self.assertEqual(results[4].decreased, 3)
        self.assertEqual(results[4].increased, 6)
        self.assertEqual(results[4].corrected, 1)
        self.assertEqual(results[4].total, 22)
        self.assertEqual(results[4].total_percentage, '000%')
        
    def test_process_source_data_with_string_keys(self):
        """Test processing source data with string keys - should create zeros as string keys are not supported."""
        # Define test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary with string keys (which won't be found by the method)
        results_dict = {
            "US_REG_WAL-MART": {
                'enrolled': 3, 'changed_to_0': 1, 'decreased': 2, 'increased': 1, 'corrected': 0
            },
            "US_CUC_WAL-MART": {
                'enrolled': 2, 'changed_to_0': 0, 'decreased': 1, 'increased': 0, 'corrected': 1
            },
            "PR_REG_WAL-MART": {
                'enrolled': 1, 'changed_to_0': 2, 'decreased': 0, 'increased': 0, 'corrected': 2
            },
            "PR_CUC_WAL-MART": {
                'enrolled': 0, 'changed_to_0': 1, 'decreased': 1, 'increased': 0, 'corrected': 0
            }
        }
        
        # Initialize empty results list and subtotals
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Verify results - since the method only works with tuple keys, expect zeros
        self.assertEqual(walmart_total, 0)
        
        # Check subtotals are all zero since string keys aren't supported
        self.assertEqual(walmart_subtotal['enrolled'], 0)
        self.assertEqual(walmart_subtotal['changed_to_0'], 0)
        self.assertEqual(walmart_subtotal['decreased'], 0)
        self.assertEqual(walmart_subtotal['increased'], 0)
        self.assertEqual(walmart_subtotal['corrected'], 0)
        
        # Check that the results list contains 5 items (4 data rows + 1 subtotal)
        self.assertEqual(len(results), 5)
        
        # Check the first result item values - all should be zero
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 0)
        self.assertEqual(results[0].changed_to_0, 0)
        self.assertEqual(results[0].decreased, 0)
        self.assertEqual(results[0].increased, 0)
        self.assertEqual(results[0].corrected, 0)
        self.assertEqual(results[0].total, 0)
        
    def test_process_source_data_when_key_not_found(self):
        """Test processing source data when keys are not found in results_dict."""
        # Define test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create an empty results dictionary
        results_dict = {}
        
        # Initialize empty results list and subtotals
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Verify results
        # Check total is zero because no data was found
        self.assertEqual(walmart_total, 0)
        
        # Check subtotals are all zero
        self.assertEqual(walmart_subtotal['enrolled'], 0)
        self.assertEqual(walmart_subtotal['changed_to_0'], 0)
        self.assertEqual(walmart_subtotal['decreased'], 0)
        self.assertEqual(walmart_subtotal['increased'], 0)
        self.assertEqual(walmart_subtotal['corrected'], 0)
        
        # Check that the results list contains 5 items (4 data rows with zeros + 1 subtotal)
        self.assertEqual(len(results), 5)
        
        # Check the first result item has zeros
        self.assertEqual(results[0].country_code, 'US')
        self.assertEqual(results[0].retirement_plan_type, 'REG')
        self.assertEqual(results[0].rate_change_source, 'WAL-MART')
        self.assertEqual(results[0].enrolled, 0)
        self.assertEqual(results[0].changed_to_0, 0)
        self.assertEqual(results[0].decreased, 0)
        self.assertEqual(results[0].increased, 0)
        self.assertEqual(results[0].corrected, 0)
        self.assertEqual(results[0].total, 0)
        
        # Check the subtotal row (last item) has zeros
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        self.assertEqual(results[4].rate_change_source, 'WAL-MART SUBTOTAL')
        self.assertEqual(results[4].enrolled, 0)
        self.assertEqual(results[4].changed_to_0, 0)
        self.assertEqual(results[4].decreased, 0)
        self.assertEqual(results[4].increased, 0)
        self.assertEqual(results[4].corrected, 0)
        self.assertEqual(results[4].total, 0)
        self.assertEqual(results[4].total_percentage, '000%')
        
    def test_process_source_data_with_mixed_keys(self):
        """Test processing source data with a mix of tuple and string keys (only tuple keys will be processed)."""
        # Define test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary with mixed key types
        results_dict = {
            ('US', 'REG', 'WAL-MART'): {
                'enrolled': 5, 'changed_to_0': 2, 'decreased': 3, 'increased': 4, 'corrected': 1
            },
            "US_CUC_WAL-MART": {  # String key - will be ignored
                'enrolled': 2, 'changed_to_0': 0, 'decreased': 1, 'increased': 0, 'corrected': 1
            },
            "PR_REG_WAL-MART": {  # String key - will be ignored
                'enrolled': 1, 'changed_to_0': 2, 'decreased': 0, 'increased': 0, 'corrected': 2
            },
            ('PR', 'CUC', 'WAL-MART'): {
                'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0
            }
        }
        
        # Initialize empty results list and subtotals
        results = []
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process data
        walmart_total = self.transformer._process_source_data(
            'WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results
        )
        
        # Only tuple keys should be processed, string keys will be ignored
        expected_total = 5 + 2 + 3 + 4 + 1 + 0 + 0 + 0 + 0 + 0  # Only from tuple keys
        self.assertEqual(walmart_total, expected_total)
        
        # Check subtotals are correctly accumulated (only for tuple keys)
        self.assertEqual(walmart_subtotal['enrolled'], 5)  # Just from ('US', 'REG', 'WAL-MART')
        self.assertEqual(walmart_subtotal['changed_to_0'], 2)
        self.assertEqual(walmart_subtotal['decreased'], 3)
        self.assertEqual(walmart_subtotal['increased'], 4)
        self.assertEqual(walmart_subtotal['corrected'], 1)
        
        # Check the subtotal row (last item)
        self.assertEqual(results[4].enrolled, 5)  # Only the tuple keys
        self.assertEqual(results[4].changed_to_0, 2)
        self.assertEqual(results[4].decreased, 3)
        self.assertEqual(results[4].increased, 4)
        self.assertEqual(results[4].corrected, 1)
        self.assertEqual(results[4].total, 15)
        
    def test_process_source_data_with_merrill_lynch_source(self):
        """Test processing source data with MERRILL LYNCH as the source."""
        # Define test data
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Create results dictionary
        results_dict = {
            ('US', 'REG', 'MERRILL LYNCH'): {
                'enrolled': 2, 'changed_to_0': 1, 'decreased': 0, 'increased': 3, 'corrected': 0
            },
            ('US', 'CUC', 'MERRILL LYNCH'): {
                'enrolled': 1, 'changed_to_0': 0, 'decreased': 1, 'increased': 0, 'corrected': 3
            },
            ('PR', 'REG', 'MERRILL LYNCH'): {
                'enrolled': 0, 'changed_to_0': 2, 'decreased': 1, 'increased': 1, 'corrected': 1
            },
            ('PR', 'CUC', 'MERRILL LYNCH'): {
                'enrolled': 2, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 2
            }
        }
        
        # Initialize empty results list and subtotals
        results = []
        merrill_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process data
        merrill_total = self.transformer._process_source_data(
            'MERRILL LYNCH', countries, plan_types, results_dict, merrill_subtotal, results
        )
        
        # Verify results
        # Check total matches expected sum
        expected_total = 2 + 1 + 0 + 3 + 0 + 1 + 0 + 1 + 0 + 3 + 0 + 2 + 1 + 1 + 1 + 2 + 0 + 0 + 0 + 2
        self.assertEqual(merrill_total, 20)
        
        # Check subtotals are correctly accumulated
        self.assertEqual(merrill_subtotal['enrolled'], 5)  # 2+1+0+2
        self.assertEqual(merrill_subtotal['changed_to_0'], 3)  # 1+0+2+0
        self.assertEqual(merrill_subtotal['decreased'], 2)  # 0+1+1+0
        self.assertEqual(merrill_subtotal['increased'], 4)  # 3+0+1+0
        self.assertEqual(merrill_subtotal['corrected'], 6)  # 0+3+1+2
        
        # Check the subtotal row (last item)
        self.assertEqual(results[4].country_code, '')
        self.assertEqual(results[4].retirement_plan_type, '')
        self.assertEqual(results[4].rate_change_source, 'MERRILL LYNCH SUBTOTAL')
        self.assertEqual(results[4].enrolled, 5)
        self.assertEqual(results[4].changed_to_0, 3)
        self.assertEqual(results[4].decreased, 2)
        self.assertEqual(results[4].increased, 4)
        self.assertEqual(results[4].corrected, 6)
        self.assertEqual(results[4].total, 20)
        self.assertEqual(results[4].total_percentage, '000%')


if __name__ == '__main__':
    unittest.main()
