# File: tests/test_retirement_plan/test_loan_outbound.py
import unittest
from unittest.mock import patch, MagicMock, Mock, mock_open
import pandas as pd
from datetime import datetime
import json
import os

# Import the LoanOutbound class from the project source
from src.retirement_plan.loan_outbound_file import LoanOutbound

class MockFileGenerator:
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        self.configuration_id = configuration_id
        self.logger = logger
        self.request_id = request_id
        self.start_date = start_date
        self.end_date = end_date
        self.request_id_dir = "/test/path"
        self.dest_file = "test_file.csv"
        self.gcp_connection = MagicMock()
        self.cosmos_connection = MagicMock()
        self.db2_connection = MagicMock()
        self.datalake_conn = MagicMock()
        self.bucket_name = "test-bucket"
        self.destination_folder = "test/path"


class TestLoanOutbound(unittest.TestCase):
    @patch('src.generate_file.file_generator.FileGenerator', MockFileGenerator)
    def setUp(self):
        # Patch configuration and file reading similar to RateChangeOutbound tests
        def mock_get_config_value(section, key=None):
            if section == "app":
                if key == "mongodb_connection_file_path":
                    return "/mock/path/mongodb_connection.json"
                elif key == "gcs_connection_file_path":
                    return "/mock/path/gcs_connection.json"
                elif key == "db2_connection_file_path":
                    return "/mock/path/db2_connection.yaml"
                elif key == "core_sql_api":
                    return "/mock/path/azure_ad.json"
                elif key == "core_sql_cosmos_url":
                    return "https://mock-cosmos-account.documents.azure.com:443/"
                else:
                    return "/tmp/test"
            elif section == "flow_config":
                return {
                    'flow_name': 'LOAN OUTBOUND',
                    'plan_number': '609450',
                    'plan_id': ['Regular', 'Catchup'],
                    'source_file_path': '',
                    'destination_file_path': 'test/path',
                    'bucket_name': 'test-bucket',
                    'gcp_project': 'test-project',
                    'bigquery_dataset': 'test-dataset'
                }
            elif section == "file_layout":
                return {
                    "static_col_record_set": {
                        "r56": {"R56-LOAN-REPAY-AMT": "", "R56-LOAN-NUMBER": "", "R56-PLAN-NUMBER": ""}
                    }
                }
            return None

        mock_yaml_content = """
        db2_region:
            db2_database: testdb
            db2_hostname: testhost
            db2_protocol: tcpip
            db2_userid: testuser
            db2_port: 50000
        """

        # for spark setup mock
        mock_datalake = Mock()

        self.patches = [
            patch('src.utils.app_config.get_config_value', side_effect=mock_get_config_value),
            patch('builtins.open', mock_open(read_data=mock_yaml_content)),
            patch('json.load', return_value={
                'primary': {
                    'expiryDate': '2025-12-31 23:59:59.999',
                    'secText': 'primary_secret'
                },
                'secondary': {
                    'expiryDate': '2025-12-31 23:59:59.999',
                    'secText': 'secondary_secret'
                },
                'spnTenantId': '12345678-1234-5678-1234-567812345678',
                'spnClientId': '87654321-8765-4321-8765-432187654321'
            }),
            patch('src.integrations.cosmos_utils.ClientSecretCredential', return_value=Mock()),
            patch('src.integrations.cosmos_utils.CosmosClient', return_value=Mock()),
            patch('ibm_db.connect', return_value=Mock()),
            patch('ibm_db_dbi.connect', return_value=Mock()),
            patch('google.cloud.bigquery.Client', return_value=Mock()),
            patch('os.path.exists', return_value=True),
            patch('os.makedirs', return_value=True),
            patch('os.path.join', return_value='/mock/path'),
            patch('os.path.isdir', return_value=True),
            patch('src.integrations.gcs_utils.GCSUtils.upload_folder', return_value=True),
            patch('src.integrations.datalake_hudi_conn.DataLakeHudiUtils', MagicMock(return_value=mock_datalake)),
            patch('src.generate_file.file_generator.DataLakeHudiUtils', MagicMock(return_value=mock_datalake)),
            patch('src.integrations.datalake_hudi_conn.DataLakeHudiUtils.get_hudi_data', return_value=mock_datalake),
        ]
        for patcher in self.patches:
            patcher.start()
            self.addCleanup(patcher.stop)
        self.configuration_id = 1
        self.logger = MagicMock()
        self.request_id = "loan_req_123"
        self.start_date = datetime(2023, 1, 1)
        self.end_date = datetime(2023, 12, 31)
        self.loan_outbound = LoanOutbound(self.configuration_id, self.logger, self.request_id, self.start_date, self.end_date)

    # @patch('src.retirement_plan.loan_outbound_file.update_request_status')
    # def test_start_process_completes_successfully(self, mock_update_status):
    #     # Set up mocks for methods used in start_process
    #     self.loan_outbound.create_working_directory = MagicMock()
    #     self.loan_outbound.get_transaction_logs_with_comments = MagicMock(return_value=[
    #         {'associateId': '123', 'comments': 'GEN LOAN SEQENCE NO: 001'}
    #     ])
    #     self.loan_outbound.get_associate_info = MagicMock(return_value=pd.DataFrame())
    #     self.loan_outbound.process_core_hr_df = MagicMock(return_value=pd.DataFrame())
    #     self.loan_outbound.generate_record_dict = MagicMock(return_value={})
    #     self.loan_outbound.apply_loan_specific_updates = MagicMock(return_value={})
    #     self.loan_outbound.apply_plan_detail_attributes = MagicMock(return_value={})
    #     self.loan_outbound.initiate_flat_file_generation = MagicMock()
    #     self.loan_outbound.transfer_file_to_gcs = MagicMock()
    #     # Call start_process
    #     self.loan_outbound.start_process()
    #     # Assert methods were called
    #     self.loan_outbound.create_working_directory.assert_called_once_with(self.request_id)
    #     self.loan_outbound.get_transaction_logs_with_comments.assert_called_once()
    #     self.loan_outbound.get_associate_info.assert_called_once()
    #     self.loan_outbound.process_core_hr_df.assert_called_once()
    #     self.loan_outbound.generate_record_dict.assert_called_once()
    #     self.loan_outbound.apply_loan_specific_updates.assert_called_once()
    #     self.loan_outbound.apply_plan_detail_attributes.assert_called_once()
    #     self.loan_outbound.initiate_flat_file_generation.assert_called_once()
    #     self.loan_outbound.transfer_file_to_gcs.assert_called_once()
    #     mock_update_status.assert_called_once_with(self.request_id, 'COMPLETED', self.logger)
    #
    # @patch('src.retirement_plan.loan_outbound_file.update_request_status')
    # def test_start_process_handles_exception(self, mock_update_status):
    #     self.loan_outbound.create_working_directory = MagicMock()
    #     self.loan_outbound.get_transaction_logs_with_comments = MagicMock(side_effect=Exception("Test exception"))
    #     with self.assertRaises(Exception):
    #         self.loan_outbound.start_process()
    #     self.loan_outbound.create_working_directory.assert_called_once_with(self.request_id)
    #     self.loan_outbound.get_transaction_logs_with_comments.assert_called_once()
    #     mock_update_status.assert_called_once_with(self.request_id, 'ERROR', self.logger, 'Test exception')

    def test_apply_loan_specific_updates_applies_correctly(self):
        # Create a simple DataFrame for r56 records
        loan_df = pd.DataFrame([{'associate_id': '123'}])
        record_dict = {'r56': loan_df.copy()}
        loan_transaction_data = pd.DataFrame([{'associateId': '123',
                                               'sequence_number': '123',
                                               'loanIndicator': 1,
                                               'doe_code': 1,
                                               'loanSequenceNumber': '001',
                                               'NATIONAL_ID': '123',
                                               }])
        # Simulate GCP loan data: doe_amt of 100.0 converts to 10000 in cents and zero filled to 9 characters
        gcp_loan_df = pd.DataFrame([{'win_nbr': 123, 'doe_amt': 100.0, 'doe_code': 1, 'record_type': 'test'}])
        self.loan_outbound.fetch_loan_data_from_gcp = MagicMock(return_value=gcp_loan_df)
        updated_dict = self.loan_outbound.apply_loan_specific_updates(record_dict, loan_transaction_data)
        self.assertEqual(updated_dict['r56'].iloc[0]['R56-LOAN-REPAY-AMT'], '000010000')
        self.assertEqual(updated_dict['r56'].iloc[0]['R56-LOAN-NUMBER'], '001')
        self.assertEqual(updated_dict['r56'].iloc[0]['R56-PLAN-NUMBER'], self.loan_outbound.plan_number)

    def test_fetch_loan_data_from_gcp_empty_list(self):
        # Return an empty DataFrame when associate list is empty
        result = self.loan_outbound.fetch_loan_data_from_gcp([])
        self.assertTrue(result.empty)

    def test_fetch_loan_data_from_gcp_numeric_ids(self):
        # Setup: when IDs are numeric, they should not be quoted in the query
        self.loan_outbound.gcp_connection.get_df_from_query = MagicMock(return_value=pd.DataFrame())
        self.loan_outbound.flow_config = {"gcp_project": "test-project", "bigquery_dataset": "test-dataset"}
        self.loan_outbound.fetch_loan_data_from_gcp([123, 456])
        query_arg = self.loan_outbound.gcp_connection.get_df_from_query.call_args[0][0]
        self.assertIn("123,456", query_arg)
        self.assertNotIn("123','456", query_arg)

    def test_fetch_loan_data_from_gcp_string_ids(self):
        # Setup: when IDs are strings, they should be quoted in the query
        self.loan_outbound.gcp_connection.get_df_from_query = MagicMock(return_value=pd.DataFrame())
        self.loan_outbound.flow_config = {"gcp_project": "test-project", "bigquery_dataset": "test-dataset"}
        self.loan_outbound.fetch_loan_data_from_gcp(['A123', 'B456'])
        query_arg = self.loan_outbound.gcp_connection.get_df_from_query.call_args[0][0]
        self.assertIn("'A123','B456'", query_arg)

    def test_fetch_loan_data_from_gcp_missing_config(self):
        # Test missing configuration raises error
        self.loan_outbound.flow_config = {}
        with self.assertRaises(ValueError):
            self.loan_outbound.fetch_loan_data_from_gcp(['123'])

if __name__ == '__main__':
    unittest.main()