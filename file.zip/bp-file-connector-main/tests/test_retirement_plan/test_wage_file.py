import sys
import json
import logging
from unittest.mock import Mock, patch, mock_open, MagicMock
import pytest
from datetime import datetime
import pandas as pd
from contextlib import ExitStack

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

from src.generate_file.file_generator import FileGenerator
from src.retirement_plan.wage_file import WageFile
from src.constants import FG_INITIALIZE, F_ERROR
from src.utils.errors.app_errors import ApplicationError
from src.integrations.db2_conn_helper import DB2IDatabase


class MockFileGenerator(FileGenerator):
    """Mock FileGenerator for testing"""
    def __init__(self, configuration_id, logger_instance, request_id, start_date, end_date):
        self.logger = logger_instance
        self.logger.info(FG_INITIALIZE)
        self.configuration_id = configuration_id
        self.request_id = request_id
        self.start_date = start_date
        self.end_date = end_date
        self.flow_name = "WAGE_FILE"
        self.dest_file = "output.txt"
        self.destination_file_path = "test/path"
        self.plan_number = None
        self.plan_file = None
        self.primary_key = None
        self.bucket_name = "test-bucket"
        self.file_gen_func = None
        self.record_types = None
        self.request_id_dir = "/test/working/dir/test-request"
        self.source_file_path = None
        self.plan_stat_code = None
        self.region = None
        self.plan_id = []
        self.gcp_connection = Mock()


class TestWageFile:
    @pytest.fixture
    def mock_logger(self):
        return Mock()

    @pytest.fixture
    def mock_config_dict(self):
        """Configuration dictionary for testing"""
        return {
            "app": {
                "working_dir": "/test/working/dir",
                "gcs_connection_file_path": "/mock/path/gcs_connection.json",
                "mongodb_connection_file_path": "/mock/path/mongodb_connection.json",
                "db2_connection_file_path": "/mock/path/db2_connection.yaml",
            },
            "flow_config": {
                "21": {
                    "flow_name": "WAGE_FILE",
                    "dest_file": "output.txt",
                    "source_file_path": "",
                    "destination_file_path": "test/path",
                    "bucket_name": "test-bucket",
                    "gcp_project": "test-project",
                    "bigquery_dataset": "test_dataset",
                    "row_limit": "1000",
                    "batch_size": "500",
                    "doe_codes": "'01','02'",
                    "earn_type_codes": "1,2",
                    "plan_id": [],
                }
            }
        }

    @pytest.fixture
    def mock_configuration(self, mock_config_dict):
        """Create mock configuration getter"""

        def get_config_value(section, key=None):
            logger.debug(f"Getting config: section={section}, key={key}")
            if section == "app":
                return mock_config_dict["app"].get(key)
            elif section == "flow_config":
                return mock_config_dict["flow_config"].get(key)
            return None

        return get_config_value

    @pytest.fixture(autouse=True)
    def setup(self, mock_logger, mock_configuration, mock_config_dict):
        """Setup test fixtures"""
        logger.debug("Setting up test fixtures")

        mock_file_contents = {
            '/mock/path/gcs_connection.json': json.dumps({"project_id": "test-project"}),
            '/mock/path/db2_connection.yaml': """
                db2_region:
                    db2_database: testdb
                    db2_hostname: testhost
                    db2_protocol: tcpip
                    db2_userid: testuser
                    db2_port: 50000
                    db2_testset: TEST
            """
        }

        def mock_file_open(filename, mode='r', encoding=None):
            logger.debug(f"Mock opening file: {filename}")
            content = mock_file_contents.get(filename, '')
            return mock_open(read_data=content).return_value

        with ExitStack() as stack:
            # Setup patches
            stack.enter_context(patch('src.utils.app_config.get_config_value', side_effect=mock_configuration))
            stack.enter_context(patch('builtins.open', side_effect=mock_file_open))
            stack.enter_context(patch('os.path.exists', return_value=True))
            stack.enter_context(patch('os.makedirs', return_value=True))
            stack.enter_context(patch('src.retirement_plan.wage_file.FileGenerator', MockFileGenerator))

            # Mock DB2 Database
            mock_db2 = MagicMock(spec=DB2IDatabase)
            mock_db2.testset = 'TEST'
            stack.enter_context(patch('src.integrations.db2_conn_helper.DB2IDatabase', return_value=mock_db2))

            # Initialize test object
            self.wage_file = WageFile(
                configuration_id=21,
                logger=mock_logger,
                request_id="test-request",
                start_date=datetime(2024, 1, 1)
            )

    # def test_get_max_run_date(self, mock_logger):
    #     """Test getting max run date from BigQuery"""
    #     mock_df = pd.DataFrame({'max_date': [datetime(2024, 1, 1)]})
    #
    #     with patch.object(self.wage_file.gcp_connection, 'get_df_from_query', return_value=mock_df):
    #         result = self.wage_file.get_max_run_date()
    #         assert result == datetime(2024, 1, 1)
    #
    # def test_start_process(self, mock_logger):
    #     """Test the full process flow"""
    #     # Set required attributes
    #     self.wage_file.dest_file = "output.txt"
    #     self.wage_file.request_id_dir = "/test/working/dir/test-request"
    #
    #     with patch.multiple(
    #             self.wage_file,
    #             create_working_directory=Mock(),
    #             _ensure_empty_file_exists=Mock(),
    #             transfer_file_to_gcs=Mock()
    #     ):
    #         # Mock BigQuery processing
    #         mock_gcp_connection = Mock()
    #         mock_gcp_connection.fetch_and_write_data.return_value = 100
    #         self.wage_file.gcp_connection = mock_gcp_connection
    #
    #         total_records = self.wage_file.start_process()
    #
    #         assert total_records == 100
    #         self.wage_file.create_working_directory.assert_called_once()
    #         self.wage_file._ensure_empty_file_exists.assert_called_once()
    #         self.wage_file.transfer_file_to_gcs.assert_called_once()
    #
    # def test_init_configuration_error(self, mock_logger, mock_config_dict):
    #     """Test error handling during initialization when configuration fails"""
    #     # Patch config to throw an error during initialization
    #     with patch('src.utils.app_config.get_config_value', side_effect=Exception("Config error")):
    #         with pytest.raises(ApplicationError) as exc_info:
    #             WageFile(21, mock_logger, "test-request", datetime(2024, 1, 1))
    #
    #         # Verify error message and logging
    #         assert "Error loading wage file configuration" in str(exc_info.value)
    #         mock_logger.error.assert_called()
    #
    # def test_start_process_error_handling(self, mock_logger):
    #     """Test error handling in start_process when an exception occurs"""
    #     # Set required attributes
    #     self.wage_file.request_id = "test-request"
    #     self.wage_file.logger = mock_logger
    #     self.wage_file.request_id_dir = "/test/path"
    #     self.wage_file.dest_file = "test.txt"
    #     self.wage_file.flow_config = {
    #         "plan_number": "12345",
    #         "bucket_name": "test-bucket",
    #         "destination_file_path": "/test/dest"
    #     }
    #
    #     # Reset mock_logger to clear previous calls
    #     mock_logger.reset_mock()
    #
    #     # Mock create_working_directory to avoid directory creation error
    #     with patch.multiple(
    #             self.wage_file,
    #             create_working_directory=Mock(),
    #             _ensure_empty_file_exists=Mock()
    #     ):
    #         # Mock GCP connection to raise an error
    #         mock_gcp = Mock()
    #         mock_gcp.fetch_and_write_data = Mock(side_effect=Exception("Test error"))
    #         self.wage_file.gcp_connection = mock_gcp
    #
    #         # Mock update_request_status function
    #         with patch('src.retirement_plan.wage_file.update_request_status') as mock_update_status:
    #             # Execute and verify
    #             with pytest.raises(ApplicationError) as exc_info:
    #                 self.wage_file.start_process()
    #
    #             # Verify error was logged
    #             mock_logger.error.assert_called_once()
    #
    #             # Verify request status was updated
    #             mock_update_status.assert_called_once_with(
    #                 "test-request",
    #                 F_ERROR,
    #                 mock_logger,
    #                 "Test error"
    #             )
    #
    #             # Verify correct error was raised
    #             assert "Error generating wage file" in str(exc_info.value)
    #
    # def test_get_max_run_date_error(self, mock_logger):
    #     """Test error handling in get_max_run_date when query fails"""
    #     # Setup required attributes
    #     self.wage_file.gcp_connection = Mock()
    #     self.wage_file.gcp_project = "test-project"
    #     self.wage_file.bigquery_dataset = "test_dataset"
    #     self.wage_file.gcp_connection.get_df_from_query = Mock(side_effect=Exception("Query failed"))
    #
    #     # Execute and verify
    #     with pytest.raises(ApplicationError) as exc_info:
    #         self.wage_file.get_max_run_date()
    #
    #     # Verify exact error message
    #     assert "Invalid or missing run date: Query failed" in str(exc_info.value)
    #     assert "APP0002" in str(exc_info.value)  # Verify error code