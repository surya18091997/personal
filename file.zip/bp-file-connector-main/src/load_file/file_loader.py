from src.file_connector.file_transfer import file_transfer
from src.integrations.db2_conn_helper import DB2IDatabase
from src.integrations.gcs_utils import GCSUtils
from src.utils import app_config


class FileLoader:

    def __init__(self, configuration_id, logger, request_id):
        """
        Initialize the FileLoader with a configuration ID, logger, request ID.
        Also sets up utilities for DB2, Google Cloud Storage (GCS) and file transfer.
        """
        try:
            self.request_id = request_id
            self.bucket_name = None
            self.flow_name = None
            self.source_file_path = None
            self.output_table_name = None
            self.logger = logger
            self.db2_connection = DB2IDatabase(logger=logger)
            self.db2_region = self.db2_connection.testset
            self.gcs_util = GCSUtils(logger)  # GCS utility
            self.ft = file_transfer(self.logger)  # File transfer utility
            self.set_file_flow_config_parameters(configuration_id)
            self.cwd = app_config.get_config_value("app", "working_dir")
        except Exception as e:
            self.logger.error(f'Error initialising FileLoader {e}')

    def set_file_flow_config_parameters(self, configuration_id):
        """
        Set the file flow configuration parameters based on the provided configuration ID.

        Parameters:
            configuration_id (int): The ID of the configuration to retrieve.

        Returns:
            None
        """
        try:
            flow_config = app_config.get_config_value("flow_config", str(configuration_id))
            self.flow_name = flow_config["flow_name"]
            self.source_file_path = flow_config["source_file_path"]
            self.bucket_name = flow_config["bucket_name"]
            self.output_table_name = flow_config["output_table_name"]
            self.logger.info(f'Flow Configuration details are retrieved {flow_config}')
        except Exception as e:
            self.logger.error(f'Error while retrieving flow configuration details {e}')
            raise e # Raising exception to end the flow if required configurations are not present in flow_config

