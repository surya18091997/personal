from src.constants import INVALID_CONFIGURATION_ID
from src.retirement_plan.ContributionOutbound import ContributionOutbound
from src.retirement_plan.eligibility_file import Eligibility
from src.retirement_plan.hardship_inbound import HardshipInbound
from src.retirement_plan.hours_file import HoursFile
from src.retirement_plan.hours_file_outbound import HoursOutboundFile
from src.retirement_plan.loan_inbound import LoanInbound
from src.retirement_plan.loan_outbound_file import LoanOutbound
from src.retirement_plan.rate_change_file import RateChange
from src.retirement_plan.rate_change_outbound_file import RateChangeOutbound
from src.retirement_plan.rehire_data_lake_files import RehireDataLakeUnload
from src.retirement_plan.rk_transactions_writer import RKTransactionWriter
from src.retirement_plan.state_transfer_file import StateTransfer
from src.retirement_plan.term_file import TerminationOutbound
from src.retirement_plan.wage_file import WageFile
from src.retirement_plan.payroll_transactions_writer import PayrollTransactionsWriter
from src.disability.hri_file_generator.hri_file_generator_biweekly import HRIFileGeneratorBiweekly
from src.disability.hri_file_generator.get_hri_pre_dependencies import FetchHRIPreDependencies
from src.data_extract_domain.benefits_hudi_data_extract import BenefitsHudiDataExtract
from typing import Union


class FileProcessorFactory:
    _generator_map = {
        1: Eligibility, #Eligibility_US
        4: Eligibility, #Eligibility_PR
        'Eligibility': Eligibility,
        2: StateTransfer, #StateTransfer_US
        3: StateTransfer, #StateTransfer_PR
        'StateTransfer': StateTransfer,
        5: Eligibility,  # Rehire_US
        6: Eligibility,  # Rehire_PR
        11: RateChange,  # RateChange_Inbound
        32: LoanInbound,  # LoanUS
        40: LoanInbound,  # LoanPR
        12: RateChangeOutbound, #RateChange_US
        13: RateChangeOutbound, #RateChange_PR
        'RateChangeOutbound': RateChangeOutbound,
        14: TerminationOutbound,  # TerminationOutbound_US
        15: TerminationOutbound,  # TerminationOutbound_PR
        'TerminationOutbound': TerminationOutbound,
        33: LoanOutbound,  # LoanOutbound_US
        34: LoanOutbound,  # LoanOutbound_PR
        35: LoanOutbound,  # LoanOutbound_WV
        'LoanOutbound': LoanOutbound,
        16 : HRIFileGeneratorBiweekly,
        18 : FetchHRIPreDependencies,
        41: HardshipInbound,
        42: HardshipInbound,
        50: RehireDataLakeUnload
    }

    _loader_map = {
        31: PayrollTransactionsWriter,
        36: RKTransactionWriter
    }

    _run_date_map = {
        21: WageFile,  # WageFile
        22: HoursFile,
        'WageFile': WageFile,
        'HoursFile': HoursFile,
        23: HoursOutboundFile,
        'HoursOutboundFile': HoursOutboundFile,
        43: ContributionOutbound,  # ContributionOutbound_US
        44: ContributionOutbound,  # ContributionOutbound_PR
        45: ContributionOutbound,  # ContributionOutbound_WV
        46: ContributionOutbound,  # ContributionOutbound_NY
        'LoanOutbound': LoanOutbound,
    }

    _data_file_extract_map = {
        101: BenefitsHudiDataExtract,
        'BenefitsHudiDataExtract': BenefitsHudiDataExtract
    }

    @staticmethod
    def create_processor(configuration_id: Union[int, str], logger, request_id, start_date=None, end_date=None, data=None):
        if configuration_id in FileProcessorFactory._generator_map:
            generator_class = FileProcessorFactory._generator_map[configuration_id]
            logger.debug("Generator class: {}".format(generator_class))
            return generator_class(configuration_id, logger, request_id, start_date, end_date)
        elif configuration_id in FileProcessorFactory._loader_map:
            loader_class = FileProcessorFactory._loader_map[configuration_id]
            logger.debug("Loader class: {}".format(loader_class))
            return loader_class(configuration_id, logger, request_id)
        elif configuration_id in FileProcessorFactory._run_date_map:
            run_date_class = FileProcessorFactory._run_date_map[configuration_id]
            logger.debug("Run date class: {}".format(run_date_class))
            return run_date_class(configuration_id, logger, request_id, start_date)
        elif configuration_id in FileProcessorFactory._data_file_extract_map:
            data_file_extract_class = FileProcessorFactory._data_file_extract_map[configuration_id]
            logger.debug("data extract class: {}".format(data_file_extract_class))
            return data_file_extract_class(configuration_id, logger, request_id, data)
        else:
            logger.error(INVALID_CONFIGURATION_ID.format(configuration_id=configuration_id))
            raise ValueError(INVALID_CONFIGURATION_ID.format(configuration_id=configuration_id))
