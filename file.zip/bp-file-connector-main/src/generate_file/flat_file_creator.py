import pandas as pd
from datetime import datetime
from src.constants import F_ERROR, FF_FP_CLOSED_FOR_WRITING, FG_EMPTY_FILE_INFO, DEF_FLAT_LINE_LENGTH, \
    STATE_TRANSFER_FILE
from src.utils.common_utils import update_request_status
class gen_flat_file:


    def __init__(self, file_path, invalid_records_path, layouts, logger, max_line_length = DEF_FLAT_LINE_LENGTH):
        self.request_id = None
        self.file_path = file_path
        self.invalid_records_path = invalid_records_path
        self.file_pointer = None
        self.invalid_records = None
        self.logger = logger
        # Define the layout mapping with columns appearing in multiple places
        self.layouts = layouts
        self.max_line_length = max_line_length

    """
    Open the files specified by `self.file_path` and `self.invalid_records_path` in append mode.

    This function initializes the `self.file_pointer` and `self.invalid_records` attributes
    by opening the files specified by `self.file_path` and `self.invalid_records_path`
    respectively in append mode.

    Parameters:
        self (gen_flat_file): The instance of the `gen_flat_file` class.

    Returns:
        None
    """
    def open_files(self):
        self.file_pointer = open(self.file_path, 'a')
        self.invalid_records = open(self.invalid_records_path, 'a')  # Open the invalid records log

        self.logger.info("Files opened for writing")

    """
    Close the file pointers for the file and the invalid records file.

    This function checks if the `file_pointer` and `invalid_records` attributes are not `None`,
    and if so, it closes them.

    Parameters:
        None

    Returns:
        None
    """
    def close_files(self):
        if self.file_pointer:
            self.file_pointer.close()
        if self.invalid_records:
            self.invalid_records.close()

        self.logger.info(FF_FP_CLOSED_FOR_WRITING)

    """
        This will prepare a dictionary of sets for fast id lookup
    """
    def prepare_id_sets(self, dataframes_dict, primary_key="associate_id"):
        try:
            """Preprocess dataframes to create a dictionary of sets for fast id lookup."""
            id_sets = {df_type: set(df[primary_key].astype(str)) for df_type, df in dataframes_dict.items()}
            return id_sets
        except Exception as err:
            self.logger.error(f"Exception in prepare_id_sets method: {err}")

    """
        This will create the header output record for eligibility file
    """
    def write_header(self, plan_number, file_type, file_data_type, file_filler, payroll_end_date):

        try:
            self.logger.info("Inside write_header method")
            #Get Current Date
            current_date = datetime.now()
            latest_payroll_date = payroll_end_date
            # Company code
            company_code = "  00" if file_type != STATE_TRANSFER_FILE else "    "
            # Format the Header Record
            header_str = ("UHDR " + latest_payroll_date.strftime("%Y%j") + str(plan_number).ljust(6," ") +
                          file_type.ljust(20," ") + current_date.strftime("%H%M%S") + latest_payroll_date.strftime("%m%d%y") +
                          company_code + file_filler.ljust(124, " ") + file_data_type + (" " * 142))

            self.file_pointer.write(header_str + '\n')
            self.logger.info("Header record written successfully")

        except Exception as err:
            self.logger.error(f"Exception in write_header method: {err}")

    """
    Writes the trailer record to the file.
    The record contains the count of each record type
    The record count is updated in the respective record type in trailer record mapping
    Parameters:
        row_count_dict (dict): A dictionary containing the count of each record type.

    Returns:
        None
    """
    def write_trailer(self, row_count_dict, file_type):
        try:
            self.logger.info("Inside write_trailer method")
            layout = self.layouts['trailer_record']
            fixed_length_row = [' '] * 250  # 250 is the max length of the line

            if file_type == STATE_TRANSFER_FILE:
                layout['R99-BT-BASIC-SOURCE']['default'] = ""
            # Fill the positions based on the layout
            for col, data in layout.items():
                default_value = data['default']
                for (start, end) in data['positions']:
                    fixed_length_row[start:end] = default_value

            total_record_count = sum(row_count_dict.values()) + 2
            total_record_count_str = str(total_record_count).rjust(8, '0')
            fixed_length_row[5:13] = total_record_count_str

            # Override the default values based on the row_count_dict
            for row_key, row_value in row_count_dict.items():
                for col, data in layout.items():
                    if 'TOTAL-' + row_key.upper() in col:
                        value = str(row_value).rjust(8, '0')
                        for (start, end) in data['positions']:
                            fixed_length_row[start:end] = value

            # Write the fixed-length row to the file
            self.file_pointer.write(''.join(fixed_length_row) + '\n')
            self.logger.info("Trailer record written successfully")

        except Exception as e:
            self.logger.error(f"Exception in write_trailer method: {e}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))


    """
    Writes the record types to the file.

    Parameters:
        dataframes_dict (dict): A dictionary of dataframes, where the keys are the record types and the values are the dataframes.
        primary_key (str): The name of the column to use as the primary key.

    Returns:
        dict: A dictionary containing the count of each record type.
    """
    def write_record_types(self, dataframes_dict, primary_key):
        try:
            self.logger.info("Inside write_record_types method")

            if all(df.empty for df in dataframes_dict.values()):
                self.logger.info(FG_EMPTY_FILE_INFO)
                return {key: 0 for key in dataframes_dict.keys()}

            valid_count = 0
            # Find the unique ids by taking all the unique 'id' values across all dataframes
            all_ids = pd.concat([df[primary_key].astype(str) for df in dataframes_dict.values()]).unique()

            # Preprocess the dataframes into sets of ids for fast lookup
            id_sets = self.prepare_id_sets(dataframes_dict, primary_key)

            df_list = []

            # For each id, check if it exists in all dataframes
            for associate_id in all_ids:
                missing_from = []
                present_in = []

                # Check if the associate information is available in all the record type dataframes
                for df_type, id_set in id_sets.items():
                    if associate_id not in id_set:
                        missing_from.append(df_type)
                    else:
                        present_in.append(df_type)
                self.logger.debug(f'Check for the missing data from all the record types for {associate_id}')

                # If the associate id is missing then do not include in the file.
                if missing_from:
                    # Log to the invalid_records if the ID is missing from some dataframes
                    self.invalid_records.write(
                        f"ID {associate_id} is missing from: {', '.join(missing_from)}. Present in: {', '.join(present_in)}\n"
                    )
                else:
                    valid_count += 1

                    # Process the ID and write to the flat file if present in all dataframes
                    for df_type, df in dataframes_dict.items():
                        layout = self.layouts[df_type]
                        # Filter the dataframe to get the rows for the current associate_id
                        df_filtered = df[df[primary_key].astype(str) == associate_id]
                        # Generate the fixed-length row for the filtered dataframe
                        df_filtered = df_filtered.apply(
                            lambda row: self.generate_fixed_length_row(row, layout),
                            axis=1
                        )
                        df_list.append(df_filtered)

            if df_list:
                df_combined = pd.concat(df_list)
                for value in df_combined.values:
                    self.file_pointer.write(str(value) + '\n')

            self.logger.info(f"{valid_count} valid records written to file")
            self.logger.info("Record types written successfully")
            # Create a row count dictionary for each record type, this will be used to write the trailer record
            row_count_dict = {key: valid_count for key in dataframes_dict.keys()}
            return row_count_dict

        except Exception as e:
            self.logger.error(f"Exception in write_record_types method: {e}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            # Add any necessary error handling or logging here
            return {key: 0 for key in dataframes_dict.keys()}

    """
    Generates a fixed-length row based on the given row and layout.

    Args:
        row (dict): A dictionary representing the row data.
        layout (dict): A dictionary representing the layout of the fixed-length row.

    Returns:
        str: The generated fixed-length row.
    """
    def generate_fixed_length_row(self, row, layout):
        try:
            fixed_length_row = [' '] * self.max_line_length 
            for col, positions in layout.items():
                value = str(row[col])
                # Place the same column value in multiple positions
                for (start, end) in positions:
                    fixed_length_row[start:end] = value.ljust(end - start)[:end - start]

            self.logger.debug(f'Fixed length row generated successfully for the row {row}')
            return ''.join(fixed_length_row)
        except Exception as e:
            self.logger.error(f"Exception in generate_fixed_length_row method: {e}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))

    """
    Starts the process of generating a flat file.

    Args:
        dataframes_dict (dict): A dictionary of dataframes.
        plan_number (int): The plan number.
        file_type (str): The type of the file.
        primary_key (str): The primary key.

    Returns:
        None
    """
    def start_process(self, dataframes_dict, plan_number, file_type, file_data_type, file_filler, payroll_end_date, primary_key):
        try:

            # Open files globally
            self.open_files()

            # Write header
            self.write_header(plan_number, file_type, file_data_type, file_filler, payroll_end_date)

            # Write flat file using the provided dataframes
            row_count_dict = self.write_record_types(dataframes_dict, primary_key)

            # Write trailer
            self.write_trailer(row_count_dict, file_type)

            # Close the files after writing is complete
            self.close_files()

        except Exception as e:
            self.logger.error(f"Exception in start_process method: {e}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))

