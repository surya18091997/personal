from src.constants import F_ERROR, FG_INSTANCE_CREATED, FG_INITIALIZE, CFG_FLOW_CONFIG_RETRIEVED, CFG_FLOW_NAME, \
    CFG_DEST_FILE, CFG_PLAN_NUMBER, CFG_PLAN_FILE, CFG_SOURCE_FILE_PATH, CFG_DESTINATION_FILE_PATH, CFG_PRIMARY_KEY, \
    CFG_BUCKET_NAME, CFG_FILE_GEN_FUNC, CFG_RECORD_TYPES, CFG_REGION, CFG_PLAN_STAT_CODE, CFG_FLOW_CONFIG_ERROR, \
    FG_CREATE_W_DIR, APP_NAME, CFG_WORKING_DIR, FG_W_DIR_CREATED, FG_W_DIR_CREATE_ERROR, FG_FILE_GEN_COSMOS, \
    FG_FILE_FROM_COSMOS_CREATED, FG_FILE_COSMOS_ERROR, FG_STR_FILE_STARTED, FG_STR_EMPTY_FILE, FG_DIV_NBR_EMPTY, \
    FG_FILE_DB2_START, FG_FILE_DB2_CREATED, FG_FILE_DB2_ERROR, FG_DIV_NBR_SUCCESS, FG_DIV_STR_MAP, FG_TX_LOG_ST_DT, \
    FG_TX_LOG_END_DT, FG_NO_ASSOC_DATA, FG_CORE_HR_DATA_NOT_AVAILABLE, DB2_EMPTY_RESULT, FG_RECORD_TYPE_GENERATED, \
    FG_DF_FILLED, FG_INVALID_RECORDS, CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT, FG_FLAT_FILE_GEN_PROCESS, \
    FILE_TRANSFER_TO_GCS, FILE_TRANSFER_SUCCESS, MF_FILE_DOWNLOADED, MF_FILE_DOWNLOAD_ERROR, FG_GEN_PROCESS_START, \
    CONSENT_FETCH_ERROR, PLAN_ATTRIBUTE_ERROR, CONSENT_PROCESS_ERROR, \
    CONSENT_ASSOCIATE_ERROR, MISSING_CONSENT_ERROR, PLAN_TYPE, CONTRIBUTION_DATA_FETCH, CONTRIBUTION_DATA_EMPTY, \
    CONTRIBUTION_FETCH_ERROR, CONTRIBUTION_DATA_MISSING, CONTRIBUTION_FORMAT_INVALID, \
    CONTRIBUTION_PROCESS_ERROR, DATE_FORMAT_YYYY_MM_DD, PG_SQL_MAX_RECORD, BATCH_SIZE, FLOW_NAME_RE_HIRE_BASE, \
    REHIRE_CREDIT_IND, LOAN_WV_CONDITION, DEF_FLAT_LINE_LENGTH, CFG_DEST_FILE_PATH_MF, CFG_FILE_DATA_TYPE, \
    CFG_FILE_FILLER, DEF_HOURS_SERVICE, DEF_YEARS_OF_SERVICE, REGION_PR, REGION_US
from src.file_connector.file_transfer import file_transfer
from src.integrations.bigquery_conn import BigQueryDatabase
from src.integrations.cosmos_utils import CosmosUtils
from src.integrations.db2_conn_helper import DB2IDatabase
from src.integrations.postgre_sql_conn_helper import PostgresGCPConnection
from src.integrations.datalake_hudi_conn import DataLakeHudiUtils
from src.utils.errors.app_errors import ApplicationError, ConsentFetchError, ConsentProcessError, PlanAttributeError
from src.utils.errors.db2_errors import DatabaseError
from src.utils.sql import (ASSOCIATE_INFO, DIVISION_NUMBER_QUERY, EXPERIENCE_YEARS_QUERY, PAYPERIOD_END_DATE_QUERY,
                           ASSOCIATE_HR_QUERY, MDSE_DIV_NBR_QUERY, PAYROLL_END_DATE_QUERY, IS_SAP_ACTIVE_ASSOC_QUERY)
import os
from datetime import datetime
import pandas as pd
import src.utils.app_config as app_config
from src.utils.common_utils import create_dir_if_not_exists, write_list_to_file, write_dataframe_to_file, \
    update_request_status
from src.generate_file.flat_file_creator import gen_flat_file
from typing import Union
from os import PathLike

class FileGenerator:
    """
    Initializes a new instance of the `FileGenerator` class.

    Args:
        configuration_id (int): The ID of the configuration.
        logger_instance (logging.Logger): The logger instance.
        request_id (str): The ID of the request.
        start_date (datetime.datetime): The start date.
        end_date (datetime.datetime): The end date.

    Returns:
        None
    """
    def __init__(self, configuration_id, logger_instance, request_id, start_date, end_date, data=None):
        self.logger = logger_instance
        self.logger.info(FG_INITIALIZE)
        self.configuration_id = configuration_id
        self.request_id = request_id
        self.start_date = start_date
        self.end_date = end_date
        self.flow_name = None
        self.dest_file = None
        self.destination_file_path=None
        self.plan_number = None
        self.plan_file = None
        self.file_data_type = None
        self.file_filler = None
        self.primary_key = None
        self.bucket_name = None
        self.file_gen_func = None
        self.record_types = None
        self.request_id_dir = None
        self.source_file_path = None
        self.dest_file_path_mf = None
        self.plan_stat_code = None
        self.region = None
        flow_config = app_config.get_config_value("flow_config", str(configuration_id))
        self.plan_id = flow_config.get("plan_id", [])
        self.cosmos_connection = CosmosUtils(logger=logger_instance)
        self.db2_connection = DB2IDatabase(logger=logger_instance)
        self.gcp_connection = BigQueryDatabase(logger=logger_instance)
        self.datalake_conn = None
        self.data_file_extract = data
        self.set_file_flow_config_parameters(configuration_id)
        self.logger.info(FG_INSTANCE_CREATED)

    """
    Set the file flow configuration parameters based on the provided configuration ID.

    Parameters:
        configuration_id (int): The ID of the configuration to retrieve.

    Returns:
        None
    """
    def set_file_flow_config_parameters(self, configuration_id):
        try:
            flow_config = app_config.get_config_value("flow_config", str(configuration_id))
            self.flow_name = flow_config.get(CFG_FLOW_NAME, "")
            self.dest_file = flow_config.get(CFG_DEST_FILE, "")
            self.plan_number = flow_config.get(CFG_PLAN_NUMBER, "")
            self.plan_file = flow_config.get(CFG_PLAN_FILE, "")
            self.file_data_type = flow_config.get(CFG_FILE_DATA_TYPE, "")
            self.file_filler = flow_config.get(CFG_FILE_FILLER, "")
            self.source_file_path = flow_config.get(CFG_SOURCE_FILE_PATH, "")
            self.destination_file_path = flow_config.get(CFG_DESTINATION_FILE_PATH, "")
            self.dest_file_path_mf = flow_config.get(CFG_DEST_FILE_PATH_MF, "")
            self.primary_key = flow_config.get(CFG_PRIMARY_KEY, "")
            self.bucket_name = flow_config.get(CFG_BUCKET_NAME, "")
            self.file_gen_func = flow_config.get(CFG_FILE_GEN_FUNC, "")
            self.record_types = flow_config.get(CFG_RECORD_TYPES, [])
            self.region = flow_config.get(CFG_REGION, "")
            self.plan_stat_code = flow_config.get(CFG_PLAN_STAT_CODE, "")
            self.logger.info(CFG_FLOW_CONFIG_RETRIEVED.format(flow_config=flow_config))
        except Exception as e:
            self.logger.error(CFG_FLOW_CONFIG_ERROR.format(error_message=str(e)))


    """
    Creates a working directory for a given request ID.
    Args:
        request_id (str): The ID of the request.
    Returns:
        None
    """
    def create_working_directory(self, request_id):
        try:
            self.logger.info(FG_CREATE_W_DIR)
            cwd = app_config.get_config_value(APP_NAME,CFG_WORKING_DIR)
            create_dir_if_not_exists(cwd)
            request_id_dir = os.path.join(cwd, request_id)
            create_dir_if_not_exists(request_id_dir, self.logger)
            self.request_id_dir = request_id_dir
            self.logger.info(FG_W_DIR_CREATED.format(dir=request_id_dir))
        except Exception as e:
            self.logger.error(FG_W_DIR_CREATE_ERROR.format(error_message=str(e)))

    """
    Retrieves data from the specified Cosmos DB collection based on the given search criteria.
    Args:
        cosmos_database (str): The name of the Cosmos DB database.
        cosmos_collection (str): The name of the Cosmos DB collection.
        cosmos_projection (dict): The projection parameters for the query.
        cosmos_search_criteria (dict): The search criteria for the query.

    Returns:
        list: A list of unique eligible associate IDs.

    """
    def get_data_from_cosmos(self, cosmos_database, cosmos_collection, cosmos_projection,
                                         cosmos_search_criteria):
        try:

            self.logger.info(FG_FILE_GEN_COSMOS.format(collection=cosmos_collection))
            list_data = self.cosmos_connection.get_structured_data(cosmos_database, cosmos_collection, cosmos_projection,
                                                       cosmos_search_criteria)
            self.logger.info(FG_FILE_FROM_COSMOS_CREATED.format(collection=cosmos_collection, dir=self.request_id_dir))
            return list_data

        except Exception as e:
            self.logger.error(FG_FILE_COSMOS_ERROR.format(error_message=str(e)))
        return None

    """
        Retrieves data from the specified Cosmos DB collection based on the given search criteria.
        Args:
            cosmos_database (str): The name of the Cosmos DB database.
            cosmos_collection (str): The name of the Cosmos DB collection.
            cosmos_projection (dict): The projection parameters for the query.
            cosmos_search_criteria (dict): The search criteria for the query.

        Returns:
            list: A list of unique eligible associate IDs.

        """

    def get_eligible_data_from_cosmos(self, cosmos_database, cosmos_collection, cosmos_projection,
                             cosmos_search_criteria):
        try:

            self.logger.info(FG_FILE_GEN_COSMOS.format(collection=cosmos_collection))

            list_data = self.cosmos_connection.get_structured_data(cosmos_database, cosmos_collection,
                                                                   cosmos_projection,
                                                                   cosmos_search_criteria)
            # Get unique eligible associate list
            eligible_list = list({eligible_id['associateId'] for eligible_id in list_data})

            self.logger.info(f'Retrieved {len(eligible_list)} from {cosmos_collection} ')

            # Write that data to sourced from mongo DB to request ID directory in azure mount.
            write_list_to_file(self.request_id_dir + '/' + cosmos_collection, eligible_list, self.logger)

            self.logger.info(FG_FILE_FROM_COSMOS_CREATED.format(collection=cosmos_collection, dir=self.request_id_dir))
            self.logger.debug(f'Eligible list retrieved from COSMOS : {eligible_list} ')
            return eligible_list

        except Exception as e:
            self.logger.error(FG_FILE_COSMOS_ERROR.format(error_message=str(e)))
        return None


    """
    Retrieves data from a GCP Big-Query database for a given list of store numbers.

    Args:
        store_list_df (list): A list of Store numbers for the resulting DataFrame.

    Returns:
        pandas.DataFrame: The DataFrame containing the retrieved data.
    """
    def get_data_from_bigquery(self, store_list_df):
        try:
            self.logger.info(FG_STR_FILE_STARTED)

            if len(store_list_df) == 0:
                self.logger.warning(FG_STR_EMPTY_FILE)
                return None

            store_list = [f"'{str_num}'" for str_num in store_list_df]
            store_list_str = ",".join(store_list)

            self.logger.debug(f'Store list: {store_list}')

            division_df = self.gcp_connection.get_df_from_query(DIVISION_NUMBER_QUERY.format(STORE_LIST=store_list_str))

            # Check if division_df is not empty
            if division_df.empty:
                self.logger.warning(FG_DIV_NBR_EMPTY.format(list=store_list))
                return None

            self.logger.info(f'Division number list: {division_df}')
            return division_df

        except Exception as e:
            self.logger.error(f'Error in get_data_from_bigquery: {e}')


    """
    Retrieves data from a DB2 database and stores it in a CSV file.

    Args:
        col_names (list): A list of column names for the resulting DataFrame.
        query (str): The SQL query to execute on the DB2 database.
        table_name (str): The name of the table to retrieve data from.

    Returns:
        pandas.DataFrame: The DataFrame containing the retrieved data.
    """
    def get_data_from_db2(self, col_names, query, table_name):
        try:
            self.logger.info(FG_FILE_DB2_START.format(table=table_name))

            if '{ASSOCIATE_LIST}' in query and not query.split('({ASSOCIATE_LIST})')[1].strip():
                self.logger.info("No associates to query, returning empty DataFrame")
                return pd.DataFrame(columns=col_names)

            rows = self.db2_connection.fetchall(query)

            generated_file_name = os.path.join(self.request_id_dir, table_name + '.csv')
            df = pd.DataFrame(rows, columns=col_names)
            # Write that data to sourced from mongo DB to request ID directory in azure mount.
            write_dataframe_to_file(generated_file_name, df, self.logger)

            self.logger.info(FG_FILE_DB2_CREATED.format(table=table_name,dir=self.request_id_dir))

            return df
        except Exception as e:
            self.logger.error(FG_FILE_DB2_ERROR.format(table=table_name, error_message=str(e)))
            return None

    """
    Fetches the division numbers for the given store numbers.

    Args:
        store_nums_df (pandas.DataFrame): The DataFrame containing the store numbers.

    Returns:
        pandas.DataFrame: The DataFrame containing the division numbers.
    """
    def fetch_division_numbers(self, store_nums_df):
        division_store_df = self.get_data_from_bigquery(store_nums_df)
        self.logger.info(FG_DIV_NBR_SUCCESS)
        self.logger.debug(FG_DIV_STR_MAP.format(division=division_store_df, stores=store_nums_df))
        return division_store_df

    """
    Fetches core HR data from the database based on the provided associate list.

    Parameters:
        associate_list (list): A list of associate IDs.

    Returns:
        pandas.DataFrame: A DataFrame containing the fetched core HR data.
    """
    def fetch_core_hr_data(self, associate_list):
        core_hr_col_names = ['WIN_NBR', 'NATIONAL_ID', 'LAST_NAME', 'FIRST_NAME', 'BIRTH_DATE',
                             'GENDER_CODE', 'ACT_MARITAL_CODE', 'HIRE_DATE', 'COMP_FREQ_CODE', 'HOME_ADDR_LINE_1', 'HOME_ADDR_LINE_2',
                             'CITY_NAME', 'STATE_PROV_CODE', 'POSTAL_CODE', 'STR_STATE_PROV_CD',
                             'STORE_NBR', 'CHRG_STORE_NBR', 'PAY_TYPE_CODE', 'TERMINATION_DATE', 'CHRG_MDSE_DIV_NBR', 'EMPLOY_STAT_CODE', 'TERM_REASON_CODE']

        self.logger.debug(f'associateList :: {associate_list}')

        # Split the associate_list into chunks of 10,000
        associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]

        # Initialize the result DataFrame
        core_hr_df = pd.DataFrame()

        # Loop through each chunk and append to the result DataFrame
        for associate_chunk in associate_chunks:
            associate_list = ",".join([f"{win}" for win in associate_chunk])
            chunk_df = self.get_data_from_db2(
                col_names=core_hr_col_names,
                query=ASSOCIATE_INFO.format(DB2_SCHEMA=self.db2_connection.testset, ASSOCIATE_LIST=associate_list,
                                            REGION=self.region, WV_FILTER=LOAN_WV_CONDITION if self.region=='US' and self.flow_name == 'LOAN_DEDUCTION' else ''),
                table_name='win_associate'
            )
            # Append to resultant dataframe
            core_hr_df = pd.concat([core_hr_df, chunk_df], ignore_index=True)

        return core_hr_df

    def get_transaction_logs(self):
        """
        Retrieves transaction logs based on different conditions:
        1. If start_date and end_date provided (new hire event), use those
        2. If timestamp exists in flow_config, use that
        3. Otherwise, get max timestamp from postgres and use that

        Returns:
            list: List of associate IDs from matching transaction logs
        """
        try:
            # Get flow config for potential timestamp
            flow_config = app_config.get_config_value("flow_config", str(self.configuration_id))
            timestamp_from_config = flow_config.get("last_processed_timestamp")

            # Case 1: If start_date and end_date provided, use those
            if self.start_date and self.end_date:
                self.logger.info(f"Using provided date range: {self.start_date} to {self.end_date}")
                start_date_str = self.start_date.strftime(DATE_FORMAT_YYYY_MM_DD)
                end_date_str = self.end_date.strftime(DATE_FORMAT_YYYY_MM_DD)
                criteria = {
                    "where": f"c.activity = '{self.flow_name}' AND " +
                             f"SUBSTRING(c.createdAt, 0, 10) >= '{start_date_str}' AND " +
                             f"SUBSTRING(c.createdAt, 0, 10) <= '{end_date_str}'" +
                             (f" AND CONTAINS(c.comment,'rebase') " if self.configuration_id in [1, 4, 5, 6] and self.flow_name == FLOW_NAME_RE_HIRE_BASE else "")
                }

            # Case 2: If timestamp exists in flow_config, use that
            elif timestamp_from_config:
                self.logger.info(f"Using timestamp from config: {timestamp_from_config}")
                criteria = {
                    "where": f"c.activity = '{self.flow_name}' AND " +
                             f"c.createdAt >= '{timestamp_from_config}'"
                }

            # Case 3: Get max timestamp from postgres
            else:
                db_connection = PostgresGCPConnection(logger=self.logger)
                with db_connection as conn:
                    max_timestamp = conn.execute_query_with_fetchone(PG_SQL_MAX_RECORD,(str(self.configuration_id),))
                    if not max_timestamp:
                        max_timestamp = datetime.min

                self.logger.info(f"Using max timestamp from postgres: {max_timestamp}")
                criteria = {
                    "where": f"c.activity = '{self.flow_name}' AND " +
                             f"c.createdAt >= '{max_timestamp}'"
                }

            # Query using CosmosUtils
            projection = "distinct(c.associateId)"
            eligible_associate_list = self.cosmos_connection.get_structured_data(
                cosmos_database='benefits-platform',
                cosmos_collection='transaction-logs',
                cosmos_projection=projection,
                cosmos_search_criteria=criteria
            )

            if not eligible_associate_list :
                self.logger.info(FG_NO_ASSOC_DATA)
                if not self.flow_name == FLOW_NAME_RE_HIRE_BASE :
                    update_request_status(self.request_id, F_ERROR, self.logger, FG_NO_ASSOC_DATA)
                return []

            # Extract associate IDs from results
            associates = [item['associateId'] for item in eligible_associate_list if 'associateId' in item]
            self.logger.info(f"Found {len(associates)} eligible associates")
            return associates

        except Exception as e:
            self.logger.error(f"Error in get_transaction_logs: {str(e)}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

    """
    Retrieves the associate information from the core HR data and the division numbers.

    Parameters:
        associate_list (list): A list of associate IDs.

    Returns:
        pandas.DataFrame: The associate information dataframe.

    Raises:
        DatabaseError: If the core HR data is empty.
    """
    def get_associate_info(self, associate_list):
        if not associate_list:
            self.logger.info("Empty associate list, returning empty DataFrame")
            # Create empty DataFrame with core_hr_columns structure
            core_hr_col_names = ['WIN_NBR', 'NATIONAL_ID', 'LAST_NAME', 'FIRST_NAME',
                                 'BIRTH_DATE', 'GENDER_CODE', 'ACT_MARITAL_CODE', 'HIRE_DATE',
                                 'COMP_FREQ_CODE', 'HOME_ADDR_LINE_1', 'HOME_ADDR_LINE_2',
                                 'CITY_NAME', 'STATE_PROV_CODE', 'POSTAL_CODE',
                                 'STR_STATE_PROV_CD', 'STORE_NBR', 'CHRG_STORE_NBR',
                                 'PAY_TYPE_CODE', 'TERMINATION_DATE', 'CHRG_MDSE_DIV_NBR', 'EMPLOY_STAT_CODE',
                                 'TERM_REASON_CODE']

            associate_info_df = pd.DataFrame(columns=core_hr_col_names)
            associate_info_df['DIV_NBR'] = ''  # Add division number column
            return associate_info_df

        # Get basic associate profile information from core hr (without ASC_STORE_JOB join)
        associate_info_df = self.fetch_basic_core_hr_data(associate_list)
        self.logger.info(f'Fetched {len(associate_info_df)} basic records from DB2')

        if associate_info_df.empty:
            return associate_info_df

        # Get division numbers separately and merge with associate info
        if not associate_info_df.empty:
            store_nums_list = associate_info_df['STORE_NBR'].unique().tolist()
            # Remove any null/empty store numbers
            store_nums_list = [store for store in store_nums_list if store and str(store).strip()]

            if store_nums_list:
                division_store_df = self.fetch_division_numbers(store_nums_list).astype('int64')
                # Left join to preserve all associates, even those without division numbers
                associate_info_df = pd.merge(associate_info_df, division_store_df, on='STORE_NBR', how="left")

            # Fill missing division numbers with 0
            associate_info_df['DIV_NBR'] = associate_info_df['DIV_NBR'].fillna(0).astype(int)

            # Also get ASC_STORE_JOB data separately and merge
            asc_store_job_df = self.fetch_asc_store_job_data(associate_list)
            if not asc_store_job_df.empty:
                # Left join to preserve all associates
                associate_info_df = pd.merge(associate_info_df, asc_store_job_df[['WIN_NBR', 'CHRG_MDSE_DIV_NBR']],
                                             on='WIN_NBR', how="left")

            # Fill missing CHRG_MDSE_DIV_NBR with 0
            if 'CHRG_MDSE_DIV_NBR' not in associate_info_df.columns:
                associate_info_df['CHRG_MDSE_DIV_NBR'] = 0
            else:
                associate_info_df['CHRG_MDSE_DIV_NBR'] = associate_info_df['CHRG_MDSE_DIV_NBR'].fillna(0).astype(int)

        return associate_info_df

    """
    Formats coreHR dataframe's columns to the file's requirement.
    Args:
        df (pandas.DataFrame): The DataFrame containing the core HR data.
    """
    def process_core_hr_df(self, df):
        # Create name column - This is a combination of both last name and first name
        df['NAME'] = df['LAST_NAME'] + ", " + df['FIRST_NAME']
        # Convert date columns to date format for further processing
        df['BIRTH_DATE'] = pd.to_datetime(df['BIRTH_DATE'], format='%Y-%d-%m')
        df['R01-BDAY-DD'] = df['BIRTH_DATE'].dt.strftime('%d')
        df['R01-BDAY-MM'] = df['BIRTH_DATE'].dt.strftime('%m')
        df['R01-BDAY-YY'] = df['BIRTH_DATE'].dt.strftime('%Y')

        df['HIRE_DATE'] = pd.to_datetime(df['HIRE_DATE'], format='%Y-%d-%m')
        df['R01-HDAY-DD'] = df['HIRE_DATE'].dt.strftime('%d')
        df['R01-HDAY-MM'] = df['HIRE_DATE'].dt.strftime('%m')
        df['R01-HDAY-YY'] = df['HIRE_DATE'].dt.strftime('%Y')

        if self.configuration_id == 14 or self.configuration_id == 15:
            df['ACTL_TERM_DATE'] = df['TERMINATION_DATE'].apply(
                lambda x: x.strftime('%Y%m%d') if x else '')

        else:
            df['TERMINATION_DATE'] = df['TERMINATION_DATE'].apply(
                lambda x: x.strftime('%d%m%Y') if x else '')
            df['ACTL_TERM_DATE'] = ""

        # Format the store number, division number, left pad zeros,handle and maintain as a string.
        df['STORE_NBR'] = df['STORE_NBR'].fillna(0).astype(int).astype(str).str.zfill(5)
        df['CHRG_STORE_NBR'] = df['CHRG_STORE_NBR'].fillna(0).astype(int).astype(str).str.zfill(5)
        df['DIV_NBR'] = df['DIV_NBR'].astype(str).str.zfill(3)
        df['CHRG_MDSE_DIV_NBR'] = df['CHRG_MDSE_DIV_NBR'].astype(str).str.zfill(3)

        #Set STR_STATE_PROV_CD with R02_BONAFIDE_IND logic for R02 records
        df.loc[(df['STR_STATE_PROV_CD'] == REGION_PR) & (
                    df['STATE_PROV_CODE'] == REGION_PR), 'STR_STATE_PROV_CD'] = REGION_PR
        df.loc[~((df['STR_STATE_PROV_CD'] == REGION_PR) & (
                    df['STATE_PROV_CODE'] == REGION_PR)), 'STR_STATE_PROV_CD'] = REGION_US

        df['EMPLOY_STAT_CODE'] = df['EMPLOY_STAT_CODE'].astype(str).str.zfill(1)
        df['TERM_REASON_CODE'] = df['TERM_REASON_CODE'].astype(str).str.zfill(3)

        df = df.astype(str).replace({'NaT': '', 'NaN': '', 'None': ''}).map(str.strip)
        return df

    """
    Generates a DataFrame based on the given record type.
    The data obtained from DB2 is stitched with static columns for the given record type

    Args:
        core_hr_df (pandas.DataFrame): The DataFrame containing the core HR data.
        associate_list (list): The list of associate IDs.
        static_columns (dict): The dictionary of static columns and their corresponding values.
        core_hr_col_names (list): The list of column names in the core HR DataFrame.
        record_type (str): The type of the record.

    Returns:
        pandas.DataFrame: The generated DataFrame.
    """
    def generate_df_by_record_type(self, core_hr_df, associate_list, static_columns, core_hr_col_names, record_type):
        df = pd.DataFrame(associate_list, columns=['associate_id'])
        for column, value in static_columns.items():
            df[column] = value

        core_hr_df = core_hr_df[core_hr_col_names]
        df = pd.merge(df, core_hr_df, left_on='associate_id', right_on='WIN_NBR', how='inner',sort=True)
        self.logger.info(FG_RECORD_TYPE_GENERATED.format(record_type=record_type))
        return df


    """
    Generates a dictionary of dataframes for each record type.

    Args:
        associate_info (pandas.DataFrame): The dataframe containing information about associates.
        associate_list (list): A list of associate IDs.

    Returns:
        dict: A dictionary where the keys are record types and the values are dataframes.
    """
    def generate_record_dict(self, associate_info_df, associate_list):
        df_dict = dict()
        # Retrieve static column for each record set
        static_col_record_set = app_config.get_config_value("file_layout", "static_col_record_set")
        # Retrieve hr columns by record type
        core_hr_columns_by_recordtype = app_config.get_config_value("file_layout", "corehr_columns_by_recordtype")

        # Extract the df_dic generation
        for record_type in self.record_types:
            df_dict[record_type] = self.generate_df_by_record_type(associate_info_df,
                                                                   associate_list,
                                                                   static_col_record_set[
                                                                       record_type],
                                                                   core_hr_columns_by_recordtype[
                                                                       record_type],
                                                                   record_type)
        self.logger.info(FG_DF_FILLED)
        return df_dict


    """
    Initiates the generation of flat files.

    Args:
        record_dict (dict): A dictionary containing the data to be written to the flat files.

    Returns:
        None

    This function generates flat files based on the provided record dictionary. It creates the file paths,
    retrieves the flat file layout from the configuration, and initializes a flat file generator object.
    It then starts the process of generating the flat files with the provided record dictionary, plan number,
    plan file, and primary key.

    The generated files and the records that could not be processed are logged.

    Example:
        record_dict = {
            'r01': pd.DataFrame(),
            'r02': pd.DataFrame(),
            'r05': pd.DataFrame(),
            'r62': pd.DataFrame()
        }
        initiate_flat_file_generation(record_dict)
    """
    def initiate_flat_file_generation(self, record_dict, file_layout = CFG_FLAT_FILE_LAYOUT, max_line_length = DEF_FLAT_LINE_LENGTH):
        generated_file = os.path.join(self.request_id_dir, self.dest_file)
        invalid_file = os.path.join(self.request_id_dir, 'invalid_' + self.dest_file)


        self.logger.info(FG_INVALID_RECORDS.format(file=generated_file, invalid_file=invalid_file))

        flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, file_layout)

        # Create object for the flat file generator
        create_flat_file = gen_flat_file(generated_file, invalid_file,
                                         flat_file_layout, self.logger, max_line_length)
        self.logger.info(FG_FLAT_FILE_GEN_PROCESS.format(plan_number=self.plan_number, plan_file=self.plan_file))
        create_flat_file.start_process(record_dict, self.plan_number, self.plan_file, self.file_data_type, self.file_filler, self.fetch_current_payroll_enddate(), self.primary_key)

    """
    Transfers a file to a Google Cloud Storage (GCS) bucket.

    This function uses the `file_transfer` module to transfer a file to a GCS bucket.
    It takes the `self.request_id` and `self.bucket_name` as parameters to construct
    the destination folder name. The file to be transferred is located in the
    `self.request_id_dir` directory.

    Parameters:
        self (object): The instance of the class.

    Returns:
        None
    """
    def transfer_file_to_gcs(self):
        # Transfer file to GCS bucket.
        ft = file_transfer(self.logger)
        ft.transfer_file_to_gcs(self.bucket_name,self.request_id_dir, self.destination_file_path, self.dest_file)
        self.logger.info(FILE_TRANSFER_TO_GCS.format(destination_file_path=self.destination_file_path,bucket_name = self.bucket_name))

        # Create backup path
        if not self.destination_file_path.endswith('/'):
            self.destination_file_path += '/'
        backup_path = f"{self.destination_file_path}{'backup/'}"
        ft.transfer_file_to_gcs(self.bucket_name, self.request_id_dir, backup_path, self.dest_file)
        self.logger.info(FILE_TRANSFER_TO_GCS.format(destination_file_path=backup_path, bucket_name=self.bucket_name))

    """
    Transfers a file from the local directory to an Azure directory.

    This function creates a `file_transfer` object and calls its `transfer_to_azure_directory` method
    to transfer the file. The file is transferred from the `request_id_dir` directory to the
    `destination_file_path` directory. The file name is specified by the `dest_file` parameter.

    Parameters:
        None

    Returns:
        None
    """
    def transfer_file_to_azure_directory(self):
        ft = file_transfer(self.logger)
        ft.transfer_to_azure_directory(self.request_id_dir, self.destination_file_path, self.dest_file)
        self.logger.info(FILE_TRANSFER_SUCCESS.format(source_file_path=self.request_id_dir, destination_file_path=self.destination_file_path))

    """
    Retrieves a file from the mainframe and saves it to a specified directory.

    This function uses the `file_transfer` module to transfer a file from the mainframe to a local directory.
    It takes the `self.source_file_path` as the path of the file to be transferred, `self.request_id_dir` as
    the destination directory, and `self.dest_file` as the name of the file in the destination directory.

    Parameters:
        self (object): The instance of the class.

    Returns:
        None

    Raises:
        Exception: If there is an error during the transfer.
    """
    def get_file_from_mainframe(self):
        try:
            ft = file_transfer(self.logger)
            # Transfer from mainframe
            ft.transfer_file_from_mainframe(self.source_file_path, self.request_id_dir, self.dest_file)
            self.logger.info(MF_FILE_DOWNLOADED.format(source_file_path=self.source_file_path, dir=self.request_id_dir))
        except Exception as e:
            self.logger.error(MF_FILE_DOWNLOAD_ERROR.format(error_message=str(e)))
            raise ApplicationError(MF_FILE_DOWNLOAD_ERROR.format(error_message=str(e)))

    def transfer_file_to_mainframe(self):
        try:
            ft = file_transfer(self.logger)
            # Transfer to mainframe
            ft.transfer_to_mainframe(self.dest_file_path_mf, self.request_id_dir, self.dest_file)
            self.logger.info(f"File uploaded successfully to mainframe: {self.dest_file_path_mf}")
        except Exception as e:
            self.logger.error(f"Error uploading file to mainframe: {str(e)}")
            raise ApplicationError(f"Error uploading file to mainframe: {str(e)}")

    """
    Generates a file based on the given record types.

    This function retrieves the pre-requisite data from core HR data and the list of associate IDs,
    generates DataFrames based on the record types. 
    The DataFrames are then used for generating flat file with the given record types. 
    The generated file is available in azure mount specified the KITT, the files are available in request ID directory
    And the files are then transferred to GCS bucket to request ID directory, based on configuration. 

    Returns:
        None
    """
    def start_process(self):
        self.logger.info(FG_GEN_PROCESS_START)

    def fetch_associate_contribution(self, eligible_associate_list):
        try:
            self.logger.info(CONTRIBUTION_DATA_FETCH.format(collection='coverages'))

            if not eligible_associate_list:
                self.logger.info("Empty associate list for contribution fetch")
                return pd.DataFrame()

            # Use chunked Cosmos query with placeholder for associate list
            search_criteria_template = {
                "where": f"c.associateId IN ({'{ASSOCIATE_LIST}'}) and "
                         f" c.planId in ('retirement_401k_regular_us','retirement_401k_regular_pr',"
                         f" 'retirement_401k_catchup_regular_us','retirement_401k_catchup_regular_pr')"
            }

            # Use the new chunked method
            list_data = self.cosmos_connection.get_structured_data_chunked(
                cosmos_database='benefits-platform',
                cosmos_collection='coverages',
                cosmos_projection="c.associateId, c.planId, c.version, c.contribution",
                cosmos_search_criteria=search_criteria_template,
                associate_list=eligible_associate_list,
                chunk_size=1000
            )

            if not list_data:
                self.logger.info(CONTRIBUTION_DATA_EMPTY)
                return pd.DataFrame()

            contribution_df = pd.DataFrame(list_data)

            # Get latest version for each associate+plan combination
            contribution_df = contribution_df.loc[
                contribution_df.groupby(['associateId', 'planId'])['version'].idxmax()
            ].copy()

            # Remove the *100 multiplication to fix the formatting issue
            contribution_df['contribution'] = contribution_df.apply(self._extract_contribution_value, axis=1)

            # Set contribution flags and initialize rates as float
            contribution_df['R01-SAVINGS-RATES-INCLUDED'] = contribution_df['contribution'].apply(
                lambda x: 'Y' if x >= 0 else 'N'
            )
            contribution_df['R01-ELECT-BT-SAVE-RATE'] = 0.0
            contribution_df['R01-ELECT-BT-CUC-SAVE-RATE'] = 0.0

            # Process regular 401k contributions
            regular_records = contribution_df[contribution_df['planId'] == self.plan_id[0]]
            if not regular_records.empty:
                contribution_df.loc[regular_records.index, 'R01-ELECT-BT-SAVE-RATE'] = regular_records['contribution']

            # Process catch-up 401k contributions
            catchup_records = contribution_df[contribution_df['planId'] == self.plan_id[1]]
            if not catchup_records.empty:
                contribution_df.loc[catchup_records.index, 'R01-ELECT-BT-CUC-SAVE-RATE'] = catchup_records[
                    'contribution']

            # Prepare final DataFrame
            result_df = contribution_df.groupby('associateId').agg({
                'R01-SAVINGS-RATES-INCLUDED': 'first',
                'R01-ELECT-BT-SAVE-RATE': 'max',
                'R01-ELECT-BT-CUC-SAVE-RATE': 'max'
            }).reset_index()

            result_df = result_df.rename(columns={'associateId': 'WIN_NBR'})
            result_df['WIN_NBR'] = result_df['WIN_NBR'].astype(str)

            return result_df

        except Exception as e:
            self.logger.error(CONTRIBUTION_FETCH_ERROR.format(error_message=str(e)))
            raise

    def process_contribution_df(self, contribution_df):
        """
        Formats contribution dataframe's columns to the file's requirement.
        """
        if contribution_df is not None:
            columns = ['R01-ELECT-BT-SAVE-RATE', 'R01-ELECT-BT-CUC-SAVE-RATE']

            # Create a copy of the DataFrame to avoid SettingWithCopy warning
            contribution_df = contribution_df.copy()

            # Fill NaN values and format each column
            for col in columns:
                contribution_df[col] = (contribution_df[col]
                                        .fillna(0)
                                        .astype(float)
                                        .apply(self.decimal_custom_format))
        else:
            self.logger.error('Error: contribution_df is empty')
        return contribution_df

    def decimal_custom_format(self, rate):
        """
        Formats the rate into mainframe specific string format.
        Converts decimal parts of rate into letters (1=A, 2=B, etc)
        Example: 4.2 -> 004B, 3.5 -> 003E
        """
        try:
            # Ensure we're working with a float
            abs_rate = abs(float(rate))

            # Get integer and decimal parts
            int_part = int(abs_rate)
            decimal_part = abs_rate - int_part

            # Format integer part with leading zeros
            formatted_int = str(int_part).zfill(3)

            # If there's a decimal part, convert it to letter
            if decimal_part > 0:
                # Multiply by 10 to get first decimal place as integer
                decimal_digit = int(round(decimal_part * 10))
                # Convert to corresponding letter (1->A, 2->B, etc)
                return formatted_int + chr(64 + decimal_digit)

            # No decimal part
            return formatted_int + "{"
        except ValueError as e:
            self.logger.error(f"Error formatting rate {rate}: {str(e)}")
            return "000000{"

    def _extract_contribution_value(self, row):
        """
        Helper method to safely extract contribution value.
        """
        try:
            contribution = row.get('contribution')
            if pd.isna(contribution) or contribution is None:
                self.logger.warning(CONTRIBUTION_DATA_MISSING.format(
                    associate_id=row.get('associateId', 'Unknown')
                ))
                return 0
            elif isinstance(contribution, (int, float)):
                return contribution
            elif isinstance(contribution, dict) and 'value' in contribution:
                return contribution['value']
            else:
                self.logger.warning(CONTRIBUTION_FORMAT_INVALID.format(
                    associate_id=row.get('associateId', 'Unknown')
                ))
                return 0
        except Exception as e:
            self.logger.warning(CONTRIBUTION_PROCESS_ERROR.format(
                associate_id=row.get('associateId', 'Unknown'),
                error_message=str(e)
            ))
            return 0

    """
    Updates record dictionary with contribution data. This is a common functionality
    that can be used by different file types.

    Args:
        record_dict (dict): Dictionary containing record data
        contribution_df (pd.DataFrame, optional): DataFrame containing contribution data

    Returns:
        dict: Updated record dictionary with contribution data
    """
    def update_contribution_data(self, record_dict, contribution_df=None):
        try:
            if contribution_df is not None:
                record_dict['r01'].set_index('associate_id', inplace=True)
                contribution_df.set_index('WIN_NBR', inplace=True)

                columns_to_update = ['R01-SAVINGS-RATES-INCLUDED', 'R01-ELECT-BT-SAVE-RATE',
                                   'R01-ELECT-BT-CUC-SAVE-RATE']
                record_dict['r01'].update(contribution_df[columns_to_update])

                record_dict['r01'].reset_index(inplace=True)
                contribution_df.reset_index(inplace=True)

            return record_dict
        except Exception as e:
            self.logger.error(f'Error in update_contribution_data: {e}')
            raise

    def fetch_associate_consent(self, eligible_associate_list):
        try:
            if not eligible_associate_list:
                self.logger.info("Empty associate list for consent fetch")
                return pd.DataFrame()

            # Use chunked Cosmos query with placeholder for associate list
            search_criteria_template = {
                "where": f"c.associateId IN ({'{ASSOCIATE_LIST}'})"
            }

            # Use the new chunked method
            consent_data = self.cosmos_connection.get_structured_data_chunked(
                cosmos_database='benefits-platform',
                cosmos_collection='associate-benefit-profile',
                cosmos_projection="c.associateId, c.consent, c.planConsents, c.version",
                cosmos_search_criteria=search_criteria_template,
                associate_list=eligible_associate_list,
                chunk_size=1000
            )

            if not consent_data:
                raise ConsentFetchError(CONSENT_FETCH_ERROR.format(error_message=MISSING_CONSENT_ERROR))

            # Create DataFrame with default values
            consent_df = pd.DataFrame(consent_data)
            consent_df['R02-OPT-IN-OUT-FLAG'] = ''  # Default opt-out
            consent_df['R02-EMAIL-TYPE'] = ''
            consent_df['R02-EMAIL-ADDRESS'] = ''

            # Handle missing objects
            if 'planConsents' not in consent_df.columns:
                consent_df['planConsents'] = None
            if 'consent' not in consent_df.columns:
                consent_df['consent'] = None

            # Get latest version for each associate
            consent_df = consent_df.loc[
                consent_df.groupby(['associateId'])['version'].idxmax()
            ]

            # Process each row
            for idx, row in consent_df.iterrows():
                try:
                    flag, email = self._determine_consent_and_email(row)
                    consent_df.at[idx, 'R02-OPT-IN-OUT-FLAG'] = flag
                    consent_df.at[idx, 'R02-EMAIL-TYPE'] = 'H' if flag == '1' else ''
                    consent_df.at[idx, 'R02-EMAIL-ADDRESS'] = email
                except Exception as e:
                    self.logger.warning(CONSENT_ASSOCIATE_ERROR.format(
                        associate_id=row.get('associateId', 'Unknown'),
                        error_message=str(e)
                    ))

            # Select and rename columns for output
            consent_df = consent_df[['associateId', 'R02-OPT-IN-OUT-FLAG', 'R02-EMAIL-TYPE', 'R02-EMAIL-ADDRESS']]
            consent_df = consent_df.rename(columns={'associateId': 'WIN_NBR'})
            consent_df['WIN_NBR'] = consent_df['WIN_NBR'].astype('str')

            return consent_df

        except Exception as e:
            self.logger.error(CONSENT_FETCH_ERROR.format(error_message=str(e)))
            raise ConsentFetchError(CONSENT_FETCH_ERROR.format(error_message=str(e)))

    """
        Determines consent status and email from associate data.
        Checks both retirement plan consent and general email consent.

        Args:
            row (pandas.Series): Row containing associate's consent information.
                               Must have 'planConsents' and 'consent' fields.

        Returns:
            tuple: (consent_flag, email_address)
                - consent_flag (str): '1' if consented, '0' if not
                - email_address (str): Email address if provided, '' if not

        Raises:
            ConsentProcessError: If there's an error processing the consent data.

        Note:
            - First checks retirement plan specific consent
            - Falls back to general email consent if no plan consent found
            - Returns default ('0', '') if no valid consent found
    """

    def _determine_consent_and_email(self, row):
        """Helper method to determine consent status and email from a row."""
        try:
            # Check for retirement_401k plan consent
            plan_consents = row.get('planConsents', [])
            if isinstance(plan_consents, list):
                for plan_consent in plan_consents:
                    if self._is_valid_401k_plan(plan_consent) and self._has_valid_consent(plan_consent):
                        return '1', plan_consent.get('emailId', '')

            # Fall back to general consent
            # Now checking benefitsMaterial inside electronicPreference
            consent = row.get('consent', {})
            electronic_preference = consent.get('electronicPreference', {})

            if isinstance(electronic_preference, dict) and electronic_preference.get('benefitsMaterial', False):
                return '1', consent.get('emailId', '')

            return '0', ''

        except Exception as e:
            error_msg = CONSENT_PROCESS_ERROR.format(
                associate_id=row.get('associateId', 'Unknown'),
                error_message=str(e)
            )
            raise ConsentProcessError(error_msg)

    """
        Validates if a plan consent object is for a retirement_401k plan.

        Args:
            plan_consent (dict): Plan consent object to validate.
                               Must have 'planType' field.

        Returns:
            bool: True if valid retirement_401k plan, False otherwise.

        Note:
            - Checks both object type and plan type
            - Handles missing or malformed data 
            - Uses PLAN_TYPE constant for comparison
    """
    def _is_valid_401k_plan(self, plan_consent):
        """Check if the plan consent is a valid retirement_401k plan."""
        if not isinstance(plan_consent, dict):
            return False

        plan_type = plan_consent.get('planType', '')
        return isinstance(plan_type, str) and plan_type.startswith(PLAN_TYPE)

    """
        Checks if a plan consent object has valid consent value.

        Args:
            plan_consent (dict): Plan consent object to check.
                               Must have 'consent' field.

        Returns:
            bool: True if consent is valid and true, False otherwise.

        Note:
            - Verifies consent is boolean type
            - Checks if consent value is True
            - Handles missing or invalid consent values
    """

    def _has_valid_consent(self, plan_consent):
        """Check if the plan consent has valid consent value."""
        return isinstance(plan_consent.get('consent'), bool) and plan_consent['consent']

    """
        Checks general email consent and retrieves email address.

        Args:
            consent (dict): Consent object containing email consent information.
                           Should have 'emailConsent' and 'emailId' fields.

        Returns:
            tuple: (consent_flag, email_address)
                - consent_flag (str): '1' if email consented, '0' if not
                - email_address (str): Email address if provided, '' if not

        Note:
            - Used as fallback when no plan-specific consent exists
            - Validates consent object structure
            - Returns default values for invalid/missing data
    """
    def _check_email_consent(self, consent):
        """
        Check consent based on benefitsMaterial field inside electronicPreference.
        """
        if isinstance(consent, dict):
            electronic_preference = consent.get('electronicPreference', {})
            if isinstance(electronic_preference, dict) and electronic_preference.get('benefitsMaterial', False):
                return '1', consent.get('emailId', '')
        return '0', ''

    def _ensure_empty_file_exists(self, file_path: Union[str, bytes, PathLike]) -> None:
        """Ensure an empty file exists, creating it if necessary.

        Args:
            file_path: Path to the file to create. Can be string, bytes or PathLike object.

        Raises:
            ApplicationError: If file creation fails
        """
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(file_path), exist_ok=True)

            # Create empty file if it doesn't exist
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    f.write('')  # Create empty file
                self.logger.info(f"Created empty file: {file_path}")
        except Exception as e:
            raise ApplicationError(f"Error creating empty file: {str(e)}")

    """
    Apply the plan detail attributes to the given dataframe dictionary.

    Parameters:
        df_dict (dict): A dictionary of dataframes, where each dataframe is keyed by a record type.

    Returns:
        dict: The updated dataframe dictionary with the plan detail attributes applied.
    """
    def apply_plan_detail_attributes(self, df_dict):
        """
        Applies basic plan details to the record dictionary.
        """
        try:
            if 'r01' in df_dict:
                df_dict['r01']['R01-PLAN-NUMBER'] = self.plan_number
                df_dict['r01']['R01-STAT-CODE'] = self.plan_stat_code

            if 'r02' in df_dict:
                df_dict['r02']['R02-PLAN-NUMBER'] = self.plan_number

            if 'r05' in df_dict:
                df_dict['r05']['R05-PLAN-NUMBER'] = self.plan_number
                if self.configuration_id in [2,3,14,15]:
                    df_dict['r05']['R05-HOURS-SERVICE'] = DEF_HOURS_SERVICE
                    df_dict['r05']['R05-YEARS-OF-SERVICE'] = DEF_YEARS_OF_SERVICE

            if 'r56' in df_dict:
                df_dict['r56']['R62-PLAN-NUMBER'] = self.plan_number

            if 'r62' in df_dict:
                df_dict['r62']['R62-PLAN-NUMBER'] = self.plan_number
                df_dict['r62']['TERMINATION_DATE'] = ""

            return df_dict

        except Exception as e:
            self.logger.error(PLAN_ATTRIBUTE_ERROR.format(error_message=str(e)))
            raise PlanAttributeError(PLAN_ATTRIBUTE_ERROR.format(error_message=str(e)))

    def get_transaction_logs_with_comments(self):
        """
        Enhanced version of get_transaction_logs that includes comments field.
        This method fetches transaction logs with additional fields needed for
        specialized processing such as loan processing.

        Returns:
            list: List of transaction logs with comments and other details
        """
        try:
            # Format dates for SQL date comparison
            start_date_str = self.start_date.strftime("%Y-%m-%d")
            end_date_str = self.end_date.strftime("%Y-%m-%d")

            # Prepare SQL-style projection and criteria using SUBSTRING for date comparison
            # Adding comments field to projection
            projection = "distinct c.associateId, c.comment"
            criteria = {
                "where": f"c.activity = '{self.flow_name}' AND " +
                         f"SUBSTRING(c.createdAt, 0, 10) >= '{start_date_str}' AND " +
                         f"SUBSTRING(c.createdAt, 0, 10) <= '{end_date_str}' AND " +
                         f"c.comment in ({REHIRE_CREDIT_IND})"
            }

            # Query Cosmos DB using SQL format directly
            transaction_logs = self.cosmos_connection.get_structured_data(
                cosmos_database='benefits-platform',
                cosmos_collection='transaction-logs',
                cosmos_projection=projection,
                cosmos_search_criteria=criteria
            )

            if not transaction_logs:
                self.logger.info(f"No matching transaction logs found for {self.flow_name}")
                update_request_status(self.request_id, F_ERROR, self.logger,
                                      f"No eligible data found for {self.flow_name}")
                return []

            self.logger.info(f"Found {len(transaction_logs)} transaction logs with comments")
            return transaction_logs

        except Exception as e:
            self.logger.error(f"Error in get_transaction_logs_with_comments: {str(e)}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

    def get_benefits_hudi_data(self):
        """
        Retrieves data from the Hudi data lake based on configuration in data argument.

        The method expects data to be a dictionary with the following structure:
        {
          "configurationId": 0,
          "dataSource": {
            "tableName": "coverages",
            "selectFields": "id, associateId",
            "whereClause": "associateId = 1"
          },
          "targetStorage": {
            "type": "dataframe",
            "filePath": "",
            "fileName": "",
            "fileFormat": "csv"
          }
        }

        Returns:
            pandas.DataFrame: DataFrame containing the query results, or saved file path if file storage specified

        Raises:
            ApplicationError: If there is an issue with the data extraction
        """
        try:
            self.logger.info("Starting data extraction from Hudi data lake")

            #check data lake connection status and create if not exists
            if not self.datalake_conn:
                self.datalake_conn = DataLakeHudiUtils(logger=self.logger)

            if not self.data_file_extract:
                raise ApplicationError("No data configuration provided for Hudi data extraction")

            data_config = self.data_file_extract

            # Validate required fields
            if not all(key in data_config for key in ["dataSource", "targetStorage"]):
                raise ApplicationError("Missing required fields in data config: dataSource or targetStorage")

            data_source = data_config.get("dataSource", {})
            if not all(key in data_source for key in ["tableName", "selectFields", "whereClause"]):
                raise ApplicationError("Missing required fields in dataSource: tableName, selectFields, or whereClause")

            # Extract query parameters
            table_name = data_source.get("tableName")
            select_fields = data_source.get("selectFields")
            where_clause = data_source.get("whereClause")

            self.logger.info(
                f"Querying Hudi table: {table_name} with fields: {select_fields} and filter: {where_clause}")

            # Execute query using datalake connection
            result_df = self.datalake_conn.get_hudi_data(
                table_name=table_name,
                select_clause=select_fields,
                where_clause=where_clause
            )

            # Check if result needs to be saved to file
            target_storage = data_config.get("targetStorage", {})

            self.logger.info(f"Successfully retrieved {len(result_df)} records from {table_name}")
            return result_df, target_storage

        except Exception as e:
            error_msg = f"Error extracting data from Hudi: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, error_msg)
            raise ApplicationError(error_msg)

    """
        Fetches the original hire date from Cosmos DB (associate-benefit-profile) for a given list of eligible associates.

        Parameters:
            - eligible_associate_list (list): A list of eligible associate IDs.     
        Returns:
            - pd.DataFrame: A DataFrame containing the original hire date details with columns:
            ['associateId', 'originalHireDate'].
        Raises:
            - Exception: If there is an error during the data retrieval process.
        """
    def fetch_hire_date(self, eligible_associate_list):
        try:
            # Convert the list to a string for SQL IN clause
            associates_list = ",".join([f"'{id}'" for id in eligible_associate_list])

            hire_date_data = self.cosmos_connection.get_structured_data(
                'benefits-platform',
                'associate-benefit-profile',
                "c.associateId, c.eligibility.plans",  # SQL projection
                {
                    "where": f"c.associateId IN ({associates_list}) "
                }
            )

            # Convert hire_date_data to a DataFrame
            hire_date_df = pd.DataFrame(hire_date_data)

            if not hire_date_df.empty:
                # Extract the eligible hours column (assuming it's named 'eligibleHours')
                hire_date_df = hire_date_df.explode('plans')  # Flatten nested data if needed
                hire_date_df = pd.concat(
                    [hire_date_df[['associateId']].reset_index(drop=True),
                     pd.json_normalize(hire_date_df['plans'])],
                    axis=1
                )

                # Region-based planId filtering
                if self.region == "US":
                    hire_date_df = hire_date_df[
                        (hire_date_df['planId'] == 'retirement_401k_regular_us') |
                        (hire_date_df['planId'] == 'retirement_401k_catchup_regular_us')
                        ]
                elif self.region == "PR":
                    hire_date_df = hire_date_df[
                        (hire_date_df['planId'] == 'retirement_401k_regular_pr') |
                        (hire_date_df['planId'] == 'retirement_401k_catchup_regular_pr')
                        ]
                else:
                    self.logger.info("Region not recognized, applying fallback logic.")
                    # fallback: keep all four planIds
                    hire_date_df = hire_date_df[
                        (hire_date_df['planId'] == 'retirement_401k_regular_us') |
                        (hire_date_df['planId'] == 'retirement_401k_catchup_regular_us') |
                        (hire_date_df['planId'] == 'retirement_401k_regular_pr') |
                        (hire_date_df['planId'] == 'retirement_401k_catchup_regular_pr')
                        ]

                # Pick only the first row for every associateId
                hire_date_df = hire_date_df.drop_duplicates(subset=['associateId'], keep='first')
                # Select only the required columns
                hire_date_df = hire_date_df[['associateId', 'originalHireDate']]

            return hire_date_df

        except Exception as e:
            self.logger.error(f'Error in fetch_hire_date: {e}')
            raise

    """
        Functions   : fetch_experience_years & fetch_experience_years_data
        Fetches the years of service (experience years) for a given list of associates from DB2.

        Parameters:
        - associate_list (list): A list of associate IDs for which experience years are to be fetched.

        Returns:
        - pd.DataFrame: A DataFrame containing experience years details with columns:
          ['WIN_NBR', 'ADJUSTMT_NBR', 'R05-YEARS-OF-SERVICE'].
        """
    def fetch_experience_years(self,associate_list):
        if not associate_list:
            self.logger.info("Empty associate list, returning empty DataFrame")
            # Create empty DataFrame with experience_years_cols structure
            experience_years_cols = ['WIN_NBR','ADJUSTMT_NBR', 'R05-YEARS-OF-SERVICE']
            experience_years_df = pd.DataFrame(columns=experience_years_cols)
            return experience_years_df

        #Get experience_years_cols information from DB2
        experience_years_df = self.fetch_experience_years_data(associate_list)
        self.logger.info(f'Fetched {len(experience_years_df)} experience years records from DB2')

        # Apply integer_lastbyte_conversion to R05-YEARS-OF-SERVICE
        if not experience_years_df.empty:
            experience_years_df['R05-YEARS-OF-SERVICE'] = experience_years_df['R05-YEARS-OF-SERVICE'].apply(
                lambda x: self.integer_lastbyte_conversion(x) if pd.notna(x) else x)

        return experience_years_df

    def fetch_experience_years_data(self, associate_list):
        experience_years_cols = ['WIN_NBR','ADJUSTMT_NBR' , 'R05-YEARS-OF-SERVICE']

        self.logger.debug(f'associateList :: {associate_list}')

        # Split the associate_list into chunks of 10,000
        associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]
        #set fiscal_year, fiscal year Start date and End date
        fiscal_year,fiscal_year_start_date,fiscal_year_end_date=self.get_fiscal_year()

        # Initialize the result DataFrame
        experience_years_df = pd.DataFrame()

        # Loop through each chunk and append to the result DataFrame
        for associate_chunk in associate_chunks:
            associate_list = ",".join([f"{win}" for win in associate_chunk])
            chunk_df = self.get_data_from_db2(
                col_names=experience_years_cols,
                query=EXPERIENCE_YEARS_QUERY.format(DB2_SCHEMA=self.db2_connection.testset,FISCAL_YEAR=fiscal_year, ASSOCIATE_LIST=associate_list, REGION=self.region),
                table_name='rtrmt_acct_adjmt'
            )
            # Append to resultant dataframe
            experience_years_df = pd.concat([experience_years_df, chunk_df], ignore_index=True)
            #pick only the first row for each WIN_NBR
            experience_years_df = experience_years_df.drop_duplicates(subset='WIN_NBR', keep='first')

        return experience_years_df

    def fetch_eligible_hours(self, eligible_associate_list):
        """
        Fetches the eligible hours for a given list of eligible associates from cosmos(post-payroll-snapshot).
        Processes associates in chunks to avoid Cosmos DB query size limits.

        Parameters:
        - eligible_associate_list (list): A list of eligible associate IDs.

        Returns:
        - pd.DataFrame: A DataFrame containing eligible hours details with columns:
          ['associateId', 'totalHours', 'R05-HOURS-SERVICE'].
        Logic:
         - Get (Sum of Eligible Hours for fiscal year + Sum of Adjusted Hours for fiscal year - Sum of Prorated Hours for fiscal year)
         - Add the Prorated Hours only for the current pay period
        Raises:
        - Exception: If there is an error during the data retrieval or processing.
        """
        try:
            if not eligible_associate_list:
                self.logger.info("Empty associate list for eligible hours fetch")
                return pd.DataFrame(columns=['associateId', 'totalHours', 'R05-HOURS-SERVICE'])

            # Set fiscal_year, fiscal year Start date and End date
            fiscal_year, fiscal_year_start_date, fiscal_year_end_date = self.get_fiscal_year()

            fiscal_year_start_date = "'" + fiscal_year_start_date + "'"
            fiscal_year_end_date = "'" + fiscal_year_end_date + "'"

            # Process associates in chunks to avoid Cosmos DB query size limits
            chunk_size = 1000  # Adjust this size based on your Cosmos DB limits
            associate_chunks = [eligible_associate_list[i:i + chunk_size]
                                for i in range(0, len(eligible_associate_list), chunk_size)]

            all_eligible_hours_data = []

            for chunk_index, associate_chunk in enumerate(associate_chunks):
                try:
                    self.logger.info(
                        f"Processing chunk {chunk_index + 1}/{len(associate_chunks)} with {len(associate_chunk)} associates")

                    # Convert the chunk to a string for SQL IN clause
                    associates_list = ",".join([f"'{id}'" for id in associate_chunk])

                    eligible_hours_data = self.cosmos_connection.get_structured_data(
                        'benefits-platform',
                        'post-payroll-snapshot',
                        "c.associateId, c.payPeriodEndDate, c.payrollSnapShot",  # SQL projection
                        {
                            "where": f"c.associateId in ({associates_list}) and"
                                     f" c.payPeriodEndDate >= {fiscal_year_start_date} and c.payPeriodEndDate <= {fiscal_year_end_date} "
                            # SQL where clause
                        }
                    )

                    if eligible_hours_data:
                        all_eligible_hours_data.extend(eligible_hours_data)
                        self.logger.info(f"Chunk {chunk_index + 1} returned {len(eligible_hours_data)} records")
                    else:
                        self.logger.info(f"Chunk {chunk_index + 1} returned no data")

                except Exception as chunk_error:
                    self.logger.error(f"Error processing chunk {chunk_index + 1}: {str(chunk_error)}")
                    # Continue with other chunks even if one fails
                    continue

            if not all_eligible_hours_data:
                self.logger.info("No eligible hours data found for any chunks")
                return pd.DataFrame(columns=['associateId', 'totalHours', 'R05-HOURS-SERVICE'])

            # Convert all data to DataFrame
            eligible_hours_df = pd.DataFrame(all_eligible_hours_data)

            # Check if the DataFrame is not empty
            if not eligible_hours_df.empty:
                # Extract the eligible hours column (assuming it's named 'eligibleHours')
                eligible_hours_df = eligible_hours_df.explode('payrollSnapShot')  # Flatten nested data if needed
                eligible_hours_df = pd.concat(
                    [eligible_hours_df[['associateId', 'payPeriodEndDate']].reset_index(drop=True),
                     pd.json_normalize(eligible_hours_df['payrollSnapShot'])],
                    axis=1
                )

                # Filter rows based on specific conditions (e.g., planId)
                eligible_hours_df = eligible_hours_df[
                    ((eligible_hours_df['planId'] == 'RETIREMENT_401K_REGULAR_US') |
                     (eligible_hours_df['planId'] == 'RETIREMENT_401K_REGULAR_PR'))
                ]

                # **POTENTIAL ISSUE #1: Check if required columns exist and create them if missing**
                required_columns = ['eligibleHours', 'adjustedHours', 'proratedHours']
                for col in required_columns:
                    if col not in eligible_hours_df.columns:
                        self.logger.warning(f"Column '{col}' not found in data, setting to 0")
                        eligible_hours_df[col] = 0

                # Move zeroes to Null columns
                eligible_hours_df[required_columns] = eligible_hours_df[required_columns].fillna(0)

                # **CRITICAL FIX: Group by associateId and sum eligible hours - this should ensure no duplicates**
                eligible_hours_summary = eligible_hours_df.groupby('associateId', as_index=False).agg({
                    'eligibleHours': 'sum',
                    'adjustedHours': 'sum',
                    'proratedHours': 'sum'
                })

                # Calculate Total Eligible Hours
                eligible_hours_summary['totalHours'] = eligible_hours_summary['eligibleHours'] + eligible_hours_summary[
                    'adjustedHours'] - eligible_hours_summary['proratedHours']

                # Fetch current payPeriodEndDate to fetch the prorated hours for that specific period
                try:
                    payperiod_enddate = self.fetch_current_payperiod_enddate()
                    # Find the latest payPeriodEndDate for each associate
                    if 'proratedHours' in eligible_hours_df.columns and payperiod_enddate:
                        latest_prorated_hours = eligible_hours_df.loc[
                            eligible_hours_df['payPeriodEndDate'].str.slice(0, 10) == payperiod_enddate, ['associateId',
                                                                                                          'proratedHours']
                        ]

                        if not latest_prorated_hours.empty:
                            # Group by associateId
                            latest_prorated_hours = latest_prorated_hours.groupby('associateId', as_index=False).agg({
                                'proratedHours': 'sum'  # Sum if multiple records exist for same associate/date
                            })

                            # Merge the latest proratedHours into eligible_hours_summary
                            eligible_hours_summary = eligible_hours_summary.merge(
                                latest_prorated_hours.rename(columns={'proratedHours': 'latestProratedHours'}),
                                on='associateId',
                                how='left'
                            )

                            # Add the latest proratedHours to totalHours
                            eligible_hours_summary['latestProratedHours'] = eligible_hours_summary[
                                'latestProratedHours'].fillna(0)
                            eligible_hours_summary['totalHours'] += eligible_hours_summary['latestProratedHours']
                        else:
                            self.logger.info("No prorated hours found for current pay period")
                    else:
                        self.logger.warning("proratedHours column not available or payperiod_enddate is None")
                except Exception as prorated_error:
                    self.logger.warning(f"Error processing current period prorated hours: {str(prorated_error)}")

            else:
                eligible_hours_summary = pd.DataFrame(columns=['associateId', 'totalHours'])
                self.logger.info("No eligible hours data found after processing.")

            if not eligible_hours_summary.empty:
                # Check for duplicates and log if found
                duplicate_count = eligible_hours_summary['associateId'].duplicated().sum()
                if duplicate_count > 0:
                    self.logger.warning(
                        f"Found {duplicate_count} duplicate associateIds in eligible_hours_summary, removing duplicates")
                    eligible_hours_summary = eligible_hours_summary.drop_duplicates(subset=['associateId'],
                                                                                    keep='first')

                eligible_hours_summary['R05-HOURS-SERVICE'] = eligible_hours_summary['totalHours'].apply(
                    lambda x: self.decimal_mainframe_conversion(x, 4, 3) if pd.notna(x) else '000000{')
            else:
                # Return empty DataFrame with required columns
                eligible_hours_summary = pd.DataFrame(columns=['associateId', 'totalHours', 'R05-HOURS-SERVICE'])

            self.logger.info(f"Successfully processed eligible hours for {len(eligible_hours_summary)} associates")
            return eligible_hours_summary

        except Exception as e:
            self.logger.error(f'Error in fetch_eligible_hours: {e}')
            # Return empty DataFrame instead of raising exception to prevent complete failure
            return pd.DataFrame(columns=['associateId', 'totalHours', 'R05-HOURS-SERVICE'])

    """
        Converts an integer value into a mainframe-specific format by replacing the last digit with a corresponding character.
        Parameters:
        - value (int): The integer value to be converted.

        Returns:
        - str: The formatted string with the last digit replaced by a character.

        Raises:
        - Exception: If there is an error during the conversion process.
    """
    def integer_lastbyte_conversion(self, value):
        try:
            last_digit = value % 10
            other_digits = (value // 10)

            # If there's a decimal part, convert it to letter
            if last_digit > 0:
                # Convert to corresponding letter (1->A, 2->B, etc)
                formatted_int = str(other_digits) + chr(64 + last_digit)
                return formatted_int
            else:
                formatted_int = str(other_digits) + "{"
                return formatted_int
        except:
            self.logger.error(f'Error in integer_lastbyte_conversion')
            raise

    """
        Converts an integer value into a mainframe-specific format by replacing the last digit with a corresponding character.
        Parameters:
        - value (int): The integer value to be converted.

        Returns:
        - str: The formatted string with the last digit replaced by a character.

        Raises:
        - Exception: If there is an error during the conversion process.
        """
    def decimal_mainframe_conversion(self, value, intlen, decilen):
        try:
            abs_rate = abs(float(value))

            # Get integer and decimal parts
            int_part = int(abs_rate)
            decimal_part = round(abs_rate - int_part, decilen)

            # Format integer part with leading zeros
            formatted_int = str(int_part).zfill(intlen)
            # Format decimal part and pick last digit
            decimal_part = str(round(decimal_part * (10 ** decilen))).zfill(decilen)
            if int(decimal_part) > 0:
                other_decimal_digits = decimal_part[0:decilen - 1]
                last_decimal_digit = int(decimal_part[decilen - 1])
            else:
                other_decimal_digits = '0' * (decilen - 1)
                last_decimal_digit = 0

            # If there's a decimal part, convert it to letter
            if last_decimal_digit > 0:
                # Convert to corresponding letter (1->A, 2->B, etc)
                formatted_int = formatted_int + other_decimal_digits + chr(64 + last_decimal_digit)
                return formatted_int
            else:
                return formatted_int + other_decimal_digits + "{"
        except:
            self.logger.error(f'Error in decimal_mainframe_conversion')
            raise

    """
        Determines the fiscal year, start date, and end date based on the current date.
        Returns:
        - tuple: A tuple containing:
            - fiscal_year (int): The determined fiscal year.
            - fiscal_year_start_date (str): The start date of the fiscal year in 'YYYY-MM-DD' format.
            - fiscal_year_end_date (str): The end date of the fiscal year in 'YYYY-MM-DD' format.

        Raises:
        - Exception: If there is an error during the calculation process.
        """
    def get_fiscal_year(self):
        try:
            current_date = datetime.now()

            if current_date.month > 1:
                fiscal_year = current_date.year + 1
            else:
                fiscal_year = current_date.year

            fiscal_year_start_date = str(fiscal_year - 1) + '-02-01'
            fiscal_year_end_date = str(fiscal_year) + '-01-31'

            return fiscal_year, fiscal_year_start_date, fiscal_year_end_date
        except:
            self.logger.error(f'Error in get_fiscal_year')
            raise

    """
        Fetches the current pay period end date from the DB2 database.
        The method queries the `hr_payroll_cycle` table using the `PAYPERIOD_END_DATE_QUERY`.
        It retrieves the `PAYPERIOD_ENDDATE` column and returns the first value from the result.
        If the query result is empty, it returns `None`
    """
    def fetch_current_payperiod_enddate(self):

        payperiod_enddate_col = ['PAYPERIOD_ENDDATE']

        payperiod_enddate_df = self.get_data_from_db2(
            col_names=payperiod_enddate_col,
            query=PAYPERIOD_END_DATE_QUERY.format(DB2_SCHEMA=self.db2_connection.testset, REGION=self.region),
            table_name='hr_payroll_cycle'
        )
        # Extract the value as a single string
        payperiod_enddate_value = payperiod_enddate_df['PAYPERIOD_ENDDATE'].iloc[0] if not payperiod_enddate_df.empty else None

        return payperiod_enddate_value

    def fetch_basic_core_hr_data(self, associate_list):
        """
        Fetches basic core HR data without ASC_STORE_JOB join.

        Parameters:
            associate_list (list): A list of associate IDs.

        Returns:
            pandas.DataFrame: A DataFrame containing the basic core HR data.
        """
        core_hr_col_names = ['WIN_NBR', 'NATIONAL_ID', 'LAST_NAME', 'FIRST_NAME', 'BIRTH_DATE',
                             'GENDER_CODE', 'ACT_MARITAL_CODE', 'HIRE_DATE', 'COMP_FREQ_CODE',
                             'HOME_ADDR_LINE_1', 'HOME_ADDR_LINE_2', 'CITY_NAME', 'STATE_PROV_CODE',
                             'POSTAL_CODE', 'STR_STATE_PROV_CD', 'STORE_NBR', 'CHRG_STORE_NBR',
                             'PAY_TYPE_CODE', 'TERMINATION_DATE', 'EMPLOY_STAT_CODE', 'TERM_REASON_CODE']

        self.logger.debug(f'associateList :: {associate_list}')

        # Split the associate_list into chunks of 10,000
        associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]

        # Initialize the result DataFrame
        core_hr_df = pd.DataFrame()

        # Basic core HR query without ASC_STORE_JOB join
        basic_query = ASSOCIATE_HR_QUERY

        # Loop through each chunk and append to the result DataFrame
        for associate_chunk in associate_chunks:
            associate_list_str = ",".join([f"{win}" for win in associate_chunk])
            chunk_df = self.get_data_from_db2(
                col_names=core_hr_col_names,
                query=basic_query.format(DB2_SCHEMA=self.db2_connection.testset, ASSOCIATE_LIST=associate_list_str,
                                         REGION=self.region,
                                         WV_FILTER=LOAN_WV_CONDITION if self.region == 'US' and self.flow_name == 'LOAN_DEDUCTION' else ''),
                table_name='basic_win_associate'
            )
            # Append to resultant dataframe
            core_hr_df = pd.concat([core_hr_df, chunk_df], ignore_index=True)

        return core_hr_df

    def fetch_asc_store_job_data(self, associate_list):
        """
        Fetches ASC_STORE_JOB data separately with left join logic.

        Parameters:
            associate_list (list): A list of associate IDs.

        Returns:
            pandas.DataFrame: A DataFrame containing the ASC_STORE_JOB data.
        """
        asc_store_job_cols = ['WIN_NBR', 'MDSE_DIV_NBR']

        self.logger.debug(f'Fetching ASC_STORE_JOB for associateList :: {associate_list}')

        # Split the associate_list into chunks of 10,000
        associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]

        # Initialize the result DataFrame
        asc_store_job_df = pd.DataFrame()

        # Simplified ASC_STORE_JOB query - using the same logic as the original but fixing the JOIN syntax
        asc_store_job_query = MDSE_DIV_NBR_QUERY

        # Loop through each chunk and append to the result DataFrame
        for associate_chunk in associate_chunks:
            associate_list_str = ",".join([f"{win}" for win in associate_chunk])
            try:
                chunk_df = self.get_data_from_db2(
                    col_names=asc_store_job_cols,
                    query=asc_store_job_query.format(DB2_SCHEMA=self.db2_connection.testset,
                                                     ASSOCIATE_LIST=associate_list_str,
                                                     REGION=self.region,
                                                     WV_FILTER=LOAN_WV_CONDITION if self.region == 'US' and self.flow_name == 'LOAN_DEDUCTION' else ''),
                    table_name='asc_store_job'
                )
                # Append to resultant dataframe
                asc_store_job_df = pd.concat([asc_store_job_df, chunk_df], ignore_index=True)
            except Exception as e:
                self.logger.error(f"Error fetching ASC_STORE_JOB data for chunk: {str(e)}")
                # Continue with other chunks even if one fails
                continue

        # Rename column to match expected name and remove duplicates
        if not asc_store_job_df.empty:
            asc_store_job_df = asc_store_job_df.rename(columns={'MDSE_DIV_NBR': 'CHRG_MDSE_DIV_NBR'})
            # Remove duplicates - keep first occurrence
            asc_store_job_df = asc_store_job_df.drop_duplicates(subset=['WIN_NBR'], keep='first')

        return asc_store_job_df

    """
        Fetches the current pay period end date from the DB2 database.
        The method queries the `hr_payroll_cycle` table using the `PAYROLL_END_DATE_QUERY`.
        It retrieves the `PAYROLL_ENDDATE` column and returns the first value from the result.
        If the query result is empty, it returns `None`
    """
    def fetch_current_payroll_enddate(self):
        payroll_enddate_col = ['PAYROLL_END_DATE']
        payroll_enddate_df = self.get_data_from_db2(
            col_names=payroll_enddate_col,
            query=PAYROLL_END_DATE_QUERY.format(DB2_SCHEMA=self.db2_connection.testset, REGION=self.region),
            table_name='hr_payroll_cycle'
        )

        if not payroll_enddate_df.empty:
            date_str = payroll_enddate_df['PAYROLL_END_DATE'].iloc[0]
            return datetime.strptime(date_str, "%Y-%m-%d")
        else:
            return None

    def getSAPActiveAssociates(self):
        """
        Retrieves a DataFrame of SAP active associates from the DB2 database.

        Returns:
            pandas.DataFrame: A DataFrame containing the WIN_NBR of SAP active associates.
        """
        sap_col = ['WIN_NBR']
        payroll_enddate_df = self.get_data_from_db2(
            col_names=sap_col,
            query=IS_SAP_ACTIVE_ASSOC_QUERY.format(DB2_SCHEMA=self.db2_connection.testset, REGION=self.region),
            table_name='sap_associates'
        )
        return payroll_enddate_df
