import csv
import os
import pandas as pd
import uuid
import json
from flask import jsonify
from datetime import datetime
from src.constants import F_WORK_IN_PROGRESS, F_ERROR, PG_SQL_VALUE_LIMIT_99
from src.integrations.postgre_sql_conn_helper import PostgresGCPConnection
from src.utils.errors.app_errors import CreateJsonResponseError, ApplicationError
from src.utils.sql import INSERT_TO_FC_TRACKER, UPDATE_FC_TRACKER, SELECT_FC_TRACKER, UPDATE_FC_TRACKER_DETAILS

"""
create a directory if not exists in the server
args - directory name ex -
       logger: logger object can be passed
               logger.info method is used to log message
return - None
"""
def create_dir_if_not_exists(dir_name, logger=None):
    if not os.path.exists(dir_name):
        os.makedirs(dir_name, exist_ok=True)
        if logger:
            logger.info(f"Directory {dir_name} created")
        return 1

    else:
        if logger:
            logger.info(f"Directory {dir_name} exists already")
        return 0

"""
Writes a list of content to a file.

Args:
    file_path (str): The path of the file to write.
    file_content (List[str]): The content to write to the file.
    logger (Optional[logging.Logger]): The logger to use for logging.

Returns:
    None
"""
def write_list_to_file(file_path, file_content, logger):

    # Create the directory if it doesn't exist
    with open(file_path, 'w') as file:
        file.write(','.join(file_content) + '\n')
    if logger: logger.info(f"File {file_path} created successfully")


"""
Writes a pandas DataFrame to a CSV file.

Args:
    file_path (str): The path of the file to write.
    data_frame (pandas.DataFrame): The DataFrame to write to the file.
    logger (Optional[logging.Logger]): The logger to use for logging.

Returns:
    None
"""
def write_dataframe_to_file(file_path,data_frame, logger):

    data_frame.to_csv(file_path, index=False, quoting=csv.QUOTE_NONNUMERIC)
    if logger: logger.info(f"File {file_path} created successfully")


"""
Reads a CSV file and load it into a pandas DataFrame.

Args:
    file_path (str): The path of the file to read.
    logger (Optional[logging.Logger]): The logger to use for logging.

Returns:
    data_frame (pandas.DataFrame): The DataFrame loaded from the file.
"""

def read_file_to_dataframe(file_path, logger=None):
    try:
        data_frame = pd.read_csv(file_path, quoting=csv.QUOTE_NONNUMERIC)
        if logger: logger.info(f"File {file_path} loaded successfully")
        return data_frame
    except Exception as e:
        if logger: logger.error(f"Error occurred while loading file {file_path}: {str(e)}")
        raise e

def create_json_response(request_id, message, code):
    try:
        response = {
            'request_id': request_id,
            'status': message,
        }
        return jsonify(response, code)
    except Exception as e:
        raise CreateJsonResponseError(e)


def record_request_id(request_id,request_body, module,logger=None):
    try:
        # Log the JSON
        logger.info(f"Request body: {json.dumps(request_body, indent=4)}")

        # Extract required fields
        configuration_id = request_body.get("configurationId")
        current_status = F_WORK_IN_PROGRESS
        db_connection = PostgresGCPConnection(logger=logger)
        now = datetime.now()

        with db_connection as conn:
            values = (request_id, configuration_id, module, str(request_body)[:PG_SQL_VALUE_LIMIT_99],now,now,current_status)
            conn.execute_nonquery(INSERT_TO_FC_TRACKER, values)
            conn.commit()
            logger.info(f'Request ID: {request_id} recorded successfully in DB')

    except Exception as e:
        logger.error(f'Error recording the request{request_id} in DB with error {str(e)}')
        raise ApplicationError("record_request_id", str(e))

def update_request_status(request_id, status, logger=None, error_message=None):
    try:
        db_connection = PostgresGCPConnection(logger=logger)
        with db_connection as conn:
            # First check if already in error state
            current_status = conn.execute_query(SELECT_FC_TRACKER,
                (request_id,)
            )

            # If already in error state, don't update
            if current_status and current_status[0][0] == F_ERROR:
                logger.info(f"Request {request_id} already in error state, skipping status update")
                return

            # If not in error, proceed with update
            now = datetime.now()
            if status == F_ERROR:
                # Truncate error message to fit varchar(100)
                truncated_error = error_message[:97] + '...' if error_message and len(error_message) > 100 else error_message
                values = (status, now, truncated_error, request_id)
                conn.execute_nonquery(UPDATE_FC_TRACKER_DETAILS, values)
            else:
                values = (status, now, request_id)
                conn.execute_nonquery(UPDATE_FC_TRACKER, values)
            conn.commit()
            logger.info("status updated successfully")

    except Exception as e:
        logger.error(f"Error initializing request and generate ID: {str(e)}")
        raise ApplicationError("record_request_id", str(e))


"""
Generate a unique request ID.

Returns:
    str: The generated request ID.
"""
def generate_request_id():
    return str(uuid.uuid1())
