import logging
import os

import src.utils.app_config as app_config

def get_working_directory():
    working_dir = app_config.get_config_value("app","working_dir")
    os.makedirs(working_dir, exist_ok=True)
    print(f'Working directory is created: {working_dir}')
    return working_dir

def setup_request_logger(request_id):
    log_level = app_config.get_config_value("app","log_level")
    log_format = app_config.get_config_value("app","log_format")
    logger = logging.getLogger(f'{request_id}')

    # if not logger.hasHandlers():
    logger.setLevel(log_level)
    logger.handlers.clear()
    working_dir = get_working_directory()
    request_dir = str(os.path.join(working_dir, request_id))
    os.makedirs(request_dir, exist_ok=True)

    log_file = os.path.join(request_dir, f'{request_id}.log')

    #create a file handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(logging.Formatter(log_format))

    #create a console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(log_format))

    # add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

