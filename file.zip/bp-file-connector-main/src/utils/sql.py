ASSOCIATE_INFO = """
    SELECT 
    A.WIN_NBR as WIN_NBR, A.NATIONAL_ID as NATIONAL_ID,  A.LAST_NAME as LAST_NAME,  A.FIRST_NAME as FIRST_NAME,  A.BIRTH_DATE as BIRTH_DATE,  A.GENDER_CODE as GENDER_CODE,  A.ACT_MARITAL_CODE as ACT_MARITAL_CODE, 
    A.HIRE_DATE as HIRE_DATE,  A.COMP_FREQ_CODE as COMP_FREQ_CODE,  A.HOME_ADDR_LINE_1 as HOME_ADDR_LINE_1, A.HOME_ADDR_LINE_2 as HOME_ADDR_LINE_2, A.CITY_NAME as CITY_NAME,  A.STATE_PROV_CODE as STATE_PROV_CODE,  A.POSTAL_CODE as POSTAL_CODE, 
    A.STR_STATE_PROV_CD as STR_STATE_PROV_CD, A.STORE_NBR as STORE_NBR,  A.CHRG_STORE_NBR as CHRG_STORE_NBR,  A.PAY_TYPE_CODE as PAY_TYPE_CODE,  A.TERMINATION_DATE as TERMINATION_DATE, B.MDSE_DIV_NBR as CHRG_MDSE_DIV_NBR,
    A.EMPLOY_STAT_CODE as EMPLOY_STAT_CODE,A.TERM_REASON_CODE as TERM_REASON_CODE
    FROM {DB2_SCHEMA}GBLASC.V3_WIN_ASC_NID_US A, {DB2_SCHEMA}GBLASC.ASC_STORE_JOB B
    WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}) )
    AND (A.STR_STATE_PROV_CD = '{REGION}' OR ('{REGION}' = 'US' AND A.STR_STATE_PROV_CD <> 'PR' {WV_FILTER}))
    AND   (A.WIN_NBR = B.WIN_NBR)
    AND (A.STR_COUNTRY_CODE = B.STR_COUNTRY_CODE)
    AND (A.STORE_NBR = B.STORE_NBR)
    AND (A.HR_SOURCE_CODE = B.HR_SOURCE_CODE)
    AND ((A.EMPLOY_STAT_CODE NOT IN ('T','D') AND
          (B.OBSOLETE_DATE IS NULL OR B.OBSOLETE_DATE >=
           CURRENT DATE)) OR
          (A.EMPLOY_STAT_CODE  IN ('T','D') AND
            (B.OBSOLETE_DATE IN (SELECT
             MAX (Z.OBSOLETE_DATE) FROM
             {DB2_SCHEMA}GBLASC.ASC_STORE_JOB Z
             WHERE Z.WIN_NBR = A.WIN_NBR
             AND Z.EFFECTIVE_DATE <= CURRENT_DATE
             AND A.STORE_NBR  = Z.STORE_NBR))
            )
           )
    AND B.JOB_TYPE_SEQ_NBR = 0
    AND B.EFFECTIVE_DATE IN
    (SELECT MAX (EFFECTIVE_DATE) FROM
    {DB2_SCHEMA}GBLASC.ASC_STORE_JOB C WHERE C.WIN_NBR = A.WIN_NBR
    AND C.EFFECTIVE_DATE <= CURRENT_DATE AND
    ((A.EMPLOY_STAT_CODE NOT IN ('T','D') AND
    (C.OBSOLETE_DATE IS NULL OR C.OBSOLETE_DATE >=
                          CURRENT DATE)) OR
    (A.EMPLOY_STAT_CODE  IN ('T','D') AND
    (C.OBSOLETE_DATE IN (SELECT
    MAX (Z.OBSOLETE_DATE)  FROM {DB2_SCHEMA}GBLASC.ASC_STORE_JOB Z
    WHERE Z.WIN_NBR = A.WIN_NBR AND
    Z.EFFECTIVE_DATE <= CURRENT_DATE
    AND A.STORE_NBR  = Z.STORE_NBR)))
   )
   AND A.STORE_NBR  = C.STORE_NBR
   AND C.JOB_TYPE_SEQ_NBR = 0
   AND C.HR_SOURCE_CODE = A.HR_SOURCE_CODE
  )
  WITH UR;
  """

STATE_TRANSFER_TO_US = """
    SELECT A.WIN_NBR as WIN_NBR, A.STR_STATE_PROV_CD AS CURRENT_STATE , C.STATE_CODE AS PREVIOUS_STATE
    FROM {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE a, {DB2_SCHEMA}PAYRL0.ASSOCIATE_ID_hist b, {DB2_SCHEMA}PEOPLE.STATE c, {DB2_SCHEMA}GBLASC.WIN_SSN_XREF_TMP x
    WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}))  
    AND A.WIN_NBR = x.WIN_NBR 
    and b.ASC_SS_NBR = x.SSN_NBR 
    AND B.ASC_WORK_STATE = C.STATE_NBR
    AND A.COUNTRY_CODE in ('US')
    AND DATE(A.INSERT_TS) BETWEEN DATE('{START_DATE}') - 1 DAY AND '{END_DATE}'
    AND C.STATE_CODE = 'PR'
    AND A.STR_STATE_PROV_CD <> 'PR'
    AND B.LAST_CHANGE_DATE = (SELECT MAX(D.LAST_CHANGE_DATE) 
                            FROM {DB2_SCHEMA}PAYRL0.ASSOCIATE_ID_HIST D
                            WHERE D.ASC_SS_NBR = X.SSN_NBR
                            AND D.LAST_CHANGE_DATE < (SELECT MIN(DATE(E.INSERT_TS))
                                                        FROM {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE_LOG E
                                                        WHERE E.WIN_NBR = X.WIN_NBR
                                                        AND E.STR_STATE_PROV_CD = A.STR_STATE_PROV_CD
                                                        AND E.COUNTRY_CODE = 'US'
                                                        AND DATE(E.INSERT_TS) BETWEEN '{START_DATE}' AND '{END_DATE}'))
    WITH UR;
    """

STATE_TRANSFER_TO_PR = """
    SELECT A.WIN_NBR as WIN_NBR, A.STR_STATE_PROV_CD AS CURRENT_STATE , C.STATE_CODE AS PREVIOUS_STATE
    FROM {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE a, {DB2_SCHEMA}PAYRL0.ASSOCIATE_ID_hist b, {DB2_SCHEMA}PEOPLE.STATE c, {DB2_SCHEMA}GBLASC.WIN_SSN_XREF_TMP x
    WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}))  
    AND A.WIN_NBR = x.WIN_NBR 
    and b.ASC_SS_NBR = x.SSN_NBR 
    AND B.ASC_WORK_STATE = C.STATE_NBR
    AND A.COUNTRY_CODE in ('US')
    AND DATE(A.INSERT_TS) BETWEEN DATE('{START_DATE}') - 1 DAY AND '{END_DATE}'
    AND C.STATE_CODE <> 'PR'
    AND A.STR_STATE_PROV_CD = 'PR'
    AND B.LAST_CHANGE_DATE = (SELECT MAX(D.LAST_CHANGE_DATE) 
                            FROM {DB2_SCHEMA}PAYRL0.ASSOCIATE_ID_HIST D
                            WHERE D.ASC_SS_NBR = X.SSN_NBR
                            AND D.LAST_CHANGE_DATE < (SELECT MIN(DATE(E.INSERT_TS)) 
                                                        FROM {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE_LOG E
                                                        WHERE E.WIN_NBR = X.WIN_NBR
                                                        AND E.STR_STATE_PROV_CD = A.STR_STATE_PROV_CD
                                                        AND E.COUNTRY_CODE = 'US'
                                                        AND DATE(E.INSERT_TS) BETWEEN '{START_DATE}' AND '{END_DATE}'))
    WITH UR;
    """

BASIC_CORE_HR_QUERY = """
    SELECT 
    WIN_NBR as WIN_NBR, NATIONAL_ID as NATIONAL_ID,  LAST_NAME as LAST_NAME,  FIRST_NAME as FIRST_NAME,  BIRTH_DATE as BIRTH_DATE,  GENDER_CODE as GENDER_CODE,  ACT_MARITAL_CODE as ACT_MARITAL_CODE, 
    HIRE_DATE as HIRE_DATE,  COMP_FREQ_CODE as COMP_FREQ_CODE,  HOME_ADDR_LINE_1 as HOME_ADDR_LINE_1, CITY_NAME as CITY_NAME,  STATE_PROV_CODE as STATE_PROV_CODE,  POSTAL_CODE as POSTAL_CODE, 
    STR_STATE_PROV_CD as STR_STATE_PROV_CD, STORE_NBR as STORE_NBR,  CHRG_STORE_NBR as CHRG_STORE_NBR,  PAY_TYPE_CODE as PAY_TYPE_CODE,  TERMINATION_DATE as TERMINATION_DATE, CHRG_MDSE_DIV_NBR as CHRG_MDSE_DIV_NBR
    FROM {DB2_SCHEMA}GBLASC.V3_WIN_ASC_NID_US A
    WHERE (WIN_NBR IN ({ASSOCIATE_LIST}) )
    """

WIN_SSN_MAPPING_CORE_HR_QUERY = """
    SELECT 
    WIN_NBR, NATIONAL_ID
    FROM {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE A
    WHERE (WIN_NBR IN ({ASSOCIATE_LIST}) )
    """


DIVISION_NUMBER_QUERY = """
    SELECT 
    business_unit_nbr as STORE_NBR, base_division_code as DIV_NBR 
    FROM wmt-loc-cat-prod.catalog_location_tables.businessunit 
    WHERE (business_unit_nbr in ({STORE_LIST}) ) 
    AND country_code IN ('US','PR')
    """

ELIGIBLE_WAGES_QUERY = """
WITH earnings AS (
    SELECT
        p.win_nbr,
        p.pay_center_id,
        p.payroll_run_date,
        e.payroll_end_date,
        e.earning_type_code,
        e.pay_seq_code as earn_pay_sequence,
        e.earn_amt,
        e.ytd_tot_earn_amt,
        CAST(' ' AS STRING) as doe_code,
        CAST(' ' AS STRING) as  doe_pay_sequence,
        NULL as doe_amt,
        NULL as ytd_tot_doe_amt,
        p.pay_frequency_code,
        p.national_id,
        CASE
            WHEN p.work_state_prov_cd = '80' THEN 'AB'
            WHEN p.work_state_prov_cd = '02' THEN 'AK'
            WHEN p.work_state_prov_cd = '01' THEN 'AL'
            WHEN p.work_state_prov_cd = '04' THEN 'AR'
            WHEN p.work_state_prov_cd = '60' THEN 'AS'
            WHEN p.work_state_prov_cd = '03' THEN 'AZ'
            WHEN p.work_state_prov_cd = '81' THEN 'BC'
            WHEN p.work_state_prov_cd = '54' THEN 'BR'
            WHEN p.work_state_prov_cd = '05' THEN 'CA'
            WHEN p.work_state_prov_cd = '93' THEN 'CH'
            WHEN p.work_state_prov_cd = '06' THEN 'CO'
            WHEN p.work_state_prov_cd = '07' THEN 'CT'
            WHEN p.work_state_prov_cd = '09' THEN 'DC'
            WHEN p.work_state_prov_cd = '08' THEN 'DE'
            WHEN p.work_state_prov_cd = '10' THEN 'FL'
            WHEN p.work_state_prov_cd = '61' THEN 'FM'
            WHEN p.work_state_prov_cd = '11' THEN 'GA'
            WHEN p.work_state_prov_cd = '92' THEN 'GD'
            WHEN p.work_state_prov_cd = '62' THEN 'GU'
            WHEN p.work_state_prov_cd = '12' THEN 'HI'
            WHEN p.work_state_prov_cd = '57' THEN 'HK'
            WHEN p.work_state_prov_cd = '16' THEN 'IA'
            WHEN p.work_state_prov_cd = '13' THEN 'ID'
            WHEN p.work_state_prov_cd = '14' THEN 'IL'
            WHEN p.work_state_prov_cd = '15' THEN 'IN'
            WHEN p.work_state_prov_cd = '17' THEN 'KS'
            WHEN p.work_state_prov_cd = '18' THEN 'KY'
            WHEN p.work_state_prov_cd = '19' THEN 'LA'
            WHEN p.work_state_prov_cd = '22' THEN 'MA'
            WHEN p.work_state_prov_cd = '82' THEN 'MB'
            WHEN p.work_state_prov_cd = '21' THEN 'MD'
            WHEN p.work_state_prov_cd = '20' THEN 'ME'
            WHEN p.work_state_prov_cd = '63' THEN 'MH'
            WHEN p.work_state_prov_cd = '23' THEN 'MI'
            WHEN p.work_state_prov_cd = '24' THEN 'MN'
            WHEN p.work_state_prov_cd = '26' THEN 'MO'
            WHEN p.work_state_prov_cd = '64' THEN 'MP'
            WHEN p.work_state_prov_cd = '25' THEN 'MS'
            WHEN p.work_state_prov_cd = '27' THEN 'MT'
            WHEN p.work_state_prov_cd = '53' THEN 'MX'
            WHEN p.work_state_prov_cd = '83' THEN 'NB'
            WHEN p.work_state_prov_cd = '34' THEN 'NC'
            WHEN p.work_state_prov_cd = '35' THEN 'ND'
            WHEN p.work_state_prov_cd = '28' THEN 'NE'
            WHEN p.work_state_prov_cd = '84' THEN 'NF'
            WHEN p.work_state_prov_cd = '30' THEN 'NH'
            WHEN p.work_state_prov_cd = '31' THEN 'NJ'
            WHEN p.work_state_prov_cd = '32' THEN 'NM'
            WHEN p.work_state_prov_cd = '85' THEN 'NS'
            WHEN p.work_state_prov_cd = '90' THEN 'NT'
            WHEN p.work_state_prov_cd = '29' THEN 'NV'
            WHEN p.work_state_prov_cd = '33' THEN 'NY'
            WHEN p.work_state_prov_cd = '36' THEN 'OH'
            WHEN p.work_state_prov_cd = '37' THEN 'OK'
            WHEN p.work_state_prov_cd = '86' THEN 'ON'
            WHEN p.work_state_prov_cd = '38' THEN 'OR'
            WHEN p.work_state_prov_cd = '39' THEN 'PA'
            WHEN p.work_state_prov_cd = '87' THEN 'PE'
            WHEN p.work_state_prov_cd = '88' THEN 'PQ'
            WHEN p.work_state_prov_cd = '52' THEN 'PR'
            WHEN p.work_state_prov_cd = '65' THEN 'PW'
            WHEN p.work_state_prov_cd = '88' THEN 'QC'
            WHEN p.work_state_prov_cd = '40' THEN 'RI'
            WHEN p.work_state_prov_cd = '41' THEN 'SC'
            WHEN p.work_state_prov_cd = '42' THEN 'SD'
            WHEN p.work_state_prov_cd = '89' THEN 'SK'
            WHEN p.work_state_prov_cd = '43' THEN 'TN'
            WHEN p.work_state_prov_cd = '44' THEN 'TX'
            WHEN p.work_state_prov_cd = '45' THEN 'UT'
            WHEN p.work_state_prov_cd = '47' THEN 'VA'
            WHEN p.work_state_prov_cd = '66' THEN 'VI'
            WHEN p.work_state_prov_cd = '46' THEN 'VT'
            WHEN p.work_state_prov_cd = '48' THEN 'WA'
            WHEN p.work_state_prov_cd = '50' THEN 'WI'
            WHEN p.work_state_prov_cd = '49' THEN 'WV'
            WHEN p.work_state_prov_cd = '51' THEN 'WY'
            WHEN p.work_state_prov_cd = '91' THEN 'YT'
        ELSE 'US'
        END AS state_code
    FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` p
    INNER JOIN `{gcp_project}.{bigquery_dataset}.HR_ASC_EARNINGS` e
        ON p.win_nbr = e.WIN_NBR 
        AND p.payroll_run_date = e.payroll_run_date
        AND p.pay_center_id = e.pay_center_id
    WHERE p.payroll_run_date = @run_date
    AND e.earning_type_code IN ({earn_type_codes})
    AND (p.employ_stat_code NOT IN ('T','D')  OR e.earn_amt <> 0)
),
deductions AS (
    SELECT
        p.win_nbr,
        p.pay_center_id,
        p.payroll_run_date,
        d.payroll_end_date,
        NULL as earning_type_code,
        CAST(' ' AS STRING) as earn_pay_sequence,
        NULL as earn_amt,
        NULL as ytd_tot_earn_amt,
        case WHEN d.doe_code IS NULL OR TRIM(d.doe_code) = '' THEN d.wg_type_cd ELSE d.doe_code end,
        d.pay_seq_code as doe_pay_sequence,
        d.doe_amt,
        d.ytd_tot_doe_amt,
        p.pay_frequency_code,
        p.national_id,
        CASE
            WHEN p.work_state_prov_cd = '80' THEN 'AB'
            WHEN p.work_state_prov_cd = '02' THEN 'AK'
            WHEN p.work_state_prov_cd = '01' THEN 'AL'
            WHEN p.work_state_prov_cd = '04' THEN 'AR'
            WHEN p.work_state_prov_cd = '60' THEN 'AS'
            WHEN p.work_state_prov_cd = '03' THEN 'AZ'
            WHEN p.work_state_prov_cd = '81' THEN 'BC'
            WHEN p.work_state_prov_cd = '54' THEN 'BR'
            WHEN p.work_state_prov_cd = '05' THEN 'CA'
            WHEN p.work_state_prov_cd = '93' THEN 'CH'
            WHEN p.work_state_prov_cd = '06' THEN 'CO'
            WHEN p.work_state_prov_cd = '07' THEN 'CT'
            WHEN p.work_state_prov_cd = '09' THEN 'DC'
            WHEN p.work_state_prov_cd = '08' THEN 'DE'
            WHEN p.work_state_prov_cd = '10' THEN 'FL'
            WHEN p.work_state_prov_cd = '61' THEN 'FM'
            WHEN p.work_state_prov_cd = '11' THEN 'GA'
            WHEN p.work_state_prov_cd = '92' THEN 'GD'
            WHEN p.work_state_prov_cd = '62' THEN 'GU'
            WHEN p.work_state_prov_cd = '12' THEN 'HI'
            WHEN p.work_state_prov_cd = '57' THEN 'HK'
            WHEN p.work_state_prov_cd = '16' THEN 'IA'
            WHEN p.work_state_prov_cd = '13' THEN 'ID'
            WHEN p.work_state_prov_cd = '14' THEN 'IL'
            WHEN p.work_state_prov_cd = '15' THEN 'IN'
            WHEN p.work_state_prov_cd = '17' THEN 'KS'
            WHEN p.work_state_prov_cd = '18' THEN 'KY'
            WHEN p.work_state_prov_cd = '19' THEN 'LA'
            WHEN p.work_state_prov_cd = '22' THEN 'MA'
            WHEN p.work_state_prov_cd = '82' THEN 'MB'
            WHEN p.work_state_prov_cd = '21' THEN 'MD'
            WHEN p.work_state_prov_cd = '20' THEN 'ME'
            WHEN p.work_state_prov_cd = '63' THEN 'MH'
            WHEN p.work_state_prov_cd = '23' THEN 'MI'
            WHEN p.work_state_prov_cd = '24' THEN 'MN'
            WHEN p.work_state_prov_cd = '26' THEN 'MO'
            WHEN p.work_state_prov_cd = '64' THEN 'MP'
            WHEN p.work_state_prov_cd = '25' THEN 'MS'
            WHEN p.work_state_prov_cd = '27' THEN 'MT'
            WHEN p.work_state_prov_cd = '53' THEN 'MX'
            WHEN p.work_state_prov_cd = '83' THEN 'NB'
            WHEN p.work_state_prov_cd = '34' THEN 'NC'
            WHEN p.work_state_prov_cd = '35' THEN 'ND'
            WHEN p.work_state_prov_cd = '28' THEN 'NE'
            WHEN p.work_state_prov_cd = '84' THEN 'NF'
            WHEN p.work_state_prov_cd = '30' THEN 'NH'
            WHEN p.work_state_prov_cd = '31' THEN 'NJ'
            WHEN p.work_state_prov_cd = '32' THEN 'NM'
            WHEN p.work_state_prov_cd = '85' THEN 'NS'
            WHEN p.work_state_prov_cd = '90' THEN 'NT'
            WHEN p.work_state_prov_cd = '29' THEN 'NV'
            WHEN p.work_state_prov_cd = '33' THEN 'NY'
            WHEN p.work_state_prov_cd = '36' THEN 'OH'
            WHEN p.work_state_prov_cd = '37' THEN 'OK'
            WHEN p.work_state_prov_cd = '86' THEN 'ON'
            WHEN p.work_state_prov_cd = '38' THEN 'OR'
            WHEN p.work_state_prov_cd = '39' THEN 'PA'
            WHEN p.work_state_prov_cd = '87' THEN 'PE'
            WHEN p.work_state_prov_cd = '88' THEN 'PQ'
            WHEN p.work_state_prov_cd = '52' THEN 'PR'
            WHEN p.work_state_prov_cd = '65' THEN 'PW'
            WHEN p.work_state_prov_cd = '88' THEN 'QC'
            WHEN p.work_state_prov_cd = '40' THEN 'RI'
            WHEN p.work_state_prov_cd = '41' THEN 'SC'
            WHEN p.work_state_prov_cd = '42' THEN 'SD'
            WHEN p.work_state_prov_cd = '89' THEN 'SK'
            WHEN p.work_state_prov_cd = '43' THEN 'TN'
            WHEN p.work_state_prov_cd = '44' THEN 'TX'
            WHEN p.work_state_prov_cd = '45' THEN 'UT'
            WHEN p.work_state_prov_cd = '47' THEN 'VA'
            WHEN p.work_state_prov_cd = '66' THEN 'VI'
            WHEN p.work_state_prov_cd = '46' THEN 'VT'
            WHEN p.work_state_prov_cd = '48' THEN 'WA'
            WHEN p.work_state_prov_cd = '50' THEN 'WI'
            WHEN p.work_state_prov_cd = '49' THEN 'WV'
            WHEN p.work_state_prov_cd = '51' THEN 'WY'
            WHEN p.work_state_prov_cd = '91' THEN 'YT'
        ELSE 'US'
        END AS state_code
    FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` p
    INNER JOIN `{gcp_project}.{bigquery_dataset}.HR_ASC_DOE` d
        ON p.win_nbr = d.WIN_NBR 
        AND p.payroll_run_date = d.payroll_run_date
        AND p.pay_center_id = d.pay_center_id
    WHERE p.payroll_run_date = @run_date
    AND (p.employ_stat_code NOT IN ('T','D')  OR d.doe_amt <> 0)
    AND (d.doe_code in ({doe_codes}) or d.wg_type_cd = '/102')
)
SELECT * FROM earnings
UNION ALL 
SELECT * FROM deductions
ORDER BY 
    national_id,
    pay_center_id,
    CASE 
        WHEN earning_type_code IS NOT NULL THEN 2
        WHEN doe_code IS NOT NULL THEN 3
        ELSE 1
    END,
    earning_type_code,
    doe_code,
    doe_pay_sequence
"""

GET_MAX_RUN_DATE_FOR_HOURS_QUERY = """
SELECT MAX(payroll_run_date) as max_date 
FROM `{gcp_project}.{bigquery_dataset}.HR_ASC_HOURS_TYPE`
"""

GET_MAX_RUN_DATE_FOR_WAGES_QUERY = """
SELECT MAX(payroll_run_date) as max_date 
FROM `{gcp_project}.{bigquery_dataset}.HR_ASC_EARNINGS`
"""

INSERT_TO_FC_TRACKER = """ INSERT INTO connector.fc_tracker (request_id, configuration_id, module_name, request_body, 
                               request_create_ts, request_last_update_ts, current_status) 
                           VALUES(%s, %s, %s, %s, %s, %s, %s);
"""

UPDATE_FC_TRACKER = """ UPDATE connector.fc_tracker SET current_status = %s, request_last_update_ts = %s 
                        WHERE request_id = %s;"""

SELECT_FC_TRACKER = """ SELECT current_status FROM connector.fc_tracker WHERE request_id = %s; """

SELECT_QUEUED_RECORDS = """ select associate_id as "associateId" from core_engine.archive_events ae,core_engine.event_status es where ae.id = es.archive_event_id
and ae.event_type = %s and es.status = 'QUEUED'
order by ae.created_at desc; """

UPDATE_FC_TRACKER_DETAILS = """ UPDATE connector.fc_tracker 
                                SET current_status = %s,request_last_update_ts = %s, detailed_status = %s
                                WHERE request_id = %s"""

PAID_ASSOCIATE_QUERY = """
WITH associate AS (
    SELECT distinct
        p.win_nbr,
        p.pay_type_code,
        p.pay_frequency_code,
        P.pay_center_id,
        h.payroll_end_date,
        p.asc_type_code,
        p.termination_date, 
        p.work_state_prov_cd,
        p.employ_stat_code
    FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` p
    INNER JOIN `{gcp_project}.{bigquery_dataset}.HR_ASC_HOURS_TYPE` h
        ON p.win_nbr = h.WIN_NBR 
        AND p.payroll_run_date = h.payroll_run_date
        AND p.pay_center_id = h.pay_center_id
    WHERE p.payroll_run_date >= DATE_SUB(@run_date, INTERVAL 60 DAY)
)
SELECT * FROM associate
ORDER BY 
    win_nbr
"""

ELIGIBLE_HOURS_HR_ASC_HOURS_TYPE_QUERY = """
WITH hours AS (
    SELECT
        p.win_nbr,
        h.payroll_end_date,
        p.pay_center_id,
        h.hour_type_code,
        h.hours_qty,
        h.pay_seq_code
    FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` p
    INNER JOIN `{gcp_project}.{bigquery_dataset}.HR_ASC_HOURS_TYPE` h
        ON p.win_nbr = h.WIN_NBR 
        AND p.payroll_run_date = h.payroll_run_date
        AND p.pay_center_id = h.pay_center_id
    WHERE p.payroll_run_date >= DATE_SUB(@run_date, INTERVAL 60 DAY)
    AND h.hours_qty <> 0
)
SELECT * FROM hours
ORDER BY 
    win_nbr,
    pay_center_id,
    hour_type_code
"""
# and a.business_date between @run_date and @run_date - 60 Days
ELIGIBLE_HOURS_ASC_DAILY_PAY_SUM = """
select a.win_nbr, a.business_date, SUM(a.pay_hour_qty) as hours
from `{gcp_project}.{bigquery_dataset_GTA}.ASC_DAILY_PAY_SUM` a 
where a.business_date BETWEEN DATE_SUB(@run_date, INTERVAL 60 DAY) AND @run_date 
GROUP BY a.WIN_NBR, a.business_date
"""
ELIGIBLE_HOURS_ETCAR_ASC_DAILY_PAY_SUM = """
select a.win_nbr, a.business_date, SUM(a.pay_hour_qty) as hours
from `{gcp_project}.{bigquery_dataset_GTA}.ETCAR_ASC_DAILY_PAY_SUM` a 
where a.business_date BETWEEN DATE_SUB(@run_date, INTERVAL 60 DAY) AND @run_date 
GROUP BY a.WIN_NBR, a.business_date
"""

LOAN_DATA_QUERY = """
SELECT 
    d.win_nbr,
    d.doe_code,
    sum(d.doe_amt) as doe_amt
FROM 
    `{gcp_project}.{bigquery_dataset}.HR_ASC_DOE` d
WHERE 
    d.win_nbr IN ({ASSOCIATE_LIST})
    AND d.doe_code IN ('{LOAN_DEDUCTION_CODE_K4}', '{LOAN_DEDUCTION_CODE_K5}')
    AND d.payroll_run_date = (SELECT MAX(payroll_run_date) FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` WHERE PAY_CENTER_ID IN(1, 2, 4))
group by d.win_nbr, d.doe_code 
"""

LOAN_DATA_QUERY_FULL_UNLOAD = """
with DEDUCTION as (
    SELECT 
        d.win_nbr,
        d.doe_code,
        sum(d.doe_amt) as doe_amt
    FROM 
        `{gcp_project}.{bigquery_dataset}.HR_ASC_DOE` d
    WHERE 
        d.payroll_run_date = (SELECT MAX(payroll_run_date) FROM `wmt-us-hr-prod.WW_HR_DL_US_PAYROLL_SECURE.PAID_ASSOCIATE` WHERE PAY_CENTER_ID IN(1,2,4))
        AND d.doe_code IN ('K4','K5')
        AND d.doe_amt > 0
    group by d.win_nbr, d.doe_code
    )
    SELECT 
    A.win_nbr as associateId, 
    A.national_id as NATIONAL_ID,
    B.doe_code as loanIndicator,
    B.doe_amt
    FROM
    `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` A  
    INNER JOIN
    DEDUCTION B
    USING (WIN_NBR)
    WHERE
    A.STR_STATE_PROV_CD {state_code_filter}
    AND A.effective_ts = (SELECT max(A1.effective_ts) FROM `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` A1 WHERE A.win_nbr = A1.win_nbr)
"""

WIN_SSN_MAPPING_GCP_QUERY = """
    SELECT 
    DISTINCT WIN_NBR as win_nbr, NATIONAL_ID as national_id
    FROM `{gcp_project}.{bigquery_dataset}.PAID_ASSOCIATE` A     
    WHERE (WIN_NBR IN ({win_list_str}))
"""

IMPACTED_ASSOCIATE_IDS_BY_GOOD_BAD_SSN = """
    SELECT
    A.win_nbr as associate_id,
    A.national_id as current_national_id,
    B.national_id as old_national_id,
    A.comp_freq_code as payroll_freq
    FROM
    `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` A,
    `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` B
    WHERE A.win_nbr = B.win_nbr
    AND A.national_id <> B.national_id
    AND B.national_id in ({national_id_list})
    AND A.STR_COUNTRY_CODE = 'US'
    AND B.STR_COUNTRY_CODE = 'US'
    AND A.EFFECTIVE_TS = ( select max(c.EFFECTIVE_TS)
    from `wmt-us-hr-prod.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` C
    where A.win_nbr = C.win_nbr)
    and B.EFFECTIVE_TS = ( select max(D.EFFECTIVE_TS)
    from `wmt-us-hr-prod.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` D
    where B.national_id = D.national_id
    AND D.EFFECTIVE_TS < A.EFFECTIVE_TS );
"""

RTRMT_PAYOUT_TERM_DATE = """
    SELECT 
    WIN_NBR as WIN_NBR,
    SUBSTR(CHAR((T1.PAYOUT_DATE - 30 DAYS)),6,2) as "R01-TERM-RETIRE-MM",
    SUBSTR(CHAR((T1.PAYOUT_DATE - 30 DAYS)),9,2) as "R01-TERM-RETIRE-DD",
    SUBSTR(CHAR((T1.PAYOUT_DATE - 30 DAYS)),1,4) as "R01-TERM-RETIRE-YY"
    FROM {DB2_SCHEMA}PROFIT.ASSOC_RTRMT_PAYOUT T1
    WHERE (T1.WIN_NBR IN ({ASSOCIATE_LIST}))                  
    AND (T1.MULTI_ACCT_CODE = 0)                         
    AND (T1.PAYOUT_DATE = (SELECT MAX(T2.PAYOUT_DATE)    
                  FROM {DB2_SCHEMA}PROFIT.ASSOC_RTRMT_PAYOUT T2            
                 WHERE (T1.WIN_NBR = T2.WIN_NBR)        
                   AND (T2.MULTI_ACCT_CODE = 0)))
    """

EXPERIENCE_YEARS_QUERY = """
    SELECT A.WIN_NBR as WIN_NBR,A.ADJUSTMT_NBR as ADJUSTMT_NBR,A.YEARS_ELIGIBLE_QTY as "R05-YEARS-OF-SERVICE"
    FROM {DB2_SCHEMA}PROFIT.RTRMT_ACCT_ADJMT A
    WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}))
    AND A.FISCAL_YEAR_NBR = {FISCAL_YEAR}
    ORDER BY A.WIN_NBR,A.ADJUSTMT_NBR
    """

ACTIVE_LOAN_LOA_ASSOCIATES_QUERY_GCP = """
    SELECT
    A.WIN_NBR as associateId,
    A.NATIONAL_ID,
    B.LOA_CODE,
    B.LOA_EFF_DATE,
    COALESCE(B.LOA_RETURN_DATE,'0001-01-01') as LOA_RETURN_DATE
    FROM
    `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` A
    INNER JOIN
    `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE_LOA` B
    USING (WIN_NBR)
    WHERE 
    B.LOA_EFF_DATE IS NOT NULL
    AND (B.LOA_RETURN_DATE > DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) OR B.LOA_RETURN_DATE IS NULL)
    AND B.LAST_CHG_TS = (SELECT max(B1.LAST_CHG_TS) FROM `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE_LOA` B1 WHERE B1.win_nbr = B.win_nbr)
    AND A.effective_ts = (SELECT max(A1.effective_ts) FROM `{gcp_project}.WW_HR_DL_US_CORE_SECURE.ASSOCIATE` A1 WHERE A.win_nbr = A1.win_nbr);
"""

ACTIVE_LOAN_LOA_ASSOCIATES_QUERY_DB2_FULL_UNLOAD="""
    SELECT 
    DISTINCT                                    
            W.WIN_NBR as associateId
           ,W.NATIONAL_ID                    
           ,W.LOA_CODE
           ,W.LOA_EFF_DATE    
           ,COALESCE(W.LOA_RETURN_DATE,'0001-01-01') as LOA_RETURN_DATE
    FROM
    {DB2_SCHEMA}GBLASC.WIN_ASSOCIATE W                
    WHERE
    W.LOA_EFF_DATE IS NOT NULL
    AND (W.LOA_RETURN_DATE > (CURRENT DATE - 7 DAYS) 
    OR W.LOA_RETURN_DATE IS NULL)
    WITH UR;
"""

GET_BI_WEEKLY_START_AND_PAY_DATES = """
    SELECT 
    A.PAYROLL_END_DATE,
    CASE
        WHEN A.PAY_CENTER_ID IN (1,2) THEN (A.BIWKLY_END_DATE - 13)
        WHEN A.PAY_CENTER_ID = 4 THEN (A.BIWKLY_END_DATE - 6)
    END as BI_WEEKLY_START_DATE,
    A.BIWKLY_END_DATE AS BI_WEEKLY_END_DATE,
    A.BIWKLY_CHECK_DATE AS PAY_DATE
    FROM `{gcp_project}.WW_HR_DL_US_PAYROLL_SECURE.HR_PAYROLL_CYCLE` A
    WHERE 
    A.PAY_CENTER_ID = {pay_center_id} 
    AND A.PAYROLL_RUN_DATE = (SELECT MAX(PAYROLL_RUN_DATE) 
    FROM `{gcp_project}.WW_HR_DL_US_PAYROLL_SECURE.HR_PAYROLL_CYCLE` A1 
    WHERE A1.PAY_CENTER_ID = {pay_center_id})
"""

PAYPERIOD_END_DATE_QUERY = """
    SELECT 
    CAST(MAX(A.PAYROLL_END_DATE) AS CHAR(10)) AS PAYROLL_END_DATE
    FROM {DB2_SCHEMA}GBLASC.HR_PAYROLL_CYCLE A
    """

PAYPERIOD_END_DATE_QUERY_GCP = """
SELECT MAX(PAYROLL_END_DATE) AS PAYROLL_END_DATE from `{gcp_project}.WW_HR_DL_US_PAYROLL_SECURE.HR_PAYROLL_CYCLE` A
"""

ASSOCIATE_HR_QUERY = """
        SELECT 
        A.WIN_NBR as WIN_NBR, A.NATIONAL_ID as NATIONAL_ID, A.LAST_NAME as LAST_NAME, A.FIRST_NAME as FIRST_NAME, 
        A.BIRTH_DATE as BIRTH_DATE, A.GENDER_CODE as GENDER_CODE, A.ACT_MARITAL_CODE as ACT_MARITAL_CODE, 
        A.HIRE_DATE as HIRE_DATE, A.COMP_FREQ_CODE as COMP_FREQ_CODE, A.HOME_ADDR_LINE_1 as HOME_ADDR_LINE_1, 
        A.HOME_ADDR_LINE_2 as HOME_ADDR_LINE_2, A.CITY_NAME as CITY_NAME, A.STATE_PROV_CODE as STATE_PROV_CODE, 
        A.POSTAL_CODE as POSTAL_CODE, A.STR_STATE_PROV_CD as STR_STATE_PROV_CD, A.STORE_NBR as STORE_NBR, 
        A.CHRG_STORE_NBR as CHRG_STORE_NBR, A.PAY_TYPE_CODE as PAY_TYPE_CODE, A.TERMINATION_DATE as TERMINATION_DATE,
        A.EMPLOY_STAT_CODE as EMPLOY_STAT_CODE, A.TERM_REASON_CODE as TERM_REASON_CODE
        FROM {DB2_SCHEMA}GBLASC.V3_WIN_ASC_NID_US A
        WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}))
        AND (A.STR_STATE_PROV_CD = '{REGION}' OR ('{REGION}' = 'US' AND A.STR_STATE_PROV_CD <> 'PR' {WV_FILTER}))
        WITH UR;
        """
MDSE_DIV_NBR_QUERY =  """
        SELECT 
        A.WIN_NBR as WIN_NBR, B.MDSE_DIV_NBR as MDSE_DIV_NBR
        FROM {DB2_SCHEMA}GBLASC.V3_WIN_ASC_NID_US A, {DB2_SCHEMA}GBLASC.ASC_STORE_JOB B
        WHERE (A.WIN_NBR IN ({ASSOCIATE_LIST}))
        AND (A.STR_STATE_PROV_CD = '{REGION}' OR ('{REGION}' = 'US' AND A.STR_STATE_PROV_CD <> 'PR' {WV_FILTER}))
        AND   (A.WIN_NBR = B.WIN_NBR)
        AND (A.STR_COUNTRY_CODE = B.STR_COUNTRY_CODE)
        AND (A.STORE_NBR = B.STORE_NBR)
        AND (A.HR_SOURCE_CODE = B.HR_SOURCE_CODE)
        AND ((A.EMPLOY_STAT_CODE NOT IN ('T','D') AND
              (B.OBSOLETE_DATE IS NULL OR B.OBSOLETE_DATE >=
               CURRENT DATE)) OR
              (A.EMPLOY_STAT_CODE  IN ('T','D') AND
                (B.OBSOLETE_DATE IN (SELECT
                 MAX (Z.OBSOLETE_DATE) FROM
                 {DB2_SCHEMA}GBLASC.ASC_STORE_JOB Z
                 WHERE Z.WIN_NBR = A.WIN_NBR
                 AND Z.EFFECTIVE_DATE <= CURRENT_DATE
                 AND A.STORE_NBR  = Z.STORE_NBR))
                )
               )
        AND B.JOB_TYPE_SEQ_NBR = 0
        AND B.EFFECTIVE_DATE IN
        (SELECT MAX (EFFECTIVE_DATE) FROM
        {DB2_SCHEMA}GBLASC.ASC_STORE_JOB C WHERE C.WIN_NBR = A.WIN_NBR
        AND C.EFFECTIVE_DATE <= CURRENT_DATE AND
        ((A.EMPLOY_STAT_CODE NOT IN ('T','D') AND
        (C.OBSOLETE_DATE IS NULL OR C.OBSOLETE_DATE >=
                              CURRENT DATE)) OR
        (A.EMPLOY_STAT_CODE  IN ('T','D') AND
        (C.OBSOLETE_DATE IN (SELECT
        MAX (Z.OBSOLETE_DATE)  FROM {DB2_SCHEMA}GBLASC.ASC_STORE_JOB Z
        WHERE Z.WIN_NBR = A.WIN_NBR AND
        Z.EFFECTIVE_DATE <= CURRENT_DATE
        AND A.STORE_NBR  = Z.STORE_NBR)))
       )
       AND A.STORE_NBR  = C.STORE_NBR
       AND C.JOB_TYPE_SEQ_NBR = 0
       AND C.HR_SOURCE_CODE = A.HR_SOURCE_CODE
      )
        WITH UR;
      """

PAYROLL_END_DATE_QUERY = """
    SELECT CAST(A.PAYROLL_END_DATE AS CHAR(10)) AS PAYROLL_END_DATE FROM {DB2_SCHEMA}GBLASC.HR_PAYROLL_CYCLE A
    WHERE A.PAY_CENTER_ID  = 1
    ORDER BY A.PAYROLL_RUN_DATE  DESC
    FETCH FIRST ROW ONLY
    """

IS_SAP_ACTIVE_ASSOC_QUERY = """
    SELECT A.WIN_NBR FROM                             
       {DB2_SCHEMA}PAYRL0.US_SAP_ACTIVE_ASSOC A                               
       WHERE A.POPULATION_IND = 'SAP'                       
       AND A.EFFECTIVE_DT <= (
          SELECT PAYROLL_END_DATE 
          FROM {DB2_SCHEMA}GBLASC.HR_PAYROLL_CYCLE B
          WHERE B.PAY_CENTER_ID = 1
          ORDER BY B.PAYROLL_RUN_DATE DESC
          FETCH FIRST ROW ONLY
      )
    WITH UR;   
    """
