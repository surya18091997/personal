import os
import json
import logging
from cachetools import TTLCache
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

cache = TTLCache(maxsize=100, ttl=86400)

path = '/etc/config'
app_config_path = os.path.join(path, 'application.json')
file_module_config_map_path = os.path.join(path, 'flow_config_map.json')
file_layout_path = os.path.join(path, 'file_layouts.json')

"""
Load all configuration files into the cache.

Returns:
    None
"""
def load_all_config_to_cache():
    load_config_to_cache('app',app_config_path)
    load_config_to_cache('flow_config',file_module_config_map_path)
    load_config_to_cache('file_layout',file_layout_path)

"""
Load a configuration file into the cache.

Args:
    config_name (str): The name of the configuration.
    config_file (str): The path to the configuration file.

Returns:
    None

Raises:
    FileNotFoundError: If the configuration file is not found.
    json.JSONDecodeError: If the configuration file contains invalid JSON.
    Exception: If an error occurs while loading the configuration.

"""
def load_config_to_cache(config_name,config_file):
    try:
        with open(config_file, 'r') as f:
            config_file_content = f.read()

            # CCM formats a json value into a string for a specified configuration key, which is not being parsed.
            # A tilde special character was therefore introduced to create a pattern and is subsequently removed
            # before parsing to prevent any parsing errors. A regex is used to identify and remove all instances of '~...~'.
            # Also, for a JSON string all the double quotes are escaped and when delivered to pod, this is not case in work offline mode.
            config_file_content = config_file_content.replace('\\"', '"').replace('"~', '').replace('~"', '')
            data = json.loads(config_file_content)

        for key, value in data["configResolution"]["resolved"].items():
            try:
                cache[config_name + key] = value
                print(f"Configuration {key}: {value}")

            except json.JSONDecodeError:
                value = value.replace('\n', '').strip()
                cache[config_name + key] = value
                print(f"JSON parsing failed for key: {key}, try parsing as string")

        # cache.update(config_resolution)

    except FileNotFoundError as e:
        logging.error(f"Configuration file not found: {config_file} and exception {e}")

    except json.JSONDecodeError as e:
        logging.error(f"Invalid JSON in configuration file: {config_file} and exception {e}")

    except Exception as e:
        logging.error(f"Error loading configuration: {e}")


"""
Retrieves a value from the configuration dictionary using a colon-separated key.

Args:
    config_name (str): The name of the configuration.
    key (str): The colon-separated key.

Returns:
    Any: The retrieved value.

Raises:
    KeyError: If the key is not found in the configuration dictionary.
"""
def get_config_value(config_name,key):
    value = cache.get(config_name + key, None)
    if cache.get(config_name+key, None) is None:
        load_all_config_to_cache()
        value = cache.get(config_name+key, None)

    logging.info(f"Configuration retrieved for {key}: {value}")
    return value

class FileModifiedHandler(FileSystemEventHandler):
    def on_modified(self, event):
        cache.clear()
        load_all_config_to_cache()

def start_watcher():
    if os.path.isdir(path):
        event_handler = FileModifiedHandler()
        load_all_config_to_cache()
        observer = Observer()
        observer.schedule(event_handler, path=path, recursive=False)
        observer.start()
        
