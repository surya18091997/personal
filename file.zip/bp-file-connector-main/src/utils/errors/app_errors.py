from src.utils.errors.custom_error import CustomError

class CreateJsonResponseError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("APP0001", "Failed to create JSON response", "error", additional_details)

class ApplicationError(CustomError):
    def __init__(self, method_name, additional_details=None):
        super().__init__("APP0002", "App failed to process..."+method_name, "error", additional_details)

class ApplicationErrorMessage(CustomError):
    def __init__(self, error_message, additional_details=None):
        super().__init__("APP0003", error_message, "error", additional_details)

class ConsentFetchError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("APP0004", "Error in consent fetch process", "error", additional_details)

class ConsentProcessError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("APP0005", "Error in consent processing", "error", additional_details)

class PlanAttributeError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("APP0006", "Error in plan attribute process", "error", additional_details)