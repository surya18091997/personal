class CustomError(Exception):
    def __init__(self, error_code, error_message, severity_level, additional_details=None):
        self.error_code = error_code
        self.error_message = error_message
        self.severity_level = severity_level
        self.additional_details = additional_details

    def __str__(self):
        return f"{self.error_code} - {self.error_message} ({self.severity_level})\nAdditional Details: {self.additional_details}"
