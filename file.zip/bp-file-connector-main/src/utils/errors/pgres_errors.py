from src.utils.errors.custom_error import CustomError

class PostgresQueryExecutionError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0001", "PGRES Query Execution error occurred", "critical", additional_details)


class PostgresNonQueryExecutionError(Exception):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0002", "PGRES Non Query Execution error occurred", "error", additional_details)


class PostgresBulkInsertError(Exception):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0003", "PGRES Bulk Insert error occurred", "error", additional_details)

class PostgresConnectionError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0004", "PGRES Connection error occurred", "error", additional_details)

class PostgresTimeoutError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0005", "PGRES Timeout error occurred", "error", additional_details)

class PostgresInvalidQueryError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0006", "PGRES Invalid Query error occurred", "error", additional_details)

class PostgresInvalidParameterError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0007", "PGRES Invalid Parameter error occurred", "error", additional_details)

class PostgresInvalidDataError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0008", "PGRES Invalid Data error occurred", "error", additional_details)

class PostgresInvalidSchemaError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("PGRES0009", "PGRES Invalid Schema error occurred", "error", additional_details)

