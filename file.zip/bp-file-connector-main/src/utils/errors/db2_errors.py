from src.utils.errors.custom_error import CustomError


class DatabaseError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("DB0001", "Database error occurred", "critical", additional_details)


class FetchDBError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("DB0002", "Database Fetch error occurred", "error", additional_details)


class UpdateDBError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("DB0003", "Database Update error occurred", "error", additional_details)


class InsertDBError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("DB0004", "Database Insert error occurred", "error", additional_details)


class DeleteDBError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("DB0005", "Database Delete error occurred", "error", additional_details)


class TechnicalError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("TE0001", "Technical error occurred", "error", additional_details)


class BusinessError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("BE0001", "Business error occurred", "error", additional_details)