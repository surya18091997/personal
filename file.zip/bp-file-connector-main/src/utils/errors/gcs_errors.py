from src.utils.errors.custom_error import CustomError


class GCSError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0001", "GCS error occurred", "critical", additional_details)


class GCSCreateFolderError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0002", "GCS Create Folder error occurred", "error", additional_details)


class GCSCreateFileError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0003", "GCS Create File error occurred", "error", additional_details)


class GCSUploadFileError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0004", "GCS Upload File error occurred", "error", additional_details)


class GCSUploadFolderError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0005", "GCS Upload Folder error occurred", "error", additional_details)


class GCSDownloadFileError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0006", "GCS Download File error occurred", "error", additional_details)

class GCSResumableUploadError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0007", "GCS Resumable Upload error occurred", "error", additional_details)


class GCSUploadChunkError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0008", "GCS Upload Chunk error occurred", "error", additional_details)

class GCSHudiConnectionError(CustomError):
    def __init__(self, additional_details=None):
        super().__init__("GCS0101", "GCS Hudi connection setup error", "error", additional_details)

