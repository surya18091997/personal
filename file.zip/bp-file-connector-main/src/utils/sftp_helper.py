import json
import os

import paramiko.common

from src.utils import app_config
import paramiko
from paramiko.sftp_attr import SFTPAttributes
from paramiko.sftp_client import SFTPClient

from src.constants import SERVER, PORT, DEFAULT_PORT, USER_ID, AUTHENTICATION_TYPE, CERTIFICATE, \
    CERTIFICATE_PATH, PUB_KEYS, RSA_SHA_256, RSA_SHA_512, SECRET, SFTP_MAINFRAME_FILE_PATH, SFTP_MAINFRAME_UPLOAD_FILE_PATH, \
    SFTP_FILE_TRANSFER_STATUS, SFTP_FILE_TRANSFER_SUCCESS, SFTP_FILE_TRANSFER_FAILURE, SFTP_CLIENT_CREATED_WITH_CERT, \
    SFTP_CLIENT_CREATED_WITH_SECRET, SFTP_CLIENT_NOT_SUPPORTED, SFTP_CLIENT_CREATE_ERROR, SFTP_PASSWORD
from src.utils.errors.app_errors import ApplicationError


class SftpHelper:
    """
    Initializes a new instance of the `SftpHelper` class.

    Args:
        logger (logging.Logger): The logger instance.

    Raises:
        ApplicationError: If there is an error connecting to the SFTP server.

    Returns:
        None
    """
    def __init__(self,logger):
        try:
            self.sftp_config = None
            self.logger = logger
            self.get_sftp_config(key="sftp_config")
            # This is to resolve the sonar issue of CLIENT not getting assigned with inconsistent type
            self.sftp_client = None
            self.get_client()
        except Exception as e:
            raise ApplicationError(f"Error connecting to SFTP server: {e}")

    """
    Retrieves the SFTP configuration from the application.

    Args:
        key (str): The key to retrieve the configuration from.

    Returns:
        None
    """
    def get_sftp_config(self,key):
        sftp_config_path = app_config.get_config_value("app", key)
        with open(sftp_config_path, 'r') as file:
            self.sftp_config = json.load(file)

    """
    Retrieves an SFTP client based on the authentication type.

    Returns:
        None

    Raises:
        ApplicationError: If there is an error connecting to the SFTP server.

    """
    def get_client(self):
        try:
            host_name: str = str(self.sftp_config.get(SERVER)).strip()
            port: int = int(self.sftp_config.get(PORT, DEFAULT_PORT))
            user_id: str = str(self.sftp_config.get(USER_ID)).strip()

            authentication_type: str = self.sftp_config.get(AUTHENTICATION_TYPE)

            if authentication_type == CERTIFICATE:
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                private_key_path: str = self.sftp_config.get(CERTIFICATE_PATH)
                p_key: paramiko.pkey.PKey = paramiko.RSAKey.from_private_key_file(private_key_path)
                ssh_client.connect(hostname=host_name,
                                   username=user_id,
                                   pkey=p_key,
                                   disabled_algorithms={PUB_KEYS: [RSA_SHA_256, RSA_SHA_512]},
                                   banner_timeout=200)
                self.sftp_client: SFTPClient = ssh_client.open_sftp()
                self.logger.info(SFTP_CLIENT_CREATED_WITH_CERT)

            elif authentication_type == SFTP_PASSWORD:
                secret: str = self.sftp_config.get(SECRET)
                transport = paramiko.Transport((host_name, port))
                transport.connect(username=user_id, password=secret)
                self.sftp_client: SFTPClient = paramiko.SFTPClient.from_transport(transport)
                self.logger.info(SFTP_CLIENT_CREATED_WITH_SECRET)
            else:
                self.logger.error(SFTP_CLIENT_NOT_SUPPORTED)
                raise RuntimeError(SFTP_CLIENT_NOT_SUPPORTED)
        except Exception as e:
            self.logger.error(SFTP_CLIENT_CREATE_ERROR.format(error_message=e))
            raise ApplicationError(SFTP_CLIENT_CREATE_ERROR.format(error_message=e))

    """
    Downloads files from the SFTP server.

    Args:
        source_file_path (List[str]): A list of file paths to download.
        request_id_dir (str): The directory to save the downloaded files.
        dest_file (str): The name of the downloaded file.

    Returns:
        None

    Raises:
        Exception: If there is an error downloading the file.
    """
    def download_files(self,source_file_path, request_id_dir,dest_file):
        def sftp_callback(bytes_transferred: int, curr_file_path):
            kb = bytes_transferred / 1024
            mb = kb / 1024
            self.logger.info(SFTP_FILE_TRANSFER_STATUS.format(file_path=curr_file_path, bytes_transferred=bytes_transferred, kb=kb, mb=mb))

        for file in source_file_path:
            file_path: str = SFTP_MAINFRAME_FILE_PATH.format(file_name=file)
            try:
                file_info: SFTPAttributes = self.sftp_client.stat(file_path)
                local_file = os.path.join(request_id_dir, dest_file)
                if file_info:
                    self.sftp_client.get(file_path, callback=lambda bt, fp=file_path:sftp_callback(bt, fp),localpath=local_file, prefetch=False)
                    self.logger.info(SFTP_FILE_TRANSFER_SUCCESS.format(file_name=file, file_path=file_path))
            except Exception as ex:
                self.logger.error(SFTP_FILE_TRANSFER_FAILURE.format(file_path=source_file_path, error_message=ex))

    """
        Formats each line of the input file to be exactly LRECL characters long.
        Pads with spaces or truncates as needed. Returns the path of the temp formatted file.
    """
    def format_file_to_fixed_length(self, input_path: str, lrecl: int) -> str:
        formatted_file_path = input_path + ".formatted"

        with open(input_path, 'r') as infile, open(formatted_file_path, 'wb') as outfile:
            for line in infile:
                stripped = line.rstrip('\n\r')
                fixed_line = stripped.ljust(lrecl)[:lrecl]
                outfile.write((fixed_line + '\r\n').encode('ascii'))

        return formatted_file_path

    """
        Uploads a file to the mainframe via SFTP.

        Args:
            dest_file_path_mf (str): The destination file path on the mainframe.
            request_id_dir (str): The local directory containing the file to upload.
            dest_file (str): The name of the file to upload.
        Raises:
            Exception: If any error occurs during the upload process, it is logged and re-raised.
    """
    def upload_file_to_mainframe(self,dest_file_path_mf, request_id_dir, dest_file):
        try:
            local_file_path = os.path.join(request_id_dir, dest_file)
            lrecl = 250
            formatted_path = self.format_file_to_fixed_length(local_file_path, lrecl)

            mainframe_file_path: str = SFTP_MAINFRAME_UPLOAD_FILE_PATH.format(file_name=dest_file_path_mf)

            try:
                self.logger.info(f"Checking if file exists on mainframe: {mainframe_file_path}")
                self.sftp_client.stat(mainframe_file_path)
                self.logger.info(f"File already exists on mainframe. Deleting: {mainframe_file_path}")
                self.sftp_client.remove(mainframe_file_path)  # Delete the existing file
            except FileNotFoundError:
                self.logger.info(f"File does not exist on mainframe. Proceeding with upload.")

            self.logger.info(f"Uploading file to mainframe...")
            with open(formatted_path, 'rb') as f:
                with self.sftp_client.file(mainframe_file_path, 'wb') as remote_file:
                    while chunk := f.read(1024):
                        remote_file.write(chunk)
            self.logger.info(f"File uploaded successfully to mainframe path: {mainframe_file_path}")
    
        except Exception as e:
            self.logger.error(f"Error uploading file to mainframe: {str(e)}")