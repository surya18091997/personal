import connexion
import os
import logging
from flask_cors import CORS

from src.report_generator.orchestrator import Orchestrator
from src.telemetry import instrument_requests
from src.utils import app_config
from uvicorn import Config, Server

def main():
    try:
        app = connexion.App(__name__, specification_dir='../')
        CORS(app.app, resources={r"/*": {"origins": "*", "send_wildcard": "True"}})  # Enable CORS for all routes
        app.add_api('api-spec.yaml', arguments={'title': 'Benefits Platform File Connector'}, pythonic_params=True)
        app_config.start_watcher()
        instrument_requests.add_interceptor(app)

        if 'ENV' in os.environ:
            logging.info(" * Environment: %s", os.environ['ENV'])
        else:
            logging.info(" * Environment: local")

        config = Config(app, host='0.0.0.0', port=8080)
        server = Server(config)
        server.run()

    except Exception as e:
        logging.error(f"Error starting the application: {str(e)}", exc_info=True)
        raise e


if __name__ == '__main__':
    main()
    print("over")