import datetime
import pandas as pd
import os
from src.constants import (F_COMPLETED, F_ERROR, FG_EMPTY_FILE_INFO, DATA_STORAGE_TYPE, DATA_STORAGE_INMEMORY,
                           DATA_STORAGE_AZURE_FILE, DATA_STORAGE_GCS_FILE, FILE_FORMAT_CSV, FILE_FORMAT_JSON,
                           FILE_FORMAT_PARQUET, DATA_FILE_PATH, DATA_FILE_NAME, DATA_FILE_FORMAT, GCS_BUCKET_NAME)
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError
from src.utils.sql import (STATE_TRANSFER_TO_US, STATE_TRANSFER_TO_PR)


class BenefitsHudiDataExtract(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, data):
        super().__init__(configuration_id=configuration_id, logger_instance=logger, request_id=request_id,
                         start_date="", end_date="", data=data)

    """"
        1. Working directory checkups
        2. Fetch the data based on the query
        3. transfer the file to Azure or GCS if requested 
    """""

    def start_process(self):
        try:
            # Step1  : working_dir setup
            self.create_working_directory(self.request_id)

            # Step2  : fetch the data from benefits hudi
            benefits_hudi_df, target_storage = self.get_benefits_hudi_data()

            storage_type = target_storage.get(DATA_STORAGE_TYPE, DATA_STORAGE_INMEMORY)

            # Step3  : transfer the file to Azure or GCS if requested
            if storage_type.lower() == DATA_STORAGE_AZURE_FILE:
                self.destination_file_path = target_storage.get(DATA_FILE_PATH, self.request_id_dir)
                self.dest_file = target_storage.get(DATA_FILE_NAME)
                file_format = target_storage.get(DATA_FILE_FORMAT, FILE_FORMAT_CSV)

                full_path = os.path.join(self.request_id_dir, self.dest_file)
                # Save to file based on format
                if file_format.lower() == FILE_FORMAT_CSV:
                    benefits_hudi_df.to_csv(full_path, index=False)
                elif file_format.lower() == FILE_FORMAT_PARQUET:
                    benefits_hudi_df.to_parquet(full_path, index=False)
                elif file_format.lower() == FILE_FORMAT_JSON:
                    benefits_hudi_df.to_json(full_path, orient="records", lines=True)
                else:
                    self.logger.warning(f"Unsupported file format: {file_format}, defaulting to CSV")
                    benefits_hudi_df.to_csv(full_path, index=False)

                self.transfer_file_to_azure_directory()

                self.logger.info(f"Data saved to {self.destination_file_path}")
                return f"{self.destination_file_path}/{self.dest_file}"

            if storage_type.lower() == DATA_STORAGE_GCS_FILE:
                self.bucket_name = target_storage.get(GCS_BUCKET_NAME, self.request_id_dir)
                self.destination_file_path = target_storage.get(DATA_FILE_PATH, self.request_id_dir)
                self.dest_file = target_storage.get(DATA_FILE_NAME)
                file_format = target_storage.get(DATA_FILE_FORMAT, FILE_FORMAT_CSV)

                full_path = os.path.join(self.request_id_dir, self.dest_file)
                # Save to file based on format
                if file_format.lower() == FILE_FORMAT_CSV:
                    benefits_hudi_df.to_csv(full_path, index=False)
                elif file_format.lower() == FILE_FORMAT_PARQUET:
                    benefits_hudi_df.to_parquet(full_path, index=False)
                elif file_format.lower() == FILE_FORMAT_JSON:
                    benefits_hudi_df.to_json(full_path, orient="records", lines=True)
                else:
                    self.logger.warning(f"Unsupported file format: {file_format}, defaulting to CSV")
                    benefits_hudi_df.to_csv(full_path, index=False)

                self.transfer_file_to_gcs()

                self.logger.info(f"Data saved to {self.destination_file_path} in {self.bucket_name} GCS bucket")
                return f"gs://{self.bucket_name}/{self.destination_file_path}/{self.dest_file}"

            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(f"Failed during file generation: {str(e)}", exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise


