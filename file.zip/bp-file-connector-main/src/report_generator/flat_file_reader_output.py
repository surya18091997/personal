from dataclasses import dataclass

@dataclass
class FlatFileReaderOutput:
    generated: str
    status: str
    code: int

    def __str__(self):
        return 'generated path: {}, status: {}, code: {}'.format(self.generated, self.status, self.code)


