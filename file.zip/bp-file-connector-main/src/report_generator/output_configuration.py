from dataclasses import dataclass

from src.report_generator.templates.data_objects.data_object import DataObject


@dataclass
class TransformerConfig:
    output_file_name: str
    page_size: int
    report_id: str
    data_objects: list[DataObject] = None

