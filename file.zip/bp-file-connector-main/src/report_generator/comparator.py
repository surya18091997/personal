import os

import pandas as pd
import re

# Common header and footer patterns for all reports
HEADER_FOOTER_PATTERNS = [
    r".*RUN ON",  # Matches lines starting with 'RUN ON'
    r"^\s*HCE",     # Matches lines starting with 'HCE'
    r"^\s*TOTAL ASSOCS",  # Matches lines starting with 'TOTAL ASSOCS'
    r".*PAGE-NO.",  # Matches lines containing 'PAGE-NO.'
    r"^\s*\*\* END-OF-JOB \*\*"  # Matches lines indicating end of the job
]

# Combined column definitions for different reports
REPORT_DEFINITIONS = {
    "401K ELIGIBILITY FILE(BIWEEKLY) PR": {
        "column_widths": [
            3, 10, 10, 20, 25, 25, 20, 2, 5, 10, 10, 10, 10, 10, 10, 5, 3
        ],
        "column_names": [
            "HCE", "SSN", "WIN", "FIRST_NAME", "LAST_NAME", "ADDRESS", "CITY", "ST", "ZIP",
            "WRK_STR_NBR", "HIRE_DATE", "BIRTH_DATE", "EFF_DATE", "TERM_DATE", "PAYOUT_DT", "ELIG_HRS", "YOS"
        ]
    },
    "401K TERMINATION FILE(WEEKLY) PR": {
        "column_widths": [
            3, 10, 10, 20, 25, 25, 20, 2, 5, 10, 10, 10, 10, 10, 10, 5, 3
        ],
        "column_names": [
            "HCE", "SSN", "WIN", "FIRST_NAME", "LAST_NAME", "ADDRESS", "CITY", "ST", "ZIP",
            "WRK_STR_NBR", "HIRE_DATE", "BIRTH_DATE", "EFF_DATE", "TERM_DATE", "PAYOUT_DT", "ELIG_HRS", "YOS"
        ]
    },
    "401K LOAN FILE(BIWEEKLY) PR": {
        "column_widths": [],  # No detailed data rows in this report
        "column_names": []
    },
    "401K RE HIRE FILE(WEEKLY) PR": {
        "column_widths": [
            3, 10, 10, 20, 25, 25, 20, 2, 5, 10, 10, 10, 10, 10, 10, 5, 3
        ],
        "column_names": [
            "HCE", "SSN", "WIN", "FIRST_NAME", "LAST_NAME", "ADDRESS", "CITY", "ST", "ZIP",
            "WRK_STR_NBR", "REHI/ORG DT", "BIRTH_DATE", "EFF_DATE", "TERM_DATE", "PAYOUT_DT", "ELIG_HRS", "YOS"
        ]
    },
    "401K STATE TRANSFER FILE(WEEKLY)": {
        "column_widths": [
            3, 10, 10, 20, 25, 25, 20, 2, 5, 5, 10, 10, 10, 10, 10, 10, 5, 3
        ],
        "column_names": [
            "HCE", "SSN", "WIN", "FIRST_NAME", "LAST_NAME", "ADDRESS", "CITY", "ST", "ZIP",
            "WRK_DIV", "WRK_STR_NBR", "HIRE_DATE", "BIRTH_DATE", "EFF_DATE", "TERM_DATE", "PAYOUT_DT", "HOURS", "YOS"
        ]
    }
}

def compare_files(lhs_file_path: str, rhs_file_path: str, column_widths: list[int], column_names: list[str], unique_keys: list[str],report_type:str):
    """
    Compares two fixed-width EBCDIC format files using specified unique keys.

    Args:
        lhs_file_path (str): Path to the left-hand side file.
        rhs_file_path (str): Path to the right-hand side file.
        column_widths (list[int]): List of column widths for the fixed-width file.
        column_names (list[str]): List of column names corresponding to the column widths.
        unique_keys (list[str]): List of column names to use as unique keys for comparison.

    Returns:
        dict: A dictionary containing differences categorized as 'added', 'removed', and 'modified'.
    """
    def extract_valid_rows(file_path):
        """Extracts valid data rows by skipping headers and footers based on patterns."""
        with open(file_path, 'r') as file:
            lines = file.readlines()

        # Filter out header and footer lines using regex patterns
        data_lines = [
            line for line in lines
            if not any(re.match(pattern, line) for pattern in HEADER_FOOTER_PATTERNS)
        ]
        # Remove any lines that are empty or contain only whitespace
        data_lines = [line for line in data_lines if line.strip()]
        data_lines = [
            line for line in data_lines if not any(column in line for column in column_names)
        ]

        # Write filtered lines to a temporary file for parsing
        temp_file_path = "temp_filtered_file.txt"
        with open(temp_file_path, 'w') as temp_file:
            temp_file.writelines(data_lines)

        return pd.read_fwf(temp_file_path, widths=column_widths, names=column_names, dtype=str)

    # Load the files into DataFrames
    lhs_df = extract_valid_rows(lhs_file_path)
    rhs_df = extract_valid_rows(rhs_file_path)

    # Ensure unique key columns exist
    if not set(unique_keys).issubset(lhs_df.columns) or not set(unique_keys).issubset(rhs_df.columns):
        raise ValueError(f"Both files must contain the unique key columns: {unique_keys}.")

    # Set unique keys as the index for comparison
    lhs_df.set_index(unique_keys, inplace=True)
    rhs_df.set_index(unique_keys, inplace=True)

    # Normalize data to avoid false positives in comparisons
    lhs_df = lhs_df.map(lambda x: x.strip() if isinstance(x, str) else x).astype(str)
    rhs_df = rhs_df.map(lambda x: x.strip() if isinstance(x, str) else x).astype(str)

    # Initialize result containers
    added = []
    removed = []
    modified = []

    # Convert DataFrames to dictionaries for simple looping
    lhs_dict = lhs_df.to_dict(orient='index')
    rhs_dict = rhs_df.to_dict(orient='index')

    # Loop through RHS to find added and modified rows
    for key, rhs_row in rhs_dict.items():
        if key not in lhs_dict:
            added.append({**{k: key[i] for i, k in enumerate(unique_keys)}, **rhs_row})
        elif lhs_dict[key] != rhs_row:
            # Identify which columns are modified
            modified_columns = {
                col: {'lhs': lhs_dict[key][col], 'rhs': rhs_row[col]}
                for col in rhs_row if lhs_dict[key][col] != rhs_row[col]
            }
            modified.append({
                **{k: key[i] for i, k in enumerate(unique_keys)},
                'modified_columns': modified_columns
            })

    # Loop through LHS to find removed rows
    for key, lhs_row in lhs_dict.items():
        if key not in rhs_dict:
            removed.append({**{k: key[i] for i, k in enumerate(unique_keys)}, **lhs_row})

    total_rows = len(rhs_df) + len(removed) + len(added)
    total_cells = total_rows * len(column_names)
    non_matching_cells = (len(added) + len(removed)) * len(column_names) + sum(len(mod['modified_columns']) for mod in modified)
    match_percent = 100 - ((non_matching_cells * 100) / total_cells)
    return {
        'report_name':report_type,
        'total_rows': total_rows,
        'total_cells': total_cells,
        'match_percent': match_percent,
        'non_matching_cells': non_matching_cells,
        'removed': len(removed),
        'added': len(added),
        'added_records': added,
        'removed_records': removed,
        'modified': modified,
    }

def __main__():

    for comparable in comparables:
        lhs_file = comparable["lhs_file"]
        rhs_file = comparable["rhs_file"]
        report_type = comparable["report_type"]
        unique_keys = comparable["unique_keys"]
        if report_type not in REPORT_DEFINITIONS:
            raise ValueError(f"Report type '{report_type}' is not supported.")

        column_widths = REPORT_DEFINITIONS[report_type]["column_widths"]
        column_names = REPORT_DEFINITIONS[report_type]["column_names"]

        differences = compare_files(f"{os.getcwd()}/{lhs_file}", f"{os.getcwd()}/{rhs_file}", column_widths, column_names, unique_keys,report_type)
        print(differences)

comparables = [
    {
     "lhs_file": "src/report_generator/output_temp/for_comparison/US_STATE_TRANSFER_RPT",
     "rhs_file": "src/report_generator/output_temp/for_comparison/401K STATE TRANSFER FILE(WEEKLY) US.report",
     "report_type": "401K STATE TRANSFER FILE(WEEKLY)",
     "unique_keys": ["SSN", "WIN"]
     }
]


if __name__ == "__main__":
    __main__()


