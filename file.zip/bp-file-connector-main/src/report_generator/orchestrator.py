import datetime
import os
import shutil

from src.integrations.gcs_utils import GCSUtils
from src.report_generator import input_configuration
from src.report_generator.flat_file_writer import FlatFileWriter
from src.report_generator.flatfile_csv_generator import FlatFileToCSVGenerator
from src.report_generator.input_configuration import FlatFileReadConfiguration, FileType
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.report_utils import file_path_layout, file_path_flat
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.activity_report_transformer import ActivityReportTransformer
from src.report_generator.transformers.eligibility_transformer import EligibilityFileTransformer
from src.report_generator.transformers.hardship_outbound_transformer import HardshipInboundTransformer
from src.report_generator.transformers.loa_file_transformer import LoaFileTransformer
from src.report_generator.transformers.loan_file_transformer import LoanFileTransformer
from src.report_generator.transformers.loan_inbound_transformer import LoaninFileTransformer
from src.report_generator.transformers.rate_change_activity_transformer import RateChangeActivityTransformer
from src.report_generator.transformers.rate_change_compare_transformer import RateChangeCompareTransformer
from src.report_generator.transformers.rate_change_exception_transformer import RateChangeExceptionTransformer
from src.report_generator.transformers.rate_change_hardship_compare_transformer import \
    RateChangeHardshipCompareTransformer
from src.report_generator.transformers.rate_change_outbound_summary_transformer import \
    RateChangeOutboundSummaryTransformer
from src.report_generator.transformers.rehire_transformer import ReHireTransformer
from src.report_generator.transformers.report_types import ReportType
from src.report_generator.transformers.state_transfer_doe_change_transformer import StateTransferDoeChangeTransformer
from src.report_generator.transformers.state_transfer_transformer import StateTransferTransformer
from src.report_generator.transformers.term_over_65_transformer import TermOver65Transformer
from src.report_generator.transformers.termination_transformer import TerminationTransformer
from src.utils import app_config
from src.utils.logging_helper import setup_request_logger


class Orchestrator:
    def __init__(self):
        gcs_bucket_name = app_config.get_config_value("app","reporting_gcs_bucket")
        self.logger = setup_request_logger("Report Orchestrator")
        self.gcs_utils = GCSUtils(self.logger)
        self.bucket_name = gcs_bucket_name

    def start(self, identifiers=None):
        #validate output dir
        directory = f"{os.getcwd()}/src/report_generator/output_temp"
        flat_files = f"{os.getcwd()}/src/report_generator/flat_files"
        reports = f"{os.getcwd()}/src/report_generator/output_temp/reports"
        if not os.path.exists(directory):
            os.makedirs(directory)
        if not os.path.exists(reports):
            os.makedirs(reports)
        if not os.path.exists(flat_files):
            os.makedirs(flat_files)
        # Orchestrate the report generation process
        flat_file_configs = self.__get_flat_file_configs()
        for flat_file_config in flat_file_configs:
            if flat_file_config.type == input_configuration.FileType.GCS:
                try:
                    self.logger.info(f"Downloading flat file from GCS: {flat_file_config.remote_file}")
                    self.gcs_utils.download_file(flat_file_config.bucket, flat_file_config.remote_file, flat_file_config.file)
                except Exception as e:
                    self.logger.error(f"Error downloading GCS file {flat_file_config.remote_file}: {str(e)}")
                    continue
            elif flat_file_config.type == input_configuration.FileType.AZURE:
                self.logger.info(f"Processing Azure file: {flat_file_config.remote_file}")
                try:
                    if flat_file_config.remote_file and os.path.exists(flat_file_config.remote_file):
                        os.makedirs(os.path.dirname(flat_file_config.file), exist_ok=True)
                        shutil.copy2(flat_file_config.remote_file, flat_file_config.file)
                        self.logger.info(f"Copied Azure file to: {flat_file_config.file}")
                    else:
                        self.logger.warning(f"Azure file not found or path is None: {flat_file_config.remote_file}")
                except Exception as e:
                    self.logger.error(f"Error copying Azure file: {str(e)}")

            try:
                reader = FlatFileToCSVGenerator()
                lines = []
                with open(flat_file_config.file, 'r') as file:
                    for line in file:
                        lines.append(Orchestrator.pad_to_bytes(line, bytes_needed=flat_file_config.fixed_size))
                flat_file_config.file = flat_file_config.file + ".binary"
                with open(flat_file_config.file, 'wb') as file:
                    file.writelines(lines)

                reader.generate(flat_file_config)
            except Exception as e:
                self.logger.error(f"Error processing flat file {flat_file_config.file}: {str(e)}")
                continue

        transformers = Orchestrator.__get_transformer_configs(self.logger)

        # Filter transformers based on identifiers if provided
        if identifiers and len(identifiers) > 0:
            self.logger.info(f"Filtering transformers by identifiers: {identifiers}")
            filtered_transformers = []
            for transformer in transformers:
                try:
                    if transformer.identifier() in identifiers:
                        self.logger.info(f"Including transformer: {transformer.__class__.__name__} with identifier: {transformer.identifier()}")
                        filtered_transformers.append(transformer)
                except Exception as e:
                    self.logger.error(f"Error checking transformer identifier: {str(e)}")
            transformers = filtered_transformers
            if not transformers:
                self.logger.error(f"No matching transformers found for identifiers: {identifiers}")
                transformers = []
        errors = []
        for transformer in transformers:
            try:
                writer = FlatFileWriter()
                data_objects = transformer.transform()
                transformer.output_configuration.data_objects = data_objects
                writer.write(transformer.output_configuration)
                source_file_path = f"{os.getcwd()}/src/report_generator/output_temp/reports/{transformer.output_configuration.output_file_name}"
                current_date = datetime.datetime.now().strftime("%y-%m-%d")
                self.gcs_utils.upload_file(self.bucket_name, f"reports/{transformer.output_configuration.report_id}/{current_date}/{transformer.output_configuration.output_file_name}", source_file_path)
            except Exception as e:
                self.logger.error(f"Error in transformer {transformer.__class__.__name__}: {str(e)}")
                errors.append(f"Error in transformer {transformer.__class__.__name__}: {str(e)}")
        self.logger.error(errors)
        self.logger.info("Report process completed. Please check above logs for any errors")

    def __get_flat_file_configs(self) -> list[FlatFileReadConfiguration]:
        return [
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/us/US_LOAN_File',
                layout=f"{file_path_layout('INBOUND_LOAN_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('INBOUND_LOAN_FILE_US.txt')}", fixed_size=150,
                ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/us/US_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_LOAN_FILE_US.txt')}",
                fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/us/US_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_LOAN_FILE_US.txt')}",
                fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/pr/PR_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_LOAN_FILE_PR.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/pr/PR_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_LAYOUT.json')}",
                  file=f"{file_path_flat('OUTBOUND_LOAN_FILE_PR.txt')}", fixed_size=250),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/wv/WV_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_LOAN_FILE_WV.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loan/wv/WV_LOAN_File',
                layout=f"{file_path_layout('OUTBOUND_LOAN_FILE_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_LOAN_FILE_WV.txt')}", fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loa/us/LOA_FILE',
                layout=f"{file_path_layout('OUTBOUND_LOA_FILE_UHDR_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_LOA_FILE_US.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loa/us/LOA_FILE',
                layout=f"{file_path_layout('OUTBOUND_LOA_FILE_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_LOA_FILE_US.txt')}", fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loa/us/LOA_FILE',
                layout=f"{file_path_layout('OUTBOUND_LOA_FILE_UHDR_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_LOA_FILE_PR.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/loa/us/LOA_FILE',
                layout=f"{file_path_layout('OUTBOUND_LOA_FILE_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_LOA_FILE_PR.txt')}", fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file=self.get_absolute_first_path_from_prefix("/mnt/azure/incoming/hardship/archive",
                                                                     "HARDSHIP_US_INBOUND.txt_" + datetime.datetime.now().strftime(
                                                                         "%Y%m%d")),
                layout=f"{file_path_layout('INBOUND_HARDSHIP_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('INBOUND_HARDSHIP_FILE_US.txt')}",
                fixed_size=100,
                ignore_errors=True,
                type=FileType.AZURE
            ),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file=self.get_absolute_first_path_from_prefix("/mnt/azure/incoming/hardship/archive",
                                                                     "HARDSHIP_US_INBOUND.txt_" + datetime.datetime.now().strftime(
                                                                         "%Y%m%d")),
                layout=f"{file_path_layout('INBOUND_HARDSHIP_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('INBOUND_HARDSHIP_FILE_US.txt')}",
                fixed_size=100,
                type=FileType.AZURE
            ),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file=self.get_absolute_first_path_from_prefix("/mnt/azure/incoming/hardship/archive",
                                                                     "HARDSHIP_PR_INBOUND.txt_" + datetime.datetime.now().strftime(
                                                                         "%Y%m%d")),
                layout=f"{file_path_layout('INBOUND_HARDSHIP_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('INBOUND_HARDSHIP_FILE_PR.txt')}",
                fixed_size=100,
                ignore_errors=True,
                type=FileType.AZURE
            ),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file=self.get_absolute_first_path_from_prefix("/mnt/azure/incoming/hardship/archive",
                                                                     "HARDSHIP_PR_INBOUND.txt_" + datetime.datetime.now().strftime(
                                                                         "%Y%m%d")),
                layout=f"{file_path_layout('INBOUND_HARDSHIP_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('INBOUND_HARDSHIP_FILE_PR.txt')}",
                fixed_size=100,
                type=FileType.AZURE
            ),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/eligibility/US_Eligibility_File',
                layout=f"{file_path_layout('OUTGOING_ELIGIBILITY_FILE_UHDR_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTGOING_US_ELIGIBILITY_FILE.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/eligibility/US_Eligibility_File',
                layout=f"{file_path_layout('OUTGOING_ELIGIBILITY_FILE_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTGOING_US_ELIGIBILITY_FILE.txt')}", fixed_size=250),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/eligibility/PR_Eligibility_File',
                layout=f"{file_path_layout('OUTGOING_ELIGIBILITY_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_PR_ELIGIBILITY_FILE.txt')}",
                fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/eligibility/PR_Eligibility_File',
                layout=f"{file_path_layout('OUTGOING_ELIGIBILITY_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_PR_ELIGIBILITY_FILE.txt')}",
                fixed_size=250),


            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/transfers/us/US_Transfer_File',
                layout="src/report_generator/flat_file_layouts/OUTGOING_STATE_TRANSFER_FILE_UHDR_LAYOUT.json",
                file=f"{file_path_flat('OUTBOUND_STATE_TRANSFER_FILE_US.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/transfers/us/US_Transfer_File',
                layout=f"{file_path_layout('OUTGOING_STATE_TRANSFER_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_STATE_TRANSFER_FILE_US.txt')}",
                fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/transfers/pr/PR_Transfer_File',
                layout=f"{file_path_layout('OUTGOING_STATE_TRANSFER_FILE_UHDR_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_STATE_TRANSFER_FILE_PR.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/transfers/pr/PR_Transfer_File',
                layout=f"{file_path_layout('OUTGOING_STATE_TRANSFER_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_STATE_TRANSFER_FILE_PR.txt')}",
                fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rehire/US_Rehire_File',
                layout="src/report_generator/flat_file_layouts/OUTGOING_RE_HIRE_FILE_UHDR_LAYOUT.json",
                file=f"{file_path_flat('OUTBOUND_RE_HIRE_FILE_US.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rehire/US_Rehire_File',
                layout=f"{file_path_layout('OUTGOING_RE_HIRE_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_RE_HIRE_FILE_US.txt')}",
                fixed_size=250),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rehire/PR_Rehire_File',
                layout=f"{file_path_layout('OUTGOING_RE_HIRE_FILE_UHDR_LAYOUT.json')}",
                                      file=f"{file_path_flat('OUTBOUND_RE_HIRE_FILE_PR.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rehire/PR_Rehire_File',
                layout=f"{file_path_layout('OUTGOING_RE_HIRE_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTBOUND_RE_HIRE_FILE_PR.txt')}",
                fixed_size=250),


            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/termination/US_Termination_File',
                layout=f"{file_path_layout('OUTGOING_TERMINATION_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_TERMINATION_FILE_US.txt')}",fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/termination/US_Termination_File',
                layout=f"{file_path_layout('OUTGOING_TERMINATION_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_TERMINATION_FILE_US.txt')}",
                fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/termination/PR_Termination_File',
                layout=f"{file_path_layout('OUTGOING_TERMINATION_FILE_UHDR_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_TERMINATION_FILE_PR.txt')}", fixed_size=250, ignore_errors=True),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/termination/PR_Termination_File',
                layout=f"{file_path_layout('OUTGOING_TERMINATION_FILE_LAYOUT.json')}",
              file=f"{file_path_flat('OUTGOING_TERMINATION_FILE_PR.txt')}", fixed_size=250),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rate_change/us/ML_HARDSHIP_INBOUND_FILE.txt',
                layout=f"{file_path_layout('INBOUND_RATE_COMPARISON_HARDSHIP_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('ML_HARDSHIP_INBOUND_FILE.txt')}",
                fixed_size=100,ignore_errors=True),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rate_change/pr/ML_HARDSHIP_INBOUND_FILE.txt',
                layout=f"{file_path_layout('INBOUND_RATE_COMPARISON_HARDSHIP_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('ML_HARDSHIP_INBOUND_FILE.txt')}",
                fixed_size=100, ignore_errors=True),

            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rate_change/us/US_RATE_CHANGE_File',
                layout=f"{file_path_layout('OUTGOING_RATE_CHANGE_SUMMARY_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_RATE_CHANGE_SUMMARY_FILE_US.txt')}", fixed_size=250),
            FlatFileReadConfiguration(
                bucket=self.bucket_name,
                remote_file='outgoing/rate_change/pr/PR_RATE_CHANGE_File',
                layout=f"{file_path_layout('OUTGOING_RATE_CHANGE_SUMMARY_FILE_LAYOUT.json')}",
                file=f"{file_path_flat('OUTGOING_RATE_CHANGE_SUMMARY_FILE_PR.txt')}", fixed_size=250),
            ]


    @staticmethod
    def __get_transformer_configs(logger) -> list[Transformer]:
        loan_inbound_config_us = TransformerConfig("401K LOANS INBOUND FILE(WEEKLY) US.report", 50, 'PS786101US', [])
        loan_inbound_config_pr = TransformerConfig("401K LOANS INBOUND FILE(WEEKLY) PR.report", 50, 'PS786101PR', [])

        loan_config_us = TransformerConfig("401K LOAN FILE(BIWEEKLY) US.report", 50, 'PS788301US', [])
        loan_config_pr = TransformerConfig("401K LOAN FILE(BIWEEKLY) PR.report", 50, 'PS788301PR', [])
        loan_config_wv = TransformerConfig("401K LOAN FILE(BIWEEKLY) WV.report", 50, 'PS788301WV', [])

        eligibility_config_us = TransformerConfig("401K ELIGIBILITY FILE(BIWEEKLY) US.report", 50, 'PS719101US', [])
        eligibility_config_pr = TransformerConfig("401K ELIGIBILITY FILE(BIWEEKLY) PR.report", 50, 'PS719101PR', [])

        state_transfer_config_us = TransformerConfig("401K STATE TRANSFER FILE(WEEKLY) US.report", 50, 'PS276101US', [])
        state_transfer_config_pr = TransformerConfig("401K STATE TRANSFER FILE(WEEKLY) PR.report", 50, 'PS276101PR', [])

        re_hire_config_us = TransformerConfig("401K RE HIRE FILE(WEEKLY) US.report", 50, 'PS719301US', [])
        re_hire_config_pr = TransformerConfig("401K RE HIRE FILE(WEEKLY) PR.report", 50, 'PS719301PR', [])
        #
        termination_config_us = TransformerConfig("401K TERMINATION FILE(WEEKLY) US.report", 50, 'PS719201US', [])
        termination_config_pr = TransformerConfig("401K TERMINATION FILE(WEEKLY) PR.report", 50, 'PS719201PR', [])
        #
        loa_config_us = TransformerConfig("401K LOA FILE(BIWEEKLY) US.report", 50, 'PS789101US', [])

        # Activity Report configuration
        activity_report_config = TransformerConfig("ACTIVITY_REPORT.report", 50, 'BE208801US', [])

        # Rate Change Exception Report configurations
        rate_change_exception_us_config = TransformerConfig("RATE_CHANGE_ACTIVITY_EXCEPTION_US.report", 50, 'BE208802US', [])
        rate_change_exception_pr_config = TransformerConfig("RATE_CHANGE_ACTIVITY_EXCEPTION_PR.report", 50, 'BE208802PR', [])

        rate_change_activity_summary_config = TransformerConfig("RATE_CHANGE_ACTIVITY_SUMMARY.report", 50,
                                                            'BE208801US', [])

        rate_change_summary_us_config = TransformerConfig("RATE_CHANGE_ACTIVITY_SUMMARY_US.report", 50,
                                                            'PS719701US', [])
        rate_change_summary_pr_config = TransformerConfig("RATE_CHANGE_ACTIVITY_SUMMARY_PR.report", 50,
                                                          'PS719701PR', [])

        # State Transfer DOE Change Report configurations
        state_transfer_doe_change_us_config = TransformerConfig("STATE_TRANSFER_DOE_CHANGE_US.report", 50, 'BE208101US', [])
        state_transfer_doe_change_pr_config = TransformerConfig("STATE_TRANSFER_DOE_CHANGE_PR.report", 50, 'BE208101PR', [])

        # Hardship Outbound Report configurations
        hardship_outbound_us_config = TransformerConfig("HARDSHIP_OUTBOUND_REPORT_US.report", 50, 'BE208901US', [])
        hardship_outbound_pr_config = TransformerConfig("HARDSHIP_OUTBOUND_REPORT_PR.report", 50, 'BE208901PR', [])

        # Rate Change Compare Report configurations
        rate_change_compare_us_config = TransformerConfig("RATE_CHANGE_COMPARE_US.report", 50, 'BE209201US', [])
        rate_change_compare_pr_config = TransformerConfig("RATE_CHANGE_COMPARE_PR.report", 50, 'BE209201PR', [])

        # Rate Change Hardship Compare Report configurations
        rate_change_hardship_compare_us_config = TransformerConfig("RATE_CHANGE_HARDSHIP_COMPARE_US.report", 10, 'BE209201US', [])
        rate_change_hardship_compare_pr_config = TransformerConfig("RATE_CHANGE_HARDSHIP_COMPARE_PR.report", 10, 'BE209201PR', [])

        # Term Over 65 Report configuration - single report
        term_over_65_config = TransformerConfig("TERM_OVER_65.report", 50, 'PS112101US', [])


        return [
            LoaninFileTransformer(loan_inbound_config_us, ReportType.US, logger),
            LoaninFileTransformer(loan_inbound_config_pr, ReportType.PR, logger),
            ActivityReportTransformer(activity_report_config, ReportType.US, logger),
            # Use a single identifier for both US and PR Rate Change Exception reports
            RateChangeExceptionTransformer(rate_change_exception_us_config, ReportType.US, logger),
            RateChangeExceptionTransformer(rate_change_exception_pr_config, ReportType.PR, logger),

            RateChangeOutboundSummaryTransformer(rate_change_summary_us_config, ReportType.US, logger),
            RateChangeOutboundSummaryTransformer(rate_change_summary_pr_config, ReportType.PR, logger),

            # Use a single identifier for both US and PR State Transfer DOE Change reports
            StateTransferDoeChangeTransformer(state_transfer_doe_change_us_config, ReportType.US, logger),
            StateTransferDoeChangeTransformer(state_transfer_doe_change_pr_config, ReportType.PR, logger),
            # Use a single identifier for both US and PR Hardship Inbound reports
            HardshipInboundTransformer(hardship_outbound_us_config, ReportType.US, logger),
            HardshipInboundTransformer(hardship_outbound_pr_config, ReportType.PR, logger),
            # Use a single identifier for both US and PR Rate Change Compare reports
            RateChangeCompareTransformer(rate_change_compare_us_config, ReportType.US, logger),
            RateChangeCompareTransformer(rate_change_compare_pr_config, ReportType.PR, logger),
            # Use a single identifier for both US and PR Rate Change Hardship Compare reports
            RateChangeHardshipCompareTransformer(rate_change_hardship_compare_us_config, ReportType.US, logger),
            RateChangeHardshipCompareTransformer(rate_change_hardship_compare_pr_config, ReportType.PR, logger),

            # Rate Change Activity Reports (US & PR)
            RateChangeActivityTransformer(rate_change_activity_summary_config, ReportType.US, logger),

            # Single Term Over 65 report (not separated by country)
            TermOver65Transformer(term_over_65_config, ReportType.US, logger),
            LoaFileTransformer(loa_config_us, ReportType.US, logger),
            LoanFileTransformer(loan_config_us, ReportType.US, logger),
            LoanFileTransformer(loan_config_pr, ReportType.PR, logger),
            LoanFileTransformer(loan_config_wv, ReportType.WV, logger),
            EligibilityFileTransformer(eligibility_config_us, ReportType.US, logger),
            EligibilityFileTransformer(eligibility_config_pr, ReportType.PR, logger),
            StateTransferTransformer(state_transfer_config_us, ReportType.US, logger),
            StateTransferTransformer(state_transfer_config_pr, ReportType.PR, logger),
            ReHireTransformer(re_hire_config_us, ReportType.US, logger),
            ReHireTransformer(re_hire_config_pr, ReportType.PR, logger),
            TerminationTransformer(termination_config_us, ReportType.US, logger),
            TerminationTransformer(termination_config_pr, ReportType.PR, logger),
        ]

    @staticmethod
    def pad_to_bytes(content, bytes_needed=250) -> str:

        content = content.replace("\n", '')
        content = content.replace("\r", '')
        # Convert to bytes
        content_bytes = content.encode('utf-8')

        # If less than 250 bytes, pad with spaces
        if len(content_bytes) < bytes_needed:
            # Calculate how many spaces needed
            spaces_needed = bytes_needed - len(content_bytes)
            content += ' ' * spaces_needed
            content_bytes = content.encode('utf-8')

        # If more than 250 bytes, truncate
        elif len(content_bytes) > bytes_needed:
            # Truncate to 250 bytes (be careful with UTF-8)
            content_bytes = content_bytes[:bytes_needed]

        return content_bytes

    @staticmethod
    def get_absolute_first_path_from_prefix(directory: str, prefix: str) -> str:
        """
        Returns the absolute path of the first file in the given directory that starts with the prefix.
        Returns None if no such file is found or if an error occurs while accessing the directory.
        """
        try:
            if not os.path.exists(directory):
                print(f"Directory does not exist: {directory}")
                return None

            for file_name in os.listdir(directory):
                if file_name.startswith(prefix):
                    return os.path.abspath(os.path.join(directory, file_name))

            print(f"No file starting with {prefix} found in {directory}")
            return None
        except PermissionError:
            print(f"Permission denied when accessing directory: {directory}")
            return None
        except FileNotFoundError:
            print(f"Directory not found: {directory}")
            return None
        except OSError as e:
            print(f"OS error when accessing directory {directory}: {e}")
            return None
        except Exception as e:
            print(f"Unexpected error when accessing directory {directory}: {e}")
            return None
