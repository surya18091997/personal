import logging
import os
import traceback

from ebcdic_parser.convert import run

from src.report_generator.constants import DELIMITER
from src.report_generator.input_configuration import FlatFileReadConfiguration


class FlatFileProcessingError(Exception):
    """Custom exception for file processing errors"""
    pass


class FlatFileToCSVGenerator:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def generate(self, config: FlatFileReadConfiguration) -> str:
        """Generate CSV file from flat file

        Args:
            config: The flat file read configuration

        Returns:
            str: The output folder path where the generated CSV files are stored

        Raises:
            FlatFileProcessingError: If processing fails or if return code is not 0
                                     and ignore_errors is False
        """
        try:
            self._validate_config(config)
            self.logger.info(f"Processing file {config.file} with layout {config.layout}")
            self.logger.info(f"Ignore errors setting: {config.ignore_errors}")

            output_folder = os.path.join(os.getcwd(), "src", "report_generator", "output_temp")
            log_folder = os.path.join(os.getcwd(), "src", "report_generator", "output_temp")

            # Ensure directories exist
            self._ensure_output_directory(output_folder)
            self._ensure_output_directory(log_folder)

            self.logger.debug(f"Output folder: {output_folder}")


            # Check file size before processing
            try:
                file_size = os.path.getsize(config.file)
                self.logger.info(f"File size of {config.file}: {file_size} bytes")

                if file_size == 0:
                    self.logger.warning(f"File {config.file} is empty")
            except Exception as e:
                self.logger.warning(f"Could not get file size for {config.file}: {str(e)}")

            self.logger.info(f"Starting conversion with ignoreConversionErrors={config.ignore_errors}")

            return_code = run(
                inputFile=config.file,
                outputFolder=output_folder,
                layoutFile=config.layout,
                encodingName="utf_8",
                outputDelimiter=DELIMITER,
                ignoreConversionErrors=config.ignore_errors,
                outputFileExtension=".csv",
                debug=False,  # Enable debug mode to get more information
                stripDelimiterValues=False,
                logfolder=log_folder  # Ensure all bytes including footer are processed
            )

            self.logger.info(f"Conversion completed with return code: {return_code}")

            if return_code == 0:
                self.logger.info(f"Successfully processed file {config.file}")
                return output_folder
            else:
                error_message = f"Failed to process file {config.file} and layout {config.layout} with return code {return_code}"
                self.logger.error(error_message)
                return "None"


        except FlatFileProcessingError:
            if not config.ignore_errors:
                # Re-raise FlatFileProcessingError to propagate it if not ignoring errors
                self.logger.error(f"FlatFileProcessingError occurred and will be propagated as ignore_errors={config.ignore_errors}")
                raise
            else:
                self.logger.warning(f"Ignoring validation error as configured for file {config.file}")
                return os.path.join(os.getcwd(), "src", "report_generator", "output_temp")

        except Exception as e:
            error_message = f"Unexpected error processing file {config.file if config else 'unknown'}: {str(e)}"
            self.logger.exception(error_message)
            self.logger.error(f"Stack trace: {traceback.format_exc()}")

            if not config.ignore_errors:
                raise FlatFileProcessingError(error_message) from e
            else:
                self.logger.warning(f"Ignoring unexpected error as configured: {error_message}")
                return os.path.join(os.getcwd(), "src", "report_generator", "output_temp")


    def _validate_config(self, config: FlatFileReadConfiguration) -> None:
        """Validate the configuration parameters before processing

        Args:
            config: The flat file read configuration

        Raises:
            FlatFileProcessingError: If configuration validation fails
        """
        if not config:
            raise FlatFileProcessingError("Configuration cannot be None")

        if not config.file or not os.path.exists(config.file):
            raise FlatFileProcessingError(f"Input file does not exist or is invalid: {config.file}")
        else:
            self.logger.info(f"Input file validation successful: {config.file}")

        if not config.layout or not os.path.exists(config.layout):
            raise FlatFileProcessingError(f"Layout file does not exist or is invalid: {config.layout}")
        else:
            self.logger.info(f"Layout file validation successful: {config.layout}")

        self.logger.info("All configuration validations passed successfully")

    def _ensure_output_directory(self, output_path: str) -> None:
        """Ensure the output directory exists

        Args:
            output_path: Path to the output directory

        Raises:
            FlatFileProcessingError: If directory creation fails
        """
        try:
            os.makedirs(output_path, exist_ok=True)
        except Exception as e:
            raise FlatFileProcessingError(f"Failed to create output directory: {str(e)}")

