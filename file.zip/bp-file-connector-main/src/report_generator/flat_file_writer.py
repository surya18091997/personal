from src.report_generator.output_configuration import TransformerConfig
from jinja2 import Environment, PackageLoader, select_autoescape


def pad_pre(value, char, width=0):
    return str(value).rjust(width, char)[:width]


def pad_post(value, char, width=10):
    return str(value).ljust(width, char)[:width]

class FlatFileWriter:

    def __init__(self):
        self.env = Environment(
            loader=PackageLoader("src.report_generator", package_path="templates"),
            autoescape=select_autoescape(),
            keep_trailing_newline=True
        )
        self.folder = "src/report_generator/output_temp/reports"
        self.env.filters['pad_pre'] = pad_pre
        self.env.filters['pad_post'] = pad_post

    def write(self, config: TransformerConfig):
        file_path = f"{self.folder}/{config.output_file_name}"
        f = open(file_path, 'w')
        f.truncate(0)
        for data in config.data_objects:
            if data is not None:
                template = self.env.get_template(data.template_name())
                value = template.render(data.to_dict())
                with open(file_path, 'a') as file:
                    file.write(value)
                    if data.include_new_line():
                        file.write("\n")
