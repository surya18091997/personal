from src.report_generator.templates.data_objects.data_object import DataObject


class LoanTrailerObject(DataObject):
    """
    A class to represent a loan data object.
    """


    def __init__(self, total: int, total_loan_amount: int):
        self.total = total
        self.total_loan_amount = total_loan_amount

    def to_dict(self):
        return {
            "total": self.total,
            "total_loan_amount": self.total_loan_amount,
        }

    def template_name(self):
        return "loan_trailer.template"

