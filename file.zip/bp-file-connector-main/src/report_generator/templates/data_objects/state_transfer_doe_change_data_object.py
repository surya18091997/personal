from src.report_generator.templates.data_objects.data_object import DataObject

class StateTransferDoeChangeDataObject(DataObject):
    """
    A class to represent a single detail row for the State Transfer DOE Change report.
    :param win_number: WIN NUMBER of the associate
    :param ssn: SSN of the associate from WIN_ASSOCIATE DB2 table
    :param associate_name: Last name delimited by space + ', ' + First name of the associate delimited by space from WIN_ASSOCIATE DB2 table
    :param store: STORE-NBR from WIN_ASSOCIATE DB2 table
    :param hce_ind: HCE Indicator Mapped to associate-benefit-profile.eligibility.isHighlyCompensated --> always '0' for NHCE associates and '1' for HCE associates. But as of now HCE/NHCE concept is no more followed in the system.
    :param old_doe: Old DOE code --> need to refer to the deduction process to get the OLD DOE code
    :param new_doe: New DOE code --> need to refer to the deduction process to get the NEW DOE code
    """
    def __init__(self,
                 win_number: str,
                 ssn: str,
                 associate_name: str,
                 store: str,
                 hce_ind: str,
                 old_doe: str,
                 new_doe: str):
        self.win_number = win_number
        self.ssn = ssn
        self.associate_name = associate_name
        self.store = store
        self.hce_ind = hce_ind
        self.old_doe = old_doe
        self.new_doe = new_doe

    def to_dict(self):
        return {
            "win_number": self.win_number,
            "ssn": self.ssn,
            "associate_name": self.associate_name,
            "store": self.store,
            "hce_ind": self.hce_ind,
            "old_doe": self.old_doe,
            "new_doe": self.new_doe
        }

    def template_name(self):
        return "state_transfer_doe_change_data.template"

