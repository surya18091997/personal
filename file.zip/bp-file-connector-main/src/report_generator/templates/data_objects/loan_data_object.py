from src.report_generator.templates.data_objects.data_object import DataObject


class LoanDataObject(DataObject):
    """
    A class to represent a loan data object.
    """

    def __init__(self, ssn: str, win: str, loan_number: str, loan_amount: str, pay_end_date: str, loan_cr_date: str):
        self.ssn = ssn
        self.win = win
        self.loan_number = loan_number
        self.loan_amount = loan_amount
        self.pay_end_date = pay_end_date
        self.loan_cr_date = loan_cr_date
        pass

    def to_dict(self):
        return {
            "ssn": self.ssn,
            "win": self.win,
            "loan_number": self.loan_number,
            "loan_amount": self.loan_amount,
            "pay_end_date": self.pay_end_date,
            "loan_cr_date": self.loan_cr_date,
        }

    def template_name(self):
        return "loan_data.template"

