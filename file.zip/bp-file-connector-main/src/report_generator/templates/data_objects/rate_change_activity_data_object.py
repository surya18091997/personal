from src.report_generator.templates.data_objects.data_object import DataObject


def _format_number(number):
    """
    Formats a number with commas for thousands separators.

    :param number: The number to format
    :return: Formatted string with commas
    """
    return f"{number:,}"


class RateChangeActivityDataObject(DataObject):
    """
    A class to represent a rate change activity data object.
    """

    def __init__(self, country_code: str, retirement_plan_type: str, rate_change_source: str, enrolled: int, changed_to_0: int, decreased: int, increased: int, corrected: int, total: int, total_percentage: str=""):
        """
        :param country_code: Country code (e.g., 'US' or 'PR') identified from the Coverages.planId.
        :param retirement_plan_type: Type of retirement plan identified by Coverages.planId (e.g., 'REG' - retirement_401k_regular_us).
        :param rate_change_source: Source of the rate change (e.g., 'WAL-MART' --> if createdBy = "Enrollment API", 'MERRILL LYNCH' --> if createdBy = "ML").
        :param enrolled: - Newly Enrolled - This is for associates without any pre-existing rate percent in the system. Field to check for Coverage.contribution.value for the corresponding planId
        :param changed_to_0: - Changed to 0% - This is for associates who had a pre-existing rate percent in the system and changed it to 0%. Field to check for Coverage.contribution.value for the corresponding planId
        :param decreased: - Decreased - This is for associates who had a pre-existing rate percent in the system and decreased it. Field to check for Coverage.contribution.value for the corresponding planId
        :param increased: - Increased - This is for associates who had a pre-existing rate percent in the system and increased it. Field to check for Coverage.contribution.value for the corresponding planId
        :param corrected: - Corrected - This is for associates who do not fall on any of the above categories but had a rate change. Field to check for Coverage.contribution.value for the corresponding planId
        :param total: - Total - This is the sum of all the above categories with percentage of grand total included.
        """
        self.country_code = country_code
        self.retirement_plan_type = retirement_plan_type
        self.rate_change_source = rate_change_source
        self.enrolled = enrolled
        self.changed_to_0 = changed_to_0
        self.decreased = decreased
        self.increased = increased
        self.corrected = corrected
        self.total = total
        self.total_percentage = total_percentage

    def to_dict(self):
        """
        Convert the object to a dictionary with properly formatted values.
        """
        return {
            "country_code": self.country_code,
            "retirement_plan_type": self.retirement_plan_type,
            "rate_change_source": self.rate_change_source,
            "enrolled": _format_number(self.enrolled),
            "changed_to_0": _format_number(self.changed_to_0),
            "decreased": _format_number(self.decreased),
            "increased": _format_number(self.increased),
            "corrected": _format_number(self.corrected),
            "total": _format_number(self.total),
            "total_percentage": self.total_percentage
        }

    def template_name(self):
        return "rate_change_activity_data.template"