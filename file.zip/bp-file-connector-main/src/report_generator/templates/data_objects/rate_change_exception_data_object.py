from src.report_generator.templates.data_objects.data_object import DataObject

class RateChangeExceptionDataObject(DataObject):
    """
    A class to represent a single detail row for the Rate Change Exception report.
    :param ssn: National_ID from WIN_ASSOCIATE table.
    :param asc_first_name: First name of the associate from WIN_ASSOCIATE table
    :param asc_last_name: Last name of the associate from WIN_ASSOCIATE table
    :param asc_status: EMPLOY_STAT_CODE from WIN_ASSOCIATE table
    :param elig_status: Mapped to isEligible of associate-benefit-profile for the 401k planId's
    :param elig_date: Mapped to startDate from coverages collection for the 401k hardship planId's : retirement_hardship_us & retirement_hardship_pr
    :param cntry_code: Identified based on the planId, e.g., 'US' or 'PR'.
    :param hardship_stdate: Hardship start date from coverages cosmos table
    :param reg_rate: Mapped to the latest rate (value from coverages collection) opted by the associate for the 401k regular planId's"
    :param cuc_rate: Mapped to the latest rate (value from coverages collection) opted by the associate for the 401k catchup planId's
    :param message: Message to be displayed in the report is decided as per below:
          - ASSOC NOT ELIGIBLE: Verifies that the Eligible Indicator in the base record is true.
          - ASSOC NOT FOUND IN HR QUERY: Ensures that the associate has a base record in WIN_ASSOCIATE record.
          - ASSOC TERMINATED: Checks that the employment status code of the associate is neither 'T', 'D', nor 'Q', unless the termination reason code is 83.
          - ASSOC IS ON HARDSHIP: Program will also check for associates in hardship, with the endDate from Coverages for hardship planID to be later than the current date.
          - ASSOC NOT ELIG FOR CUC: If an associate opts for the Catch-up Contribution, the program verifies that they are under 50 years old.
          - EXCEEDED MAX CATCHUP RATE US: Checks if associate opted for Catchup and elected Catch-up percentage that is less or equal to the permissible percentage.
          - EXCEEDED MAX REGULAR RATE NHCE US: Checks that associates with HCE 0 must have an elected NHCE percentage that is less or equal to the permissible percentage.
          - EXCEEDED MAX REGULAR RATE HCE US: Checks that associates with HCE 1 must have an elected HCE percentage that is less or equal to the permissible percentage.

    """
    def __init__(self,
                 ssn: str,
                 win_nbr: str,
                 asc_first_name: str,
                 asc_last_name: str,
                 asc_status: str,
                 elig_status: str,
                 elig_date: str,
                 cntry_code: str,
                 hardship_stdate: str,
                 reg_rate: str,
                 cuc_rate: str,
                 message: str):
        self.ssn = ssn
        self.win_nbr = win_nbr
        self.asc_first_name = asc_first_name
        self.asc_last_name = asc_last_name
        self.asc_status = asc_status
        self.elig_status = elig_status
        self.elig_date = elig_date
        self.cntry_code = cntry_code
        self.hardship_stdate = hardship_stdate
        self.reg_rate = reg_rate
        self.cuc_rate = cuc_rate
        self.message = message

    def to_dict(self):
        return {
            "ssn": self.ssn,
            "win_nbr": self.win_nbr,
            "asc_first_name": self.asc_first_name,
            "asc_last_name": self.asc_last_name,
            "asc_status": self.asc_status,
            "elig_status": self.elig_status,
            "elig_date": self.elig_date,
            "cntry_code": self.cntry_code,
            "hardship_stdate": self.hardship_stdate,
            "reg_rate": self.reg_rate,
            "cuc_rate": self.cuc_rate,
            "message": self.message
        }

    def template_name(self):
        return "rate_change_exception_data.template"

