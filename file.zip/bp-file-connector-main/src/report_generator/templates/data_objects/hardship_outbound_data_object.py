from src.report_generator.templates.data_objects.data_object import DataObject

class HardshipInboundDataObject(DataObject):
    """
    A class to represent a single detail row for the Hardship Inbound report.
    :param ssn: National ID from WIN_ASSOCIATE table
    :param win_nbr: WIN number
    :param first_name: First name of the associate from WIN_ASSOCIATE table
    :param last_name: Last name of the associate from WIN_ASSOCIATE table
    :param a_st: EMPLOY-STAT-CODE of the associate from WIN_ASSOCIATE table
    :param e_st: Mapped to isEligible of associate-benefit-profile for the 401k planId's
    :param e_date: Mapped to eligibleDate of associate-benefit-profile for the 401k planId's
    :param c_c: STR-STATE-PROV-CD from WIN_ASSOCIATE table
    :param start_dt: eligibleDate from associate-benefit-profile for the 401k hardship planId's
    :param end_dt: Derive the Hardship end date by the below formula:
        1) PR Associate	--> One year from the start date
        2) US Associate	--> Six months from the start date
    :param message: Message is derived as given below:
        1) If start Date in BAML Inbound file is not of the correct format  --> 	'INVALID BEGIN DATE FROM ML'
        2) If ML End date is not matching with the Derived end date	--> 'ML END DATE IS INCORRECT. CORRECT DATE USED'

    """
    def __init__(self,
                 ssn: str,
                 win_nbr: str,
                 first_name: str,
                 last_name: str,
                 a_st: str,
                 e_st: str,
                 e_date: str,
                 c_c: str,
                 start_dt: str,
                 end_dt: str,
                 message: str):
        self.ssn = ssn
        self.win_nbr = win_nbr
        self.first_name = first_name
        self.last_name = last_name
        self.a_st = a_st
        self.e_st = e_st
        self.e_date = e_date
        self.c_c = c_c
        self.start_dt = start_dt
        self.end_dt = end_dt
        self.message = message

    def to_dict(self):
        return {
            "ssn": self.ssn,
            "win_nbr": self.win_nbr,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "a_st": self.a_st,
            "e_st": self.e_st,
            "e_date": self.e_date,
            "c_c": self.c_c,
            "start_dt": self.start_dt,
            "end_dt": self.end_dt,
            "message": self.message
        }

    def template_name(self):
        return "hardship_outbound_data.template"

