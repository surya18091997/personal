from abc import abstractmethod, ABC


class DataObject(ABC):

    @abstractmethod
    def to_dict(self):
        pass

    @abstractmethod
    def template_name(self):
        pass

    def include_new_line(self) -> bool:
        return True