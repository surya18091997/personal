from typing_extensions import override

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.loan_data_object import LoanDataObject


class DataObjectWrapper(DataObject):
    """
    A class to represent a loan data object.
    """


    def __init__(self, data: list[DataObject], template_name_str: str):
        self.data = data
        self.template_name_str = template_name_str
        pass

    def to_dict(self):
        return {
            "dataset":  [d.to_dict() for d in self.data]
        }

    def template_name(self):
        return  self.template_name_str

    @override
    def include_new_line(self) -> bool:
        return False


