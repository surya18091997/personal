from src.report_generator.templates.data_objects.data_object import DataObject


class RateChangeActivityTrailerObject(DataObject):
    """
    A class to represent a loan data object.
    """


    def __init__(self, enrolled_count: int, change_to_0_count: int, decreased_count: int, increased_count: int, corrected_count: int, total:int, percent_grand_total: str):
        self.enrolled_count = enrolled_count
        self.change_to_0_count = change_to_0_count
        self.decreased_count = decreased_count
        self.increased_count = increased_count
        self.corrected_count = corrected_count
        self.total = total
        self.percent_grand_total = percent_grand_total

    def to_dict(self):
        return {
            "enrolled_count": self.enrolled_count,
            "change_to_0_count": self.change_to_0_count,
            "decreased_count": self.decreased_count,
            "increased_count": self.increased_count,
            "corrected_count": self.corrected_count,
            "total": self.total,
            "percent_grand_total": self.percent_grand_total
        }

    def template_name(self):
        return "rate_change_activity_trailer.template"

