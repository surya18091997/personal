from src.report_generator.templates.data_objects.data_object import DataObject


class EligibilityTrailerObject(DataObject):
    """
    A class to represent a loan data object.
    """


    def __init__(self, total: int):
        self.total = total

    def to_dict(self):
        return {
            "total": self.total
        }

    def template_name(self):
        return "eligibility_trailer.template"

