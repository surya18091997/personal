from src.report_generator.templates.data_objects.data_object import DataObject

class RateChangeExceptionTrailerObject(DataObject):
    """
    A class to represent the 'Rate Change Exception' trailer data object for the report.
    """
    def __init__(self,
                 assoc_not_eligible: int,
                 assoc_terminated: int,
                 assoc_not_elig_for_cuc: int,
                 exceeded_max_regular_rate_nhce_us: int,
                 exceeded_max_regular_rate_hce_us: int,
                 exceeded_max_catchup_rate_us: int,
                 assoc_is_on_hardship: int):
        self.assoc_not_eligible = assoc_not_eligible
        self.assoc_terminated = assoc_terminated
        self.assoc_not_elig_for_cuc = assoc_not_elig_for_cuc
        self.exceeded_max_regular_rate_nhce_us = exceeded_max_regular_rate_nhce_us
        self.exceeded_max_regular_rate_hce_us = exceeded_max_regular_rate_hce_us
        self.exceeded_max_catchup_rate_us = exceeded_max_catchup_rate_us
        self.assoc_is_on_hardship = assoc_is_on_hardship

    def to_dict(self):
        return {
            "assoc_not_eligible": self.assoc_not_eligible,
            "assoc_terminated": self.assoc_terminated,
            "assoc_not_elig_for_cuc": self.assoc_not_elig_for_cuc,
            "exceeded_max_regular_rate_nhce_us": self.exceeded_max_regular_rate_nhce_us,
            "exceeded_max_regular_rate_hce_us": self.exceeded_max_regular_rate_hce_us,
            "exceeded_max_catchup_rate_us": self.exceeded_max_catchup_rate_us,
            "assoc_is_on_hardship": self.assoc_is_on_hardship
        }

    def template_name(self):
        return "rate_change_exception_trailer.template"

