from src.report_generator.templates.data_objects.data_object import DataObject


class LoaDataObject(DataObject):
    """
    A class to represent a loa data object.
    """

    def __init__(self, win: str, leave_type: str,  start_date: str, end_date: str):
        self.win = win
        self.leave_type = leave_type
        self.start_date = start_date
        self.end_date = end_date
        pass

    def to_dict(self):
        return {
            "win": self.win,
            "leave_type": self.leave_type,
            "start_date": self.start_date,
            "end_date": self.end_date
        }

    def template_name(self):
        return "loa_data.template"