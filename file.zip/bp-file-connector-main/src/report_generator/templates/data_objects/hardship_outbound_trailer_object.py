from src.report_generator.templates.data_objects.data_object import DataObject

class HardshipInboundTrailerObject(DataObject):
    """
    A class to represent the trailer record for the Hardship Inbound report.
    :param total_reads: Total number of reads
    :param total_correct: Total number of correctly processed records and inserted into the cosmos db
    :param total_incorrect: Total number of invalid record skipped
    """
    def __init__(self, total_reads: int, total_correct: int, total_incorrect: int):
        self.total_reads = total_reads
        self.total_correct = total_correct
        self.total_incorrect = total_incorrect

    def to_dict(self):
        return {
            "total_reads": self.total_reads,
            "total_correct": self.total_correct,
            "total_incorrect": self.total_incorrect
        }

    def template_name(self):
        return "hardship_outbound_trailer.template"

