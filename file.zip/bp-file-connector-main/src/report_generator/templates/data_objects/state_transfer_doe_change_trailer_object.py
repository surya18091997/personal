from src.report_generator.templates.data_objects.data_object import DataObject


class StateTransferDoeChangeTrailerObject(DataObject):
    """
    This class represents the trailer for the State Transfer DOE Change report.
    It contains the report number for the trailer section.
    """

    def __init__(self, report_number):
        """
        Initializes the StateTransferDoeChangeTrailerObject with the given parameters.

        :param report_number: The report number to display in the trailer
        """
        self.report_number = report_number

    def to_dict(self):
        return {
            "report_number": self.report_number
        }

    def template_name(self):
        return "state_transfer_doe_change_trailer.template"
