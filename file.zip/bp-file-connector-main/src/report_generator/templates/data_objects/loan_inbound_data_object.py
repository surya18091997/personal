from src.report_generator.templates.data_objects.data_object import DataObject


class LoanInboundDataObject(DataObject):
    """
    A class to represent a loan data object.
    :param win: Mapped to Coverages.associateId
    :param loan_number: Mapped to Coverages.loanSequenceNumber
    :param deducted_amount: Mapped to Coverages.deduction.value
    :param loan_type: To be derived from Coverages.planId.
        1) retirement_401k_loan_general_us --> 0,
        2) retirement_401k_loan_residential_us --> 1,
        3) retirement_401k_loan_general_pr --> 0,
        4) retirement_401k_loan_residential_pr --> 1
    :param payroll_id: Mapped to PAYROLL-ID from Loan in-bound file
    :param goal_amount: Mapped to GOAL-AMOUNT from Loan in-bound file
    :param pay_frequency: Mapped to PAY-FREQUENCY from Loan in-bound file
    :param store_location_code: Mapped to STORE-LOCATION-CD from Loan in-bound file
    :param country_code: To be derived from the Coverage.planId.
        1) retirement_401k_loan_general_us --> US,
        2) retirement_401k_loan_residential_us --> US,
        3) retirement_401k_loan_general_pr --> PR,
        4) retirement_401k_loan_residential_pr --> PR
    """

    def __init__(self,win: str, loan_number: str, deducted_amount: str, loan_type: str, payroll_id: str, goal_amount: str, pay_frequency: str, store_location_code: str,country_code: str):
        self.win = win
        self.loan_number = loan_number
        self.deducted_amount = deducted_amount
        self.loan_type = loan_type
        self.payroll_id = payroll_id
        self.goal_amount = goal_amount
        self.pay_frequency = pay_frequency
        self.store_location_code = store_location_code
        self.country_code = country_code
        pass

    def to_dict(self):
        return {
            "win": self.win,
            "loan_number": self.loan_number,
            "deducted_amount": self.deducted_amount,
            "loan_type": self.loan_type,
            "payroll_id":self.payroll_id,
            "goal_amount": self.goal_amount,
            "pay_frequency":self.pay_frequency,
            "store_location_code":self.store_location_code,
            "country_code":self.country_code
        }

    def template_name(self):
        return "loan_inbound_data.template"

