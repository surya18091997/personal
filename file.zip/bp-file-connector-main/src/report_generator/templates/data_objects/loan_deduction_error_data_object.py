from src.report_generator.templates.data_objects.data_object import DataObject

class LoanDeductionErrorDataObject(DataObject):
    """
    A class to represent a single detail row for the Loan Deduction Error report.
    :param hce: HCE indicator
    :param win: WIN number
    :param loan_num: Loan number
    :param deducted_amt: Deducted amount
    :param loan_type: Loan type
    :param payroll_id: Payroll ID
    :param goal_amount: Goal amount
    :param pay_frqncy: Pay frequency
    :param sstr_loc_code: SSTR location code
    :param country_code: Country code
    :param error_message: Error message
    """
    def __init__(self,
                 hce: str,
                 win: str,
                 loan_num: str,
                 deducted_amt: str,
                 loan_type: str,
                 payroll_id: str,
                 goal_amount: str,
                 pay_frqncy: str,
                 sstr_loc_code: str,
                 country_code: str,
                 error_message: str):
        self.hce = hce
        self.win = win
        self.loan_num = loan_num
        self.deducted_amt = deducted_amt
        self.loan_type = loan_type
        self.payroll_id = payroll_id
        self.goal_amount = goal_amount
        self.pay_frqncy = pay_frqncy
        self.sstr_loc_code = sstr_loc_code
        self.country_code = country_code
        self.error_message = error_message

    def to_dict(self):
        return {
            "hce": self.hce,
            "win": self.win,
            "loan_num": self.loan_num,
            "deducted_amt": self.deducted_amt,
            "loan_type": self.loan_type,
            "payroll_id": self.payroll_id,
            "goal_amount": self.goal_amount,
            "pay_frqncy": self.pay_frqncy,
            "sstr_loc_code": self.sstr_loc_code,
            "country_code": self.country_code,
            "error_message": self.error_message
        }

    def template_name(self):
        return "loan_deduction_error_data.template"

