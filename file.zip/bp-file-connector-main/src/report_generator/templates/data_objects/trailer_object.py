from src.report_generator.templates.data_objects.data_object import DataObject


class TrailerObject(DataObject):
    """
    This class represents the header of a report.
    It contains the title, subtitle, and date of the report.
    """

    def __init__(self, run_on, run_at, report_number,pay_period_date):
        """
        Initializes the LoanDataObject with the given parameters.

        :param run_on: The date of the loan data object.
        :param run_at: The time of the loan data object.
        :param report_number: The report number of the loan data object.
        :param pay_period_date: The pay period date of the loan data object.
        """
        self.run_on = run_on
        self.run_at = run_at
        self.report_number = report_number
        self.pay_period_date = pay_period_date

    def to_dict(self):
        return {
            "run_on": self.run_on,
            "run_at": self.run_at,
            "report_number": self.report_number,
            "pay_period_date": self.pay_period_date,
        }

    def template_name(self):
        return "trailer.template"

