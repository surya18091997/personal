from src.report_generator.templates.data_objects.data_object import DataObject

class RateChangeCompareTrailerObject(DataObject):
    """
    A class to represent the trailer record for the Rate Change Compare report.
    :param total_nbr_of_assocs: Total number of associates on compare
    """
    def __init__(self, total_nbr_of_assocs: int):
        self.total_nbr_of_assocs = total_nbr_of_assocs

    def to_dict(self):
        return {
            "total_nbr_of_assocs": self.total_nbr_of_assocs
        }

    def template_name(self):
        return "rate_change_compare_trailer.template"

