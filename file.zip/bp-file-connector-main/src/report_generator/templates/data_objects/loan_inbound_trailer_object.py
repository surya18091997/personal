from src.report_generator.templates.data_objects.data_object import DataObject


class LoanInboundTrailerObject(DataObject):
    """
    A class to represent a loan data object.
    """


    def __init__(self, total: int, total_deducted_amount: int,total_goal_amount: int):
        self.total = total
        self.total_deducted_amount = total_deducted_amount
        self.total_goal_amount = total_goal_amount

    def to_dict(self):
        return {
            "total": self.total,
            "total_deducted_amount": self.total_deducted_amount,
            "total_goal_amount": self.total_goal_amount
        }

    def template_name(self):
        return "loan_inbound_trailer.template"

