from src.report_generator.templates.data_objects.data_object import DataObject


class TerminationDataObject(DataObject):
    """
    A class to represent a loan data object.
    ssn - R01-PART-NUMBER from the out bound file
    win - R01-EMPLOYEE-NUMBER from the out bound file
    first_name - FIRST_NAME from WIN_ASSOCIATE
    last_name - LAST_NAME from WIN_ASSOCIATE
    address - R02-STREET-ADDRESS-L2 from outbound file
    zip - R02-ZIP from out bound file
    store_number - R62-WORK-LOCATION from the out bound file
    hire date - associate-benefits-profile.eligibility.plans.originalHireDate
    birth date - R01-BIRTH-DATE from the out bound file
    eff_date - PAYOUT_DATE - 30 DAYS
    term_date - R01-TERM-RETIRE-DATE from outbound file
    term_payout_date - PAYOUT_DATE
    """

    def __init__(self, ssn: str, win: str, first_name: str,  last_name: str, address: str, city: str,  state: str, zip: str, store_number: str, hire_date : str, birth_date: str, eff_date : str, term_date: str, term_payout_date: str, eligible_hours: str, years_of_service: str ):
        self.ssn = ssn
        self.win = win
        self.first_name = first_name
        self.last_name = last_name
        self.address = address
        self.city = city
        self.state = state
        self.zip = zip
        self.store_number = store_number
        self.hire_date = hire_date
        self.birth_date = birth_date
        self.eff_date = eff_date
        self.term_date = term_date
        self.term_payout_date = term_payout_date
        self.eligible_hours = eligible_hours
        self.years_of_service = years_of_service
        pass

    def to_dict(self):
        return {
            "ssn": self.ssn,
            "win": self.win,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "address": self.address,
            "city": self.city,
            "state": self.state,
            "zip": self.zip,
            "store_number": self.store_number,
            "hire_date": self.hire_date,
            "birth_date": self.birth_date,
            "eff_date": self.eff_date,
            "term_date": self.term_date,
            "term_payout_date": self.term_payout_date,
            "eligible_hours": self.eligible_hours,
            "years_of_service": self.years_of_service
        }

    def template_name(self):
        return "termination_data.template"