from src.report_generator.templates.data_objects.data_object import DataObject

class RateChangeCompareDataObject(DataObject):
    """
    A class to represent a single detail row for the Rate Change Compare report.
    :param ssn: National_ID of the associate from WIN_ASSOCIATE table
    :param win_nbr: WIN number
    :param asc_first_name: Associate first name from WIN_ASSOCIATE table
    :param asc_last_name: Associate last name from WIN_ASSOCIATE table
    :param asc_status: EMPLOY-STAT-CODE from WIN_ASSOCIATE table
    :param elig_status: Mapped to isEligible of associate-benefit-profile for the 401k planId's from cosmos
    :param elig_date: Mapped to eligibleDate of associate-benefit-profile for the 401k planId's from cosmos
    :param term_date: TERMINATION-DATE from WIN_ASSOCIATE table of db2
    :param db_reg_rate: Mapped to the field coverages.contribution.value for 401k regular planId from cosmos
    :param db_cuc_rate: Mapped to the field coverages.contribution.value for 401k CUC planId from cosmos
    :param fl_reg_rate: Regular rate (record-10) received from BAML inbound Hardship file N01.BEN.BE2075B.FTP.ASOCRATE.PML/N01.BEN.BE2075B.FTP.ASOCRATE.ML
            coverages -> plainId -> hardship -> if its active -> (start and end date should cover the current run date) ->  0  else  db_reg_rate
    :param fl_cuc_rate: CUC rate (record-10) received from BAML inbound Hardship file N01.BEN.BE2075B.FTP.ASOCRATE.PML/N01.BEN.BE2075B.FTP.ASOCRATE.ML
            coverages -> plainId -> regular_catchup -> if its active -> (start and end date should cover the current run date) ->  0 else db_cuc_rate
    """
    def __init__(self,
                 ssn: str,
                 win_nbr: str,
                 asc_first_name: str,
                 asc_last_name: str,
                 asc_status: str,
                 elig_status: str,
                 elig_date: str,
                 term_date: str,
                 db_reg_rate: str,
                 db_cuc_rate: str,
                 fl_reg_rate: str,
                 fl_cuc_rate: str):
        self.ssn = ssn
        self.win_nbr = win_nbr
        self.asc_first_name = asc_first_name
        self.asc_last_name = asc_last_name
        self.asc_status = asc_status
        self.elig_status = elig_status
        self.elig_date = elig_date
        self.term_date = term_date
        self.db_reg_rate = db_reg_rate
        self.db_cuc_rate = db_cuc_rate
        self.fl_reg_rate = fl_reg_rate
        self.fl_cuc_rate = fl_cuc_rate

    def to_dict(self):
        return {
            "ssn": self.ssn,
            "win_nbr": self.win_nbr,
            "asc_first_name": self.asc_first_name,
            "asc_last_name": self.asc_last_name,
            "asc_status": self.asc_status,
            "elig_status": self.elig_status,
            "elig_date": self.elig_date,
            "term_date": self.term_date,
            "db_reg_rate": self.db_reg_rate,
            "db_cuc_rate": self.db_cuc_rate,
            "fl_reg_rate": self.fl_reg_rate,
            "fl_cuc_rate": self.fl_cuc_rate
        }

    def template_name(self):
        return "rate_change_compare_data.template"

