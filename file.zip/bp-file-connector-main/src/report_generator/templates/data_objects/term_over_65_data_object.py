from src.report_generator.templates.data_objects.data_object import DataObject


class TermOver65DataObject(DataObject):
    """
    This class represents a data record for the Terminated Associates Over 65 Report.
    It contains information about terminated associates who are over the age of 70.
    """

    def __init__(self, hce, ssn, first_name, last_name, state_cd, zip_cd, wrk_div_number,
                 wrk_store_number, employee_status, eligible_date, hire_date, birth_date,
                 calculated_age, effective_date, termination_date, payout_date, eligible_hours,
                 years_eligible):
        """
        Initialize a TermOver65DataObject with the provided parameters.

        :param hce: Higher Compensated Employee indicator
        :param ssn: Social Security Number
        :param first_name: First name of the associate
        :param last_name: Last name of the associate
        :param state_cd: State code
        :param zip_cd: ZIP code
        :param wrk_div_number: Work division number
        :param wrk_store_number: Work store number
        :param employee_status: Employee status
        :param eligible_date: Eligibility date
        :param hire_date: Hire date
        :param birth_date: Birth date
        :param calculated_age: Calculated age
        :param effective_date: Effective date
        :param termination_date: Termination date
        :param payout_date: Payout date
        :param eligible_hours: Eligible hours
        :param years_eligible: Years eligible
        """
        self.hce = hce
        self.ssn = ssn
        self.first_name = first_name
        self.last_name = last_name
        self.state_cd = state_cd
        self.zip_cd = zip_cd
        self.wrk_div_number = wrk_div_number
        self.wrk_store_number = wrk_store_number
        self.employee_status = employee_status
        self.eligible_date = eligible_date
        self.hire_date = hire_date
        self.birth_date = birth_date
        self.calculated_age = calculated_age
        self.effective_date = effective_date
        self.termination_date = termination_date
        self.payout_date = payout_date
        self.eligible_hours = eligible_hours
        self.years_eligible = years_eligible

    def to_dict(self):
        """
        Convert this object to a dictionary.

        :return: A dictionary representation of this object
        """
        return {
            "hce": self.hce,
            "ssn": self.ssn,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "state_cd": self.state_cd,
            "zip_cd": self.zip_cd,
            "wrk_div_number": self.wrk_div_number,
            "wrk_store_number": self.wrk_store_number,
            "employee_status": self.employee_status,
            "eligible_date": self.eligible_date,
            "hire_date": self.hire_date,
            "birth_date": self.birth_date,
            "calculated_age": self.calculated_age,
            "effective_date": self.effective_date,
            "termination_date": self.termination_date,
            "payout_date": self.payout_date,
            "eligible_hours": self.eligible_hours,
            "years_eligible": self.years_eligible
        }

    def template_name(self):
        """
        Return the template name for this data object.

        :return: The template name
        """
        return "term_over_65_data.template"

