from src.report_generator.templates.data_objects.data_object import DataObject


class RateChangeOutboundSummaryDataObject(DataObject):
    """
    This class represents the summary data for the Rate Change Outbound report.
    It contains counts of different record types and total records.
    """

    def __init__(self, header_count=0, trailer_count=0, record_type_01=0, 
                 record_type_02=0, record_type_05=0, record_type_08=0, 
                 record_type_10=0, record_type_62=0, total_count=0):
        """
        Initializes the RateChangeOutboundSummaryDataObject with the given parameters.

        :param header_count: Count of header records
        :param trailer_count: Count of trailer records
        :param record_type_01: Count of eligibility data records (TYPE 01)
        :param record_type_02: Count of address records (TYPE 02)
        :param record_type_05: Count of contribution records (TYPE 05)
        :param record_type_08: Count of non-discrimination records (TYPE 08)
        :param record_type_10: Count of SSN change records (TYPE 10)
        :param record_type_62: Count of term data address records (TYPE 62)
        :param total_count: Total count of all records
        """
        self.header_count = header_count
        self.trailer_count = trailer_count
        self.record_type_01 = record_type_01
        self.record_type_02 = record_type_02
        self.record_type_05 = record_type_05
        self.record_type_08 = record_type_08
        self.record_type_10 = record_type_10
        self.record_type_62 = record_type_62
        self.total_count = total_count

    def to_dict(self):
        """
        Returns a dictionary of the object's attributes with proper formatting.
        This is used for template rendering.
        """
        
        # Wrap the data object in a dataset list to match the template's expectations
        return {
            "header_count": self._format_number(self.header_count),
            "trailer_count": self._format_number(self.trailer_count),
            "record_type_01": self._format_number(self.record_type_01),
            "record_type_02": self._format_number(self.record_type_02),
            "record_type_05": self._format_number(self.record_type_05),
            "record_type_08": self._format_number(self.record_type_08),
            "record_type_10": self._format_number(self.record_type_10),
            "record_type_62": self._format_number(self.record_type_62),
            "total_count": self._format_number(self.total_count)
        }
        
    def _format_number(self, number):
        """
        Formats a number with commas for thousands separators.
        
        :param number: The number to format
        :return: Formatted string with commas
        """
        return f"{number:,}"

        
    def template_name(self):
        """
        Returns the name of the template file for this object.
        """
        return "rate_change_outbound_summary_data.template"
