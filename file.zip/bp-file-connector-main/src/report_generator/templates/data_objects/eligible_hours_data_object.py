from src.report_generator.templates.data_objects.data_object import DataObject


class EligibleHoursDataObject(DataObject):
    """
    A class to represent a single detail row for the Eligible Hours report.
    :param total_header: Count of total header records
    :param total_trailer: Count of total trailer records
    :param record_type_01: Count for record type 01 (eligibility data)
    :param record_type_02: Count for record type 02 (address)
    :param record_type_05: Count for record type 05 (contributions)
    :param record_type_08: Count for record type 08 (non-discrimination)
    :param record_type_10: Count for record type 10 (SSN changes)
    :param record_type_62: Count for record type 62 (term data address)
    :param total_count: Total count
    """

    def __init__(
            self,
            total_header: int,
            total_trailer: int,
            record_type_01: int,
            record_type_02: int,
            record_type_05: int,
            record_type_08: int,
            record_type_10: int,
            record_type_62: int,
            total_count: int
    ):
        self.total_header = total_header
        self.total_trailer = total_trailer
        self.record_type_01 = record_type_01
        self.record_type_02 = record_type_02
        self.record_type_05 = record_type_05
        self.record_type_08 = record_type_08
        self.record_type_10 = record_type_10
        self.record_type_62 = record_type_62
        self.total_count = total_count

    def to_dict(self):
        return {
            "total_header": self.total_header,
            "total_trailer": self.total_trailer,
            "record_type_01": self.record_type_01,
            "record_type_02": self.record_type_02,
            "record_type_05": self.record_type_05,
            "record_type_08": self.record_type_08,
            "record_type_10": self.record_type_10,
            "record_type_62": self.record_type_62,
            "total_count": self.total_count
        }

    def template_name(self):
        return "eligible_hours_data.template"