from src.report_generator.templates.data_objects.data_object import DataObject


class TermOver65TrailerObject(DataObject):
    """
    This class represents the trailer for the Terminated Associates Over 65 Report.
    It contains the count of associates in the report.
    """

    def __init__(self, total_assocs):
        """
        Initialize a TermOver65TrailerObject with the provided parameters.

        :param total_assocs: Total number of associates in the report
        """
        self.total_assocs = total_assocs

    def to_dict(self):
        """
        Convert this object to a dictionary.

        :return: A dictionary representation of this object
        """
        return {
            "total_assocs": self.total_assocs
        }

    def template_name(self):
        """
        Return the name of the template to use for this trailer.

        :return: Template name
        """
        return "term_over_65_trailer.template"
