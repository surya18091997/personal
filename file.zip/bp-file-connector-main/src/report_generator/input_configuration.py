from dataclasses import dataclass
from enum import Enum


class FileType(Enum):
    GCS = 1
    AZURE = 2

@dataclass
class FlatFileReadConfiguration:
    bucket: str
    remote_file: str
    layout: str
    file: str
    fixed_size: int
    ignore_errors: bool = False
    type: FileType = FileType.GCS
