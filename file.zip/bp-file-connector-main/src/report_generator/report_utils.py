import os
from enum import Enum


class ReportFileType(Enum):
    FLAT = 1
    LAYOUT = 2

file_type_dict = {
    ReportFileType.FLAT: f"src/report_generator/flat_files",
    ReportFileType.LAYOUT: "src/report_generator/flat_file_layouts"
}

def file_path_layout(name: str):
    return file_path(ReportFileType.LAYOUT, name)

def file_path_flat(name: str):
    return file_path(ReportFileType.FLAT, name)

def file_path(file_type: ReportFileType, name: str):
    return f"{os.getcwd()}/{file_type_dict[file_type]}/{name}"

def reverse_integer_lastbyte_conversion(formatted_str):
    """
    Reverses the mainframe-specific format back to the original integer.

    Parameters:
    - formatted_str (str): The formatted string with the last character in EBCDIC overpunch format.

    Returns:
    - int: The original integer value.

    Raises:
    - ValueError: If the input format is invalid.
    """
    try:
        if isinstance(formatted_str, int):
            return '{}'.format(formatted_str)

        if not formatted_str or not isinstance(formatted_str, str):
            return 0

        if formatted_str == "0":
            return 0

        overpunch_char = formatted_str[-1]
        number_part = formatted_str[:-1]

        # Map overpunch characters to digits
        if overpunch_char == '{':
            digit = '0'
        else:
            digit = str(ord(overpunch_char) - 64)

        return int(number_part + digit)

    except Exception as e:
        # self.logger.error(f'Error in reverse_integer_lastbyte_conversion: {e}')
        raise


def convert_digits_to_decimal(value_int: int):
    """
    Converts an integer to a decimal format where the last two digits become the decimal part.
    For example: 00000 -> "0.00", 12345 -> "123.45", 00100 -> "1.00", 1234567 -> "12345.67"

    Parameters:
    - value_int (int): The integer value to convert

    Returns:
    - str: The converted decimal string
    """
    if value_int == 0:
        return "0.00"

    # Check if the integer has at least 2 digits
    if value_int >= 100:
        whole_part = value_int // 100  # Integer division to get the whole number part
        decimal_part = value_int % 100  # Modulo to get the last two digits

        return f"{whole_part}.{decimal_part:02d}"  # Format decimal part to always have 2 digits
    else:
        # If less than 100, format as 0.xx
        return f"0.{value_int:02d}"
