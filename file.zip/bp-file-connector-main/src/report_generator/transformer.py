from abc import abstractmethod, ABC
from typing import TypeVar, Generic

from pyspark.sql import SparkSession

from repo_utils.cosmos_utils_mongo import cosmos_utils
from src.integrations.bigquery_conn import BigQueryDatabase
import yaml
from src.constants import PG_CONNECTION_PATH, APP_NAME, PG_SQL_CONFIG, PG_CFG_HOSTNAME, \
    PG_CFG_DATABASE, PG_CFG_PORT, PG_CFG_USERNAME, PG_CFG_PASSWORD
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.data_object_wrapper import DataObjectWrapper
from src.report_generator.transformers.report_types import ReportType
from src.utils import app_config

T = TypeVar('T', bound=DataObject)


class Transformer(ABC, Generic[T]):

    def __init__(self, transfor_config: TransformerConfig, report_type: ReportType, logger):
        self.output_configuration = transfor_config
        with open(app_config.get_config_value("app", "DB2BAUS"), 'r') as file:
            self.db2_connection  = file.read()
        with open(app_config.get_config_value("app", "cosmos_connection_string"), 'r') as file:
            self.cosmos_connection_string  = file.read()

        self.cosmos_connection_url = app_config.get_config_value("app", "core_sql_cosmos_url")
        self.gcp_connection = BigQueryDatabase(logger=logger)
        self.logger = logger
        self.report_type = report_type
        # TO Run in local
        # .config("spark.driver.extraJavaOptions", "-Djava.security.manager=allow") \
        # .config("spark.executor.extraJavaOptions", "-Djava.security.manager=allow") \
        # Configure Spark for single-node operation
        self.logger.info("Initializing Spark Session")
        self.spark = SparkSession.builder \
            .appName("ReportGeneratorSparkSession") \
            .config("spark.driver.memory", "8g") \
            .config("spark.executor.memory", "8g") \
            .config("spark.memory.fraction", "0.8") \
            .config("spark.sql.shuffle.partitions", "8") \
            .config("spark.memory.storageFraction", "0.3") \
            .config("spark.default.parallelism", "8") \
            .config("spark.ui.showConsoleProgress", "true") \
            .config("spark.ui.consoleProgress.update.interval", "5000") \
            .config("spark.jars.packages",
                    "com.azure.cosmos.spark:azure-cosmos-spark_3-5_2-12:4.37.2,com.ibm.db2.jcc:db2jcc:db2jcc4,org.postgresql:postgresql:42.6.0") \
            .master("local[*]") \
            .getOrCreate()
        self.logger.info("Spark Session initialized successfully")

    def _cosmos_config(self):
        return {
            "spark.cosmos.accountEndpoint": self.cosmos_connection_url,
            "spark.cosmos.accountKey": self.cosmos_connection_string,
            "spark.cosmos.database": 'benefits-platform',
            # Add optimized Cosmos DB specific parameters
            "spark.cosmos.read.maxItemCount": "100000",
            "spark.cosmos.read.partitioning.strategy": "Restrictive"
        }

    def _postgres_config(self):
        try:
            postgres_sql_connection_file_path = app_config.get_config_value(APP_NAME, PG_CONNECTION_PATH)
            with open(postgres_sql_connection_file_path, 'r') as file:
                config = yaml.full_load(file)
            db_config = config.get(PG_SQL_CONFIG)
            schema = db_config.get("currentSchema", "public")

            if db_config:
                return  {
                    "driver": "org.postgresql.Driver",
                    "port": db_config.get(PG_CFG_PORT),
                    "hostname": db_config.get(PG_CFG_HOSTNAME),
                    "database": db_config.get(PG_CFG_DATABASE),
                    "user": db_config.get(PG_CFG_USERNAME),
                    "password": db_config.get(PG_CFG_PASSWORD),
                    "schema": schema
                }

            else:
                self.logger.error("No configuration found for PostgreSQL connection")
                raise ConnectionError("No configuration found for PostgreSQL connection")
        except Exception as e:
            self.logger.error(f"Error connecting to PostgreSQL database: {e}")
            raise e

    def cosmos_dataframe(self, container_name: str):
        """
        Create a DataFrame from Cosmos DB container.
        :param container_name: Name of the Cosmos DB container.
        :return: DataFrame containing data from the specified container.
        """
        properties = self._cosmos_config()
        return self.spark.read.format("cosmos.oltp").options(**properties).option("spark.cosmos.container", container_name)


    def db2_frame(self, table_name: str):
        properties = {
            "driver": "com.ibm.db2.jcc.DB2Driver",
        }
        return self.spark.read.option("fetchsize", "100000").jdbc(url=self.db2_connection, table=table_name,
                                                                   properties=properties)

    def cosmos_query(self, query, container_name: str):
        properties = self._cosmos_config()
        properties["spark.cosmos.read.customQuery"] = query

        return self.spark.read.format("cosmos.oltp").options(**properties).option("spark.cosmos.container", container_name).load()


    def db2_query(self, query: str):
        # Create a DataFrame from DB2 using the provided query
        properties = {
            "driver": "com.ibm.db2.jcc.DB2Driver",
        }
        return self.spark.read.format('jdbc').options(url=self.db2_connection, query=query, **properties).load()

    def bigquery_extract(self, query: str):
        # Create a DataFrame from BigQuery using the provided query.
        result_df = self.gcp_connection.get_df_from_query(query)

        return result_df

    def postgres_frame(self, table_name: str):
        """
        Create a DataFrame from PostgreSQL table.
        :param table_name: Name of the PostgreSQL table.
        :return: DataFrame containing data from the specified table.
        """
        try:

            properties = self._postgres_config()
            db_properties = {
                "driver": "org.postgresql.Driver",
                "user": properties['user'],
                "password": properties['password'],
                "currentSchema": properties['schema']
            }
            jdbc_url = f"jdbc:postgresql://{properties['hostname']}:{properties['port']}/{properties['database']}"

            self.logger.info(f"Creating DataFrame from PostgreSQL table: {table_name}")
            return self.spark.read.option("fetchsize", "100000").jdbc(url=jdbc_url, table=table_name, properties=db_properties)
        except Exception as e:
            self.logger.error(e)
            raise ConnectionError("No configuration found for PostgreSQL connection")

    def transform(self) -> list[T]:
        try:
            self.logger.info(f"Starting transformation for report type: {self.report_type}")
            data_objects = self._transform()
            final_objects = []
            if len(data_objects) == 0:
                final_objects.append(self._header(1))
                final_objects.append(DataObjectWrapper([], self.data_template_name()))

            else:
                page_size = self.output_configuration.page_size
                split_arrays = [data_objects[i:i + page_size] for i in range(0, len(data_objects), page_size)]
                index = 0
                for objects in split_arrays:
                    index = index + 1
                    final_objects.append(self._header(index))
                    final_objects.append(DataObjectWrapper(objects, objects[0].template_name()))

            final_objects.append(self._dynamic_trailer(data_objects))
            final_objects.append(self._trailer())
            self.logger.info(f"Transformation completed for report type: {self.report_type}")
            return final_objects
        except Exception as e:
            self.spark.catalog.clearCache()
            self.logger.error(f"Error during transformation: {e}")
            raise e

    @abstractmethod
    def _header(self, page: int) -> DataObject:
        pass

    @abstractmethod
    def _dynamic_trailer(self, records: list[DataObject]) -> DataObject:
        pass

    @abstractmethod
    def _trailer(self) -> DataObject:
        pass

    @abstractmethod
    def _transform(self) -> list[T]:
        pass

    @abstractmethod
    def identifier(self) -> str:
        pass

    @abstractmethod
    def data_template_name(self) -> str:
        pass


