from datetime import datetime
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_activity_data_object import RateChangeActivityDataObject
from src.report_generator.templates.data_objects.rate_change_activity_trailer_object import RateChangeActivityTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType

class ActivityReportTransformer(Transformer[RateChangeActivityDataObject]):
    def data_template_name(self) -> str:
        return "rate_change_activity_data.template"

    def __init__(self, transfor_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transfor_config, report_type, logger)

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at="00:00:00",
            report_number="BE208801US",
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name="ACTIVITY REPORT"
        )

    def _dynamic_trailer(self, records: list[RateChangeActivityDataObject]) -> DataObject:
        # Dummy aggregation for trailer
        enrolled = sum(int(r.enrolled) for r in records)
        changed_to_0 = sum(int(r.changed_to_0) for r in records)
        decreased = sum(int(r.decreased) for r in records)
        increased = sum(int(r.increased) for r in records)
        corrected = sum(int(r.corrected) for r in records)
        total = sum(int(r.total) for r in records)
        percent_grand_total = "100"
        return RateChangeActivityTrailerObject(
            enrolled_count=enrolled,
            change_to_0_count=changed_to_0,
            decreased_count=decreased,
            increased_count=increased,
            corrected_count=corrected,
            total=total,
            percent_grand_total=percent_grand_total
        )

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="00:00:00",
            report_number="BE208801US",
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[RateChangeActivityDataObject]:
        # Dummy data for demonstration
        dummy_data = [
            RateChangeActivityDataObject("US", "REG", "WAL-MART", "603", "177", "341", "471", "8", "1600"),
            RateChangeActivityDataObject("US", "CUC", "WAL-MART", "14", "4", "2", "2", "0", "22"),
            RateChangeActivityDataObject("PR", "REG", "WAL-MART", "8", "4", "5", "2", "0", "19"),
            RateChangeActivityDataObject("PR", "CUC", "WAL-MART", "0", "0", "0", "0", "0", "0"),
            RateChangeActivityDataObject("US", "REG", "MERRILL LYNCH", "0", "0", "0", "0", "0", "0"),
            RateChangeActivityDataObject("US", "CUC", "MERRILL LYNCH", "0", "0", "0", "0", "0", "0"),
            RateChangeActivityDataObject("PR", "REG", "MERRILL LYNCH", "0", "0", "0", "0", "0", "0"),
            RateChangeActivityDataObject("PR", "CUC", "MERRILL LYNCH", "0", "0", "0", "0", "0", "0"),
        ]
        return dummy_data

    def identifier(self) -> str:
        return "activity_report"

