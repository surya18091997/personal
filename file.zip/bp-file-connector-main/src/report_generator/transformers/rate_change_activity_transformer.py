from datetime import datetime, timedelta, time,timezone
from zoneinfo import ZoneInfo

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_activity_data_object import RateChangeActivityDataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType
from src.integrations.cosmos_utils import CosmosUtils
import pandas as pd


class RateChangeActivityTransformer(Transformer[RateChangeActivityDataObject]):
    """
    Transformer class for generating Rate Change Activity Reports.
    This report shows the counts of different types of rate changes 
    (enrolled, changed to 0, decreased, increased, corrected)
    grouped by country code, retirement plan type, and rate change source.
    """

    def data_template_name(self) -> str:
        return "rate_change_activity_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        """Initialize the transformer with configuration."""
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type
        self.report_id = "BE208801US"
        self.report_name = "401K DOWNLOAD ACTIVITY(DAILY)"

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[RateChangeActivityDataObject]) -> DataObject:
        return None

    def grand_total(self, records: list[RateChangeActivityDataObject]) -> DataObject:
        """Create a dynamic trailer with the grand total of all records."""
        if not records:
            return None
        
        # Calculate grand totals
        enrolled_total = 0
        changed_to_0_total = 0
        decreased_total = 0
        increased_total = 0
        corrected_total = 0
        grand_total = 0
        
        # Only consider regular data rows (not subtotal rows)
        for record in records:
            if record.country_code and record.retirement_plan_type:  # Skip subtotal rows
                try:
                    enrolled_total += int(record.enrolled)
                    changed_to_0_total += int(record.changed_to_0)
                    decreased_total += int(record.decreased)
                    increased_total += int(record.increased)
                    corrected_total += int(record.corrected)
                except (ValueError, TypeError):
                    self.logger.warning(f"Could not parse numeric value in record: {record.to_dict()}")
        
        # Calculate grand total
        grand_total = enrolled_total + changed_to_0_total + decreased_total + increased_total + corrected_total
        
        # Create the grand total row
        return RateChangeActivityDataObject(
            country_code="",
            retirement_plan_type="",
            rate_change_source="GRAND TOTAL",
            enrolled=enrolled_total,
            changed_to_0=changed_to_0_total,
            decreased=decreased_total,
            increased=increased_total,
            corrected=corrected_total,
            total=grand_total,
            total_percentage="100%"
        )

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            pay_period_date=formatted_date
        )

    def _transform(self) -> list[DataObject]:
        """
        Transform data for the Rate Change Activity report.
        
        Queries Cosmos DB for transaction logs and coverages data, then
        processes the data to count different types of rate changes.
        """
        self.logger.info(f"Starting transformation for Rate Change Activity Report")
        
        try:
            cst = ZoneInfo("America/Chicago")

            # Get yesterday's date range for filtering transaction logs
            yesterday = datetime.now(cst) - timedelta(days=1)

            start_date = datetime.combine(yesterday.date(),time(0, 45), tzinfo=cst).astimezone(timezone.utc)
            end_date = start_date+timedelta(days=1)


            # Define valid plan IDs
            valid_plan_ids = [
                'retirement_401k_regular_us',
                'retirement_401k_regular_pr',
                'retirement_401k_catchup_us',
                'retirement_401k_catchup_pr'
            ]
            
            # Query transaction logs for RATE_CHANGE activity within date range and valid plan IDs
            valid_plan_ids_str = ",".join([f"'{plan}'" for plan in valid_plan_ids])
            transaction_logs_query = {
                'where': f"c.activity = 'RATE_CHANGE' AND c.createdAt >= '{start_date:%Y-%m-%dT%H:%M:%S.%f}0Z' AND c.createdAt <= '{end_date:%Y-%m-%dT%H:%M:%S.%f}0Z' AND c.planId IN ({valid_plan_ids_str})",
                'project': "c.id, c.associateId, c.planId, c.createdBy, c.createdAt"
            }
            transaction_logs_query = f"SELECT {transaction_logs_query['project']} FROM c WHERE {transaction_logs_query['where']}"
            self.logger.info("Querying transaction logs for RATE_CHANGE activity")
            logs_df = self.cosmos_query(transaction_logs_query,"transaction-logs").toPandas()
            
            # Create empty results if no data
            if logs_df.empty:
                self.logger.info("No transaction logs found for the date range")
                # Return empty report structure with all groups having zero counts
                return self._create_empty_report_structure()

            
            # Keep only the most recent RATE_CHANGE activity for each associateId/planId combination
            if not logs_df.empty:
                logs_df['createdAt'] = pd.to_datetime(logs_df['createdAt'])
                # Sort by createdAt descending to get most recent first
                logs_df.sort_values(['associateId', 'planId', 'createdAt'], ascending=[True, True, False], inplace=True)
                # Keep only the first occurrence (most recent) for each associateId/planId combination
                logs_df = logs_df.drop_duplicates(subset=['associateId', 'planId'])
            
            # Extract associate IDs and plan IDs for coverage lookup
            if logs_df.empty:
                self.logger.info("No valid transaction logs after filtering")
                return self._create_empty_report_structure()
            
            associate_ids = list(logs_df['associateId'].unique())
            
            # Query coverages for these associates
            associate_list_str = ",".join([f"'{id}'" for id in associate_ids])
            plan_ids_str = ",".join([f"'{plan}'" for plan in valid_plan_ids])
            coverages_query_dict = {
                'where': f"c.associateId IN ({associate_list_str}) AND c.planId IN ({plan_ids_str})",
                'project': 'c.id, c.associateId, c.planId, c.version, c.contribution, c.isLatest'
            }
            coverages_query = f"SELECT {coverages_query_dict['project']} FROM c WHERE {coverages_query_dict['where']}"
            self.logger.info(f"Querying coverages for {len(associate_ids)} associates")
            coverages = self.cosmos_query(coverages_query,'coverages')
            
            # Convert to pandas DataFrame for easier analysis
            coverages_df = coverages.toPandas() if not coverages.isEmpty() else pd.DataFrame()
            
            # Skip processing if no coverages data
            if coverages_df.empty:
                self.logger.info("No coverages data found for processing")
                return self._create_empty_report_structure()
            
            # Extract country codes (US or PR) from planId
            logs_df['country_code'] = logs_df['planId'].apply(lambda x: 'PR' if '_pr' in x.lower() else 'US')
            
            # Extract retirement plan types (Regular or Catchup) from planId
            logs_df['retirement_plan_type'] = logs_df['planId'].apply(
                lambda x: 'REG' if 'regular' in x.lower() else 'CUC'
            )
            
            # Determine rate change source (WALMART or ML)
            logs_df['rate_change_source'] = logs_df['createdBy'].apply(
                lambda x: 'MERRILL LYNCH' if x == 'ML' else 'WAL-MART'
            )
            
            # Prepare coverages data
            coverages_df['contribution_value'] = coverages_df["contribution"].apply(lambda t: float(t[1]) if isinstance(t, tuple) else None).fillna(0.0)
            
            # Initialize results dictionary to store counts for each group
            results_dict = {}
            
            # Define all possible groups to ensure all are represented
            countries = ['US', 'PR']
            plan_types = ['REG', 'CUC']
            sources = ['WAL-MART', 'MERRILL LYNCH']
            
            # Initialize all possible groups with zero counts
            for country in countries:
                for plan_type in plan_types:
                    for source in sources:
                        results_dict[(country, plan_type, source)] = {
                            'enrolled': 0,
                            'changed_to_0': 0,
                            'decreased': 0,
                            'increased': 0,
                            'corrected': 0
                        }
            
            # Process each log entry
            for _, log in logs_df.iterrows():
                associate_id = log['associateId']
                plan_id = log['planId']
                country_code = log['country_code']
                plan_type = log['retirement_plan_type']
                source = log['rate_change_source']
                
                # Get all coverages for this associate and plan
                associate_coverages = coverages_df[
                    (coverages_df['associateId'] == associate_id) & 
                    (coverages_df['planId'] == plan_id)
                ].sort_values(by='version')
                
                if associate_coverages.empty:
                    continue
                
                # Get current coverage value
                latest_coverage = associate_coverages[associate_coverages['isLatest'] == True]
                if latest_coverage.empty:
                    continue
                
                latest_coverage = latest_coverage.iloc[0]
                latest_version = latest_coverage['version']
                latest_value = latest_coverage['contribution_value']
                
                # Get the group key
                group_key = (country_code, plan_type, source)
                
                # Categorize the change
                if latest_version == 1:
                    # Newly enrolled
                    results_dict[group_key]['enrolled'] += 1
                else:
                    # Get previous version
                    previous_coverages = associate_coverages[associate_coverages['version'] < latest_version]
                    if previous_coverages.empty:
                        continue
                    
                    previous_coverage = previous_coverages.iloc[-1]  # Get latest previous version
                    previous_value = previous_coverage['contribution_value']
                    
                    # Changed to 0%
                    if previous_value > 0 and latest_value == 0:
                        results_dict[group_key]['changed_to_0'] += 1
                    # Decreased
                    elif latest_value < previous_value:
                        results_dict[group_key]['decreased'] += 1
                    # Increased
                    elif latest_value > previous_value:
                        results_dict[group_key]['increased'] += 1
                    # Corrected (no change)
                    else:
                        results_dict[group_key]['corrected'] += 1
            
            # Convert results dictionary to data objects and calculate totals
            results = []
            
            # Calculate subtotals for each source
            walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
            merrill_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
            
            # Track grand total
            grand_total = 0
            
            # Generate results in specified order
            # Process WAL-MART entries
            walmart_total = self._process_source_data('WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results)
            grand_total = walmart_total
            
            # Process MERRILL LYNCH entries
            merrill_total = self._process_source_data('MERRILL LYNCH', countries, plan_types, results_dict, merrill_subtotal, results)
            grand_total += merrill_total
            
            # Add percentage to subtotals
            if grand_total > 0:
                # Update WAL-MART subtotal with percentage
                walmart_percentage = (walmart_total / grand_total) * 100
                results[4].total_percentage = f"{walmart_percentage:03.0f}%"
                
                # Update MERRILL LYNCH subtotal with percentage
                merrill_percentage = (merrill_total / grand_total) * 100
                results[-1].total_percentage = f"{merrill_percentage:03.0f}%"
            else:
                results[4].total_percentage = f"{0:03.0f}%"
                results[-1].total_percentage = f"{0:03.0f}%"

            self.logger.info(f"Completed transformation for Rate Change Activity Report with {len(results)} groups")
            results.append(self.grand_total(results))
            return results
            
        except Exception as e:
            self.logger.error(f"Error transforming data: {str(e)}")
            raise e

    def identifier(self) -> str:
        """Return a unique identifier for this transformer."""
        return "rate_change_activity"
    
    def _process_source_data(self, source: str, countries: list, plan_types: list, results_dict: dict, subtotal_dict: dict, results: list) -> int:
        """
        Process data for a given source (WAL-MART or MERRILL LYNCH) and append to results list.
        
        Args:
            source: The data source name ('WAL-MART' or 'MERRILL LYNCH')
            countries: List of countries to process
            plan_types: List of plan types to process
            results_dict: Dictionary containing the rate change data
            subtotal_dict: Dictionary to track subtotals for this source
            results: List to append results to
            
        Returns:
            The total count of all changes for this source
        """
        source_total = 0
        
        # Process entries for this source
        for country in countries:
            for plan_type in plan_types:
                group_key = (country, plan_type, source)
                if group_key in results_dict:
                    data = results_dict[group_key]
                    enrolled = data['enrolled']
                    changed_to_0 = data['changed_to_0']
                    decreased = data['decreased']
                    increased = data['increased']
                    corrected = data['corrected']
                    
                    # Update subtotals
                    subtotal_dict['enrolled'] += enrolled
                    subtotal_dict['changed_to_0'] += changed_to_0
                    subtotal_dict['decreased'] += decreased
                    subtotal_dict['increased'] += increased
                    subtotal_dict['corrected'] += corrected
                    
                    # Calculate total for this group
                    total = enrolled + changed_to_0 + decreased + increased + corrected
                    source_total += total
                    
                    # Create data object
                    results.append(RateChangeActivityDataObject(
                        country_code=country,
                        retirement_plan_type=plan_type,
                        rate_change_source=source,
                        enrolled=enrolled,
                        changed_to_0=changed_to_0,
                        decreased=decreased,
                        increased=increased,
                        corrected=corrected,
                        total=total
                    ))
                else:
                    # If no data for this group, add a zero row
                    results.append(RateChangeActivityDataObject(
                        country_code=country,
                        retirement_plan_type=plan_type,
                        rate_change_source=source,
                        enrolled=0,
                        changed_to_0=0,
                        decreased=0,
                        increased=0,
                        corrected=0,
                        total=0
                    ))
                    
        # Add subtotal row for this source
        results.append(RateChangeActivityDataObject(
            country_code="",
            retirement_plan_type="",
            rate_change_source=f"{source} SUBTOTAL",
            enrolled=subtotal_dict['enrolled'],
            changed_to_0=subtotal_dict['changed_to_0'],
            decreased=subtotal_dict['decreased'],
            increased=subtotal_dict['increased'],
            corrected=subtotal_dict['corrected'],
            total=source_total,
            total_percentage="000%"# Percentage will be updated later if grand_total > 0
        ))
        
        return source_total

    def _create_empty_report_structure(self) -> list[RateChangeActivityDataObject]:
        """Create an empty report structure with all groups having zero counts."""
        results = []
        
        # Define all possible groups
        countries = ['US', 'PR']
        plan_types = ['REG', 'CUC']
        
        # Empty results dictionary
        results_dict = {}
        
        # Create empty subtotals
        walmart_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        merrill_subtotal = {'enrolled': 0, 'changed_to_0': 0, 'decreased': 0, 'increased': 0, 'corrected': 0}
        
        # Process WAL-MART entries
        self._process_source_data('WAL-MART', countries, plan_types, results_dict, walmart_subtotal, results)
        
        # Process MERRILL LYNCH entries
        self._process_source_data('MERRILL LYNCH', countries, plan_types, results_dict, merrill_subtotal, results)
        
        return results
