from datetime import datetime

import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StringType, NullType, IntegerType, BooleanType, DateType, StructType

from src.report_generator import constants
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.loan_data_object import LoanDataObject
from src.report_generator.templates.data_objects.loan_trailer_object import LoanTrailerObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class LoanFileTransformer(Transformer[LoanDataObject]):

    def data_template_name(self) -> str:
        return "loan_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_US.txt_type_UHDR.csv',
                'main': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_US.txt_type_main.csv',
                'inbound': 'src/report_generator/output_temp/INBOUND_LOAN_FILE_US.txt_type_main.csv',
            },
            ReportType.PR: {
                'uhdr': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_PR.txt_type_UHDR.csv',
                'main': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_PR.txt_type_main.csv',
                'inbound': 'src/report_generator/output_temp/INBOUND_LOAN_FILE.txt_type_main.csv',
            },
            ReportType.WV: {
                'uhdr': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_WV.txt_type_UHDR.csv',
                'main': 'src/report_generator/output_temp/OUTBOUND_LOAN_FILE_WV.txt_type_main.csv',
            },
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = self.pay_end_date('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            page_no="{}".format(page),
            pay_period_date=formatted_date,
            report_name="401K LOANS OUTBOUND FILE(WEEKLY)"
        )

    def _dynamic_trailer(self, records: list[LoanDataObject]) -> DataObject:
        total = sum(int(item.loan_amount) for item in records)
        return LoanTrailerObject(len(records), total)

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[DataObject]:
        pay_end_date = self.pay_end_date("%Y-%m-%d")
        self.logger.info("Starting loan file transformation process")


        # Load outbound dataframe with minimal partitioning for single node
        outbound_df = self.spark.read \
            .option("delimiter", constants.DELIMITER) \
            .csv(self.configs[self.report_type]['main']).toDF("KEY", "PLAN_NUM", "SSN",
                                                              "LOAN_NUMBER", "FILLER_1",
                                                              "LOAN_AMOUNT", "FILLER_2",
                                                              "PAYROLL_IND",
                                                              "FILLER_3", "DEFAULT_COLUMN")

        # For single node, we want fewer but more efficient partitions
        outbound_df = outbound_df.repartition(8, "SSN").persist()
        self.logger.info("Outbound dataframe loaded and persisted")

        # Cache SSN values to avoid repeated collection
        ssn_values = outbound_df.select("SSN").rdd.flatMap(lambda x: x).collect()
        self.logger.info(f"SSN numbers collected for filtering db2 data: {len(ssn_values)}")
        # Load db2 dataframe - optimize for single node with fewer partitions
        db2_df = self.db2_frame("win_associate") \
                .select("NATIONAL_ID", "WIN_NBR", "COUNTRY_CODE") \
                .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
                .filter(F.col("COUNTRY_CODE").isin(["US"])) \
                .filter(F.col("NATIONAL_ID").isin(ssn_values)) \
                .cache()  # Use cache() for single node rather than persist()
        self.logger.info("DB2 dataframe loaded and filtered based on outbound_df['SSN']")

        # Always use broadcast join on single node for small to medium tables
        file_df = outbound_df.join(db2_df, outbound_df['SSN'] == db2_df["NATIONAL_ID"], "inner") \
                 .select(
                    outbound_df["SSN"],
                    outbound_df["LOAN_NUMBER"],
                    outbound_df["LOAN_AMOUNT"],
                    db2_df["WIN_NBR"]
                 ).cache()

        # Clean up intermediates to free memory on single node
        outbound_df.unpersist()
        db2_df.unpersist()
        self.logger.info("First join completed and intermediates cleaned")

        # Load cosmos data with minimal schema and processing for single node
        minimal_schema = StructType([
            StructField('associateId', StringType(), True),
            StructField('planId', StringType(), True),
            StructField('startDate', DateType(), True),
            StructField('loanId', StringType(), True),
            StructField('isLatest', BooleanType(), True),
        ])

        # Cache WIN_NBR values to avoid repeated collection
        win_nbr_values = file_df.select("WIN_NBR").rdd.flatMap(lambda x: x).collect()
        self.logger.info(f"Win numbers collected for filtering cosmos data: {len(win_nbr_values)}")
        # For single node, filter early to reduce data volume
        plans = [  "retirement_401k_loan_general_us",  "retirement_401k_loan_general_pr", "retirement_401k_loan_residential_pr", "retirement_401k_loan_residential_us"]
        cosmos_df = self.cosmos_dataframe('coverages') \
                .load(schema=minimal_schema) \
                .filter(F.col("planId").isin(plans)) \
                .filter(F.col("isLatest") == True) \
                .filter(F.col("associateId").isin(win_nbr_values)) \
                .select("associateId", "planId", "startDate", "loanId") \
                .cache()

        self.logger.info("Cosmos dataframe loaded and cached")

        # Set up the join conditions
        join_condition = (file_df['WIN_NBR'] == cosmos_df["associateId"]) & (file_df['LOAN_NUMBER'] == cosmos_df["loanId"])

        # Apply the join - for single node, we don't need complex strategies
        result_df = file_df.join(cosmos_df, join_condition, "inner") \
                   .select(file_df["SSN"], file_df["LOAN_NUMBER"], file_df["LOAN_AMOUNT"],
                           file_df["WIN_NBR"], cosmos_df["startDate"])

        # Collect data without additional repartitioning for single node
        self.logger.info("Processing final results")
        loans = result_df.rdd.map(lambda row: create_loan_object(row, pay_end_date)).collect()

        # Clean up to free memory
        file_df.unpersist()
        cosmos_df.unpersist()
        self.logger.info(f"Loan transformation completed, returning {len(loans)} records")
        return loans

    def pay_end_date(self, date_format) -> str:
        with open(self.configs[self.report_type]['uhdr'], 'r') as file:
            rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                               delimiter=constants.DELIMITER,
                               names=["FILLER", "PAY_END_DATE", "FILLE_2", "FILLER_3"]).values.tolist()
            gregorian_date = ""
            for row in rows:
                julian_date = '{}'.format(row[1])
                dt = datetime.strptime(julian_date, '%Y%j')
                gregorian_date = dt.strftime(date_format)
                break
            return gregorian_date


    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for loan file transformation
        """
        return "loan"
def create_loan_object(row, formatted_date: str) -> LoanDataObject:
    from datetime import datetime, timedelta
    dt = datetime.strptime(formatted_date, "%Y-%m-%d")
    adjusted_date = (dt - timedelta(days=2)).strftime("%Y-%m-%d")
    return LoanDataObject(
        win=row['WIN_NBR'],
        ssn=row['SSN'],
        loan_number=row['LOAN_NUMBER'],
        loan_amount=str(row['LOAN_AMOUNT']).zfill(11),
        pay_end_date=adjusted_date,
        loan_cr_date=row['startDate'].strftime("%Y-%m-%d")
    )



