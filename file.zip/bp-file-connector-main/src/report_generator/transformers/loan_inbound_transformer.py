from datetime import datetime

import pandas as pd
# from pyspark.shell import spark
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StringType, StructType

from src.report_generator import constants
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
# from src.report_generator.templates.data_objects.loan_data_object import LoanDataObject
from src.report_generator.templates.data_objects.loan_inbound_data_object import LoanInboundDataObject
from src.report_generator.templates.data_objects.loan_inbound_trailer_object import LoanInboundTrailerObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class LoaninFileTransformer(Transformer[LoanInboundDataObject]):

    def data_template_name(self) -> str:
        return "loan_inbound_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr': 'src/report_generator/output_temp/INBOUND_LOAN_FILE_US.txt_type_UHDR.csv',
                'main': 'src/report_generator/output_temp/INBOUND_LOAN_FILE_US.txt_type_main.csv',
                'country_code': 'US',
            },
            ReportType.PR: {
                 'uhdr': 'src/report_generator/output_temp/INBOUND_LOAN_FILE_PR.txt_type_UHDR.csv',
                 'main': 'src/report_generator/output_temp/INBOUND_LOAN_FILE_PR.txt_type_main.csv',
                'country_code': 'PR',
            },
        }

    def _header(self, page: int) -> DataObject:
        # Use 'mm/dd/yy' format for the header record
        formatted_date = self.pay_end_date('%m/%d/%y')
        print('formatted date', formatted_date)
        return HeaderObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            page_no="{}".format(page),
            pay_period_date=formatted_date,
            report_name="401K LOANS INBOUND FILE(WEEKLY)"
        )

    def _dynamic_trailer(self, records: list[LoanInboundDataObject]) -> DataObject:
         total_deducted_amount = int(sum(float(item.deducted_amount) for item in records if  item.deducted_amount is not None))
         total_goal_amount = int(sum(float(item.goal_amount) for item in records if item.goal_amount is not None))
         return LoanInboundTrailerObject(len(records), total_deducted_amount,total_goal_amount)

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[DataObject]:
        # Derive the pay_end_date in 'YYYY-MM-DD' format before the cosmos call
        pay_end_date = self.pay_end_date('%Y-%m-%d')
        self.logger.info(f"Derived pay_end_date for cosmos call: {pay_end_date}")

        # Process data into a list for conversion to Spark DataFrame
        inbound_df = self.spark.read \
            .option("delimiter", constants.DELIMITER) \
            .csv(self.configs[self.report_type]['main']).toDF("SSN", "WIN",
            "LOAN_NUMBER", "FILLER_0",
            "DEDUCTED_AMOUNT", "FILLER_1",
            "LOAN_TYPE","PAYROLL_ID","GOAL_AMOUNT",
            "PAYROLL_FREQUENCY","FILLER_2","STORE_LOCATION_CODE",
            "COUNTRY_CODE","DEFAULT_COLUMN")
        inbound_df.show()

        # Load cosmos data with minimal schema and processing for single node
        minimal_schema = StructType([
            StructField('associateId', StringType(), True),
            StructField('planId', StringType(), True),
            StructField('startDate', StringType(), True),  # Changed from DateType to StringType
            StructField('loanSequenceNumber', StringType(), True),
            StructField('isLatest', StringType(), True) # Changed from DateType to StringType
        ])

        # Extract WIN values from results_df
        win_nbr_values = inbound_df.select('WIN').rdd.flatMap(lambda x: x).collect()
        self.logger.info(f"Win numbers collected for filtering cosmos data: {len(win_nbr_values)}")

        # For single node, filter early to reduce data volume
        plans = ["retirement_401k_loan_general_us", "retirement_401k_loan_general_pr",
                 "retirement_401k_loan_residential_pr", "retirement_401k_loan_residential_us"]

        # Log intermediate values for debugging
        self.logger.info(f"Plans: {plans}")
        self.logger.info(f"WIN numbers: {win_nbr_values}")
        self.logger.info(f"Pay end date: {pay_end_date}")

        formatted_ids = "(" + ",".join(f"'{id}'" for id in win_nbr_values) + ")" if win_nbr_values else "(NULL)"
        coverages_query = f"""
                SELECT * 
                FROM c 
                WHERE c.associateId IN {formatted_ids}
                """


    # Apply filters step by step for debugging
        cosmos_df = self.cosmos_query(coverages_query, "coverages") \
            .filter(F.col("planId").isin(plans)) \
            .filter(F.col("associateId").isin(win_nbr_values)) \
            .filter(F.col("isLatest") == True) \
            .filter(F.to_date(F.col("startDate")) == F.to_date(F.lit(pay_end_date))) \
            .select("associateId", "planId", "startDate", "loanSequenceNumber") \
            .cache()

        self.logger.info("Cosmos dataframe loaded and cached")
        # Set up the join conditions
        join_condition = (inbound_df['WIN'] == cosmos_df["associateId"]) & (
                    inbound_df['LOAN_NUMBER'] == cosmos_df["loanSequenceNumber"])

        # Select only existing columns from file_df (loan_amount was missing)
        result_df = inbound_df.join(cosmos_df, join_condition, "inner") \
            .select(inbound_df["WIN"], inbound_df["LOAN_NUMBER"], inbound_df["DEDUCTED_AMOUNT"],
                    inbound_df["PAYROLL_ID"], inbound_df["GOAL_AMOUNT"], inbound_df["PAYROLL_FREQUENCY"],
                    inbound_df["STORE_LOCATION_CODE"], inbound_df["LOAN_TYPE"], inbound_df["COUNTRY_CODE"])

        # Collect data without additional repartitioning for single node
        self.logger.info("Processing final results")
        country_code = self.configs[self.report_type]['country_code']
        # Convert result to list of LoanInboundDataObject objects
        loans = result_df.rdd.map(lambda row: create_loan_inbound_object(row,country_code)).collect()

        # Clean up to free memory
        inbound_df.unpersist()
        cosmos_df.unpersist()
        self.logger.info(f"Loan transformation completed, returning {len(loans)} records")
        return loans

    def pay_end_date(self, date_format='%Y-%m-%d') -> str:
        try:
            # Read the UHDR file using the corrected column specifications
            uhdr_file_path = self.configs[self.report_type]['uhdr']
            column_specs = [(0, 6), (6, 146)]  # Corrected column positions based on actual file structure
            column_names = ["LOAN-IN-DATE", "LOAN-DETAIL-0"]

            uhdr_data = pd.read_fwf(uhdr_file_path, colspecs=column_specs, names=column_names)



            # Ensure the file contains valid data
            if uhdr_data.empty or "LOAN-IN-DATE" not in uhdr_data.columns:
                self.logger.error("UHDR file is empty or does not contain the expected LOAN-IN-DATE column.")
                return ""

            # Extract the first record (LOAN-IN-DATE)
            loan_in_date_raw = str(uhdr_data.iloc[0, 0]).strip()

            # Validate the extracted date
            if not loan_in_date_raw.isdigit() or len(loan_in_date_raw) != 6:
                self.logger.error(f"Invalid LOAN-IN-DATE value: {loan_in_date_raw}")
                return ""

            # Convert the extracted date to the desired format
            formatted_date = datetime.strptime(loan_in_date_raw, '%y%m%d').strftime(date_format)

            self.logger.info(f"Formatted pay end date: {formatted_date}\n")
            return formatted_date
        except Exception as e:
            self.logger.error(f"Error while processing UHDR file: {e}\n")
            return ""

    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for loan file transformation
        """
        return "loanin"

def create_loan_inbound_object(row, country_code):
    return LoanInboundDataObject(
        win=row['WIN'],
        loan_number=row['LOAN_NUMBER'],
        deducted_amount=row['DEDUCTED_AMOUNT'],
        loan_type=row['LOAN_TYPE'],
        payroll_id=row['PAYROLL_ID'] if row['PAYROLL_ID'] else ' ',
        goal_amount=row['GOAL_AMOUNT'] if row['GOAL_AMOUNT'] else '0',
        pay_frequency=row['PAYROLL_FREQUENCY'] if row['PAYROLL_FREQUENCY'] else ' ',
        store_location_code=row['STORE_LOCATION_CODE'],
        country_code= country_code
    )

def default_if_nan(value, default):
    return default if pd.isna(value) else value
