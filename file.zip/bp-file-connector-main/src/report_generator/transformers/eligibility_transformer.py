from datetime import datetime

import pandas as pd
from pyspark.sql import functions as F

from src.report_generator import constants, flat_file_writer, report_utils, report_constants
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.eligibility_data_object import EligibilityDataObject
from src.report_generator.templates.data_objects.eligibility_trailer_object import EligibilityTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class EligibilityFileTransformer(Transformer[EligibilityDataObject]):

    def data_template_name(self) -> str:
        return "eligibility_data.template"

    def __init__(self, transfor_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transfor_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr'  : 'src/report_generator/output_temp/OUTGOING_US_ELIGIBILITY_FILE.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTGOING_US_ELIGIBILITY_FILE.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_US_ELIGIBILITY_FILE.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_US_ELIGIBILITY_FILE.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTGOING_US_ELIGIBILITY_FILE.txt_type_62.csv',
            },
            ReportType.PR: {
                'uhdr'  : 'src/report_generator/output_temp/OUTGOING_PR_ELIGIBILITY_FILE.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTGOING_PR_ELIGIBILITY_FILE.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_PR_ELIGIBILITY_FILE.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_PR_ELIGIBILITY_FILE.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTGOING_PR_ELIGIBILITY_FILE.txt_type_62.csv',
            },
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = self.pay_end_date('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            page_no="{}".format(page),
            pay_period_date=formatted_date,
            report_name="ELIGIBILITY FILE BEING SENT TO MERRILL."
        )

    def _dynamic_trailer(self, records: list[EligibilityDataObject]) -> DataObject:
        return EligibilityTrailerObject(len(records))

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date
        )

    def _transform(self) -> list[DataObject]:
        # Define all column names for record type 01 based on the layout

        # Verify we have 68 columns
        print(f"Number of columns defined: {len(report_constants.TYPE01_COLUMNS)}")

        type01_df = pd.read_csv(self.configs[self.report_type]["type01"],
                                delimiter=constants.DELIMITER,names=report_constants.TYPE01_COLUMNS).values.tolist()
        type02_df = pd.read_csv(self.configs[self.report_type]["type02"],
                                delimiter=constants.DELIMITER,names=report_constants.TYPE02_COLUMNS).values.tolist()
        type05_df = pd.read_csv(self.configs[self.report_type]["type05"],
                                delimiter=constants.DELIMITER, names=report_constants.TYPE05_COLUMNS).values.tolist()
        type62_df = pd.read_csv(self.configs[self.report_type]["type62"],
                                delimiter=constants.DELIMITER, names=report_constants.TYPE62_COLUMNS).values.tolist()

        win_nbr_values = [row[7] for row in type01_df]  # Extract the 7th index column (R01_EMPLOYEE_NUMBER)
        db2_df = self.db2_frame("win_associate") \
            .select("NATIONAL_ID", "WIN_NBR", "COUNTRY_CODE", "FIRST_NAME", "LAST_NAME") \
            .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
            .filter(F.col("COUNTRY_CODE").isin(["US"])) \
            .filter(F.col("WIN_NBR").isin(win_nbr_values)) \
            .cache()  # Use cache() for single node rather than p
        results = []
        for index, value in enumerate(type01_df):
            type1 = type01_df[index]
            type2 = type02_df[index]
            type5 = type05_df[index]
            type62 = type62_df[index]
            # Convert eligibility hours from string to decimal
            eligibility_hours = report_utils.convert_digits_to_decimal(report_utils.reverse_integer_lastbyte_conversion(type5[3]))
            # Convert to float before dividing to avoid type error
            eligibility_hours_corrected = float(eligibility_hours) / 10 if eligibility_hours else 0
            if eligibility_hours_corrected == 0:
                formatted_hours = "0.00"
            else:
                formatted_hours = f"{eligibility_hours_corrected:,.2f}"

            results.append({
                'win': value[7],
                'ssn': type1[1],
                'first_name': type1[9],
                'last_name': type1[8],
                'address': type2[3],
                'city': type2[8],
                'state': type2[9],
                'zip': type2[10],
                'store_number': type62[3],
                'hire_date': "{}{}-{}-{}".format(type1[17], flat_file_writer.pad_pre(type1[18], '0', 2),
                                                 flat_file_writer.pad_pre(type1[15], '0', 2),
                                                 flat_file_writer.pad_pre(type1[16], '0', 2)),
                'birth_date': "{}{}-{}-{}".format(type1[13], flat_file_writer.pad_pre(type1[14], '0', 2),
                                                  flat_file_writer.pad_pre(type1[11], '0', 2),
                                                  flat_file_writer.pad_pre(type1[12], '0', 2)),
                're_hire_date': '',
                'term_date': '',
                'term_payout_date': '',
                'eligible_hours': formatted_hours,
                'years_of_service': report_utils.reverse_integer_lastbyte_conversion(type5[5])
            })

        # Convert results to Spark DataFrame for join
        results_df = self.spark.createDataFrame(results)
        # Join on win/results_df['win'] == db2_df['WIN_NBR']
        joined_df = results_df.join(db2_df, results_df.win == db2_df.WIN_NBR, 'left')
        # Iterate joined_df, call create_eligibility_object, assign to results
        joined_rows = joined_df.collect()
        results = [create_eligibility_object(row.asDict()) for row in joined_rows]
        return results

    def pay_end_date(self,date_format) -> str:
        rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                    delimiter=constants.DELIMITER, names=["FILLER", "PAY_END_DATE", "FILLE_2", "FILLER_3"]).values.tolist()
        gregorian_date = ""
        for row in rows:
            julian_date = str(row[1])
            dt = datetime.strptime(julian_date, '%Y%j')
            gregorian_date = dt.strftime(date_format)
            break
        return gregorian_date

    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for eligibility file transformation
        """
        return "eligibility"

def create_eligibility_object(row):
    return EligibilityDataObject(
        win=row['win'],
        ssn=row['ssn'],
        first_name=row['FIRST_NAME'],
        last_name=row['LAST_NAME'],
        address=row['address'],
        city=row['city'],
        state=row['state'],
        zip=row['zip'],
        store_number=row['store_number'],
        hire_date=row['hire_date'],
        birth_date=row['birth_date'],
        re_hire_date=row['re_hire_date'],
        term_date=row['term_date'],
        term_payout_date=row['term_payout_date'],
        eligible_hours=row['eligible_hours'],
        years_of_service=row['years_of_service']
    )

