from datetime import datetime
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.term_over_65_data_object import TermOver65DataObject
from src.report_generator.templates.data_objects.term_over_65_trailer_object import TermOver65TrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType


class TermOver65Transformer(Transformer[TermOver65DataObject]):
    print('Termed over 65 transformer initialized')
    def data_template_name(self) -> str:
        return "term_over_65_data.template"
    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        # Single report ID and name regardless of report type
        self.report_id = "PS112101US"
        self.report_name = "ASSOCIATES TERMINATED AND OVER THE AGE 70 REPORT"

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[TermOver65DataObject]) -> DataObject:
        # Return a trailer with the count of records
        return TermOver65TrailerObject(
            total_assocs=len(records)
        )

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        return None

    def _transform(self) -> list[TermOver65DataObject]:
        """
        Transform data for Terminated Associates Over 70 reports.

        In a real implementation, this would fetch data from a database or other source.
        For now, we'll use sample data similar to the report examples.
        """
        # Combine all terminated associates over 65, regardless of country
        records = [
            TermOver65DataObject(
                hce="0",
                ssn="00999999",
                first_name="XNY",
                last_name="DEMO",
                state_cd="TV",
                zip_cd="75678",
                wrk_div_number="1",
                wrk_store_number="05210",
                employee_status="T",
                eligible_date="2016-04-22",
                hire_date="2016-04-22",
                birth_date="1950-02-26",
                calculated_age="75",
                effective_date="2025-05-30",
                termination_date="2025-05-29",
                payout_date="2025-06-29",
                eligible_hours="504.97",
                years_eligible="8"
            ),
            TermOver65DataObject(
                hce="0",
                ssn="555555555",
                first_name="YYY",
                last_name="HHHHHH",
                state_cd="ME",
                zip_cd="04240",
                wrk_div_number="1",
                wrk_store_number="01868",
                employee_status="T",
                eligible_date="2022-07-27",
                hire_date="2022-07-27",
                birth_date="1953-06-12",
                calculated_age="71",
                effective_date="2025-05-27",
                termination_date="2025-05-26",
                payout_date="2025-06-26",
                eligible_hours="694.06",
                years_eligible="2"
            )

        ]

        return records

    def identifier(self) -> str:
        # Return the identifier for this transformer
        return "term_over_65"
