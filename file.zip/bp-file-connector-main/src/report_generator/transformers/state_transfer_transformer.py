from datetime import datetime
import math
from pyspark.sql import functions as F

import pandas as pd
from pyspark.sql.types import StructField, StringType, StructType, ArrayType

from src.report_generator import constants, flat_file_writer, report_utils
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.eligibility_data_object import EligibilityDataObject
from src.report_generator.templates.data_objects.eligibility_trailer_object import EligibilityTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.state_transfer_data_object import StateTransferDataObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class StateTransferTransformer(Transformer[StateTransferDataObject]):

    def data_template_name(self) -> str:
        return "state_transfer_data.template"
    def __init__(self, transfor_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transfor_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr'  : 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_62.csv',
                'plans': ['retirement_401k_regular_us','retirement_401k_catchup_regular_us','retirement_401k_roth_us','retirement_401k_catchup_roth_us']
            },
            ReportType.PR: {
                'uhdr'  : 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_62.csv',
                'plans': ['retirement_401k_regular_pr', 'retirement_401k_catchup_regular_pr']
            },
        }

    def _header(self, page: int) -> DataObject:
            formatted_date = self.pay_end_date('%m/%d/%y')
            return HeaderObject(
                run_on=formatted_date,
                run_at="10:00:00",
                report_number=self.output_configuration.report_id,
                page_no="{}".format(page),
                pay_period_date=formatted_date,
                report_name= 'ASSOCIATES TRANSFERRED TO {}'.format(self.report_type.name)
            )

    def _dynamic_trailer(self, records: list[EligibilityDataObject]) -> DataObject:
        return EligibilityTrailerObject(len(records))

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[DataObject]:
        # Define all column names for record type 01 based on the layout
        type01_columns = [
            "R01_PLAN_NUMBER",
            "R01_PART_NUMBER",
            "R01_ACTION",
            "R01_STAT_CODE",
            "FILLER",
            "R01_SAVINGS_RATES_INCLUDED",
            "R01_FILLER_1",
            "R01_EMPLOYEE_NUMBER",
            "R01_LAST_NAME",
            "R01_FIRST_NAME",
            "R01_FULL_NAME",
            "R01_BDAY_MM",
            "R01_BDAY_DD",
            "R01_BDAY_CC",
            "R01_BDAY_YY",
            "R01_HDAY_MM",
            "R01_HDAY_DD",
            "R01_HDAY_CC",
            "R01_HDAY_YY",
            "R01_PEDAY_MM",
            "R01_PEDAY_DD",
            "R01_PEDAY_CC",
            "R01_PEDAY_YY",
            "R01_SEX",
            "R01_MARITAL_STATUS",
            "R01_FILLER_2",
            "R01_UDF_1",
            "R01_UDF_2",
            "R01_UDF_3",
            "R01_UDF_4",
            "R01_UDF_5",
            "R01_VDAY_MM",
            "R01_VDAY_DD",
            "R01_VDAY_CC",
            "R01_VDAY_YY",
            "R01_TDAY_MM",
            "R01_TDAY_DD",
            "R01_TDAY_CC",
            "R01_TDAY_YY",
            "R01_ADAY_MM",
            "R01_ADAY_DD",
            "R01_ADAY_CC",
            "R01_ADAY_YY",
            "R01_ELIGIBILITY_FLAG",
            "R01_BENEFIT_RATE",
            "R01_HCE_INDICATOR",
            "R01_EMPLOYEE_TYPE",
            "R01_PAYROLL_CODE",
            "R01_PAYROLL_ID",
            "R01_ELECT_BT_SAVE_RATE",
            "R01_ELECT_AT_SAVE_RATE",
            "R01_FILLER_3",
            "R01_SECTION_16_IND",
            "R01_FILLER_4",
            "R01_AFR_IND",
            "R01_ELIGIBILITY_DATE",
            "R01_FILLER_5",
            "R01_ELECT_BT_FLAT_SAVE_RATE",
            "R01_ELECT_AT_FLAT_SAVE_RATE",
            "R01_ELECT_BT_CUC_SAVE_RATE",
            "R01_REHIRE_CREDIT_IND",
            "R01_FILLER_6",
            "R01_RDAY_MM",
            "R01_RDAY_DD",
            "R01_RDAY_CC",
            "R01_RDAY_YY",
            "R01_END_FILLER"
        ]
        type02_columns = [
            "R02_PLAN_NUMBER",
            "R02_PART_NUMBER",
            "R02_OPT_IN_OUT_FLAG",
            "R02_STREET_ADDRESS_L1",
            "R02_STREET_ADDRESS_L2",
            "R02_FILLER_2",
            "R02_EMAIL_TYPE",
            "R02_FILLER_3",
            "R02_CITY",
            "R02_STATE",
            "R02_ZIP",
            "R02_FILLER_3_DUP",
            "R02_ALTERNATE_STATE",
            "R02_PR_BONAFIDE_IND",
            "R02_FILLER_4",
            "R02_EMAIL_ADDRESS",
            "R02_FILLER_5",
            "R02_FILLER_6"
        ]
        type05_columns = [
            "R02_PLAN_NUMBER",
            "R02_PART_NUMBER",
            "FILLER",
            "HOURS",
            "FILLER1",
            "YOS",
            "FILLER2",
            "DEFAULT_COLUMN"
        ]
        type62_columns = [
            "PLAN_NUMBER",
            "PARTICIPANT_NUMBER",
            "FILLER0",
            "WORK_LOCATION",
            "WORK_DIVISION",
            "CHARGE_LOCATION",
            "CHARGE_DIVISION",
            "PAY_CODE",
            "FILLER1",
            "ACTUAL_TERM_DATE",
            "FILLER3",
            "DEFAULT_COLUMN",
        ]

        # Verify we have 68 columns
        print(f"Number of columns defined: {len(type01_columns)}")

        type01_df = pd.read_csv(self.configs[self.report_type]["type01"],
                                delimiter=constants.DELIMITER,names=type01_columns).values.tolist()
        type02_df = pd.read_csv(self.configs[self.report_type]["type02"],
                                delimiter=constants.DELIMITER,names=type02_columns).values.tolist()
        type05_df = pd.read_csv(self.configs[self.report_type]["type05"],
                                delimiter=constants.DELIMITER, names=type05_columns).values.tolist()
        type62_df = pd.read_csv(self.configs[self.report_type]["type62"],
                                delimiter=constants.DELIMITER, names=type62_columns).values.tolist()
        win_nbr_values = [row[7] for row in type01_df]  # Extract the 7th index column (R01_EMPLOYEE_NUMBER)
        db2_df = self.db2_frame("win_associate") \
            .select("NATIONAL_ID", "WIN_NBR", "COUNTRY_CODE", "FIRST_NAME", "LAST_NAME","TERMINATION_DATE") \
            .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
            .filter(F.col("COUNTRY_CODE").isin(["US"])) \
            .filter(F.col("WIN_NBR").isin(win_nbr_values)) \
            .cache()  # Use cache() for single node rather than p

        payout_date_df = self.db2_frame("assoc_rtrmt_payout") \
            .select("WIN_NBR", "PAYOUT_DATE", "MULTI_ACCT_CODE") \
            .withColumn("EFF_DATE", F.date_add(F.to_date(F.col("PAYOUT_DATE")),-30)) \
            .filter(F.col("WIN_NBR").isin(win_nbr_values)) \
            .filter(F.col("MULTI_ACCT_CODE").isin(["0"])) \
            .orderBy(F.col("PAYOUT_DATE").desc()) \
            .groupBy("WIN_NBR") \
            .agg(
                F.first("PAYOUT_DATE").alias("PAYOUT_DATE"),
                F.first("EFF_DATE").alias("EFF_DATE"),
                F.first("MULTI_ACCT_CODE").alias("MULTI_ACCT_CODE")
            ) \
            .cache()  # Use cache() for single node rather than p

        payout_date_df.show()
        # Load cosmos data with minimal schema and processing for single node
        minimal_schema = StructType([
            StructField('associateId', StringType(), True),
            StructField('eligibility', StructType([
                StructField('plans', ArrayType(StructType([
                    StructField('planId', StringType(), True),
                    StructField('planGroup', StringType(), True),
                    StructField('originalHireDate', StringType(), True)
                ])), True)
            ]), True)
        ])
        plans = self.configs[self.report_type]['plans']

        # Query cosmos DB with the minimal schema
        cosmos_df = self.cosmos_dataframe('associate-benefit-profile') \
            .load(schema=minimal_schema) \
            .filter(F.col("associateId").isin(win_nbr_values)) \
            .withColumn("plan_data", F.explode_outer("eligibility.plans")) \
            .filter(F.col("plan_data.planId").isin(plans)) \
            .orderBy(F.col("plan_data.originalHireDate").desc()) \
            .groupBy("associateId", "plan_data.planGroup") \
            .agg(
                F.first("plan_data.originalHireDate").alias("originalHireDate"),
            ) \
            .cache()
        cosmos_df.show()
        result = []
        for index, value in enumerate(type01_df):
            type1 = type01_df[index]
            type2 = type02_df[index]
            type5 = type05_df[index]
            type62 = type62_df[index]
            eligibility_hours = report_utils.convert_digits_to_decimal(report_utils.reverse_integer_lastbyte_conversion(type5[3]))
            # Convert to float before dividing to avoid type error
            eligibility_hours_corrected = float(eligibility_hours) / 10 if eligibility_hours else 0
            if eligibility_hours_corrected == 0:
                formatted_hours = "0.00"
            else:
                formatted_hours = f"{eligibility_hours_corrected:,.2f}"
            result.append({
                'win': value[7],
                'ssn': type1[1],
                'first_name': type1[9],
                'last_name': type1[8],
                'address': type2[3],
                'city': type2[8],
                'state': type2[9],
                'zip': type2[10],
                'work_division': type62[4],
                'store_number': type62[3],
                'hire_date': "{}{}-{}-{}".format(type1[17], flat_file_writer.pad_pre(type1[18], '0', 2),
                                                 flat_file_writer.pad_pre(type1[15], '0', 2),
                                                 flat_file_writer.pad_pre(type1[16], '0', 2)),
                'birth_date': "{}{}-{}-{}".format(type1[13], flat_file_writer.pad_pre(type1[14], '0', 2),
                                                  flat_file_writer.pad_pre(type1[11], '0', 2),
                                                  flat_file_writer.pad_pre(type1[12], '0', 2)),
                're_hire_date': '',
                'term_date': '',
                'term_payout_date': '',
                'eligible_hours': formatted_hours,
                'years_of_service': report_utils.reverse_integer_lastbyte_conversion(type5[5])

            })
        results_df = self.spark.createDataFrame(result)

        # Join with DB2 data
        joined_df = results_df.join(db2_df, results_df.win == db2_df.WIN_NBR, 'inner')

        # Join with Cosmos data to get originalHireDate
        final_df = joined_df.join(
            cosmos_df,
            joined_df.win == cosmos_df.associateId,
            'inner'  # Use left join to keep all records even if they don't have cosmos data
        ).select(
            joined_df["*"],  # Keep all columns from the joined_df
            cosmos_df.originalHireDate.alias("cosmos_original_hire_date")  # Add the originalHireDate column
        )

        final_df = final_df.join(payout_date_df, final_df.win == payout_date_df['WIN_NBR'], "left")
        # Convert the dataframe to a list of dictionaries for further processing
        final_result = [row.asDict() for row in final_df.collect()]
        self.logger.info(f"Total result values: {len(final_result)}")
        # Create data objects from the final result
        return [create_eligibility_object(row) for row in final_result]


    def pay_end_date(self,date_format) -> str:
        rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                    delimiter=constants.DELIMITER, names=["FILLER", "PAY_END_DATE", "FILLE_2", "FILLER_3"]).values.tolist()
        gregorian_date = ""
        for row in rows:
            julian_date = str(row[1])
            dt = datetime.strptime(julian_date, '%Y%j')
            gregorian_date = dt.strftime(date_format)
            break
        return gregorian_date

    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for state transfer file transformation
        """
        return "state_transfer"

def create_eligibility_object(row):
    # Handle termination date - check for both None and NaN values
    term_date = row.get('TERMINATION_DATE', None)
    if term_date is None or (isinstance(term_date, float) and math.isnan(term_date)):
        term_date = ''

    return StateTransferDataObject(
        win=row['win'],
        ssn=row['ssn'],
        first_name=row['FIRST_NAME'],
        last_name=row['LAST_NAME'],
        address=row['address'],
        city=row['city'],
        state=row['state'],
        zip=row['zip'],
        work_division=row['work_division'],
        store_number=row['store_number'],
        hire_date=row['cosmos_original_hire_date'],
        birth_date=row['birth_date'],
        eff_date=row['EFF_DATE'] if row['EFF_DATE'] else " ",
        term_date=term_date,
        term_payout_date=row['PAYOUT_DATE'] if row['PAYOUT_DATE'] else " ",
        eligible_hours=row['eligible_hours'],
        years_of_service=row['years_of_service']
    )
