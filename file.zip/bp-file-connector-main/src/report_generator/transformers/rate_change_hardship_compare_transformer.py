from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.functions import col

from src.report_generator import constants, report_constants
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_compare_data_object import RateChangeCompareDataObject
from src.report_generator.templates.data_objects.rate_change_compare_trailer_object import RateChangeCompareTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType


class RateChangeHardshipCompareTransformer(Transformer[RateChangeCompareDataObject]):
    def data_template_name(self) -> str:
        return "rate_change_compare_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'type10': 'src/report_generator/output_temp/ML_HARDSHIP_INBOUND_FILE.txt_type_10.csv',
            },
            ReportType.PR: {
                'type10': 'src/report_generator/output_temp/ML_HARDSHIP_INBOUND_FILE_PR.txt_type_10.csv',
            }
        }
        self.report_type = report_type
        # Define report IDs and names based on report type
        if report_type == ReportType.US:
            self.report_id = "BE209201US"
            self.report_name = "ASSOCIATES RATE CHANGE REPORT LAYOUT"
        if report_type == ReportType.PR:
            self.report_id = "BE209201PR"
            self.report_name = "ASSOCIATES RATE CHANGE REPORT LAYOUT"

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[RateChangeCompareDataObject]) -> DataObject:
        # Return a trailer with the count of records
        return RateChangeCompareTrailerObject(total_nbr_of_assocs=len(records))

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date
        )

    def _transform(self) -> list[RateChangeCompareDataObject]:
        """
        Transform data for Rate Change Compare reports.

        In a real implementation, this would fetch data from a database or other source.
        For now, we'll use sample data similar to the report examples.
        """

        def check_records(records, existing_wins, existing_wins_string ):
            if len(records) > 0:
                values = [row['associateId'] for row in records if row['associateId'] not in existing_wins]
                values_string = ', '.join(
                    f"'{value}'" for value in values)

                return values, values_string

            print('record count :', 0)
            return records, existing_wins_string


        type10_df = self.spark.read.format('csv') \
            .option("delimiter", constants.DELIMITER) \
            .option('header', False) \
            .load(self.configs[self.report_type]["type10"])

        type10_df = type10_df.toDF(*report_constants.TYPE10_COLUMNS)

        existing_wins = [row['MER_EMPL_NUM'] for row in type10_df.select('MER_EMPL_NUM').collect()]

        if len(existing_wins) == 0:
            return []
        # Format WIN_NBR values for SQL query
        existing_wins_string = ', '.join(f"'{value}'" for value in existing_wins)

        regular_plan_id = 'retirement_401k_regular_us' if self.report_type == ReportType.US else 'retirement_401k_regular_pr'

        catchup_plan_id = 'retirement_401k_catchup_regular_us'  if self.report_type == ReportType.US else  'retirement_401k_catchup_regular_pr'

        cosmos_regular_coverages_query = f"""        
                 SELECT c.associateId, c.contribution['value']*100 as 'rate_change', c.planId, c.createdAt 
                 FROM c where c.associateId in ({existing_wins_string}) and c.planId = '{regular_plan_id}'
                    order by  c.createdAt desc
                    offset 0 limit 1 
                 """

        cosmos_df_regular = self.cosmos_query(cosmos_regular_coverages_query, 'coverages')

        cosmos_df_regular.show()
        cosmos_df_regular_check = cosmos_df_regular.filter(F.col('createdAt') >= F.date_sub(F.current_date(), 5)).select('associateId').collect()

        records, wins_str = check_records(cosmos_df_regular_check, existing_wins, existing_wins_string)

        if len(records) == 0:
            return []

        cosmos_df_regular = cosmos_df_regular.select(*(col(x).alias(f'regular_{x}') for x in cosmos_df_regular.columns))



        cosmos_catchup_coverages_query = f"""        
                         SELECT c.associateId, c.contribution['value']*100 as 'rate_change', c.planId, c.createdAt  
                         FROM c where c.associateId in ({wins_str}) and c.planId = '{catchup_plan_id}'
                            order by  c.createdAt desc
                            offset 0 limit 1 
                         """
        print('cosmos_catchup_coverages_query:', cosmos_catchup_coverages_query)
        cosmos_df_catchup = self.cosmos_query(cosmos_catchup_coverages_query, 'coverages')

        cosmos_df_catchup.show()

        if cosmos_df_catchup.count() > 0:

            cosmos_df_catchup_check = cosmos_df_catchup.filter(
                F.col('createdAt') >= F.date_sub(F.current_date(), 5)).select('associateId').collect()

            records, wins_str = check_records(cosmos_df_catchup_check, existing_wins, existing_wins_string)

            if len(records) == 0:
                return []

            cosmos_df_catchup = cosmos_df_catchup.select(*(col(x).alias(f'catchup_{x}') for x in cosmos_df_catchup.columns))

            cosmos_df_coverages = cosmos_df_regular.join(cosmos_df_catchup, cosmos_df_regular.regular_associateId == cosmos_df_catchup.catchup_associateId, "left")
        else:
            cosmos_df_coverages = cosmos_df_regular
            cosmos_df_coverages = cosmos_df_coverages.withColumn("catchup_rate_change",F.lit(0))

        cosmos_df_coverages.show()

        check_emp_status = F"""
        SELECT 
        DISTINCT(T1.WIN_NBR), T1.NATIONAL_ID, T1.FIRST_NAME, T1.LAST_NAME, T1.EMPLOY_STAT_CODE
        FROM DPGBLASC.WIN_ASSOCIATE T1
        WHERE T1.WIN_NBR IN ({wins_str})
        AND T1.STR_COUNTRY_CODE = 'US'
        AND T1.EMPLOY_STAT_CODE NOT IN ('Q', 'T', 'D')
        """
        print('check_emp_status:', check_emp_status)

        filter_emp_status = self.db2_query(check_emp_status).cache()

        check_emp_status_values = [row['WIN_NBR'] for row in filter_emp_status.collect()]

        if len(check_emp_status_values) == 0:
            print('No records found in db2_check_emp_status')
            return []

        win_nbr_values_str = ', '.join(f"'{value}'" for value in check_emp_status_values)
        print('check_emp_status_records:', win_nbr_values_str)


        cosmos_profile_query = f"""
        SELECT * FROM c where c.associateId in ({win_nbr_values_str})
        """

        cosmos_df = self.cosmos_query(cosmos_profile_query, 'associate-benefit-profile') \
            .withColumn("plan_data", F.explode_outer("eligibility.plans")) \
            .filter(F.col("plan_data.planGroup") == "Retirement") \
            .filter(F.col("plan_data.isEligible")) \
            .groupBy("associateId", "plan_data.planId") \
            .agg(
            F.first("plan_data.isEligible").alias("isEligible"),
            F.first("plan_data.eligibleDate").alias("eligibleDate")
        ) \
            .cache()

        # Extract only the date
        cosmos_df = cosmos_df.withColumn("eligibleDate", F.to_date(F.col("eligibleDate")))

        cosmos_df = cosmos_df.orderBy(F.col("eligibleDate")).limit(1)

        final_df = filter_emp_status.join(cosmos_df , filter_emp_status.WIN_NBR == cosmos_df.associateId , "inner")

        final_df = final_df.join(cosmos_df_coverages, final_df.associateId == cosmos_df_coverages.regular_associateId, "inner")

        final_df = final_df.join(type10_df, type10_df.MER_EMPL_NUM == final_df.associateId, "inner")

        final_df.show()

        # Iterate joined_df, call create_eligibility_object, assign to results
        joined_rows = final_df.collect()
        records = [create_rate_comparison_object(row.asDict()) for row in joined_rows]

        return records

    def identifier(self) -> str:
        # Return the identifier specified
        return "rate_change_compare_hardship"

def create_rate_comparison_object(row):

    return RateChangeCompareDataObject(
        ssn=row['NATIONAL_ID'],
        win_nbr=row['WIN_NBR'],
        asc_first_name=row['FIRST_NAME'],
        asc_last_name=row['LAST_NAME'],
        asc_status=row['EMPLOY_STAT_CODE'],
        elig_status="E" if row['isEligible'] == True else "N",
        elig_date=row['eligibleDate'],
        term_date="          ",
        db_reg_rate=row['regular_rate_change'],
        db_cuc_rate=row['catchup_rate_change'],
        fl_reg_rate=row['CUC_SAVINGS_RATE'],
        fl_cuc_rate=row['CUC_SAVINGS_AMOUNT']
    )