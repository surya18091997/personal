from datetime import datetime

import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql.functions import to_date, substring, add_months
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, BooleanType

from src.report_generator import report_constants, constants, flat_file_writer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.hardship_outbound_data_object import HardshipInboundDataObject
from src.report_generator.templates.data_objects.hardship_outbound_trailer_object import HardshipInboundTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class HardshipInboundTransformer(Transformer[HardshipInboundDataObject]):
    def data_template_name(self) -> str:
        return "hardship_outbound_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type
        # Define report IDs and names based on report type
        self.configs = {
            ReportType.US: {
                'uhdr': 'src/report_generator/output_temp/INBOUND_HARDSHIP_FILE_US.txt_type_UHDR.csv',
                'type50': 'src/report_generator/output_temp/INBOUND_HARDSHIP_FILE_US.txt_type_50.csv',
            },
            ReportType.PR: {
                'uhdr': 'src/report_generator/output_temp/INBOUND_HARDSHIP_FILE_PR.txt_type_UHDR.csv',
                'type50': 'src/report_generator/output_temp/INBOUND_HARDSHIP_FILE_PR.txt_type_50.csv',
            },
        }

        if report_type == ReportType.US:
            self.report_id = "BE208901US"
            self.report_name = "THE ASSOCIATES THAT HAVE JUST TAKEN A HARDSHIP"
        else:  # PR
            self.report_id = "BE208901PR"
            self.report_name = "THE ASSOCIATES THAT HAVE JUST TAKEN A HARDSHIP"

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[HardshipInboundDataObject]) -> DataObject:
        # Compute trailer statistics based on the records
        total_reads = len(records)
        total_correct = sum(1 for record in records if not record.message)
        total_incorrect = total_reads - total_correct

        return HardshipInboundTrailerObject(
            total_reads=total_reads,
            total_correct=total_correct,
            total_incorrect=total_incorrect
        )

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        return None

    def _transform(self) -> list[HardshipInboundDataObject]:
        """
        Transform data for Hardship Inbound reports.

        In a real implementation, this would fetch data from a database or other source.
        For now, we'll use sample data similar to the report examples.
        """
        print(f"Number of columns defined: {len(report_constants.TYPE50_COLUMNS)}")

        try:
            type50_df = pd.read_csv(self.configs[self.report_type]["type50"],
                                delimiter=constants.DELIMITER, names=report_constants.TYPE50_COLUMNS).values.tolist()
        except Exception as e:
            self.logger.error(f"Error reading type50 file: {e}")
            return []

        national_id_values = [row[0] for row in type50_df]
        self.logger.info(f"Extracted National ID values: {len(national_id_values)}")
        db2_df = self.db2_frame("WIN_ASSOCIATE") \
                  .select("NATIONAL_ID", "WIN_NBR", "FIRST_NAME", "LAST_NAME", "EMPLOY_STAT_CODE", "STR_STATE_PROV_CD", "COUNTRY_CODE") \
                  .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
                  .filter(F.col("NATIONAL_ID").isin(national_id_values)) \
                  .filter(F.col("COUNTRY_CODE").isin(["US"])) \
                  .cache()

        win_nbr_values = [row["WIN_NBR"] for row in db2_df.select("WIN_NBR").collect()]
        self.logger.info(f"Filtered WIN_NBR values: {win_nbr_values}")
        minimal_schema = StructType([
            StructField('associateId', StringType(), True),
            StructField('eligibility', StructType([
                StructField('plans', ArrayType(StructType([
                    StructField('planId', StringType(), True),
                    StructField('planGroup', StringType(), True),
                    StructField('isEligible', BooleanType(), True),
                    StructField('eligibleDate', StringType(), True)
                ])), True)
            ]), True)
        ])

        plan_id = "retirement_401k_hardship_us" if self.report_type == ReportType.US else "retirement_401k_hardship_pr"

        cosmos_df = self.cosmos_dataframe('associate-benefit-profile') \
            .load(schema=minimal_schema) \
            .filter(F.col("associateId").isin(win_nbr_values)) \
            .withColumn("plan_data", F.explode_outer("eligibility.plans")) \
            .filter(F.col("plan_data.planId").isin(plan_id)) \
            .groupBy("associateId", "plan_data.planId") \
            .agg(
                    F.first("plan_data.isEligible").alias("isEligible"),
                    F.first("plan_data.eligibleDate").alias("eligibleDate"),
            ) \
            .cache()
        self.logger.info(f"Cosmos DataFrame loaded and cached")
        cosmos_df.show()
        result = []

        for index, value in enumerate(type50_df):
            result.append({
                'ssn': value[0],
                'start_dt': "{}{}-{}-{}".format(value[2],
                                                flat_file_writer.pad_pre(value[3], '0', 2),
                                                flat_file_writer.pad_pre(value[4], '0', 2),
                                                flat_file_writer.pad_pre(value[5], '0', 2)),
                'ml_end_dt': "{}{}-{}-{}".format(value[6],
                                                flat_file_writer.pad_pre(value[7], '0', 2),
                                                flat_file_writer.pad_pre(value[8], '0', 2),
                                                flat_file_writer.pad_pre(value[9], '0', 2)),
            })

        results_df = self.spark.createDataFrame(result)

        #Join with DB2 Data
        joined_df = results_df.join(db2_df, results_df.ssn == db2_df.NATIONAL_ID, "inner").cache()
        self.logger.info(f"Joined DataFrame with DB2 data")
        joined_df.show()
        # Handle date conversions safely
        converted_df = (joined_df
            .withColumn("start_dt_validated", to_date(substring(F.col("start_dt"), 1, 10)))
            .withColumn("ml_end_dt_validated", to_date(substring(F.col("ml_end_dt"), 1, 10)))
            .withColumn("end_dt",
                        F.when(F.col("start_dt_validated").isNotNull(),
                               F.when(
                                   F.lit(self.report_type == ReportType.PR),
                                   add_months(F.col("start_dt_validated"), 12)
                               ).otherwise(add_months(F.col("start_dt_validated"), 6))
                        ).otherwise(F.lit("          "))
            )
            .withColumn("message",
                        F.when(
                            F.col("start_dt_validated").isNull(),
                            F.lit("INVALID BEGIN DATE FROM ML")
                        )
                        .when(
                            F.col("ml_end_dt_validated").isNotNull() &
                            F.col("end_dt").isNotNull() &
                            (F.col("ml_end_dt_validated") != F.col("end_dt")),
                            F.lit("ML END DATE IS INCORRECT. CORRECT DATE USED")
                        ).otherwise(F.lit(""))
            )
            .select(
                joined_df.ssn,
                joined_df.WIN_NBR.alias("win_nbr"),
                joined_df.FIRST_NAME.alias("first_name"),
                joined_df.LAST_NAME.alias("last_name"),
                joined_df.EMPLOY_STAT_CODE.alias("a_st"),
                joined_df.STR_STATE_PROV_CD.alias("c_c"),
                F.when(F.col("start_dt_validated").isNotNull(),
                    F.col("start_dt_validated")).otherwise(F.lit("          ")).alias("start_dt"),
                F.col("end_dt"),
                F.col("message")
            )
        ).cache()

        # Join Cosmos Data
        converted_df_with_cosmos = converted_df.join(cosmos_df, converted_df.win_nbr == cosmos_df.associateId, "inner")

        # Add cosmos data frame to final dataframe
        final_df = (converted_df_with_cosmos
                    .withColumn("e_st",F.when(F.col("isEligible") == True, "Y").otherwise("N"))
                    .withColumn("e_date", to_date(substring(F.col("eligibleDate"), 1, 10)))
                    .drop(F.col("isEligible"), F.col("eligibleDate"), F.col("associateId"), F.col("planId"))
                    )
        self.logger.info(f"Final DataFrame prepared")
        # Convert the dataframe to a list of dictionaries for further processing
        final_result = [row.asDict() for row in final_df.collect()]

        # Create HardshipInboundDataObject instances from the final result
        return [self.create_hardship_object(row) for row in final_result]

    @staticmethod
    def create_hardship_object(row: dict) -> HardshipInboundDataObject:
        """
        Create a HardshipInboundDataObject from a dictionary row.
        :param row: Dictionary containing the data for the hardship object.
        :return: An instance of HardshipInboundDataObject.
        """
        return HardshipInboundDataObject(
            ssn=row['ssn'],
            win_nbr=row['win_nbr'],
            first_name=row['first_name'],
            last_name=row['last_name'],
            a_st=row['a_st'],
            e_st=row['e_st'],
            e_date=row['e_date'],
            c_c=row['c_c'],
            start_dt=row['start_dt'],
            end_dt=row['end_dt'],
            message=row.get('message', '')
        )

    def identifier(self) -> str:
        # Return a single identifier for both US and PR transformers
        return "hardship_outbound"
