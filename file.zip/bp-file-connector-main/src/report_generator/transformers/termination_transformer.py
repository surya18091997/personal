import math
from datetime import datetime
from pyspark.sql import functions as F

import pandas as pd

from src.report_generator import constants, flat_file_writer, report_utils
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.eligibility_data_object import EligibilityDataObject
from src.report_generator.templates.data_objects.eligibility_trailer_object import EligibilityTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.termination_data_object import TerminationDataObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class TerminationTransformer(Transformer[TerminationDataObject]):
    def data_template_name(self) -> str:
        return "termination_data.template"

    def __init__(self, transfor_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transfor_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr'  : 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_US.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_US.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_US.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_US.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_US.txt_type_62.csv',
            },
            ReportType.PR: {
                'uhdr'  : 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_PR.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_PR.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_PR.txt_type_02.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_PR.txt_type_05.csv',
                'type62': 'src/report_generator/output_temp/OUTGOING_TERMINATION_FILE_PR.txt_type_62.csv',
            },
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = self.pay_end_date('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            page_no="{}".format(page),
            pay_period_date=formatted_date,
            report_name= 'TERMINATION FILE BEING SENT TO MERRILL.'
        )

    def _dynamic_trailer(self, records: list[EligibilityDataObject]) -> DataObject:
        return EligibilityTrailerObject(len(records))

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[DataObject]:
        # Define all column names for record type 01 based on the layout
        type01_columns = [
            "R01_PLAN_NUMBER",
            "R01_PART_NUMBER",
            "R01_ACTION",
            "R01_STAT_CODE",
            "FILLER",
            "R01_SAVINGS_RATES_INCLUDED",
            "R01_FILLER_1",
            "R01_EMPLOYEE_NUMBER",
            "R01_LAST_NAME",
            "R01_FIRST_NAME",
            "R01_FULL_NAME",
            "R01_BDAY_MM",
            "R01_BDAY_DD",
            "R01_BDAY_CC",
            "R01_BDAY_YY",
            "R01_HDAY_MM",
            "R01_HDAY_DD",
            "R01_HDAY_CC",
            "R01_HDAY_YY",
            "R01_PEDAY_MM",
            "R01_PEDAY_DD",
            "R01_PEDAY_CC",
            "R01_PEDAY_YY",
            "R01_SEX",
            "R01_MARITAL_STATUS",
            "R01_FILLER_2",
            "R01_UDF_1",
            "R01_UDF_2",
            "R01_UDF_3",
            "R01_UDF_4",
            "R01_UDF_5",
            "R01_VDAY_MM",
            "R01_VDAY_DD",
            "R01_VDAY_CC",
            "R01_VDAY_YY",
            "R01_TDAY_MM",
            "R01_TDAY_DD",
            "R01_TDAY_CC",
            "R01_TDAY_YY",
            "R01_ADAY_MM",
            "R01_ADAY_DD",
            "R01_ADAY_CC",
            "R01_ADAY_YY",
            "R01_ELIGIBILITY_FLAG",
            "R01_BENEFIT_RATE",
            "R01_HCE_INDICATOR",
            "R01_EMPLOYEE_TYPE",
            "R01_PAYROLL_CODE",
            "R01_PAYROLL_ID",
            "R01_ELECT_BT_SAVE_RATE",
            "R01_ELECT_AT_SAVE_RATE",
            "R01_FILLER_3",
            "R01_SECTION_16_IND",
            "R01_FILLER_4",
            "R01_AFR_IND",
            "R01_ELIGIBILITY_DATE",
            "R01_FILLER_5",
            "R01_ELECT_BT_FLAT_SAVE_RATE",
            "R01_ELECT_AT_FLAT_SAVE_RATE",
            "R01_ELECT_BT_CUC_SAVE_RATE",
            "R01_REHIRE_CREDIT_IND",
            "R01_FILLER_6",
            "R01_RDAY_MM",
            "R01_RDAY_DD",
            "R01_RDAY_CC",
            "R01_RDAY_YY",
            "R01_END_FILLER"
        ]
        type02_columns = [
            "R02_PLAN_NUMBER",
            "R02_PART_NUMBER",
            "R02_OPT_IN_OUT_FLAG",
            "R02_STREET_ADDRESS_L1",
            "R02_STREET_ADDRESS_L2",
            "R02_FILLER_2",
            "R02_EMAIL_TYPE",
            "R02_FILLER_3",
            "R02_CITY",
            "R02_STATE",
            "R02_ZIP",
            "R02_FILLER_3_DUP",
            "R02_ALTERNATE_STATE",
            "R02_PR_BONAFIDE_IND",
            "R02_FILLER_4",
            "R02_EMAIL_ADDRESS",
            "R02_FILLER_5",
            "R02_FILLER_6"
        ]
        type05_columns = [
            "R02_PLAN_NUMBER",
            "R02_PART_NUMBER",
            "FILLER",
            "HOURS",
            "FILLER1",
            "YOS",
            "FILLER2",
            "DEFAULT_COLUMN"
        ]
        type62_columns = [
            "PLAN_NUMBER",
            "PARTICIPANT_NUMBER",
            "FILLER0",
            "WORK_LOCATION",
            "WORK_DIVISION",
            "CHARGE_LOCATION",
            "CHARGE_DIVISION",
            "PAY_CODE",
            "FILLER1",
            "ACTUAL_TERM_DATE",
            "FILLER3",
            "DEFAULT_COLUMN",
        ]

        # Verify we have 68 columns
        print(f"Number of columns defined: {len(type01_columns)}")

        type01_df = pd.read_csv(self.configs[self.report_type]["type01"],
                                delimiter=constants.DELIMITER,names=type01_columns).to_numpy().tolist()
        type02_df = pd.read_csv(self.configs[self.report_type]["type02"],
                                delimiter=constants.DELIMITER,names=type02_columns).to_numpy().tolist()
        type05_df = pd.read_csv(self.configs[self.report_type]["type05"],
                                delimiter=constants.DELIMITER, names=type05_columns).to_numpy().tolist()
        type62_df = pd.read_csv(self.configs[self.report_type]["type62"],
                                delimiter=constants.DELIMITER, names=type62_columns).to_numpy().tolist()

        win_nbr_values = [row[7] for row in type01_df]  # Extract the 7th index column (R01_EMPLOYEE_NUMBER)
        db2_df = self.db2_frame("win_associate") \
            .select("NATIONAL_ID", "WIN_NBR", "COUNTRY_CODE", "FIRST_NAME", "LAST_NAME","TERMINATION_DATE") \
            .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
            .filter(F.col("COUNTRY_CODE").isin(["US"])) \
            .filter(F.col("WIN_NBR").isin(win_nbr_values)) \
            .cache()  # Use cache() for single node rather than p
        db2_df.show()

        payout_date_df = self.db2_frame("assoc_rtrmt_payout") \
            .select("WIN_NBR", "PAYOUT_DATE", "MULTI_ACCT_CODE") \
            .withColumn("EFF_DATE", F.date_add(F.to_date(F.col("PAYOUT_DATE")),-30)) \
            .filter(F.col("WIN_NBR").isin(win_nbr_values)) \
            .filter(F.col("MULTI_ACCT_CODE").isin(["0"])) \
            .orderBy(F.col("PAYOUT_DATE").desc()) \
            .groupBy("WIN_NBR") \
            .agg(
            F.first("PAYOUT_DATE").alias("PAYOUT_DATE"),
            F.first("EFF_DATE").alias("EFF_DATE"),
            F.first("MULTI_ACCT_CODE").alias("MULTI_ACCT_CODE")
        ) \
            .cache()  # Use cache() for single node rather than p

        payout_date_df.show()
        # Create a list of initial data objects with placeholder values for first_name and last_name
        result = []
        for index, value in enumerate(type01_df):
            type1 = type01_df[index]
            type2 = type02_df[index]
            type5 = type05_df[index]
            type62 = type62_df[index]
            eff_date=''
            if not math.isnan(type1[37]):
                eff_date = "{}{}-{}-{}".format(int(type1[37]), flat_file_writer.pad_pre(int(type1[38]), '0', 2),
                                            flat_file_writer.pad_pre(int(type1[35]), '0', 2),
                                            flat_file_writer.pad_pre(int(type1[36]), '0', 2))
            # Convert eligibility hours from string to decimal
            eligibility_hours = report_utils.convert_digits_to_decimal(report_utils.reverse_integer_lastbyte_conversion(type5[3]))
            # Convert to float before dividing to avoid type error
            eligibility_hours_corrected = float(eligibility_hours) / 10 if eligibility_hours else 0
            if eligibility_hours_corrected == 0:
                formatted_hours = "0.00"
            else:
                formatted_hours = f"{eligibility_hours_corrected:,.2f}"
            result.append({
                'win': value[7],
                'ssn': type1[1],
                # Leave first_name and last_name empty as they will come from the DB join
                'first_name': '',
                'last_name': '',
                'address': type2[3],
                'city': type2[8],
                'state': type2[9],
                'zip': type2[10],
                'work_division': type62[4],
                'store_number': type62[3],
                'hire_date': "{}{}-{}-{}".format(type1[17], flat_file_writer.pad_pre(type1[18], '0', 2),
                                                flat_file_writer.pad_pre(type1[15], '0', 2),
                                                flat_file_writer.pad_pre(type1[16], '0', 2)),
                'birth_date': "{}{}-{}-{}".format(type1[13], flat_file_writer.pad_pre(type1[14], '0', 2),
                                                flat_file_writer.pad_pre(type1[11], '0', 2),
                                                flat_file_writer.pad_pre(type1[12], '0', 2)),
                'eff_date': eff_date,
                'term_date': '',
                'term_payout_date': '',
                'eligible_hours': formatted_hours,
                'years_of_service': report_utils.reverse_integer_lastbyte_conversion(type5[5])
            })

        # Convert result list to DataFrame for joining
        results_df = self.spark.createDataFrame(result)
        # Join with db2_df to get the first_name and last_name
        joined_df = results_df.join(db2_df, results_df.win == db2_df.WIN_NBR, 'inner')

        final_df = joined_df.join(payout_date_df, joined_df.win == payout_date_df['WIN_NBR'], "left")
        # Convert joined dataframe to dictionary and create termination objects directly
        final_records = [row.asDict() for row in final_df.collect()]
        return [create_termination_object(row) for row in final_records]

    def pay_end_date(self,date_format) -> str:
        rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                    delimiter=constants.DELIMITER, names=["FILLER", "PAY_END_DATE", "FILLE_2", "FILLER_3"]).to_numpy().tolist()
        gregorian_date = ""
        for row in rows:
            julian_date = str(row[1])
            dt = datetime.strptime(julian_date, '%Y%j')
            gregorian_date = dt.strftime(date_format)
            break
        return gregorian_date

    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for termination file transformation
        """
        return "termination"

def create_termination_object(row):

    # Helper to clean up possible NaN/None/"nan" values and invalid store numbers
    def safe_str(val):
        if val is None or pd.isna(val) or (isinstance(val, str) and val.strip().lower() == 'nan'):
            return ''
        return str(val)

    # Handle both uppercase and lowercase name fields from different sources
    first_name = row.get('FIRST_NAME', None)
    if first_name is None or not first_name:
        first_name = row.get('first_name', '')

    last_name = row.get('LAST_NAME', None)
    if last_name is None or not last_name:
        last_name = row.get('last_name', '')

    address = safe_str(row.get('address', ''))
    city = safe_str(row.get('city', ''))
    state = safe_str(row.get('state', ''))
    raw_zip_code = safe_str(row.get('zip', ''))
    if raw_zip_code:
        zip_code = raw_zip_code.zfill(5)
    else:
        zip_code = ' ' * 5

    return TerminationDataObject(
        win=row['win'],
        ssn=row['ssn'],
        first_name=first_name,
        last_name=last_name,
        address=address,
        city=city,
        state=state,
        zip=zip_code,
        store_number=row['store_number'],
        hire_date=row['hire_date'],
        birth_date=row['birth_date'],
        eff_date=row['eff_date'],
        term_date=row['TERMINATION_DATE'] if row['TERMINATION_DATE'] else ' ' * 10,
        term_payout_date=row['PAYOUT_DATE'] if row['PAYOUT_DATE'] else " ",
        eligible_hours=row['eligible_hours'],
        years_of_service=row['years_of_service']
    )
