from datetime import datetime

from pyspark.sql.types import StructType, StringType, StructField, DateType, BooleanType

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_exception_data_object import RateChangeExceptionDataObject
from src.report_generator.templates.data_objects.rate_change_exception_trailer_object import RateChangeExceptionTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType, ExceptionMessageType
from pyspark.sql.functions import col, when, lit, lower, explode_outer, first


class RateChangeExceptionTransformer(Transformer[RateChangeExceptionDataObject]):
    def data_template_name(self) -> str:
        return "rate_change_exception_data.template"
    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type
        # Define report IDs and names based on report type
        if report_type == ReportType.US:
            self.report_id = "BE208802US"
            self.report_name = "US EXCEPTION REPORT"
            self.retirement_plans = ['retirement_401k_loan_general_us', 'retirement_401k_loan_general_pr']
            self.hardship_plans = ['retirement_hardship_us']
            self.plans =  zip(self.hardship_plans, self.retirement_plans)
        else:  # PR
            self.report_id = "BE208802PR"
            self.report_name = "PR EXCEPTION REPORT"
            self.retirement_plans = ['retirement_401k_loan_residential_pr', 'retirement_401k_loan_residential_us']
            self.hardship_plans = ['retirement_hardship_pr']
            self.plans =  zip(self.hardship_plans, self.retirement_plans)

    def _header(self, page: int) -> DataObject:
            formatted_date = datetime.now().strftime('%m/%d/%y')
            return HeaderObject(
                run_on=formatted_date,
                run_at=datetime.now().strftime('%H:%M:%S'),
                report_number=self.report_id,
                page_no=str(page),
                pay_period_date=formatted_date,
                report_name=self.report_name
            )

    def _dynamic_trailer(self, records: list[RateChangeExceptionDataObject]) -> DataObject:
        # Aggregate counts for each message type
        assoc_not_eligible = 0
        assoc_terminated = 0
        assoc_not_elig_for_cuc = 0
        exceeded_max_regular_rate_nhce = 0
        exceeded_max_regular_rate_hce = 0
        exceeded_max_catchup_rate = 0
        assoc_is_on_hardship = 0

        # Count occurrences of each exception type
        for record in records:
            if record.message == ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value:
                assoc_not_eligible += 1
            elif record.message == ExceptionMessageType.ASSOC_TERMINATED.value:
                assoc_terminated += 1
            elif record.message == ExceptionMessageType.ASSOC_NOT_ELIG_FOR_CUC.value:
                assoc_not_elig_for_cuc += 1
            elif ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_NHCE_US.value in record.message:
                exceeded_max_regular_rate_nhce += 1
            elif ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_HCE_US.value in record.message:
                exceeded_max_regular_rate_hce += 1
            elif ExceptionMessageType.EXCEEDED_MAX_CATCHUP_RATE_US.value in record.message:
                exceeded_max_catchup_rate += 1
            elif record.message == ExceptionMessageType.ASSOC_IS_ON_HARDSHIP.value:
                assoc_is_on_hardship += 1

        # Return trailer object with aggregated counts
        return RateChangeExceptionTrailerObject(
            assoc_not_eligible=assoc_not_eligible,
            assoc_terminated=assoc_terminated,
            assoc_not_elig_for_cuc=assoc_not_elig_for_cuc,
            exceeded_max_regular_rate_nhce_us=exceeded_max_regular_rate_nhce,
            exceeded_max_regular_rate_hce_us=exceeded_max_regular_rate_hce,
            exceeded_max_catchup_rate_us=exceeded_max_catchup_rate,
            assoc_is_on_hardship=assoc_is_on_hardship
        )

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return TrailerObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[RateChangeExceptionDataObject]:
        """
        Transform data for Rate Change Exception reports.

        In a real implementation, this would fetch data from a database or other source.
        For now, we'll use sample data similar to the report examples.
        """
        exceptions = []

        # Get data from PostgreSQL tables
        archive_events_df = (self
                             .postgres_frame("core_engine.archive_events")
                             .filter(col("event_type") == "ENROLLMENT_COMPLETE")
                             )
        event_status_df = (self
                           .postgres_frame("core_engine.event_status")
                           .filter(col("status") != "PROCESSED")
                           )

        # Join dataframes using the specified conditions
        archive_events_df.createOrReplaceTempView("archive_events")
        event_status_df.createOrReplaceTempView("event_status")

        # Execute SQL to join the dataframes
        joined_df = self.spark.sql("""
            SELECT *
            FROM archive_events ae
            JOIN event_status es ON ae.id = es.archive_event_id
            WHERE ae.event_type = 'ENROLLMENT_COMPLETE'
            AND ae.created_at = current_date
            AND es.status <> 'PROCESSED'
        """)
        classified_df = _classify_error_messages(joined_df).cache()
        # Collect associateIds
        associate_ids = classified_df.select("associate_id").distinct().collect()
        associate_ids = [row.associate_id for row in associate_ids]
        # Log the count of records found
        classified_df.show(truncate=500)

        # filter by associate_ids
        self.logger.info(f"Found {len(associate_ids)} distinct associate IDs in classified_df")
        formatted_ids = "(" + ",".join(f"'{id}'" for id in associate_ids) + ")" if associate_ids else "(NULL)"
        win_associate_df = self.db2_query(f"SELECT * FROM win_associate WHERE WIN_NBR IN {formatted_ids}")
        # join win_associate_df with joined_df on associate_id
        self.logger.info(f"Joining classified_df with win_associate_df on associate_id")
        data_df = classified_df.join(win_associate_df, classified_df.associate_id == win_associate_df['WIN_NBR'], "inner")

        self.logger.info(f"Win numbers collected for filtering cosmos data: {formatted_ids}")
        # For single node, filter early to reduce data volume
        coverages_query = f"""
        SELECT * 
        FROM c 
        WHERE c.associateId IN {formatted_ids}
        """
        retirement_plans = self.retirement_plans
        associate_df = self.cosmos_query(coverages_query, "associate-benefit-profile") \
                        .withColumn("plan_data", explode_outer("eligibility.plans")) \
                        .filter(col("plan_data.planGroup").isin(["Retirement"])) \
                        .filter(~col("plan_data.planId").isin(retirement_plans)) \
                        .orderBy(col("plan_data.eligibleDate").desc())
        associate_df = associate_df.cache()

        associate_df = (associate_df
                .groupBy("associateId")
                .agg(
                    first("plan_data.isEligible").alias("isEligible"),
                    first("plan_data.eligibleDate").alias("eligibleDate"),
                )
            )

        result_df = data_df.join(associate_df, data_df.associate_id == associate_df['associateId'], "left")
        result_df.show()
        result_set = result_df.collect()
        # Process the joined data
        exceptions = []
        for row in result_set:
            exceptions.append(RateChangeExceptionDataObject(
                ssn=getattr(row, 'NATIONAL_ID', ''),
                win_nbr=getattr(row, 'WIN_NBR', ''),
                asc_first_name=getattr(row, 'FIRST_NAME', ''),
                asc_last_name=getattr(row, 'LAST_NAME', ''),
                asc_status=getattr(row, 'EMPLOY_STAT_CODE', ''),
                elig_status=getattr(row, 'isEligible', ''),
                elig_date=getattr(row, 'eligibleDate', '') if row.isEligible else '',
                cntry_code=getattr(row, 'COUNTRY_CODE', ''),
                hardship_stdate=str(getattr(row, 'LOA_EFF_DATE', '')), # coverages
                reg_rate='', # coverages
                cuc_rate='', # coverages
                message=getattr(row, 'classification', '')
            ))

        return exceptions

    def identifier(self) -> str:
        # Return a single identifier for both US and PR transformers
        return "rate_change_exception"
def _classify_error_messages(joined_df):
    """
    Classify error messages according to predefined categories and return dataframe with added message column
    """

    # Add a message classification column based on the error_message content (case-insensitive)
    return joined_df.withColumn(
        "classification",
        when(lower(col("error_message")).contains("base plan is not available in profile") |
             lower(col("error_message")).contains("coverage has end date"),
             lit(ExceptionMessageType.ASSOC_NOT_ELIGIBLE.value))
        .when(lower(col("error_message")).contains("associate terminated"),
              lit(ExceptionMessageType.ASSOC_TERMINATED.value))
        .when(lower(col("error_message")).contains("associate is not eligible for catchup"),
              lit(ExceptionMessageType.ASSOC_NOT_ELIG_FOR_CUC.value))
        .when(lower(col("error_message")).contains("exceeded max regular rate") &
              ~lower(col("error_message")).contains("hce"),
              lit(ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_NHCE_US.value))
        .when(lower(col("error_message")).contains("exceeded max regular rate") &
              lower(col("error_message")).contains("hce"),
              lit(ExceptionMessageType.EXCEEDED_MAX_REGULAR_RATE_HCE_US.value))
        .when(lower(col("error_message")).contains("exceeded max catchup rate"),
              lit(ExceptionMessageType.EXCEEDED_MAX_CATCHUP_RATE_US.value))
        .when(lower(col("error_message")).contains("hardship"),
              lit(ExceptionMessageType.ASSOC_IS_ON_HARDSHIP.value))
        .otherwise(lit("UNKNOWN"))  # Use original message if no match
    )
