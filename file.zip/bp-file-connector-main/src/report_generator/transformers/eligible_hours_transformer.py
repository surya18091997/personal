import logging

import pandas as pd

from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.eligible_hours_data_object import EligibleHoursDataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from datetime import datetime

from src.report_generator.transformers.report_types import ReportType


class EligibleHoursTransformer(Transformer[EligibleHoursDataObject]):
    def data_template_name(self) -> str:
        return "eligible_hours_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type

        self.configs = {
            ReportType.US: {
                'uhdr': 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_US.txt_type_UHDR.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_US.txt_type_05.csv',
            },
            ReportType.PR: {
                'uhdr': 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_PR.txt_type_UHDR.csv',
                'type05': 'src/report_generator/output_temp/OUTGOING_ELIGIBLE_HOURS_FILE_PR.txt_type_05.csv',
            },
        }
        if report_type == ReportType.US:
            self.report_id = "PS085611US"
            self.report_name = "401(K) HOURS FILE SENT TO MERRILL LYNCH FOR US"
        else:
            self.report_id = "PS085611PR"
            self.report_name = "401(K) HOURS FILE SENT TO MERRILL LYNCH FOR PUERTO RICO"

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        return None

    def _dynamic_trailer(self, records: list[EligibleHoursDataObject]) -> DataObject:
        return None

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _transform(self) -> list[EligibleHoursDataObject]:
        try:
            type05_df = pd.read_csv(self.configs[self.report_type]["type05"])
            record_type_05_count = len(type05_df)
        except Exception as e:
            self.logger.error(f"Error reading type05 file: {e}")
            record_type_05_count = 0

        total_count = record_type_05_count + 2

        # Create the data object
        counts = EligibleHoursDataObject(
            total_header=1,
            total_trailer=1,
            record_type_01=0,
            record_type_02=0,
            record_type_05=self.format_count(record_type_05_count),
            record_type_08=0,
            record_type_10=0,
            record_type_62=0,
            total_count=self.format_count(total_count)
        )
        return [counts]

    @staticmethod
    def format_count(value: int):
        return f"{int(value):,}"

    def identifier(self) -> str:
        return "eligible_hours"