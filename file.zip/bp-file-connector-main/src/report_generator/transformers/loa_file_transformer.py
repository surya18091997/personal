from datetime import datetime

import pandas as pd
import numpy as np

from src.report_generator import constants
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.loa_data_object import LoaDataObject
from src.report_generator.templates.data_objects.loa_trailer_object import LoaTrailerObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.transformers.report_types import ReportType


class LoaFileTransformer(Transformer[LoaDataObject]):

    def data_template_name(self) -> str:
        return "loa_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr'  : 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_US.txt_type_02.csv',
            },
            ReportType.PR: {
                'uhdr'  : 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_UHDR.csv',
                'type01': 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_01.csv',
                'type02': 'src/report_generator/output_temp/OUTBOUND_LOA_FILE_PR.txt_type_02.csv',
            },
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = self.pay_end_date('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            page_no="{}".format(page),
            pay_period_date=formatted_date,
            report_name= '401(K) LOA INFORMATION FILE.'
        )

    def _dynamic_trailer(self, records: list[LoaDataObject]) -> DataObject:
        return LoaTrailerObject(len(records))

    def _trailer(self) -> DataObject:
        formatted_date = datetime.now().strftime("%m/%d/%y")
        return TrailerObject(
            run_on=formatted_date,
            run_at="10:00:00",
            report_number=self.output_configuration.report_id,
            pay_period_date=formatted_date,
        )

    def _transform(self) -> list[DataObject]:
        # Define all column names for record type 01 based on the layout
        type01_columns = [
            "R01_PLAN_NUMBER",
            "R01_PART_NUMBER",
            "R01_ACTION",
            "R01_STAT_CODE",
            "R01_FILLER_1",
            "R01_WIN_NUMBER",
            "R01_FILLER_2"
        ]
        type02_columns = [
            "R02_PLAN_NUMBER",
            "R02_PART_NUMBER",
            "R02_FILLER_1",
            "R02_USERRA_START_DATE",
            "R02_USERRA_END_DATE",
            "R02_LOA_START_DATE",
            "R02_LOA_END_DATE",
            "R02_FILLER_2"
        ]


        # Verify we have 68 columns

        try:
            type01_df = pd.read_csv(self.configs[self.report_type]["type01"],
                                delimiter=constants.DELIMITER,names=type01_columns).values.tolist()
            type02_df = pd.read_csv(self.configs[self.report_type]["type02"],
                                delimiter=constants.DELIMITER,names=type02_columns).values.tolist()
        except Exception as e:
            self.logger.error(f"Error reading type02/01 file: {e}")
            return []
        result = []
        for index, value in enumerate(type01_df):
            type01 = type01_df[index]
            type02 = type02_df[index]
            leave_type_val = 'NON-MILT'
            start_date = type02[4]
            end_date = type02[5]
            if str(type01[2]) == '52':
                leave_type_val = 'MILITARY'
                start_date = type02[2]
                end_date = type02[3]
            result.append(create_loa_object({
                'win': type01[4],
                'leave_type': leave_type_val,
                'start_date': start_date,
                'end_date': end_date

            }))

        return result


    def pay_end_date(self,date_format) -> str:
        rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                    delimiter=constants.DELIMITER, names=["FILLER", "PAY_END_DATE", "FILLE_2", "FILLER_3"]).values.tolist()
        gregorian_date = ""
        for row in rows:
            julian_date = str(row[1])
            dt = datetime.strptime(julian_date, '%Y%j')
            gregorian_date = dt.strftime(date_format)
            break
        return gregorian_date

    def identifier(self) -> str:
        """
        Returns a unique identifier for this transformer

        Returns:
            str: The identifier key for leave of absence file transformation
        """
        return "loa"

def create_loa_object(row):
    # Check if start_date is null or NaN and replace with spaces if it is
    start_date = row['start_date']
    if start_date is None or pd.isna(start_date) or start_date == "" or (isinstance(start_date, float) and np.isnan(start_date)):
        start_date = " "
    else:
        # Convert from "20250530.0" to "2025-05-30" format
        try:
            if isinstance(start_date, float) or isinstance(start_date, str):
                # Remove decimal part if present
                date_str = str(start_date).split('.')[0]
                if len(date_str) == 8:  # Ensure it's in the expected format
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    start_date = f"{year}-{month}-{day}"
        except Exception:
            # Keep original if conversion fails
            pass

    # Check if end_date is null or NaN and replace with spaces if it is
    end_date = row['end_date']
    if end_date is None or pd.isna(end_date) or end_date == "" or (isinstance(end_date, float) and np.isnan(end_date)):
        end_date = " "
    else:
        # Convert from "20250530.0" to "2025-05-30" format
        try:
            if isinstance(end_date, float) or isinstance(end_date, str):
                # Remove decimal part if present
                date_str = str(end_date).split('.')[0]
                if len(date_str) == 8:  # Ensure it's in the expected format
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    end_date = f"{year}-{month}-{day}"
        except Exception:
            # Keep original if conversion fails
            pass

    return LoaDataObject(
        win=row['win'],
        leave_type=row['leave_type'],
        start_date=start_date,
        end_date=end_date
    )
