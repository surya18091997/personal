from datetime import datetime
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_compare_data_object import RateChangeCompareDataObject
from src.report_generator.templates.data_objects.rate_change_compare_trailer_object import RateChangeCompareTrailerObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType


class RateChangeCompareTransformer(Transformer[RateChangeCompareDataObject]):

    def data_template_name(self) -> str:
        return "rate_change_compare_data.template"
    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type
        # Define report IDs and names based on report type
        if report_type == ReportType.US:
            self.report_id = "BE209201US"
            self.report_name = "ASSOCIATES RATE CHANGE REPORT LAYOUT"
        else:  # PR
            self.report_id = "BE209201PR"
            self.report_name = "ASSOCIATES RATE CHANGE REPORT LAYOUT"

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[RateChangeCompareDataObject]) -> DataObject:
        # Return a trailer with the count of records
        return RateChangeCompareTrailerObject(total_nbr_of_assocs=len(records))

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        return None

    def _transform(self) -> list[RateChangeCompareDataObject]:
        """
        Transform data for Rate Change Compare reports.

        In a real implementation, this would fetch data from a database or other source.
        For now, we'll use sample data similar to the report examples.
        """
        records = []

        # Sample data based on country code (US or PR)
        if self.report_type == ReportType.US:
            # Sample US data
            records = [
                RateChangeCompareDataObject(
                    ssn="123456789",
                    win_nbr="232819157",
                    asc_first_name="JOHN",
                    asc_last_name="SMITH",
                    asc_status="A",
                    elig_status="E",
                    elig_date="01/15/25",
                    term_date="",
                    db_reg_rate="5.0",
                    db_cuc_rate="1.0",
                    fl_reg_rate="5.0",
                    fl_cuc_rate="1.0"
                ),
                RateChangeCompareDataObject(
                    ssn="987654321",
                    win_nbr="232503759",
                    asc_first_name="MARY",
                    asc_last_name="JOHNSON",
                    asc_status="A",
                    elig_status="E",
                    elig_date="02/20/25",
                    term_date="",
                    db_reg_rate="6.0",
                    db_cuc_rate="0.0",
                    fl_reg_rate="7.0",
                    fl_cuc_rate="0.0"
                ),
                RateChangeCompareDataObject(
                    ssn="456789123",
                    win_nbr="231876450",
                    asc_first_name="ROBERT",
                    asc_last_name="WILLIAMS",
                    asc_status="A",
                    elig_status="E",
                    elig_date="03/10/25",
                    term_date="",
                    db_reg_rate="10.0",
                    db_cuc_rate="2.0",
                    fl_reg_rate="10.0",
                    fl_cuc_rate="2.0"
                )
            ]
        elif self.report_type == ReportType.PR:
            # Sample PR data
            records = [
                RateChangeCompareDataObject(
                    ssn="111223333",
                    win_nbr="230975621",
                    asc_first_name="CARLOS",
                    asc_last_name="RIVERA",
                    asc_status="A",
                    elig_status="E",
                    elig_date="01/05/25",
                    term_date="",
                    db_reg_rate="4.0",
                    db_cuc_rate="0.0",
                    fl_reg_rate="4.0",
                    fl_cuc_rate="0.0"
                ),
                RateChangeCompareDataObject(
                    ssn="444556666",
                    win_nbr="231123456",
                    asc_first_name="MARIA",
                    asc_last_name="RODRIGUEZ",
                    asc_status="A",
                    elig_status="E",
                    elig_date="02/15/25",
                    term_date="",
                    db_reg_rate="3.0",
                    db_cuc_rate="1.0",
                    fl_reg_rate="3.5",
                    fl_cuc_rate="1.0"
                )
            ]

        return records

    def identifier(self) -> str:
        # Return the identifier specified
        return "rate_change_compare"
