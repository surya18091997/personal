from datetime import datetime
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.rate_change_outbound_summary_data_object import RateChangeOutboundSummaryDataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType
import pandas as pd


class RateChangeOutboundSummaryTransformer(Transformer[RateChangeOutboundSummaryDataObject]):
    """
    Transformer class for generating Eligible Hours Outbound Summary Reports.
    This report shows the counts of different record types processed.
    """
    def data_template_name(self) -> str:
        return "rate_change_outbound_summary_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        """Initialize the transformer with configuration."""
        super().__init__(transformer_config, report_type, logger)
        self.report_type = report_type
        # Define report IDs and names based on report type
        if report_type == ReportType.US:
            self.report_id = "PS719701US"
            self.report_name = "SAVINGS RATE RECORD SENT TO MERRILL LYNCH FOR UNITED STATES"
        else:  # PR
            self.report_id = "PS719701PR"
            self.report_name = "SAVING RATE FILE RECORD SENT TO MERRILL LYNCH FOR PUERTO RICO"
        
        self.configs = {
            ReportType.US: {
                'type01': 'src/report_generator/output_temp/OUTGOING_RATE_CHANGE_SUMMARY_FILE_US.txt_type_02.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_RATE_CHANGE_SUMMARY_FILE_US.txt_type_02.csv',
                'report_title': 'SAVINGS RATE RECORD SENT TO MERRILL LYNCH FOR UNITED STATES',
                'report_id': 'PS719701US'
            },
            ReportType.PR: {
                'type01': 'src/report_generator/output_temp/OUTGOING_RATE_CHANGE_SUMMARY_FILE_PR.txt_type_02.csv',
                'type02': 'src/report_generator/output_temp/OUTGOING_RATE_CHANGE_SUMMARY_FILE_PR.txt_type_02.csv',
                'report_title': 'SAVING RATE FILE RECORD SENT TO MERRILL LYNCH FOR PUERTO RICO',
                'report_id': 'PS719701PR'
            }
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name=self.report_name
        )

    def _dynamic_trailer(self, records: list[RateChangeOutboundSummaryDataObject]) -> DataObject:
        """This report doesn't need a dynamic trailer."""
        return None

    def _trailer(self) -> DataObject:
        """This report doesn't need a standard trailer."""
        return None

    def _transform(self) -> list[DataObject]:
        """
        Transform data for the Eligible Hours Outbound Summary report.
        
        This counts the number of records in relevant file types,
        with static counts for headers and trailers.
        """
        self.logger.info(f"Starting transformation for Eligible Hours Outbound Summary Report")
        
        try:
            # Initialize counts with static values as directed
            header_count = 1
            trailer_count = 1
            record_type_01 = 0
            record_type_02 = 0

            try:
                # Count type01 records
                type01_df = pd.read_csv(self.configs[self.report_type]['type01'], header=None)
                record_type_01 = len(type01_df)
                # Count type02 records
                type02_df = pd.read_csv(self.configs[self.report_type]['type02'], header=None)
                record_type_02 = len(type02_df)
            except Exception as e:
                self.logger.error(f"Error reading the count of type01 and type02 file: {str(e)}")
                raise e
            
            # Set other record counts to 0
            record_type_05 = 0
            record_type_08 = 0
            record_type_10 = 0
            record_type_62 = 0
            
            # Calculate total count
            total_count = header_count + trailer_count + record_type_01 + record_type_02
            
            # Create the summary data object
            summary = RateChangeOutboundSummaryDataObject(
                header_count=header_count,
                trailer_count=trailer_count,
                record_type_01=record_type_01,
                record_type_02=record_type_02,
                record_type_05=record_type_05,
                record_type_08=record_type_08,
                record_type_10=record_type_10,
                record_type_62=record_type_62,
                total_count=total_count
            )
            
            self.logger.info(f"Completed transformation for Eligible Hours Outbound Summary Report")
            
            return [summary]
            
        except Exception as e:
            self.logger.error(f"Error transforming data: {str(e)}")
            raise e

    def identifier(self) -> str:
        """Return a unique identifier for this transformer."""
        return "rate_change_compare"
