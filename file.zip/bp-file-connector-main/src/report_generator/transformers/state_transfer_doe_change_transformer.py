from datetime import datetime
import pandas as pd
from pyspark.sql import functions as F
from src.report_generator import constants, flat_file_writer, report_utils, report_constants
from src.report_generator.templates.data_objects.data_object import DataObject
from src.report_generator.templates.data_objects.state_transfer_doe_change_data_object import StateTransferDoeChangeDataObject
from src.report_generator.templates.data_objects.header_object import HeaderObject
from src.report_generator.templates.data_objects.trailer_object import TrailerObject
from src.report_generator.templates.data_objects.state_transfer_doe_change_trailer_object import StateTransferDoeChangeTrailerObject
from src.report_generator.transformer import Transformer
from src.report_generator.output_configuration import TransformerConfig
from src.report_generator.transformers.report_types import ReportType


class StateTransferDoeChangeTransformer(Transformer[StateTransferDoeChangeDataObject]):
    def data_template_name(self) -> str:
        return "state_transfer_doe_change_data.template"

    def __init__(self, transformer_config: TransformerConfig, report_type: ReportType, logger):
        super().__init__(transformer_config, report_type, logger)
        self.configs = {
            ReportType.US: {
                'uhdr': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_US.txt_type_UHDR.csv',

            },
            ReportType.PR: {
                'uhdr': 'src/report_generator/output_temp/OUTBOUND_STATE_TRANSFER_FILE_PR.txt_type_UHDR.csv',
            },
        }

    def _header(self, page: int) -> DataObject:
        formatted_date = datetime.now().strftime('%m/%d/%y')
        return HeaderObject(
            run_on=formatted_date,
            run_at=datetime.now().strftime('%H:%M:%S'),
            report_number=self.output_configuration.report_id,
            page_no=str(page),
            pay_period_date=formatted_date,
            report_name='          ASSOCIATE DOE CHANGES - {}          '.format(
                self.report_type.name)
        )

    def _dynamic_trailer(self, records: list[StateTransferDoeChangeDataObject]) -> DataObject:
        # Return a specialized trailer object for State Transfer DOE Change reports
        return StateTransferDoeChangeTrailerObject(report_number=self.output_configuration.report_id)

    def _trailer(self) -> DataObject:
        # Return None to prevent duplicate trailer
        return None

    def pay_end_date(self, date_format) -> str:
        rows = pd.read_csv(self.configs[self.report_type]["uhdr"],
                           delimiter=constants.DELIMITER,
                           names=["FILLER", "PAY_END_DATE", "FILLE_2",
                                  "FILLER_3"]).values.tolist()
        gregorian_date = ""
        for row in rows:
            julian_date = str(row[1])
            dt = datetime.strptime(julian_date, '%Y%j')
            gregorian_date = dt.strftime(date_format)
            break
        return gregorian_date

    def _transform(self) -> list[StateTransferDoeChangeDataObject]:
        """
        Transform data for State Transfer DOE Change reports.

        Need to run only on Saturdays after the deduction driver process runs
        """
        run_date = self.pay_end_date("%y/%m/%d")
        self.logger.info(f"Run date for the report: {run_date}")

        # Calculate the most recent Saturday's date
        today = datetime.today()
        offset = (today.weekday() - 5) % 7  # 5 = Saturday
        last_saturday = today if today.weekday() == 5 else today - pd.Timedelta(
            days=offset)
        last_saturday_str = last_saturday.strftime('%Y-%m-%d')
        self.logger.info(f"Most recent Saturday's date: {last_saturday_str}")


        state_transfer_doe_sql_query = f"""SELECT ASSOCIATE_SSN,
               CREATE_DATE,
               CREATION_CODE,
               MAX(CASE WHEN SUBSTR(TRANSACTION_DATA, 5, 1) = '0' THEN SUBSTR(TRANSACTION_DATA, 1, 2) END) AS OLD_DOE,
               MAX(CASE WHEN SUBSTR(TRANSACTION_DATA, 5, 1) = 'A' THEN SUBSTR(TRANSACTION_DATA, 1, 2) END) AS NEW_DOE
            FROM DPPEOPLE.MSA_TRANSACTIONS
            WHERE CREATION_CODE = 'RTMS'
              AND TRANSACTION_CODE = 'RK'
              AND CREATE_DATE = DATE('{last_saturday_str}')
              AND SUBSTR(TRANSACTION_DATA, 1, 2) IN ('KL','KM','KN','KO')
            GROUP BY ASSOCIATE_SSN, CREATE_DATE, CREATION_CODE
             UNION
            SELECT ASSOCIATE_SSN,
               CREATE_DATE,
               CREATION_CODE,
               MAX(CASE WHEN SUBSTR(TRANSACTION_DATA, 5, 1) = '0' THEN SUBSTR(TRANSACTION_DATA, 1, 2) END) AS OLD_DOE,
               MAX(CASE WHEN SUBSTR(TRANSACTION_DATA, 5, 1) = 'A' THEN SUBSTR(TRANSACTION_DATA, 1, 2) END) AS NEW_DOE
            FROM DPPEOPLE.MSA_TRANSACTIONS
            WHERE CREATION_CODE = 'RTMS'
              AND TRANSACTION_CODE = 'RK'
              AND CREATE_DATE = DATE('{last_saturday_str}')
              AND SUBSTR(TRANSACTION_DATA, 1, 2) IN ('K0','K1','K2','K3')
            GROUP BY ASSOCIATE_SSN, CREATE_DATE, CREATION_CODE"""

        db2_df = self.db2_query(state_transfer_doe_sql_query).cache()
        db2_df.show()

        result = []

        # Ensure all SSNs are 9 digits with leading zeros if necessary
        national_id_values = [str(row["ASSOCIATE_SSN"]).zfill(9) for row in db2_df.collect()]
        self.logger.info(f"Total National ID values: {len(national_id_values)}")

        db2_win_df = self.db2_frame("win_associate") \
            .select("NATIONAL_ID", "WIN_NBR", "COUNTRY_CODE", "FIRST_NAME",
                    "LAST_NAME", "STR_STATE_PROV_CD", "STORE_NBR") \
            .withColumn("NATIONAL_ID", F.trim(F.col("NATIONAL_ID"))) \
            .filter(F.col("COUNTRY_CODE").isin(["US"])) \
            .filter(F.col("NATIONAL_ID").isin(national_id_values))
        if self.report_type == ReportType.PR:
            db2_win_df = db2_win_df.filter(F.col("STR_STATE_PROV_CD").isin([
                "PR"]))
        else:
            db2_win_df = db2_win_df.filter(~F.col("STR_STATE_PROV_CD").isin([
                "PR"]))
        db2_win_df = db2_win_df.cache()

        db2_win_df.show()

        # Join with DB2 data
        joined_df = db2_df.join(db2_win_df,
                                    db2_df.ASSOCIATE_SSN == db2_win_df.NATIONAL_ID,
                                    'inner')
        joined_df.show()

        # Convert the dataframe to a list of dictionaries for further processing
        final_result = [row.asDict() for row in joined_df.collect()]
        self.logger.info(f"Total result values: {len(final_result)}")
        # Create data objects from the final result
        return [create_state_transfer_doe_object(row) for row in final_result]


    def identifier(self) -> str:
        # Return a single identifier for both US and PR transformers
        return "state_transfer_doe_change"

def create_state_transfer_doe_object(row):
    last_name = row['LAST_NAME'].strip().split()[0]
    first_name = row['FIRST_NAME'].strip().split()[0]
    return StateTransferDoeChangeDataObject(
        win_number=row['WIN_NBR'],
        ssn=row['NATIONAL_ID'],
        associate_name=last_name + ", " + first_name,
        store=row['STORE_NBR'],
        hce_ind="0",
        old_doe=row['OLD_DOE'],
        new_doe=row['NEW_DOE']
    )
