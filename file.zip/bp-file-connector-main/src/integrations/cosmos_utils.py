from azure.identity import ClientSecretCredential
from azure.cosmos import CosmosClient
from datetime import datetime
import time
import json
import os
import src.utils.app_config as app_config
from src.utils.errors.db2_errors import DatabaseError
from src.constants import (
    COSMOS_INIT_START, COSMOS_CONFIG_SUCCESS, COSMOS_CLIENT_SUCCESS,
    COSMOS_CLIENT_ERROR, COSMOS_CONFIG_NOT_FOUND, COSMOS_CONFIG_MISSING,
    COSMOS_CONFIG_READ_ERROR, COSMOS_QUERY_EXECUTION, COSMOS_QUERY_RESULT,
    COSMOS_QUERY_ATTEMPT_FAILED, COSMOS_FETCH_ERROR, COSMOS_DB_CONNECT_ERROR,
    COSMOS_CONFIG_READ_PATH, COSMOS_DB_CONFIG_ERROR, COSMOS_MAX_RETRY_COUNT,
    COSMOS_RETRY_DELAY, COSMOS_SECRET_EXPIRED, APP_NAME, APP_CFG_CORE_SQL_CONNECTION_KEY, APP_CFG_CORE_SQL_URL,
    DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS
)


class CosmosUtils:
    def __init__(self, logger):
        """
        Initialize Cosmos DB connection using configuration from app_config.
        Args:
            logger: Logger instance
        """
        self.logger = logger
        try:
            self.logger.info(COSMOS_INIT_START)
            azure_config = self._get_azure_config()
            self.logger.info(COSMOS_CONFIG_SUCCESS)

            credential = ClientSecretCredential(
                tenant_id=azure_config['tenant_id'],
                client_id=azure_config['client_id'],
                client_secret=azure_config['client_secret']
            )

            self.client = CosmosClient(
                url=azure_config['cosmos_account_url'],
                credential=credential
            )
            self.logger.info(COSMOS_CLIENT_SUCCESS)

        except Exception as e:
            self.logger.error(COSMOS_CLIENT_ERROR.format(str(e)))
            raise DatabaseError(COSMOS_DB_CONNECT_ERROR.format(e))

    def _get_azure_config(self):
        """
        Get Cosmos DB configuration from app_config.

        Returns:
            dict: Configuration for Cosmos DB
        """
        try:
            azure_ad_path = app_config.get_config_value(APP_NAME, APP_CFG_CORE_SQL_CONNECTION_KEY)
            cosmos_url = app_config.get_config_value(APP_NAME, APP_CFG_CORE_SQL_URL)
            self.logger.info(COSMOS_CONFIG_READ_PATH.format(azure_ad_path))

            if not os.path.exists(azure_ad_path):
                error_msg = COSMOS_CONFIG_NOT_FOUND.format(azure_ad_path)
                self.logger.error(error_msg)
                raise DatabaseError(error_msg)

            with open(azure_ad_path, 'r') as f:
                cosmos_config = json.load(f)

            # Extract expiry date and secText from primary and secondary
            primary_expiry_date = datetime.strptime(cosmos_config['primary']['expiryDate'], DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS)
            primary_sec_text = cosmos_config['primary']['secText']

            secondary_expiry_date = datetime.strptime(cosmos_config['secondary']['expiryDate'],
                                                      DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS) if \
                cosmos_config['secondary']['expiryDate'] else None
            secondary_sec_text = cosmos_config['secondary']['secText']

            # Compare expiryDates with current date
            if primary_expiry_date > datetime.now():
                sec_text = primary_sec_text
            elif secondary_expiry_date and secondary_expiry_date > datetime.now():
                sec_text = secondary_sec_text
            else:
                self.logger.error(COSMOS_SECRET_EXPIRED)
                raise DatabaseError(COSMOS_SECRET_EXPIRED)

            config = {
                'tenant_id': cosmos_config['spnTenantId'],
                'client_id': cosmos_config['spnClientId'],
                'client_secret': sec_text,
                'cosmos_account_url': cosmos_url
            }

            return config

        except Exception as e:
            self.logger.error(COSMOS_CONFIG_READ_ERROR.format(str(e)))
            raise DatabaseError(COSMOS_DB_CONFIG_ERROR.format(e))

    def get_structured_data(self, cosmos_database, cosmos_collection, cosmos_projection, cosmos_search_criteria):
        """
        Retrieves data using Cosmos DB SQL query with retries.

        Args:
            cosmos_database (str): Database name
            cosmos_collection (str): Collection name
            cosmos_projection (str): SQL projection clause (e.g., "c.field1, c.field2")
            cosmos_search_criteria (dict): SQL where clause in dict format

        Returns:
            list: Query results

        Raises:
            DatabaseError: If query execution fails after retries
        """
        retry_count = 0

        while retry_count < COSMOS_MAX_RETRY_COUNT:
            try:
                database = self.client.get_database_client(cosmos_database)
                container = database.get_container_client(cosmos_collection)

                # Build SQL query
                query = f"SELECT {cosmos_projection} FROM c"
                if 'where' in cosmos_search_criteria:
                    query += f" WHERE {cosmos_search_criteria['where']}"

                self.logger.info(COSMOS_QUERY_EXECUTION.format(query))

                # Execute query
                items = list(container.query_items(
                    query=query,
                    enable_cross_partition_query=True
                ))

                self.logger.info(COSMOS_QUERY_RESULT.format(len(items)))
                return items

            except Exception as e:
                retry_count += 1
                self.logger.error(COSMOS_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < COSMOS_MAX_RETRY_COUNT:
                    time.sleep(COSMOS_RETRY_DELAY)
                    continue
                raise DatabaseError(COSMOS_FETCH_ERROR.format(e))

    def get_structured_data_chunked(self, cosmos_database, cosmos_collection, cosmos_projection, cosmos_search_criteria,
                                    associate_list=None, chunk_size=1000):
        """
        Retrieves data using Cosmos DB SQL query with chunking support for large associate lists.

        Args:
            cosmos_database (str): Database name
            cosmos_collection (str): Collection name
            cosmos_projection (str): SQL projection clause (e.g., "c.field1, c.field2")
            cosmos_search_criteria (dict): SQL where clause template with {ASSOCIATE_LIST} placeholder
            associate_list (list): List of associate IDs to process in chunks
            chunk_size (int): Number of associates to process per chunk

        Returns:
            list: Combined query results from all chunks

        Raises:
            DatabaseError: If query execution fails after retries
        """
        try:
            if not associate_list:
                # If no associate list provided, use regular method
                return self.get_structured_data(cosmos_database, cosmos_collection, cosmos_projection,
                                                cosmos_search_criteria)

            # Process associates in chunks
            associate_chunks = [associate_list[i:i + chunk_size]
                                for i in range(0, len(associate_list), chunk_size)]

            all_results = []

            for chunk_index, associate_chunk in enumerate(associate_chunks):
                try:
                    self.logger.info(
                        f"Processing Cosmos chunk {chunk_index + 1}/{len(associate_chunks)} with {len(associate_chunk)} associates")

                    # Create associate list string for this chunk
                    associates_list_str = ",".join([f"'{id}'" for id in associate_chunk])

                    # Replace placeholder in where clause
                    where_clause = cosmos_search_criteria.get('where', '')
                    chunked_where_clause = where_clause.replace('{ASSOCIATE_LIST}', associates_list_str)

                    # Create search criteria for this chunk
                    chunked_search_criteria = {
                        'where': chunked_where_clause
                    }

                    # Execute query for this chunk
                    chunk_results = self.get_structured_data(
                        cosmos_database,
                        cosmos_collection,
                        cosmos_projection,
                        chunked_search_criteria
                    )

                    if chunk_results:
                        all_results.extend(chunk_results)
                        self.logger.info(f"Cosmos chunk {chunk_index + 1} returned {len(chunk_results)} records")
                    else:
                        self.logger.info(f"Cosmos chunk {chunk_index + 1} returned no data")

                except Exception as chunk_error:
                    self.logger.error(f"Error processing Cosmos chunk {chunk_index + 1}: {str(chunk_error)}")
                    # Continue with other chunks even if one fails
                    continue

            self.logger.info(
                f"Successfully processed {len(associate_chunks)} chunks, total results: {len(all_results)}")
            return all_results

        except Exception as e:
            self.logger.error(f"Error in chunked Cosmos query: {str(e)}")
            raise DatabaseError(COSMOS_FETCH_ERROR.format(e))