import json
import time
from datetime import datetime, timedelta, timezone
from google.cloud import storage, bigquery
import src.utils.app_config as app_config
import os
from src.constants import GCS_ERROR_EXPORT, GCS_INFO_JOB_SUBMITTED, \
    GCS_ERROR_JOB_WAIT, GCS_INFO_EXPORT_STARTED, GCS_ERROR_VERIFY_COPY, GCS_ERROR_COPY_BLOB, GCS_INFO_BLOB_COPIED, \
    GCS_ERROR_LIST_FILES, GCS_INFO_FILES_FOUND, APP_NAME, CFG_GCS_CONNECTION_FILE, GCS_ERROR_DOWNLOAD_CONTENT
from src.utils import common_utils
from src.utils.errors.app_errors import ApplicationError
from src.utils.errors.gcs_errors import GCSCreateFolderError, GCSCreateFileError, GCSUploadFileError, \
    GCSUploadFolderError, GCSDownloadFileError, GCSResumableUploadError, GCSUploadChunkError, GCSError


class GCSUtils:

    def __init__(self,logger):
        try:
            self.logger = logger
            # Get GCS config first
            self.gcs_connection_file_path = app_config.get_config_value(APP_NAME, CFG_GCS_CONNECTION_FILE)

            # Initialize clients
            self.storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            self.bigquery_client = bigquery.Client.from_service_account_json(self.gcs_connection_file_path)

            # Get project ID last (not needed for initialization)
            creds = json.load(open(self.gcs_connection_file_path))
            self.gcp_project = creds.get('project_id')

        except Exception as e:
            raise GCSError(f"Error initializing GCS Utils: {str(e)}")

    """
    Creates a folder in the specified bucket.

    Args:
        bucket_name (str): The name of the bucket.
        folder_name (str): The name of the folder to create.

    Returns:
        None

    Raises:
        google.cloud.exceptions.NotFound: If the bucket does not exist.

    """
    def create_folder(self, bucket_name, folder_name):
        try:
            storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            bucket = storage_client.get_bucket(bucket_name)
            blob = bucket.blob(folder_name + '/')

            if not blob.exists():
                blob.upload_from_string('')
                self.logger.info('Created folder: {}'.format(blob.name))
            else:
                self.logger.info('Folder {} already exists.'.format(blob.name))
        except Exception as e:
            self.logger.error('Error creating folder: {}'.format(e))
            raise GCSCreateFolderError('Error creating folder: {}'.format(e))

    def create_file(self, bucket_name, folder_name, file_name, file_content):
        try:
            # Create storage client from credentials
            storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            # Access the bucket
            bucket = storage_client.get_bucket(bucket_name)
            # Create a new blob
            blob = bucket.blob(folder_name + '/' + file_name)

            # Upload the data to the blob
            blob.upload_from_string(file_content)
            self.logger.info('Created file: {}'.format(blob.name))
        except Exception as e:
            self.logger.error('Error creating file: {}'.format(e))
            raise GCSCreateFileError('Error creating file: {}'.format(e))

    def upload_file(self, bucket_name, destination_file_path, source_file_path):
        try:
            # Create storage client from credentials
            storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            # Access the bucket
            bucket = storage_client.get_bucket(bucket_name)
            # Create a new blob
            blob = bucket.blob(destination_file_path)

            # Upload the data to the blob
            blob.upload_from_filename(source_file_path)
            self.logger.info(' file: {}'.format(blob.name) + ' uploaded successfully')
        except Exception as e:
            self.logger.error('Error uploading file: {}'.format(e))
            raise GCSUploadFileError('Error uploading file: {}'.format(e))

    def upload_folder(self, bucket_name, destination_folder_name, path_to_folder):
        try:
            # Create storage client from credentials
            storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            # Access the bucket
            bucket = storage_client.get_bucket(bucket_name)

            # Get all files in the local folder
            files = [os.path.join(path_to_folder, file) for file in os.listdir(path_to_folder) if
                     os.path.isfile(os.path.join(path_to_folder, file))]

            # Upload each file to the GCS bucket
            for file_path in files:
                file_name = os.path.basename(file_path)
                # Create a new blob
                blob = bucket.blob(os.path.join(destination_folder_name, file_name))
                #upload file
                blob.upload_from_filename(file_path)

            self.logger.info(f"Folder {path_to_folder} transferred to GCS bucket {bucket_name} in folder {destination_folder_name}")
        except Exception as e:
            self.logger.error('Error uploading folder: {}'.format(e))
            raise GCSUploadFolderError('Error uploading folder: {}'.format(e))

    def download_file(self, bucket_name, blob_name, destination_file_name):
        try:
            """Downloads a file from the given GCS path."""
            storage_client = storage.Client.from_service_account_json(self.gcs_connection_file_path)
            bucket = storage_client.get_bucket(bucket_name)
            blob = bucket.blob(blob_name)

            destination_dir = os.path.dirname(destination_file_name)

            common_utils.create_dir_if_not_exists(destination_dir, self.logger)
            if not os.path.exists(destination_dir):
                os.makedirs(destination_dir)

            blob.download_to_filename(destination_file_name)

            self.logger.info(f'Blob {blob_name} downloaded to {destination_file_name}.')
        except Exception as e:
            self.logger.error('Error downloading file: {}'.format(e))
            raise GCSDownloadFileError('Error downloading file: {}'.format(e))

    def create_resumable_upload(self, bucket_name, destination_path, chunk_size=None):
        """Creates a resumable upload session"""
        try:
            storage_client = storage.Client().from_service_account_json(self.gcs_connection_file_path)
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.blob(destination_path)
            if chunk_size:
                blob.chunk_size = chunk_size
            return blob.create_resumable_upload_session()
        except Exception as e:
            self.logger.error('Error creating resumable upload session: {}'.format(e))
            raise GCSResumableUploadError('Error creating resumable upload session: {}'.format(e))

    def upload_chunk(self, upload_session, chunk, offset):
        """Uploads a single chunk to GCS"""
        try:
            upload_session.transmit_chunk(chunk, offset)
        except Exception as e:
            self.logger.error('Error uploading chunk: {}'.format(e))
            raise GCSUploadChunkError('Error uploading chunk: {}'.format(e))

    @staticmethod
    def get_destination_path(destination_folder, source_name, date_suffix):
        """
            Constructs the final destination path for processed files in GCS.

            Args:
                destination_folder (str): Target folder for final files
                source_name (str): Name of the source/query being processed
                date_suffix (str): Date suffix for file naming (format: YYYYMMDD)

            Returns:
                str: Formatted destination path with .csv extension
                # dest_folder = destination_folder.strip('/')  # Remove trailing slashes for consistency
        """
        dest_folder = destination_folder
        if date_suffix:
            return f"{dest_folder}/{source_name.lower()}_{date_suffix}.csv"
        else:
            return f"{dest_folder}/{source_name.lower()}.csv"

    def list_files_in_working_dir(self, bucket_name, working_dir, source_name=None, date_suffix=None):
        """
            Lists all files in a GCS working directory with optional filtering by source and date.

            Args:
                bucket_name (str): Name of the GCS bucket
                working_dir (str): Directory to list files from
                source_name (str, optional): Filter by source name
                date_suffix (str, optional): Filter by date suffix

            Returns:
                list: List of GCS blob objects matching the criteria

            Raises:
                GCSUploadFolderError: If listing files fails
        """
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            # Build the prefix path progressively based on provided filters
            prefix = working_dir
            if source_name:
                prefix = f"{prefix}/{source_name.lower()}"
                if date_suffix:
                    prefix = f"{prefix}_{date_suffix}"

            blobs = list(bucket.list_blobs(prefix=prefix))
            self.logger.info(GCS_INFO_FILES_FOUND.format(len(blobs), prefix))
            return blobs

        except Exception as e:
            self.logger.error(GCS_ERROR_LIST_FILES.format(str(e)))
            raise GCSUploadFolderError(GCS_ERROR_LIST_FILES.format(str(e)))

    def copy_blob(self, bucket_name, source_blob, destination_path):
        """
            Copies blob(s) to a destination path, handling both single and multiple file cases.
            Supports composing multiple chunks into a single file, respecting GCS 32-blob limit.

            Args:
                bucket_name (str): Name of the GCS bucket
                source_blob (google.cloud.storage.blob.Blob or list): Source blob(s) to copy
                destination_path (str): Destination path in the bucket

            Returns:
                bool: True if copy successful

            Raises:
                GCSUploadFolderError: If copy operation fails
        """
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            destination_blob = bucket.blob(destination_path)

            if isinstance(source_blob, list):
                # Handle multiple files (chunks) case
                if len(source_blob) == 1:
                    # Single chunk case
                    destination_blob.rewrite(source_blob[0])
                elif len(source_blob) <= 32:
                    # Can compose directly if 32 or fewer blobs
                    destination_blob.compose(source_blob)
                else:
                    # For more than 32 blobs, need hierarchical composition
                    temp_blobs = []
                    temp_blob_names = []

                    # Step 1: Create intermediate compositions, each with up to 32 blobs
                    for i in range(0, len(source_blob), 32):
                        chunk = source_blob[i:i + 32]
                        temp_name = f"{destination_path}_temp_{i}"
                        temp_blob = bucket.blob(temp_name)
                        temp_blob_names.append(temp_name)

                        # Compose this batch into a temporary blob
                        temp_blob.compose(chunk)
                        temp_blobs.append(temp_blob)

                    # Step 2: Compose all temporary blobs into the final destination
                    # If we have more than 32 temp blobs, we'd need another level of composition
                    if len(temp_blobs) <= 32:
                        destination_blob.compose(temp_blobs)
                    else:
                        # Handle the rare case of needing multiple levels of composition
                        self.logger.warning(f"Large file composition: {len(temp_blobs)} intermediate blobs")
                        secondary_temps = []
                        secondary_names = []

                        # Create second-level temporary blobs
                        for j in range(0, len(temp_blobs), 32):
                            secondary_name = f"{destination_path}_secondary_{j}"
                            secondary_blob = bucket.blob(secondary_name)
                            secondary_names.append(secondary_name)

                            # Compose up to 32 first-level temps into a second-level temp
                            secondary_blob.compose(temp_blobs[j:j + 32])
                            secondary_temps.append(secondary_blob)

                        # Compose all second-level temps into the destination
                        destination_blob.compose(secondary_temps)

                        # Clean up second-level temporary blobs
                        for name in secondary_names:
                            bucket.blob(name).delete()

                    # Clean up first-level temporary blobs
                    for name in temp_blob_names:
                        bucket.blob(name).delete()
            else:
                # Single file case - direct copy
                destination_blob.rewrite(source_blob)

            self.logger.info(GCS_INFO_BLOB_COPIED.format(destination_path))
            return True

        except Exception as e:
            self.logger.error(GCS_ERROR_COPY_BLOB.format(str(e)))
            raise GCSUploadFolderError(GCS_ERROR_COPY_BLOB.format(str(e)))

    def verify_copy(self, bucket_name, source_blob, destination_path):
        """
            Verifies a copy operation by comparing MD5 hashes of source and destination.

            Args:
                bucket_name (str): Name of the GCS bucket
                source_blob (google.cloud.storage.blob.Blob): Source blob
                destination_path (str): Path to the destination blob

            Returns:
                bool: True if copy is verified successful, False otherwise
        """
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            destination_blob = bucket.blob(destination_path)
            if not destination_blob.exists():
                return False
            return destination_blob.md5_hash == source_blob.md5_hash

        except Exception as e:
            self.logger.error(GCS_ERROR_VERIFY_COPY.format(str(e)))
            return False

    def export_query_to_gcs(self, query_name, base_query, working_dir, date_suffix, bucket_name, replacements=None):
        """
            Exports BigQuery query results directly to GCS as CSV files.

            Args:
                query_name (str): Name of the query for identification
                base_query (str): Base SQL query template
                working_dir (str): Working directory for temporary files
                date_suffix (str): Date suffix for file naming
                bucket_name (str): Target GCS bucket name
                replacements (dict, optional): Key-value pairs for query parameter substitution

            Returns:
                google.cloud.bigquery.job.QueryJob: The submitted BigQuery job

            Raises:
                ApplicationError: If export fails
        """
        try:
            if date_suffix:
                working_path = f"{working_dir}/{query_name.lower()}_{date_suffix}"
            else:
                working_path = f"{working_dir}/{query_name.lower()}"

            self.logger.info(GCS_INFO_EXPORT_STARTED.format(query_name))

            formatted_query = base_query

            if replacements:
                for key, value in replacements.items():
                    formatted_query = formatted_query.replace(key, str(value))

            export_query = f"""
            EXPORT DATA
            OPTIONS(
                uri='gs://{bucket_name}/{working_path}-*.csv',
                format='CSV',
                overwrite=true,
                header=true,
                field_delimiter=',',
                compression='NONE'
            ) AS (
                {formatted_query}
            )
            """

            job = self.bigquery_client.query(export_query)
            self.logger.info(GCS_INFO_JOB_SUBMITTED.format(query_name))
            return job

        except Exception as e:
            error_msg = GCS_ERROR_EXPORT.format(query_name, str(e))
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)

    def wait_for_job(self, job, timeout_minutes=30):
        """
        Waits for a BigQuery job to complete
        Polls job status every 10 seconds until completion or timeout.

        Args:
            job (google.cloud.bigquery.job.QueryJob): BigQuery job to monitor
            timeout_minutes (int, optional): Maximum wait time in minutes. Defaults to 30.

        Returns:
            bool: True if job completes successfully

        Raises:
            ApplicationError: If job fails or times out
            TimeoutError: If job exceeds timeout period
        """
        try:
            # Get the current time in UTC to avoid timezone issues
            start_time = datetime.now(timezone.utc)

            while True:
                job.reload()  # Refresh job status
                if job.state == 'DONE':
                    if job.errors:
                        actual_error = GCS_ERROR_JOB_WAIT
                        error_msg = GCS_ERROR_JOB_WAIT.format(actual_error)
                        raise ApplicationError(error_msg)
                    return True

                # Check for timeout using UTC time
                if (datetime.now(timezone.utc) - start_time) > timedelta(minutes=timeout_minutes):
                    raise TimeoutError(f"Export timeout after {timeout_minutes} minutes")

                time.sleep(10)  # Wait 10 seconds before next check

        except Exception as e:
            actual_error = str(e)
            error_msg = GCS_ERROR_JOB_WAIT.format(actual_error)
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)

    def download_file_content(self, bucket_name, blob_path):
        """Download content of a file from GCS bucket."""
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            blob = bucket.blob(blob_path)
            return blob.download_as_string().decode('utf-8')
        except Exception as e:
            self.logger.error(GCS_ERROR_DOWNLOAD_CONTENT.format(str(e)))
            raise GCSDownloadFileError(GCS_ERROR_DOWNLOAD_CONTENT.format(str(e)))
        
    def download_single_file_content_with_prefix(self, bucket_name, prefix):
        """Download the content of the first file matching a prefix from a GCS bucket."""
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            # Get the first blob with a name starting with the given prefix
            blobs = bucket.list_blobs(prefix=prefix)
            first_blob = next(blobs, None)  # Get the first blob or None if no blobs are found

            if not first_blob:
                self.logger.error(f"No files found with prefix '{prefix}' in bucket '{bucket_name}'.")
                raise GCSDownloadFileError(f"No files found with prefix '{prefix}' in bucket '{bucket_name}'.")

            return first_blob.download_as_string().decode('utf-8')

        except Exception as e:
            self.logger.error(GCS_ERROR_DOWNLOAD_CONTENT.format(str(e)))
            raise GCSDownloadFileError(GCS_ERROR_DOWNLOAD_CONTENT.format(str(e)))