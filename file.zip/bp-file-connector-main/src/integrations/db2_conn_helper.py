import os

import ibm_db_dbi
from src.utils.errors.db2_errors import FetchDBError, InsertDBError, UpdateDBError, DeleteDBError, DatabaseError
from datetime import datetime, timezone
import yaml
import src.utils.app_config as app_config

def formatted_today(dateformat):
    """
    Get the today date time in specified format
    args - format date
    return - formatted date
    """
    now = datetime.now(timezone.utc)
    return now.strftime(dateformat)

def create_dir_if_not_exists(dir_name, log_instance=None):
    """
    create a directory if not exists in the server
    args - directory name ex -
           logger: logger object can be passed
                   logger.info method is used to log message
    return - None
    """

    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
        if log_instance:
            log_instance.info(f"Directory {dir_name} created")
        return 1

    else:
        if log_instance:
            log_instance.info(f"Directory {dir_name} exists already")
        return 0

class DB2IDatabase:

    def __init__(self, logger, key="db2_region"):
        self.logger = logger
        try:
            self._get_db_details(key)
            self.conn = self._make_connection()
            self.cursor = self.conn.cursor()
            self.logger = logger
        except Exception as e:
            raise DatabaseError(f"Error connecting to database: {e}")

    def _get_db_details(self, key):
        """
        Read database connection values from config file
        """

        db2_connection_file_path = app_config.get_config_value("app","db2_connection_file_path")

        with open(db2_connection_file_path, 'r') as file:
            config = yaml.full_load(file)

        db_config = config.get(key)

        if db_config:
            self.database = db_config.get('db2_database')
            self.hostname = db_config.get('db2_hostname')
            self.protocol = db_config.get('db2_protocol')
            self.userid = db_config.get('db2_userid')
            self.port = db_config.get('db2_port')
            self.ssl_client_label = db_config.get('db2_ssl_client_label')
            self.ssl_client_keystoredb = db_config.get('db2_ssl_client_keystoredb')
            self.ssl_client_keystash = db_config.get('db2_ssl_client_keystash')
            self.testset = db_config.get('db2_testset')
        else:
            self.logger.error(f"No configuration found for key {key}")

    def _make_connection(self):

        connection_string = (
            'DATABASE={0};'
            'HOSTNAME={1};'
            'PROTOCOL={2};'
            'UID={3};'
            'PORT={4};'
            'AUTHENTICATION=certificate;'
            'SSLClientLabel={5};'
            'SECURITY=ssl;'
            'SSLClientKeystoredb={6};'
            'SSLClientKeystash={7};'
            'isolation_level=READ UNCOMMITTED;'
        ).format(
            self.database,
            self.hostname,
            self.protocol,
            self.userid,
            self.port,
            self.ssl_client_label,
            self.ssl_client_keystoredb,
            self.ssl_client_keystash)

        return ibm_db_dbi.connect(connection_string, '', '')

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):

        try:
            self.cursor.close()
        except Exception as e:
            self.logger.error(f"Error closing cursor: {e}")
            raise DatabaseError("Error occurred during cursor closing connection")

        try:
            self.conn.close()
        except Exception as e:
            self.logger.error(f"Error closing connection: {e}")
            raise DatabaseError("Error occurred during connection closing connection")

    def fetch_chunk(self, query, chunk_size=1000, params=None):
        try:
            self.cursor.execute(query, params)
            while True:
                data = self.cursor.fetchmany(chunk_size)
                if not data:
                    break
                yield data
        except Exception as e:
            self.logger.error("Error while fetching data in fetch_chunk method : [%s]", {e})
            raise FetchDBError(f"Error fetching data from database: {e}")

    def fetchall(self, query, params=None):
        try:
            self.cursor.execute(query, params)
            return self.cursor.fetchall()
        except Exception as e:
            self.logger.error("Error fetching data from database:: [%s]", {e})
            raise FetchDBError(f"Error fetching data from database: {e}")

    def insert(self, query, params=None):
        try:
            self.cursor.execute(query, params)
        except Exception as e:
            self.logger.error("Error inserting data into database: [%s]", {e})
            raise InsertDBError(f"Error inserting data into database: {e}")

    def update(self, query, params=None):
        try:
            self.cursor.execute(query, params)
            return self.cursor.rowcount
        except Exception as e:
            self.logger.error("Error updating data in database: [%s]", {e})
            raise UpdateDBError(f"Error updating data in database: {e}")

    def delete(self, query, params=None):
        try:
            self.cursor.execute(query, params)
        except Exception as e:
            self.logger.error("Error deleting data from database: [%s]", {e})
            raise DeleteDBError(f"Error deleting data from database: {e}")

    def bulk_insert(self, table, columns, values):
        column_names = ', '.join(columns)
        placeholders = ', '.join(['?'] * len(columns))
        insert_query = f"INSERT INTO {table} ({column_names}) VALUES ({placeholders})"
        try:
            self.cursor.executemany(insert_query, values)
        except Exception as e:
            raise InsertDBError(f"Error inserting data into database: {e}")

    def update_many(self, query, params_list=None):
        try:
            self.cursor.executemany(query, params_list)
            return self.cursor.rowcount
        except Exception as e:
            self.logger.error(f"Error updating data in database: {e}")
            raise UpdateDBError(f"Error updating data in database: {e}")

    def commit_db(self):
        try:
            self.conn.commit()
        except Exception as e:
            self.logger.error("Error committing changes to the database:", str(e))
            self.conn.rollback()
            raise DatabaseError(f"Error occurred during commit transaction: {e}")

    def close_connection(self):

        if self.cursor:
            try:
                self.cursor.close()
                self.cursor = None
            except Exception as e:
                self.logger.error(f"Error closing cursor: {e}")
                raise DatabaseError(f"Error occurred during cursor closing cursor:  {e}")
        else:
            self.logger.info("DB cursor not open. Hence no closing of cursor is required")

        if self.conn:
            try:
                self.conn.close()
                self.conn = None
            except Exception as e:
                self.logger.error(f"Error closing connection: {e}")
                raise DatabaseError(f"Error occurred during connection closing connection:  {e}")
        else:
            self.logger.info("DB Connection not created. Hence no closing is required")