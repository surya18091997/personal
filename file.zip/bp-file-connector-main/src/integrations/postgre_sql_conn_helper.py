import psycopg2
import yaml

from src.constants import PG_CONNECTION_PATH, APP_NAME, PG_SQL_CONFIG, PG_CFG_CONN_ERROR, PG_CFG_HOSTNAME, \
    PG_CFG_DATABASE, PG_CFG_CURRENT_SCHEMA, PG_CFG_PORT, PG_CFG_USERNAME, PG_CFG_PASSWORD
from src.utils import app_config
from src.utils.errors.pgres_errors import PostgresConnectionError, PostgresQueryExecutionError, \
    PostgresNonQueryExecutionError, PostgresBulkInsertError


class PostgresGCPConnection:
    def __init__(self, logger):
        try:
            self.connected = False
            self.logger = logger
            self.create_connection()
        except Exception as e:
            raise PostgresConnectionError(f"Error connecting to database: {e}")

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        try:
            self.cursor.close()
        except Exception as e:
            self.logger.error(f"Error closing cursor: {e}")
            raise PostgresConnectionError("Error occurred during cursor closing connection")

    def create_connection(self):
        try:
            if self.connected:
                return

            postgres_sql_connection_file_path = app_config.get_config_value(APP_NAME, PG_CONNECTION_PATH)
            with open(postgres_sql_connection_file_path, 'r') as file:
                config = yaml.full_load(file)

            db_config = config.get(PG_SQL_CONFIG)

            if db_config:
                self.hostname = db_config.get(PG_CFG_HOSTNAME)
                self.username = db_config.get(PG_CFG_USERNAME)
                self.password = db_config.get(PG_CFG_PASSWORD)
                self.database = db_config.get(PG_CFG_DATABASE)
                self.current_schema = db_config.get(PG_CFG_CURRENT_SCHEMA)
                self.port = db_config.get(PG_CFG_PORT)
            else:
                self.logger.error(PG_CFG_CONN_ERROR)
                raise ConnectionError(PG_CFG_CONN_ERROR)

            self.connection = psycopg2.connect(
                database=self.database,
                user=self.username,
                password=self.password,
                host=self.hostname,
                port=self.port
            )
            self.cursor = self.connection.cursor()
            self.connected = True

            # Set the current schema
            self.connection.set_session(autocommit=True, isolation_level='read committed')
            self.connection.cursor().execute(f"SET search_path TO {self.current_schema}")

            self.logger.info("Connection to PostgresSQL DB successful")
        except Exception as e:
            self.logger.error(f"The error '{e}' occurred")
            raise PostgresConnectionError(f"Error connecting to database: {e}")

    def execute_query_with_fetchone(self, query, args=()):
        try:
            if query == "" or query is None:
                raise PostgresQueryExecutionError("Query is empty")
            self.cursor.execute(query, args)
            val = self.cursor.fetchone()[0]
            return val
        except Exception as e:
            raise PostgresQueryExecutionError(str(e))

    def execute_query(self, query, args=()):
        try:
            self.cursor.execute(query, args)
            rows = self.cursor.fetchall()
            return rows
        except Exception as e:
            raise PostgresQueryExecutionError(str(e))

    def execute_nonquery(self, query, args=()):
        try:
            self.cursor.execute(query, args)
            count = self.cursor.rowcount
            return count
        except Exception as e:
            raise PostgresNonQueryExecutionError(str(e))

    def bulk_insert(self, query, values):
        try:
            self.cursor.executemany(query, values)
            count = self.cursor.rowcount
            print(count, "Record inserted successfully into table")
        except Exception as error:
            if self.connection:
                print("Failed to insert record into table", error)
                raise PostgresBulkInsertError(str(error))

    def commit(self):
        if self.connection:
            self.connection.commit()

    def rollback(self):
        if self.connection:
            self.connection.rollback()

    def disconnect(self):
        if self.connection:
            self.connection.close()
            self.cursor.close()