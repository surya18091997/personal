import time
from datetime import datetime
import pandas as pd
from google.cloud import bigquery
from src.constants import (
    BIGQUERY_BATCH_ERROR, BIGQUERY_DATA_FETCH_ERROR, BIGQUERY_BATCH_START,
    BIGQUERY_PROCESSING_PROGRESS, BIGQUERY_DATAFRAME_CONVERSION,
    BIGQUERY_FILE_WRITE, BIGQUERY_BATCH_COMPLETE, BIGQUERY_FILE_GEN_START,
    BIGQUERY_ROW_LIMIT_REACHED,
    BIGQUERY_PROGRESS_SUMMARY, BIGQUERY_COMPLETION_SUMMARY, LIMIT_CLAUSE_TEMPLATE, BATCH_SIZE
)
from src.utils.errors.app_errors import ApplicationError
from src.utils.errors.db2_errors import DatabaseError
import src.utils.app_config as app_config
from src.utils.sql import WIN_SSN_MAPPING_GCP_QUERY


class BigQueryDatabase:
    """Handles all BigQuery database operations including batch processing"""

    def __init__(self, logger):
        """
           Initializes a new instance of the BigQueryDatabase class.

           Args:
               logger (logging.Logger): The logger instance.

           Raises:
               DatabaseError: If the BigQuery Credential JSON file path is not found.

           Returns:
               None
           """
        self.logger = logger
        self.logger.info("Inside BigQuery connection creation")
        self.client = None

        if app_config.get_config_value("app", "gcs_connection_file_path") is not None:
            self.bigquery_json_creds_path = app_config.get_config_value("app", "gcs_connection_file_path")
        else:
            self.logger.error("Error while getting to BigQuery Credential JSON file path")
            raise DatabaseError("Error while getting to BigQuery Credential JSON file path")
        self.conn = self._connect()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return self

    def _connect(self):
        try:
            self.logger.info("Inside BigQuery connection connect method")
            self.client = bigquery.Client.from_service_account_json(self.bigquery_json_creds_path)
            self.logger.info("BigQuery connection created")
        except Exception as e:
            self.logger.error(f"Error in connecting to BigQuery:,{e}")
            raise DatabaseError("Error connecting to big query database client") from e

    def execute(self, query, query_kwargs=None):
        if query_kwargs:
            query = query.format(**query_kwargs)
        job = self.client.query(query)
        return job

    def get_arr_from_sing_sel_query(self, query, query_kwargs=None):
        job = self.execute(query, query_kwargs)
        results = job.result()
        rows = [row[0] for row in results]
        return rows

    def get_df_from_query(self, query, query_kwargs=None, df_kwargs=None):
        job = self.execute(query, query_kwargs)
        result_dict = [dict(row) for row in job.result()]
        if df_kwargs:
            result_df = pd.DataFrame(data=result_dict, **df_kwargs)
        else:
            result_df = pd.DataFrame(data=result_dict)
        return result_df

    @staticmethod
    def format_time(seconds):
        """Format seconds into readable HH:MM:SS format."""
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

    def process_bigquery_batch(self, batch_params, query_template, replacements):
        """Process a single batch of BigQuery data.

        Args:
            batch_params (tuple): Contains (offset, is_first_batch, output_file)
            query_template (str): The query template to use
            replacements (dict): Query parameter replacements

        Returns:
            int: Number of records processed in this batch

        Raises:
            ApplicationError: If an error occurs during batch processing
        """
        # Extract parameters before try block to ensure they're available for error handling
        offset = batch_params[0]
        is_first_batch = batch_params[1]
        output_file = batch_params[2]
        batch_start_time = time.time()

        try:
            self.logger.info(BIGQUERY_BATCH_START.format(offset=offset))

            # Step 1: Execute query and get records
            records = self._execute_batch_query(query_template, replacements)
            if not records:
                self.logger.info(f"No records found for offset {offset}")
                return 0
            # Step 2: Create DataFrame from records
            df = self._create_batch_dataframe(records, batch_start_time)
            # Step 3: Write data to file
            self._write_batch_to_file(df, output_file, is_first_batch)
            # Step 4: Log completion metrics
            batch_time = time.time() - batch_start_time
            self._log_batch_metrics(df, batch_time)

            return len(df)

        except Exception as e:
            error_msg = BIGQUERY_BATCH_ERROR.format(offset=offset, error=str(e))
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)

    def _execute_batch_query(self, query_template, replacements):
        """Execute the BigQuery batch query.

        Args:
            query_template (str): The query template
            replacements (dict): Query parameter replacements containing all parameters
                               including offset

        Returns:
            list: Query results as list of dictionaries

        Raises:
            ApplicationError: If query execution fails
        """
        try:
            formatted_query = query_template
            for key, value in replacements.items():
                formatted_query = formatted_query.replace(key, str(value))

            query_job = self.client.query(formatted_query)
            return [dict(row.items()) for row in query_job.result()]
        except Exception as e:
            error_msg = f"Failed to execute BigQuery batch query: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg) from e

    def _create_batch_dataframe(self, records, batch_start_time):
        """Convert records to DataFrame with progress logging.

        Args:
            records (list): Query results
            batch_start_time (float): Start time of batch processing

        Returns:
            pandas.DataFrame: DataFrame containing the records

        Raises:
            ApplicationError: If DataFrame creation fails
        """
        try:
            total_records = len(records)

            # Log progress in 10k record increments
            for row_count in range(0, total_records, 10000):
                if row_count > 0:  # Skip first iteration
                    elapsed = time.time() - batch_start_time
                    rate = row_count / elapsed if elapsed > 0 else 0
                    self.logger.info(BIGQUERY_PROCESSING_PROGRESS.format(
                        rows=row_count,
                        rate=rate
                    ))

            self.logger.info(BIGQUERY_DATAFRAME_CONVERSION.format(records=total_records))
            return pd.DataFrame(records)
        except Exception as e:
            error_msg = f"Failed to create DataFrame from records: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg) from e

    def _write_batch_to_file(self, df, output_file, is_first_batch):
        """Write DataFrame to CSV file.

        Args:
            df (pandas.DataFrame): DataFrame to write
            output_file (str): Output file path
            is_first_batch (bool): Whether this is the first batch

        Raises:
            ApplicationError: If file writing fails
        """
        try:
            self.logger.info(BIGQUERY_FILE_WRITE)
            df.to_csv(
                output_file,
                mode='w' if is_first_batch else 'a',
                header=is_first_batch,
                index=False
            )
        except (IOError, OSError) as e:
            error_msg = f"Failed to write batch to file {output_file}: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg) from e
        except Exception as e:
            error_msg = f"Unexpected error while writing batch to file: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg) from e

    def _log_batch_metrics(self, df, batch_time):
        """Log batch completion metrics.

        Args:
            df (pandas.DataFrame): Processed DataFrame
            batch_time (float): Total processing time

        Raises:
            ApplicationError: If metrics logging fails
        """
        try:
            records_in_batch = len(df)
            rate = records_in_batch / batch_time if batch_time > 0 else 0
            self.logger.info(BIGQUERY_BATCH_COMPLETE.format(
                records=records_in_batch,
                time=self.format_time(batch_time),
                rate=rate
            ))
        except Exception as e:
            error_msg = f"Failed to log batch metrics: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg) from e

    def _log_batch_progress(self, total_records, start_time, row_limit):
        """Log progress information for batch processing."""
        elapsed = time.time() - start_time
        avg_speed = total_records / elapsed if elapsed > 0 else 0
        remaining = f"\n - Remaining records: {row_limit - total_records:,}" if row_limit else ""

        self.logger.info(BIGQUERY_PROGRESS_SUMMARY.format(
            total=total_records,
            elapsed=self.format_time(elapsed),
            speed=avg_speed,
            remaining=remaining
        ))

    @staticmethod
    def _get_row_limit(replacements):
        """Extract and parse row limit from replacements."""
        limit_clause = replacements.get('{limit_clause}', '')
        try:
            if limit_clause and 'LIMIT' in limit_clause:
                return int(limit_clause.split('LIMIT')[1].strip())
            return None
        except (ValueError, IndexError):
            return None

    def fetch_and_write_data(self, query_template, replacements, output_file, batch_size):
        """Fetch data from BigQuery in batches and write to file."""
        try:
            total_records = 0
            start_time = time.time()
            row_limit = self._get_row_limit(replacements)

            self.logger.info(BIGQUERY_FILE_GEN_START.format(
                timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ))

            if row_limit:
                self.logger.info(f"Row limit set to: {row_limit:,} records")

            while True:
                if row_limit and total_records >= row_limit:
                    self.logger.info(BIGQUERY_ROW_LIMIT_REACHED.format(limit=row_limit))
                    break

                current_batch_size = self._calculate_batch_size(batch_size, row_limit, total_records)
                offset = total_records

                replacements.update({
                    '@batch_size': str(current_batch_size),
                    '@offset': str(offset),
                    '{limit_clause}': LIMIT_CLAUSE_TEMPLATE.format(
                        batch_size=current_batch_size,
                        offset=offset
                    )
                })

                batch_result = self.process_bigquery_batch(
                    (offset, total_records == 0, output_file, None),
                    query_template,
                    replacements
                )

                if batch_result == 0:
                    break

                total_records += batch_result
                self._log_batch_progress(total_records, start_time, row_limit)

            self._log_completion_summary(total_records, start_time)
            return total_records

        except Exception as e:
            error_msg = BIGQUERY_DATA_FETCH_ERROR.format(error=str(e))
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)

    @staticmethod
    def _calculate_batch_size(batch_size, row_limit, total_records):
        """Calculate the appropriate batch size based on limits and progress."""
        if not row_limit:
            return batch_size
        remaining = row_limit - total_records
        return min(batch_size, remaining)

    def _log_completion_summary(self, total_records, start_time):
        """Log the completion summary with total records and processing speed."""
        total_time = time.time() - start_time
        self.logger.info(BIGQUERY_COMPLETION_SUMMARY.format(
            total=total_records,
            time=self.format_time(total_time),
            speed=total_records / total_time if total_time > 0 else 0
        ))

    def fetch_national_ids(self, win_numbers, gcp_project, bigquery_dataset):
        """
        Fetch National IDs for the given WIN numbers using BigQuery.
        Handles large lists by batching the requests to avoid query size limits.

        Args:
            win_numbers (list): List of WIN numbers to look up
            gcp_project (str): GCP project name
            bigquery_dataset (str): BigQuery dataset name

        Returns:
            dict: Mapping of WIN numbers to National IDs
        """
        try:
            # Create empty result dictionary
            win_to_national_id = {}

            batch_size = BATCH_SIZE

            # convert win numbers to strings
            win_numbers = [str(win) for win in win_numbers]

            # Process in batches
            for i in range(0, len(win_numbers), batch_size):
                batch = win_numbers[i:i + batch_size]

                # Format the WIN numbers for SQL query with quotes
                win_list_str = ",".join([f"{win}" for win in batch])

                # Skip empty batches
                if not win_list_str:
                    continue

                # Use aliasing to ensure column names are consistent
                formatted_query = WIN_SSN_MAPPING_GCP_QUERY.format(
                    gcp_project=gcp_project,
                    bigquery_dataset=bigquery_dataset,
                    win_list_str=win_list_str
                )

                self.logger.debug(f"Executing batch query for {len(batch)} WIN numbers")

                # Execute the query
                batch_df = self.get_df_from_query(formatted_query)

                if not batch_df.empty:
                    # Handle column name casing issues
                    if 'win_nbr' not in batch_df.columns or 'national_id' not in batch_df.columns:
                        available_columns = batch_df.columns.tolist()

                        # Try to find case-insensitive matches
                        win_col = next((col for col in available_columns if col.lower() == 'win_nbr'), None)
                        id_col = next((col for col in available_columns if col.lower() == 'national_id'), None)

                        if win_col and id_col:
                            # Update result dictionary with this batch
                            batch_results = dict(zip(batch_df[win_col].astype(str), batch_df[id_col].astype(str)))
                            win_to_national_id.update(batch_results)
                    else:
                        # Update result dictionary with this batch
                        batch_results = dict(zip(batch_df['win_nbr'].astype(str), batch_df['national_id'].astype(str)))
                        win_to_national_id.update(batch_results)

                self.logger.debug(f"Processed batch {i // batch_size + 1} with {len(batch)} WIN numbers")

            missing_count = len(win_numbers) - len(win_to_national_id)
            self.logger.info(
                f"Fetched {len(win_to_national_id)} National IDs for associates from GCP ({missing_count} missing)")

            # For any WIN numbers not found in the database, use a default placeholder
            for win in win_numbers:
                if win not in win_to_national_id:
                    win_to_national_id[win] = f"ID{win}"

            return win_to_national_id

        except Exception as e:
            self.logger.error(f"Error fetching National IDs from GCP: {str(e)}")

            # For testing purposes, create mock data instead of failing
            self.logger.warning("Creating mock national ID mapping due to error")
            return {str(win): f"ID{win}" for win in win_numbers}