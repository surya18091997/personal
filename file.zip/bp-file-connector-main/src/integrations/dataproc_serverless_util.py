import logging
import time
from typing import Dict, List, Optional

from google.cloud import dataproc_v1


class DataprocServerlessUtil:
    """Handles Dataproc Serverless batch job submissions with configurable options."""

    def __init__(self, project_id: str, region: str, logger: Optional[logging.Logger] = None):
        """
        Initialize the Dataproc Serverless utility.

        Args:
            project_id: GCP project ID
            region: GCP region for Dataproc
            logger: Logger instance for tracking operations
        """
        self.project_id = project_id
        self.region = region
        self.logger = logger or logging.getLogger(__name__)
        self.batch_client = dataproc_v1.BatchControllerClient(
            client_options={"api_endpoint": f"{region}-dataproc.googleapis.com:443"}
        )
        self.parent = f"projects/{project_id}/locations/{region}"

    def submit_batch(
            self,
            batch_id: str,
            main_jar_file_uri: Optional[str] = None,
            main_class: Optional[str] = None,
            main_python_file_uri: Optional[str] = None,
            jar_file_uris: Optional[List[str]] = None,
            python_file_uris: Optional[List[str]] = None,
            file_uris: Optional[List[str]] = None,
            archive_uris: Optional[List[str]] = None,
            args: Optional[List[str]] = None,
            runtime_version: str = "1.2",
            network: Optional[str] = None,
            subnetwork: Optional[str] = None,
            service_account: Optional[str] = None,
            container_image: Optional[str] = None,
            properties: Optional[Dict[str, str]] = None,
            labels: Optional[Dict[str, str]] = None,
            max_retries: int = 3,
            timeout_minutes: int = 60
    ):
        """
        Submit a Dataproc Serverless batch job with comprehensive configuration options.

        Args:
            batch_id: Unique identifier for the batch job
            main_jar_file_uri: URI of the main JAR file
            main_class: Main class for Java/Scala applications
            main_python_file_uri: URI of the main Python file
            jar_file_uris: List of additional JAR file URIs
            python_file_uris: List of additional Python file URIs
            file_uris: List of additional file URIs
            archive_uris: List of archive URIs
            args: Command line arguments for the job
            runtime_version: Dataproc runtime version
            network: VPC network
            subnetwork: VPC subnetwork
            service_account: Service account email
            container_image: Custom container image URI
            properties: Spark properties
            labels: Labels for the batch job
            max_retries: Maximum number of retry attempts
            timeout_minutes: Timeout in minutes for job completion

        Raises:
            Exception: If job submission fails or times out
        """
        try:
            # Construct the batch config
            batch = dataproc_v1.Batch()
            batch.environment_config = dataproc_v1.EnvironmentConfig()

            # Configure runtime configuration
            batch.runtime_config = dataproc_v1.RuntimeConfig()
            batch.runtime_config.version = runtime_version

            # Set execution config based on job type
            if main_python_file_uri:
                batch.pyspark_batch = dataproc_v1.PySparkBatch()
                batch.pyspark_batch.main_python_file_uri = main_python_file_uri
                if python_file_uris:
                    batch.pyspark_batch.python_file_uris = python_file_uris
            elif main_jar_file_uri:
                batch.spark_batch = dataproc_v1.SparkBatch()
                batch.spark_batch.main_jar_file_uri = main_jar_file_uri
                if main_class:
                    batch.spark_batch.main_class = main_class
                if jar_file_uris:
                    batch.spark_batch.jar_file_uris = jar_file_uris

            # Set common configurations
            if args:
                if main_python_file_uri:
                    batch.pyspark_batch.args = args
                else:
                    batch.spark_batch.args = args

            if file_uris:
                batch.environment_config.execution_config.file_uris = file_uris
            if archive_uris:
                batch.environment_config.execution_config.archive_uris = archive_uris

            # Network configuration
            if network or subnetwork:
                if network:
                    batch.environment_config.execution_config.network_uri = network
                if subnetwork:
                    batch.environment_config.execution_config.subnetwork_uri = subnetwork

            # Additional configurations
            if service_account:
                batch.environment_config.execution_config.service_account = service_account
            if container_image:
                batch.runtime_config.container_image = container_image
            if properties:
                batch.runtime_config.properties = properties
            if labels:
                batch.labels = labels

            # Submit the batch with retry logic
            operation = None
            for attempt in range(max_retries):
                try:
                    operation = self.batch_client.create_batch(
                        request={
                            "parent": self.parent,
                            "batch": batch,
                            "batch_id": batch_id,
                        }
                    )
                    break
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    self.logger.warning(f"Attempt {attempt + 1} failed: {str(e)}")
                    time.sleep(2 ** attempt)

            # Wait for job completion with timeout
            start_time = time.time()
            timeout_seconds = timeout_minutes * 60

            while True:
                if time.time() - start_time > timeout_seconds:
                    raise TimeoutError(f"Job {batch_id} timed out after {timeout_minutes} minutes")

                status = self.get_batch_status(batch_id)

                if status["state"] in ["SUCCEEDED"]:
                    self.logger.info(f"Job {batch_id} completed successfully")

                if operation.cancelled():
                    raise RuntimeError(f"Job {batch_id} was cancelled")

                # Check job status
                if status["state"] in ["FAILED", "ERROR", "CANCELLED"]:
                    raise RuntimeError(f"Job {batch_id} failed with state: {status['state']}")

                if operation.done():
                    break

                time.sleep(30)
                self.logger.info(f"Job {batch_id} is still running... State: {status['state']}")

            result = operation.result()

            if not result:
                raise RuntimeError(f"Job {batch_id} completed with no result")
            self.logger.info(result)

        except Exception as e:
            self.logger.error(f"Failed to submit/execute batch job: {str(e)}")
            raise

    def get_batch_status(self, batch_id: str) -> dict:
        """
        Get the status of a batch job.

        Args:
            batch_id: Batch job ID

        Returns:
            dict: Current status of the batch job
        """
        try:
            batch = self.batch_client.get_batch(name=f"{self.parent}/batches/{batch_id}")
            return {
                "state": batch.state.name,
                "create_time": batch.create_time,
                "uuid": batch.uuid,
            }
        except Exception as e:
            self.logger.error(f"Failed to get batch status: {str(e)}")
            raise