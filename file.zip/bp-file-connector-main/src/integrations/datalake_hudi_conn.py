import os
import json
import time
from datetime import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import src.utils.app_config as app_config
from src.utils.errors.db2_errors import DatabaseError
from src.utils.errors.gcs_errors import GCSHudiConnectionError
from src.constants import (
    APP_NAME, DATALAKE_INIT_START, DATALAKE_CONFIG_SUCCESS, DATALAKE_CLIENT_SUCCESS,
    DATALAKE_CLIENT_ERROR, DATALAKE_CONFIG_NOT_FOUND, DATALAKE_CONFIG_MISSING,
    DATALAKE_CONFIG_READ_ERROR, DATALAKE_QUERY_EXECUTION, DATALAKE_QUERY_RESULT,
    DATALAKE_QUERY_ATTEMPT_FAILED, DATALAKE_FETCH_ERROR, DATALAKE_DB_CONNECT_ERROR,
    DATALAKE_CONFIG_READ_PATH, DATALAKE_DB_CONFIG_ERROR, DATALAKE_MAX_RETRY_COUNT,
    DATALAKE_RETRY_DELAY, DATALAKE_SECRET_EXPIRED, APP_CFG_HUDI_CONNECTION_KEY,
    APP_CFG_GCS_HUDI_BUCKET, APP_CFG_GCS_HUDI_DATA_PATH, DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS
)


class DataLakeHudiUtils:
    def __init__(self, logger):
        """
        Initialize Spark session with Hudi configuration for GCS storage.
        Args:
            logger: Logger instance
        """
        self.logger = logger
        try:
            self.logger.info(DATALAKE_INIT_START)
            gcs_config = self._get_gcs_config()
            self.logger.info(DATALAKE_CONFIG_SUCCESS)

            # Initialize Spark session
            self.spark = SparkSession.builder \
                .appName("HudiDataReader") \
                .master("local[*]") \
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
                .config("spark.hadoop.google.cloud.auth.service.account.enable", "true") \
                .config("spark.hadoop.google.cloud.auth.service.account.json.keyfile", gcs_config['credentials_path']) \
                .config("spark.hadoop.fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem") \
                .config("spark.hadoop.fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS") \
                .config("spark.jars",
                        "/mnt/azure/dependency_jars/gcs-connector-hadoop3-latest.jar,"
                        " /mnt/azure/dependency_jars/hudi-spark3.5-bundle_2.12-0.15.0.jar") \
                .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension") \
                .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.hudi.catalog.HoodieCatalog") \
                .getOrCreate()

            self.spark._jsc.hadoopConfiguration().set('fs.gs.impl',
                                                      'com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem')
            self.spark._jsc.hadoopConfiguration().set('fs.AbstractFileSystem.gs.impl', 'com.google.cloud.hadoop.fs.gcs'
                                                                                       '.GoogleHadoopFileSystem')

            self.bucket_name = gcs_config['bucket_name']
            self.hudi_data_path = gcs_config['hudi_data_path']
            self.logger.info(DATALAKE_CLIENT_SUCCESS)

        except Exception as e:
            self.logger.error(DATALAKE_CLIENT_ERROR.format(str(e)))
            raise

    def _get_gcs_config(self):
        """
        Get GCS configuration from app_config.

        Returns:
            dict: Configuration for GCS
        """
        try:
            gcs_credentials_path = app_config.get_config_value(APP_NAME, APP_CFG_HUDI_CONNECTION_KEY)
            bucket_name = app_config.get_config_value(APP_NAME, APP_CFG_GCS_HUDI_BUCKET)
            hudi_data_path = app_config.get_config_value(APP_NAME, APP_CFG_GCS_HUDI_DATA_PATH)

            if gcs_credentials_path is None or bucket_name is None:
                error_msg = DATALAKE_CONFIG_MISSING
                self.logger.error(error_msg)
                raise GCSHudiConnectionError(error_msg)

            self.logger.info(DATALAKE_CONFIG_READ_PATH.format(gcs_credentials_path))

            if not os.path.exists(gcs_credentials_path):
                error_msg = DATALAKE_CONFIG_NOT_FOUND.format(gcs_credentials_path)
                self.logger.error(error_msg)
                raise GCSHudiConnectionError(error_msg)

            with open(gcs_credentials_path, 'r') as f:
                gcs_config = json.load(f)

            # Extract expiry date if applicable
            if 'expiryDate' in gcs_config:
                expiry_date = datetime.strptime(gcs_config['expiryDate'], DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS)
                if expiry_date <= datetime.now():
                    self.logger.error(DATALAKE_SECRET_EXPIRED)
                    raise GCSHudiConnectionError(DATALAKE_SECRET_EXPIRED)

            config = {
                'credentials_path': gcs_credentials_path,
                'bucket_name': bucket_name,
                'hudi_data_path': hudi_data_path
            }

            return config

        except Exception as e:
            self.logger.error(DATALAKE_CONFIG_READ_ERROR.format(str(e)))
            raise GCSHudiConnectionError(DATALAKE_DB_CONFIG_ERROR.format(e))


    def read_hudi_snapshot(self, table_path):
        """
        Read the latest snapshot of Hudi table data.

        Args:
            table_path (str): Path to the Hudi table in GCS

        Returns:
            DataFrame: Spark DataFrame containing the table data

        Raises:
            DatabaseError: If reading fails
        """
        retry_count = 0

        while retry_count < DATALAKE_MAX_RETRY_COUNT:
            try:
                full_path = f"gs://{self.bucket_name}/{table_path}"
                self.logger.info(DATALAKE_QUERY_EXECUTION.format(f"Reading snapshot from {full_path}"))

                # Read the latest snapshot
                df = self.spark.read.format("hudi").load(full_path)

                row_count = df.count()
                self.logger.info(DATALAKE_QUERY_RESULT.format(row_count))
                return df

            except Exception as e:
                retry_count += 1
                self.logger.error(DATALAKE_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < DATALAKE_MAX_RETRY_COUNT:
                    time.sleep(DATALAKE_RETRY_DELAY)
                    continue
                raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))

    def read_hudi_incremental(self, table_path, begin_timestamp):
        """
        Read incremental data from Hudi table.

        Args:
            table_path (str): Path to the Hudi table in GCS
            begin_timestamp (str): Beginning timestamp for incremental data

        Returns:
            DataFrame: Spark DataFrame containing incremental data

        Raises:
            DatabaseError: If reading fails
        """
        retry_count = 0

        while retry_count < DATALAKE_MAX_RETRY_COUNT:
            try:
                full_path = f"gs://{self.bucket_name}/{table_path}"
                self.logger.info(DATALAKE_QUERY_EXECUTION.format(f"Reading incremental data from {full_path} since {begin_timestamp}"))

                # Read incremental data
                df = self.spark.read.format("hudi") \
                    .option("hoodie.datasource.query.type", "incremental") \
                    .option("hoodie.datasource.read.begin.instanttime", begin_timestamp) \
                    .load(full_path)

                row_count = df.count()
                self.logger.info(DATALAKE_QUERY_RESULT.format(row_count))
                return df

            except Exception as e:
                retry_count += 1
                self.logger.error(DATALAKE_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < DATALAKE_MAX_RETRY_COUNT:
                    time.sleep(DATALAKE_RETRY_DELAY)
                    continue
                raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))

    def read_hudi_point_in_time(self, table_path, as_of_instant):
        """
        Read Hudi data as of a specific point in time.

        Args:
            table_path (str): Path to the Hudi table in GCS
            as_of_instant (str): Instant time to read data

        Returns:
            DataFrame: Spark DataFrame containing data as of the specified time

        Raises:
            DatabaseError: If reading fails
        """
        retry_count = 0

        while retry_count < DATALAKE_MAX_RETRY_COUNT:
            try:
                full_path = f"gs://{self.bucket_name}/{table_path}"
                self.logger.info(DATALAKE_QUERY_EXECUTION.format(f"Reading data from {full_path} as of {as_of_instant}"))

                # Read data at a point in time
                df = self.spark.read.format("hudi") \
                    .option("as.of.instant", as_of_instant) \
                    .load(full_path)

                row_count = df.count()
                self.logger.info(DATALAKE_QUERY_RESULT.format(row_count))
                return df

            except Exception as e:
                retry_count += 1
                self.logger.error(DATALAKE_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < DATALAKE_MAX_RETRY_COUNT:
                    time.sleep(DATALAKE_RETRY_DELAY)
                    continue
                raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))


    def get_hudi_data(self, table_name, select_clause, where_clause):
        """
        Query Hudi data with projection and filtering.

        Args:
            table_path (str): Path to the Hudi table in GCS
            columns (list, optional): List of columns to select
            where_clause (str, optional): WHERE clause for filtering

        Returns:
            DataFrame: Spark DataFrame containing the query results

        Raises:
            DatabaseError: If query execution fails
        """
        retry_count = 0

        while retry_count < DATALAKE_MAX_RETRY_COUNT:
            try:
                full_path = f"gs://{self.bucket_name}/{self.hudi_data_path}/{table_name}"

                # Construct query
                df = self.spark.read.format("hudi").load(full_path)

                # Create a temporary view from your dataframe
                df.createOrReplaceTempView("hudi_table_data")

                # Query it with spark.sql, selecting required fields and applying a WHERE filter
                #sample query = "SELECT id, associateId FROM hudi_table_data WHERE associateId = '123456789'"

                query = f"SELECT {select_clause} FROM hudi_table_data WHERE {where_clause}"
                query_df = self.spark.sql(query)

                # convert data into pandas dataframe and return
                pandas_df = query_df.toPandas()
                self.logger.info(DATALAKE_QUERY_RESULT.format(len(pandas_df)))
                return pandas_df

            except Exception as e:
                retry_count += 1
                self.logger.error(DATALAKE_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < DATALAKE_MAX_RETRY_COUNT:
                    time.sleep(DATALAKE_RETRY_DELAY)
                    continue
                raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))

    def get_hudi_data_with_dataframe_filter(self, table_name, select_clause, filter_df, filter_column, chunk_size=1000):
        """
        Query Hudi data with projection and filtering based on an input DataFrame.

        Args:
            table_name (str): Name of the Hudi table in GCS.
            select_clause (str): Fields to select from the table.
            filter_df (DataFrame): Pandas DataFrame containing filter data.
            filter_column (str): Column in the Hudi table to filter against.
            chunk_size (int): Number of rows to process in each chunk.

        Returns:
            DataFrame: Pandas DataFrame containing the combined query results.

        Raises:
            DatabaseError: If query execution fails.
        """
        try:
            # Convert the filter DataFrame to a list of unique values
            filter_values = filter_df[filter_column].unique().tolist()

            # Split the filter values into chunks
            chunks = [filter_values[i:i + chunk_size] for i in range(0, len(filter_values), chunk_size)]

            combined_results = []

            for chunk in chunks:
                # Construct the WHERE clause for the current chunk
                chunk_filter = ', '.join([f"'{value}'" for value in chunk])
                where_clause = f"{filter_column} IN ({chunk_filter})"

                # Query the Hudi table for the current chunk
                full_path = f"gs://{self.bucket_name}/{self.hudi_data_path}/{table_name}"
                df = self.spark.read.format("hudi").load(full_path)
                df.createOrReplaceTempView("hudi_table_data")

                query = f"SELECT {select_clause} FROM hudi_table_data WHERE {where_clause}"
                query_df = self.spark.sql(query)

                # Convert the Spark DataFrame to Pandas and append to results
                combined_results.append(query_df.toPandas())

            # Combine all chunk results into a single Pandas DataFrame
            final_result = pd.concat(combined_results, ignore_index=True)
            self.logger.info(DATALAKE_QUERY_RESULT.format(len(final_result)))

            return final_result

        except Exception as e:
            self.logger.error(DATALAKE_FETCH_ERROR.format(str(e)))
            raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))


    def get_hudi_table_schema(self, table_path):
        """
        Get the schema of a Hudi table.

        Args:
            table_path (str): Path to the Hudi table in GCS

        Returns:
            StructType: Schema of the Hudi table

        Raises:
            DatabaseError: If schema retrieval fails
        """
        retry_count = 0

        while retry_count < DATALAKE_MAX_RETRY_COUNT:
            try:
                full_path = f"gs://{self.bucket_name}/{table_path}"
                self.logger.info(DATALAKE_QUERY_EXECUTION.format(f"Getting schema from {full_path}"))

                # Get schema without loading all data
                df = self.spark.read.format("hudi").load(full_path).limit(1)
                schema = df.schema

                self.logger.info(DATALAKE_QUERY_RESULT.format("Schema retrieved successfully"))
                return schema

            except Exception as e:
                retry_count += 1
                self.logger.error(DATALAKE_QUERY_ATTEMPT_FAILED.format(retry_count, str(e)))
                if retry_count < DATALAKE_MAX_RETRY_COUNT:
                    time.sleep(DATALAKE_RETRY_DELAY)
                    continue
                raise DatabaseError(DATALAKE_FETCH_ERROR.format(e))

    def close(self):
        """
        Stop the Spark session.
        """
        if hasattr(self, 'spark') and self.spark:
            self.spark.stop()

