from contextlib import suppress

from src.integrations.gcs_utils import GCSUtils
from src.utils.common_utils import create_dir_if_not_exists
from src.utils.errors.app_errors import ApplicationErrorMessage, ApplicationError
from src.utils.errors.gcs_errors import GCSUploadChunkError
from src.utils.sftp_helper import SftpHelper
import shutil
import os
import time
from src.constants import ROOT_DIR, GCS_CONNECTION_UPLOAD_SETTINGS, APP_NAME, GCS_CHUNK_SIZE, GCS_RETRY_INITIAL, \
    GCS_RETRY_MAXIMUM, GCS_RETRY_MULTIPLIER, GCS_UPLOAD_TIMEOUT, GCS_CHUNK_SIZE_VALUE, GCS_RETRY_INITIAL_VALUE, \
    GCS_RETRY_MAXIMUM_VALUE, GCS_RETRY_MULTIPLIER_VALUE, GCS_UPLOAD_TIMEOUT_VALUE, FOLDER_TRANSFERRED_TO_GCS, \
    STANDARD_GCS_UPLOAD, FILE_TRANSFER_TO_GCS, FAIL_OVER_TO_CHUNK_GCS_UPLOAD, \
    ERROR_GCS_UPLOAD, \
    STANDARD_GCS_UPLOAD_COMPLETED, CHUNK_GCS_UPLOAD, BINARY_READ_MODE, CHUNK_GCS_UPLOAD_COMPLETED, \
    START_SFTP_TRANSFER, ERROR_SFTP_TRANSFER, \
    START_AZURE_TRANSFER, FILE_TRANSFER_SUCCESS, FILE_TRANSFER_ERROR, MAX_UPLOAD_RETRIES, CHUNK_UPLOAD_RETRY_MSG, \
    UPLOAD_RETRY_DELAY, UPLOAD_CHUNK_LOG_FREQUENCY, CHUNK_UPLOAD_PROGRESS_MSG, START_SFTP_UPLOAD, ERROR_SFTP_UPLOAD
import src.utils.app_config as app_config
from google.api_core.exceptions import GoogleAPIError
from datetime import datetime

class file_transfer:

    def __init__(self, logger):
        self.sftp_connection = None
        self.logger = logger
        self.gcs_connection = GCSUtils(logger)
        gcs_settings = app_config.get_config_value(APP_NAME, GCS_CONNECTION_UPLOAD_SETTINGS) or {}
        self.chunk_size = int(gcs_settings.get(GCS_CHUNK_SIZE, GCS_CHUNK_SIZE_VALUE)) #5MB Default Chuck size
        self.retry_initial = float(gcs_settings.get(GCS_RETRY_INITIAL, GCS_RETRY_INITIAL_VALUE))
        self.retry_maximum = float(gcs_settings.get(GCS_RETRY_MAXIMUM, GCS_RETRY_MAXIMUM_VALUE))
        self.retry_multiplier = float(gcs_settings.get(GCS_RETRY_MULTIPLIER, GCS_RETRY_MULTIPLIER_VALUE))
        self.upload_timeout = int(gcs_settings.get(GCS_UPLOAD_TIMEOUT, GCS_UPLOAD_TIMEOUT_VALUE))

    """
    Transfers a folder from local storage to a GCS bucket.
    Args:
        local_folder_path (str): The path to the local folder.
        bucket_name (str): The name of the GCS bucket.
        destination_folder_name (str): The name of the folder in the GCS bucket.
        credentials_path (str): The path to the GCS credentials JSON file.

    """

    def transfer_folder_to_gcs(self, local_folder_path, bucket_name, destination_folder_name):

        self.gcs_connection.upload_folder(bucket_name, destination_folder_name, local_folder_path)
        self.logger.info(FOLDER_TRANSFERRED_TO_GCS.format(local_folder_path=local_folder_path, bucket_name = bucket_name))

    """
        Uploads a file to Google Cloud Storage (GCS) with automatic fallback to chunked upload.
        First attempts a standard upload, and if that fails, automatically falls back to a chunked upload approach.

        Args:
            bucket_name (str): The name of the GCS bucket where the file will be uploaded
            source_folder_path (str): Local directory path containing the file to be uploaded
            destination_folder_path (str): Target directory path within the GCS bucket
            destination_file_name (str): Name of the file to be uploaded (same for source and destination)

        Raises:
            GoogleAPIError: When there are issues with GCS API operations
            MemoryError: When system runs out of memory during upload
            IOError: When there are input/output related issues
            Exception: For any other unexpected errors during both standard and chunked uploads
    """
    def transfer_file_to_gcs(self, bucket_name, source_folder_path, destination_folder_path, destination_file_name):

        if destination_folder_path.endswith('backup/'):
            current_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            destination_file_name_bkp = f"{destination_file_name}_{current_timestamp}"
            destination_file_path = os.path.join(destination_folder_path, destination_file_name_bkp)
            source_file_path = os.path.join(source_folder_path, destination_file_name)
        else:
            destination_file_path = os.path.join(destination_folder_path, destination_file_name)
            source_file_path = os.path.join(source_folder_path, destination_file_name)

        self.logger.info(STANDARD_GCS_UPLOAD.format(destination_file_path=destination_file_path))

        # Try standard upload first - suppress specific errors to allow fallback
        with suppress(GoogleAPIError, MemoryError, IOError, TimeoutError):
            self._transfer_file_to_gcs_standard(bucket_name, source_file_path, destination_file_path)
            self.logger.info(FILE_TRANSFER_TO_GCS.format(
                destination_file_path=destination_file_path,
                bucket_name=bucket_name
            ))
            return

        # If standard upload failed, try chunked upload
        self.logger.info(FAIL_OVER_TO_CHUNK_GCS_UPLOAD)
        try:
            self._transfer_file_to_gcs_in_chunks(bucket_name, source_file_path, destination_file_path)
            self.logger.info(FILE_TRANSFER_TO_GCS.format(
                destination_file_path=destination_file_path,
                bucket_name=bucket_name
            ))
        except Exception as e:
            error_msg = ERROR_GCS_UPLOAD.format(
                error_message=str(e),
                chunk_error=str(e)
            )
            self.logger.error(error_msg)
            raise ApplicationErrorMessage(error_msg)

    """
        Performs a standard (non-chunked) upload to GCS. This method is suitable for smaller files
        or when memory constraints are not an issue.

        Args:
            bucket_name (str): Target GCS bucket name
            source_file_path (str): Complete local path to the source file
            destination_file_path (str): Complete path where the file will be stored in GCS

        Internal Method:
            Prefixed with underscore (_) as it's intended for internal use by transfer_file_to_gcs

        Technical Details:
            - Uses GCS connection's upload_file method for direct upload
            - No file size limitations enforced
            - Entire file is loaded into memory during upload

    """
    def _transfer_file_to_gcs_standard(self, bucket_name, source_file_path, destination_file_path):
        self.logger.info(STANDARD_GCS_UPLOAD.format(destination_file_path=destination_file_path))
        self.gcs_connection.upload_file(
            bucket_name,
            destination_file_path,
            source_file_path
        )
        self.logger.info(STANDARD_GCS_UPLOAD_COMPLETED)

    """
        Performs a chunked upload to GCS, breaking the file into smaller pieces.
        This method is ideal for large files or when memory usage needs to be controlled.

        Args:
            bucket_name (str): Target GCS bucket name
            source_file_path (str): Complete local path to the source file
            destination_file_path (str): Complete path where the file will be stored in GCS

        Technical Details:
            - Uses 'rb' (read binary) mode for file opening:
            - chunk_size: Defined in CCM, default size is 5MB
            - Progress logging: Every 100MB of upload
            - Retry mechanism: 1-second delay between retries
            - File size calculation: Uses os.path.getsize for progress percentage

        Memory Management:
            - Only one chunk is loaded into memory at a time
            - chunk_size determines maximum memory usage per chunk
            - File handle is properly closed using 'with' context
    """

    def _transfer_file_to_gcs_in_chunks(self, bucket_name, source_file_path, destination_file_path):
        """Performs a chunked upload to GCS."""
        try:
            file_size = os.path.getsize(source_file_path)
            self.logger.info(CHUNK_GCS_UPLOAD)

            upload_session = self.gcs_connection.create_resumable_upload(
                bucket_name,
                destination_file_path,
                chunk_size=self.chunk_size
            )

            with open(source_file_path, BINARY_READ_MODE) as f:
                uploaded = 0
                while True:
                    chunk = f.read(self.chunk_size)
                    if not chunk:
                        break

                    chunk_size = self._upload_chunk_with_retry(upload_session, chunk, uploaded, file_size)
                    uploaded += chunk_size

            self.logger.info(CHUNK_GCS_UPLOAD_COMPLETED)

        except Exception as e:
            error_msg = f"Error in chunked upload: {str(e)}"
            self.logger.error(error_msg)
            raise GCSUploadChunkError(error_msg)

    def _log_upload_progress(self, uploaded, file_size):
        """Log upload progress for large files."""
        if uploaded % UPLOAD_CHUNK_LOG_FREQUENCY == 0:
            progress = (uploaded / file_size) * 100
            self.logger.info(CHUNK_UPLOAD_PROGRESS_MSG.format(
                uploaded=uploaded,
                percentage=progress
            ))

    def _upload_chunk_with_retry(self, upload_session, chunk, uploaded, file_size):
        """Handle chunk upload with retry logic."""
        retry_count = 0

        while retry_count < MAX_UPLOAD_RETRIES:
            try:
                upload_session.transmit_chunk(chunk, uploaded)
                self._log_upload_progress(uploaded, file_size)
                return len(chunk)
            except Exception as e:
                retry_count += 1
                if retry_count == MAX_UPLOAD_RETRIES:
                    raise
                self.logger.warning(CHUNK_UPLOAD_RETRY_MSG.format(error_message=str(e)))
                time.sleep(UPLOAD_RETRY_DELAY)
        return 0

    """
    Downloads files from the mainframe server to a specified directory.

    Args:
        source_file_path (str): The path to the files on the mainframe server.
        request_id_dir (str): The directory to save the downloaded files.
        destination_file_name (str): The name to save the downloaded files.

    Raises:
        Exception: If an error occurs during the file transfer.
    """
    def transfer_file_from_mainframe(self, source_file_path, request_id_dir, destination_file_name):
        try:
            self.logger.info(START_SFTP_TRANSFER)
            self.sftp_connection = SftpHelper(self.logger)
            self.sftp_connection.download_files(source_file_path, request_id_dir, destination_file_name)
        except Exception as e:
            self.logger.error(ERROR_SFTP_TRANSFER.format(error_message=str(e)))

    """
       Uploads a file to the mainframe server.

       Args:
           dest_file_path_mf (str): The path to the file on mainframe server
           request_id_dir (str): The directory where the file is located.
           dest_file (str): The name of the file to be uploaded.

       Raises:
           Exception: If there is an error uploading the file.
    """
    def transfer_to_mainframe(self, dest_file_path_mf, request_id_dir, dest_file):
        try:
            self.logger.info(START_SFTP_UPLOAD)
            self.sftp_connection = SftpHelper(self.logger)
            self.sftp_connection.upload_file_to_mainframe(dest_file_path_mf, request_id_dir, dest_file)
        except Exception as e:
            self.logger.error(ERROR_SFTP_UPLOAD.format(error_message=str(e)))
            raise ApplicationError(ERROR_SFTP_UPLOAD.format(error_message=str(e)))

    """
    Initiates the transfer of a file to the destination directory within Azure.

    Args:
        source (str): The source directory of the file.
        destination (str): The destination directory within Azure.
        destination_file_name (str): The name of the file to be transferred.

    Raises:
        Exception: If there is an error copying the file.

    Returns:
        None
    """
    def transfer_to_azure_directory(self, source, destination, destination_file_name):
        self.logger.info(START_AZURE_TRANSFER)
        try:
            # Get the full path of the source file
            source_file_path = os.path.join(source,destination_file_name)
            # Create the parent directory of the destination file
            create_dir_if_not_exists(destination, self.logger)
            # Get the full path of the destination file append the azure mount
            destination_file_path = os.path.join(ROOT_DIR, destination, destination_file_name)
            # Copy the file
            shutil.copyfile(source_file_path, destination_file_path)
            self.logger.info(FILE_TRANSFER_SUCCESS.format(source_file_path=source_file_path, destination_file_path=destination_file_path))
        except Exception as e:
            self.logger.error(FILE_TRANSFER_ERROR.format(source_file_path=source, destination_file_path=destination,error_message=str(e)))
            raise ApplicationError(FILE_TRANSFER_ERROR.format(source_file_path=source, destination_file_path=destination,error_message=str(e)))





