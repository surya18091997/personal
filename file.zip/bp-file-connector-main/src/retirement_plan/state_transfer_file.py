import datetime
import pandas as pd

from src.constants import F_COMPLETED, F_ERROR, FG_EMPTY_FILE_INFO
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError
from src.utils.sql import (STATE_TRANSFER_TO_US, STATE_TRANSFER_TO_PR)


class StateTransfer(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        super().__init__(configuration_id, logger, request_id, start_date, end_date)

    """"
        1. Working directory checkups
        2. Fetch Driving query -> generate query based on config Id and call cosmos executor from file_gen.py
        3. Fetch the eligible transfers from the driving query df
        4. Filter based on US & PR (config_Id)
        5. Fetch Core_HR + BQ data (combine this into one function in file_gen.py)
        6. Process the data frame => column level adjustments
        7. Extract the df_dic generator as separate method
        8. Apply state_transfer specific rules
        9. Extract file generation as separate method and Call it
        10. Transfer the files to GCS bucket
        11. Transfer the file to mainframe
    """""

    def start_process(self):
        try:
            # Step1  : working_dir setup
            self.create_working_directory(self.request_id)
            # Step2  : fetch the transfers list from transaction logs
            transfers_associate_list = self.get_transaction_logs()
            # Step3  : get the eligible transfers(US-PR or PR-US) from all transfers
            eligible_associate_transfers = self.eligible_state_transfers(transfers_associate_list, self.start_date,self.end_date)
            # Step4  : get the associate data
            associate_info_df = self.get_associate_info(eligible_associate_transfers)

            # Check if dataframe is empty
            if associate_info_df.empty:
                self.logger.info(FG_EMPTY_FILE_INFO)
                # Create empty record dict for header/trailer generation
                record_dict = {}
            else:
                # Step5  : process the dataframe
                associate_info_df = self.process_core_hr_df(associate_info_df)

                # Convert eligible_associate_transfers to string to match associate_info_df
                eligible_associate_transfers_str = [str(assoc_id) for assoc_id in eligible_associate_transfers]
                associate_info_df['WIN_NBR'] = associate_info_df['WIN_NBR'].astype(str)

                # Step6  : generate the dict - now with consistent data types
                record_dict = self.generate_record_dict(associate_info_df, eligible_associate_transfers_str)

            # Step7  : apply plan details using base class method
            record_dict = self.apply_plan_detail_attributes(record_dict)

            # Step7a: Fetch experience years and eligible hours data
            experience_years_df = self.fetch_experience_years(eligible_associate_transfers)
            eligible_hours_term_df = self.fetch_eligible_hours(eligible_associate_transfers)

            # Step7b: Apply state transfer specific updates
            record_dict = self.apply_state_transfer_specific_updates(record_dict, experience_years_df,
                                                                     eligible_hours_term_df)

            # Step8  : generate the files
            self.initiate_flat_file_generation(record_dict)
            # Step9  : transfer the files within Azure
            self.transfer_file_to_azure_directory()
            # Step10  : transfer the files to GCS bucket
            self.transfer_file_to_gcs()
            # Step11  : transfer the file to mainframe
            self.transfer_file_to_mainframe()
            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(f"Failed during file generation: {str(e)}", exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

    def apply_state_transfer_specific_updates(self, record_dict, experience_years_df=None, eligible_hours_term_df=None):
        """
        Apply state transfer specific updates including R05-YEARS-OF-SERVICE and R05-HOURS-SERVICE.
        EXACTLY THE SAME PATTERN AS TERM FILE - update_plan_specific_data_term method.
        """
        try:
            # Update r05 records
            if 'r05' in record_dict:
                record_dict['r05']['associate_id'] = record_dict['r05']['associate_id'].astype(str)

                # Update experience years if available
                if experience_years_df is not None and not experience_years_df.empty:
                    experience_years_df['WIN_NBR'] = experience_years_df['WIN_NBR'].astype(str)
                    record_dict['r05'].set_index('associate_id', inplace=True)
                    experience_years_df.set_index('WIN_NBR', inplace=True)
                    columns_to_update = ['R05-YEARS-OF-SERVICE']
                    record_dict['r05'].update(experience_years_df[columns_to_update])
                    record_dict['r05'].reset_index(inplace=True)
                    experience_years_df.reset_index(inplace=True)
                    self.logger.info(f"Updated {len(experience_years_df)} records with years of service data")

                # Update eligible hours
                if eligible_hours_term_df is not None:
                    if not eligible_hours_term_df.empty:
                        columns_to_update = ['R05-HOURS-SERVICE']
                        if all(col in eligible_hours_term_df.columns for col in columns_to_update):
                            eligible_hours_term_df['associateId'] = eligible_hours_term_df['associateId'].astype(str)
                            eligible_hours_term_df.set_index('associateId', inplace=True)
                            record_dict['r05'].set_index('associate_id', inplace=True)
                            record_dict['r05'].update(eligible_hours_term_df[columns_to_update])
                            record_dict['r05'].reset_index(inplace=True)
                            eligible_hours_term_df.reset_index(inplace=True)
                            self.logger.info(f"Updated {len(eligible_hours_term_df)} records with eligible hours data")
                        else:
                            self.logger.error(f"Columns {columns_to_update} are missing in eligible_hours_term_df.")
                            self.logger.debug(f"Available columns: {eligible_hours_term_df.columns.tolist()}")
                    else:
                        self.logger.error("No eligible hours data found. Skipping update for 'R05-HOURS-SERVICE'.")

            return record_dict

        except Exception as e:
            self.logger.error(f"Error applying state transfer specific updates: {e}", exc_info=True)
            raise

    """
    Retrieves the eligible state transfers from the specified DB2 collection based on the associate list and date range.
    Args:
        associate_list (str): The name of the Cosmos DB database.
        start_date (str): The name of the Cosmos DB collection.
        end_date (dict): The projection parameters for the query.    
    Returns:
        str: A concatenated string of associate transfer list 
    """

    def eligible_state_transfers(self, associate_list, start_date, end_date):
        associate_list = ",".join([f"'{win}'" for win in associate_list])
        # TODO maintain a CCM config for state_transfer and get it from app_config.get('state_transfer')['transfer_col_names']
        transfer_col_names = ['WIN_NBR', 'CURRENT_STATE', 'PREVIOUS_STATE']

        start_date = datetime.datetime.strftime(start_date, '%Y-%m-%d')
        end_date = datetime.datetime.strftime(end_date, '%Y-%m-%d')

        query = STATE_TRANSFER_TO_US if self.region == 'US' else STATE_TRANSFER_TO_PR
        eligible_transfers_df = self.get_data_from_db2(
            col_names=transfer_col_names,
            query=query.format(DB2_SCHEMA=self.db2_connection.testset, ASSOCIATE_LIST=associate_list,
                               START_DATE=start_date, END_DATE=end_date),
            table_name='win_associate'
        )
        eligible_transfers_list = eligible_transfers_df['WIN_NBR'].unique().tolist()

        self.logger.info(
            f'Final eligible state transfers associate count for {self.region} is {len(eligible_transfers_list)}')

        if len(eligible_transfers_list) == 0:
            update_request_status(self.request_id, F_ERROR, self.logger,
                                  "Empty result set for the given query, cannot proceed further. Interrupting the program execution flow.")

        return eligible_transfers_list
