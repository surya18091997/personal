import os
from datetime import date

from src.constants import (
    F_ERROR, F_COMPLETED, CFG_WORKING_DIR, ERROR_INIT_FILE,
    INFO_USING_RUN_DATE, INFO_START_PROCESSING, ERROR_NO_SOURCE_FILES, INFO_COMPLETED_PROCESSING, ERROR_PROCESS_QUERY,
    ERROR_FILE_GENERATION, ERROR_MAX_RUN_DATE, CFG_GCP_PROJECT, CFG_FLOW_CONFIG, CFG_BIGQUERY_DATASET, CFG_BUCKET_NAME,
    CFG_DESTINATION_PATH, CFG_DEST_FILE, CFG_WAGE_DOE_CODES, CFG_WAGE_EARN_TYPE_CODES, STRIP_DATE, DATE_METHOD,
    PROCESS_TYPE_WAGES, MAX_DATE, SAP_ASSOC_FILE_NAME
)
from src.generate_file.file_generator import FileGenerator
from src.integrations.gcs_utils import GCSUtils
from src.utils.common_utils import update_request_status
from src.utils.sql import ELIGIBLE_WAGES_QUERY, GET_MAX_RUN_DATE_FOR_WAGES_QUERY
from src.utils.errors.app_errors import ApplicationError
import src.utils.app_config as app_config


class WageFile(FileGenerator):
    """Handles fetching eligible wages data and generating files."""

    def __init__(self, configuration_id, logger, request_id, start_date):
        try:
            super().__init__(configuration_id, logger, request_id, start_date, start_date)

            # Get config from CCM
            self.flow_config = app_config.get_config_value(CFG_FLOW_CONFIG, str(configuration_id))
            self.gcp_project = self.flow_config.get(CFG_GCP_PROJECT)
            self.bigquery_dataset = self.flow_config.get(CFG_BIGQUERY_DATASET)

            # Setup GCS paths
            self.bucket_name = self.flow_config.get(CFG_BUCKET_NAME)
            self.destination_folder = self.flow_config.get(CFG_DESTINATION_PATH)
            self.dest_file = self.flow_config.get(CFG_DEST_FILE)
            self.working_dir = f"{CFG_WORKING_DIR}/{self.request_id}"
            self.destination_file=f"{self.destination_folder}{self.dest_file}.csv"

            # Initialize GCS utils
            self.gcs_util = GCSUtils(logger)

        except Exception as e:
            raise ApplicationError(ERROR_INIT_FILE.format(PROCESS_TYPE_WAGES, str(e)))

    def start_process(self):
        """
        Executes the main workflow to process wage data from BigQuery and export it to GCS.
        This method handles date configuration, query execution, and file management.
        Includes error handling and status updates throughout the process.

        Raises:
            ApplicationError: If any step in the process fails, including missing source files
                             or errors during query execution
        """
        try:
            # Step 1: Working directory setup
            self.create_working_directory(self.request_id)
            # Step 2: Configure and validate the query date
            query_date = self.start_date.date() if hasattr(self.start_date, DATE_METHOD) else self.start_date

            # Fall back to max run date if no run date provided
            if not query_date:
                query_date = self.get_max_run_date()

            current_date = date.today()
            if query_date != current_date:
                error_msg = f"Query date {query_date} does not match the current date {current_date}. Halting the process."
                self.logger.error(error_msg)
                raise ApplicationError(error_msg)

            # Format date for file naming convention
            date_suffix = query_date.strftime(STRIP_DATE)
            self.logger.info(INFO_USING_RUN_DATE.format(query_date))

            # Step 3: Prepare query parameters
            replacements = {
                '{gcp_project}': self.gcp_project,
                '{bigquery_dataset}': self.bigquery_dataset,
                '{doe_codes}': self.flow_config.get(CFG_WAGE_DOE_CODES),
                '{earn_type_codes}': self.flow_config.get(CFG_WAGE_EARN_TYPE_CODES),
                '@run_date': f"'{query_date}'"
            }

            try:
                # Step 4: Begin wage data processing
                self.logger.info(INFO_START_PROCESSING.format(PROCESS_TYPE_WAGES))

                # Execute BigQuery and export results to GCS
                job = self.gcs_util.export_query_to_gcs(
                    self.dest_file,
                    ELIGIBLE_WAGES_QUERY,
                    self.working_dir,
                    date_suffix,
                    self.bucket_name,
                    replacements
                )

                # Wait for query job completion
                self.gcs_util.wait_for_job(job)

                # Step 5: Locate exported files in GCS
                source_files = self.gcs_util.list_files_in_working_dir(
                    self.bucket_name,
                    self.working_dir,
                    self.dest_file,
                    date_suffix
                )

                # Step 6: Fetch SAP active associates
                sap_assoc_df = self.getSAPActiveAssociates()

                # Verify that files were generated
                if not source_files:
                    raise ApplicationError(ERROR_NO_SOURCE_FILES.format(PROCESS_TYPE_WAGES))

                # Step 7: Copy files to final destination in GCS
                self.gcs_util.copy_blob(
                    self.bucket_name,
                    source_files,
                    self.destination_file
                )

                # Step 8: upload sap associate file to final destination in GCS
                sap_file_path = os.path.join(self.request_id_dir, SAP_ASSOC_FILE_NAME)
                sap_gcs_path = f"{self.destination_folder}{SAP_ASSOC_FILE_NAME}"
                self.gcs_util.upload_file(
                    self.bucket_name,
                    sap_gcs_path,
                    sap_file_path,
                )

                # Step 9: Update process status and log completion
                self.logger.info(INFO_COMPLETED_PROCESSING.format(PROCESS_TYPE_WAGES))
                update_request_status(self.request_id, F_COMPLETED, self.logger)

            except Exception as e:
                # Handle errors during query processing and file operations
                error_msg = ERROR_PROCESS_QUERY.format(PROCESS_TYPE_WAGES, str(e))
                self.logger.error(error_msg)
                update_request_status(self.request_id, F_ERROR, self.logger, error_msg)
                raise ApplicationError(error_msg)

        except Exception as e:
            # Handle errors during initial setup and date configuration
            error_msg = ERROR_FILE_GENERATION.format(PROCESS_TYPE_WAGES, str(e))
            self.logger.error(error_msg)
            update_request_status(self.request_id, F_ERROR, self.logger, str(error_msg))
            raise ApplicationError(error_msg)

    def get_max_run_date(self):
        """Get max run date from earnings table if not provided."""
        try:
            query = GET_MAX_RUN_DATE_FOR_WAGES_QUERY.format(
                gcp_project=self.gcp_project,
                bigquery_dataset=self.bigquery_dataset
            )
            result = self.gcp_connection.get_df_from_query(query)
            return result[MAX_DATE].iloc[0]
        except Exception as e:
            raise ApplicationError(ERROR_MAX_RUN_DATE.format(str(e)))