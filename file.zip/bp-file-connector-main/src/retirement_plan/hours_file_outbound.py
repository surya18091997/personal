import os
from datetime import datetime, timedelta
import json
import pandas as pd
from src.constants import (
    F_ERROR, F_COMPLETED, CFG_WORKING_DIR, ERROR_READING_SOURCE_FILE,
    ERROR_PARSE_JSON, ERROR_GENERATE_R14, ERROR_HOURS_OUTBOUND_INIT,
    ERROR_GENERATE_FILE, RECORD_TYPE_R14, CFG_SOURCE_BUCKET_NAME, CFG_SOURCE_FILE_PATH, CFG_BUCKET_NAME,
    CFG_DESTINATION_FILE_PATH, CFG_DEST_FILE, CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT
)
from src.generate_file.file_generator import FileGenerator
from src.generate_file.flat_file_creator import gen_flat_file
from src.integrations.gcs_utils import GCSUtils
from src.utils import app_config
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError


class HoursOutboundFile(FileGenerator):
    """Handles generation of eligible hours outbound file."""

    def __init__(self, configuration_id, logger, request_id, start_date):
        try:
            super().__init__(configuration_id, logger, request_id, start_date, start_date)

            # Get config from CCM
            self.flow_config = app_config.get_config_value("flow_config", str(configuration_id))
            self.source_bucket = self.flow_config.get(CFG_SOURCE_BUCKET_NAME)
            self.source_file_path = self.flow_config.get(CFG_SOURCE_FILE_PATH)
            self.gcp_project = self.flow_config.get("gcp_project")
            self.bigquery_dataset = self.flow_config.get("bigquery_dataset")

            # Setup GCS paths
            self.bucket_name = self.flow_config.get(CFG_BUCKET_NAME)
            self.destination_folder = self.flow_config.get(CFG_DESTINATION_FILE_PATH)
            self.dest_file = self.flow_config.get(CFG_DEST_FILE, "hours_outbound.txt")
            self.working_dir = f"{CFG_WORKING_DIR}/{self.request_id}"

            # Initialize GCS utils
            self.gcs_util = GCSUtils(logger)

            # Get file layouts
            self.flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT)

        except Exception as e:
            raise ApplicationError(ERROR_HOURS_OUTBOUND_INIT.format(str(e)))

    def read_source_file(self):
        """Read and parse JSONL file from GCS (JSON Lines format)."""
        try:
            # Download file content
            content = self.gcs_util.download_file_content(
                self.source_bucket or self.bucket_name,
                # Use source_bucket if available, otherwise fall back to bucket_name
                self.source_file_path
            )

            # Parse as JSON Lines format (each line is a separate JSON object)
            records = []
            for line in content.splitlines():
                line = line.strip()
                if line:  # Skip empty lines
                    try:
                        record = json.loads(line)
                        records.append(record)
                    except json.JSONDecodeError as e:
                        self.logger.warning(f"Failed to parse line: {line[:100]}... - {str(e)}")
                        # Continue processing other lines even if one fails

            if records:
                self.logger.info(f"Successfully parsed {len(records)} records from JSONL format")
            else:
                self.logger.warning("No valid records found in the file")

            return records

        except Exception as e:
            raise ApplicationError(ERROR_READING_SOURCE_FILE.format(str(e)))

    def _map_dates_to_days(self, pay_period_hours, end_date_str):
        """Map dates to specific day positions (day1-day14)."""
        try:
            # Parse the end date
            if not end_date_str:
                return [0] * 14  # Default to zeros if no end date

            end_date = datetime.strptime(end_date_str, "%Y-%m-%d")

            # Create a dictionary of date to hours
            # Handle both list and empty lists safely
            if not pay_period_hours:
                date_to_hours = {}
            else:
                date_to_hours = {item.get('date'): float(item.get('hours', 0))
                                 for item in pay_period_hours if 'date' in item and 'hours' in item}

            # Initialize array for 14 days of hours
            daily_hours = []

            # Fill in hours for each day, starting from the end date and going backward 14 days
            for i in range(14):
                current_date = end_date - timedelta(days=i)
                date_str = current_date.strftime("%Y-%m-%d")
                hours = date_to_hours.get(date_str, 0)
                daily_hours.append(hours)

            return daily_hours

        except Exception as e:
            self.logger.error(f"Error mapping dates to days: {str(e)}")
            return [0] * 14  # Return zeros on error

    def apply_plan_specific_record_updates(self, records):
        """
        Apply specific record updates for hours outbound file.
        Creates the R14 records with daily hours mapped correctly.
        """
        try:
            # Extract all WIN numbers to fetch National IDs
            win_numbers = [str(record.get('win_nbr', '')) for record in records]

            # Use the BigQuery connection to fetch National IDs
            win_to_national_id = self.gcp_connection.fetch_national_ids(
                win_numbers,
                self.gcp_project,
                self.bigquery_dataset
            )

            r14_data = []

            for record in records:
                win_nbr = str(record.get('win_nbr', ''))
                national_id = win_to_national_id.get(win_nbr, '')
                payroll_end_date = record.get('payroll_end_date', '')

                # Process daily hours - handle potentially missing or empty PAY_PERIOD_HOURS_LIST
                pay_period_hours = record.get('PAY_PERIOD_HOURS_LIST', []) or []
                daily_hours = self._map_dates_to_days(pay_period_hours, payroll_end_date)

                # Create a row for the DataFrame - use exact length strings without padding
                row = {
                    'associate_id': win_nbr,
                    'R14-REC-TYPE': "14",
                    'R14-PLAN-NUMBER': self.plan_number,
                    'R14-ASC-SS-NBR': national_id.ljust(9),
                    'R14-WIN-NBR': win_nbr.ljust(9)
                }

                # Add daily hours fields with custom decimal formatting
                for i, hours in enumerate(daily_hours, 1):
                    # Format hours with the decimal custom format without padding
                    row[f'R14-DAY{i}-HOUR'] = self.decimal_custom_format(hours)

                # Add adjusted hours - use 0 if missing
                adjusted_hours = float(record.get('CALCULATED_ADJUSTED_HOURS', 0) or 0)
                row['R14-ADJUST-HOUR'] = self.decimal_custom_format(adjusted_hours)

                # Add total hours - use 0 if missing
                total_hours = float(record.get('CALCULATED_ELIGIBLE_HOURS', 0) or 0)
                row['R14-TOTAL-HOUR'] = self.decimal_custom_format(total_hours)

                r14_data.append(row)

            # Create DataFrame from the data
            r14_df = pd.DataFrame(r14_data)

            # Return dictionary with record type and DataFrame
            return {'r14': r14_df}

        except Exception as e:
            self.logger.error(f"Error applying plan specific record updates: {str(e)}")
            raise ApplicationError(f"Failed to apply plan specific record updates: {str(e)}")

    def start_process(self):
        """Generate hours outbound file."""
        try:
            # Create working directory
            self.create_working_directory(self.request_id)

            # Read source records
            records = self.read_source_file()
            self.logger.info(f"Read {len(records)} records from source file")

            if not records:
                self.logger.warning("No records to write to file")
                update_request_status(self.request_id, F_COMPLETED, self.logger)
                return

            # Apply plan specific updates and get record dictionary
            record_dict = self.apply_plan_specific_record_updates(records)

            # Generate the flat file using the standard process
            self.initiate_custom_flat_file_generation(record_dict)

            # Transfer file to GCS bucket
            self.transfer_file_to_gcs()

            # Transfer file to mainframe
            self.transfer_file_to_mainframe()

            # Update request status to completed
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            error_msg = ERROR_GENERATE_FILE.format(str(e))
            self.logger.error(error_msg)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise ApplicationError(error_msg)

    def decimal_custom_format(self, rate):
        """
        Formats the rate into mainframe specific string format.
        Converts decimal parts of rate into letters (1=A, 2=B, etc)
        Example: 4.2 -> 004B, 3.5 -> 003E
        """
        try:
            abs_rate = abs(float(rate))

            # Get integer and decimal parts
            int_part = int(abs_rate)
            decimal_part = abs_rate - int_part

            # Format integer part with leading zeros
            formatted_int = str(int_part).zfill(4)

            # If there's a decimal part, convert it to letter
            if decimal_part > 0:
                # Multiply by 10 to get first decimal place as integer
                decimal_digit = int(round(decimal_part * 10))
                # Convert to corresponding letter (1->A, 2->B, etc)
                return formatted_int + chr(64 + decimal_digit)

            # No decimal part
            return formatted_int + "{"
        except ValueError as e:
            self.logger.error(f"Error formatting rate {rate}: {str(e)}")
            return "000{"

    def generate_r14_fixed_length_row(self, row, layout):
        """
        Generate fixed-length row for R14 records without extra spaces.
        This overrides the default behavior to ensure dense packing.
        """
        try:
            # Build the record starting with record type, plan number, and IDs
            # Convert all values to strings
            record = str(row['R14-REC-TYPE']) + str(row['R14-PLAN-NUMBER']) + str(row['R14-ASC-SS-NBR']) + str(
                row['R14-WIN-NBR'])

            # Add all day hours (1-14)
            for i in range(1, 15):
                record += str(row[f'R14-DAY{i}-HOUR'])

            # Add adjusted and total hours
            record += str(row['R14-ADJUST-HOUR']) + str(row['R14-TOTAL-HOUR'])

            # Ensure length is 250 characters by padding if needed
            if len(record) < 250:
                record = record.ljust(250)

            return record
        except Exception as e:
            self.logger.error(f"Error generating fixed length row for R14: {str(e)}")
            raise ApplicationError(f"Failed to generate fixed length row: {str(e)}")

    def initiate_custom_flat_file_generation(self, record_dict):
        """Override to use custom row generator for R14 records."""
        generated_file = os.path.join(self.request_id_dir, self.dest_file)
        invalid_file = os.path.join(self.request_id_dir, 'invalid_' + self.dest_file)

        self.logger.info(
            f"Files about to be generated: {generated_file} and records that could not be processed: {invalid_file}")

        flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT)

        # Create object for the flat file generator
        create_flat_file = gen_flat_file(generated_file, invalid_file, flat_file_layout, self.logger)
        create_flat_file.request_id = self.request_id

        # Open files
        create_flat_file.open_files()

        # Write header
        create_flat_file.write_header(self.plan_number, self.plan_file, self.file_data_type, self.file_filler, self.fetch_current_payroll_enddate())

        # Write records directly using our custom method
        for _, row in record_dict['r14'].iterrows():
            fixed_row = self.generate_r14_fixed_length_row(row, flat_file_layout['r14'])
            create_flat_file.file_pointer.write(fixed_row + '\n')

        # Write trailer
        row_count_dict = {'r14': len(record_dict['r14'])}
        create_flat_file.write_trailer(row_count_dict, self.plan_file)

        # Close files
        create_flat_file.close_files()