import os
import time
from datetime import datetime

import pandas
import pandas as pd
from pandas import DataFrame

from src.constants import CFG_SOURCE_BUCKET_NAME, CFG_SOURCE_FILE_PATH, CFG_BUCKET_NAME, CFG_DESTINATION_FILE_PATH, \
    CFG_DEST_FILE, CFG_WORKING_DIR, CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT, \
    ERROR_CONTRIBUTION_OUTBOUND_INIT, F_COMPLETED, ERROR_GENERATE_CONTRIBUTION_FILE, F_ERROR, ERROR_READING_SOURCE_FILE, \
    ASSOCIATE_ID, GCP_FETCH_ERROR, NATIONAL_ID, \
    FIELD_WIN_NBR, APP_NAME, COLUMNS_TO_DROP_IN_CONTRIBUTION_DF, columns_to_apply_zfill, \
    R05_YTD_415_COMPENSATION, R05_PLAN_NUMBER, R05_HOURS_SERVICE, R05_PAYROLL_FREQ, R05_ELIGIBLE_WAGE, \
    ASSOCIATE_ELIGIBLE_WAGE, COLUMN_ORDER, SOURCE_AMOUNT_COLUMNS, SINGLE_SPACE_COLUMNS, R05_FILLER_01, R05_FILLER_02, \
    R05_FILLER_02_DEFAULT, R05_FILLER_01_DEFAULT, COLUMNS_TO_KEEP, R05_YTD_415_COMPENSATION_DEFAULT, \
    R05_HOURS_SERVICE_DEFAULT, TRAILER_COLUMNS_TO_ZFILL, R05_RECORD_TYPE, R05, DOE_CODE, STATE_CODE, CFG_PAY_CENTER_ID
from src.generate_file.file_generator import FileGenerator
from src.generate_file.flat_file_creator import gen_flat_file
from src.integrations.gcs_utils import GCSUtils
from src.utils import app_config
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError
from src.utils.sql import IMPACTED_ASSOCIATE_IDS_BY_GOOD_BAD_SSN, GET_BI_WEEKLY_START_AND_PAY_DATES


def update_columns_vectorized(df):
    # Create masks for each plan_type
    regular_mask = df['plan_type'] == 'REGULAR'
    catch_up_mask = df['plan_type'] == 'CATCH_UP'
    roth_mask = df['plan_type'] == 'ROTH'
    roth_catch_up_mask = df['plan_type'] == 'ROTH_CATCH_UP'

    # Update columns for REGULAR
    df.loc[regular_mask, 'R05-SOURCE-ID-A(1)'] = 'A'
    df.loc[regular_mask, 'R05-CONTRIB-IND-A(1)'] = 'B'
    df.loc[regular_mask, 'R05-SOURCE-AMOUNT-A(1)'] = df.loc[regular_mask, 'contribution_amount']

    # Update columns for CATCH_UP
    df.loc[catch_up_mask, 'R05-SOURCE-ID-A(2)'] = 'Z'
    df.loc[catch_up_mask, 'R05-CONTRIB-IND-A(2)'] = 'B'
    df.loc[catch_up_mask, 'R05-SOURCE-AMOUNT-A(2)'] = df.loc[catch_up_mask, 'contribution_amount']

    # Update columns for ROTH
    df.loc[roth_mask, 'R05-SOURCE-ID-A(3)'] = 'Q'
    df.loc[roth_mask, 'R05-CONTRIB-IND-A(3)'] = 'B'
    df.loc[roth_mask, 'R05-SOURCE-AMOUNT-A(3)'] = df.loc[roth_mask, 'contribution_amount']

    # Update columns for ROTH_CATCH_UP
    df.loc[roth_catch_up_mask, 'R05-SOURCE-ID-A(4)'] = 'U'
    df.loc[roth_catch_up_mask, 'R05-CONTRIB-IND-A(4)'] = 'B'
    df.loc[roth_catch_up_mask, 'R05-SOURCE-AMOUNT-A(4)'] = df.loc[roth_catch_up_mask, 'contribution_amount']

    return df


def amt_zfill(x,length = 9):
    if str(x).strip():
        if float(x) < 0:
            # Convert to cents, zero-fill, and replace the last digit
            result = str(round(float(x) * -100)).zfill(length)  # Convert to positive for processing
            last_digit = int(result[-1])
            if last_digit > 0:
                return result[:-1] + chr(73 + last_digit)
            else:
                return result[:-1] + "}"
        else:
            return str(round(float(x) * 100)).zfill(length)
    return x


def decimal_to_int(x):
    if str(x).strip():
        return round(float(x * 100))
    return 0

def fill_with_spaces(value, length=9):
    if not value or str(value).strip() == "":
        return " " * length
    return value

def add_missing_columns(df, required_columns, default_value=""):
    for column in required_columns:
        if column not in df.columns:
            df[column] = default_value
    return df

class ContributionOutbound(FileGenerator):
    """
        This class handles the generation of loan outbound files for the 401k retirement plan.
        It processes loan requests from coverages collection, extracts loan data from GCP,
        and generates files with the appropriate loan information.
    """

    def __init__(self, configuration_id, logger, request_id, start_date):
        try:
            super().__init__(configuration_id, logger, request_id, start_date, start_date)

            # Get config from CCM
            self.flow_config = app_config.get_config_value("flow_config", str(configuration_id))
            self.source_bucket = self.flow_config.get(CFG_SOURCE_BUCKET_NAME)
            self.source_file_path = self.flow_config.get(CFG_SOURCE_FILE_PATH)
            self.gcp_project = self.flow_config.get("gcp_project")
            self.bigquery_dataset = self.flow_config.get("bigquery_dataset")
            self.static_col_record_set = app_config.get_config_value("file_layout", "static_col_record_set")
            self.pay_center_id =  self.flow_config.get(CFG_PAY_CENTER_ID, "")

            # Setup GCS paths
            self.bucket_name = self.flow_config.get(CFG_BUCKET_NAME)
            self.destination_folder = self.flow_config.get(CFG_DESTINATION_FILE_PATH)
            self.dest_file = self.flow_config.get(CFG_DEST_FILE, "contribution_outbound.txt")
            self.working_dir = app_config.get_config_value(APP_NAME,CFG_WORKING_DIR) +'/' + self.request_id

            # Initialize GCS utils
            self.gcs_util = GCSUtils(logger)

            # Get file layouts
            self.flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT)

        except Exception as e:
            raise ApplicationError(ERROR_CONTRIBUTION_OUTBOUND_INIT.format(str(e)))

    def start_process(self):
        """Generate hours outbound file."""
        try:
            # Step 1: Create working directory
            self.create_working_directory(self.request_id)

            # Step 2: Read contribution file as dataframe
            contribution_df = self.read_source_file()
            good_bad_ssn_df = self.get_good_bad_ssn()

            contribution_df = self.apply_good_bad_ssn_correction(contribution_df,good_bad_ssn_df)
            #

            self.logger.info(f"Loaded dataframe from source .csv file")

            if contribution_df.empty:
                self.logger.warning("No records to write to file")
                update_request_status(self.request_id, F_COMPLETED, self.logger)
                return

            # Step 3: re-organise the df
            contribution_df = update_columns_vectorized(contribution_df)

            # Step 4: Sort the df
            # We might need to sort again after adding good-bas ssn.
            # contribution_df = self.sort_df(contribution_df)

            # Step 5: CleanUp the df
            contribution_df.drop(columns=COLUMNS_TO_DROP_IN_CONTRIBUTION_DF, inplace=True)

            # Step 6: Format the df
            df, contribution_totals = self.apply_contribution_attributes(contribution_df)

            # Step 7: Generate the flat file
            self.initiate_custom_flat_file_generation(df, contribution_totals)

            # Step 8: Transfer the file to GCS bucket
            self.transfer_file_to_gcs()

            # Step 9: Transfer the file to mainframe
            self.transfer_file_to_mainframe()

            # Step 10: Update request status to completed
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            error_msg = ERROR_GENERATE_CONTRIBUTION_FILE.format(str(e))
            self.logger.error(error_msg)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise ApplicationError(error_msg)

    def read_source_file(self):
        try:
            # Download file content
            self.gcs_util.download_file(
                self.source_bucket or self.bucket_name,
                self.source_file_path,
                self.working_dir+"/contribution_df.csv"
            )
            contribution_df = pandas.read_csv(self.working_dir+"/contribution_df.csv")
            return contribution_df
        except Exception as e:
            raise ApplicationError(ERROR_READING_SOURCE_FILE.format(str(e)))

    def initiate_custom_flat_file_generation(self, df, contribution_totals):
        generated_file = os.path.join(self.request_id_dir, self.dest_file)
        invalid_file = os.path.join(self.request_id_dir, 'invalid_' + self.dest_file)

        self.logger.info(
            f"Files about to be generated: {generated_file} and records that could not be processed: {invalid_file}")

        flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT)

        # Create object for the flat file generator
        create_flat_file = gen_flat_file(generated_file, invalid_file, flat_file_layout, self.logger)
        create_flat_file.request_id = self.request_id

        # Open files
        create_flat_file.open_files()

        # Write header
        header_record = self.generate_header_record()
        create_flat_file.file_pointer.write(header_record + '\n')
        start_time = time.time()

        # Write records directly using our custom method
        for _, row in df.iterrows():
            fixed_row = "".join(map(str, row.values))
            create_flat_file.file_pointer.write(fixed_row + '\n')
        end_time = time.time()
        self.logger.warning(f"Time taken to write records to file: {end_time - start_time} seconds")

        # Write trailer
        trailer_record = self.write_contribution_trailer(df, contribution_totals)
        create_flat_file.file_pointer.write(trailer_record + '\n')

        # Close files
        create_flat_file.close_files()

    def generate_header_record(self):
        current_date = datetime.now()
        julian_date = current_date.strftime("%Y%j")
        time_stamp = current_date.strftime("%H%M%S")
        #fetch it form GCP - HR_PAYROLL_CYCLE
        payroll_end_date, bi_weekly_start_date, pay_date = self.get_dates_for_header()

        # Format the Header Record
        header_record = (
            f"UHDR {julian_date}{self.plan_number}{self.plan_file.ljust(20)}{time_stamp}{payroll_end_date}  0000"
            f"{' ' * 54}{bi_weekly_start_date}{' ' * 8}{pay_date}{' ' * 44}C{' ' * 142}"
        )
        return header_record

    def write_contribution_trailer(self, df: DataFrame, contribution_totals):
        # Step 1 - construct a df with footer based columns
        try:
            data={
                "R99-RECORD-TYPE": ["UTRL"],
                "R99-FILLER-1": [" "],
                "R99-RECORD-COUNT-N": ["00000000"],
                "R99-PLAN-NUMBER": ["609450"],
                "R99-FILLER-2":["0" * 16],
                "R99-WMT-COUNT-R55": ["00000000"],#Fill this with count
                "FILLER-2":["0" *48],
                "R99-FILLER-3" : ["   "],
                "R99-BT-BASIC-SB-INDICATOR": ["BASC"],
                "R99-BT-BASIC-SOURCE": ["A  "],
                "R99-BT-BASIC-TOTAL": ["00000000000"],
                "R99-BT-SUPP-SB-INDICATOR": ["BASC"],
                "R99-BT-SUPP-SOURCE": ["Z  "],
                "R99-BT-SUPP-TOTAL": ["00000000000"],
                "R99-REG-BASIC-SB-INDICATOR": ["BASC"],
                "R99-REG-BASIC-SOURCE": ["X  "],
                "FILLER-3": [" " * 15],
                "R99-REG-SUPP-SOURCE": ["Q  "],
                "R99-REG-SUPP-TOTAL": ["00000000000"],
                "R99-COMPANY-SB-INDICATOR": ["    "],
                "R99-COMPANY-SOURCE": ["U  "],
                "R99-COMPANY-TOTAL": ["00000000000"],
                "R99-TOTAL-CONTRIBUTIONS": ["00000000000"],
                "R99-FILLER-4":["0" * 37],
                "R99-FILLER-5": [" " * 18],
            }
            trailer_df = pd.DataFrame(data)

            trailer_df['R99-RECORD-COUNT-N'] = str(len(df) + 2).zfill(8)  # Including header & footer
            trailer_df['R99-WMT-COUNT-R55'] = str(len(df)).zfill(8)
            trailer_df['R99-PLAN-NUMBER'] = self.plan_number
            trailer_df['R99-BT-BASIC-TOTAL'] = contribution_totals['regular'].astype(str).zfill(11)  # Regular amt
            trailer_df['R99-BT-SUPP-TOTAL'] = contribution_totals['catchup'].astype(str).zfill(11)  # Catchup amt
            trailer_df['R99-REG-SUPP-TOTAL'] = contribution_totals['roth'].astype(str).zfill(11)  # Roth
            trailer_df['R99-COMPANY-TOTAL'] = contribution_totals['roth_catchup'].astype(str).zfill(11)  # Roth catchup

            # Sum the values in the contribution_totals dict
            trailer_df['R99-TOTAL-CONTRIBUTIONS'] = sum(contribution_totals.values()).astype(str).zfill(11)
            if self.region == 'PR':
                trailer_df['R99-REG-SUPP-SOURCE'] = ["   "]
                trailer_df['R99-COMPANY-SOURCE'] = ["   "]

            trailer_df['R99-RECORD-COUNT-N'] = trailer_df['R99-RECORD-COUNT-N'].astype(str).str.zfill(8)
            trailer_df['R99-WMT-COUNT-R55'] = trailer_df['R99-WMT-COUNT-R55'].astype(str).str.zfill(8)
            for col in TRAILER_COLUMNS_TO_ZFILL:
                trailer_df[col] = trailer_df[col].astype(str).str.zfill(11)

            # Step 4 - Write the trailer record to the file
            fixed_row = ""
            for _, row in trailer_df.iterrows():
                fixed_row = "".join(map(str, row.values))
            return fixed_row
        except Exception as e:
            self.logger.error(f"Error writing trailer record: {e}")
            raise

    def apply_contribution_attributes(self, df):
        df.rename(columns={'payroll_freq': R05_PAYROLL_FREQ}, inplace=True)
        # Add missing columns
        df = add_missing_columns(df,self.static_col_record_set[self.record_types[0]])
        df.fillna('', inplace=True)

        contribution_df = df[columns_to_apply_zfill].applymap(decimal_to_int)
        contribution_totals = {
            'regular': contribution_df['R05-SOURCE-AMOUNT-A(1)'].sum(),
            'catchup': contribution_df['R05-SOURCE-AMOUNT-A(2)'].sum(),
            'roth': contribution_df['R05-SOURCE-AMOUNT-A(3)'].sum(),
            'roth_catchup': contribution_df['R05-SOURCE-AMOUNT-A(4)'].sum()
        }
        df[columns_to_apply_zfill] = df[columns_to_apply_zfill].applymap(amt_zfill, length=9)

        df[R05_RECORD_TYPE] = R05
        df[R05_PLAN_NUMBER] = self.plan_number
        df[R05_HOURS_SERVICE] = R05_HOURS_SERVICE_DEFAULT
        df[R05_YTD_415_COMPENSATION] = R05_YTD_415_COMPENSATION_DEFAULT
        df[R05_ELIGIBLE_WAGE] = df[ASSOCIATE_ELIGIBLE_WAGE].apply(amt_zfill,length = 10)

        # Filter the unnecessary columns - keep only mandatory columns
        df = df[COLUMNS_TO_KEEP]

        df[SOURCE_AMOUNT_COLUMNS] = df[SOURCE_AMOUNT_COLUMNS].applymap(fill_with_spaces, length=9)
        df[SINGLE_SPACE_COLUMNS] = df[SINGLE_SPACE_COLUMNS].applymap(fill_with_spaces, length=1)

        # ADD FILLER COLUMNS
        df[R05_FILLER_01] = R05_FILLER_01_DEFAULT
        df[R05_FILLER_02] = R05_FILLER_02_DEFAULT

        df = df[COLUMN_ORDER]
        df[NATIONAL_ID] = df[NATIONAL_ID].astype(str).str.zfill(9)
        return df , contribution_totals

    def sort_df(self,df):
        custom_order = ['CATCH_UP', 'ROTH', 'ROTH_CATCH_UP', 'REGULAR']

        # Apply custom sorting for plan_type
        df['plan_type'] = pd.Categorical(df['plan_type'], categories=custom_order, ordered=True)

        # Sort by national_id and plan_type
        df = df.sort_values(by=['national_id', 'plan_type'])

        return df

    def get_good_bad_ssn(self):
        # 1.read the good_bad_ssn csv
        good_bad_ssn_df = self.read_good_bad_ssn()
        if good_bad_ssn_df.empty:
            return good_bad_ssn_df
        # 2. Get mismatched win-ssn from GCS
        old_national_id_list = good_bad_ssn_df[NATIONAL_ID].unique().tolist()
        impacted_associate_df = self.fetch_impacted_associate_ids(old_national_id_list)
        # 3.Do Inner join with good_bad_ssn_df
        good_bad_ssn_df[NATIONAL_ID] = good_bad_ssn_df[NATIONAL_ID].astype(str)
        good_bad_ssn_df = good_bad_ssn_df.merge(impacted_associate_df, left_on=NATIONAL_ID, right_on='old_national_id', how='inner')
        good_bad_ssn_df.to_csv(self.working_dir+"/good_bad_ssn_df.csv", index=False)
        # apply plan_type udf to doe_code
        good_bad_ssn_df['plan_type'] = good_bad_ssn_df[DOE_CODE].apply(lambda x: self.get_plan_type(x))
        # 4. Filter the required columns
        # TODO - drop the correct column names once the header file is ready
        good_bad_ssn_df.drop(columns=[DOE_CODE,'old_national_id', 'METHOD', 'PERIOD_CODE', 'TYPE'], inplace=True)
        return good_bad_ssn_df

    def get_plan_type(self, doe_code):
        # Define the mapping of doe_code to plan_type
        plan_type_mapping = {
            "K0": "REGULAR", "K1": "REGULAR", "K2": "REGULAR", "K3": "REGULAR",
            "J0": "REGULAR", "J1": "REGULAR", "J2": "REGULAR", "J3": "REGULAR",
            "KL": "CATCH_UP", "KM": "CATCH_UP", "KN": "CATCH_UP", "KO": "CATCH_UP",
            "KP": "ROTH",
            "KQ": "ROTH_CATCH_UP"
        }
        # Return the corresponding plan_type or None if not found
        return plan_type_mapping.get(doe_code)

    def read_good_bad_ssn(self):
        # Download file content
        # check if the file is available
        try:
            self.gcs_util.download_file(
                self.source_bucket or self.bucket_name,
                'GOOD-BAD/GOOD-BAD-SSN-FILE',
                self.working_dir+"/GOOD-BAD-SSN.csv"
            )
            good_bad_ssn_df = pandas.read_csv(self.working_dir+"/GOOD-BAD-SSN.csv")
            return good_bad_ssn_df
        except Exception as e:
            # What if the file is present and an error occurred while reading?
            self.logger.warning("Good-Bad SSN file not found or could not be read. Returning empty DataFrame.")
            return pd.DataFrame()

    def fetch_impacted_associate_ids(self,national_id_list):
        try:
            # Check national_id_list is not empty
            if not national_id_list:
                self.logger.warning("No national IDs provided for fetching impacted associate IDs.")
                return pd.DataFrame()
            formatted_list = ",".join([f"'{national_id}'" for national_id in national_id_list])
            # Get GCP project and dataset from config
            gcp_project = self.flow_config.get("gcp_project")
            bigquery_dataset = self.flow_config.get("bigquery_dataset")

            # Check if project and dataset are configured
            if not gcp_project or not bigquery_dataset:
                error_msg = f"Missing GCP configuration. Project: {gcp_project}, Dataset: {bigquery_dataset}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

            query = IMPACTED_ASSOCIATE_IDS_BY_GOOD_BAD_SSN.format(
                gcp_project=gcp_project,
                national_id_list = formatted_list
            )
            self.logger.info(f"Fetching impacted associate IDs from GCP using query: {query}")
            self.logger.debug(f"Executing query: {query}")
            # Use the existing GCP connection to execute the query
            impacted_associate_ids = self.gcp_connection.get_df_from_query(query)
            self.logger.debug(f"Fetched impacted associate IDs: {len(impacted_associate_ids)}")
            return impacted_associate_ids
        except Exception as e:
            self.logger.error(GCP_FETCH_ERROR.format(error_message=str(e)))
            raise

    def apply_good_bad_ssn_correction(self, contribution_df,correction_df):
        contribution_df.rename(columns={ASSOCIATE_ID: FIELD_WIN_NBR, 'national_id': NATIONAL_ID}, inplace=True)
        if correction_df.empty:
            self.logger.warning("No good-bad SSN corrections found. Returning original contribution_df.")
            return contribution_df

        # Filter by state_code
        if self.region == 'US':
            correction_df = correction_df[~correction_df[STATE_CODE].isin(['52', '49'])]
        else:
            correction_df = correction_df[correction_df[STATE_CODE] == self.plan_stat_code]

        # Check if the correction_df is not empty
        if correction_df.empty:
            return contribution_df

        #Negative DOE_AMOUNT
        negative_doe_amt_df = correction_df[correction_df['AMOUNT'] < 0]
        # Group by national_id and plan_type, and sum the doe_amt
        if not negative_doe_amt_df.empty:
            summed_doe_amt = (negative_doe_amt_df.groupby(['current_national_id', 'plan_type'])['AMOUNT'].sum()).reset_index()
            summed_doe_amt.rename(columns={'current_national_id': NATIONAL_ID}, inplace=True)

            # Merge the summed values into df2
            summed_doe_amt[NATIONAL_ID] = summed_doe_amt[NATIONAL_ID].astype(int)
            contribution_df = contribution_df.merge(summed_doe_amt, on=[NATIONAL_ID, 'plan_type'], how='left')

            # Add the summed doe_amt to the existing doe_amt in df2
            # Check if the doe_amt column exists in df1
            contribution_df.loc[contribution_df['AMOUNT'].notna(), 'contribution_amount'] += contribution_df.loc[contribution_df['AMOUNT'].notna(), 'AMOUNT']

            # Drop the temporary summed column
            contribution_df.drop(columns=['AMOUNT'], inplace=True)


        #Positive DOE_AMOUNT
        # TODO - check if it needs to be processed first - incase of +ve & -ve doe_amt for same win_nbr
        positive_doe_amt_df = correction_df[correction_df['AMOUNT'] > 0]
        if positive_doe_amt_df.empty:
            return contribution_df

        template_row = contribution_df.iloc[0].copy()
        positive_doe_amt_df.rename(columns={'AMOUNT': 'contribution_amount'}, inplace=True)
        new_row_list: list = []
        for _, row in positive_doe_amt_df.iterrows():
            new_row = template_row.copy()
            new_row['associate_eligible_wage'] = 0.0
            for col in new_row.index:
                if col in row.index:
                    new_row[col] = row[col]
            new_row_list.append(new_row)

        contribution_df = pd.concat([contribution_df, pd.DataFrame(new_row_list)], ignore_index=True)

        # TODO - What should be done for AMOUNT = 0 case?
        return contribution_df

    def get_dates_for_header(self):
        """
        Returns the dates for the header record.
        :return: Tuple of (bi_weekly_start_date, pay_date)
        """
        try:
            gcp_project = self.flow_config.get("gcp_project")
            if not gcp_project:
                error_msg = f"Missing GCP configuration. Project: {gcp_project}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

            query = GET_BI_WEEKLY_START_AND_PAY_DATES.format(
                gcp_project=gcp_project,
                pay_center_id = self.pay_center_id
            )

            dates_df = self.gcp_connection.get_df_from_query(query)
            payroll_end_date = pd.to_datetime(dates_df['PAYROLL_END_DATE']).dt.strftime('%m%d%y').iloc[0]
            # apply the date formatting
            bi_weekly_start_date = pd.to_datetime(dates_df['BI_WEEKLY_START_DATE']).dt.strftime('%Y%m%d').iloc[0]
            # apply the WV,PR logic - payDate - 1 for WV
            pay_date = dates_df['PAY_DATE'].apply(lambda x: (x - pd.Timedelta(days=1)).strftime('%Y%m%d') if self.region == 'WV' else x.strftime('%Y%m%d')).iloc[0]

            return payroll_end_date,bi_weekly_start_date, pay_date
        except Exception as e:
            self.logger.error("Error while fetching bi_weekly start date: {error_message}".format(error_message=str(e)))
            raise