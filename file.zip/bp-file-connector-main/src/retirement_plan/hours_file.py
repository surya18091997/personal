from src.constants import F_ERROR, F_COMPLETED, WAGE_FILE_DATE_ERROR, CFG_WORKING_DIR, FLOW_CONFIG, CFG_FLOW_CONFIG, \
    CFG_BIGQUERY_DATASET, CFG_BIGQUERY_DATASET_GTA, CFG_PLATFORM_DEV, CFG_BUCKET_NAME, CFG_DESTINATION_PATH, \
    HR_ASC_HOURS_TYPE, ASC_DAILY_PAY_SUM, ETCAR_ASC_DAILY_PAY_SUM, PAID_ASSOCIATE, CFG_GCP_PROJECT, ERROR_INIT_FILE, \
    INFO_USING_RUN_DATE, INFO_START_PROCESSING, ERROR_NO_SOURCE_FILES, INFO_COMPLETED_PROCESSING, ERROR_PROCESS_QUERY, \
    ERROR_PROCESS_FAILED, INFO_ALL_QUERIES_SUCCESS, ERROR_FILE_GENERATION, STRIP_DATE, MAX_DATE
from src.generate_file.file_generator import FileGenerator
from src.integrations.gcs_utils import GCSUtils
from src.utils import app_config
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError
from src.utils.sql import (
    ELIGIBLE_HOURS_HR_ASC_HOURS_TYPE_QUERY,
    ELIGIBLE_HOURS_ASC_DAILY_PAY_SUM,
    ELIGIBLE_HOURS_ETCAR_ASC_DAILY_PAY_SUM,
    PAID_ASSOCIATE_QUERY, GET_MAX_RUN_DATE_FOR_HOURS_QUERY
)

class HoursFile(FileGenerator):
    """Handles fetching eligible hours data and generating files."""


    def __init__(self, configuration_id, logger, request_id, start_date):
        try:
            super().__init__(configuration_id, logger, request_id, start_date, start_date)

            # Get config from CCM
            self.flow_config = app_config.get_config_value(CFG_FLOW_CONFIG, str(configuration_id))
            self.gcp_project = self.flow_config.get(CFG_GCP_PROJECT)
            self.bigquery_dataset = self.flow_config.get(CFG_BIGQUERY_DATASET)
            self.bigquery_dataset_GTA = self.flow_config.get(CFG_BIGQUERY_DATASET_GTA, CFG_PLATFORM_DEV)

            # Setup GCS paths
            self.bucket_name = self.flow_config.get(CFG_BUCKET_NAME)
            self.destination_folder = self.flow_config.get(CFG_DESTINATION_PATH)
            self.working_dir = f"{CFG_WORKING_DIR}/{self.request_id}"

            # Initialize GCS utils
            self.gcs_util = GCSUtils(logger)

        except Exception as e:
            raise ApplicationError(ERROR_INIT_FILE.format(str(e)))

    def start_process(self):
        """
        Executes a multi-query workflow to process various types of hour and pay data from BigQuery and export to GCS.
        Handles multiple query executions, with individual error handling for each query

        The process exports four different datasets:
        - HR ASC Hours Type data
        - ASC Daily Pay Summary
        - ETCAR ASC Daily Pay Summary
        - Paid Associate data

        Raises:
            ApplicationError: If any critical step fails or if one or more queries fail to process
        """
        try:
            # Step 1: Configure and validate the query date

            query_date = self.start_date.date() if hasattr(self.start_date, 'date') else self.start_date

            # Fall back to max run date if no run date provided
            if not query_date:
                query_date = self.get_max_run_date()

            # Format date for file naming convention
            # date_suffix = query_date.strftime(STRIP_DATE)
            date_suffix = ""
            self.logger.info(INFO_USING_RUN_DATE.format(query_date))

            # Step 2: Prepare query parameters
            replacements = {
                '{gcp_project}': self.gcp_project,
                '{bigquery_dataset}': self.bigquery_dataset,
                '{bigquery_dataset_GTA}': self.bigquery_dataset_GTA,
                '@run_date': f"'{query_date}'"
            }

            # Define list of queries to process with their respective names
            export_queries = [
                (HR_ASC_HOURS_TYPE, ELIGIBLE_HOURS_HR_ASC_HOURS_TYPE_QUERY),
                (ASC_DAILY_PAY_SUM, ELIGIBLE_HOURS_ASC_DAILY_PAY_SUM),
                (ETCAR_ASC_DAILY_PAY_SUM, ELIGIBLE_HOURS_ETCAR_ASC_DAILY_PAY_SUM),
                (PAID_ASSOCIATE, PAID_ASSOCIATE_QUERY)
            ]

            # Step 3: Execute each query and process its results
            # Track failed queries for error reporting
            failed_queries = []
            for query_name, base_query in export_queries:
                try:
                    self.logger.info(INFO_START_PROCESSING.format(query_name))

                    # Execute BigQuery and export results to temporary GCS location
                    job = self.gcs_util.export_query_to_gcs(
                        query_name,
                        base_query,
                        self.working_dir, # Exporting into GCS working directory
                        date_suffix,
                        self.bucket_name,
                        replacements
                    )

                    # Wait for query execution to complete
                    self.gcs_util.wait_for_job(job)

                    # Locate exported files in temporary location
                    source_files = self.gcs_util.list_files_in_working_dir(
                        self.bucket_name,
                        self.working_dir,
                        query_name,
                        date_suffix
                    )

                    # Verify export produced files
                    if not source_files:
                        raise ApplicationError(ERROR_NO_SOURCE_FILES.format(query_name))

                    # Generate final destination path
                    dest_path = self.gcs_util.get_destination_path(
                        self.destination_folder,
                        query_name,
                        date_suffix
                    )

                    # Move files from temporary to final location
                    self.gcs_util.copy_blob(
                        self.bucket_name,
                        source_files,
                        dest_path
                    )

                    self.logger.info(INFO_COMPLETED_PROCESSING.format(query_name))
                except Exception as e:
                    # Log individual query failures but continue processing others
                    self.logger.error(ERROR_PROCESS_QUERY.format(query_name, str(e)))
                    failed_queries.append(query_name)

            # Step 4: Final status update and error handling
            # If any queries failed, raise error with details
            if failed_queries:
                error_msg = ERROR_PROCESS_FAILED.format(', '.join(failed_queries))
                update_request_status(self.request_id, F_ERROR, self.logger, error_msg)
                raise ApplicationError(error_msg)

            # Log success and update status if all queries processed successfully
            self.logger.info(INFO_ALL_QUERIES_SUCCESS)
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            # Handle any unexpected errors in the overall process
            error_msg = ERROR_FILE_GENERATION.format(str(e))
            self.logger.error(error_msg)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise ApplicationError(error_msg)

    def get_max_run_date(self):
        """Get max run date from hours table if not provided."""
        try:
            query = GET_MAX_RUN_DATE_FOR_HOURS_QUERY.format(
                gcp_project=self.gcp_project,
                bigquery_dataset=self.bigquery_dataset
            )
            result = self.gcp_connection.get_df_from_query(query)
            return result[MAX_DATE].iloc[0]
        except Exception as e:
            raise ApplicationError(WAGE_FILE_DATE_ERROR.format(error=str(e)))