from src.constants import F_COMPLETED, F_ERROR, FG_EMPTY_FILE_INFO, DATE_FORMAT_YYYY_MM_DD
from src.generate_file.file_generator import FileGenerator
from src.utils import app_config
from src.utils.common_utils import update_request_status
import pandas as pd


class RateChangeOutbound(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        super().__init__(configuration_id, logger, request_id, start_date, end_date)
        # Get config from CCM
        self.flow_config = app_config.get_config_value("flow_config", str(configuration_id))
        self.planId = self.flow_config["plan_id"]

    """"
        1. Working directory checkups
        2. Fetch Driving query -> generate query based on config Id and call cosmos executor from file_gen.py
        3. Fetch Core_HR + BQ data (combine this into one function in file_gen.py)
        4. Process the data frame => column level adjustments
        5. Extract the df_dic generator as separate method
        6. Fetch rate and consent data
        7. Update record_dict with contribution and consent data
        8. Apply rate change specific rules
        9. Extract file generation as separate method and Call it
        10. Transfer the files to GCS bucket
        11. Transfer the file to mainframe
    """""

    def start_process(self):
        try:
            # Step1  : working_dir setup
            self.create_working_directory(self.request_id)
            # Step2  : fetch the rate change list from transaction logs
            rate_change_associate_list = self.get_latest_approved_rate_changes()
            # Step3  : get the associate data
            associate_info_df = self.get_associate_info(rate_change_associate_list)
            # Check if dataframe is empty
            if associate_info_df.empty:
                self.logger.info(FG_EMPTY_FILE_INFO)
                # Create empty record dict to be used for header/trailer generation
                record_dict = {}
            else:
                # Step4  : process the dataframe
                associate_info_df = self.process_core_hr_df(associate_info_df)
                # Step5  : generate the dict
                record_dict = self.generate_record_dict(associate_info_df, rate_change_associate_list)
                # Step6  : get the contribution dataframe and process contribution data
                contribution_df = self.fetch_associate_contribution(rate_change_associate_list)
                contribution_df = self.process_contribution_df(contribution_df)
                # Step7 : Update record_dict with contribution data only
                record_dict = self.update_contribution_data(record_dict, contribution_df)
                # Step8: Get consent data and apply rate change specific updates
                consent_df = self.fetch_associate_consent(rate_change_associate_list)
                self.apply_plan_specific_record_updates(record_dict, consent_df)
            # Step9 : Apply attributes based on record types in config
            record_dict = self.apply_plan_detail_attributes(record_dict)
            # Step10  : generate the files
            self.initiate_flat_file_generation(record_dict)
            # Step11  : transfer the file to GCS bucket
            self.transfer_file_to_gcs()
            # Step12  : transfer the file to mainframe
            self.transfer_file_to_mainframe()
            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(f'Error in generate_file: {e}')
            update_request_status(self.request_id, F_ERROR, self.logger)
            raise

    """
    Modified method to get rate changes only for associates whose latest transaction 
    log entry was created by OE or ME_APP within the specified date range.

    This method first gets all rate change transaction logs within the specified date range,
    then filters to only include those whose latest entry was created by an approved source.
    """

    def get_latest_approved_rate_changes(self):
        try:
            if self.start_date and self.end_date:
                self.logger.info(f"Using provided date range: {self.start_date} to {self.end_date}")
                start_date_str = self.start_date.strftime(DATE_FORMAT_YYYY_MM_DD)
                end_date_str = self.end_date.strftime(DATE_FORMAT_YYYY_MM_DD)

                # Modified projection to include both created and modified fields
                all_txn_logs = self.cosmos_connection.get_structured_data(
                    cosmos_database='benefits-platform',
                    cosmos_collection='transaction-logs',
                    cosmos_projection="c.associateId, c.createdAt, c.createdBy, c.lastModifiedAt, c.lastModifiedBy",
                    cosmos_search_criteria={
                        "where": f"c.activity = '{self.flow_name}' " +
                                 f"AND SUBSTRING(c.createdAt, 0, 10) >= '{start_date_str}' " +
                                 f"AND SUBSTRING(c.createdAt, 0, 10) <= '{end_date_str}'" +
                                 f"AND c.planId in ('retirement_401k_regular_us','retirement_401k_regular_pr'," +
                                 f"'retirement_401k_catchup_regular_us','retirement_401k_catchup_regular_pr')"
                    }
                )
                if not all_txn_logs:
                    self.logger.info("No rate change transaction logs found")
                    return []
                # Convert to DataFrame for easier processing
                txn_df = pd.DataFrame(all_txn_logs)
                # Convert datetime fields to proper datetime objects
                txn_df['createdAt'] = pd.to_datetime(txn_df['createdAt'])
                txn_df['lastModifiedAt'] = pd.to_datetime(txn_df['lastModifiedAt'], errors='coerce')
                # Create columns for the actual timestamp and source to use for filtering
                # Priority: lastModifiedAt if present, otherwise createdAt
                txn_df['effective_timestamp'] = txn_df.apply(
                    lambda row: row['lastModifiedAt'] if pd.notna(row['lastModifiedAt']) else row['createdAt'],
                    axis=1
                )
                txn_df['effective_source'] = txn_df.apply(
                    lambda row: row['lastModifiedBy'] if pd.notna(row['lastModifiedBy']) else row['createdBy'],
                    axis=1
                )
                # Sort by associateId and effective_timestamp (most recent first)
                txn_df = txn_df.sort_values(['associateId', 'effective_timestamp'], ascending=[True, False])
                # Get latest transaction for each associate
                latest_txns = txn_df.drop_duplicates(subset=['associateId'], keep='first')
                # Filter to only include those with latest transaction from approved sources
                approved_txns = latest_txns[latest_txns['effective_source'].isin(['OE', 'ME_APP'])]
                # Return the list of eligible associate IDs
                return approved_txns['associateId'].unique().tolist()

        except Exception as e:
            self.logger.error(f"Error in get_transaction_logs: {str(e)}")
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

    """
    Applies rate change specific field overrides and updates contribution and consent fields.

    Args:
        record_dict (dict): The record dictionary to be updated
        consent_df (pandas.DataFrame, optional): DataFrame containing consent data

    Returns:
        dict: The updated record dictionary
    """

    def apply_plan_specific_record_updates(self, record_dict, consent_df=None):
        try:
            # Update contribution fields in r01 if not already handled by update_contribution_data
            if 'r01' in record_dict:
                # If contribution fields are missing, set default values
                if 'R01-SAVINGS-RATES-INCLUDED' not in record_dict['r01'].columns:
                    record_dict['r01']['R01-SAVINGS-RATES-INCLUDED'] = " "
                if 'R01-ELECT-BT-SAVE-RATE' not in record_dict['r01'].columns:
                    record_dict['r01']['R01-ELECT-BT-SAVE-RATE'] = " "
                if 'R01-ELECT-BT-CUC-SAVE-RATE' not in record_dict['r01'].columns:
                    record_dict['r01']['R01-ELECT-BT-CUC-SAVE-RATE'] = " "
                self.logger.info("Ensured contribution fields exist in r01 records")

            # Update consent fields in r02 if available
            if 'r02' in record_dict:
                record_dict['r02'].set_index('associate_id', inplace=True)
                consent_df.set_index('WIN_NBR', inplace=True)
                columns_to_update = ['R02-OPT-IN-OUT-FLAG', 'R02-EMAIL-TYPE', 'R02-EMAIL-ADDRESS']
                record_dict['r02'].update(consent_df[columns_to_update])
                record_dict['r02'].reset_index(inplace=True)
                record_dict['r02']['R02-OPT-IN-OUT-FLAG'] = (
                    record_dict['r02']['R02-OPT-IN-OUT-FLAG']
                    .fillna('')
                    .astype(str)
                    .str.strip()
                    .replace('', '0')
                )
                self.logger.info(f"Updated {len(consent_df)} records with consent data")

            # Override fields with spaces as per rate change requirements
            columns_to_override = [
                'R01-ACTION', 'LAST_NAME', 'FIRST_NAME', 'HOME_ADDR_LINE_1', 'HOME_ADDR_LINE_2', 'CITY_NAME',
                'R01-BDAY-DD', 'R01-BDAY-MM', 'R01-BDAY-YY', 'R01-HDAY-DD', 'R01-HDAY-MM',
                'R01-HDAY-YY', 'R01-HCE-INDICATOR', 'COMP_FREQ_CODE', 'STATE_PROV_CODE',
                'POSTAL_CODE', 'GENDER_CODE', 'ACT_MARITAL_CODE'
            ]

            for record_type, df in record_dict.items():
                if not df.empty:
                    for col in columns_to_override:
                        if col in df.columns:
                            df[col] = " "

            return record_dict

        except Exception as e:
            self.logger.error(f"Error applying plan-specific updates: {e}")
            raise