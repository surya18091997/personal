from src.constants import F_COMPLETED, F_ERROR
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status


class LoanInbound(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        super().__init__(configuration_id, logger, request_id, start_date, end_date)
        self.logger.info(f"Loan initialized with request_id: {request_id}")

    def start_process(self):
        try:
            self.logger.info("Initiated Loan inbound file")
            # Step 1: Create working directory
            self.create_working_directory(self.request_id)
            # Step 2: Transfer from mainframe
            self.get_file_from_mainframe()
            # Step 3: Transfer to Azure directory
            self.transfer_file_to_azure_directory()
            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(f"Failed during file transfer: {str(e)}", exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

        self.logger.info("File transfer process completed")

    def __str__(self):
        return f"Loan (request_id={self.request_id}, dest_file={self.dest_file})"
