import pandas as pd

from src.constants import CFG_FLOW_CONFIG, CFG_BUCKET_NAME, CFG_WORKING_DIR, ERROR_INIT_FILE, \
    ERROR_FILE_GENERATION, F_ERROR, RAW_JSON_COLUMNS_LIST, EVENT_TYPE_REHIRE, \
    CFG_GCP_PROJECT, CFG_GCP_REGION, DATAPROC_DEFAULT_PYTHON_MAIN_FILE_URI, GCP_SERVICE_ACCOUNT, GCP_SUBNETWORK_URI, \
    CUSTOM_CONTAINER_IMAGE, F_COMPLETED, POST_PAYROLL_SNAPSHOT_HUDI_PATH, PROFILE_HUDI_PATH, PROFILE_OUTPUT_PATH, \
    POST_PAYROLL_SNAPSHOT_OUTPUT_PATH, JSON_TYPE, ASSOCIATE_ID_FILTER_TEMP_FILE, DATAPROC_HUDI_UNLOAD_PREFIX
from src.generate_file.file_generator import FileGenerator
from src.integrations.dataproc_serverless_util import DataprocServerlessUtil
from src.integrations.postgre_sql_conn_helper import PostgresGCPConnection
from src.utils import app_config
from src.utils.common_utils import update_request_status
from src.utils.errors.app_errors import ApplicationError
from src.utils.sql import SELECT_QUEUED_RECORDS


class RehireDataLakeUnload(FileGenerator):

    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        try:
            super().__init__(configuration_id, logger, request_id, start_date, end_date)
            # Get config from CCM
            self.flow_config = app_config.get_config_value(CFG_FLOW_CONFIG, str(configuration_id))
            self.gcp_project = self.flow_config.get(CFG_GCP_PROJECT)
            self.gcp_region = self.flow_config.get(CFG_GCP_REGION)
            self.db_connection = PostgresGCPConnection(logger=logger)
            self.bucket_name = self.flow_config.get(CFG_BUCKET_NAME)
            self.profile_hudi_path = self.flow_config.get(PROFILE_HUDI_PATH)
            self.post_payroll_snapshot_hudi_path = self.flow_config.get(POST_PAYROLL_SNAPSHOT_HUDI_PATH)
            self.raw_json_columns_list = self.flow_config.get(RAW_JSON_COLUMNS_LIST)
            self.profile_output_path = self.flow_config.get(PROFILE_OUTPUT_PATH)
            self.post_payroll_snapshot_output_path = self.flow_config.get(POST_PAYROLL_SNAPSHOT_OUTPUT_PATH)
            self.working_dir = f"gs://{self.bucket_name}/{CFG_WORKING_DIR}/{self.request_id}"
            self.filter_file_path = f"{self.working_dir}/{ASSOCIATE_ID_FILTER_TEMP_FILE}"
            self.service_account = self.flow_config.get(GCP_SERVICE_ACCOUNT)
            self.subnetwork_uri = self.flow_config.get(GCP_SUBNETWORK_URI)
            self.custom_container_image = self.flow_config.get(CUSTOM_CONTAINER_IMAGE)
            self.batch_name = f"{DATAPROC_HUDI_UNLOAD_PREFIX}{self.request_id}"
        except Exception as e:
            raise ApplicationError(ERROR_INIT_FILE.format(str(e)))

    def start_process(self):
        """Main process to handle rehire data lake unload."""
        try:
            queued_rehire_records_df = self._fetch_queued_records()
            self._write_filter_file(queued_rehire_records_df)
            self._submit_dataproc_job(self.batch_name + '-1', self.profile_hudi_path, self.profile_output_path, self.logger)
            self._submit_dataproc_job(self.batch_name + '-2', self.post_payroll_snapshot_hudi_path, self.post_payroll_snapshot_output_path, self.logger)
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            error_msg = ERROR_FILE_GENERATION.format(EVENT_TYPE_REHIRE, str(e))
            self.logger.error(error_msg)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise ApplicationError(error_msg)

    def _fetch_queued_records(self):
        """Fetch queued rehire records from database."""
        with self.db_connection as conn:
            queued_rehire_records = conn.execute_query(SELECT_QUEUED_RECORDS, (EVENT_TYPE_REHIRE,))
            return pd.DataFrame(queued_rehire_records, columns=[desc[0] for desc in conn.cursor.description])

    def _write_filter_file(self, df):
        """Write filter file to GCS."""
        try:
            df.to_csv(self.filter_file_path,
                      storage_options={'token': None},
                      index=False, header=True)
            self.logger.info(f"Successfully wrote filter file to {self.filter_file_path}")
        except Exception as e:
            error_msg = f"Failed to write filter file: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)

    def _submit_dataproc_job(self, batch_name, table_path, output_path, logger):
        """Submit and monitor Dataproc batch job."""
        try:
            dataproc_util = DataprocServerlessUtil(
                project_id=self.gcp_project,
                region=self.gcp_region,
                logger=logger
            )

            dataproc_util.submit_batch(
                batch_id=batch_name,
                main_python_file_uri=DATAPROC_DEFAULT_PYTHON_MAIN_FILE_URI,
                args=[table_path, self.raw_json_columns_list, output_path, JSON_TYPE,
                      self.filter_file_path],
                timeout_minutes=30,
                service_account=self.service_account,
                properties={
                    "spark.executor.memory": "4g",
                    "spark.driver.memory": "4g"
                },
                container_image=self.custom_container_image,
                subnetwork=self.subnetwork_uri,
                runtime_version='1.2',
            )
            self.logger.info(f"Successfully completed Dataproc batch job with ID: {self.batch_name}.\n")
        except Exception as e:
            error_msg = f"Failed to submit/complete Dataproc job: {str(e)}"
            self.logger.error(error_msg)
            raise ApplicationError(error_msg)
