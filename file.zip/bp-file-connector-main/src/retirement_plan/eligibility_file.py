import datetime
import pandas as pd
from src.constants import (
    F_ERROR, F_COMPLETED, FG_EMPTY_FILE_INFO,
    LOG_REHIRE_ASSOCIATES_FOUND, LOG_COMBINED_ASSOCIATES,
    LOG_CONSENT_DATA_UPDATED,
    LOG_CONSENT_DEFAULT_VALUES, LOG_FILE_GENERATION_FAILED,
    LOG_FILE_TRANSFER_COMPLETED, LOG_REHIRE_BASE_ERROR,
    LOG_PLAN_UPDATES_ERROR,
    FLOW_NAME_RE_HIRE_BASE,
    FIELD_ASSOCIATE_ID, FIELD_WIN_NBR,
    R01_ELECT_BT_SAVE_RATE,
    R01_ELECT_BT_CUC_SAVE_RATE,
    R02_CONSENT_FIELDS, VALUE_EMPTY, DEFAULT_CONSENT_VALUES, REHIRE_CREDIT_IND,
    LOG_ELIGIBILITY_INITIALIZED, LOG_PROCESSING_REHIRE_LOGS,
    LOG_SKIPPING_ASSOCIATE, LOG_FILTERED_REHIRES,
    LOG_NO_R01_RECORDS, LOG_APPLIED_REHIRE_FIELDS,
    LOG_REHIRE_FIELDS_ERROR, DEF_YEARS_OF_SERVICE, DEF_HOURS_SERVICE
)
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status
from src.utils.sql import STATE_TRANSFER_TO_US, STATE_TRANSFER_TO_PR


class Eligibility(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        super().__init__(configuration_id, logger, request_id, start_date, end_date)
        self.is_rehire = configuration_id in [5, 6]
        self.logger.info(LOG_ELIGIBILITY_INITIALIZED.format(configuration_id, self.is_rehire))
        self.rehire_comment_map = {}  # Store comment first byte for each rehire associate

    """"
        1. Working directory checkups
        2. Fetch Driving query -> generate query based on config Id and call cosmos executor from file_gen.py
        3. Fetch the eligible associate list from the driving query df ( transaction logs )
        4. Filter based on US & PR (config_Id)
        5. Fetch Core_HR + BQ data (combine this into one function in file_gen.py)
        6. Process the data frame => column level adjustments
        7. Extract the df_dic generator as separate method
        8. Apply state_transfer specific rules
        9. Extract file generation as separate method and Call it
        10. Transfer the files to GCS bucket
        11. Transfer the file to mainframe
    """""

    def start_process(self):
        try:
            # Step1: working_dir setup
            self.create_working_directory(self.request_id)
            # Step2: fetch the eligible list from transaction logs (NEW_HIRE activity)
            newly_eligible_list = []


            newly_eligible_list = self.get_transaction_logs()

            # Initialize lists to avoid reference before assignment
            rehire_base_list = []
            state_transfer_list = []

            # For rehire config, process differently using comments
            if self.is_rehire:
                # Get rehire transaction logs with comments
                rehire_transaction_logs = self.get_transaction_logs_with_comments()
                # Filter based on comment criteria and store in rehire_comment_map for later use
                eligible_associates = self._process_rehire_comments(rehire_transaction_logs)
            else:
                # Get RE_HIRE_BASE associates separately for additional processing (non-rehire configs)
                rehire_base_list = self.get_rehire_base_associates()
                self.logger.info(LOG_REHIRE_ASSOCIATES_FOUND.format(len(rehire_base_list)))

                # For configuration IDs 1 and 4 (NEW_HIRE flows), also include state transfer associates
                if self.configuration_id in [1, 4]:
                    state_transfer_list = self.get_state_transfer_associates()
                # Combine all lists for processing (removing duplicates)
                eligible_associates = list(set(newly_eligible_list + rehire_base_list + state_transfer_list))
                self.logger.info(LOG_COMBINED_ASSOCIATES.format(len(eligible_associates)))

            # Step3: get the associate profile data
            associate_info_df = self.get_associate_info(eligible_associates)
            # Create empty record dict with only header/trailer if no eligible associates found
            if associate_info_df.empty:
                self.logger.info(FG_EMPTY_FILE_INFO)
                plan_updated_record_dict = self.apply_plan_detail_attributes({})
            else:
                # Step4: process the dataframe
                associate_info_df = self.process_core_hr_df(associate_info_df)
                # Step5: generate the dict
                record_dict = self.generate_record_dict(associate_info_df, eligible_associates)

                # Step6: fetch hire date, experience years, and eligible hours FIRST
                hire_date_df = self.fetch_hire_date(eligible_associates)
                experience_years_df = self.fetch_experience_years(eligible_associates)
                eligible_hours_term_df = self.fetch_eligible_hours(eligible_associates)

                # Generate the dict using the processed dataframe
                record_dict = self.generate_record_dict(associate_info_df, eligible_associates)

                if hire_date_df is not None and not hire_date_df.empty:
                    columns_to_update = ['R01-HDAY-MM', 'R01-HDAY-DD', 'R01-HDAY-YY']
                    if 'r01' in record_dict and all(col in hire_date_df.columns for col in columns_to_update):
                        hire_date_df.set_index('associateId', inplace=True)
                        record_dict['r01'].set_index('associate_id', inplace=True)
                        record_dict['r01'].update(hire_date_df[columns_to_update])
                        record_dict['r01'].reset_index(inplace=True)
                        self.logger.info(f"Updated {len(hire_date_df)} records with hire date data from Cosmos")

                # Step7: fetch contribution and consent data
                contribution_df = self.fetch_associate_contribution(eligible_associates)
                contribution_df = self.process_contribution_df(contribution_df)
                consent_df = self.fetch_associate_consent(eligible_associates)

                # Step8: Apply all fetched data to records FIRST
                record_dict = self.apply_plan_specific_record_updates(record_dict, consent_df,
                                                                      hire_date_df, experience_years_df,
                                                                      eligible_hours_term_df)
                record_dict = self.update_contribution_data(record_dict, contribution_df)

                # Step9: THEN apply field overrides to ensure they take precedence
                if self.is_rehire:
                    record_dict = self._apply_rehire_specific_fields(record_dict, associate_info_df)
                else:
                    # For non-rehire configs, apply empty values for specific fields for all associate types
                    # Combine all the associate lists that should get field overrides
                    all_associates_for_override = list(
                        set(newly_eligible_list + rehire_base_list + state_transfer_list))
                    record_dict = self.override_fields_for_new_hire(record_dict, all_associates_for_override)

                # Step10: Apply plan attributes LAST
                plan_updated_record_dict = self.apply_plan_detail_attributes(record_dict)
            # Generate the files
            self.initiate_flat_file_generation(plan_updated_record_dict)
            # Transfer the file to GCS
            self.transfer_file_to_gcs()
            # Transfer the file to mainframe
            self.transfer_file_to_mainframe()
            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(LOG_FILE_GENERATION_FAILED.format(str(e)), exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

        self.logger.info(LOG_FILE_TRANSFER_COMPLETED)

    """
    Retrieves associates specifically with RE_HIRE_BASE activity.
    """
    def get_rehire_base_associates(self):
        try:
            # Save original flow_name
            original_flow_name = self.flow_name
            # Temporarily change flow_name to get RE_HIRE associates
            self.flow_name = FLOW_NAME_RE_HIRE_BASE
            rehire_base_list = self.get_transaction_logs()
            # Restore original flow_name
            self.flow_name = original_flow_name
            return rehire_base_list
        except Exception as e:
            self.logger.error(LOG_REHIRE_BASE_ERROR.format(str(e)))
            return []

    """
    Process rehire transaction logs to filter associates based on comment criteria.
    Only include associates whose comments' first byte is one of 1,2,3,4,5,6.

    Args:
        transaction_logs (list): List of transaction logs with comments

    Returns:
        list: Filtered list of eligible associate IDs
    """
    def _process_rehire_comments(self, transaction_logs):
        eligible_associates = []
        skipped_count = 0

        self.logger.info(LOG_PROCESSING_REHIRE_LOGS.format(len(transaction_logs)))
        # Store comment values for later use when populating R01-REHIRE-CREDIT-IND
        self.rehire_comment_map = {}

        for log in transaction_logs:
            associate_id = log.get('associateId')
            comment = log.get('comment', '')

            # Check if comment exists and first character is one of 1,2,3,4,5,6
            if comment and len(comment) > 0 and comment[0] in REHIRE_CREDIT_IND:
                eligible_associates.append(associate_id)
                # Store the comment's first character for later use
                self.rehire_comment_map[associate_id] = comment[0]
            else:
                skipped_count += 1
                self.logger.info(LOG_SKIPPING_ASSOCIATE.format(associate_id, comment))

        self.logger.info(LOG_FILTERED_REHIRES.format(len(eligible_associates), skipped_count))
        return eligible_associates

    """
    Apply rehire-specific fields to the record dictionary based on comment values

    Args:
        record_dict (dict): Record dictionary to update
        associate_info_df (DataFrame): Associate information dataframe

    Returns:
        dict: Updated record dictionary with rehire fields
    """

    def override_fields_for_new_hire(self, record_dict, associate_list):
        """
        Overrides specific fields with empty spaces for specified associates.
        This is applied to NEW_HIRE, RE_HIRE_BASE, and STATE_TRANSFER associates in non-rehire configs.
        This method FORCES the override regardless of existing data.
        Also converts 0 or spaces in R05 fields to default values.
        """
        try:
            self.logger.info(f"Applying FORCED field overrides with empty values for {len(associate_list)} associates")

            # Convert associate_list to strings to ensure consistent matching
            associate_list_str = [str(assoc_id) for assoc_id in associate_list]

            # Update r01 contribution fields with empty spaces for specified associates
            if 'r01' in record_dict and not record_dict['r01'].empty:
                # Make a copy to avoid modifying during iteration
                r01_df = record_dict['r01'].copy()

                # Ensure associate_id column is string for consistent matching
                r01_df['associate_id'] = r01_df['associate_id'].astype(str)

                # Create mask for associates that need override
                mask = r01_df['associate_id'].isin(associate_list_str)

                # Apply overrides using .loc to avoid warnings
                r01_df.loc[mask, R01_ELECT_BT_SAVE_RATE] = VALUE_EMPTY
                r01_df.loc[mask, R01_ELECT_BT_CUC_SAVE_RATE] = VALUE_EMPTY

                # Log which associates got overridden
                overridden_associates = r01_df.loc[mask, 'associate_id'].tolist()
                self.logger.info(
                    f"Overrode R01 contribution fields for {len(overridden_associates)} associates: {overridden_associates[:10]}...")

                record_dict['r01'] = r01_df

            # Update r02 email fields with spaces for specified associates
            if 'r02' in record_dict and not record_dict['r02'].empty:
                # Make a copy to avoid modifying during iteration
                r02_df = record_dict['r02'].copy()

                # Ensure associate_id column is string for consistent matching
                r02_df['associate_id'] = r02_df['associate_id'].astype(str)

                # Create mask for associates that need override
                mask = r02_df['associate_id'].isin(associate_list_str)

                # Apply overrides using .loc to avoid warnings
                r02_df.loc[mask, 'R02-EMAIL-ADDRESS'] = " "
                r02_df.loc[mask, 'R02-EMAIL-TYPE'] = " "
                r02_df.loc[mask, 'R02-OPT-IN-OUT-FLAG'] = " "

                # Log which associates got overridden
                overridden_associates = r02_df.loc[mask, 'associate_id'].tolist()
                self.logger.info(
                    f"Overrode R02 email fields for {len(overridden_associates)} associates: {overridden_associates[:10]}...")

                record_dict['r02'] = r02_df

            # Update r05 fields - convert 0 or spaces to default values for specified associates
            if 'r05' in record_dict and not record_dict['r05'].empty:
                # Make a copy to avoid modifying during iteration
                r05_df = record_dict['r05'].copy()

                # Ensure associate_id column is string for consistent matching
                r05_df['associate_id'] = r05_df['associate_id'].astype(str)

                # Create mask for associates that need override
                mask = r05_df['associate_id'].isin(associate_list_str)

                # Convert 0, spaces, or empty values to default values for R05-YEARS-OF-SERVICE
                if 'R05-YEARS-OF-SERVICE' in r05_df.columns:
                    years_mask = mask & (
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip() == '') |
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip() == '0') |
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip().str.match(r'^\s*$'))
                    )
                    r05_df.loc[years_mask, 'R05-YEARS-OF-SERVICE'] = DEF_YEARS_OF_SERVICE
                    years_updated_count = years_mask.sum()
                    self.logger.info(
                        f"Updated R05-YEARS-OF-SERVICE to default value for {years_updated_count} associates")

                # Convert 0, spaces, or empty values to default values for R05-HOURS-SERVICE
                if 'R05-HOURS-SERVICE' in r05_df.columns:
                    hours_mask = mask & (
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '') |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '0') |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip().str.match(r'^\s*$')) |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '000000{')
                    )
                    r05_df.loc[hours_mask, 'R05-HOURS-SERVICE'] = DEF_HOURS_SERVICE
                    hours_updated_count = hours_mask.sum()
                    self.logger.info(f"Updated R05-HOURS-SERVICE to default value for {hours_updated_count} associates")

                record_dict['r05'] = r05_df

            self.logger.info(f"SUCCESSFULLY applied FORCED field overrides for {len(associate_list)} associates")
            return record_dict

        except Exception as e:
            self.logger.error(f"Error applying field overrides: {str(e)}", exc_info=True)
            return record_dict

    def get_state_transfer_associates(self):
        """
        Retrieves associates with STATE_TRANSFER activity for inclusion in NEW_HIRE flows.
        This method follows the same two-step process as state_transfer_file.py:
        1. Get transaction logs for STATE_TRANSFER activity
        2. Filter through eligible_state_transfers to get actual US-PR or PR-US transfers
        """
        original_flow_name = None
        try:
            # Save original flow_name
            original_flow_name = self.flow_name
            # Temporarily change flow_name to get STATE_TRANSFER associates
            self.flow_name = 'STATE_TRANSFER'

            # Step 1: Fetch the transfers list from transaction logs (same as state_transfer_file.py)
            transfers_associate_list = self.get_transaction_logs()
            self.logger.info(f"Found {len(transfers_associate_list)} STATE_TRANSFER transaction log entries")

            # Restore original flow_name before calling eligible_state_transfers
            self.flow_name = original_flow_name

            # Step 2: Get the eligible transfers (US-PR or PR-US) from all transfers (same as state_transfer_file.py)
            if transfers_associate_list and self.start_date and self.end_date:
                eligible_associate_transfers = self.eligible_state_transfers(transfers_associate_list, self.start_date,
                                                                             self.end_date)
                self.logger.info(f"Filtered to {len(eligible_associate_transfers)} eligible state transfer associates")
                return eligible_associate_transfers
            else:
                self.logger.info("No transfers found or missing date range for state transfer filtering")
                return []

        except Exception as e:
            self.logger.error(f"Error retrieving state transfer associates: {str(e)}")
            # Restore original flow_name even if there's an error
            if original_flow_name is not None:
                self.flow_name = original_flow_name
            return []

    def eligible_state_transfers(self, associate_list, start_date, end_date):
        """
        Retrieves the eligible state transfers from the specified DB2 collection based on the associate list and date range.
        Args:
            associate_list (list): List of associate IDs.
            start_date (datetime.datetime): The start date for the query.
            end_date (datetime.datetime): The end date for the query.
        Returns:
            list: A list of eligible associate transfer IDs
        """
        try:
            associate_list_str = ",".join([f"'{win}'" for win in associate_list])
            # TODO maintain a CCM config for state_transfer and get it from app_config.get('state_transfer')['transfer_col_names']
            transfer_col_names = ['WIN_NBR', 'CURRENT_STATE', 'PREVIOUS_STATE']

            # Handle both datetime objects and string dates
            if hasattr(start_date, 'strftime'):
                start_date_str = start_date.strftime('%Y-%m-%d')
            else:
                start_date_str = str(start_date)

            if hasattr(end_date, 'strftime'):
                end_date_str = end_date.strftime('%Y-%m-%d')
            else:
                end_date_str = str(end_date)

            query = STATE_TRANSFER_TO_US if self.region == 'US' else STATE_TRANSFER_TO_PR
            eligible_transfers_df = self.get_data_from_db2(
                col_names=transfer_col_names,
                query=query.format(DB2_SCHEMA=self.db2_connection.testset, ASSOCIATE_LIST=associate_list_str,
                                   START_DATE=start_date_str, END_DATE=end_date_str),
                table_name='win_associate'
            )
            eligible_transfers_list = eligible_transfers_df['WIN_NBR'].unique().tolist()

            self.logger.info(
                f'Final eligible state transfers associate count for {self.region} is {len(eligible_transfers_list)}')

            if len(eligible_transfers_list) == 0:
                self.logger.warning("Empty result set for the given state transfer query")

            return eligible_transfers_list

        except Exception as e:
            self.logger.error(f"Error in eligible_state_transfers: {str(e)}")
            return []

    def apply_plan_specific_record_updates(self, record_dict, consent_df=None, hire_date_df=None,
                                           experience_years_df=None, eligible_hours_term_df=None):
        """
            Applies eligibility specific updates including consent fields.

            Args:
                record_dict (dict): The record dictionary to be updated
                consent_df (pandas.DataFrame): DataFrame containing consent data

            Returns:
                dict: The updated record dictionary
            """
        try:
            # Update r02 records with consent data if available
            if 'r02' in record_dict and consent_df is not None:
                record_dict['r02'].set_index(FIELD_ASSOCIATE_ID, inplace=True)
                consent_df.set_index(FIELD_WIN_NBR, inplace=True)
                record_dict['r02'].update(consent_df[R02_CONSENT_FIELDS])
                record_dict['r02'].reset_index(inplace=True)
                self.logger.info(LOG_CONSENT_DATA_UPDATED.format(len(consent_df)))
            else:
                # If r02 exists but no consent data, set default values
                if 'r02' in record_dict:
                    for field, value in DEFAULT_CONSENT_VALUES.items():
                        record_dict['r02'][field] = value
                    self.logger.info(LOG_CONSENT_DEFAULT_VALUES)

            # OVERRIDE: Update hire date information from Cosmos if available (R01-HDAY-*)
            if 'r01' in record_dict and hire_date_df is not None and not hire_date_df.empty:
                # Process hire date from Cosmos originalHireDate field
                hire_date_processed = self._process_cosmos_hire_date(hire_date_df)
                if not hire_date_processed.empty:
                    columns_to_update = ['R01-HDAY-MM', 'R01-HDAY-DD', 'R01-HDAY-YY']
                    if all(col in hire_date_processed.columns for col in columns_to_update):
                        hire_date_processed.set_index('associateId', inplace=True)
                        record_dict['r01'].set_index('associate_id', inplace=True)
                        # Override the core HR hire date with Cosmos hire date
                        record_dict['r01'].update(hire_date_processed[columns_to_update])
                        record_dict['r01'].reset_index(inplace=True)
                        hire_date_processed.reset_index(inplace=True)
                        self.logger.info(f"OVERRIDDEN {len(hire_date_processed)} records with Cosmos hire date data (R01-HDAY-*)")

            # Update eligible hours if available
            if 'r05' in record_dict and eligible_hours_term_df is not None and not eligible_hours_term_df.empty:
                columns_to_update = ['R05-HOURS-SERVICE']
                if all(col in eligible_hours_term_df.columns for col in columns_to_update):
                    eligible_hours_term_df.set_index('associateId', inplace=True)
                    record_dict['r05'].set_index('associate_id', inplace=True)
                    record_dict['r05'].update(eligible_hours_term_df[columns_to_update])
                    record_dict['r05'].reset_index(inplace=True)
                    self.logger.info(f"Updated {len(eligible_hours_term_df)} records with eligible hours data")

            # MISSING: Update experience years if available
            if 'r05' in record_dict and experience_years_df is not None and not experience_years_df.empty:
                columns_to_update = ['R05-YEARS-OF-SERVICE']
                if all(col in experience_years_df.columns for col in columns_to_update):
                    # Convert WIN_NBR to string to match associate_id format
                    experience_years_df['WIN_NBR'] = experience_years_df['WIN_NBR'].astype(str)
                    experience_years_df.set_index('WIN_NBR', inplace=True)
                    record_dict['r05'].set_index('associate_id', inplace=True)
                    record_dict['r05'].update(experience_years_df[columns_to_update])
                    record_dict['r05'].reset_index(inplace=True)
                    experience_years_df.reset_index(inplace=True)
                    self.logger.info(f"Updated {len(experience_years_df)} records with experience years data")

            return record_dict
        except Exception as e:
            self.logger.error(LOG_PLAN_UPDATES_ERROR.format(e))
            raise

    def _process_cosmos_hire_date(self, hire_date_df):
        """
        Process the originalHireDate from Cosmos into R01-HDAY-MM, R01-HDAY-DD, R01-HDAY-YY format.

        Args:
            hire_date_df (pandas.DataFrame): DataFrame with associateId and originalHireDate columns

        Returns:
            pandas.DataFrame: Processed DataFrame with hire date components
        """
        try:
            if hire_date_df.empty or 'originalHireDate' not in hire_date_df.columns:
                self.logger.warning("No originalHireDate data available from Cosmos")
                return pd.DataFrame()

            # Create a copy to avoid modifying the original
            processed_df = hire_date_df.copy()

            # Extract date components from originalHireDate (format: YYYY-MM-DD)
            processed_df[['R01-HDAY-YY', 'R01-HDAY-MM', 'R01-HDAY-DD']] = processed_df['originalHireDate'].str.extract(
                r'(\d{4})-(\d{2})-(\d{2})')

            # Keep only necessary columns
            processed_df = processed_df[['associateId', 'R01-HDAY-MM', 'R01-HDAY-DD', 'R01-HDAY-YY']]

            # Remove rows where date extraction failed
            processed_df = processed_df.dropna(subset=['R01-HDAY-MM', 'R01-HDAY-DD', 'R01-HDAY-YY'])

            self.logger.info(f"Successfully processed {len(processed_df)} Cosmos hire dates")
            return processed_df

        except Exception as e:
            self.logger.error(f"Error processing Cosmos hire date: {str(e)}")
            return pd.DataFrame()

    def _apply_rehire_specific_fields(self, record_dict, associate_info_df):
        """
        Apply rehire-specific fields to the record dictionary based on comment values
        Also converts 0 or spaces in R05 fields to default values.

        NOTE: R01-REHIRE-* fields use Core HR hire date (NOT Cosmos hire date)

        Args:
            record_dict (dict): Record dictionary to update
            associate_info_df (DataFrame): Associate information dataframe

        Returns:
            dict: Updated record dictionary with rehire fields
        """
        try:
            if 'r01' not in record_dict:
                self.logger.warning(LOG_NO_R01_RECORDS)
                return record_dict

            # Create a cross-reference from WIN_NBR to DataFrame index for faster lookups
            associate_idx_map = {}
            for idx, row in associate_info_df.iterrows():
                associate_idx_map[row['WIN_NBR']] = idx

            # Initialize rehire fields with spaces
            record_dict['r01']['R01-REHIRE-CREDIT-IND'] = " "
            record_dict['r01']['R01-REHIRE-MM'] = "  "
            record_dict['r01']['R01-REHIRE-DD'] = "  "
            record_dict['r01']['R01-REHIRE-YY'] = "    "

            # Update rehire fields for each associate
            for idx, row in record_dict['r01'].iterrows():
                associate_id = row['associate_id']

                # Set R01-REHIRE-CREDIT-IND from comment's first byte
                if associate_id in self.rehire_comment_map:
                    record_dict['r01'].at[idx, 'R01-REHIRE-CREDIT-IND'] = self.rehire_comment_map[associate_id]

                    # Find the associate in associate_info_df to get CORE HR hire date for rehire fields
                    if associate_id in associate_idx_map:
                        info_idx = associate_idx_map[associate_id]
                        # Extract CORE HR hire date components (already formatted in process_core_hr_df)
                        # NOTE: These are the CORE HR hire dates, NOT Cosmos hire dates
                        hire_mm = associate_info_df.at[info_idx, 'R01-HDAY-MM']
                        hire_dd = associate_info_df.at[info_idx, 'R01-HDAY-DD']
                        hire_yy = associate_info_df.at[info_idx, 'R01-HDAY-YY']

                        # Set rehire date fields to use CORE HR hire date (not Cosmos)
                        record_dict['r01'].at[idx, 'R01-REHIRE-MM'] = hire_mm
                        record_dict['r01'].at[idx, 'R01-REHIRE-DD'] = hire_dd
                        record_dict['r01'].at[idx, 'R01-REHIRE-YY'] = hire_yy
            # Override R01 contribution fields (SAVE_RATE, CUC_SAVE_RATE) with VALUE_EMPTY for rehire associates
            if 'r01' in record_dict and not record_dict['r01'].empty:
                r01_df = record_dict['r01'].copy()
                rehire_associate_ids = list(self.rehire_comment_map.keys())
                rehire_associate_ids_str = [str(assoc_id) for assoc_id in rehire_associate_ids]
                r01_df['associate_id'] = r01_df['associate_id'].astype(str)
                rehire_mask = r01_df['associate_id'].isin(rehire_associate_ids_str)

                # Apply overrides
                r01_df.loc[rehire_mask, R01_ELECT_BT_SAVE_RATE] = VALUE_EMPTY
                r01_df.loc[rehire_mask, R01_ELECT_BT_CUC_SAVE_RATE] = VALUE_EMPTY

                self.logger.info(
                    f"Overrode R01 contribution fields (SAVE_RATE, CUC_SAVE_RATE) for {rehire_mask.sum()} rehire associates"
                )

                record_dict['r01'] = r01_df

    # Initialize r02 email fields with spaces for rehire associates
            if 'r02' in record_dict:
                record_dict['r02']['R02-EMAIL-ADDRESS'] = " "
                record_dict['r02']['R02-EMAIL-TYPE'] = " "
                record_dict['r02']['R02-OPT-IN-OUT-FLAG'] = " "

            # Handle R05 fields - convert 0 or spaces to default values for rehire associates
            if 'r05' in record_dict and not record_dict['r05'].empty:
                r05_df = record_dict['r05'].copy()

                # Get list of rehire associate IDs
                rehire_associate_ids = list(self.rehire_comment_map.keys())
                rehire_associate_ids_str = [str(assoc_id) for assoc_id in rehire_associate_ids]

                # Ensure associate_id column is string for consistent matching
                r05_df['associate_id'] = r05_df['associate_id'].astype(str)

                # Create mask for rehire associates
                rehire_mask = r05_df['associate_id'].isin(rehire_associate_ids_str)

                # Convert 0, spaces, or empty values to default values for R05-YEARS-OF-SERVICE
                if 'R05-YEARS-OF-SERVICE' in r05_df.columns:
                    years_mask = rehire_mask & (
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip() == '') |
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip() == '0') |
                            (r05_df['R05-YEARS-OF-SERVICE'].astype(str).str.strip().str.match(r'^\s*$'))
                    )
                    r05_df.loc[years_mask, 'R05-YEARS-OF-SERVICE'] = DEF_YEARS_OF_SERVICE
                    years_updated_count = years_mask.sum()
                    self.logger.info(
                        f"Updated R05-YEARS-OF-SERVICE to default value for {years_updated_count} rehire associates")

                # Convert 0, spaces, or empty values to default values for R05-HOURS-SERVICE
                if 'R05-HOURS-SERVICE' in r05_df.columns:
                    hours_mask = rehire_mask & (
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '') |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '0') |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip().str.match(r'^\s*$')) |
                            (r05_df['R05-HOURS-SERVICE'].astype(str).str.strip() == '000000{')
                    )
                    r05_df.loc[hours_mask, 'R05-HOURS-SERVICE'] = DEF_HOURS_SERVICE
                    hours_updated_count = hours_mask.sum()
                    self.logger.info(
                        f"Updated R05-HOURS-SERVICE to default value for {hours_updated_count} rehire associates")

                record_dict['r05'] = r05_df

            self.logger.info(LOG_APPLIED_REHIRE_FIELDS.format(len(record_dict['r01'])))
            self.logger.info("NOTE: R01-REHIRE-* fields use Core HR hire date, R01-HDAY-* fields use Cosmos hire date")
            return record_dict

        except Exception as e:
            self.logger.error(LOG_REHIRE_FIELDS_ERROR.format(str(e)))
            return record_dict