import os
from datetime import datetime, timedelta

import pandas as pd
import pytz

from src.constants import USER_EXIT_INDICATOR, PERMANENTLY_INACTIVE_INDICATOR, IGNORE_INSUFFICIENT_EARNINGS_INDICATOR, \
    NEW_LIMIT_INDICATOR, TRANSACTION_DATA_LENGTH, ACTIVE_INDICATOR, CREATION_CODE_RTMS, TRANSACTION_CODE, \
    CORPORATION_CODE, \
    COMPANY_CODE_PR, COMPANY_CODE_US, CREATION_CODE_P787, SECURE_2_0_CATCHUP_INDICATOR, \
    MSA_TRANSACTIONS_REFERENCE_FILE_NAME, CENTRAL_TIME_ZONE, NATIONAL_ID, TIME_FORMAT_HH_MM_SS, STATE_CODE, \
    SECURE_2_0_FLAG, YES, STOP_IND, DOE_CODE, METHOD_TYPE, RATE, PERIOD_CODE, LIMIT, CREATE_DATE, CREATION_CODE, \
    CREATE_TIME, SENT_TO_PAYR_DATE, TRANSACTION_CODE_COLUMN, CORPORATION_CODE_COLUMN, COMPANY_CODE_COLUMN, \
    EFFECTIVE_DATE, TRANSACTION_DATA, ASSOCIATE_SSN, FIELD_WIN_NBR, SSN_MAPPING_BATCH_SIZE
from src.load_file.file_loader import FileLoader
from src.utils.common_utils import read_file_to_dataframe, write_dataframe_to_file
from src.utils.sql import WIN_SSN_MAPPING_CORE_HR_QUERY


class PayrollTransactionsWriter(FileLoader):
    """
    This class is responsible for loading payroll transactions, including reading deduction driver output file,
    transforming data and loading it into the MSA_TRANSACTION table. Inherits from the FileGenerator class.
    """

    def __init__(self, configuration_id, logger, request_id):
        """
        Initialize the PayrollTransactionsWriter with a configuration ID, logger, request ID.
        Also sets up utilities for Google Cloud Storage (GCS) and file transfer.
        """
        super().__init__(configuration_id, logger, request_id)
        try:
            self.reference_output_file_name = MSA_TRANSACTIONS_REFERENCE_FILE_NAME
            self.output_table_name = f"{self.db2_connection.testset}PEOPLE.{self.output_table_name}"  # Output table name
        except Exception as e:
            self.logger.error(f'Error initialising Payroll transactions writer {e}')

    def start_process(self):
        """
        Orchestrates the process of loading payroll transaction files into the MSA_TRANSACTION table.
        """
        try:

            self.logger.info("Initiating file loader")

            # Step 1: Download source file into the working directory
            self.logger.info("Downloading source file")
            file_download_path = os.path.join(self.cwd, self.request_id, self.source_file_path)
            self.gcs_util.download_file(self.bucket_name, self.source_file_path, file_download_path)

            # Step 2: Read file into pandas dataframe
            self.logger.info("Reading file into dataframe")
            deduction_input_df: pd.DataFrame = read_file_to_dataframe(file_download_path)

            # Step 3: Fetch and populate the National IDs of the associates
            self.logger.info("Fetching and populating National IDs")
            associate_id_list = ','.join([f'{associate_id}' for associate_id in deduction_input_df['WIN_NBR'].unique().tolist()])
            win_national_id_mapping_df = self.fetch_win_ssn_mapping(deduction_input_df['WIN_NBR'].unique().tolist())
            input_df_with_national_ids = pd.merge(deduction_input_df, win_national_id_mapping_df, on='WIN_NBR', how="left")

            # Step 4: Transform input deductions to MSA_TRANSACTION table format
            self.logger.info("Transforming input to MSA_TRANSACTIONS format")
            msa_transaction_columns, transformed_values = self.transform_to_msa_transactions_format(input_df_with_national_ids)

            # Step 5: Write transformed records to working directory in CSV format for future reference
            output_df = pd.DataFrame(transformed_values, columns=msa_transaction_columns)
            output_file_path = os.path.join(self.cwd, self.request_id, self.reference_output_file_name)
            write_dataframe_to_file(output_file_path, output_df, self.logger)
            self.logger.info("Transformed records written into working directory in CSV format for reference.")

            # Step 6: Insert the transformed records into MSA_TRANSACTION table
            self.logger.info("Inserting transformed records into MSA_TRANSACTIONS table")
            self.insert_to_msa_transactions_table(msa_transaction_columns, transformed_values)
            self.logger.info("Transformed records inserted into MSA_TRANSACTIONS table successfully")

        except Exception as e:
            self.logger.error(f'Error while trying to load file to payroll database {e}')
            raise e

    def transform_to_msa_transactions_format(self, deduction_input):
        """
        Transforms the input DataFrame into the format required for the MSA_TRANSACTIONS table.

        :param deduction_input: pandas DataFrame with input data
        :return: A tuple of column names and transformed values for bulk insertion
        """
        try:

            central_time_details = pytz.timezone(CENTRAL_TIME_ZONE)

            # Current date and time in central_time_details
            current_datetime_central = datetime.now(central_time_details)
            effective_date = (current_datetime_central - timedelta(days=1)).date()
            current_time = current_datetime_central
            sent_to_payroll_date = datetime(1,1,1)

            # Sort by NATIONAL_ID
            deduction_input = deduction_input.sort_values(by=[NATIONAL_ID])

            # Transformation logic
            transformed_values = []
            previous_national_id = None
            increment_seconds = 0

            for idx, row in deduction_input.iterrows():
                # Increment time if NATIONAL_ID is the same as the previous record
                # to prevent unique key violation in MSA_TRANSACTIONS table
                if row[NATIONAL_ID] == previous_national_id:
                    increment_seconds += 1
                else:
                    increment_seconds = 0  # Reset increment for a new NATIONAL_ID

                # Adjust current_time with incremented seconds
                adjusted_time = current_time + timedelta(seconds=increment_seconds)
                adjusted_time_str = adjusted_time.strftime(TIME_FORMAT_HH_MM_SS)

                # Format ASSOCIATE_SSN to 10 characters with leading spaces
                associate_ssn = int(row[NATIONAL_ID])

                # Generating INFOR payroll RK transactions.:
                """
                    1. For each row, check 'STOP_IND' column.
                    2. If 'STOP_IND' is 'Y':
                       - Create a stop transaction with rate and limit set to 0.
                       - Format transaction data by combining 'DOE_CODE', user exit indicator, 
                         permanently inactive indicator, ignore insufficient earnings indicator, rate, 
                         new limit indicator, and limit.
                       - Pad transaction data to meet required length.
                    3. If 'STOP_IND' is not 'Y':
                       - Create a start transaction with given rate and limit.
                       - Format transaction data by combining 'DOE_CODE', user exit indicator, 
                         active indicator, ignore insufficient earnings indicator, rate, 
                         new limit indicator, and limit.
                       - Pad transaction data to meet required length."""

                # Set Company code
                company_code = COMPANY_CODE_PR if row[STATE_CODE] == COMPANY_CODE_PR else COMPANY_CODE_US

                # Secure 2.0 Flag
                secure_2_0_flag = True if row[SECURE_2_0_FLAG] == YES else False

                # Build TRANSACTION_DATA
                if row[STOP_IND] == YES:
                    # STOP TRANSACTION -> 0 rate and 0 limit
                    rate_str = f"{0:011}"
                    limit_str = f"{0:011}"
                    transaction_data = "".join([row.get(DOE_CODE, ''), " ", USER_EXIT_INDICATOR,
                                                PERMANENTLY_INACTIVE_INDICATOR,
                                                IGNORE_INSUFFICIENT_EARNINGS_INDICATOR,
                                                rate_str, NEW_LIMIT_INDICATOR,
                                                limit_str]).ljust(TRANSACTION_DATA_LENGTH, ' ')
                elif row[METHOD_TYPE] == '1':
                    # LOAN DEDUCTION
                    rate_str = f"{int(row[RATE] * 100):011}"
                    transaction_data = "".join([row.get(DOE_CODE, ''), " ", row.get(METHOD_TYPE, ''),
                                                row.get(PERIOD_CODE, ''), IGNORE_INSUFFICIENT_EARNINGS_INDICATOR,
                                                rate_str]).ljust(TRANSACTION_DATA_LENGTH, ' ')
                else:
                    # START TRANSACTION
                    rate_str = f"{int(row[RATE] * 100):011}"
                    limit_str = f"{int(row[LIMIT] * 100):011}"
                    transaction_data = "".join([row.get(DOE_CODE, ''), " ", USER_EXIT_INDICATOR,
                                                ACTIVE_INDICATOR, IGNORE_INSUFFICIENT_EARNINGS_INDICATOR,
                                                rate_str, NEW_LIMIT_INDICATOR,
                                                limit_str]).ljust(TRANSACTION_DATA_LENGTH, ' ')

                if secure_2_0_flag:
                    transaction_data = transaction_data[:56].ljust(56) + SECURE_2_0_CATCHUP_INDICATOR

                # Create the record
                record = tuple([
                    CREATION_CODE_P787 if row[METHOD_TYPE] == '1' else CREATION_CODE_RTMS,  # CREATION_CODE
                    effective_date,  # CREATE_DATE
                    adjusted_time_str,  # CREATE_TIME
                    sent_to_payroll_date,  # SENT_TO_PAYR_DATE
                    TRANSACTION_CODE,  # TRANSACTION_CODE
                    CORPORATION_CODE,  # CORPORATION_CODE
                    company_code,  # COMPANY_CODE
                    associate_ssn,  # ASSOCIATE_SSN
                    transaction_data,  # TRANSACTION_DATA
                    effective_date  # EFFECTIVE_DATE
                ])

                transformed_values.append(record)

                # Update previous_national_id
                previous_national_id = row[NATIONAL_ID]

            # Column names for the DB2 table
            msa_transaction_columns = [
                CREATION_CODE, CREATE_DATE, CREATE_TIME, SENT_TO_PAYR_DATE,
                TRANSACTION_CODE_COLUMN, CORPORATION_CODE_COLUMN, COMPANY_CODE_COLUMN,
                ASSOCIATE_SSN, TRANSACTION_DATA, EFFECTIVE_DATE
            ]
            return msa_transaction_columns, transformed_values

        except Exception as e:
            self.logger.error(f'Error while transforming deduction driver output to MSA_TRANSACTIONS format {e}')
            raise e # Raising exception to end the flow as malformed data can't be inserted

    """
    Fetches WIN-SSN mapping from the database based on the provided associate list.

    Parameters:
        associate_list (list): A list of associate IDs.

    Returns:
        pandas.DataFrame: A DataFrame containing the WIN-SSN mapping.
    """

    def fetch_win_ssn_mapping(self, associate_list):
        try:
            win_ssn_mapping_columns = [FIELD_WIN_NBR, NATIONAL_ID]
            self.logger.debug(f'associateList :: {associate_list}')

            # Define batch size
            batch_size = SSN_MAPPING_BATCH_SIZE
            associate_list_batches = [associate_list[i:i + batch_size] for i in
                                      range(0, len(associate_list), batch_size)]
            all_rows = []

            for batch in associate_list_batches:
                self.logger.debug(f'Processing batch with {len(batch)} associates')
                batch_query = WIN_SSN_MAPPING_CORE_HR_QUERY.format(
                    DB2_SCHEMA=self.db2_connection.testset,
                    ASSOCIATE_LIST=','.join(batch),
                    REGION=self.db2_region
                )
                rows = self.db2_connection.fetchall(batch_query)
                all_rows.extend(rows)

            return pd.DataFrame(all_rows, columns=win_ssn_mapping_columns)
        except Exception as e:
            self.logger.error(f'Error while fetching WIN-National ID mapping {e}')
            raise e  # Raising exception to end the flow as if National IDs are not retrieved as National ID is mandatory
    """
    This method inserts provided data into the MSA_TRANSACTIONS DB2 table.

    Parameters:
    columns (list): Column names for data insertion.
    values (list): Data to be inserted, each tuple represents one row.
    """
    def insert_to_msa_transactions_table(self, columns, values):
        try:
            self.db2_connection.bulk_insert(self.output_table_name, columns, values)
            self.db2_connection.commit_db()
        except Exception as e:
            self.logger.error(f'Error while inserting records to MSA_TRANSACTIONS table {e}')
            raise e # Raising exception to propagate the failure message to perform_file_load()
