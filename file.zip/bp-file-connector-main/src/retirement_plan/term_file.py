from src.constants import (F_ERROR, F_COMPLETED, INFO_TERMINATION_FILE_TRANSFER_COMPLETED, TERMINATION_GENERATION_ERROR,
                           BATCH_SIZE,STAT_CODE_36_COND_1,STAT_CODE_36_COND_2,STAT_CODE_36,STAT_CODE_30)
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status
import pandas as pd
from src.utils.sql import (RTRMT_PAYOUT_TERM_DATE)
from src.integrations.cosmos_utils import CosmosUtils
from src.integrations.db2_conn_helper import DB2IDatabase


class TerminationOutbound(FileGenerator):
    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        super().__init__(configuration_id, logger, request_id, start_date, end_date)
        self.cosmos_connection = CosmosUtils(logger=logger)
        self.db2_connection = DB2IDatabase(logger=logger)

    """"
        1. Working directory checkups
        2. Fetch Driving query -> generate query based on config Id and call cosmos executor from file_gen.py
        3. Fetch the terminated associate list from the driving query df ( transaction logs )
        4. Filter based on US & PR (config_Id)
        5. Fetch Core_HR + BQ data (combine this into one function in file_gen.py)
        6. Process the data frame => column level adjustments
        7. Extract the df_dic generator as separate method
        8. Apply termination specific rules
        9. Extract file generation as separate method and Call it
    """""

    def start_process(self):
        try:
            # Step1  : working_dir setup
            self.create_working_directory(self.request_id)
            # Step2  : fetch the termination list from transaction logs
            terminated_list = self.get_transaction_logs()
            # Step3  : get the associate profile data
            associate_info_df = self.get_associate_info(terminated_list)
            # Step4  : process the dataframe
            associate_info_df = self.process_core_hr_df(associate_info_df)
            # Step5  : generate the dict
            record_dict = self.generate_record_dict(associate_info_df, terminated_list)
            # Step6 : Apply specific termination parameters
            plan_updated_record_dict = self.apply_plan_detail_attributes(record_dict)
            # Step7  : Fetch Contribution Info
            contribution_df     = self.fetch_associate_contribution(terminated_list)
            # Step8  : Fetch Term_Effective_Date Info
            term_eff_date_df    = self.fetch_term_eff_date(terminated_list)
            # Step9  : Fetch Hire_Date Info
            hire_date_df        = self.fetch_hire_date(terminated_list)
            # Step10 : Fetch Experience Years Info
            experience_years_df = self.fetch_experience_years(terminated_list)
            # Step11 : Fetch Eligible hours Info
            eligible_hours_term_df   = self.fetch_eligible_hours(terminated_list)

            # Step12  : Apply above fetched info to record_dict
            plan_updated_record_dict=self.update_plan_specific_data_term(associate_info_df,plan_updated_record_dict, contribution_df,term_eff_date_df,hire_date_df,experience_years_df,eligible_hours_term_df)

            # Step13  : generate the files
            self.initiate_flat_file_generation(plan_updated_record_dict)
            # Step14  : transfer the file to GCS
            self.transfer_file_to_gcs()
            # Step15  : transfer the file to mainframe
            self.transfer_file_to_mainframe()
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            error_message = TERMINATION_GENERATION_ERROR.format(str(e))
            self.logger.error(error_message, exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

        self.logger.info(INFO_TERMINATION_FILE_TRANSFER_COMPLETED)

    """
       Functions : fetch_term_eff_date &  fetch_term_eff_date_data
       Fetches the termination effective date information for a given list of associates.

       Parameters:
       - associate_list (list): A list of associate IDs for which termination effective dates are to be fetched.

       Returns:
       - pd.DataFrame: A DataFrame containing termination effective date details with columns:
         ['WIN_NBR', 'R01-TERM-RETIRE-MM', 'R01-TERM-RETIRE-DD', 'R01-TERM-RETIRE-YY'].
       """

    def fetch_term_eff_date(self,associate_list):
        # Check if the associate list is empty
        if not associate_list:
            self.logger.info("Empty associate list, returning empty DataFrame")
            # Create empty DataFrame with core_hr_columns structure
            term_eff_date_cols = ['WIN_NBR', 'R01-TERM-RETIRE-MM', 'R01-TERM-RETIRE-DD', 'R01-TERM-RETIRE-YY']
            term_eff_date_df = pd.DataFrame(columns=term_eff_date_cols)
            return term_eff_date_df

        # Fetch termination effective date data from DB2
        term_eff_date_df = self.fetch_term_eff_date_data(associate_list)
        # Log the number of records fetched
        self.logger.info(f'Fetched {len(term_eff_date_df)} term_eff_date records from DB2')

        return term_eff_date_df

    def fetch_term_eff_date_data(self, associate_list):
        term_eff_date_cols = ['WIN_NBR', 'R01-TERM-RETIRE-MM', 'R01-TERM-RETIRE-DD', 'R01-TERM-RETIRE-YY']

        self.logger.debug(f'associateList :: {associate_list}')

        # Split the associate_list into chunks of 10,000
        associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]

        # Initialize the result DataFrame
        term_eff_date_df = pd.DataFrame()

        # Loop through each chunk and append to the result DataFrame
        for associate_chunk in associate_chunks:
            associate_list = ",".join([f"{win}" for win in associate_chunk])
            chunk_df = self.get_data_from_db2(
                col_names=term_eff_date_cols,
                query=RTRMT_PAYOUT_TERM_DATE.format(DB2_SCHEMA=self.db2_connection.testset, ASSOCIATE_LIST=associate_list, REGION=self.region),
                table_name='assoc_rtrmt_payout'
            )
            # Append to resultant dataframe
            term_eff_date_df = pd.concat([term_eff_date_df, chunk_df], ignore_index=True)

        return term_eff_date_df

    """
        Updates the record dictionary with plan-specific data for terminated associates.

        Parameters:
        - associate_info_df (pd.DataFrame): DataFrame containing associate information.
        - record_dict (dict): Dictionary containing record data for different sections (e.g., 'R01', 'R02', 'R05').
        - contribution_df (pd.DataFrame, optional): DataFrame containing contribution details.
        - term_eff_date_df (pd.DataFrame, optional): DataFrame containing termination effective date details.
        - hire_date_df (pd.DataFrame, optional): DataFrame containing hire date details.
        - experience_years_df (pd.DataFrame, optional): DataFrame containing years of service details.
        - eligible_hours_term_df (pd.DataFrame, optional): DataFrame containing eligible hours details.

        Returns:
        - dict: Updated record dictionary with plan-specific data.
        """

    def update_plan_specific_data_term(self, associate_info_df, record_dict, contribution_df=None,term_eff_date_df=None,hire_date_df=None,experience_years_df=None,eligible_hours_term_df=None):
        try:

            if 'r01' in record_dict:
                for index, row in associate_info_df.iterrows():
                    if row['TERM_REASON_CODE'] == STAT_CODE_36_COND_1 or row['EMPLOY_STAT_CODE'] == STAT_CODE_36_COND_2:
                        associate_info_df.loc[index, 'R01-STAT-CODE'] = STAT_CODE_36
                    else:
                        associate_info_df.loc[index, 'R01-STAT-CODE'] = STAT_CODE_30

                columns_to_update =['R01-STAT-CODE']
                associate_info_df.set_index('WIN_NBR', inplace=True)
                record_dict['r01'].set_index('associate_id', inplace=True)
                record_dict['r01'].update(associate_info_df[columns_to_update])
                record_dict['r01'].reset_index(inplace=True)


                columns_to_update = ['R01-TERM-RETIRE-MM', 'R01-TERM-RETIRE-DD', 'R01-TERM-RETIRE-YY']
                term_eff_date_df['WIN_NBR'] = term_eff_date_df['WIN_NBR'].astype(str)
                term_eff_date_df.set_index('WIN_NBR', inplace=True)
                record_dict['r01'].set_index('associate_id', inplace=True)
                record_dict['r01'].update(term_eff_date_df[columns_to_update])
                record_dict['r01'].reset_index(inplace=True)

                hire_date_df[['R01-HDAY-YY', 'R01-HDAY-MM', 'R01-HDAY-DD']] = hire_date_df['originalHireDate'].str.extract(r'(\d{4})-(\d{2})-(\d{2})')

                columns_to_update = ['R01-HDAY-MM', 'R01-HDAY-DD', 'R01-HDAY-YY']
                hire_date_df.set_index('associateId', inplace=True)
                record_dict['r01'].set_index('associate_id', inplace=True)
                record_dict['r01'].update(hire_date_df[columns_to_update])
                record_dict['r01'].reset_index(inplace=True)

            if contribution_df is not None:
                record_dict['r01'].set_index('associate_id', inplace=True)
                contribution_df.set_index('WIN_NBR', inplace=True)

                columns_to_update = ['R01-SAVINGS-RATES-INCLUDED']
                record_dict['r01'].update(contribution_df[columns_to_update])

                record_dict['r01'].reset_index(inplace=True)
                contribution_df.reset_index(inplace=True)

            if 'r02' in record_dict:
                # If r02 exists but no consent data, set default values
                record_dict['r02']['R02-OPT-IN-OUT-FLAG'] = " "
                record_dict['r02']['R02-EMAIL-TYPE'] = " "
                record_dict['r02']['R02-EMAIL-ADDRESS'] = " "

            if 'r05' in record_dict:
                if experience_years_df is not None:
                    experience_years_df['WIN_NBR'] = experience_years_df['WIN_NBR'].astype(str)
                    record_dict['r05'].set_index('associate_id', inplace=True)
                    experience_years_df.set_index('WIN_NBR', inplace=True)
                    columns_to_update = ['R05-YEARS-OF-SERVICE']
                    record_dict['r05'].update(experience_years_df[columns_to_update])
                    record_dict['r05'].reset_index(inplace=True)

                if eligible_hours_term_df is not None:
                    if not eligible_hours_term_df.empty:
                        columns_to_update = ['R05-HOURS-SERVICE']
                        if all(col in eligible_hours_term_df.columns for col in columns_to_update):
                            eligible_hours_term_df.set_index('associateId', inplace=True)
                            record_dict['r05'].set_index('associate_id', inplace=True)
                            record_dict['r05'].update(eligible_hours_term_df[columns_to_update])
                            record_dict['r05'].reset_index(inplace=True)
                        else:
                            self.logger.error(f"Columns {columns_to_update} are missing in eligible_hours_term_df.")
                    else:
                        self.logger.error("No eligible hours data found. Skipping update for 'R05-HOURS-SERVICE'.")

            return record_dict

        except Exception as e:
            self.logger.error(f'Error in update_plan_specific_data_term: {e}')
            raise