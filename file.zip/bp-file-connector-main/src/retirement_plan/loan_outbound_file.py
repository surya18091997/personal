import os
import time

import pandas as pd
from datetime import datetime, timedelta

from src.constants import (
    F_COMPLETED, F_ERROR,
    LOAN_DEDUCTION_CODE_K4, LOAN_DEDUCTION_CODE_K5, LOAN_FETCH_ERROR, INFO_LOAN_DATA_FETCH, INFO_LOAN_UPDATES_APPLIED,
    COSMOS_DB_NAME, COSMOS_COVERAGE_COLLECTION, LOAN_DEFAULT_SEQUENCE, LOAN_SEQUENCE_LENGTH,
    LOAN_NO_ELIGIBLE_ASSOCIATES,
    LOAN_NO_ELIGIBLE_RECORDS, LOAN_QUERY_ERROR, LOAN_QUERY_INFO, COSMOS_QUERY_PLAN_ID_CONDITION,
    COSMOS_QUERY_IS_LATEST_CONDITION,
    COSMOS_QUERY_COVERAGE_PROJECTION, RECORD_ATTR_CURRENT_MONTH, RECORD_ATTR_LOAN_REPAY_AMT, RECORD_ATTR_LOAN_NUMBER,
    RECORD_ATTR_PLAN_NUMBER, BATCH_SIZE, LOANS_COLUMN_ORDER, LOAN_COLUMNS_TO_DROP, COSMOS_QUERY_DEDUCTION_CONDITION,
    LOAN_FILLER, RECORD_ATTR_FILLER, CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT, LOAN_SEQUENCE_NUMBER,
    LOAN_DEDUCTIONS_NOT_FOUND, LOAN_ACTIVE_CONDITION
)
from src.generate_file.file_generator import FileGenerator
from src.generate_file.flat_file_creator import gen_flat_file
from src.utils import app_config
from src.utils.common_utils import update_request_status
from src.utils.sql import LOAN_DATA_QUERY, LOAN_DATA_QUERY_FULL_UNLOAD, PAYPERIOD_END_DATE_QUERY_GCP


def add_missing_columns(df, required_columns):
    for column in required_columns:
        if column not in df.columns:
            df[column] = required_columns[column]
    return df

class LoanOutbound(FileGenerator):
    """
    This class handles the generation of loan outbound files for the 401k retirement plan.
    It processes loan requests from coverages collection, extracts loan data from GCP,
    and generates files with the appropriate loan information.
    """

    def __init__(self, configuration_id, logger, request_id, start_date, end_date):
        """
        Initialize the LoanOutbound class.

        Args:
            configuration_id (int): The ID of the configuration.
            logger (logging.Logger): The logger instance.
            request_id (str): The ID of the request.
            start_date (datetime): The start date for fetching data.
            end_date (datetime): The end date for fetching data.
        """
        super().__init__(configuration_id, logger, request_id, start_date, end_date)
        self.flow_config = app_config.get_config_value("flow_config", str(configuration_id))
        self.plan_id = self.flow_config.get("plan_id", [])
        self.static_col_record_set = app_config.get_config_value("file_layout", "static_col_record_set")
        self.logger.info(f"LoanOutbound initialized with request_id: {request_id}")

    def start_process(self):
        """
        Orchestrates the process of generating the loan outbound file.
        This includes fetching loan data, processing it, and generating the file.
        """
        try:
            # Step 1: Create working directory
            self.create_working_directory(self.request_id)

            # Step 2 : Get Loan deductions from payroll
            loan_deductions_df = self.get_loan_deductions_data()

            if loan_deductions_df.empty:
                self.logger.error(LOAN_DEDUCTIONS_NOT_FOUND)
                self.initiate_custom_flat_file_generation(loan_deductions_df)
                update_request_status(self.request_id, F_ERROR, self.logger, LOAN_DEDUCTIONS_NOT_FOUND)
                return

            # Step 3: Fetch the loan data from coverages collection - get associates and loan data in one call
            active_loan_df = self.get_eligible_loan_data()

            if active_loan_df.empty:
                # TODO - what happens if no active associates found, but deductions are available in GCS
                self.logger.error(LOAN_NO_ELIGIBLE_ASSOCIATES)
                self.initiate_custom_flat_file_generation(loan_deductions_df)
                update_request_status(self.request_id, F_ERROR, self.logger, LOAN_NO_ELIGIBLE_ASSOCIATES)
                return

            # Step 5: Generate final loan_outbound df with proper formatting
            loan_df = self.apply_loan_specific_updates_v1(loan_deductions_df,active_loan_df)

            # Step 6: Generate the flat file
            self.initiate_custom_flat_file_generation(loan_df)
            # Step 7: Transfer the file to GCS bucket
            self.transfer_file_to_gcs()
            # Update request status to completed
            update_request_status(self.request_id, F_COMPLETED, self.logger)

        except Exception as e:
            self.logger.error(f"Error in loan outbound file generation: {e}", exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise

    def get_loan_deductions_data(self):
        # Get GCP project and dataset from config
        gcp_project = self.flow_config.get("gcp_project")
        bigquery_dataset = self.flow_config.get("bigquery_dataset")

        # Check if project and dataset are configured
        if not gcp_project or not bigquery_dataset:
            error_msg = f"Missing GCP configuration. Project: {gcp_project}, Dataset: {bigquery_dataset}"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
        # Build the filter string first
        if self.region == 'US':
            state_code_filter = " NOT IN ('PR', 'WV')"
        elif self.region == 'PR':
            state_code_filter = " = 'PR'"
        else:
            state_code_filter = " = 'WV'"

        # LOAN_DATA_QUERY_FULL_UNLOAD
        query = LOAN_DATA_QUERY_FULL_UNLOAD.format(
            gcp_project=gcp_project,
            bigquery_dataset=bigquery_dataset,
            LOAN_DEDUCTION_CODE_K4=LOAN_DEDUCTION_CODE_K4,
            LOAN_DEDUCTION_CODE_K5=LOAN_DEDUCTION_CODE_K5,
            state_code_filter = state_code_filter
        )

        self.logger.debug(f"Executing query: {query}")

        # Use the existing GCP connection to execute the query
        loan_deductions_df = self.gcp_connection.get_df_from_query(query)

        return loan_deductions_df

    def get_eligible_loan_data(self):
        """
        Retrieves eligible loan data from the coverage collection in Cosmos DB.
        Returns:
            pandas.DataFrame: A DataFrame containing the eligible loan data.
        Raises:
            Exception: If there is an error in the query or conversion to DataFrame.
        """
        try:
            # Build the query condition for plan IDs
            plan_ids_condition = " OR ".join(
                [COSMOS_QUERY_PLAN_ID_CONDITION.format(plan_id=plan_id) for plan_id in self.plan_id])

            # Build the query for coverage collection
            is_latest_condition = COSMOS_QUERY_IS_LATEST_CONDITION

            # Combine all conditions
            where_clause = f"({plan_ids_condition}) AND {is_latest_condition} AND {LOAN_ACTIVE_CONDITION} AND {COSMOS_QUERY_DEDUCTION_CONDITION}"

            self.logger.info(LOAN_QUERY_INFO.format(plan_ids=self.plan_id))

            coverages_data = self.cosmos_connection.get_structured_data(
                cosmos_database=COSMOS_DB_NAME,
                cosmos_collection=COSMOS_COVERAGE_COLLECTION,
                cosmos_projection=COSMOS_QUERY_COVERAGE_PROJECTION,
                cosmos_search_criteria={"where": where_clause}
            )

            if not coverages_data:
                self.logger.warning(LOAN_NO_ELIGIBLE_RECORDS)
                return None

            # Convert to DataFrame for easier processing
            coverage_df = pd.DataFrame(coverages_data)

            coverage_df['loanSequenceNumber'] = (coverage_df['loanSequenceNumber']
                                                 .fillna(LOAN_DEFAULT_SEQUENCE)
                                                 .apply(lambda x: str(x).zfill(LOAN_SEQUENCE_LENGTH).strip()))

            coverage_df['loanIndicator'] = coverage_df['planId'].apply(
                lambda x: 'K5' if 'res' in str(x).lower() else 'K4'
            )
            coverage_df.drop(columns=['planId', 'endDate', 'version', 'loanId', 'deduction'], inplace=True,
                             errors='ignore')
            # drop the duplicates
            # TODO - check for last pp - shd drop the 3 duplicates
            coverage_df.drop_duplicates(subset=['associateId','loanIndicator', 'loanSequenceNumber' ], inplace=True)
            return coverage_df

        except Exception as e:
            self.logger.error(LOAN_QUERY_ERROR.format(error=str(e)))
            raise

    def apply_loan_specific_updates_v1(self, loan_deductions_df, active_loan_df):

        active_loan_df['associateId'] = active_loan_df['associateId'].astype(int)

        loan_df = loan_deductions_df.merge(active_loan_df,
                               on=['associateId', 'loanIndicator'],how='inner')

        loan_df = add_missing_columns(loan_df, self.static_col_record_set[self.record_types[0]])
        # Add current month and year as spaces
        loan_df[RECORD_ATTR_CURRENT_MONTH] = " "
        loan_df[RECORD_ATTR_FILLER] = LOAN_FILLER
        loan_df[RECORD_ATTR_PLAN_NUMBER] = self.plan_number

        loan_df[RECORD_ATTR_LOAN_REPAY_AMT] = loan_df['doe_amt'].fillna(0).apply(
            lambda x: str(int(x * 100)).zfill(9))
        loan_df[RECORD_ATTR_LOAN_NUMBER] = loan_df[LOAN_SEQUENCE_NUMBER]

        # sort by associateID & LoanIndicator before dropping the columns
        loan_df.sort_values(by=['associateId', 'loanIndicator'], ascending=[True, True], inplace=True)
        loan_df.drop(columns=LOAN_COLUMNS_TO_DROP, inplace=True, errors='ignore')

        # Order the columns to match the output file layout
        loan_df = loan_df[LOANS_COLUMN_ORDER]

        return loan_df

    def fetch_loan_data_from_gcp(self, associate_list):
        try:
            # Check if the associate list is empty
            if not associate_list:
                self.logger.warning("Empty associate list for loan data fetch")
                return pd.DataFrame()  # Return empty DataFrame

            # Get GCP project and dataset from config
            gcp_project = self.flow_config.get("gcp_project")
            bigquery_dataset = self.flow_config.get("bigquery_dataset")

            # Check if project and dataset are configured
            if not gcp_project or not bigquery_dataset:
                error_msg = f"Missing GCP configuration. Project: {gcp_project}, Dataset: {bigquery_dataset}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

            # Check if IDs are numeric and format appropriately (without quotes for integers)
            # Split the associate_list into chunks of 10,000(considering the associate_list is integers)
            associate_chunks = [associate_list[i:i + BATCH_SIZE] for i in range(0, len(associate_list), BATCH_SIZE)]

            # Initialize the result DataFrame
            gcp_loan_df = pd.DataFrame()
            for associate_chunk in associate_chunks:
                try:
                    # If IDs are numeric, don't use quotes
                    is_numeric = all(str(win).isdigit() for win in associate_chunk)
                    if is_numeric:
                        formatted_list = ",".join([str(win) for win in associate_chunk])
                    else:
                        formatted_list = ",".join([f"'{win}'" for win in associate_chunk])
                except Exception:
                    # Fall back to assuming strings if there's any issue
                    formatted_list = ",".join([f"'{win}'" for win in associate_chunk])

                # Build the query using the constant template
                query = LOAN_DATA_QUERY.format(
                    gcp_project=gcp_project,
                    bigquery_dataset=bigquery_dataset,
                    ASSOCIATE_LIST=formatted_list,
                    LOAN_DEDUCTION_CODE_K4=LOAN_DEDUCTION_CODE_K4,
                    LOAN_DEDUCTION_CODE_K5=LOAN_DEDUCTION_CODE_K5
                )

                self.logger.debug(f"Executing query: {query}")

                # Use the existing GCP connection to execute the query
                loan_chunk_df = self.gcp_connection.get_df_from_query(query)

                # Append to resultant dataframe
                gcp_loan_df = pd.concat([gcp_loan_df, loan_chunk_df], ignore_index=True)

                self.logger.info(INFO_LOAN_DATA_FETCH.format(records=len(gcp_loan_df)))
            return gcp_loan_df

        except Exception as e:
            self.logger.error(LOAN_FETCH_ERROR.format(error_message=str(e)))
            raise

    def apply_loan_specific_updates(self, record_dict, loan_transaction_data):
        """
        Apply loan-specific updates to the given record dictionary.
        Args:
            record_dict (dict): The dictionary containing the record data.
            loan_transaction_data (pandas.DataFrame): The loan transaction data.
        Returns:
            dict: The updated record dictionary.
        Raises:
            Exception: If an error occurs during the loan-specific updates.
        """
        try:
            if 'r56' in record_dict:
                # Get loan dataframe
                loan_df = record_dict['r56']

                # Fetch loan data from GCP
                # TODO Check if we need to take unique list again
                associate_list = loan_df['associate_id'].unique().tolist()
                gcp_loan_data = self.fetch_loan_data_from_gcp(associate_list)  # ascId 1 - 1 -100, 1-2-20
                if gcp_loan_data.empty:
                    self.logger.error(LOAN_DEDUCTIONS_NOT_FOUND)
                    record_dict['r56'] = pd.DataFrame()
                    return record_dict

                gcp_loan_data = gcp_loan_data[gcp_loan_data['doe_amt'] > 0]

                # Add current month and year as spaces
                loan_df[RECORD_ATTR_CURRENT_MONTH] = " "
                loan_df[RECORD_ATTR_FILLER]=LOAN_FILLER
                loan_df[RECORD_ATTR_PLAN_NUMBER] = self.plan_number

                loan_transaction_data['associateId'] = loan_transaction_data['associateId'].astype(int)
                loan_df['associate_id'] = loan_df['associate_id'].astype(int)

                # TODO - replace with =constants
                gcp_loan_data = gcp_loan_data.merge(loan_transaction_data,
                                                    left_on=["win_nbr", "doe_code"],
                                                    right_on=["associateId", "loanIndicator"],
                                                    how="inner")

                loan_df = loan_df.merge(gcp_loan_data,
                                        left_on="associate_id",
                                        right_on="win_nbr",
                                        how="right")

                loan_df[RECORD_ATTR_LOAN_REPAY_AMT] = loan_df['doe_amt'].fillna(0).apply(
                    lambda x: str(int(x * 100)).zfill(9))
                loan_df[RECORD_ATTR_LOAN_NUMBER] = loan_df[LOAN_SEQUENCE_NUMBER]

                # sort by associateID & LoanIndicator before dropping the columns
                loan_df.sort_values(by=['associate_id','loanIndicator'], ascending=[True, True], inplace=True)
                loan_df.drop(columns=LOAN_COLUMNS_TO_DROP, inplace=True, errors='ignore')

                # Order the columns to match the output file layout
                loan_df = loan_df[LOANS_COLUMN_ORDER]

                record_dict['r56'] = loan_df

                self.logger.info(INFO_LOAN_UPDATES_APPLIED.format(count=len(loan_df)))
            return record_dict
        except Exception as e:
            self.logger.error(f"Error applying loan-specific updates: {e}")
            raise

    def initiate_custom_flat_file_generation(self, df):
        generated_file = os.path.join(self.request_id_dir, self.dest_file)
        invalid_file = os.path.join(self.request_id_dir, 'invalid_' + self.dest_file)

        self.logger.info(
            f"Files about to be generated: {generated_file} and records that could not be processed: {invalid_file}")

        flat_file_layout = app_config.get_config_value(CFG_FILE_LAYOUT, CFG_FLAT_FILE_LAYOUT)

        # Create object for the flat file generator
        create_flat_file = gen_flat_file(generated_file, invalid_file, flat_file_layout, self.logger)
        create_flat_file.request_id = self.request_id

        # Open files
        create_flat_file.open_files()

        # Write header
        header_record = self.generate_header_record()
        create_flat_file.file_pointer.write(header_record + '\n')
        start_time = time.time()

        # Write Body
        for _, row in df.iterrows():
            fixed_row = "".join(map(str, row.values))
            create_flat_file.file_pointer.write(fixed_row + '\n')
        end_time = time.time()
        self.logger.warning(f"Time taken to write records to file: {end_time - start_time} seconds")

        # Write trailer
        trailer_record = self.write_loan_trailer(df)
        create_flat_file.file_pointer.write(trailer_record + '\n')

        # Close files
        create_flat_file.close_files()

    def generate_header_record(self):
        current_date = datetime.now()
        julian_date = current_date.strftime("%Y%j")
        time_stamp = current_date.strftime("%H%M%S")
        pay_period_end_date = self.get_dates_for_header()
        # Format the Header Record
        header_record = (
            f"UHDR {julian_date}{self.plan_number}{self.plan_file.ljust(20)}{time_stamp}{pay_period_end_date}  0000"
            f"{' ' * 122}L{' ' * 71}"
        )
        return header_record

    def get_dates_for_header(self):
        """
        Returns the dates for the header record.
        :return: Tuple of (bi_weekly_start_date, pay_date)
        """
        try:
            gcp_project = self.flow_config.get("gcp_project")
            if not gcp_project:
                error_msg = f"Missing GCP configuration. Project: {gcp_project}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

            query = PAYPERIOD_END_DATE_QUERY_GCP.format(gcp_project=gcp_project)

            date_df = self.gcp_connection.get_df_from_query(query)

            return pd.to_datetime(date_df['PAYROLL_END_DATE']).dt.strftime('%m%d%y').iloc[0] if not date_df.empty \
                else (datetime.now() - timedelta(days=4)).strftime('%m%d%y') #fallback outbound rundate-4 gives friday's date
        except Exception as e:
            self.logger.error("Error while fetching bi_weekly start date: {error_message}".format(error_message=str(e)))
            raise

    def write_loan_trailer(self,df):
        try:
            data = {
                "R99-RECORD-TYPE": ["UTRL"],
                "R99-FILLER-1": [" "],
                "R99-RECORD-COUNT-N": [str(len(df) + 2).zfill(8)],
                "R99-PLAN-NUMBER": [self.plan_number],
                "R99-FILLER-2": ["0" * 56],
                "R99-WMT-COUNT-R55": [str(len(df)).zfill(8)],
                "FILLER-2": ["        000BASCA  0000000000{       0000000000{       0000000000{       0000000000{       0000000000{00000000000"],
                "R99-TOTAL-PAYROLL-DEPOSITS": [str(df[RECORD_ATTR_LOAN_REPAY_AMT].astype(int).sum()).zfill(11) if not df.empty else "0".zfill(11)],
                "R99-FILLER-3": ["0" * 26],
                "R99-FILLER-4": [" " * 18]
            }
            trailer_df = pd.DataFrame(data)
            fixed_row = ""
            for _, row in trailer_df.iterrows():
                fixed_row = "".join(map(str, row.values))
            return fixed_row
        except Exception as e:
            self.logger.error(f"Error writing trailer record: {e}")
            raise
