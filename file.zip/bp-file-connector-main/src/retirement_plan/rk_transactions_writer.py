import os
from datetime import datetime

import pandas as pd

from src.constants import TRANSACTION_CODE, \
    CORPORATION_CODE, \
    COMPANY_CODE_PR, COMPANY_CODE_US, FIELD_WIN_NBR, NATIONAL_ID, STATE_CODE, DOE_CODE, STOP_IND, PERIOD_CODE, RATE, \
    USER_EXIT_INDICATOR, SINGLE_SPACE
from src.load_file.file_loader import FileLoader
from src.utils.common_utils import read_file_to_dataframe, write_dataframe_to_file
from src.utils.sql import WIN_SSN_MAPPING_CORE_HR_QUERY


class RKTransactionWriter(FileLoader):
    """
    This class is responsible for loading payroll transactions, including reading deduction driver output file,
    transforming data and loading it into the RK Transactions file. Inherits from the FileGenerator class.
    """

    def __init__(self, configuration_id, logger, request_id):
        """
        Initialize the RKTransactionWriter with a configuration ID, logger, request ID.
        Also sets up utilities for Google Cloud Storage (GCS) and file transfer.
        """
        super().__init__(configuration_id, logger, request_id)
        try:
            self.reference_output_file_name = f"{datetime.today().date()}_RK_Transaction.csv"
        except Exception as e:
            self.logger.error(f'Error initialising RK transactions writer {e}')

    def start_process(self):
        """
        Orchestrates the process of loading payroll transaction files into the RK Transactions file.
        """
        try:

            self.logger.info("Initiating file loader")

            # Step 1: Download source file into the working directory
            self.logger.info("Downloading source file")
            file_download_path = os.path.join(self.cwd, self.request_id, self.source_file_path)
            self.gcs_util.download_file(self.bucket_name, self.source_file_path, file_download_path)

            # Step 2: Read file into pandas dataframe
            self.logger.info("Reading file into dataframe")
            deduction_input_df: pd.DataFrame = read_file_to_dataframe(file_download_path)

            if deduction_input_df.empty:
                self.logger.info("Deduction driver output file is empty. No records to process.")
                return

            # Step 3: Fetch and populate the National IDs of the associates
            self.logger.info("Fetching and populating National IDs")
            associate_id_list = ','.join([f'{associate_id}' for associate_id in deduction_input_df[FIELD_WIN_NBR].unique().tolist()])
            win_national_id_mapping_df = self.fetch_win_ssn_mapping(associate_id_list)
            input_df_with_national_ids = pd.merge(deduction_input_df, win_national_id_mapping_df, on=FIELD_WIN_NBR, how="left")

            # Step 4: Transform input deductions to RK Transactions file format
            self.logger.info("Transforming input to RK Transaction format")
            transformed_values = self.transform_to_rk_transactions_format(input_df_with_national_ids)

            # Step 5: Write transformed records to working directory in CSV format for future reference
            output_df = pd.DataFrame(transformed_values, columns=["RK-Transaction"])
            output_file_path = os.path.join(self.cwd, self.request_id, self.reference_output_file_name)
            write_dataframe_to_file(output_file_path, output_df, self.logger)
            self.logger.info("Transformed records written into working directory in CSV format for reference.")

        except Exception as e:
            self.logger.error(f'Error while trying to load file to payroll database {e}')
            raise e

    def transform_to_rk_transactions_format(self, deduction_input):
        """
        Transforms the input DataFrame into the format required for the MSA_TRANSACTIONS table.

        :param deduction_input: pandas DataFrame with input data
        :return: A tuple of column names and transformed values for bulk insertion
        """
        try:
            # Sort by NATIONAL_ID
            deduction_input = deduction_input.sort_values(by=[NATIONAL_ID])

            # Transformation logic
            transformed_values = []

            for idx, row in deduction_input.iterrows():
                # Format ASSOCIATE_SSN to 10 characters with leading spaces
                associate_ssn = f"{int(row[NATIONAL_ID]):010}"
                company_code = COMPANY_CODE_PR if row[STATE_CODE] == COMPANY_CODE_PR else COMPANY_CODE_US
                doe_code  = str(row.get(DOE_CODE,''))
                stop_ind = str(row.get(STOP_IND,''))
                method_code = SINGLE_SPACE if stop_ind == "Y" else USER_EXIT_INDICATOR
                period_code = str(row.get(PERIOD_CODE,''))
                type_code = SINGLE_SPACE if stop_ind == "Y" else "P"
                rate_str = SINGLE_SPACE * 11 if stop_ind == "Y" else f"{round(row[RATE] * 100 * 100):011}"


                rk_transaction_string = "".join([TRANSACTION_CODE, CORPORATION_CODE, company_code,
                                                 associate_ssn, doe_code, SINGLE_SPACE, method_code,
                                                 period_code, type_code, rate_str])

                transformed_values.append(rk_transaction_string)

            return transformed_values

        except Exception as e:
            self.logger.error(f'Error while transforming deduction driver output to RK Transaction format {e}')
            raise e # Raising exception to end the flow as malformed data can't be inserted

    """
    Fetches WIN-SSN mapping from the database based on the provided associate list.

    Parameters:
        associate_list (list): A list of associate IDs.

    Returns:
        pandas.DataFrame: A DataFrame containing the WIN-SSN mapping.
    """
    def fetch_win_ssn_mapping(self, associate_list):
        try:
            win_ssn_mapping_columns = [FIELD_WIN_NBR, NATIONAL_ID]
            self.logger.debug(f'associateList :: {associate_list}')

            query = WIN_SSN_MAPPING_CORE_HR_QUERY.format(DB2_SCHEMA=self.db2_connection.testset,
                                                         ASSOCIATE_LIST=associate_list,
                                                         REGION=self.db2_region)

            rows = self.db2_connection.fetchall(query)
            return pd.DataFrame(rows, columns=win_ssn_mapping_columns)
        except Exception as e:
            self.logger.error(f'Error while fetching WIN-National ID mapping {e}')
            raise e # Raising exception to end the flow as if National IDs are not retrieved as National ID is mandatory
