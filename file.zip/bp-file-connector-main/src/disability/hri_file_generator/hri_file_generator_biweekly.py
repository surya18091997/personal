from io import StringIO
import pandas as pd
from typing import Dict
from src.constants import CFG_FLOW_CONFIG
from src.disability.hri_file_generator.constants import (
    DEF_HRI_BUCKET, HRI_FILE_LAYOUT,
    HRI_SPARK_FILE_PREFIX, LINE_MAX_LENGTH, CFG_HRI_BUCKET)
from src.constants import F_ERROR, F_COMPLETED
from src.generate_file.file_generator import FileGenerator
from src.utils.common_utils import update_request_status
import src.utils.app_config as app_config
from src.integrations.gcs_utils import GCSUtils

class HRIFileGeneratorBiweekly(FileGenerator):
    """This class handles downloading the spark output files from GCS,
    generating flat file and transfer to GCS"""
    
    def get_spark_output(self) -> Dict[str, pd.DataFrame]:
        """Download spark outputs to dict"""
        gcs_util = GCSUtils(self.logger)
        record_dict = {} 
        flow_config = app_config.get_config_value(CFG_FLOW_CONFIG, str(self.configuration_id))
        hri_bucket = flow_config.get(CFG_HRI_BUCKET, DEF_HRI_BUCKET)
        for record in self.record_types:
            data = gcs_util.download_single_file_content_with_prefix(
                hri_bucket, self.source_file_path[0] + record + HRI_SPARK_FILE_PREFIX)
            record_dict[record] = pd.read_csv(StringIO(data), dtype=str).fillna('')
        return record_dict
    
    def start_process(self):
        try:
            self.logger.info("Initiated HRI file generation")
            # Step1  : working_dir setup
            self.create_working_directory(self.request_id)
            # Step2 : Get spark output data from GCS
            record_dict = self.get_spark_output()
            # Step3 : Initiate flat file gen
            self.initiate_flat_file_generation(record_dict,
                                               file_layout=HRI_FILE_LAYOUT,
                                               max_line_length=LINE_MAX_LENGTH)
            # Step4 : Transfer file to GCS
            self.transfer_file_to_gcs()
            update_request_status(self.request_id, F_COMPLETED, self.logger)
        except Exception as e:
            self.logger.error(f"Failed during file transfer: {str(e)}", exc_info=True)
            update_request_status(self.request_id, F_ERROR, self.logger, str(e))
            raise
        self.logger.info("HRI flat file gen and file transfer process completed")
