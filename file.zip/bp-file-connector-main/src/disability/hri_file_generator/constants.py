HRI_FILE_LAYOUT = "hri_file_layout"
HRI_SPARK_FILE_PREFIX = "/part-00000-"
DEF_HRI_BUCKET = "benefits-hri-process"
LINE_MAX_LENGTH = 1000
CFG_HRI_BUCKET = "hri_bucket"