CERTIFICATE_PATH = 'certificate_path'
CERTIFICATE = 'certificate'
AUTHENTICATION_TYPE = 'authentication_type'
USER_ID = "user_id"
PORT = "port"
SERVER = "server"
TEST_SERVER = 'TMAINFRAME'
MAINFRAME = 'MAINFRAME'
RSA_SHA_512 = 'rsa-sha2-512'
RSA_SHA_256 = 'rsa-sha2-256'
PUB_KEYS = 'pubkeys'
DEFAULT_PORT = 22
SECRET = "secret"
SFTP_PASSWORD = 'password'
ROOT_DIR = '/mnt/azure/'

#DATE FORMATS
DATE_FORMAT_YYYY_MM_DD = "%Y-%m-%d"
DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MS = "%Y-%m-%d %H:%M:%S.%f"
TIME_FORMAT_HH_MM_SS = '%H:%M:%S'
DATE_METHOD = 'date'
MAX_DATE = 'max_date'
RUN_DATE = 'runDate'
FROM_DATE = 'fromDate'
TO_DATE = 'toDate'

#file formats
FILE_FORMAT_CSV = 'csv'
FILE_FORMAT_JSON = 'json'
FILE_FORMAT_PARQUET = 'parquet'
DATA_FILE_PATH= 'filePath'
DATA_FILE_NAME= 'fileName'
DATA_FILE_FORMAT= 'fileFormat'



# Infor payroll transaction constants

CREATION_CODE_RTMS = 'RTMS'
CREATION_CODE_P787 = 'P787'
TRANSACTION_CODE = 'RK'
CORPORATION_CODE = '01'
COMPANY_CODE = 'WS'
COMPANY_CODE_PR = 'PR'
COMPANY_CODE_US = 'WS'
USER_EXIT_INDICATOR = 'X'
PERMANENTLY_INACTIVE_INDICATOR = '0'
ACTIVE_INDICATOR = 'A'
NEW_LIMIT_INDICATOR = 'N'
IGNORE_INSUFFICIENT_EARNINGS_INDICATOR = 'N'
TRANSACTION_DATA_LENGTH = 104
SECURE_2_0_CATCHUP_INDICATOR = 'CU'

# File Module constants
FILE_TRANSFER = 'FILE_TRANSFER'
FILE_GENERATOR = 'FILE_GENERATOR'
FILE_PARSER = 'LOAD_FILE'

## Request status constants
F_REQUEST_RECEIVED = 'REQUEST_RECEIVED'
F_WORK_IN_PROGRESS = 'WORK_IN_PROGRESS'
F_COMPLETED = 'COMPLETED'
F_ERROR = 'ERROR'

#Controller Constants
EMPTY_MESSAGE = "No records to process, generating empty file with header/trailer"
MISSING_CONFIGURATION = 'The parameter configurationId is missing.'
INVALID_CONFIGURATION_ID = 'Invalid configuration id: {configuration_id}'
RUN_DATE_VALIDATION = 'runDate is missing for wage file.'
FROM_AND_TO_DATE_VALIDATION = 'fromDate and toDate are required.'
INVALID_DATE_FORMAT = 'Invalid date format. Please use "YYYY-MM-DD'
INVALID_REQUEST = 'Invalid request, please provide the values in correct format'
TRANSFER_REQUEST_ACCEPTED = 'Request is submitted for processing and file transfer is in progress'
LOAD_REQUEST_ACCEPTED = 'Request is submitted for processing and file parse is in progress'
GENERATE_REQUEST_ACCEPTED = 'Request is submitted for processing and file generation is in progress'
ERROR_FILE_TRANSFER = 'For request: {request_id}Error initializing file transfer: {error_message}'
ERROR_FILE_TRANSFER_PROCESS = 'For request: {request_id}, Error in file transfer process: {error_message}'
ERROR_FILE_PARSE = 'For request: {request_id}, Error initializing file parsing: {error_message}'
ERROR_FILE_PARSE_PROCESS = 'For request: {request_id}, Error in file parsing process: {error_message}'
ERROR_FILE_GENERATE = 'For request: {request_id}, Error initializing file generation: {error_message}'
ERROR_FILE_GEN_PROCESS = 'For request: {request_id}, Error in file generation: {error_message}'
REQUEST_ERROR_MESSAGE = 'The errors detected in request {request_id} are: {error_message}'
UPDATE_ERROR_REQUEST_AND_HANDLE_ERROR  = 'Error in update_request_and_handle_error: {error_message}'
FILE_GEN_STARTED = 'Starting file generation process... for {request_id}'
FILE_GEN_COMPLETED = 'File generation process completed. for {request_id}'
START_DT_GT_END_DT = 'Start date {start_date} is after end date {end_date}'
FILE_TRANSFER_STARTED = 'Starting file download process... for {request_id}'
FILE_TRANSFER_COMPLETED = 'File transfer process completed. for {request_id}'
FILE_LOAD_STARTED = 'Starting file download process... for {request_id}'
FILE_LOAD_COMPLETED = 'File load process completed. for {request_id}'
END_POINT_ACCESSED = '{func_name} endpoint accessed for {request_id}, with request body: {request_body}'
ERROR_IN_LOG_CREATION = 'For request: {request_id}, Error in log creation: {error_message}'
INVALID_PROCESS_TYPE ='Invalid process type'
PLAN_TYPE = 'retirement_401k'
CONSENT_ERROR = "Error processing consent data: {error_message}"
MISSING_CONSENT_ERROR = "Empty result set for consent query"
CONSENT_ASSOCIATE_ERROR = "Error processing consent for associate {associate_id}: {error_message}"
CONSENT_FETCH_ERROR = "Error in consent fetch process: {error_message}"
CONSENT_PROCESS_ERROR = "Error processing consent for associate {associate_id}: {error_message}"
PLAN_ATTRIBUTE_ERROR = "Error applying plan detail attributes: {error_message}"
EMPTY_CONSENT_ERROR = "Empty result set for consent query"
DATA_EXTRACT_FILE_STARTED = 'Starting data file extraction process... for {request_id}'
DATA_EXTRACT_FILE_COMPLETED = 'Data file extraction process completed. for {request_id}'
ERROR_DATA_EXTRACT_FILE_PROCESS = 'For request: {request_id}, Error in data file extraction: {error_message}'
DATA_EXTRACT_FILE_REQUEST_ACCEPTED = 'Request is submitted for processing and data file extraction is in progress'
ERROR_DATA_EXTRACT_FILE = 'For request: {request_id}, Error initializing data file extraction: {error_message}'
TRANSACTION_LOG_CONFIGS = {1, 2, 3, 4, 11, 12, 13, 14, 15}

# Controller Function Names
TRANSFER_FILE = 'Transfer File'
LOAD_FILE = 'Load File'
GENERATE_FILE = 'Generate File'
DATA_EXTRACT_FILE = 'data extract'
STATE_TRANSFER_FILE = 'WM TRANSFER FILE'

#FILE TRANSFER
FOLDER_TRANSFERRED_TO_GCS = 'Folder {local_folder_path} uploaded to GCS bucket {bucket_name}'
FILE_TRANSFER_TO_GCS = 'File {destination_file_path} uploaded to GCS bucket {bucket_name}'
STANDARD_GCS_UPLOAD = 'Attempting standard GCS upload...{destination_file_path}'
FAIL_OVER_TO_CHUNK_GCS_UPLOAD = 'Falling back to chunked upload...'
CHUNK_GCS_UPLOAD = 'Attempting chunked GCS upload...'
ERROR_GCS_UPLOAD = 'Both standard and chunked uploads failed. Standard error: {error_message}, Chunked error: {chunk_error}'
STANDARD_GCS_UPLOAD_COMPLETED = 'Standard upload completed successfully'
STANDARD_GCS_UPLOAD_FAILED = 'Standard upload failed: {error_message}'
CHUNK_GCS_UPLOAD_PROGRESS = 'Uploaded {:,} bytes ({:.1f}%)'
CHUNK_GCS_UPLOAD_COMPLETED = 'Chunked upload completed successfully'
CHUNK_GCS_UPLOAD_FAILED_RETRY = 'Chunk upload failed, retrying: {error_message}'
BINARY_READ_MODE = 'rb'
START_SFTP_TRANSFER = 'Initiating file download from server using SFTP'
START_SFTP_UPLOAD = 'Initiating file upload to server using SFTP'
ERROR_SFTP_TRANSFER = 'Error transferring file from mainframe: {error_message}'
ERROR_SFTP_UPLOAD = 'Error uploading file to mainframe: {error_message}'
START_AZURE_TRANSFER = 'Initiating transfer to destination directory in Azure'
FILE_TRANSFER_SUCCESS = '{source_file_path} copied to {destination_file_path} Successfully.'
FILE_TRANSFER_ERROR = 'Error copying file from {source_file_path} to {destination_file_path}: {error_message}'
MF_FILE_DOWNLOADED = '{source_file_path} file downloaded from mainframe to {dir}'
MF_FILE_DOWNLOAD_ERROR = 'Error transferring file from mainframe: {error_message}'
INFO_TERMINATION_FILE_TRANSFER_COMPLETED = "Termination file transfer process completed"

# Telemetry Constants
APP_REQUEST_PROCESSING_TIME = 'Application request processing time in seconds'
APP_HEALTH_ENDPOINT = 'File_Connector| app_health | Health endpoint accessed'
APP_METRICS_LOG = 'File_Connector| app_metrics | Metrics endpoint accessed | Generating latest prometheus metrics'
APP_METRICS_DATA = 'File_Connector| app_metrics | {metrics_data}'
APP_REPORT_GENERATOR = 'File_Connector| app | Report generator accessed'
SERVICE_STATUS = 'service up and running'


# APP CONFIGURATION CONSTANTS
FLOW_CONFIG_ELIGIBLE_WAGES = 21
FLOW_CONFIG_ELIGIBLE_HOURS = 22
FLOW_CONFIG = 'flow_config'
GCS_CONNECTION_UPLOAD_SETTINGS = 'gcs_connection_upload_settings'
APP_NAME = 'app'
APP_CFG_CORE_SQL_CONNECTION_KEY = 'core_sql_api'
APP_CFG_CORE_SQL_URL = 'core_sql_cosmos_url'
GCS_CHUNK_SIZE = 'gcs_chunk_size'
GCS_RETRY_INITIAL = 'gcs_retry_initial'
GCS_RETRY_MAXIMUM = 'gcs_retry_maximum'
GCS_RETRY_MULTIPLIER = 'gcs_retry_multiplier'
GCS_UPLOAD_TIMEOUT = 'gcs_upload_timeout'
GCS_CHUNK_SIZE_VALUE = 5242880  #5MB Default Chuck size
GCS_RETRY_INITIAL_VALUE = 1.0
GCS_RETRY_MAXIMUM_VALUE = 60.0
GCS_RETRY_MULTIPLIER_VALUE = 2.0
GCS_UPLOAD_TIMEOUT_VALUE = 300
CFG_WORKING_DIR = 'working_dir'
CFG_FLOW_NAME = 'flow_name'
CFG_DEST_FILE = 'dest_file'
CFG_PLAN_NUMBER = 'plan_number'
CFG_PLAN_FILE = 'plan_file'
CFG_FILE_DATA_TYPE = 'file_data_type'
CFG_FILE_FILLER = 'file_filler'
CFG_SOURCE_FILE_PATH = 'source_file_path'
CFG_DESTINATION_FILE_PATH = 'destination_file_path'
CFG_DEST_FILE_PATH_MF = 'dest_file_path_mf'
CFG_PRIMARY_KEY = 'primary_key'
CFG_BUCKET_NAME = 'bucket_name'
CFG_SOURCE_BUCKET_NAME = "source_bucket"
CFG_FILE_GEN_FUNC = 'file_gen_func'
CFG_RECORD_TYPES = 'record_types'
CFG_REGION = 'region'
CFG_PAY_CENTER_ID = 'pay_center_id'
CFG_PLAN_STAT_CODE = 'plan_stat_code'
CFG_FILE_LAYOUT = 'file_layout'
CFG_FLAT_FILE_LAYOUT = 'flat_file_layout'
CFG_FLOW_CONFIG_RETRIEVED = 'Flow Configuration details are retrieved {flow_config}'
CFG_FLOW_CONFIG_ERROR = 'Error while retrieving flow configuration details {error_message}'
CFG_FLOW_CONFIG = "flow_config"
CFG_GCP_PROJECT = "gcp_project"
CFG_GCP_REGION = "gcp_region"
CFG_BIGQUERY_DATASET = "bigquery_dataset"
CFG_BIGQUERY_DATASET_GTA = "bigquery_dataset_GTA"
CFG_DESTINATION_PATH = "destination_file_path"
CFG_PLATFORM_DEV = "Platform_dev"  # Default value
CFG_ROW_LIMIT = "row_limit"
CFG_BATCH_SIZE = "batch_size"
CFG_DEFAULT_BATCH_SIZE = 250000
CFG_GCS_CONNECTION_FILE = "gcs_connection_file_path"
DATA_STORAGE_TYPE = "type"
DATA_STORAGE_INMEMORY = "dataframe"
DATA_STORAGE_AZURE_FILE = "azure"
DATA_STORAGE_GCS_FILE = "gcs"



# FILE GENERATOR CONSTANTS
FG_INITIALIZE='Initializing file generator instance...'
FG_INSTANCE_CREATED = 'File generator instance created'
FG_CREATE_W_DIR = 'Creating working directory...'
FG_W_DIR_CREATED = 'Working directory created at {dir}'
FG_W_DIR_CREATE_ERROR = 'Error while creating working directory {error_message}'
FG_FILE_GEN_COSMOS = 'Generating {collection} file from cosmos DB'
FG_FILE_FROM_COSMOS_CREATED = '{collection} File Created Successfully in {dir}'
FG_FILE_COSMOS_ERROR = 'Error in get_structured_data: {error_message}'
FG_STR_FILE_STARTED = 'Generating Store Number File from BigQuery'
FG_STR_EMPTY_FILE = 'Received an empty store list.'
FG_DIV_NBR_EMPTY = 'No division numbers were found for the given stores: {list}'
FG_DIV_NBR_SUCCESS = 'Fetched division numbers from Location Master for respective store numbers'
FG_DIV_STR_MAP = 'Division numbers::  {division} for Store numbers:: {stores} '
FG_FILE_DB2_START = 'Generating {table} File from db2 data'
FG_FILE_DB2_CREATED = '{table} File Created Successfully in {dir}'
FG_FILE_DB2_ERROR = 'An error occurred while generating {table} file from db2 data: {error_message}'
FG_TX_LOG_ST_DT = 'Setting start date to {start_date}'
FG_TX_LOG_END_DT = 'Setting end date to {end_date}'
FG_NO_ASSOC_DATA = 'No eligible associate list found.'
FG_CORE_HR_DATA_NOT_AVAILABLE = 'core hr data is empty... terminating the process...'
FG_RECORD_TYPE_GENERATED = 'Generated {record_type} df'
FG_DF_FILLED = 'Data obtained is formatted to respective record types'
FG_INVALID_RECORDS = 'Files about to be generated: {file} and records that could not be processed: {invalid_file} '
FG_FLAT_FILE_GEN_PROCESS = 'Generating flat file for plan number: {plan_number} and file type: {plan_file}'
FG_GEN_PROCESS_START = 'Starting process for generating flat file'
FF_FP_CLOSED_FOR_WRITING = 'File pointer closed for writing'
FG_EMPTY_FILE_INFO = "No records to process, generating empty file with header/trailer"
DEF_FLAT_LINE_LENGTH = 250

#RETIREMENT SAVINGS CONSTANTS
#CONTRIBUTION DATA ERROR HANDLING
CONTRIBUTION_DATA_FETCH = "Generating {collection} File from cosmos DB"
CONTRIBUTION_DATA_EMPTY = "contribution data is empty..."
CONTRIBUTION_DATA_MISSING = "Missing contribution data for associate {associate_id}"
CONTRIBUTION_FORMAT_INVALID = "Invalid contribution format for associate {associate_id}"
CONTRIBUTION_PROCESS_ERROR = "Error processing contribution for associate {associate_id}: {error_message}"
CONTRIBUTION_FETCH_ERROR = "Error in fetch_associate_contribution: {error_message}"

#INTEGRATION CONSTANTS
#COSMOS CONNECTION
DB2_EMPTY_RESULT = 'Empty result set for the given query'

#Postgres Connection
PG_CONNECTION_PATH = 'fc_postgres_db_connection'
PG_SQL_CONFIG = 'sqlDbConfig'
PG_CFG_HOSTNAME = 'host'
PG_CFG_USERNAME = 'user'
PG_CFG_PASSWORD = 'password'
PG_CFG_DATABASE = 'database'
PG_CFG_PORT = 'port'
PG_CFG_CURRENT_SCHEMA = 'currentSchema'
PG_CFG_CONN_ERROR = 'No configuration found for postgresSQL connection'
PG_SQL_MAX_RECORD = "SELECT MAX(request_last_update_ts) FROM connector.fc_tracker WHERE configuration_id = %s"
PG_SQL_VALUE_LIMIT_99 = 99

#DATALAKE HUDI CONNECTION
DATALAKE_EMPTY_RESULT = 'Empty result set for the given query'

#SFTP HELPER CONSTANTS
SFTP_MAINFRAME_FILE_PATH = "/FTADV:J=mvs,I=dos,X=text/__'{file_name}'"
SFTP_MAINFRAME_UPLOAD_FILE_PATH = "/FTADV:J=mvs,I=dos,LRECL=250,RECFM=FB/__'{file_name}'"
SFTP_FILE_TRANSFER_SUCCESS = '{file_name} from {file_path} has been transferred'
SFTP_FILE_TRANSFER_STATUS = '{file_path}::{bytes_transferred} bytes = {kb:.2f} KB = {mb:.2f} MB'
SFTP_FILE_TRANSFER_FAILURE = 'Error transferring the file {file_path}: {error_message}'
SFTP_CLIENT_CREATED_WITH_CERT = 'SFTP Client has been created with Certificate'
SFTP_CLIENT_CREATED_WITH_SECRET = 'SFTP Client has been created with Secret'
SFTP_CLIENT_NOT_SUPPORTED = 'Authentication Type is not supported'
SFTP_CLIENT_CREATE_ERROR = 'Error creating the SFTP client: {error_message}'

# Cosmos DB Constants
COSMOS_INIT_START = "Starting CosmosUtils initialization..."
COSMOS_CONFIG_SUCCESS = "Got Azure config successfully"
COSMOS_CLIENT_SUCCESS = "Successfully initialized Cosmos DB client"
COSMOS_CLIENT_ERROR = "Error initializing Cosmos DB client: {}"
COSMOS_CONFIG_NOT_FOUND = "Azure AD config file not found at {}"
COSMOS_CONFIG_MISSING = "Could not find cosmos_db configuration in cosmos-sql-connection.json"
COSMOS_SECRET_EXPIRED = "Azure service principal expired."
COSMOS_CONFIG_READ_ERROR = "Error reading Azure configuration: {}"
COSMOS_QUERY_EXECUTION = "Executing SQL query: {}"
COSMOS_QUERY_RESULT = "Query returned {} items"
COSMOS_QUERY_ATTEMPT_FAILED = "Query attempt {} failed: {}"
COSMOS_FETCH_ERROR = "Error fetching data from database: {}"
COSMOS_DB_CONNECT_ERROR = "Error connecting to database: {}"
COSMOS_CONFIG_READ_PATH = "Reading Azure AD config from: {}"
COSMOS_DB_CONFIG_ERROR = "Error reading database configuration: {}"

# Datalake DB Constants
DATALAKE_INIT_START = "Starting DatalakeUtils initialization..."
DATALAKE_CLIENT_SUCCESS = "Successfully initialized Datalake DB client"
DATALAKE_CLIENT_ERROR = "Error initializing Datalake DB client: {}"
DATALAKE_CONFIG_MISSING = "Could not find datalake configuration details in application.json"
DATALAKE_QUERY_EXECUTION = "Executing SQL query: {}"
DATALAKE_QUERY_RESULT = "Query returned {} items"
DATALAKE_QUERY_ATTEMPT_FAILED = "Query attempt {} failed: {}"
DATALAKE_FETCH_ERROR = "Error fetching data from Datalake : {}"
DATALAKE_DB_CONNECT_ERROR = "Error connecting to Datalake: {}"
DATALAKE_CONFIG_SUCCESS = "Got GCS Datalake config successfully"
DATALAKE_CONFIG_NOT_FOUND = "GCS Datalake config file not found at {}"
DATALAKE_CONFIG_READ_ERROR = "Error reading GCS configuration: {}"
DATALAKE_CONFIG_READ_PATH = "Reading Datalake config from: {}"
DATALAKE_DB_CONFIG_ERROR = "Error reading Datalake DB configuration: {}"
DATALAKE_MAX_RETRY_COUNT = 2
DATALAKE_RETRY_DELAY = 5
DATALAKE_SECRET_EXPIRED = ""
APP_CFG_HUDI_CONNECTION_KEY = "gcs_hudi_connection"
APP_CFG_GCS_HUDI_BUCKET = "gcs_hudi_bucket"
APP_CFG_GCS_HUDI_DATA_PATH = "gcs_hudi_data_path"
GCS_BUCKET_NAME = "gcsBucketName"


# Cosmos DB Query Constants
COSMOS_MAX_RETRY_COUNT = 2
COSMOS_RETRY_DELAY = 5

# BigQuery Processing Messages
BIGQUERY_BATCH_START = "Processing batch (offset: {offset:,})"
BIGQUERY_PROCESSING_PROGRESS = "Processing: {rows:,} rows ({rate:.0f} rows/second)"
BIGQUERY_DATAFRAME_CONVERSION = "Converting {records:,} records to DataFrame..."
BIGQUERY_FILE_WRITE = "Writing to file..."
BIGQUERY_BATCH_COMPLETE = "Batch completed: {records:,} records in {time} ({rate:.0f} rows/second)"
BIGQUERY_FILE_GEN_START = "Starting file generation at {timestamp}"
BIGQUERY_ROW_LIMIT_INFO = "Row limit: {limit:,} records"
BIGQUERY_ROW_LIMIT_REACHED = "Row limit of {limit:,} reached. Stopping."
BIGQUERY_PROGRESS_SUMMARY = """Progress Summary:
 - Records processed: {total:,}
 - Elapsed time: {elapsed}
 - Processing speed: {speed:.0f} records/second{remaining}"""
BIGQUERY_COMPLETION_SUMMARY = """Processing completed:
 - Total records: {total:,}
 - Total time: {time}
 - Average speed: {speed:.0f} records/second"""
LIMIT_CLAUSE_TEMPLATE = "LIMIT {batch_size} OFFSET {offset}"

# BigQuery Processing Errors
BIGQUERY_BATCH_ERROR = "Error processing batch at offset {offset}: {error}"
BIGQUERY_DATA_FETCH_ERROR = "Error fetching and writing data: {error}"
BIGQUERY_QUERY_ERROR = "Error executing BigQuery query: {error}"
BIGQUERY_FILE_WRITE_ERROR = "Error writing data to file: {error}"
BIGQUERY_TRANSFORM_ERROR = "Error transforming query results: {error}"
# Wage File Processing
CFG_WAGE_DOE_CODES = "doe_codes"
CFG_WAGE_EARN_TYPE_CODES = "earn_type_codes"
STRIP_DATE = "%Y%m%d"
PROCESS_TYPE_WAGES = "wages"
SAP_ASSOC_FILE_NAME = "sap_associates.csv"

# Wage File Processing Errors
WAGE_FILE_GEN_ERROR = "Error generating wage file: {error}"
WAGE_FILE_CONFIG_ERROR = "Error loading wage file configuration: {error}"
WAGE_FILE_GCS_ERROR = "Error transferring file to GCS: {error}"
WAGE_FILE_DATE_ERROR = "Invalid or missing run date: {error}"

#Term File Processing Errors
TERMINATION_GENERATION_ERROR = "Error in termination file generation: {}"

# Upload chunk size and frequency
UPLOAD_CHUNK_LOG_FREQUENCY = 100 * 1024 * 1024  # 100MB
MAX_UPLOAD_RETRIES = 3
UPLOAD_RETRY_DELAY = 1  # seconds

# Upload progress messages
CHUNK_UPLOAD_PROGRESS_MSG = 'Uploaded {uploaded:,} bytes ({percentage:.1f}%)'
CHUNK_UPLOAD_RETRY_MSG = 'Chunk upload failed, retrying: {error_message}'

# GCS Utils Constants
GCS_INFO_FILES_FOUND = 'Found {} files in working directory with prefix {}'
GCS_INFO_BLOB_COPIED = 'Copied blob to {}'
GCS_INFO_EXPORT_STARTED = 'Starting export for {}'
GCS_INFO_JOB_SUBMITTED = 'Submitted export job for {}'

GCS_ERROR_LIST_FILES = 'Error listing working directory files: {}'
GCS_ERROR_COPY_BLOB = 'Error copying blob: {}'
GCS_ERROR_VERIFY_COPY = 'Error verifying copy: {}'
GCS_ERROR_EXPORT = 'Failed to export {}: {}'
GCS_ERROR_JOB_WAIT = 'Error waiting for job: {}'

# Hours file
ERROR_INIT_FILE = "Error in {} initialization: {}"
ERROR_PROCESS_QUERY = "Failed to process {}: {}"
ERROR_NO_SOURCE_FILES = "No source files found for {}"
ERROR_PROCESS_FAILED = "Failed to process queries: {}"
ERROR_FILE_GENERATION = "Error in {} file generation: {}"
ERROR_MAX_RUN_DATE = "Failed to get max run date: {}"
HR_ASC_HOURS_TYPE = "HR_ASC_HOURS_TYPE"
ASC_DAILY_PAY_SUM = "ASC_DAILY_PAY_SUM"
ETCAR_ASC_DAILY_PAY_SUM = "ETCAR_ASC_DAILY_PAY_SUM"
PAID_ASSOCIATE = "PAID_ASSOCIATE"
# Hours file Outbound
PROCESS_TYPE_HOURS_OUTBOUND = "hours_outbound"
RECORD_TYPE_R14 = "14"
ERROR_READING_SOURCE_FILE = "Error reading source file: {}"
ERROR_PARSE_JSON = "Error parsing JSON records: {}"
ERROR_GENERATE_R14 = "Error generating R14 record: {}"
ERROR_HOURS_OUTBOUND_INIT = "Error in HoursOutboundFile initialization: {}"
ERROR_GENERATE_FILE = "Error generating hours outbound file: {}"
GCS_ERROR_DOWNLOAD_CONTENT = "Error downloading file content: {}"
BATCH_SIZE = 29000

# Contribution file Outbound
ERROR_CONTRIBUTION_OUTBOUND_INIT = "Error in ContributionOutbound initialization: {}"
ERROR_GENERATE_CONTRIBUTION_FILE = "Error generating contribution outbound file: {}"

# HOURS FILE OUTBOUND CONSTANTS
HOURS_FILE_OUTBOUND_INIT = "HoursFileOutbound initialized with request_id: {}"
HOURS_FILE_READ_START = "Reading eligible hours data from GCS: {}"
HOURS_FILE_READ_SUCCESS = "Successfully read {} eligible hours records"
HOURS_FILE_READ_ERROR = "Error reading eligible hours data from GCS: {}"
HOURS_FILE_PROCESS_ERROR = "Failed during hours file outbound processing: {}"
HOURS_FILE_GCS_TRANSFER = "Transferring file to GCS bucket: {}, destination: {}"
HOURS_FILE_R14_SUCCESS = "Created {} R14 records"
HOURS_FILE_R14_EMPTY = "No R14 records created - using empty DataFrame"
HOURS_FILE_UPDATE_ERROR = "Error in apply_plan_specific_record_updates: {}"
HOURS_LOCAL_FILE = "eligible_hours_data.json"
HOURS_R14_COLUMNS = ['associate_id', 'NATIONAL_ID', 'R14-RECORD-TYPE',
                     'R14-PLAN-NUMBER', 'R14-PAY-PERIOD-END-DATE',
                     'R14-TOTAL-ELIGIBLE-HOURS', 'R14-ADJUSTED-HOURS']
HOURS_R14_DAILY_PREFIX = 'R14-DAY-'
HOURS_R14_RECORD_TYPE = '14'
HOURS_FORMAT_FLOAT = '.2f'
ASSOCIATE_ID = 'associate_id'
NATIONAL_ID = 'NATIONAL_ID'
R14_RECORD_TYPE = 'R14-RECORD-TYPE'
R14_PLAN_NUMBER = 'R14-PLAN-NUMBER'
R14_PAY_PERIOD_END_DATE = 'R14-PAY-PERIOD-END-DATE'
R14_TOTAL_ELIGIBLE_HOURS = 'R14-TOTAL-ELIGIBLE-HOURS'
R14_ADJUSTED_HOURS = 'R14-ADJUSTED-HOURS'

# Status messages
INFO_USING_RUN_DATE = "Using run date: {}"
INFO_START_PROCESSING = "Starting processing for {}"
INFO_COMPLETED_PROCESSING = "Completed processing for {}"
INFO_ALL_QUERIES_SUCCESS = "All queries processed successfully"
INFO_TOTAL_RECORDS = "Processed {:,} total records"
INFO_INIT_GENERATOR = "Initialized {} generator with row_limit: {}, batch_size: {}"

# Loan processing constants
LOAN_DEDUCTION_CODE_K4 = 'K4'  # K4 deduction code
LOAN_DEDUCTION_CODE_K5 = 'K5'  # K5 deduction code

# Loan error messages
LOAN_FETCH_ERROR = "Error in loan fetch process: {error_message}"
LOAN_DATA_EMPTY = "Loan data is empty..."
LOAN_DATA_MISSING = "Missing loan data for associate {associate_id}"
LOAN_FORMAT_INVALID = "Invalid loan format for associate {associate_id}"
LOAN_PROCESS_ERROR = "Error processing loan for associate {associate_id}: {error_message}"
LOAN_GENERATION_ERROR = "Error in loan file generation: {}"
INFO_LOAN_FILE_TRANSFER_COMPLETED = "Loan file transfer process completed"
INFO_LOAN_DATA_FETCH = "Fetched loan data for {records} records from GCP"
INFO_LOAN_INDICATORS_PROCESSED = "Processed loan indicators for {count} associates"
INFO_LOAN_UPDATES_APPLIED = "Applied loan-specific updates to {count} records"


# Contribution error messages
GCP_FETCH_ERROR = "Error in loan fetch process: {error_message}"

# Contribution info messages
INFO_CONTRIBUTION_DATA_FETCH = "Fetched national ids for {records} records from GCP"

# Database constants
COSMOS_DB_NAME = 'benefits-platform'
COSMOS_COVERAGE_COLLECTION = 'coverages'

# Loan related constants
LOAN_DEFAULT_SEQUENCE = '001'
LOAN_TYPE_GENERAL = 'general'
LOAN_TYPE_RESIDENTIAL = 'residential'
LOAN_RESIDENTIAL_IDENTIFIERS = ['residential', 'res_loan']
LOAN_SEQUENCE_LENGTH = 3

# Loan deduction query constants
LOAN_DEDUCTION_MIN_VALUE = 0
LOAN_DEDUCTION_PATH = "deduction['value']"
LOAN_ACTIVE_CONDITION = "c.loanStatusCode = 'A'"
COSMOS_QUERY_DEDUCTION_CONDITION="c.deduction['value'] > 0"
# Status messages
LOAN_NO_ELIGIBLE_ASSOCIATES = "No eligible loan associates found"
LOAN_NO_ELIGIBLE_RECORDS = "No eligible loan records found in coverages collection"
LOAN_DEDUCTIONS_NOT_FOUND = "No Loan deductions found"
LOAN_ASSOCIATE_NOT_FOUND = "Associate not found in loan transaction data: {associate_id}"
LOAN_QUERY_ERROR = "Error fetching eligible loan data: {error}"
LOAN_QUERY_INFO = "Querying coverages for loan data with plan IDs: {plan_ids}"
LOAN_ELIGIBLE_COUNT = "Found {count} eligible loan associates"
LOAN_WV_CONDITION = " AND A.STR_STATE_PROV_CD <> \'WV\'"
# Date format
DATE_FORMAT = "%Y-%m-%d"

# Cosmos DB query components
COSMOS_QUERY_PLAN_ID_CONDITION = "c.planId = '{plan_id}'"
COSMOS_QUERY_IS_LATEST_CONDITION = "c.isLatest = true"
COSMOS_QUERY_COVERAGE_PROJECTION = "c.associateId, c.planId, c.loanSequenceNumber"

# Loan record attributes
RECORD_ATTR_CURRENT_MONTH = 'CURRENT_MONTH'
RECORD_ATTR_CURRENT_YEAR = 'CURRENT_YEAR'
RECORD_ATTR_FILLER = 'FILLER1'
LOAN_SEQUENCE_NUMBER='loanSequenceNumber'
LOAN_FILLER = ' ' * 220
RECORD_ATTR_LOAN_REPAY_AMT = 'R56-LOAN-REPAY-AMT'
RECORD_ATTR_LOAN_NUMBER = 'R56-LOAN-NUMBER'
RECORD_ATTR_PLAN_NUMBER = 'R56-PLAN-NUMBER'
LOANS_COLUMN_ORDER = ['record_type','R56-PLAN-NUMBER', 'NATIONAL_ID' ,'R56-LOAN-NUMBER','CURRENT_MONTH','R56-LOAN-REPAY-AMT','FILLER1']
LOAN_COLUMNS_TO_DROP = ['doe_code', 'doe_amt', 'win_nbr', 'loanIndicator', 'loanSequenceNumber', 'associateId', 'associate_id', 'WIN_NBR','R56-PAYROLL-IND','CURRENT_YEAR']

LOANS_51_COLUMN_ORDER = ['R51-RECORD-TYPE', 'R51-PLAN-NUMBER', 'NATIONAL_ID', 'R51-ACTION','R51-STAT-CODE','FILLER-1','associateId','FILLER-2']
LOANS_52_COLUMN_ORDER = ['R52-RECORD-TYPE', 'R52-PLAN-NUMBER', 'NATIONAL_ID', 'FILLER-1','R52-USERRA-START-DATE','R52-USERRA-END-DATE','R52-LOA-START-DATE','R52-LOA-END-DATE','FILLER-2']
# Flow Name Constants
FLOW_NAME_RE_HIRE_BASE = "RE_HIRE"
FLOW_NAME_NEW_HIRE = "NEW_HIRE"

# Log Messages for Eligibility File
REHIRE_CREDIT_IND = "'1','2','3','4','5','6'"
LOG_REHIRE_ASSOCIATES_FOUND = "Found {} RE_HIRE_BASE associates"
LOG_COMBINED_ASSOCIATES = "Processing {} combined associates"
LOG_NEW_HIRE_EMPTY_VALUES = "Applying empty values for {} NEW_HIRE associates"
LOG_CONSENT_DATA_UPDATED = "Updated {} records with consent data"
LOG_CONSENT_DEFAULT_VALUES = "Set default values for consent fields"
LOG_REHIRE_BASE_ERROR = "Error fetching RE_HIRE_BASE associates: {}"
LOG_NEW_HIRE_OVERRIDE_ERROR = "Error overriding fields for NEW_HIRE associates: {}"
LOG_PLAN_UPDATES_ERROR = "Error applying plan-specific updates: {}"
LOG_FILE_GENERATION_FAILED = "Failed during file generation: {}"
LOG_FILE_TRANSFER_COMPLETED = "File transfer process completed"
LOG_ELIGIBILITY_INITIALIZED = "Initialized Eligibility with configuration_id: {}, is_rehire: {}"
LOG_PROCESSING_REHIRE_LOGS = "Processing {} rehire transaction logs"
LOG_SKIPPING_ASSOCIATE = "Skipping associate {}: Comment '{}' does not start with 1-6"
LOG_FILTERED_REHIRES = "Filtered to {} eligible rehires, skipped {} records"
LOG_NO_R01_RECORDS = "No r01 records found, skipping rehire field updates"
LOG_APPLIED_REHIRE_FIELDS = "Applied rehire specific fields to {} records"
LOG_REHIRE_FIELDS_ERROR = "Error applying rehire-specific fields: {}"

# Field Names for Records
FIELD_ASSOCIATE_ID = "associate_id"
FIELD_WIN_NBR = "WIN_NBR"

# R01 Record Fields
R01_SAVINGS_RATES_INCLUDED = "R01-SAVINGS-RATES-INCLUDED"
R01_ELECT_BT_SAVE_RATE = "R01-ELECT-BT-SAVE-RATE"
R01_ELECT_BT_CUC_SAVE_RATE = "R01-ELECT-BT-CUC-SAVE-RATE"
R01_CONTRIBUTION_FIELDS = [
    R01_SAVINGS_RATES_INCLUDED,
    R01_ELECT_BT_SAVE_RATE,
    R01_ELECT_BT_CUC_SAVE_RATE
]

# R02 Record Fields
R02_OPT_IN_OUT_FLAG = "R02-OPT-IN-OUT-FLAG"
R02_EMAIL_TYPE = "R02-EMAIL-TYPE"
R02_EMAIL_ADDRESS = "R02-EMAIL-ADDRESS"
R02_CONSENT_FIELDS = [
    R02_OPT_IN_OUT_FLAG,
    R02_EMAIL_TYPE,
    R02_EMAIL_ADDRESS
]

# Field Values
VALUE_NO = "N"
VALUE_EMPTY = " "

# Default Field Values
DEFAULT_CONSENT_VALUES = {
    R02_OPT_IN_OUT_FLAG: VALUE_EMPTY,
    R02_EMAIL_TYPE: VALUE_EMPTY,
    R02_EMAIL_ADDRESS: VALUE_EMPTY
}

# Contribution Outbound Related Constants
columns_to_apply_zfill = ['R05-SOURCE-AMOUNT-A(1)', 'R05-SOURCE-AMOUNT-A(2)',
                          'R05-SOURCE-AMOUNT-A(3)', 'R05-SOURCE-AMOUNT-A(4)']
COLUMNS_TO_DROP = ['R05-PAYROLL-FREQ','R05-ELIGIBLE-WAGE',
                                 'R05-SOURCE-ID-A(1)', 'R05-CONTRIB-IND-A(1)', 'R05-SOURCE-AMOUNT-A(1)',
                                 'R05-SOURCE-ID-A(2)', 'R05-CONTRIB-IND-A(2)', 'R05-SOURCE-AMOUNT-A(2)',
                                 'R05-SOURCE-ID-A(3)', 'R05-CONTRIB-IND-A(3)', 'R05-SOURCE-AMOUNT-A(3)',
                                 'R05-SOURCE-ID-A(4)', 'R05-CONTRIB-IND-A(4)', 'R05-SOURCE-AMOUNT-A(4)']
COLUMNS_TO_DROP_IN_CONTRIBUTION_DF=['contribution_amount', 'plan_type', 'state_code']
R05_RECORD_TYPE='R05-RECORD-TYPE'
R05 ='05'
R05_PLAN_NUMBER = 'R05-PLAN-NUMBER'
R05_FILLER_01='R05-FILLER-01'
R05_FILLER_01_DEFAULT = " " * 99
R05_FILLER_02_DEFAULT = " " * 35
R05_FILLER_02='R05-FILLER-02'
PAY_FREQ_CODE='PAY_FREQ_CODE'
R05_PAYROLL_FREQ='R05-PAYROLL-FREQ'
R05_HOURS_SERVICE='R05-HOURS-SERVICE'
R05_HOURS_SERVICE_DEFAULT = " " * 7
R05_YTD_415_COMPENSATION = 'R05-YTD-415-COMPENSATION'
R05_YTD_415_COMPENSATION_DEFAULT = "000000000"
ASSOCIATE_ELIGIBLE_WAGE='associate_eligible_wage'
R05_ELIGIBLE_WAGE='R05-ELIGIBLE-WAGE'
COLUMNS_TO_KEEP = [
                    "R05-RECORD-TYPE", "R05-PLAN-NUMBER", "NATIONAL_ID", "R05-SOURCE-ID-A(1)", "R05-SOURCE-AMOUNT-A(1)",
                    "R05-SOURCE-ID-A(2)", "R05-SOURCE-AMOUNT-A(2)", "R05-SOURCE-ID-A(3)", "R05-SOURCE-AMOUNT-A(3)",
                    "R05-SOURCE-ID-A(4)", "R05-SOURCE-AMOUNT-A(4)", "R05-SOURCE-ID-A(5)", "R05-SOURCE-AMOUNT-A(5)",
                    "R05-CONTRIB-IND-A(1)", "R05-CONTRIB-IND-A(2)", "R05-CONTRIB-IND-A(3)", "R05-CONTRIB-IND-A(4)",
                    "R05-CONTRIB-IND-A(5)", "R05-PAYROLL-FREQ", "R05-HOURS-SERVICE",
                    "R05-YTD-415-COMPENSATION", "R05-ELIGIBLE-WAGE"
                ]
SOURCE_AMOUNT_COLUMNS=["R05-SOURCE-AMOUNT-A(1)", "R05-SOURCE-AMOUNT-A(2)", "R05-SOURCE-AMOUNT-A(3)", "R05-SOURCE-AMOUNT-A(4)","R05-SOURCE-AMOUNT-A(5)"]
SINGLE_SPACE_COLUMNS=[
                    "R05-SOURCE-ID-A(1)", "R05-SOURCE-ID-A(2)", "R05-SOURCE-ID-A(3)", "R05-SOURCE-ID-A(4)", "R05-SOURCE-ID-A(5)",
                    "R05-CONTRIB-IND-A(1)", "R05-CONTRIB-IND-A(2)", "R05-CONTRIB-IND-A(3)", "R05-CONTRIB-IND-A(4)", "R05-CONTRIB-IND-A(5)"
                ]
COLUMN_ORDER = ["R05-RECORD-TYPE", "R05-PLAN-NUMBER","NATIONAL_ID", "R05-SOURCE-ID-A(1)", "R05-SOURCE-AMOUNT-A(1)",
                "R05-SOURCE-ID-A(2)", "R05-SOURCE-AMOUNT-A(2)", "R05-SOURCE-ID-A(3)", "R05-SOURCE-AMOUNT-A(3)",
                "R05-SOURCE-ID-A(4)", "R05-SOURCE-AMOUNT-A(4)", "R05-SOURCE-ID-A(5)", "R05-SOURCE-AMOUNT-A(5)",
                "R05-CONTRIB-IND-A(1)", "R05-CONTRIB-IND-A(2)", "R05-CONTRIB-IND-A(3)", "R05-CONTRIB-IND-A(4)",
                "R05-CONTRIB-IND-A(5)", "R05-FILLER-01", "R05-PAYROLL-FREQ", "R05-HOURS-SERVICE",
                "R05-YTD-415-COMPENSATION", "R05-FILLER-02", "R05-ELIGIBLE-WAGE"
                ]
TRAILER_COLUMNS_TO_ZFILL = [
                'R99-BT-BASIC-TOTAL',
                'R99-BT-SUPP-TOTAL',
                'R99-REG-SUPP-TOTAL',
                'R99-COMPANY-TOTAL',
                'R99-TOTAL-CONTRIBUTIONS'
            ]
# RK Transaction File Constants
STATE_CODE = "STATE_CODE"
DOE_CODE = "DOE_CODE"
STOP_IND = "STOP_IND"
PERIOD_CODE = "PERIOD_CODE"
RATE = "RATE"
SINGLE_SPACE = " "
SSN_MAPPING_BATCH_SIZE = 10000

# Payroll Transaction Writer

MSA_TRANSACTIONS_REFERENCE_FILE_NAME = 'MSA_TRANSACTIONS_insertions.csv'
CENTRAL_TIME_ZONE = 'US/Central'
SECURE_2_0_FLAG = 'SECURE_2_0_FLAG'
YES = 'Y'
METHOD_TYPE = 'METHOD_TYPE'
LIMIT = 'LIMIT'
CREATION_CODE = 'CREATION_CODE'
CREATE_DATE = 'CREATE_DATE'
CREATE_TIME = "CREATE_TIME"
SENT_TO_PAYR_DATE = "SENT_TO_PAYR_DATE"
TRANSACTION_CODE_COLUMN = "TRANSACTION_CODE"
CORPORATION_CODE_COLUMN = "CORPORATION_CODE"
COMPANY_CODE_COLUMN = "COMPANY_CODE"
ASSOCIATE_SSN = "ASSOCIATE_SSN"
TRANSACTION_DATA = "TRANSACTION_DATA"
EFFECTIVE_DATE = "EFFECTIVE_DATE"

# Rehire data lake download

EVENT_TYPE_REHIRE = 'RE_HIRE'
POST_PAYROLL_SNAPSHOT_HUDI_PATH = "post_payroll_snapshot_hudi_path"
PROFILE_HUDI_PATH = "profile_hudi_path"
ASSOCIATE_ID_FILTER_TEMP_FILE = "associate_id_filter_file.csv"

# Dataproc constants

DATAPROC_DEFAULT_PYTHON_MAIN_FILE_URI = 'file:///app/main.py'
GCP_SERVICE_ACCOUNT = 'gcp_service_account'
GCP_SUBNETWORK_URI = 'gcp_subnetwork_uri'
CUSTOM_CONTAINER_IMAGE = 'custom_container_image'
FILTER_CONDITIONS_CSV_PATH = 'filter_conditions_csv_path'
RAW_JSON_COLUMNS_LIST = 'raw_json_columns_list'
PROFILE_OUTPUT_PATH = 'profile_output_path'
POST_PAYROLL_SNAPSHOT_OUTPUT_PATH = 'post_payroll_snapshot_output_path'
FILTER_CONDITIONS_FLAG = 'FILTER_CONDITIONS_FLAG'
JSON_TYPE = 'json'
DATAPROC_HUDI_UNLOAD_PREFIX = 'hudi-unload-'

# Termination Outbound File Constants
STAT_CODE_36_COND_1 = '75'
STAT_CODE_36_COND_2 = 'D'
STAT_CODE_36 = '36'
STAT_CODE_30 = '30'

# Default R05 record values
DEF_HOURS_SERVICE = "000000{"
DEF_YEARS_OF_SERVICE = "0{"

# Default Region Values
REGION_US = 'US'
REGION_PR = 'PR'

