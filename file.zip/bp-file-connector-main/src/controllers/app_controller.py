from concurrent.futures import ThreadPoolExecutor
from flask import request

import prometheus_client
from http import HTTPStatus
from src.constants import APP_METRICS_LOG, APP_METRICS_DATA, APP_HEALTH_ENDPOINT, SERVICE_STATUS, APP_REPORT_GENERATOR
from src.report_generator.orchestrator import Orchestrator
from src.utils.common_utils import create_json_response

executor = ThreadPoolExecutor(max_workers=5)


def app_health():
    print(APP_HEALTH_ENDPOINT)
    return create_json_response("Health Check", SERVICE_STATUS, HTTPStatus.OK )

def report_generate():
    print(APP_REPORT_GENERATOR)

    # Get identifiers from query parameters
    identifiers = request.args.get('identifiers').split(",")

    # Log the requested identifiers
    print(f"Report generation requested with identifiers: {identifiers}")

    # Submit the job to the executor with the identifiers
    orchestrator = Orchestrator()
    executor.submit(orchestrator.start, identifiers)

    return create_json_response(
        "Reporting Service",
        f"Started with identifiers: {', '.join(identifiers) if identifiers else 'All'}",
        HTTPStatus.OK
    )

def app_metrics():
    print(APP_METRICS_LOG)
    metrics_data = prometheus_client.generate_latest()
    print(APP_METRICS_DATA.format(metrics_data=metrics_data))
    return  create_json_response("Metrics", metrics_data.decode('utf-8'), HTTPStatus.OK )
