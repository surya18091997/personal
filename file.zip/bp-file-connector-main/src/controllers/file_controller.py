from flask import request
from src.file_processor_factory.file_processor_factory import FileProcessorFactory
from src.utils.common_utils import create_json_response, record_request_id, update_request_status, generate_request_id
from src.utils.errors.app_errors import ApplicationErrorMessage
from src.utils.logging_helper import setup_request_logger
from concurrent.futures import ThreadPoolExecutor
import src.utils.app_config as app_config
from http import HTTPStatus
from src.constants import DATE_FORMAT_YYYY_MM_DD, MISSING_CONFIGURATION, INVALID_CONFIGURATION_ID, \
    FROM_AND_TO_DATE_VALIDATION, INVALID_DATE_FORMAT, F_ERROR, F_COMPLETED, TRANSFER_FILE, INVALID_REQUEST, \
    TRANSFER_REQUEST_ACCEPTED, ERROR_FILE_TRANSFER, LOAD_FILE, GENERATE_REQUEST_ACCEPTED, ERROR_FILE_PARSE, \
    REQUEST_ERROR_MESSAGE, GENERATE_FILE, ERROR_FILE_GENERATE, UPDATE_ERROR_REQUEST_AND_HANDLE_ERROR, \
    FILE_GEN_STARTED, FILE_GEN_COMPLETED, LOAD_REQUEST_ACCEPTED, FLOW_CONFIG, \
    START_DT_GT_END_DT, FILE_TRANSFER_STARTED, FILE_TRANSFER_COMPLETED, FILE_LOAD_STARTED, FILE_LOAD_COMPLETED, \
    ERROR_FILE_PARSE_PROCESS, ERROR_FILE_GEN_PROCESS, ERROR_FILE_TRANSFER_PROCESS, END_POINT_ACCESSED, \
    ERROR_IN_LOG_CREATION, INVALID_PROCESS_TYPE, FLOW_CONFIG_ELIGIBLE_WAGES, FLOW_CONFIG_ELIGIBLE_HOURS, RUN_DATE, \
    FROM_DATE, TO_DATE, TRANSACTION_LOG_CONFIGS, DATA_EXTRACT_FILE, DATA_EXTRACT_FILE_STARTED, \
    DATA_EXTRACT_FILE_COMPLETED, ERROR_DATA_EXTRACT_FILE_PROCESS, DATA_EXTRACT_FILE_REQUEST_ACCEPTED, \
    ERROR_DATA_EXTRACT_FILE
import datetime

executor = ThreadPoolExecutor(max_workers=5)

"""
Handles the file transfer request.

Args:
    None

Returns:
    A JSON response indicating the request is submitted for processing with HTTP status 200.
    If validation fails, returns a JSON response with an error message and HTTP status 400.
    If any exception occurs during the process, returns a JSON response with the error message and HTTP status 500.
"""
def transfer_file():
    return process_file(TRANSFER_FILE)

"""
Handles the file load request.

Args:
    None

Returns:
    A JSON response indicating the request is submitted for processing and file generation is in progress
    with HTTP status 200.
    If validation fails, returns a JSON response with an error message and HTTP status 400.
    If any exception occurs during the process, returns a JSON response with the error message and HTTP status 500.
"""
def load_file():
    return process_file(LOAD_FILE)


"""
Generates a file based on the provided request data.
Returns:
    A tuple containing a JSON response and an HTTP status code.

Raises:
    Exception: If an error occurs during file generation.

"""
def generate_file():
    return process_file(GENERATE_FILE)


"""
extract data from database and generates a file based on 
target type and place it in requested path.
Returns:
    A tuple containing a JSON response and an HTTP status code.

Raises:
    Exception: If an error occurs during file generation.

"""
def data_extract_and_create_file():
    return process_file(DATA_EXTRACT_FILE)
"""
Process the file based on the provided request data.

Args:
    process_type (str): The type of file processing to be done.

Returns:
    tuple: A tuple containing a JSON response and an HTTP status code.

Raises:
    Exception: If an error occurs during file processing.

"""

def process_file(process_type):
    request_id = None
    logger = None
    try:
        request_id, logger = create_request_logger(request, process_type)
        data = request.get_json()

        # validate the request
        error_message, configuration_id, start_date, end_date = validate_request(data, logger, process_type)

        # if there are no errors in request, we will update the request id in database
        if error_message:
            print_error_message(request_id, error_message)
            return create_json_response(request_id, INVALID_REQUEST, HTTPStatus.BAD_REQUEST)
        else:
            # record the transaction id in the database
            record_request_id(request_id, data, process_type, logger)
            executor.submit(run_file_process, configuration_id, logger, request_id,
                            start_date, end_date, process_type, data)

            return create_json_response(request_id, get_accept_message(process_type), HTTPStatus.OK)
    except Exception as e:
        # Update the request status
        update_request_and_handle_error(request_id, logger,
                                        get_accept_error_message(process_type).format(request_id=request_id, error_message=str(e)),
                                        HTTPStatus.INTERNAL_SERVER_ERROR)

"""
Run the file processing for a given configuration.

Args:
    configuration_id (int): The ID of the configuration.
    logger (logging.Logger): The logger instance.
    request_id (str): The ID of the request.
    start_date (datetime.datetime): The start date.
    end_date (datetime.datetime): The end date.
    process_type (str): The type of process.

Returns:
    None

Raises:
    Exception: If an error occurs during file processing.
"""
def run_file_process(configuration_id,  logger, request_id, start_date, end_date, process_type, data):
    try:
        file_processor = FileProcessorFactory.create_processor(configuration_id, logger, request_id,
                                                               start_date, end_date, data)
        logger.info(get_start_message(process_type).format(request_id=request_id))
        file_processor.start_process()
        logger.info(get_completion_message(process_type).format(request_id=request_id))
        update_request_status(request_id, F_COMPLETED, logger)
    except Exception as e:
        logger.error(get_process_error_message(process_type).format(request_id=request_id, error_message=str(e)))
        update_request_status(request_id, F_ERROR, logger, str(e))

"""
Returns the start message based on the given process type.

Args:
    process_type (str): The type of process. Must be one of 'LOAD_FILE', 'GENERATE_FILE', or 'TRANSFER_FILE'.

Returns:
    str: The start message corresponding to the given process type.
"""
def get_start_message(process_type):
    if process_type == LOAD_FILE:
        return FILE_LOAD_STARTED
    elif process_type == GENERATE_FILE:
        return FILE_GEN_STARTED
    elif process_type == TRANSFER_FILE:
        return FILE_TRANSFER_STARTED
    elif process_type == DATA_EXTRACT_FILE:
        return DATA_EXTRACT_FILE_STARTED
    else:
        raise ValueError(INVALID_PROCESS_TYPE)


"""
Returns the completion message based on the given process type.

Args:
    process_type (str): The type of process. Must be one of 'LOAD_FILE', 'GENERATE_FILE', or 'TRANSFER_FILE'.

Returns:
    str: The completion message corresponding to the given process type.
"""
def get_completion_message(process_type):
    if process_type == LOAD_FILE:
        return FILE_LOAD_COMPLETED
    elif process_type == GENERATE_FILE:
        return FILE_GEN_COMPLETED
    elif process_type == TRANSFER_FILE:
        return FILE_TRANSFER_COMPLETED
    elif process_type == DATA_EXTRACT_FILE:
        return DATA_EXTRACT_FILE_COMPLETED
    else:
        raise ValueError(INVALID_PROCESS_TYPE)

"""
Returns the appropriate error message based on the given process type.

Args:
    process_type (str): The type of process. Must be one of 'LOAD_FILE', 'GENERATE_FILE', or 'TRANSFER_FILE'.

Returns:
    str: The error message corresponding to the given process type.
"""
def get_process_error_message(process_type):
    if process_type == LOAD_FILE:
        return ERROR_FILE_PARSE_PROCESS
    elif process_type == GENERATE_FILE:
        return ERROR_FILE_GEN_PROCESS
    elif process_type == TRANSFER_FILE:
        return ERROR_FILE_TRANSFER_PROCESS
    elif process_type == DATA_EXTRACT_FILE:
        return ERROR_DATA_EXTRACT_FILE_PROCESS
    else:
        raise ValueError(INVALID_PROCESS_TYPE)

"""
Returns the appropriate acceptance message based on the given process type.

Parameters:
    process_type (str): The type of process.

Returns:
    str: The acceptance message.

Raises:
    None.
"""
def get_accept_message(process_type):
    if process_type == LOAD_FILE:
        return LOAD_REQUEST_ACCEPTED
    elif process_type == GENERATE_FILE:
        return GENERATE_REQUEST_ACCEPTED
    elif process_type == TRANSFER_FILE:
        return TRANSFER_REQUEST_ACCEPTED
    elif process_type == DATA_EXTRACT_FILE:
        return DATA_EXTRACT_FILE_REQUEST_ACCEPTED
    else:
        raise ValueError(INVALID_PROCESS_TYPE)

"""
Returns the appropriate error message based on the given process type.

Args:
    process_type (str): The type of process. Must be one of 'LOAD_FILE', 'GENERATE_FILE', or 'TRANSFER_FILE'.

Returns:
    str: The error message corresponding to the given process type.
"""
def get_accept_error_message(process_type):
    if process_type == LOAD_FILE:
        return ERROR_FILE_PARSE
    elif process_type == GENERATE_FILE:
        return ERROR_FILE_GENERATE
    elif process_type == TRANSFER_FILE:
        return ERROR_FILE_TRANSFER
    elif process_type == DATA_EXTRACT_FILE:
        return ERROR_DATA_EXTRACT_FILE
    else:
        raise ValueError(INVALID_PROCESS_TYPE)

"""
Print the error message for a given request ID.

Args:
    request_id (str): The ID of the request.
    error_message (str): The error message to print.

Returns:
    None
"""
def print_error_message(request_id, error_message):
    print(REQUEST_ERROR_MESSAGE.format(request_id=request_id, error_message=error_message))


"""
Validates the request data and returns the error message, configuration ID, start date, and end date.

Args:
    data (dict): The request data.
    logger (logging.Logger): The logger to use for logging.
    process_type (str): The type of process.

Returns:
    tuple: A tuple containing the error message (str), configuration ID (str), start date (datetime), and end date (datetime).
"""
def validate_request(data, logger, process_type):
    errors = []
    configuration_id = data.get('configurationId')
    error_message = ''
    start_date = None
    end_date = None

    try:
        # validate if configuration id is present in flow config and valid.
        if not configuration_id:
            errors.append(MISSING_CONFIGURATION)
        else:
            flow_config = app_config.get_config_value(FLOW_CONFIG, str(configuration_id))
            if not flow_config and process_type != DATA_EXTRACT_FILE:
                errors.append(INVALID_CONFIGURATION_ID.format(configuration_id=configuration_id))
            else:
                # For file generation validate the start date , end date and run date as applicable.
                if process_type == GENERATE_FILE:
                   start_date, end_date, errors = validate_and_parse_dates(data, configuration_id, errors)

        if errors:
            error_message = '\n'.join(errors)
            logger.error(error_message)

        return error_message, configuration_id, start_date, end_date

    except Exception as e:
        logger.error(INVALID_CONFIGURATION_ID.format(configuration_id=e))
        return error_message, configuration_id, None, None


def validate_and_parse_dates(data, configuration_id, errors):
    """
    Validates and parses dates from the request data.
    """
    try:
        # Both wage file and hours file use runDate
        if configuration_id in [FLOW_CONFIG_ELIGIBLE_WAGES, FLOW_CONFIG_ELIGIBLE_HOURS, 23, 50]:
            if configuration_id in (23, 50):
                return None, None, errors
            run_date = data.get(RUN_DATE)
            if run_date:
                # Return datetime object for provided date
                return datetime.datetime.strptime(run_date, DATE_FORMAT_YYYY_MM_DD), None, errors
            # Return None to trigger get_max_run_date()
            return None, None, errors
        else:
            start_date_str = data.get(FROM_DATE)
            end_date_str = data.get(TO_DATE)

            if not (start_date_str and end_date_str):
                if configuration_id in TRANSACTION_LOG_CONFIGS:
                    return None, None, errors
                errors.append(FROM_AND_TO_DATE_VALIDATION)
                return None, None, errors

            parsed_start = datetime.datetime.strptime(start_date_str, DATE_FORMAT_YYYY_MM_DD)
            parsed_end = datetime.datetime.strptime(end_date_str, DATE_FORMAT_YYYY_MM_DD)

            if parsed_start > parsed_end:
                errors.append(START_DT_GT_END_DT.format(start_date=parsed_start, end_date=parsed_end))
                return None, None, errors

            return parsed_start, parsed_end, errors

    except ValueError as e:
        errors.append(f"{INVALID_DATE_FORMAT} {str(e)}")
        return None, None, errors

"""
Creates a request logger.

Args:
    input_request: The input request.
    func_name: The name of the function.

Returns:
    A tuple containing the request ID and the logger.

Raises:
    CustomError: If there is an error in request creation.
"""
def create_request_logger(input_request, func_name):
    request_id = None
    try:
        request_id = generate_request_id()
        data = input_request.get_json()
        #create a logger for each request
        logger = setup_request_logger(request_id)
        logger.info(END_POINT_ACCESSED.format(func_name=func_name, request_id=request_id, request_body=data))
        return request_id, logger

    except Exception as e:
        print(ERROR_IN_LOG_CREATION.format( request_id=request_id, error_message=str(e)))
        raise(ApplicationErrorMessage(ERROR_IN_LOG_CREATION.format( request_id=request_id, error_message=str(e))))

"""
Updates the request status to error and handles the error.

Args:
    request_id (str): The ID of the request.
    logger (logging.Logger): The logger object.
    error_message (str): The error message.
    status_code (int): The HTTP status code.

Returns:
    tuple: A tuple containing the request ID, logger, and error message.

Raises:
    Exception: If there is an error in updating the request status.
"""
def update_request_and_handle_error(request_id, logger, error_message, status_code):
    try:
        update_request_status(request_id, F_ERROR, logger, error_message)
        if logger:
            logger.error(error_message)
        else:
            print(error_message)
        return create_json_response(request_id, error_message, status_code)
    except Exception as e:
        logger.error(UPDATE_ERROR_REQUEST_AND_HANDLE_ERROR.format(error_message=str(e)))
        return create_json_response(request_id, error_message, HTTPStatus.INTERNAL_SERVER_ERROR)



