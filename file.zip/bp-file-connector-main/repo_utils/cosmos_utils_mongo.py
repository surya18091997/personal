#Back up cosmos_utils for direct MongoDB fetch
from pymongo import MongoClient
from pymongo.errors import OperationFailure

import src.utils.app_config as app_config
import time


class cosmos_utils:

    def __init__(self, logger):
        self.logger = logger
        mongodb_connection_file_path = app_config.get_config_value("app","mongodb_connection_file_path")
        with open(mongodb_connection_file_path, 'r') as f:
            conn_string = f.read().strip()

        self.connection_string = conn_string

    """
    Retrieves structured data from a MongoDB collection based on the provided search criteria.

    Args:
        mongo_database (str): The name of the MongoDB database.
        mongo_collection (str): The name of the MongoDB collection.
        mongo_search_criteria (dict): The search criteria to filter the documents.

    Returns:
        str: The formatted data as a string.

    Examples:
        >>> data = get_structured_data('my_database', 'my_collection', {'field': 'value'})
        [{'_id': ObjectId('...'), 'field': 'value', ...}, ...]
    """

    def get_structured_data(self, mongo_database, mongo_collection, mongo_projection, mongo_search_criteria):
        retry_count = 0
        max_retry_count = 2
        retry_delay = 5

        # Create mongo client connection
        client = MongoClient(self.connection_string)

        # Define the database and collection
        db = client[mongo_database]
        collection = db[mongo_collection]

        # Check if 'mongo_search_criteria' is a valid BSON type
        if not isinstance(mongo_search_criteria, dict):
            self.logger.error('Invalid search criteria - must be a dictionary')
            return None

        while retry_count < max_retry_count:
            try:
                # Use the find method to retrieve data based on the search criteria
                documents = collection.find(mongo_search_criteria, mongo_projection)
                self.logger.info(
                    f'Data fetched from Cosmos Mongo API {mongo_database}.{mongo_collection} for the criteria {mongo_search_criteria} successfully')

                return list(documents)

            except OperationFailure as e:
                if e.code == 16500:
                    retry_count += 1
                    if retry_count < max_retry_count:
                        time.sleep(retry_delay)
                        continue

            except Exception as e:
                self.logger.error(f'Max retry count reached. Error in get_structured_data: {e}')
                return None


