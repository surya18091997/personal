import daft
from daft.io import IOConfig, GCSConfig


def main():
    print("Starting...")

    # io_config = IOConfig(
    #     gcs=GCSConfig(credentials="/Users/s0k02kj/Documents/Benefits-Tech/Connector/sai_daft_gcp_conn.json"))
    io_config = IOConfig(
        gcs=GCSConfig(credentials="/Users/s0k02kj/Documents/Benefits-Tech/Connector/datalake_gcskey.json"))
    # Specify the GCS bucket path to your Hudi dataset
    # hudi_path = "gs://benefits-data-lake/comparison/mongo_documents/associate_benefit_profile_dm4/*parquet"
    hudi_path = "gs://benefits-datalake/test2/flattened/transaction-logs/**/*.parquet"

    df = daft.read_parquet(hudi_path, io_config=io_config)

    df.show(n=10)

    # Convert Daft DataFrame to Pandas and then to Spark DataFrame
    spark_df = df.to_pandas()

    # How to query this data
    print("Done")

if __name__ == '__main__':
    main()