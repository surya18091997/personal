
import os

WORKING_DIR = "/working_dir" # Replace with your working directory path
CONFIG_DIR = "/etc/config/" # Replace with your config directory path

def main(file_name):
    print("Starting...")
    # Replace the config file with your file path
    with open(CONFIG_DIR + file_name, 'r') as f:
        json_str = f.read()

    remove_character_before_and_after_tilde(json_str, file_name+"parsed.json")
    print("Done")

def write_to_file(file_path, content):
    with open(file_path, 'w') as f:
        f.write(content)

def remove_character_before_and_after_tilde(input_string, f_name):
    # Removing outer quotes and un escaping inner quotes
    # Use regex to find all ~...~ and remove ~
    modified_string = input_string.replace('\\"', '"').replace('"~', '').replace('~"', '')
    modified_string = modified_string[1:-1] # Removing outer quotes

    print(f"Modified string: {modified_string} for file: {f_name}")
    write_to_file(os.path.join(WORKING_DIR, f_name), modified_string)
    return modified_string

if __name__ == '__main__':
    fileName = "<provide configuration file name that needs to be parsed>"
    main(fileName)
