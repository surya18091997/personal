import daft
from daft.io import IOConfig, GCSConfig
import time
import psutil
import pandas as pd
from memory_profiler import profile
from datetime import datetime
import os


def log_with_timestamp(message):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    print(f"[{timestamp}] {message}")


@profile
def process_in_chunks(df, chunk_size=1000000, output_file="output_data.csv"):
    """Process large DataFrame in chunks and write to CSV"""
    total_records = df.count_rows()
    num_chunks = (total_records + chunk_size - 1) // chunk_size

    log_with_timestamp(f"Processing {total_records:,} records in {num_chunks:,} chunks...")

    # Write headers only once
    header = True

    for i in range(0, total_records, chunk_size):
        chunk_start_time = time.time()
        log_with_timestamp(f"Processing chunk {(i // chunk_size) + 1} of {num_chunks}")

        # Process chunk
        chunk_df = df.limit(chunk_size).to_pandas()

        # Write chunk to CSV
        chunk_df.to_csv(output_file,
                        mode='a' if not header else 'w',
                        header=header,
                        index=False)

        # After first chunk, don't write headers
        header = False

        chunk_end_time = time.time() - chunk_start_time
        memory_usage = psutil.Process().memory_info().rss / 1024 ** 2  # MB
        log_with_timestamp(f"Chunk processed in {chunk_end_time:.2f} seconds. Memory usage: {memory_usage:.2f} MB")

def load_and_analyze_data(hudi_path: str, io_config: IOConfig, output_file: str):
    """Load and analyze data with performance metrics"""
    start_time = time.time()
    log_with_timestamp("Starting data load from GCS...")

    # Load the Daft DataFrame
    df = daft.read_parquet(hudi_path, io_config=io_config)

    # Get total count
    total_records = df.count_rows()
    log_with_timestamp(f"Total records to process: {total_records:,}")

    # Process in chunks and write to file
    process_in_chunks(df, output_file=output_file)

    # Verify output file
    output_size = os.path.getsize(output_file) / (1024 ** 2)  # MB
    log_with_timestamp(f"Output file size: {output_size:.2f} MB")

    return output_file

def main():
    start_time = time.time()
    output_file = "benefits_data_output.csv"

    try:
        log_with_timestamp("Initializing script...")

        # Configuration
        io_config = IOConfig(
            gcs=GCSConfig(credentials="/Users/s0a05sw/Documents/secrets/daft_gcp_conn.json")
        )
        hudi_path = "gs://benefits-data-lake/comparison/mongo_documents/associate_benefit_profile_dm5/*parquet"

        # Process data and write to file
        output_path = load_and_analyze_data(hudi_path, io_config, output_file)

        log_with_timestamp(f"Data successfully written to: {output_path}")

    except Exception as e:
        log_with_timestamp(f"Error occurred: {str(e)}")
        raise
    finally:
        total_time = time.time() - start_time
        log_with_timestamp(f"Total execution time: {total_time:.2f} seconds")
        log_with_timestamp("Processing completed")

if __name__ == '__main__':
    main()