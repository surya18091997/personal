

DROP TABLE connector.fc_tracker;


--Create a FC tracker table, to track the file connector module requests.
CREATE TABLE connector.fc_tracker (
	request_id uuid NOT NULL,
	configuration_id varchar(30) NOT NULL,
	module_name varchar(15) null,
	request_body varchar(100) NULL,
	request_create_ts timestamp NULL,
	request_last_update_ts timestamp NULL,
	current_status varchar(20) NULL,
	detailed_status varchar(400) NULL,
	CONSTRAINT fc_tracker_pkey PRIMARY KEY (request_id)
);