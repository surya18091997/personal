import logging

class HudiWriter:
    def __init__(self, spark_session , file_path, table_name="", key_columns="", hive_enable=False):
        self.path = file_path
        self.table_name = table_name
        self.spark = spark_session
        self.key_columns = ','.join(item for item in key_columns)

        # Set up common Hudi options here
        self.hudi_options = {
            "hoodie.table.name": self.table_name,
            "hoodie.datasource.write.recordkey.field": self.key_columns,
            "hoodie.datasource.write.precombine.field": self.key_columns,
        }
        if hive_enable:
            self.hudi_options["hoodie.datasource.hive_sync.enable"] = "true"
            self.hudi_options["hoodie.datasource.hive_sync.database"] = "benefits"
            self.hudi_options["hoodie.datasource.hive_sync.table"] = self.table_name
            self.hudi_options["hoodie.datasource.hive_sync.mode"] = "hms"
            self.hudi_options["hoodie.datasource.write.hive_style_partitioning"] = "true"

    def write_to_hudi(self, df, write_mode="overwrite", write_option="bulk_insert"):
        try:
            self.hudi_options["hoodie.datasource.write.operation"] = write_option
            df.write.format("hudi").options(**self.hudi_options).mode(write_mode).save(self.path)
        except Exception as e:
            logging.exception("An error occurred while writing to Hudi: ", e)
            # raise HudiError(f"An error occurred while writing to Hudi: {e}")

    def read_from_hudi(self):
        try:
            df = self.spark.read.format("hudi").load(self.path + "/*")
            df.show()
        except Exception as e:
            logging.exception("An error occurred while reading from Hudi: ", e)
            # raise HudiError(f"An error occurred while reading from Hudi: {e}")

    def delete_from_hudi(self, df):
        try:
            df.write.format("hudi").options(**self.hudi_options).mode("overwrite").save(self.path)
        except Exception as e:
            logging.exception("An error occurred while deleting from Hudi: ", e)
            # raise HudiError(f"An error occurred while deleting from Hudi: {e}")



