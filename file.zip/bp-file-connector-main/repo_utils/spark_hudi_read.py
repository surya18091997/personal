from pyspark.sql import SparkSession
import datetime
from repo_utils.hudi_utility import HudiWriter


def initialize_spark(app_name):
    try:
        spark = SparkSession.builder \
            .appName(app_name) \
            .master("local[*]") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.hadoop.google.cloud.auth.service.account.enable", "true") \
            .config("spark.hadoop.google.cloud.auth.service.account.json.keyfile",
                    "/mnt/azure/data_migration/configs/daft_gcp_conn.json") \
            .config("spark.hadoop.fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem") \
            .config("spark.hadoop.fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS") \
            .config("spark.jars",
                    "/Users/s0g0a75/oscar_mnt/azure/data_migration/dependency_jars/gcs-connector-hadoop3-latest.jar, /Users/s0g0a75/oscar_mnt/azure/data_migration/dependency_jars/hudi-spark3.5-bundle_2.12-0.15.0.jar") \
            .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension") \
            .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.hudi.catalog.HoodieCatalog") \
            .getOrCreate()

        spark._jsc.hadoopConfiguration().set('fs.gs.impl', 'com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem')
        spark._jsc.hadoopConfiguration().set('fs.AbstractFileSystem.gs.impl', 'com.google.cloud.hadoop.fs.gcs'
                                                                              '.GoogleHadoopFileSystem')

    except Exception as e:
        print(f"An error occurred during initializing Spark: {e}")
        raise e
    return spark

def spark_hudi_read():
    try:
        #  hudi_writer = HudiWriter(spark_session, compare_results_path, table_name=compare_results_table_name,
        #                                  key_columns=key_columns, hive_enable=hive_enable_flag)
        spark_session = initialize_spark('HudiDataReader')
        # h = HudiWriter(spark_session, 'gs://benefits-datalake/dev/6/raw/transaction-logs', 'transaction_logs', '', False)
        # h.read_from_hudi()

        df = spark_session.read.format("hudi").load("gs://benefits-datalake/dev/6/raw/transaction-logs")
        df.show()

        df.createOrReplaceTempView("hudi_table_data")
        print(f" before query - {datetime.datetime.now()}")
        selected_df = spark_session.sql(
            """
            SELECT id, associateId, fullDocument
            FROM hudi_table_data
            WHERE associateId = '101109973'
            """
        )
        print(f" after query - {datetime.datetime.now()}")
        print(selected_df.count())
        print(f" after query execution count: - {datetime.datetime.now()}")
        selected_df.show()
        print(f" after query execution show: - {datetime.datetime.now()}")

    except Exception as e:
        # Handle any exceptions
        print(f"An error occurred: {e}")
        raise
    finally:
        spark_session.stop()

if __name__ == "__main__":
    spark_hudi_read()