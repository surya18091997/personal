from azure.identity import ClientSecretCredential
from azure.cosmos import CosmosClient

#pip install azure-identity azure-cosmos

# Get the values below from the portal - https://dx.walmart.com/serviceaccountmgmt/dashboard
# Additional information on how to define secrets - https://dx.walmart.com/serviceaccountmgmt/documentation/dx/WCNP-KITT-changes-with-ESO-engine-D0000001158
# Please refer to KITT file, akeyless section.
# For DEV - SVC_CDB_benefits-platform_011525203437  - download the connection details
# For STG - SVC_CDB_benefits-platform_011625204446  - download the connection details
# Set Azure AD service principal credentials
tenant_id = '*'
client_id = '*'
client_secret = '*'

# Set Cosmos DB details
cosmos_account_url = 'https://benefits-platform-devsl-cosmos.documents.azure.com:443/'
cosmos_database_name = 'benefits-platform' #Resource Name
cosmos_container_name = '' #associate-benefit-profile

def main():
    credential = ClientSecretCredential(tenant_id, client_id, client_secret)

    # Create a new CosmosClient instance
    client = CosmosClient(cosmos_account_url, credential)

    # Connect to the Cosmos DB
    database = client.get_database_client(cosmos_database_name)
    container = database.get_container_client(cosmos_container_name)

    # Now you can run queries, read data, write data, etc.
    # For example, to get all items in the container:
    for item in container.read_all_items():
        print(item)

if __name__ == '__main__':
    main()