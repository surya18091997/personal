package com.surya.productB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductBApplication.class, args);
	}

}
