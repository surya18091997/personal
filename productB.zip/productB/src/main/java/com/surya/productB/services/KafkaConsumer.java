package com.surya.productB.services;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
    // Method to consume String messages from the Kafka topic
    @KafkaListener(topics = "associate-events-new", groupId = "surya-pakka")
    public void consumeStringMessage(String message) {
        System.out.println("Received message: " + message);
    }
}
