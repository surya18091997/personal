package com.surya.productB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductBApplicationTests {

	@Test
	void contextLoads() {
	}

}
