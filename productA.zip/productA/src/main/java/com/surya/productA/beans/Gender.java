package com.surya.productA.beans;

public enum Gender {
    MALE, FEMALE, NOT_DEFINED
}
