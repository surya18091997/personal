package com.surya.productA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductAApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductAApplication.class, args);
	}

}
