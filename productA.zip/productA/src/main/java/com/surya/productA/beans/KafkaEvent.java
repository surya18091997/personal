package com.surya.productA.beans;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class KafkaEvent {
    @NotEmpty()
    @NotNull()
    private String eventType;
    @NotEmpty()
    @NotNull()
    private String assocName;
    @NotEmpty()
    @NotNull()
    private Gender gender;

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public String getAssocName() {
        return assocName;
    }

    public void setAssocName(String assocName) {
        this.assocName = assocName;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
}
