package com.surya.productA.Service;

import org.springframework.stereotype.Service;

import com.surya.productA.beans.KafkaEvent;

import org.springframework.beans.factory.annotation.Autowired;

@Service
public class EventHandler {
    private final KafkaProducer kafkaProducer;

    @Autowired
    public EventHandler(KafkaProducer kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    public void produceEvent(KafkaEvent kafkaEvent) {
        String topic = "associate-events-new";
        kafkaProducer.sendMessage(topic, kafkaEvent.getAssocName());
    }
}
