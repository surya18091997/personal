package com.surya.productA.controller;
import org.springframework.web.bind.annotation.RestController;

import com.surya.productA.Service.EventHandler;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.http.MediaType;
import com.surya.productA.beans.KafkaEvent;

@RestController
@RequestMapping("/product/create_event")
public class AController {
    @Autowired
    private EventHandler eventHandler;

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getChangeReasonCodes (
        @Valid @RequestBody KafkaEvent kafkaEvent
    ){
        eventHandler.produceEvent(kafkaEvent);
        System.out.println(kafkaEvent);
		return new ResponseEntity<>("Success", HttpStatus.OK);
	}
}
