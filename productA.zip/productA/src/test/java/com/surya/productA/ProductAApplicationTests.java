package com.surya.productA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductAApplicationTests {

	@Test
	void contextLoads() {
	}

}
