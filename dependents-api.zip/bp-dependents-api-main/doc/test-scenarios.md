# Dependent API Test Scenarios

This document contains various test scenarios for testing the Dependent API and Sequence API functionality, along with cURL commands to execute the tests.

## Prerequisites

Before executing these tests, ensure that:
- The application is running
- You have access to the required endpoints
- You have permissions to make API calls

## Scenario 1: Creating a New Dependent (Insert Operation)

### Description
This test will create a new dependent without providing a benefitMemberId. The system should generate a unique ID using the sequence generator.

### Test Command
```bash
curl -X POST http://localhost:8080/dependents/upsert \
  -H "Content-Type: application/json" \
  -d '{
    "dependentProfile": {
      "firstName": "John",
      "lastName": "Doe",
      "dateOfBirth": "1990-01-01",
      "gender": "MALE",
      "nationalId": "123-45-6789",
      "address": [{
        "addressLine1": "123 Main St",
        "city": "Bentonville",
        "state": "AR",
        "zip": "72712",
        "country": "USA",
        "addressType": "HOME"
      }],
      "contacts": {
        "phoneNumber": "555-555-5555",
        "email": "john.doe@example.com"
      }
    },
    "lifeStyle": {
      "isSmoker": false,
      "isDrinker": false
    },
    "HIPAADisclosure": true
  }'
```

## Scenario 2: Updating an Existing Dependent

### Description
This test will update an existing dependent by providing a benefitMemberId. The system should locate the record and update it.

### Test Command
```bash
curl -X POST http://localhost:8080/dependents/upsert \
  -H "Content-Type: application/json" \
  -d '{
    "benefitMemberId": "131",
    "dependentProfile": {
      "firstName": "John",
      "lastName": "Doe",
      "dateOfBirth": "1990-01-01",
      "gender": "MALE",
      "nationalId": "123-45-6789",
      "address": [{
        "addressLine1": "456 Updated Ave",
        "city": "Bentonville",
        "state": "AR",
        "zip": "72712",
        "country": "USA",
        "addressType": "HOME"
      }],
      "contacts": {
        "phoneNumber": "555-555-5555",
        "email": "updated.email@example.com"
      }
    },
    "lifeStyle": {
      "isSmoker": true,
      "isDrinker": false
    },
    "HIPAADisclosure": true
  }'
```

## Scenario 3: Retrieving a Dependent by ID

### Description
This test will retrieve a dependent by its benefitMemberId.

### Test Command
```bash
curl -X GET http://localhost:8080/dependents/133 \
  -H "Content-Type: application/json"
```

## Scenario 4: Deleting a Dependent

### Description
This test will delete (soft delete) a dependent by setting its active status to false.

### Test Command
```bash
curl -X DELETE http://localhost:8080/dependents/132 \
  -H "Content-Type: application/json"
```

## Scenario 5: Getting the Current Sequence Value

### Description
This test will retrieve the current value of the dependent sequence without incrementing it.

### Test Command
```bash
curl -X GET http://localhost:8080/sequences/dependent \
  -H "Content-Type: application/json"
```

## Scenario 6: Generating a New Sequence Value

### Description
This test will generate a new sequence value for dependents.

### Test Command
```bash
curl -X POST http://localhost:8080/sequences/dependent/generate \
  -H "Content-Type: application/json"
```

## Scenario 7: Concurrent Insert Operations (Race Condition Test)

### Description
This test simulates multiple concurrent insert operations to verify that unique IDs are generated for each dependent.

### Test Script
```bash
#!/bin/bash
# Execute multiple insert operations in parallel

for i in {1..5}
do
  curl -X POST http://localhost:8080/dependents/upsert \
    -H "Content-Type: application/json" \
    -d '{
      "dependentProfile": {
        "firstName": "Concurrent",
        "lastName": "User'$i'",
        "dateOfBirth": "1990-01-01",
        "gender": "MALE",
        "nationalId": "123-45-678'$i'",
        "address": [{
          "addressLine1": "123 Test St",
          "city": "Bentonville",
          "state": "AR",
          "zip": "72712",
          "country": "USA",
          "addressType": "HOME"
        }],
        "contacts": {
          "phoneNumber": "555-555-555'$i'",
          "email": "test'$i'@example.com"
        }
      },
      "lifeStyle": {
        "isSmoker": false,
        "isDrinker": false
      },
      "HIPAADisclosure": true
    }' &
done

wait
echo "All requests completed"
```

## Scenario 8: Getting All Dependents

### Description
This test will retrieve all dependents from the database.

### Test Command
```bash
curl -X GET http://localhost:8080/dependents/all \
  -H "Content-Type: application/json"
```

## Scenario 9: Insert with Custodian Information

### Description
This test will create a new dependent with custodian information.

### Test Command
```bash
curl -X POST http://localhost:8080/dependents/upsert \
  -H "Content-Type: application/json" \
  -d '{
    "dependentProfile": {
      "firstName": "Child",
      "lastName": "User",
      "dateOfBirth": "2015-01-01",
      "gender": "FEMALE",
      "nationalId": "123-45-6790",
      "address": [{
        "addressLine1": "789 Guardian St",
        "city": "Bentonville",
        "state": "AR",
        "zip": "72712",
        "country": "USA",
        "addressType": "HOME"
      }],
      "contacts": {
        "phoneNumber": "555-555-5556",
        "email": "guardian@example.com"
      }
    },
    "custodian": {
      "firstName": "Parent",
      "lastName": "Guardian",
      "relationship": "PARENT",
      "contactNumber": "555-555-5557",
      "email": "parent@example.com"
    },
    "lifeStyle": {
      "isSmoker": false,
      "isDrinker": false
    },
    "HIPAADisclosure": true
  }'
```

## Scenario 10: Update with Exception Type

### Description
This test will update a dependent with exception type information.

### Test Command
```bash
curl -X POST http://localhost:8080/dependents/upsert \
  -H "Content-Type: application/json" \
  -d '{
    "benefitMemberId": "100002",
    "dependentProfile": {
      "firstName": "Special",
      "lastName": "Case",
      "dateOfBirth": "1995-01-01",
      "gender": "FEMALE",
      "nationalId": "123-45-6791",
      "address": [{
        "addressLine1": "101 Exception Ave",
        "city": "Bentonville",
        "state": "AR",
        "zip": "72712",
        "country": "USA",
        "addressType": "HOME"
      }],
      "contacts": {
        "phoneNumber": "555-555-5558",
        "email": "special@example.com"
      }
    },
    "exceptionType": "HARDSHIP",
    "exceptionTypeEffectiveDate": "2023-01-01",
    "lifeStyle": {
      "isSmoker": false,
      "isDrinker": false
    },
    "HIPAADisclosure": true
  }'
```

## Gateway API Tests

If you have a Gateway API available, you can also test the same endpoints through the gateway by replacing the base URL in the cURL commands.

### Example Gateway API Test (Creating a New Dependent)

```bash
curl -X POST https://your-gateway-api.com/dependents/upsert \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_AUTH_TOKEN" \
  -d '{
    "dependentProfile": {
      "firstName": "Gateway",
      "lastName": "Test",
      "dateOfBirth": "1990-01-01",
      "gender": "MALE",
      "nationalId": "123-45-6792",
      "address": [{
        "addressLine1": "123 Gateway Blvd",
        "city": "Bentonville",
        "state": "AR",
        "zip": "72712",
        "country": "USA",
        "addressType": "HOME"
      }],
      "contacts": {
        "phoneNumber": "555-555-5559",
        "email": "gateway@example.com"
      }
    },
    "lifeStyle": {
      "isSmoker": false,
      "isDrinker": false
    },
    "HIPAADisclosure": true
  }'
```