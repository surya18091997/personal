package com.walmart.bp.dependent.api.controllers;

import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentAddress;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import com.walmart.bp.dependent.api.exceptions.ResourceNotFoundException;
import com.walmart.bp.dependent.api.exceptions.ValidationException;
import com.walmart.bp.dependent.api.services.DependentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class DependentControllerTest {

    private static final String BENEFIT_MEMBER_ID = "123456";
    
    @Mock
    private DependentService dependentService;
    
    @InjectMocks
    private DependentController dependentController;
    
    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    
    private Dependent testDependent;
    
    // Exception handler for tests
    @ControllerAdvice
    static class TestControllerAdvice {
        
        @ExceptionHandler(ResourceNotFoundException.class)
        @ResponseStatus(HttpStatus.NOT_FOUND)
        public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
        
        @ExceptionHandler(ValidationException.class)
        @ResponseStatus(HttpStatus.BAD_REQUEST)
        public ResponseEntity<String> handleValidationException(ValidationException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
        
        @ExceptionHandler(IllegalArgumentException.class)
        @ResponseStatus(HttpStatus.BAD_REQUEST)
        public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
        
        @ExceptionHandler(RuntimeException.class)
        @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
        public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @BeforeEach
    void setUp() {
        // Set up MockMvc with the controller advice to handle exceptions
        mockMvc = MockMvcBuilders.standaloneSetup(dependentController)
                .setControllerAdvice(new TestControllerAdvice())
                .build();
        objectMapper = new ObjectMapper();
        
        // Set up test data
        testDependent = createTestDependent(BENEFIT_MEMBER_ID);
    }
    
    /**
     * Helper method to create a test Dependent instance
     */
    private Dependent createTestDependent(String benefitMemberId) {
        Dependent dependent = new Dependent();
        dependent.setBenefitMemberId(benefitMemberId);
        
        DependentProfile profile = new DependentProfile();
        Contact contact = new Contact();
        contact.setPhoneNumber("1234567890");
        profile.setContacts(contact);
        
        DependentAddress address = new DependentAddress();
        address.setCity("Test City");
        address.setZip("12345");
        address.setCountry("USA");
        profile.setAddress(Collections.singletonList(address));
        
        profile.setNationalId("123-45-6789");
        dependent.setDependentProfile(profile);
        
        return dependent;
    }
    
    @Nested
    @DisplayName("Tests for getDependentByBenefitMemberId method")
    class GetDependentByBenefitMemberIdTests {
        
        @Test
        @DisplayName("Should return dependent when found by benefit member ID")
        void shouldReturnDependentWhenFoundByBenefitMemberId() throws Exception {
            // Arrange
            when(dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                .thenReturn(testDependent);
            
            // Act & Assert
            mockMvc.perform(get("/dependents/{benefitMemberId}", BENEFIT_MEMBER_ID)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.benefitMemberId", is(BENEFIT_MEMBER_ID)))
                .andExpect(jsonPath("$.dependentProfile.contacts.phoneNumber", is("1234567890")))
                .andExpect(jsonPath("$.dependentProfile.address[0].city", is("Test City")))
                .andExpect(jsonPath("$.dependentProfile.address[0].zip", is("12345")))
                .andExpect(jsonPath("$.dependentProfile.nationalId", is("123-45-6789")));
                
            // Verify service interaction
            verify(dependentService).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
        }
        
        @Test
        @DisplayName("Should return 404 when dependent not found")
        void shouldReturn404WhenDependentNotFound() throws Exception {
            // Arrange
            String nonExistentId = "999999";
            when(dependentService.getDependentByBenefitMemberId(nonExistentId))
                .thenThrow(new ResourceNotFoundException("Dependent not found with benefitMemberId: " + nonExistentId));
            
            // Act & Assert
            mockMvc.perform(get("/dependents/{benefitMemberId}", nonExistentId)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
                
            // Verify service interaction
            verify(dependentService).getDependentByBenefitMemberId(nonExistentId);
        }
        
        @Test
        @DisplayName("Should handle unexpected errors")
        void shouldHandleUnexpectedErrors() throws Exception {
            // Arrange
            when(dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                .thenThrow(new RuntimeException("Unexpected error"));
            
            // Act & Assert
            mockMvc.perform(get("/dependents/{benefitMemberId}", BENEFIT_MEMBER_ID)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
                
            // Verify service interaction
            verify(dependentService).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
        }
        
        @Test
        @DisplayName("Should log the request information")
        void shouldLogTheRequestInformation() {
            // Arrange
            when(dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                .thenReturn(testDependent);
            
            // Act
            Dependent result = dependentController.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
            
            // Assert
            assertNotNull(result, "The result should not be null");
            assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(), "The returned dependent should have the correct ID");
            verify(dependentService).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
        }
    }
    
    @Nested
    @DisplayName("Tests for getAllDependents method")
    class GetAllDependentsTests {
        
        @Test
        @DisplayName("Should return list of all dependents when present")
        void shouldReturnListOfAllDependentsWhenPresent() throws Exception {
            // Arrange
            List<Dependent> dependents = new ArrayList<>();
            dependents.add(testDependent);
            dependents.add(createTestDependent("654321"));
            
            when(dependentService.getAllDependents()).thenReturn(dependents);
            
            // Act & Assert
            mockMvc.perform(get("/dependents/all")
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].benefitMemberId", is(BENEFIT_MEMBER_ID)))
                .andExpect(jsonPath("$[1].benefitMemberId", is("654321")));
                
            // Verify service interaction
            verify(dependentService).getAllDependents();
        }
        
        @Test
        @DisplayName("Should return empty list when no dependents are found")
        void shouldReturnEmptyListWhenNoDependentsAreFound() throws Exception {
            // Arrange
            when(dependentService.getAllDependents()).thenReturn(Collections.emptyList());
            
            // Act & Assert
            mockMvc.perform(get("/dependents/all")
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$", hasSize(0)));
                
            // Verify service interaction
            verify(dependentService).getAllDependents();
        }
        
        @Test
        @DisplayName("Should handle ResourceNotFoundException and return empty list")
        void shouldHandleResourceNotFoundExceptionAndReturnEmptyList() throws Exception {
            // Arrange
            when(dependentService.getAllDependents())
                .thenThrow(new ResourceNotFoundException("No dependents found"));
            
            // Act & Assert
            mockMvc.perform(get("/dependents/all")
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
                
            // Verify service interaction
            verify(dependentService).getAllDependents();
        }
        
        @Test
        @DisplayName("Should handle unexpected errors")
        void shouldHandleUnexpectedErrors() throws Exception {
            // Arrange
            when(dependentService.getAllDependents())
                .thenThrow(new RuntimeException("Unexpected error"));
            
            // Act & Assert
            mockMvc.perform(get("/dependents/all")
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
                
            // Verify service interaction
            verify(dependentService).getAllDependents();
        }
    }
    
    @Nested
    @DisplayName("Tests for upsertDependent method")
    class UpsertDependentTests {
        
        @Test
        @DisplayName("Should successfully insert new dependent")
        void shouldSuccessfullyInsertNewDependent() throws Exception {
            // Arrange
            Dependent newDependent = createTestDependent("");  // New dependent with no ID
            Dependent savedDependent = createTestDependent(BENEFIT_MEMBER_ID);  // Saved with generated ID
            
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenReturn(savedDependent);
            
            // Act & Assert
            mockMvc.perform(post("/dependents/upsert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(newDependent)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.benefitMemberId", is(BENEFIT_MEMBER_ID)));
                
            // Verify service interaction
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
        
        @Test
        @DisplayName("Should successfully update existing dependent")
        void shouldSuccessfullyUpdateExistingDependent() throws Exception {
            // Arrange
            Dependent existingDependent = testDependent;
            
            // Create an updated version with modified data
            Dependent updatedDependent = createTestDependent(BENEFIT_MEMBER_ID);
            DependentProfile updatedProfile = updatedDependent.getDependentProfile();
            updatedProfile.getAddress().get(0).setCity("Updated City");
            updatedProfile.setNationalId("987-65-4321");
            
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenReturn(updatedDependent);
            
            // Act & Assert
            mockMvc.perform(post("/dependents/upsert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(existingDependent)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.benefitMemberId", is(BENEFIT_MEMBER_ID)))
                .andExpect(jsonPath("$.dependentProfile.address[0].city", is("Updated City")))
                .andExpect(jsonPath("$.dependentProfile.nationalId", is("987-65-4321")));
                
            // Verify service interaction
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
        
        @Test
        @DisplayName("Should handle validation exception when input is invalid")
        void shouldHandleValidationExceptionWhenInputIsInvalid() throws Exception {
            // Arrange
            Dependent invalidDependent = new Dependent();  // Missing required fields
            
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenThrow(new ValidationException("Invalid dependent data"));
            
            // Act & Assert
            mockMvc.perform(post("/dependents/upsert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(invalidDependent)))
                .andExpect(status().isBadRequest());
                
            // Verify service interaction
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
        
        @Test
        @DisplayName("Should handle resource not found exception")
        void shouldHandleResourceNotFoundException() throws Exception {
            // Arrange
            Dependent dependent = createTestDependent("999999");  // Non-existent ID
            
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenThrow(new ResourceNotFoundException("Dependent not found for update"));
            
            // Act & Assert
            mockMvc.perform(post("/dependents/upsert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(dependent)))
                .andExpect(status().isNotFound());
                
            // Verify service interaction
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
        
        @Test
        @DisplayName("Should handle unexpected errors")
        void shouldHandleUnexpectedErrors() throws Exception {
            // Arrange
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenThrow(new RuntimeException("Unexpected error"));
            
            // Act & Assert
            mockMvc.perform(post("/dependents/upsert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(testDependent)))
                .andExpect(status().isInternalServerError());
                
            // Verify service interaction
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
        
        @Test
        @DisplayName("Should log the upsert request information")
        void shouldLogTheUpsertRequestInformation() {
            // Arrange
            when(dependentService.upsertDependent(any(Dependent.class)))
                .thenReturn(testDependent);
            
            // Act
            Dependent result = dependentController.upsertDependent(testDependent);
            
            // Assert
            assertNotNull(result, "The result should not be null");
            assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(), "The returned dependent should have the correct ID");
            verify(dependentService).upsertDependent(any(Dependent.class));
        }
    }
    
    @Nested
    @DisplayName("Tests for deleteDependent method")
    class DeleteDependentTests {
        
        @Test
        @DisplayName("Should successfully delete dependent and return deleted dependent")
        void shouldSuccessfullyDeleteDependentAndReturnDeletedDependent() throws Exception {
            // Arrange
            // Create a deleted dependent (typically would have isActive=false in real implementation)
            Dependent deletedDependent = createTestDependent(BENEFIT_MEMBER_ID);
            
            when(dependentService.deleteDependent(BENEFIT_MEMBER_ID))
                .thenReturn(deletedDependent);
            
            // Act & Assert
            mockMvc.perform(delete("/dependents/{benefitMemberId}", BENEFIT_MEMBER_ID)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.benefitMemberId", is(BENEFIT_MEMBER_ID)));
                
            // Verify service interaction
            verify(dependentService).deleteDependent(BENEFIT_MEMBER_ID);
        }
        
        @Test
        @DisplayName("Should return 404 when dependent not found for deletion")
        void shouldReturn404WhenDependentNotFoundForDeletion() throws Exception {
            // Arrange
            String nonExistentId = "999999";
            when(dependentService.deleteDependent(nonExistentId))
                .thenThrow(new ResourceNotFoundException("Dependent not found with benefitMemberId: " + nonExistentId));
            
            // Act & Assert
            mockMvc.perform(delete("/dependents/{benefitMemberId}", nonExistentId)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
                
            // Verify service interaction
            verify(dependentService).deleteDependent(nonExistentId);
        }
        
        @Test
        @DisplayName("Should handle validation exception for invalid benefitMemberId")
        void shouldHandleValidationExceptionForInvalidBenefitMemberId() throws Exception {
            // Arrange
            String invalidId = " "; // Use a space instead of empty string for path variable
            when(dependentService.deleteDependent(invalidId))
                .thenThrow(new ResourceNotFoundException("Dependent not found with benefitMemberId: " + invalidId));
            
            // Act & Assert
            mockMvc.perform(delete("/dependents/{benefitMemberId}", invalidId)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
                
            // Verify service interaction
            verify(dependentService).deleteDependent(invalidId);
        }
        
        @Test
        @DisplayName("Should handle IllegalArgumentException for null benefitMemberId")
        void shouldHandleIllegalArgumentExceptionForNullBenefitMemberId() throws Exception {
            // Arrange - We can't directly pass null as a path variable, but service might throw this
            String nullablePath = "null"; // This is a workaround since we can't actually pass null in the URL
            when(dependentService.deleteDependent(nullablePath))
                .thenThrow(new IllegalArgumentException("BenefitMemberId cannot be null or empty"));
            
            // Act & Assert
            mockMvc.perform(delete("/dependents/{benefitMemberId}", nullablePath)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
                
            // Verify service interaction
            verify(dependentService).deleteDependent(nullablePath);
        }
        
        @Test
        @DisplayName("Should handle unexpected errors during deletion")
        void shouldHandleUnexpectedErrorsDuringDeletion() throws Exception {
            // Arrange
            when(dependentService.deleteDependent(BENEFIT_MEMBER_ID))
                .thenThrow(new RuntimeException("Unexpected error during deletion"));
            
            // Act & Assert
            mockMvc.perform(delete("/dependents/{benefitMemberId}", BENEFIT_MEMBER_ID)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
                
            // Verify service interaction
            verify(dependentService).deleteDependent(BENEFIT_MEMBER_ID);
        }
        
        @Test
        @DisplayName("Should log the delete request information")
        void shouldLogTheDeleteRequestInformation() {
            // Arrange
            when(dependentService.deleteDependent(BENEFIT_MEMBER_ID))
                .thenReturn(testDependent);
            
            // Act
            Dependent result = dependentController.deleteDependent(BENEFIT_MEMBER_ID);
            
            // Assert
            assertNotNull(result, "The result should not be null");
            assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(), "The returned dependent should have the correct ID");
            verify(dependentService).deleteDependent(BENEFIT_MEMBER_ID);
        }
    }
}