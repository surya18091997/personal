package com.walmart.bp.dependent.api.mappers;

import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentAddress;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import com.walmart.bp.dependent.api.models.DependentDO;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive tests for {@link DependentDBObjectMapper} to ensure accurate mapping between
 * {@link Dependent} and {@link DependentDO} objects in all scenarios.
 */
@DisplayName("DependentDBObjectMapper Tests")
class DependentDBObjectMapperTest {

    private final DependentDBObjectMapper mapper = DependentDBObjectMapper.INSTANCE;
    
    @Nested
    @DisplayName("Tests for mapping a single Dependent to DependentDO")
    class SingleDependentToDependentDOTests {
        
        @Test
        @DisplayName("Should correctly map a Dependent with all fields to DependentDO")
        void shouldCorrectlyMapDependentWithAllFieldsToDependentDO() {
            // Arrange
            Dependent dependent = createTestDependent("123456");
            
            // Act
            DependentDO result = mapper.fromDependent(dependent);
            
            // Assert
            assertNotNull(result, "The mapped DependentDO should not be null");
            assertEquals(dependent.getBenefitMemberId(), result.getBenefitMemberId(), 
                    "BenefitMemberId should be mapped correctly");
            assertEquals(dependent.getCreatedAt(), result.getCreatedAt(), 
                    "CreatedAt should be mapped correctly");
            assertEquals(dependent.getCreatedBy(), result.getCreatedBy(), 
                    "CreatedBy should be mapped correctly");
            assertEquals(dependent.getLastModifiedAt(), result.getLastModifiedAt(), 
                    "LastModifiedAt should be mapped correctly");
            assertEquals(dependent.getLastModifiedBy(), result.getLastModifiedBy(), 
                    "LastModifiedBy should be mapped correctly");
            assertEquals(dependent.getVersion(), result.getVersion(), 
                    "Version should be mapped correctly");
            assertEquals(dependent.getDependentProfile().getNationalId(), 
                    result.getDependentProfile().getNationalId(), 
                    "NationalId should be mapped correctly");
        }
        
        @Test
        @DisplayName("Should return null when mapping a null Dependent")
        void shouldReturnNullWhenMappingNullDependent() {
            // Act
            DependentDO result = mapper.fromDependent((Dependent) null);
            
            // Assert
            assertNull(result, "The result should be null when mapping a null Dependent");
        }
        
        @Test
        @DisplayName("Should map null fields in Dependent to null in DependentDO")
        void shouldMapNullFieldsInDependentToNullInDependentDO() {
            // Arrange
            Dependent dependent = new Dependent();
            dependent.setBenefitMemberId("123456");
            // Deliberately leave other fields null
            
            // Act
            DependentDO result = mapper.fromDependent(dependent);
            
            // Assert
            assertNotNull(result, "The mapped DependentDO should not be null");
            assertEquals(dependent.getBenefitMemberId(), result.getBenefitMemberId(), 
                    "BenefitMemberId should be mapped correctly");
            assertNull(result.getDependentProfile(), 
                    "DependentProfile should be null when source is null");
            assertNull(result.getLifeStyle(), 
                    "LifeStyle should be null when source is null");
            assertNull(result.getCustodian(), 
                    "Custodian should be null when source is null");
        }
    }
    
    @Nested
    @DisplayName("Tests for mapping a list of Dependents to DependentDOs")
    class DependentListToDependentDOListTests {
        
        @Test
        @DisplayName("Should correctly map a list of Dependents to a list of DependentDOs")
        void shouldCorrectlyMapDependentListToDependentDOList() {
            // Arrange
            List<Dependent> dependentList = Arrays.asList(
                    createTestDependent("123456"),
                    createTestDependent("654321")
            );
            
            // Act
            List<DependentDO> result = mapper.fromDependent(dependentList);
            
            // Assert
            assertNotNull(result, "The mapped list should not be null");
            assertEquals(dependentList.size(), result.size(), 
                    "The mapped list should have the same size as the source list");
            
            for (int i = 0; i < dependentList.size(); i++) {
                assertEquals(dependentList.get(i).getBenefitMemberId(), result.get(i).getBenefitMemberId(), 
                        "Each BenefitMemberId should be mapped correctly");
            }
        }
        
        @Test
        @DisplayName("Should return null when mapping a null Dependent list")
        void shouldReturnNullWhenMappingNullDependentList() {
            // Act
            List<DependentDO> result = mapper.fromDependent((List<Dependent>) null);
            
            // Assert
            assertNull(result, "The result should be null when mapping a null list of Dependents");
        }
        
        @Test
        @DisplayName("Should return an empty list when mapping an empty Dependent list")
        void shouldReturnEmptyListWhenMappingEmptyDependentList() {
            // Arrange
            List<Dependent> emptyList = Collections.emptyList();
            
            // Act
            List<DependentDO> result = mapper.fromDependent(emptyList);
            
            // Assert
            assertNotNull(result, "The result should not be null when mapping an empty list");
            assertTrue(result.isEmpty(), "The result should be empty when mapping an empty list");
        }
    }
    
    @Nested
    @DisplayName("Tests for mapping a single DependentDO to Dependent")
    class SingleDependentDOToDependentTests {
        
        @Test
        @DisplayName("Should correctly map a DependentDO with all fields to Dependent")
        void shouldCorrectlyMapDependentDOWithAllFieldsToDependent() {
            // Arrange
            DependentDO dependentDO = createTestDependentDO("123456");
            
            // Act
            Dependent result = mapper.fromDependentDO(dependentDO);
            
            // Assert
            assertNotNull(result, "The mapped Dependent should not be null");
            assertEquals(dependentDO.getBenefitMemberId(), result.getBenefitMemberId(), 
                    "BenefitMemberId should be mapped correctly");
            assertEquals(dependentDO.getVersion(), result.getVersion(), 
                    "Version should be mapped correctly");
            assertEquals(dependentDO.getDependentProfile().getNationalId(), 
                    result.getDependentProfile().getNationalId(), 
                    "NationalId should be mapped correctly");
        }
        
        @Test
        @DisplayName("Should return null when mapping a null DependentDO")
        void shouldReturnNullWhenMappingNullDependentDO() {
            // Act
            Dependent result = mapper.fromDependentDO((DependentDO) null);
            
            // Assert
            assertNull(result, "The result should be null when mapping a null DependentDO");
        }
        
        @Test
        @DisplayName("Should map null fields in DependentDO to null in Dependent")
        void shouldMapNullFieldsInDependentDOToNullInDependent() {
            // Arrange
            DependentDO dependentDO = new DependentDO();
            dependentDO.setBenefitMemberId("123456");
            // Deliberately leave other fields null
            
            // Act
            Dependent result = mapper.fromDependentDO(dependentDO);
            
            // Assert
            assertNotNull(result, "The mapped Dependent should not be null");
            assertEquals(dependentDO.getBenefitMemberId(), result.getBenefitMemberId(), 
                    "BenefitMemberId should be mapped correctly");
            assertNull(result.getDependentProfile(), 
                    "DependentProfile should be null when source is null");
            assertNull(result.getLifeStyle(), 
                    "LifeStyle should be null when source is null");
            assertNull(result.getCustodian(), 
                    "Custodian should be null when source is null");
        }
    }
    
    @Nested
    @DisplayName("Tests for mapping a list of DependentDOs to Dependents")
    class DependentDOListToDependentListTests {
        
        @Test
        @DisplayName("Should correctly map a list of DependentDOs to a list of Dependents")
        void shouldCorrectlyMapDependentDOListToDependentList() {
            // Arrange
            List<DependentDO> dependentDOList = Arrays.asList(
                    createTestDependentDO("123456"),
                    createTestDependentDO("654321")
            );
            
            // Act
            List<Dependent> result = mapper.fromDependentDO(dependentDOList);
            
            // Assert
            assertNotNull(result, "The mapped list should not be null");
            assertEquals(dependentDOList.size(), result.size(), 
                    "The mapped list should have the same size as the source list");
            
            for (int i = 0; i < dependentDOList.size(); i++) {
                assertEquals(dependentDOList.get(i).getBenefitMemberId(), result.get(i).getBenefitMemberId(), 
                        "Each BenefitMemberId should be mapped correctly");
            }
        }
        
        @Test
        @DisplayName("Should return null when mapping a null DependentDO list")
        void shouldReturnNullWhenMappingNullDependentDOList() {
            // Act
            List<Dependent> result = mapper.fromDependentDO((List<DependentDO>) null);
            
            // Assert
            assertNull(result, "The result should be null when mapping a null list of DependentDOs");
        }
        
        @Test
        @DisplayName("Should return an empty list when mapping an empty DependentDO list")
        void shouldReturnEmptyListWhenMappingEmptyDependentDOList() {
            // Arrange
            List<DependentDO> emptyList = Collections.emptyList();
            
            // Act
            List<Dependent> result = mapper.fromDependentDO(emptyList);
            
            // Assert
            assertNotNull(result, "The result should not be null when mapping an empty list");
            assertTrue(result.isEmpty(), "The result should be empty when mapping an empty list");
        }
    }
    
    @Nested
    @DisplayName("Tests for patch functionality")
    class PatchFunctionalityTests {
        
        @Test
        @DisplayName("Should correctly apply changes from Dependent to DependentDO")
        void shouldCorrectlyApplyChangesFromDependentToDependentDO() {
            // Arrange
            DependentDO currentRecord = createTestDependentDO("123456");
            currentRecord.getDependentProfile().setNationalId("11111");
            
            Dependent newRecord = createTestDependent("123456");
            newRecord.getDependentProfile().setNationalId("22222");
            
            // Act
            DependentDO result = mapper.patchDependent(currentRecord, newRecord);
            
            // Assert
            assertSame(currentRecord, result, 
                    "The patch method should modify and return the target object");
            assertEquals(newRecord.getDependentProfile().getNationalId(), 
                    result.getDependentProfile().getNationalId(), 
                    "The NationalId should be updated with the value from the newRecord");
        }
        
        @Test
        @DisplayName("Should return original DependentDO when patching with null Dependent")
        void shouldReturnOriginalDependentDOWhenPatchingWithNullDependent() {
            // Arrange
            DependentDO currentRecord = createTestDependentDO("123456");
            String originalNationalId = currentRecord.getDependentProfile().getNationalId();
            
            // Act
            DependentDO result = mapper.patchDependent(currentRecord, null);
            
            // Assert
            assertSame(currentRecord, result, 
                    "The patch method should return the unchanged target object when source is null");
            assertEquals(originalNationalId, result.getDependentProfile().getNationalId(), 
                    "The NationalId should remain unchanged when patching with null");
        }
        
        @Test
        @DisplayName("Should ignore null fields in source when patching")
        void shouldIgnoreNullFieldsInSourceWhenPatching() {
            // Arrange
            DependentDO currentRecord = createTestDependentDO("123456");
            String originalNationalId = currentRecord.getDependentProfile().getNationalId();
            
            Dependent newRecord = new Dependent();
            newRecord.setBenefitMemberId("123456");
            // Deliberately leave DependentProfile null
            
            // Act
            DependentDO result = mapper.patchDependent(currentRecord, newRecord);
            
            // Assert
            assertSame(currentRecord, result, 
                    "The patch method should modify and return the target object");
            assertEquals(originalNationalId, result.getDependentProfile().getNationalId(), 
                    "The NationalId should remain unchanged when patching with null DependentProfile");
            assertEquals(newRecord.getBenefitMemberId(), result.getBenefitMemberId(), 
                    "The BenefitMemberId should be updated even though other fields are null");
        }
    }
    
    /**
     * Helper method to create a test Dependent instance with essential fields populated
     */
    private Dependent createTestDependent(String benefitMemberId) {
        Dependent dependent = new Dependent();
        dependent.setBenefitMemberId(benefitMemberId);
        
        // Set audit fields
        LocalDateTime now = LocalDateTime.now();
        dependent.setCreatedAt(now.toString()); // Convert LocalDateTime to String
        dependent.setCreatedBy("TestUser");
        dependent.setLastModifiedAt(now.toString());
        dependent.setLastModifiedBy("TestUser");
        dependent.setVersion(1);
        
        // Set up profile
        DependentProfile profile = new DependentProfile();
        profile.setFirstName("Test");
        profile.setLastName("User");
        profile.setNationalId("123-45-6789");
        
        // Set up address
        DependentAddress address = new DependentAddress();
        address.setCity("Test City");
        address.setStateName("TS");
        address.setCountry("Test Country");
        address.setZip("12345");
        profile.setAddress(Collections.singletonList(address));
        
        // Set up contacts
        Contact contact = new Contact();
        contact.setPhoneNumber("123-456-7890");
        contact.setEmailId("test@example.com");
        profile.setContacts(contact);
        
        dependent.setDependentProfile(profile);
        
        return dependent;
    }
    
    /**
     * Helper method to create a test DependentDO instance with essential fields populated
     */
    private DependentDO createTestDependentDO(String benefitMemberId) {
        DependentDO dependentDO = new DependentDO();
        dependentDO.setId("test-id-" + benefitMemberId);
        dependentDO.setBenefitMemberId(benefitMemberId);
        dependentDO.set_eTag("etag123");
        dependentDO.setActive(true);
        
        // Set audit fields
        LocalDateTime now = LocalDateTime.now();
        dependentDO.setCreatedAt(now.toString());
        dependentDO.setCreatedBy("TestUser");
        dependentDO.setLastModifiedAt(now.toString());
        dependentDO.setLastModifiedBy("TestUser");
        dependentDO.setVersion(1);
        
        // Set up profile
        DependentProfile profile = new DependentProfile();
        profile.setFirstName("Test");
        profile.setLastName("User");
        profile.setNationalId("123-45-6789");
        
        // Set up address
        DependentAddress address = new DependentAddress();
        address.setCity("Test City");
        address.setStateName("TS");
        address.setCountry("Test Country");
        address.setZip("12345");
        profile.setAddress(Collections.singletonList(address));
        
        // Set up contacts
        Contact contact = new Contact();
        contact.setPhoneNumber("123-456-7890");
        contact.setEmailId("test@example.com");
        profile.setContacts(contact);
        
        dependentDO.setDependentProfile(profile);
        
        return dependentDO;
    }
}