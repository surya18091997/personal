package com.walmart.bp.dependent.api.services.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;
import com.azure.cosmos.util.CosmosPagedFlux;
import com.walmart.bp.dependent.api.exceptions.SequenceGenerationException;
import com.walmart.bp.dependent.api.models.SequenceDO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Unit tests for {@link SequenceGeneratorServiceImpl}
 * 
 * Tests cover all methods of the service with various scenarios to ensure
 * comprehensive code coverage.
 */
@ExtendWith(MockitoExtension.class)
public class SequenceGeneratorServiceImplTest {

    @Mock
    private CosmosAsyncContainer mockSequenceContainer;
    
    @Mock
    private CosmosAsyncClient mockCosmosClient;
    
    @Mock
    private CosmosAsyncDatabase mockDatabase;
    
    @Mock
    private RetryTemplate mockRetryTemplate;
    
    @InjectMocks
    private SequenceGeneratorServiceImpl sequenceGeneratorService;
    
    // Constants for testing
    private static final String TEST_SEQUENCE_NAME = "dependent";
    private static final String TEST_SEQUENCE_TYPE = "memberId";
    
    @Mock
    private CosmosPagedFlux<SequenceDO> mockPagedFlux;
    
    @BeforeEach
    void setUp() {
        // Setup mocks for database and container
        when(mockCosmosClient.getDatabase(anyString())).thenReturn(mockDatabase);
        when(mockDatabase.getContainer(anyString())).thenReturn(mockSequenceContainer);
        
        // Initialize service with mock container and test sequence name
        ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceContainer", mockSequenceContainer);
        ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceName", TEST_SEQUENCE_NAME);
        
        // Initialize cache field
        Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();
        ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceIdCache", sequenceIdCache);
        
        // Call init method to ensure proper initialization
        sequenceGeneratorService.init();
    }

    /**
     * Tests for generateUniqueMemberId method
     */
    @Nested
    @DisplayName("Generate Unique Member ID Tests")
    class GenerateUniqueMemberIdTests {
        
        @Test
        @DisplayName("Should generate unique member ID with retry template")
        void shouldGenerateUniqueMemberIdWithRetryTemplate() {
            // Setup mock patch response
            SequenceDO resultSequence = new SequenceDO();
            resultSequence.setId(TEST_SEQUENCE_TYPE);
            resultSequence.setSequenceName(TEST_SEQUENCE_NAME);
            resultSequence.setValue(1001L);
            
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> mockResponse = mock(CosmosItemResponse.class);
            when(mockResponse.getItem()).thenReturn(resultSequence);

            // Setup mock feed response
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup mock paged flux with proper byPage() behavior
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class), 
                    any(CosmosQueryRequestOptions.class), 
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);

            // Mock createItem operation to return a valid response
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> createResponse = mock(CosmosItemResponse.class);
            SequenceDO createdSequence = new SequenceDO();
            createdSequence.setId(TEST_SEQUENCE_TYPE);
            createdSequence.setValue(1000L);
            when(createResponse.getItem()).thenReturn(createdSequence);
            
            when(mockSequenceContainer.createItem(
                any(SequenceDO.class),
                any(PartitionKey.class),
                any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.just(createResponse));
            
            // Mock retry template to invoke its callback directly
            doAnswer(invocation -> {
                RetryCallback<String, SequenceGenerationException> callback = invocation.getArgument(0);
                return callback.doWithRetry(mock(RetryContext.class));
            }).when(mockRetryTemplate).execute(any());
            
            // Mock cached document ID
            Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();
            sequenceIdCache.put(TEST_SEQUENCE_TYPE, TEST_SEQUENCE_TYPE);
            ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceIdCache", sequenceIdCache);
            
            // Mock patch operation
            when(mockSequenceContainer.patchItem(
                    anyString(),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(Mono.just(mockResponse));
            
            // Call the method
            String result = sequenceGeneratorService.generateUniqueMemberId("1");
            
            // Verify
            assertEquals("1001", result);
            verify(mockSequenceContainer).patchItem(
                    anyString(),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            );
        }
        
        @Test
        @DisplayName("Should use current ID as seed when numeric")
        void shouldUseCurrentIdAsSeedWhenNumeric() {
            // Setup for getOrCreateSequenceDocumentId
            String currentMemberId = "5000";
            
            // Setup mock query response for first call (no sequence exists yet)
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> emptyPagedFlux = mock(CosmosPagedFlux.class);
            
            // Setup Flux.byPage() behavior for empty results
            when(emptyPagedFlux.byPage()).thenReturn(Flux.empty());
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(emptyPagedFlux);
            
            // Setup for sequence creation
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> createResponse = mock(CosmosItemResponse.class);
            SequenceDO createdSequence = new SequenceDO();
            createdSequence.setId(TEST_SEQUENCE_TYPE);
            createdSequence.setValue(5000L); // Should use current ID as seed
            when(createResponse.getItem()).thenReturn(createdSequence);
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.just(createResponse));
            
            // Mock patch response after creation
            SequenceDO patchedSequence = new SequenceDO();
            patchedSequence.setId(TEST_SEQUENCE_TYPE);
            patchedSequence.setValue(5001L);
            
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> patchResponse = mock(CosmosItemResponse.class);
            when(patchResponse.getItem()).thenReturn(patchedSequence);
            
            when(mockSequenceContainer.patchItem(
                    anyString(),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(Mono.just(patchResponse));
            
            // Mock retry template
            doAnswer(invocation -> {
                RetryCallback<String, SequenceGenerationException> callback = invocation.getArgument(0);
                return callback.doWithRetry(mock(RetryContext.class));
            }).when(mockRetryTemplate).execute(any());
            
            // Call the method with numeric ID
            String result = sequenceGeneratorService.generateUniqueMemberId(currentMemberId);
            
            // Verify
            assertEquals("5001", result);
            
            // Verify createItem was called with the seed value
            ArgumentCaptor<SequenceDO> sequenceCaptor = ArgumentCaptor.forClass(SequenceDO.class);
            verify(mockSequenceContainer).createItem(
                    sequenceCaptor.capture(),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            );
            
            SequenceDO capturedSequence = sequenceCaptor.getValue();
            assertEquals(5000L, capturedSequence.getValue());
        }
        
        @Test
        @DisplayName("Should handle null response from patch operation")
        void shouldHandleNullResponseFromPatchOperation() {
            // Mock cached document ID
            Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();
            sequenceIdCache.put(TEST_SEQUENCE_TYPE, TEST_SEQUENCE_TYPE);
            ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceIdCache", sequenceIdCache);

            // Setup mock query response for first call (no sequence exists yet)
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> emptyPagedFlux = mock(CosmosPagedFlux.class);
            
            // Setup Flux.byPage() behavior for empty results
            when(emptyPagedFlux.byPage()).thenReturn(Flux.empty());
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(emptyPagedFlux);
            
            // Setup for sequence creation
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> createResponse = mock(CosmosItemResponse.class);
            SequenceDO createdSequence = new SequenceDO();
            createdSequence.setId(TEST_SEQUENCE_TYPE);
            createdSequence.setValue(5000L); // Should use current ID as seed
            when(createResponse.getItem()).thenReturn(createdSequence);
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.just(createResponse));
            
            // Mock patch response after creation
            SequenceDO patchedSequence = new SequenceDO();
            patchedSequence.setId(TEST_SEQUENCE_TYPE);
            patchedSequence.setValue(5001L);
            
            // Mock patch operation returning null response
            when(mockSequenceContainer.patchItem(
                    anyString(),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(Mono.empty());
            
            // Mock retry template to capture exception
            doAnswer(invocation -> {
                RetryCallback<String, SequenceGenerationException> callback = invocation.getArgument(0);
                try {
                    return callback.doWithRetry(mock(RetryContext.class));
                } catch (SequenceGenerationException e) {
                    throw e;
                }
            }).when(mockRetryTemplate).execute(any());
            
            // Verify exception is thrown
            SequenceGenerationException exception = assertThrows(
                SequenceGenerationException.class,
                () -> sequenceGeneratorService.generateUniqueMemberId(null)
            );
            
            // Verify exception message
            assertTrue(exception.getMessage().contains("Failed to retrieve sequence value after patch"));
        }
        
        @Test
        @DisplayName("Should handle exception during sequence generation")
        void shouldHandleExceptionDuringSequenceGeneration() {
            // Mock cached document ID
            Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();
            sequenceIdCache.put(TEST_SEQUENCE_TYPE, TEST_SEQUENCE_TYPE);
            ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceIdCache", sequenceIdCache);

            // Setup mock query response for first call (no sequence exists yet)
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> emptyPagedFlux = mock(CosmosPagedFlux.class);
            
            // Setup Flux.byPage() behavior for empty results
            when(emptyPagedFlux.byPage()).thenReturn(Flux.empty());
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(emptyPagedFlux);
            
            // Setup for sequence creation
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> createResponse = mock(CosmosItemResponse.class);
            SequenceDO createdSequence = new SequenceDO();
            createdSequence.setId(TEST_SEQUENCE_TYPE);
            createdSequence.setValue(5000L); // Should use current ID as seed
            when(createResponse.getItem()).thenReturn(createdSequence);
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.just(createResponse));
            
            // Mock patch operation to throw exception
            RuntimeException testException = new RuntimeException("Test exception");
            when(mockSequenceContainer.patchItem(
                    anyString(),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(Mono.error(testException));
            
            // Mock retry template to capture the exception
            RetryContext mockRetryContext = mock(RetryContext.class);
            when(mockRetryContext.getRetryCount()).thenReturn(3);
            
            doAnswer(invocation -> {
                RetryCallback<String, SequenceGenerationException> callback = invocation.getArgument(0);
                try {
                    return callback.doWithRetry(mockRetryContext);
                } catch (SequenceGenerationException e) {
                    throw e;
                }
            }).when(mockRetryTemplate).execute(any());
            
            // Verify exception is thrown with retry count info
            SequenceGenerationException exception = assertThrows(
                SequenceGenerationException.class,
                () -> sequenceGeneratorService.generateUniqueMemberId(null)
            );
            
            // Verify exception message includes retry count
            assertTrue(exception.getMessage().contains("after 3 retries"));
            assertEquals(testException, exception.getCause());
        }
    }
    
    /**
     * Tests for getCurrentSequenceValue method
     */
    @Nested
    @DisplayName("Get Current Sequence Value Tests")
    class GetCurrentSequenceValueTests {
        
        @Test
        @DisplayName("Should return current sequence value when sequence exists")
        void shouldReturnCurrentSequenceValueWhenSequenceExists() {
            // Setup mock sequence response for query
            SequenceDO existingSequence = new SequenceDO();
            existingSequence.setId(TEST_SEQUENCE_TYPE);
            existingSequence.setSequenceName(TEST_SEQUENCE_NAME);
            existingSequence.setValue(1000L);
            
            // Setup mock flux that will return the sequence
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.singletonList(existingSequence));
            
            // Setup mock paged flux
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);
            
            // Call the method
            Long result = sequenceGeneratorService.getCurrentSequenceValue(TEST_SEQUENCE_TYPE);
            
            // Verify
            assertEquals(1000L, result);
            verify(mockSequenceContainer).queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            );
        }
        
        @Test
        @DisplayName("Should return null when sequence doesn't exist")
        void shouldReturnNullWhenSequenceDoesntExist() {
            // Setup empty query response
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup mock paged flux with empty results
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);
            
            // Call the method
            Long result = sequenceGeneratorService.getCurrentSequenceValue(TEST_SEQUENCE_TYPE);
            
            // Verify
            assertNull(result);
            verify(mockSequenceContainer).queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            );
        }
        
        @Test
        @DisplayName("Should handle cosmos exception when getting current value")
        void shouldHandleCosmosExceptionWhenGettingCurrentValue() {
            // Setup exception to be thrown
            CosmosException cosmosException = mock(CosmosException.class);
            when(cosmosException.getMessage()).thenReturn("Test cosmos exception");
            
            // Setup mock paged flux that throws exception
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> errorPagedFlux = mock(CosmosPagedFlux.class);
            when(errorPagedFlux.byPage()).thenReturn(Flux.error(cosmosException));
            
            // Setup query to throw exception
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(errorPagedFlux);
            
            // Verify exception is thrown
            SequenceGenerationException exception = assertThrows(
                SequenceGenerationException.class,
                () -> sequenceGeneratorService.getCurrentSequenceValue(TEST_SEQUENCE_TYPE)
            );
            
            // Verify exception message
            assertTrue(exception.getMessage().contains("Error retrieving sequence value"));
            assertEquals(cosmosException, exception.getCause());
        }
    }
    
    /**
     * Tests for setSequenceValue method
     */
    @Nested
    @DisplayName("Set Sequence Value Tests")
    class SetSequenceValueTests {
        
        @Test
        @DisplayName("Should update sequence value when sequence exists")
        void shouldUpdateSequenceValueWhenSequenceExists() {
            // Setup mock sequence response for query
            SequenceDO existingSequence = new SequenceDO();
            existingSequence.setId(TEST_SEQUENCE_TYPE);
            existingSequence.setSequenceName(TEST_SEQUENCE_NAME);
            existingSequence.setValue(1000L);
            
            // Setup mock flux that will return the sequence
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.singletonList(existingSequence));
            
            // Setup mock paged flux
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);
            
            // Mock patch response
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> patchResponse = mock(CosmosItemResponse.class);
            SequenceDO patchedSequence = new SequenceDO();
            patchedSequence.setId(TEST_SEQUENCE_TYPE);
            patchedSequence.setValue(5000L);
            
            when(mockSequenceContainer.patchItem(
                    eq(TEST_SEQUENCE_TYPE),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(Mono.just(patchResponse));
            
            // Call the method
            sequenceGeneratorService.setSequenceValue(TEST_SEQUENCE_TYPE, 5000L);
            
            // Verify patchItem was called
            verify(mockSequenceContainer).patchItem(
                    eq(TEST_SEQUENCE_TYPE),
                    any(PartitionKey.class),
                    any(CosmosPatchOperations.class),
                    any(CosmosPatchItemRequestOptions.class),
                    eq(SequenceDO.class)
            );
        }
        
        @Test
        @DisplayName("Should create sequence with value when sequence doesn't exist")
        void shouldCreateSequenceWithValueWhenSequenceDoesntExist() {
            // Setup empty query response
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup mock paged flux with empty results
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);
            
            // Mock create response
            @SuppressWarnings("unchecked")
            CosmosItemResponse<SequenceDO> createResponse = mock(CosmosItemResponse.class);
            SequenceDO createdSequence = new SequenceDO();
            createdSequence.setId(TEST_SEQUENCE_TYPE);
            createdSequence.setValue(5000L);
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.just(createResponse));
            
            // Call the method
            sequenceGeneratorService.setSequenceValue(TEST_SEQUENCE_TYPE, 5000L);
            
            // Verify createItem was called with correct values
            ArgumentCaptor<SequenceDO> sequenceCaptor = ArgumentCaptor.forClass(SequenceDO.class);
            verify(mockSequenceContainer).createItem(
                    sequenceCaptor.capture(),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            );
            
            SequenceDO capturedSequence = sequenceCaptor.getValue();
            assertEquals(TEST_SEQUENCE_TYPE, capturedSequence.getId());
            assertEquals(TEST_SEQUENCE_NAME, capturedSequence.getSequenceName());
            assertEquals(5000L, capturedSequence.getValue());
            
            // Verify cache was updated
            @SuppressWarnings("unchecked")
            Map<String, String> sequenceIdCache = (Map<String, String>) ReflectionTestUtils.getField(
                    sequenceGeneratorService, "sequenceIdCache");
            assertEquals(TEST_SEQUENCE_TYPE, sequenceIdCache.get(TEST_SEQUENCE_TYPE));
        }
        
        @Test
        @DisplayName("Should handle cosmos exception when setting sequence value")
        void shouldHandleCosmosExceptionWhenSettingSequenceValue() {
            // Setup empty query response
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> mockFeedResponse = mock(FeedResponse.class);
            when(mockFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup mock paged flux with empty results
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> mockPagedFlux = mock(CosmosPagedFlux.class);
            when(mockPagedFlux.byPage()).thenReturn(Flux.just(mockFeedResponse));
            
            // Setup query execution
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(mockPagedFlux);
            
            // Setup exception on create
            CosmosException cosmosException = mock(CosmosException.class);
            when(cosmosException.getMessage()).thenReturn("Test cosmos exception");
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.error(cosmosException));
            
            // Verify exception is thrown
            SequenceGenerationException exception = assertThrows(
                SequenceGenerationException.class,
                () -> sequenceGeneratorService.setSequenceValue(TEST_SEQUENCE_TYPE, 5000L)
            );
            
            // Verify exception message
            assertTrue(exception.getMessage().contains("Error setting sequence value"));
            assertEquals(cosmosException, exception.getCause());
        }
    }
    
    /**
     * Tests for getOrCreateSequenceDocumentId private method
     */
    @Nested
    @DisplayName("Get Or Create Sequence Document ID Tests")
    class GetOrCreateSequenceDocumentIdTests {
        
        @Test
        @DisplayName("Should return cached ID when available")
        void shouldReturnCachedIdWhenAvailable() {
            // Setup cache with known value
            Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();
            sequenceIdCache.put(TEST_SEQUENCE_TYPE, "cached-id");
            ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceIdCache", sequenceIdCache);
            
            // Call the private method via reflection
            String result = (String) ReflectionTestUtils.invokeMethod(
                    sequenceGeneratorService,
                    "getOrCreateSequenceDocumentId",
                    TEST_SEQUENCE_TYPE,
                    null
            );
            
            // Verify
            assertEquals("cached-id", result);
            
            // Verify no database interactions
            verifyNoInteractions(mockSequenceContainer);
        }
        
        @Test
        @DisplayName("Should handle conflict when creating sequence")
        void shouldHandleConflictWhenCreatingSequence() {
            // First query returns no results
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> emptyFeedResponse = mock(FeedResponse.class);
            when(emptyFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup empty mock paged flux for first query
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> emptyPagedFlux = mock(CosmosPagedFlux.class);
            when(emptyPagedFlux.byPage()).thenReturn(Flux.just(emptyFeedResponse));
            
            // Second query returns existing sequence
            SequenceDO existingSequence = new SequenceDO();
            existingSequence.setId(TEST_SEQUENCE_TYPE);
            existingSequence.setSequenceName(TEST_SEQUENCE_NAME);
            existingSequence.setValue(1000L);
            
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> foundFeedResponse = mock(FeedResponse.class);
            when(foundFeedResponse.getResults()).thenReturn(Collections.singletonList(existingSequence));
            
            // Setup mock paged flux for second query
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> foundPagedFlux = mock(CosmosPagedFlux.class);
            when(foundPagedFlux.byPage()).thenReturn(Flux.just(foundFeedResponse));
            
            // Set up mock to return empty first, then the existing sequence on second call
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(emptyPagedFlux, foundPagedFlux);
            
            // Setup creation to fail with conflict (409)
            CosmosException conflictException = mock(CosmosException.class);
            when(conflictException.getStatusCode()).thenReturn(409);
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.error(conflictException));
            
            // Call the private method via reflection
            String result = (String) ReflectionTestUtils.invokeMethod(
                    sequenceGeneratorService,
                    "getOrCreateSequenceDocumentId",
                    TEST_SEQUENCE_TYPE,
                    null
            );
            
            // Verify we got the ID from the found sequence
            assertEquals(TEST_SEQUENCE_TYPE, result);
            
            // Verify cache was updated
            @SuppressWarnings("unchecked")
            Map<String, String> sequenceIdCache = (Map<String, String>) ReflectionTestUtils.getField(
                    sequenceGeneratorService, "sequenceIdCache");
            assertEquals(TEST_SEQUENCE_TYPE, sequenceIdCache.get(TEST_SEQUENCE_TYPE));
        }
        
        @Test
        @DisplayName("Should propagate non-conflict cosmos exceptions")
        void shouldPropagateNonConflictCosmosExceptions() {
            // Setup query to return empty
            @SuppressWarnings("unchecked")
            FeedResponse<SequenceDO> emptyFeedResponse = mock(FeedResponse.class);
            when(emptyFeedResponse.getResults()).thenReturn(Collections.emptyList());
            
            // Setup empty mock paged flux
            @SuppressWarnings("unchecked")
            CosmosPagedFlux<SequenceDO> emptyPagedFlux = mock(CosmosPagedFlux.class);
            when(emptyPagedFlux.byPage()).thenReturn(Flux.just(emptyFeedResponse));
            
            when(mockSequenceContainer.queryItems(
                    any(SqlQuerySpec.class),
                    any(CosmosQueryRequestOptions.class),
                    eq(SequenceDO.class)
            )).thenReturn(emptyPagedFlux);
            
            // Setup creation to fail with non-conflict error
            CosmosException internalServerError = mock(CosmosException.class);
            when(internalServerError.getStatusCode()).thenReturn(500);
            when(internalServerError.getMessage()).thenReturn("Internal Server Error");
            
            when(mockSequenceContainer.createItem(
                    any(SequenceDO.class),
                    any(PartitionKey.class),
                    any(CosmosItemRequestOptions.class)
            )).thenReturn(Mono.error(internalServerError));
            
            // Verify exception is thrown
            SequenceGenerationException exception = assertThrows(
                SequenceGenerationException.class,
                () -> ReflectionTestUtils.invokeMethod(
                        sequenceGeneratorService,
                        "getOrCreateSequenceDocumentId",
                        TEST_SEQUENCE_TYPE,
                        null
                )
            );
            
            // Verify exception message
            assertTrue(exception.getMessage().contains("Error creating sequence"));
            assertEquals(internalServerError, exception.getCause());
        }
    }
    
    /**
     * Tests for getLongSeedValue static utility method
     */
    @Nested
    @DisplayName("Get Long Seed Value Tests")
    class GetLongSeedValueTests {
        
        @Test
        @DisplayName("Should parse numeric string to Long")
        void shouldParseNumericStringToLong() {
            Long result = ReflectionTestUtils.invokeMethod(
                    SequenceGeneratorServiceImpl.class,
                    "getLongSeedValue",
                    "12345",
                    null
            );
            
            assertEquals(12345L, result);
        }
        
        @Test
        @DisplayName("Should return null for non-numeric string")
        void shouldReturnNullForNonNumericString() {
            Long seedValue = null;
            Long result = ReflectionTestUtils.invokeMethod(
                    SequenceGeneratorServiceImpl.class,
                    "getLongSeedValue",
                    "abc",
                    seedValue
            );
            
            assertNull(result);
        }
        
        @Test
        @DisplayName("Should return null for null string")
        void shouldReturnNullForNullString() {
            Long seedValue = null;
            Long result = ReflectionTestUtils.invokeMethod(
                    SequenceGeneratorServiceImpl.class,
                    "getLongSeedValue",
                    null,
                    seedValue
            );
            
            assertNull(result);
        }
    }
    
    /**
     * Tests for PostConstruct init method
     */
    @Nested
    @DisplayName("Init Method Tests")
    class InitMethodTests {
        
        @Test
        @DisplayName("Should initialize sequence container")
        void shouldInitializeSequenceContainer() {
            // Setup mocks
            CosmosAsyncDatabase mockDb = mock(CosmosAsyncDatabase.class);
            CosmosAsyncContainer mockContainer = mock(CosmosAsyncContainer.class);
            
            when(mockCosmosClient.getDatabase("benefits-platform")).thenReturn(mockDb);
            when(mockDb.getContainer("sequence-container")).thenReturn(mockContainer);
            
            // Clear existing field value
            ReflectionTestUtils.setField(sequenceGeneratorService, "sequenceContainer", null);
            
            // Call init method
            sequenceGeneratorService.init();
            
            // Verify the container was set
            CosmosAsyncContainer container = (CosmosAsyncContainer) ReflectionTestUtils.getField(
                    sequenceGeneratorService, "sequenceContainer");
            
            assertNotNull(container);
            assertEquals(mockContainer, container);
        }
    }
}