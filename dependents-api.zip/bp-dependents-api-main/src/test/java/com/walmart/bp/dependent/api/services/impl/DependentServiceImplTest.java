package com.walmart.bp.dependent.api.services.impl;

import com.azure.cosmos.CosmosException;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentAddress;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Contact;
import com.walmart.bp.dependent.api.entity.FPEFld;
import com.walmart.bp.dependent.api.entity.FPERecord;
import com.walmart.bp.dependent.api.entity.Fld;
import com.walmart.bp.dependent.api.entity.Record;
import com.walmart.bp.dependent.api.common.util.DependentConstant;
import com.walmart.bp.dependent.api.exceptions.ResourceAlreadyExistsException;
import com.walmart.bp.dependent.api.exceptions.ResourceNotFoundException;
import com.walmart.bp.dependent.api.mappers.DependentDBObjectMapper;
import com.walmart.bp.dependent.api.models.DependentDO;
import com.walmart.bp.dependent.api.repositories.DependentRepository;
import com.walmart.bp.dependent.api.services.SequnceGeneratorService;
import com.walmart.bp.dependent.api.util.CryptoUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.retry.support.RetryTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DependentServiceImplTest {

    @Mock
    private CryptoUtils cryptoUtils;

    @Mock
    private DependentRepository dependentRepository;

    @Mock
    private SequnceGeneratorService sequnceGeneratorService;

    @Mock
    private RetryTemplate retryTemplate;

    @InjectMocks
    private DependentServiceImpl dependentService;

    @Captor
    private ArgumentCaptor<DependentDO> dependentDOCaptor;
    private final DependentDBObjectMapper mapper = DependentDBObjectMapper.INSTANCE;

    private DependentDO testDependentDO;
    private Dependent testDependent;
    private final String BENEFIT_MEMBER_ID = "123456";

    @BeforeEach
    void setUp() {
        // Setup test data here
        testDependentDO = createTestDependentDO(BENEFIT_MEMBER_ID);
        testDependent = DependentDBObjectMapper.INSTANCE.fromDependentDO(testDependentDO);
    }

    /**
     * Helper method to create a test DependentDO instance
     */
    private DependentDO createTestDependentDO(String benefitMemberId) {
        DependentDO dependentDO = new DependentDO();
        dependentDO.setId("test-id");
        dependentDO.setBenefitMemberId(benefitMemberId);
        dependentDO.set_eTag("etag123");
        dependentDO.setVersion(1);
        dependentDO.setActive(true);
        DependentAddress dependentAddress = new DependentAddress();
        dependentAddress.setAddressId("1");
        dependentAddress.setCity("Test City");
        dependentAddress.setZip("Test Zip");
        dependentAddress.setCountry("Test Country");
        Contact contact = new Contact();
        contact.setPhoneNumber("1234567890");
        DependentProfile dependentProfile = new DependentProfile();
        dependentProfile.setContacts(contact);
        dependentProfile.setAddress(Collections.singletonList(dependentAddress));
        dependentProfile.setNationalId("12345");
        dependentDO.setDependentProfile(dependentProfile);


        // Add other required fields as needed
        return dependentDO;
    }

    /**
     * Helper method to mock the decryption process
     */
    private void mockDecryption() {
        when(cryptoUtils.getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT)))
                .thenReturn(Collections.emptyList()); // Simplify for now, can be enhanced later
    }

    /**
     * Helper method to mock the encryption process
     */
    private void mockEncryption(String benefitMemberId) {
        Record record = new Record();
        List<Fld> flds = new ArrayList<>();
        Fld fld = new Fld();
        fld.setId("city");
        fld.setVal("encryptedCity");
        flds.add(fld);
        fld = new Fld();
        fld.setId("ssn");
        fld.setVal("encryptedSsn");
        flds.add(fld);
        fld = new Fld();
        fld.setId("zip");
        fld.setVal("encryptedZip");
        flds.add(fld);
        fld = new Fld();
        fld.setId("phone");
        fld.setVal("encryptedPhone");
        flds.add(fld);
        record.setFlds(flds);
        record.setId(benefitMemberId + "-1");
        when(cryptoUtils.getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT)))
                .thenReturn(List.of(record)); // Simplify for now, can be enhanced later
    }

    @Nested
    @DisplayName("Tests for getDependentByBenefitMemberId method")
    class GetDependentByBenefitMemberIdTests {

        @Test
        @DisplayName("Should return dependent when found by benefit member ID")
        void shouldReturnDependentWhenFoundByBenefitMemberId() {
            // Arrange
            List<DependentDO> dependentDOList = Collections.singletonList(testDependentDO);
            when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                    .thenReturn(dependentDOList);
            mockDecryption();

            // Act
            DependentDO result = dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);

            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(),
                    "The returned dependent should have the requested benefit member ID");
            verify(dependentRepository).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT));
        }

        @Test
        @DisplayName("Should throw ResourceNotFoundException when dependent not found")
        void shouldThrowResourceNotFoundExceptionWhenDependentNotFound() {
            // Arrange
            when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                    .thenReturn(Collections.emptyList());

            // Act & Assert
            ResourceNotFoundException exception = assertThrows(
                    ResourceNotFoundException.class,
                    () -> dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID),
                    "Should throw ResourceNotFoundException when no dependent is found"
            );

            assertTrue(exception.getMessage().contains(BENEFIT_MEMBER_ID),
                    "Exception message should contain the benefit member ID");
            verify(dependentRepository).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
            verify(cryptoUtils, never()).getFPEEncryptDecryptRecords(any(), any());
        }

        @Test
        @DisplayName("Should decrypt sensitive fields when dependent found")
        void shouldDecryptSensitiveFieldsWhenDependentFound() {
            // Arrange
            List<DependentDO> dependentDOList = Collections.singletonList(testDependentDO);
            when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                    .thenReturn(dependentDOList);

            List<Record> records = new ArrayList<>();
            Record record = new Record();
            record.setId(BENEFIT_MEMBER_ID + "-1");
            List<Fld> fields = new ArrayList<>();
            fields.add(new Fld("city", "Decrypted City", "String"));
            fields.add(new Fld("zip", "12345", "String"));
            fields.add(new Fld("ssn", "123-45-6789", "String"));
            fields.add(new Fld("phone", "555-123-4567", "String"));
            record.setFlds(fields);
            records.add(record);

            when(cryptoUtils.getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT)))
                    .thenReturn(records);

            // Act
            DependentDO result = dependentService.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);

            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT));
        }
    }

    @Nested
    @DisplayName("Tests for getAllDependents method")
    class GetAllDependentsTests {

        @Test
        @DisplayName("Should return list of all dependents when present")
        void shouldReturnListOfAllDependentsWhenPresent() {
            // Arrange
            List<DependentDO> dependentDOList = new ArrayList<>();
            dependentDOList.add(testDependentDO);
            dependentDOList.add(createTestDependentDO("654321"));

            when(dependentRepository.getAllDependents()).thenReturn(Optional.of(dependentDOList));
            mockDecryption();

            // Act
            List<Dependent> result = dependentService.getAllDependents();

            // Assert
            assertNotNull(result, "The returned list should not be null");
            assertEquals(2, result.size(), "The returned list should contain all dependents");
            verify(dependentRepository).getAllDependents();
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT));
        }

        @Test
        @DisplayName("Should throw ResourceNotFoundException when no dependents are found")
        void shouldThrowResourceNotFoundExceptionWhenNoDependentsAreFound() {
            // Arrange
            when(dependentRepository.getAllDependents()).thenReturn(Optional.empty());

            // Act & Assert
            ResourceNotFoundException exception = assertThrows(
                    ResourceNotFoundException.class,
                    () -> dependentService.getAllDependents(),
                    "Should throw ResourceNotFoundException when no dependents are found"
            );

            assertEquals("No dependents found", exception.getMessage(),
                    "Exception message should indicate no dependents were found");
            verify(dependentRepository).getAllDependents();
            verify(cryptoUtils, never()).getFPEEncryptDecryptRecords(any(), any());
        }

        @Test
        @DisplayName("Should decrypt sensitive fields for all dependents")
        void shouldDecryptSensitiveFieldsForAllDependents() {
            // Arrange
            List<DependentDO> dependentDOList = new ArrayList<>();
            DependentDO dependent1 = testDependentDO;
            DependentDO dependent2 = createTestDependentDO("654321");
            dependentDOList.add(dependent1);
            dependentDOList.add(dependent2);

            when(dependentRepository.getAllDependents()).thenReturn(Optional.of(dependentDOList));

            List<Record> records = new ArrayList<>();
            // Setup records for decryption
            Record record1 = new Record();
            record1.setId(dependent1.getBenefitMemberId() + "-1");
            List<Fld> fields1 = new ArrayList<>();
            fields1.add(new Fld("city", "Decrypted City 1", "String"));
            fields1.add(new Fld("zip", "12345", "String"));
            record1.setFlds(fields1);
            records.add(record1);

            Record record2 = new Record();
            record2.setId(dependent2.getBenefitMemberId() + "-1");
            List<Fld> fields2 = new ArrayList<>();
            fields2.add(new Fld("city", "Decrypted City 2", "String"));
            fields2.add(new Fld("zip", "67890", "String"));
            record2.setFlds(fields2);
            records.add(record2);

            when(cryptoUtils.getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT)))
                    .thenReturn(records);

            // Act
            List<Dependent> result = dependentService.getAllDependents();

            // Assert
            assertNotNull(result, "The returned list should not be null");
            assertEquals(2, result.size(), "The returned list should contain all dependents");
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.DECRYPT));
        }
    }

    @Nested
    @DisplayName("Tests for upsertDependent method")
    class UpsertDependentTests {
        
        @Test
        @DisplayName("Should insert new dependent when no benefitMemberId provided")
        void shouldInsertNewDependentWhenNoBenefitMemberIdProvided() {
            // Arrange
            Dependent newDependent = new Dependent();
            newDependent.setBenefitMemberId("");  // No member ID to simulate new dependent
            DependentProfile profile = new DependentProfile();
            newDependent.setDependentProfile(profile);
            
            String generatedMemberId = "654321";
            DependentDO savedDependentDO = createTestDependentDO(generatedMemberId);
            savedDependentDO.setBenefitMemberId("");

            when(dependentRepository.findTopByOrderByBenefitMemberIdDesc())
                    .thenReturn(Collections.singletonList(testDependentDO));
            when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                    .thenReturn(generatedMemberId);

            mockEncryption(generatedMemberId);

            // Simulate retry behavior for retryTemplate
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            when(dependentRepository.insertStrict(any(DependentDO.class)))
                    .thenReturn(savedDependentDO);

            // Act
            Dependent result = dependentService.upsertDependent(savedDependentDO);

            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(generatedMemberId, result.getBenefitMemberId(),
                    "The returned dependent should have the generated member ID");
            verify(sequnceGeneratorService).generateUniqueMemberId(anyString());
            verify(dependentRepository).insertStrict(any(DependentDO.class));
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT));
        }

        @Test
        @DisplayName("Should insert new dependent when no benefitMemberId provided")
        void shouldThrowErrorOnInsertNewDependentOnFetchBenefitThrowsError() {
            // Arrange
            Dependent newDependent = new Dependent();
            newDependent.setBenefitMemberId("");  // No member ID to simulate new dependent
            DependentProfile profile = new DependentProfile();
            newDependent.setDependentProfile(profile);
            
            String generatedMemberId = "10000000";
            DependentDO savedDependentDO = createTestDependentDO(generatedMemberId);
            savedDependentDO.setBenefitMemberId("");

            when(dependentRepository.findTopByOrderByBenefitMemberIdDesc())
                    .thenThrow(RuntimeException.class);
            when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                    .thenReturn(generatedMemberId);

            mockEncryption(generatedMemberId);

            // Simulate retry behavior for retryTemplate
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            when(dependentRepository.insertStrict(any(DependentDO.class)))
                    .thenReturn(savedDependentDO);

            // Act
            Dependent result = dependentService.upsertDependent(savedDependentDO);

            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(generatedMemberId, result.getBenefitMemberId(),
                    "The returned dependent should have the generated member ID");
            verify(sequnceGeneratorService).generateUniqueMemberId(anyString());
            verify(dependentRepository).insertStrict(any(DependentDO.class));
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT));
        }

        @Test
        @DisplayName("Should throw IllegalArgumentException when dependent is null")
        void shouldThrowIllegalArgumentExceptionWhenDependentIsNull() {
            // Act & Assert
            IllegalArgumentException exception = assertThrows(
                    IllegalArgumentException.class,
                    () -> dependentService.upsertDependent(null),
                    "Should throw IllegalArgumentException when dependent is null"
            );

            assertEquals("Dependent cannot be null", exception.getMessage(),
                    "Exception message should indicate dependent cannot be null");
        }
        
        @Test
        @DisplayName("Should update existing dependent when benefitMemberId provided")
        void shouldUpdateExistingDependentWhenBenefitMemberIdProvided() {
            // Arrange
            String existingMemberId = BENEFIT_MEMBER_ID;
            Dependent existingDependent = testDependent;
            existingDependent.getBenefitMemberId(); // Ensure member ID is set
            
            DependentDO existingDependentDO = testDependentDO;
            DependentDO updatedDependentDO = createTestDependentDO(existingMemberId);
            updatedDependentDO.setVersion(existingDependentDO.getVersion() + 1);
            
            // Mock repository to return existing dependent when queried
            when(dependentRepository.getDependentByBenefitMemberId(existingMemberId))
                    .thenReturn(Collections.singletonList(existingDependentDO));
           mockDecryption();

           // Simulate retry behavior for retryTemplate
           doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            when(dependentRepository.save(any(DependentDO.class)))
                    .thenReturn(updatedDependentDO);
            
            // Act
            Dependent result = dependentService.upsertDependent(existingDependent);
            
            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(existingMemberId, result.getBenefitMemberId(), 
                    "The returned dependent should have the same member ID");
            verify(dependentRepository).getDependentByBenefitMemberId(existingMemberId);
            verify(dependentRepository).save(any(DependentDO.class));
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT));
        }

        @Test
        @DisplayName("Should update existing dependent when benefitMemberId provided")
        void shouldThrowResourceNotFoundOnEncryption() {
            // Arrange
            Dependent newDependent = new Dependent();
            newDependent.setBenefitMemberId("");  // No member ID to simulate new dependent
            DependentProfile profile = new DependentProfile();
            newDependent.setDependentProfile(profile);
            
            String generatedMemberId = "654321";
            DependentDO savedDependentDO = createTestDependentDO(generatedMemberId);
            savedDependentDO.setBenefitMemberId("");

            when(dependentRepository.findTopByOrderByBenefitMemberIdDesc())
                    .thenReturn(Collections.singletonList(testDependentDO));
            when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                    .thenReturn(generatedMemberId);

            when(cryptoUtils.getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT)))
                    .thenThrow(ResourceNotFoundException.class); 

            // Simulate retry behavior for retryTemplate
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            ResourceNotFoundException exception = assertThrows(
                        ResourceNotFoundException.class,
                        () -> dependentService.upsertDependent(savedDependentDO),
                        "Should throw IllegalArgumentException for Encrpytion"
                );

            verify(dependentRepository, never()).insertStrict(any(DependentDO.class));
            verify(cryptoUtils).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT));
        }

        @Test
        @DisplayName("Should update existing dependent when benefitMemberId provided")
        void shouldThrowResourceNotFoundOnSequenceIdGeneration() {
            // Arrange
            Dependent newDependent = new Dependent();
            newDependent.setBenefitMemberId("");  // No member ID to simulate new dependent
            DependentProfile profile = new DependentProfile();
            newDependent.setDependentProfile(profile);
            
            String generatedMemberId = "654321";
            DependentDO savedDependentDO = createTestDependentDO(generatedMemberId);
            savedDependentDO.setBenefitMemberId("");

            when(dependentRepository.findTopByOrderByBenefitMemberIdDesc())
                    .thenReturn(Collections.singletonList(testDependentDO));
            when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                    .thenThrow(RuntimeException.class);

            // Simulate retry behavior for retryTemplate
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            assertThrows(
                        Exception.class,
                        () -> dependentService.upsertDependent(savedDependentDO),
                        "Should throw IllegalArgumentException for Encrpytion"
                );

            verify(dependentRepository, never()).insertStrict(any(DependentDO.class));
            verify(cryptoUtils, never()).getFPEEncryptDecryptRecords(any(), eq(DependentConstant.FPEAction.ENCRYPT));
        }
        
        @Test
        @DisplayName("Should throw ResourceNotFoundException when updating non-existent dependent")
        void shouldThrowResourceNotFoundExceptionWhenUpdatingNonExistentDependent() {
            // Arrange
            String nonExistentMemberId = "999999";
            Dependent dependent = new Dependent();
            dependent.setBenefitMemberId(nonExistentMemberId);
            
            when(dependentRepository.getDependentByBenefitMemberId(nonExistentMemberId))
                    .thenReturn(null);

            // Simulate retry behavior for retryTemplate
           doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());
            
            // Act & Assert
            ResourceNotFoundException exception = assertThrows(
                    ResourceNotFoundException.class,
                    () -> dependentService.upsertDependent(dependent),
                    "Should throw ResourceNotFoundException when updating non-existent dependent"
            );
            
            assertTrue(exception.getMessage().contains(nonExistentMemberId),
                    "Exception message should contain the non-existent member ID");
        }

        @Test
        @DisplayName("Should handle conflict when updating dependent")
        void shouldHandleConflictWhenUpdatingDependent() {
            // Arrange
            String existingMemberId = BENEFIT_MEMBER_ID;
            Dependent existingDependent = testDependent;

            DependentDO existingDependentDO = testDependentDO;
            DependentDO updatedDependentDO = createTestDependentDO(existingMemberId);
            updatedDependentDO.setVersion(existingDependentDO.getVersion() + 1);

            // First call throws conflict, second call succeeds
            when(dependentRepository.getDependentByBenefitMemberId(existingMemberId))
                    .thenReturn(Collections.singletonList(existingDependentDO));
            /*mockEncryption(existingDependent);*/

            // Simulate 412 Conflict on first save attempt
            CosmosException cosmosException = mock(CosmosException.class);
            when(cosmosException.getStatusCode()).thenReturn(412);

            when(dependentRepository.save(any(DependentDO.class)))
                    .thenThrow(cosmosException)
                    .thenReturn(updatedDependentDO);

            // Re-setup retry template for this specific test
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    if (t instanceof CosmosException && ((CosmosException) t).getStatusCode() == 412) {
                        // On conflict, retry once
                        return updatedDependentDO;
                    }
                    throw t;
                }
            }).when(retryTemplate).execute(any());

            // Act
            Dependent result = dependentService.upsertDependent(existingDependent);

            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(existingMemberId, result.getBenefitMemberId(),
                    "The returned dependent should have the same member ID");
        }
        
        @Test
        @DisplayName("Should handle conflict when inserting dependent")
        void shouldHandleConflictWhenInsertingDependent() {
            // Arrange
            Dependent newDependent = new Dependent();
            newDependent.setBenefitMemberId(null);
            DependentProfile profile = new DependentProfile();
            newDependent.setDependentProfile(profile);
            
            String generatedMemberId = "654321";
            String secondGeneratedMemberId = "654322";
            DependentDO savedDependentDO = createTestDependentDO(secondGeneratedMemberId);
            savedDependentDO.setBenefitMemberId("");
            
            when(dependentRepository.findTopByOrderByBenefitMemberIdDesc())
                    .thenReturn(Collections.singletonList(testDependentDO));
            when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                    .thenReturn(generatedMemberId)
                    .thenReturn(secondGeneratedMemberId);

            mockEncryption(secondGeneratedMemberId);
            
            // First insert throws conflict, second succeeds
            when(dependentRepository.insertStrict(any(DependentDO.class)))
                    .thenThrow(new ResourceAlreadyExistsException("Conflict"))
                    .thenReturn(savedDependentDO);
                    
            // Re-setup retry template for this specific test
            doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    if (t instanceof ResourceAlreadyExistsException) {
                        when(sequnceGeneratorService.generateUniqueMemberId(anyString()))
                            .thenReturn(secondGeneratedMemberId);
                        return savedDependentDO;
                    }
                    throw t;
                }
            }).when(retryTemplate).execute(any());
            
            // Act
            Dependent result = dependentService.upsertDependent(savedDependentDO);
            
            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(secondGeneratedMemberId, result.getBenefitMemberId(), 
                    "The returned dependent should have the generated member ID");
        }
    

        @Nested
        @DisplayName("Tests for deleteDependent method")
        class DeleteDependentTests {
        
        @Test
        @DisplayName("Should soft delete dependent by setting active flag to false")
        void shouldSoftDeleteDependentBySettingActiveFlagToFalse() {
            // Arrange
            DependentDO existingDependentDO = testDependentDO;
            DependentDO deactivatedDependentDO = createTestDependentDO(BENEFIT_MEMBER_ID);
            deactivatedDependentDO.setActive(false);
            
            when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                    .thenReturn(Collections.singletonList(existingDependentDO));
            when(dependentRepository.save(any(DependentDO.class)))
                    .thenReturn(deactivatedDependentDO);
            mockDecryption();

            // Simulate retry behavior for retryTemplate
           doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());
            
            // Act
            Dependent result = dependentService.deleteDependent(BENEFIT_MEMBER_ID);
            
            // Assert
            assertNotNull(result, "The returned dependent should not be null");
            assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(), 
                    "The returned dependent should have the same benefit member ID");
            assertFalse(deactivatedDependentDO.isActive(), 
                    "The dependent should be marked as inactive");
            
            // Verify interactions
            verify(dependentRepository).getDependentByBenefitMemberId(BENEFIT_MEMBER_ID);
            verify(dependentRepository).save(dependentDOCaptor.capture());
            assertFalse(dependentDOCaptor.getValue().isActive(), 
                    "The saved dependent should be marked as inactive");
        }

        @Test
        @DisplayName("Should throw IllegalArgumentException when benefitMemberId is null")
        void shouldThrowIllegalArgumentExceptionWhenBenefitMemberIdIsNull() {
            // Act & Assert
            IllegalArgumentException exception = assertThrows(
                    IllegalArgumentException.class,
                    () -> dependentService.deleteDependent(null),
                    "Should throw IllegalArgumentException when benefitMemberId is null"
            );

            assertEquals("BenefitMemberId cannot be null or empty", exception.getMessage(),
                    "Exception message should indicate benefitMemberId cannot be null or empty");
        }

            @Test
            @DisplayName("Should throw IllegalArgumentException when benefitMemberId is empty")
            void shouldThrowIllegalArgumentExceptionWhenBenefitMemberIdIsEmpty() {
                // Act & Assert
                IllegalArgumentException exception = assertThrows(
                        IllegalArgumentException.class,
                        () -> dependentService.deleteDependent(""),
                        "Should throw IllegalArgumentException when benefitMemberId is empty"
                );

                assertEquals("BenefitMemberId cannot be null or empty", exception.getMessage(),
                        "Exception message should indicate benefitMemberId cannot be null or empty");
            }
        
        @Test
        @DisplayName("Should throw ResourceNotFoundException when dependent not found")
        void shouldThrowResourceNotFoundExceptionWhenDependentNotFound() {
            // Arrange
            String nonExistentMemberId = "999999";
            
            when(dependentRepository.getDependentByBenefitMemberId(nonExistentMemberId))
                    .thenReturn(null);

                    // Simulate retry behavior for retryTemplate
           doAnswer(invocation -> {
                try {
                    return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                } catch (Throwable t) {
                    throw t;
                }
            }).when(retryTemplate).execute(any());
            
            // Act & Assert
            ResourceNotFoundException exception = assertThrows(
                    ResourceNotFoundException.class,
                    () -> dependentService.deleteDependent(nonExistentMemberId),
                    "Should throw ResourceNotFoundException when dependent not found"
            );
            
            assertTrue(exception.getMessage().contains(nonExistentMemberId),
                    "Exception message should contain the non-existent member ID");
        }

            @Test
            @DisplayName("Should handle conflict when deleting dependent")
            void shouldHandleConflictWhenDeletingDependent() {
                // Arrange
                DependentDO existingDependentDO = testDependentDO;
                DependentDO deactivatedDependentDO = createTestDependentDO(BENEFIT_MEMBER_ID);
                deactivatedDependentDO.setActive(false);

                when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                        .thenReturn(Collections.singletonList(existingDependentDO))
                        .thenReturn(Collections.singletonList(existingDependentDO)); // For the retry

                /*mockEncryption(any(Dependent.class));*/

                // Simulate 412 Conflict on first save attempt
                CosmosException cosmosException = mock(CosmosException.class);
                when(cosmosException.getStatusCode()).thenReturn(412);

                when(dependentRepository.save(any(DependentDO.class)))
                        .thenThrow(cosmosException)
                        .thenReturn(deactivatedDependentDO);

                // Re-setup retry template for this specific test
                doAnswer(invocation -> {
                    try {
                        return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                    } catch (Throwable t) {
                        if (t instanceof CosmosException && ((CosmosException) t).getStatusCode() == 412) {
                            // Mock the retry behavior
                            when(dependentRepository.save(any(DependentDO.class))).thenReturn(deactivatedDependentDO);
                            return deactivatedDependentDO;
                        }
                        throw t;
                    }
                }).when(retryTemplate).execute(any());

                // Act
                Dependent result = dependentService.deleteDependent(BENEFIT_MEMBER_ID);

                // Assert
                assertNotNull(result, "The returned dependent should not be null");
                assertEquals(BENEFIT_MEMBER_ID, result.getBenefitMemberId(),
                        "The returned dependent should have the same benefit member ID");
            }

            @Test
            @DisplayName("Should handle conflict when deleting dependent")
            void shouldThrowErrorOnCosmosExceptionWhenDeletingDependent() {
                // Arrange
                DependentDO existingDependentDO = testDependentDO;
                DependentDO deactivatedDependentDO = createTestDependentDO(BENEFIT_MEMBER_ID);
                deactivatedDependentDO.setActive(false);

                when(dependentRepository.getDependentByBenefitMemberId(BENEFIT_MEMBER_ID))
                        .thenReturn(Collections.singletonList(existingDependentDO))
                        .thenReturn(Collections.singletonList(existingDependentDO)); // For the retry

                /*mockEncryption(any(Dependent.class));*/

                doAnswer(invocation -> {
                    try {
                        return invocation.getArgument(0, org.springframework.retry.RetryCallback.class).doWithRetry(null);
                    } catch (Throwable t) {
                        throw t;
                    }
                }).when(retryTemplate).execute(any());

                // Simulate 411 Conflict on first save attempt
                CosmosException cosmosException = mock(CosmosException.class);
                when(cosmosException.getStatusCode()).thenReturn(41);

                when(dependentRepository.save(any(DependentDO.class)))
                        .thenThrow(cosmosException)
                        .thenReturn(deactivatedDependentDO);

                assertThrows(
                    CosmosException.class,
                    () -> dependentService.deleteDependent(BENEFIT_MEMBER_ID),
                    "Should throw CosmosException"
                );
            }
        }

        @Nested
        @DisplayName("Tests for getDecryptedInfo method")
        class GetDecryptedInfoTests {

            @Test
            @DisplayName("Should return empty map when called")
            void shouldReturnEmptyMapWhenCalled() {
                // Arrange
                List<FPERecord> fpeRecordList = new ArrayList<>();
                FPEFld fpeFld = new FPEFld();
                fpeFld.setCity("Encrypted City");
                fpeFld.setZip("12345");
                fpeFld.setSsn("123-45-6789");
                fpeFld.setPhone("555-123-4567");
                FPERecord fpeRecord = new FPERecord(BENEFIT_MEMBER_ID, fpeFld);
                fpeRecordList.add(fpeRecord);

                // Act
                Map<String, String> result = dependentService.getDecryptedInfo(fpeRecordList);

                // Assert
                assertNotNull(result, "The returned map should not be null");
                assertTrue(result.isEmpty(), "The returned map should be empty");
            }
        }
    }
}