package com.walmart.bp.dependent.api.util;

public class ApplicationConstant {

    public static final String DEPENDENT_CONTAINER = "dependent";
}
