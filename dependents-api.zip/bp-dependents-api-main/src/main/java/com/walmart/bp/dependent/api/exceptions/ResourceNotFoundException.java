package com.walmart.bp.dependent.api.exceptions;

/**
 * Custom exception for handling Plan Config service exceptions.
 */
public class ResourceNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
