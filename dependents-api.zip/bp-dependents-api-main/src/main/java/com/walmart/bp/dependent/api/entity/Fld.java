package com.walmart.bp.dependent.api.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Fld {
    private String id = "";
    private String val = "";
    private String typ = "";
}
