package com.walmart.bp.dependent.api.common.config;

import com.azure.cosmos.*;
import com.azure.spring.data.cosmos.config.AbstractCosmosConfiguration;
import com.azure.spring.data.cosmos.repository.config.EnableCosmosRepositories;
import com.walmart.bp.dependent.api.repositories.DependentRepository;
import com.walmart.platform.ccm.ConfigurationFactory;
import com.walmart.platform.daf.cosmos.CosmosUtil;
import io.strati.configuration.ConfigurationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.Nullable;

@Configuration
@EnableCosmosRepositories(basePackageClasses = DependentRepository.class)
public class CosmosDBConfig extends AbstractCosmosConfiguration {


    @Bean("cosmosSyncClient")
    public CosmosClient cosmosClient() {
        return CosmosUtil.buildSyncClientFromStandardProviderTemplate();
    }

    @Override
    protected String getDatabaseName() {
        ConfigurationService configurationService =
                ConfigurationFactory.getConfigurationService().get();
        return configurationService.getConfiguration("database").getString("azure.cosmosdb.database");
    }


    @Override
    @Bean("cosmosAsyncClient")
    public CosmosAsyncClient cosmosAsyncClient(
            final @Nullable CosmosClientBuilder cosmosClientBuilder){
        return CosmosUtil.buildClientFromStandardProviderTemplate();
    }

//    @Bean("sequenceContainer")
//    public CosmosAsyncContainer sequenceContainer(CosmosAsyncClient cosmosAsyncClient) {
//        return getCosmosContainer( "sequence-container", cosmosAsyncClient);
//    }
//    private CosmosAsyncContainer getCosmosContainer(String collectionName, CosmosAsyncClient cosmosAsyncClient) {
//        CosmosAsyncContainer cosmosContainerResponse = cosmosAsyncClient.getDatabase(getDatabaseName()).getContainer(collectionName);
//        if (cosmosContainerResponse == null) {
//            throw new RuntimeException("Cosmos container not initialized");
//        } else {
//            return cosmosContainerResponse;
//        }
//    }

//    TODO => create a cosmosContainer Bean, read container name from secrets.
//    @Bean
//    public CosmosContainer cosmosContainer() {
//        return getCosmosContainer( "plan-config");
//    }
//    private CosmosContainer getCosmosContainer(String collectionName) {
//        CosmosContainer cosmosContainerResponse = cosmosClient().getDatabase(getDatabaseName()).getContainer(collectionName);
//        if (cosmosContainerResponse == null) {
//            throw new RuntimeException("Cosmos container not initialized");
//        } else {
//            return cosmosContainerResponse;
//        }
//    }
}
