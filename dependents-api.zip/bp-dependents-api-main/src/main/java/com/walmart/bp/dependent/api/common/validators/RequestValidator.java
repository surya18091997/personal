package com.walmart.bp.dependent.api.common.validators;

import com.walmart.benefitsplatformentitymodel.intradomain.assessment.Assessment;
import com.walmart.benefitsplatformentitymodel.intradomain.assessment.AssessmentType;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import static com.walmart.benefitsplatformentitymodel.intradomain.common.constants.DATE_PATTERN;


@NoArgsConstructor
@Component
public class RequestValidator {

  /**
   * Validate associate ID
   * @param associateId
   */
  public void validAssociateId(String associateId) {
    if (StringUtils.isBlank(associateId)) {
      throw new IllegalArgumentException("associateId is blank");
    }
  }

  /**
   * Validate assessment type
   * @param assessmentType
   */
  public void validAssessmentType(AssessmentType assessmentType) {
    if (assessmentType == null) {
      throw new IllegalArgumentException("assessmentType is null");
    }
  }

  /**
   * Validate date format according to the defined pattern
   * @param dateStr The date string to validate
   * @param fieldName The name of the field containing the date for error messages
   */
  private void validateDateFormat(String dateStr, String fieldName) {
    if (StringUtils.isNotBlank(dateStr)) {
      SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
      dateFormat.setLenient(false);
      try {
        dateFormat.parse(dateStr);
      } catch (ParseException e) {
        throw new IllegalArgumentException(fieldName + " has invalid date format. Expected format: " + DATE_PATTERN);
      }
    }
  }

  /**
   * Validate assessment date
   * @param assessmentDate
   */
  public void validAssessmentDate(String assessmentDate) {
    if (StringUtils.isBlank(assessmentDate)) {
      throw new IllegalArgumentException("assessmentDate is blank");
    }
    validateDateFormat(assessmentDate, "assessmentDate");
  }

  /**
   * Validate assessment start date
   * @param assessmentStartDate
   */
  public void validAssessmentStartDate(String assessmentStartDate) {
    if (StringUtils.isBlank(assessmentStartDate)) {
      throw new IllegalArgumentException("assessmentStartDate is blank");
    }
    validateDateFormat(assessmentStartDate, "assessmentStartDate");
  }
  
  /**
   * Validate assessment eligibility start date
   * @param assessmentEligibilityStartDate
   */
  public void validAssessmentEligibilityStartDate(String assessmentEligibilityStartDate) {
    // This may be null according to the Assessment class, so only validate if it's present
    if (StringUtils.isNotBlank(assessmentEligibilityStartDate)) {
      validateDateFormat(assessmentEligibilityStartDate, "assessmentEligibilityStartDate");
    }
  }

  /**
   * Comprehensive validation for Assessment creation
   * @param assessment
   */
  public void isValidAssessmentForCreate(Assessment assessment) {
    if (assessment == null) {
      throw new IllegalArgumentException("Assessment is null");
    }
    
    validAssociateId(assessment.getAssociateId());
    validAssessmentType(assessment.getAssessmentType());
    validAssessmentDate(assessment.getAssessmentDate());
    validAssessmentStartDate(assessment.getAssessmentStartDate());
    validAssessmentEligibilityStartDate(assessment.getAssessmentEligibilityStartDate());
  }

  /**
   * Comprehensive validation for Assessment update
   * @param assessment
   */
  public void isValidAssessmentForUpdate(Assessment assessment) {
    if (assessment == null) {
      throw new IllegalArgumentException("Assessment is null");
    }
    
    validAssociateId(assessment.getAssociateId());
    // For updates, we may want to be less strict
    if (assessment.getAssessmentType() != null) {
      validAssessmentType(assessment.getAssessmentType());
    }
    if (StringUtils.isNotBlank(assessment.getAssessmentDate())) {
      validAssessmentDate(assessment.getAssessmentDate());
    }
    if (StringUtils.isNotBlank(assessment.getAssessmentStartDate())) {
      validAssessmentStartDate(assessment.getAssessmentStartDate());
    }
    if (StringUtils.isNotBlank(assessment.getAssessmentEligibilityStartDate())) {
      validAssessmentEligibilityStartDate(assessment.getAssessmentEligibilityStartDate());
    }
  }
}
