package com.walmart.bp.dependent.api.mappers;

import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.bp.dependent.api.models.DependentDO;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.List;

import static org.mapstruct.CollectionMappingStrategy.ADDER_PREFERRED;
import static org.mapstruct.NullValueCheckStrategy.ALWAYS;
import static org.mapstruct.NullValuePropertyMappingStrategy.IGNORE;

/**
 * Mapper interface for the Assessment. This would help in achieving the patch functionality
 */
@Mapper(
        nullValueCheckStrategy = ALWAYS,
        nullValuePropertyMappingStrategy = IGNORE,
        collectionMappingStrategy = ADDER_PREFERRED
)
public interface DependentDBObjectMapper {
    DependentDBObjectMapper INSTANCE = Mappers.getMapper(DependentDBObjectMapper.class);

    DependentDO fromDependent(Dependent dependent);

    List<DependentDO> fromDependent(List<Dependent> dependent);

    Dependent fromDependentDO(DependentDO assessmentDO);

    List<Dependent> fromDependentDO(List<DependentDO> dependentDO);

    // Patch functionality
    DependentDO patchDependent(@MappingTarget DependentDO currentRecord, Dependent newRecord);
}
