package com.walmart.bp.dependent.api.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class Record {
    private String id = "";
    private List<Fld> flds;
}
