package com.walmart.bp.dependent.api.util;

import com.walmart.bp.dependent.api.entity.EncryptionResponse;
import com.walmart.bp.dependent.api.entity.FPERecord;
import com.walmart.bp.dependent.api.entity.Record;
import com.walmart.bp.dependent.api.common.util.DependentConstant;
import com.walmart.bp.dependent.api.common.util.ExternalRequestHandler;
import com.walmart.bp.dependent.api.common.util.ServiceRegistryConfig;
import com.walmart.bp.dependent.api.exceptions.DependentException;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Component
@Configuration
@Slf4j
public class CryptoUtils implements DependentConstant {

    @Autowired
    private ServiceRegistryConfig srConfig;

    @Autowired
    private ExternalRequestHandler externalRequestHandler;

    @Value("#{'${crypto.Service.url}'}")
    private String cryptoBaseUrl;
    @Value("#{'${crypto.encryption.endpoint}'}")
    private String encryptEndpoint;
    @Value("#{'${crypto.decryption.endpoint}'}")
    private String decryptEndpoint;

    public void getServiceRegistryHeaders(HttpHeaders headers, String serviceName){
        ServiceRegistryConfig.ServiceRegistry serviceReg = srConfig.getSr().get(serviceName);
        if(serviceReg != null){
            headers.set(CONSUMER_ID, serviceReg.getConsumerId());
            headers.set(KEY_VERSION, serviceReg.getKeyVersion());
            headers.set(SERVICE_NAME,serviceReg.getServiceName());
            headers.set(SERVICE_ENV, serviceReg.getEnvName());
        }else{
            log.warn("Service Registry configuration not found for the service name {}" , serviceName);
        }
    }

    public List<Record> getFPEEncryptDecryptRecords(List<FPERecord> fpeRecordList, FPEAction action) throws DependentException{
        List<Record> recordOutputList = new ArrayList<>();
        HttpHeaders headers = new HttpHeaders();
        String fpeURL = cryptoBaseUrl ;
        try{
            headers.add("Content-Type", "application/json");
            headers.add("identifier", "HealthCoverageService");
            if(IS_SERVICE_REGISTRY_ENABLED){
                getServiceRegistryHeaders(headers,FPE_SERVICE_KEY);
            }
            if (action == FPEAction.ENCRYPT) {
                fpeURL += encryptEndpoint;
            } else if (action == FPEAction.DECRYPT) {
                fpeURL += decryptEndpoint;
            }
            log.info("FPE URL: {}", fpeURL);
            EncryptionResponse encryptionResponse = externalRequestHandler.post(fpeURL,fpeRecordList,headers,EncryptionResponse.class);
            log.info("EncryptionResponse: {}", encryptionResponse);
            if (null != encryptionResponse) {
                if(encryptionResponse.getResponseCode() != HttpStatus.SC_OK){
                    log.error("Error record obtained while encrypting/decrypting request: {}", encryptionResponse.getErrorRecords());
                    throw new DependentException ("Error record obtained while encrypting/decrypting request");
                } else if (encryptionResponse.getRecords().get(0).getId().equals(fpeRecordList.get(0).getId())) {
                    recordOutputList = encryptionResponse.getRecords();
                }
            }

        }catch (Exception e){
            log.error("Exception in encryption/decryption service call: {}" , e.getMessage());
            throw new DependentException("Error in encryption/decryption service call: " +  e.getMessage());
        }
        return recordOutputList;
    }

    public String addLeadingZeros(String attribute, int length) {
        String validAttribute = EMPTYSTRING;
        if(StringUtils.hasText(attribute)){
            validAttribute = attribute;
            while (validAttribute.length() < length) {
                validAttribute = STRING_STR_ZERO + validAttribute;
            }
        }
        return validAttribute;
    }

}
