package com.walmart.bp.dependent.api.common.util;

import org.springframework.util.StringUtils;

public interface DependentConstant {

    String CONSUMER_ID = "WM_CONSUMER.ID";
    String KEY_VERSION = "WM_SEC.KEY_VERSION";
    String SERVICE_NAME = "WM_SVC.NAME";
    String SERVICE_ENV = "WM_SVC.ENV";

    String FPE_SERVICE_KEY = "fpe";

    String EMPTYSTRING = "";
    String STRING_STR_ZERO = "0";

    enum FPEAction {
        ENCRYPT, DECRYPT
    }

    boolean IS_SERVICE_REGISTRY_ENABLED = StringUtils
            .hasText(System.getProperty("service.registry.enabled")) ? Boolean.parseBoolean(System
            .getProperty("service.registry.enabled")) : false;

}