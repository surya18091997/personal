package com.walmart.bp.dependent.api.services;

/**
 * Service responsible for generating unique member IDs in a distributed environment.
 * Ensures uniqueness across multiple container instances.
 */
public interface SequnceGeneratorService {
    
    /**
     * Generates a new unique member ID that is guaranteed to be greater than the current member ID.
     * This method is designed to work in a distributed environment with multiple containers.
     * 
     * @param currentMemberId The current highest member ID (as a string)
     * @return A new unique member ID that is greater than the current member ID
     */
    String generateUniqueMemberId(String currentMemberId);
    
    /**
     * Gets the current value of a sequence without incrementing it.
     * This is useful for testing and for checking the current state of a sequence.
     * 
     * @param sequenceType The type of sequence to check
     * @return The current sequence value, or null if the sequence doesn't exist
     */
    Long getCurrentSequenceValue(String sequenceType);
    
    /**
     * Sets the value of a sequence.
     * This is useful for initializing a sequence with a specific starting value.
     * 
     * @param sequenceType The type of sequence to set
     * @param value The value to set for the sequence
     */
    void setSequenceValue(String sequenceType, Long value);
}