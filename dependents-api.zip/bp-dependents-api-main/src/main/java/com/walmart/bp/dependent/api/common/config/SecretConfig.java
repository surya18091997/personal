package com.walmart.bp.dependent.api.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;

/**
 * Interface with functions that get us default messages from CCM.
 */
@Configuration(
    configName = "database",
    externalFileName = "DatabaseConfig.properties",
    failOnMissingExternalFile = "true")
public interface SecretConfig {

  @Property(propertyName = "spring.datasource.username")
  String getUserName();

  @Property(propertyName = "spring.datasource.password")
  String getPassword();

}
