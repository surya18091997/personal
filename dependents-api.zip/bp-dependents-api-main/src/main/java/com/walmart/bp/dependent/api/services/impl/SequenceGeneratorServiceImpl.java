package com.walmart.bp.dependent.api.services.impl;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;
import com.walmart.bp.dependent.api.exceptions.SequenceGenerationException;
import com.walmart.bp.dependent.api.models.SequenceDO;
import com.walmart.bp.dependent.api.services.SequnceGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SequenceGeneratorServiceImpl implements SequnceGeneratorService {

//    @Autowired
    private CosmosAsyncContainer sequenceContainer;

    @Autowired
    private CosmosAsyncClient cosmosClient;

    @Autowired
    private RetryTemplate retryTemplate;
    
    @Value("${sequence.name:dependent}")
    private String sequenceName;

    private static final String SEQUENCE_NAME = "@sequenceName";
    private static final String SEQUENCE_TYPE = "@sequenceType";
    private static final String QUERY_TEXT = "SELECT * FROM c WHERE c.sequenceName = " + SEQUENCE_NAME + " AND c.id = " + SEQUENCE_TYPE;
    
    @PostConstruct
    public void init() {
        // Initialize the sequence container
        sequenceContainer = cosmosClient.getDatabase("benefits-platform").getContainer("sequence-container");
    }

    // Cache to store sequence document IDs by sequence name
    private final Map<String, String> sequenceIdCache = new ConcurrentHashMap<>();

    public String generateUniqueMemberId(String currMemberId) {
        return retryTemplate.execute(context -> {
            try {
                // Get or create document ID for this sequence - pass the current ID as seed if it's numeric
                Long seedValue = null;
                seedValue = getLongSeedValue(currMemberId, seedValue);

                String documentId = getOrCreateSequenceDocumentId(sequenceName, seedValue);
                
                // Use patch operation to increment the sequence value
                CosmosPatchOperations patchOps = CosmosPatchOperations.create()
                        .increment("/value", 1);

                CosmosPatchItemRequestOptions options = new CosmosPatchItemRequestOptions();
                options.setConsistencyLevel(ConsistencyLevel.STRONG);

                // Perform the atomic increment operation
                CosmosItemResponse<SequenceDO> response = sequenceContainer.patchItem(
                        documentId,
                        new PartitionKey(sequenceName),
                        patchOps,
                        options,
                        SequenceDO.class
                ).block(); // block() to make it synchronous within the retry context

                if (response == null || response.getItem() == null) {
                    throw new SequenceGenerationException("Failed to retrieve sequence value after patch for sequenceType: " + sequenceName, null);
                }

                return String.valueOf(response.getItem().getValue());

            } catch (Exception e) {
                // Wrap the original exception in the custom SequenceGenerationException
                throw new SequenceGenerationException(
                    "Failed to increment sequence for type '" + sequenceName + "' after " +
                    context.getRetryCount() + " retries: " + e.getMessage(), e);
            }
        });
    }

    private static Long getLongSeedValue(String currMemberId, Long seedValue) {
        try {
            seedValue = Long.parseLong(currMemberId);
        } catch (NumberFormatException e) {
            // Not a number, will use default seed value
        }
        return seedValue;
    }

    /**
     * Gets the document ID for a given sequence type from cache or retrieves it from the database.
     * If the sequence doesn't exist yet, it creates one with an initial value.
     *
     * @param sequenceType the type of sequence (e.g., "memberId")
     * @param seedValue optional seed value to use when creating a new sequence
     * @return the document ID for the sequence in Cosmos DB
     */
    private String getOrCreateSequenceDocumentId(String sequenceType, Long seedValue) {
        // Check cache first
        String cachedId = sequenceIdCache.get(sequenceType);
        if (cachedId != null) {
            return cachedId;
        }
        
        // Query for the sequence by name and type
        SqlQuerySpec querySpec = new SqlQuerySpec(QUERY_TEXT,
                new SqlParameter(SEQUENCE_NAME, sequenceName),
                new SqlParameter(SEQUENCE_TYPE, sequenceType));
                
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();

        // Try to find existing sequence
        SequenceDO sequenceDO = sequenceContainer.queryItems(querySpec, options, SequenceDO.class)
                .byPage()
                .flatMap(page -> Mono.justOrEmpty(page.getResults().stream().findFirst()))
                .blockFirst();
                
        if (sequenceDO != null) {
            // Found existing sequence, cache it
            sequenceIdCache.put(sequenceType, sequenceDO.getId());
            return sequenceDO.getId();
        }
        
        // Sequence doesn't exist, create it
        sequenceDO = new SequenceDO();
        sequenceDO.setId(sequenceType); // Use sequenceType as document ID
        sequenceDO.setSequenceName(sequenceName);
        
        // Use seed value if provided, otherwise start from 0
        sequenceDO.setValue(seedValue != null ? seedValue : 0L);
        
        try {
            CosmosItemResponse<SequenceDO> response = sequenceContainer.createItem(
                    sequenceDO,
                    new PartitionKey(sequenceName),
                    new CosmosItemRequestOptions()
            ).block();
            
            if (response == null || response.getItem() == null) {
                throw new SequenceGenerationException("Failed to create sequence for type: " + sequenceType, null);
            }
            
            // Cache the document ID
            sequenceIdCache.put(sequenceType, sequenceType);
            return sequenceType;
            
        } catch (CosmosException e) {
            // Handle case where the sequence might have been created by another instance
            if (e.getStatusCode() == 409) { // Conflict status code
                // Try to get the sequence again
                return getOrCreateSequenceDocumentId(sequenceType, seedValue);
            }
            throw new SequenceGenerationException("Error creating sequence: " + e.getMessage(), e);
        }
    }

    @Override
    public Long getCurrentSequenceValue(String sequenceType) {
        try {
            // Query for the sequence by name and type
            SqlQuerySpec querySpec = new SqlQuerySpec(QUERY_TEXT,
                    new SqlParameter(SEQUENCE_NAME, sequenceName),
                    new SqlParameter(SEQUENCE_TYPE, sequenceType));
                    
            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();

            // Try to find existing sequence
            SequenceDO sequenceDO = sequenceContainer.queryItems(querySpec, options, SequenceDO.class)
                    .byPage()
                    .flatMap(page -> Mono.justOrEmpty(page.getResults().stream().findFirst()))
                    .blockFirst();
                    
            if (sequenceDO != null) {
                // Found existing sequence, return its value
                return sequenceDO.getValue();
            }
            
            // Sequence doesn't exist yet
            return null;
            
        } catch (CosmosException e) {
            throw new SequenceGenerationException("Error retrieving sequence value: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void setSequenceValue(String sequenceType, Long value) {
        try {
            // First, check if the sequence exists
            String documentId = null;
            
            // Query for the sequence by name and type
            SqlQuerySpec querySpec = new SqlQuerySpec(QUERY_TEXT,
                    new SqlParameter(SEQUENCE_NAME, sequenceName),
                    new SqlParameter(SEQUENCE_TYPE, sequenceType));
                    
            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();

            // Try to find existing sequence
            SequenceDO sequenceDO = sequenceContainer.queryItems(querySpec, options, SequenceDO.class)
                    .byPage()
                    .flatMap(page -> Mono.justOrEmpty(page.getResults().stream().findFirst()))
                    .blockFirst();
                    
            if (sequenceDO != null) {
                // Found existing sequence, update it
                documentId = sequenceDO.getId();
                
                // Use patch operation to set the value
                CosmosPatchOperations patchOps = CosmosPatchOperations.create()
                        .set("/value", value);

                CosmosPatchItemRequestOptions patchOptions = new CosmosPatchItemRequestOptions();
                patchOptions.setConsistencyLevel(ConsistencyLevel.STRONG);

                // Perform the update operation
                sequenceContainer.patchItem(
                        documentId,
                        new PartitionKey(sequenceName),
                        patchOps,
                        patchOptions,
                        SequenceDO.class
                ).block();
            } else {
                // Sequence doesn't exist, create it
                sequenceDO = new SequenceDO();
                sequenceDO.setId(sequenceType);
                sequenceDO.setSequenceName(sequenceName);
                sequenceDO.setValue(value);
                
                sequenceContainer.createItem(
                        sequenceDO,
                        new PartitionKey(sequenceName),
                        new CosmosItemRequestOptions()
                ).block();
                
                // Cache the document ID
                sequenceIdCache.put(sequenceType, sequenceType);
            }
            
        } catch (CosmosException e) {
            throw new SequenceGenerationException("Error setting sequence value: " + e.getMessage(), e);
        }
    }
}