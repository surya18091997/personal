package com.walmart.bp.dependent.api.models;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data object representing a sequence counter in Cosmos DB.
 * Uses the sequence name as the partition key to allow multiple applications
 * to use the same container with different sequence names.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Container(containerName = "sequence-container")
public class SequenceDO {

    @Id
    private String id;
    
    @PartitionKey
    private String sequenceName;
    
    private long value;
    
    // Enable optimistic locking
    @Version
    private String _eTag;
}