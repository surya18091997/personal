package com.walmart.bp.dependent.api.common.config;//
//package com.walmart.bp.assessment.api.common.config;
//
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collection;
//import java.util.Collections;
//import java.util.List;
//
//
//import com.fasterxml.classmate.TypeResolver;
//import com.walmart.bp.assessment.api.exceptions.AssessmentExceptionResponse;
//import com.walmart.bp.assessment.api.exceptions.PlanConfigExceptionResponse;
//import org.springframework.boot.actuate.autoconfigure.endpoint.web.CorsEndpointProperties;
//import org.springframework.boot.actuate.autoconfigure.endpoint.web.WebEndpointProperties;
//import org.springframework.boot.actuate.autoconfigure.web.server.ManagementPortType;
//import org.springframework.boot.actuate.endpoint.ExposableEndpoint;
//import org.springframework.boot.actuate.endpoint.web.EndpointLinksResolver;
//import org.springframework.boot.actuate.endpoint.web.EndpointMapping;
//import org.springframework.boot.actuate.endpoint.web.EndpointMediaTypes;
//import org.springframework.boot.actuate.endpoint.web.ExposableWebEndpoint;
//import org.springframework.boot.actuate.endpoint.web.WebEndpointsSupplier;
//import org.springframework.boot.actuate.endpoint.web.annotation.ControllerEndpointsSupplier;
//import org.springframework.boot.actuate.endpoint.web.annotation.ServletEndpointsSupplier;
//import org.springframework.boot.actuate.endpoint.web.servlet.WebMvcEndpointHandlerMapping;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.env.Environment;
//import org.springframework.http.ResponseEntity;
//import org.springframework.util.StringUtils;
//import springfox.documentation.builders.ApiInfoBuilder;
//import springfox.documentation.builders.PathSelectors;
//import springfox.documentation.builders.RequestHandlerSelectors;
//import springfox.documentation.oas.annotations.EnableOpenApi;
//import springfox.documentation.service.ApiInfo;
//import springfox.documentation.service.ApiKey;
//import springfox.documentation.service.AuthorizationScope;
//import springfox.documentation.service.SecurityReference;
//import springfox.documentation.service.SecurityScheme;
//import springfox.documentation.spi.DocumentationType;
//import springfox.documentation.spi.service.contexts.SecurityContext;
//import springfox.documentation.spring.web.plugins.Docket;
//import springfox.documentation.swagger.web.SecurityConfiguration;
//import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
//
// /**
// * Swagger Configuration that implements security and OpenAPI 3.0
// */
//
////@Configuration
////@EnableOpenApi
//public class SwaggerConfig {
//
//
//   /**
//   * Builds the primary interface into the swagger-spring framework.
//   */
//
//  @Bean
//  public Docket planConfigApi(TypeResolver typeResolver) {
//    return new Docket(DocumentationType.OAS_30)
//        .apiInfo(apiInfo())
//        .select()
//        .apis(RequestHandlerSelectors.basePackage("com.walmart.bp.assessment.api"))
//        .paths(PathSelectors.any())
//        .build()
//        .pathMapping("/")
//        .securityContexts(Collections.singletonList(securityContext()))
//        .securitySchemes(getSecurityScheme())
//        .directModelSubstitute(LocalDate.class, String.class)
//        .genericModelSubstitutes(ResponseEntity.class)
//        .additionalModels(typeResolver.resolve(AssessmentExceptionResponse.class));
//  }
//
//  private ApiInfo apiInfo() {
//    ApiInfo apiInfo = new ApiInfoBuilder()
//        .title("assessment-api")
//        .version("1.0")
//        .build();
//
//    return apiInfo;
//  }
//
//  private List<SecurityScheme> getSecurityScheme() {
//    List<SecurityScheme> securitySchemes = new ArrayList<>();
//    securitySchemes.add(new ApiKey("wm_consumer.id", "wm_consumer.id", "header"));
//    securitySchemes.add(new ApiKey("wm_consumer.intimestamp", "wm_consumer.intimestamp", "header"));
//    securitySchemes.add(new ApiKey("wm_sec.key_version", "wm_sec.key_version", "header"));
//    securitySchemes.add(new ApiKey("wm_sec.auth_signature", "wm_sec.auth_signature", "header"));
//    securitySchemes.add(new ApiKey("wm_svc.name", "wm_svc.name", "header"));
//    securitySchemes.add(new ApiKey("wm_svc.env", "wm_svc.env", "header"));
//
//    return securitySchemes;
//  }
//
//  private SecurityContext securityContext() {
//    return SecurityContext.builder()
//        .securityReferences(defaultAuth())
//        .build();
//  }
//
//  private List<SecurityReference> defaultAuth() {
//    AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
//    AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
//    authorizationScopes[0] = authorizationScope;
//    return Arrays.asList(new SecurityReference("wm_consumer.id", authorizationScopes),
//        new SecurityReference("wm_consumer.intimestamp", authorizationScopes),
//        new SecurityReference("wm_sec.key_version", authorizationScopes),
//        new SecurityReference("wm_sec.auth_signature", authorizationScopes),
//        new SecurityReference("wm_svc.name", authorizationScopes),
//        new SecurityReference("wm_svc.env", authorizationScopes));
//  }
//
//  @Bean
//  SecurityConfiguration security() {
//    return SecurityConfigurationBuilder.builder()
//        .enableCsrfSupport(true)
//        .build();
//  }
//
//  /**
//   * WebMvcEndpointHandlerMapping makes web endpoints available over HTTP.
//   */
//
//  @Bean
//  public WebMvcEndpointHandlerMapping webEndpointServletHandlerMapping(
//      WebEndpointsSupplier webEndpointsSupplier,
//      ServletEndpointsSupplier servletEndpointsSupplier,
//      ControllerEndpointsSupplier controllerEndpointsSupplier,
//      EndpointMediaTypes endpointMediaTypes,
//      CorsEndpointProperties corsProperties,
//      WebEndpointProperties webEndpointProperties,
//      Environment environment) {
//
//    List<ExposableEndpoint<?>> allEndpoints = new ArrayList<>();
//    Collection<ExposableWebEndpoint> webEndpoints = webEndpointsSupplier.getEndpoints();
//    allEndpoints.addAll(webEndpoints);
//    allEndpoints.addAll(servletEndpointsSupplier.getEndpoints());
//    allEndpoints.addAll(controllerEndpointsSupplier.getEndpoints());
//    String basePath = webEndpointProperties.getBasePath();
//    EndpointMapping endpointMapping = new EndpointMapping(basePath);
//    boolean shouldRegisterLinksMapping = this.shouldRegisterLinksMapping(webEndpointProperties,
//        environment,
//        basePath);
//    return new WebMvcEndpointHandlerMapping(
//        endpointMapping, webEndpoints, endpointMediaTypes, corsProperties.toCorsConfiguration(),
//        new EndpointLinksResolver(allEndpoints, basePath), shouldRegisterLinksMapping);
//  }
//
//  private boolean shouldRegisterLinksMapping(WebEndpointProperties webEndpointProperties,
//                                             Environment environment, String basePath) {
//    return webEndpointProperties.getDiscovery().isEnabled()
//        && (StringUtils.hasText(basePath)
//        || ManagementPortType.get(environment).equals(ManagementPortType.DIFFERENT));
//  }
//}
