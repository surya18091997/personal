package com.walmart.bp.dependent.api.repositories;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import com.azure.spring.data.cosmos.repository.Query;

import com.walmart.bp.dependent.api.models.DependentDO;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DependentRepository extends CosmosRepository<DependentDO, String>, CustomDependentRepository {

    @Query("SELECT TOP 1 * FROM c where c.benefitMemberId = @benefitMemberId order by c._ts desc")
    List<DependentDO> getDependentByBenefitMemberId(@Param("benefitMemberId") String benefitMemberId);

    @Query("SELECT * FROM c order by c._ts desc")
    Optional<List<DependentDO>> getAllDependents();
    
    /**
     * Query to get the highest member ID
     * This helps in generating the next member ID
     * Remove this method as we'll use the custom implementation
     */
    // @Query("SELECT TOP 1 c.benefitMemberId FROM c ORDER BY c.benefitMemberId DESC")
    // Optional<String> getLatestMemberId();
    
    /**
     * Get all dependents ordered by benefitMemberId in descending order
     * This will be used by the custom repository implementation to extract the latest member ID
     */
    @Query("SELECT TOP 1 * FROM c ORDER BY c.benefitMemberId DESC")
    List<DependentDO> findTopByOrderByBenefitMemberIdDesc();
}
