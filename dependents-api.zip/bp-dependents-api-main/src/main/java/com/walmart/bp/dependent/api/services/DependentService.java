package com.walmart.bp.dependent.api.services;

import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.bp.dependent.api.entity.FPERecord;

import java.util.List;
import java.util.Map;

public interface DependentService {
    Dependent getDependentByBenefitMemberId(String benefitMemberId);
    List<Dependent> getAllDependents();
    Dependent upsertDependent(Dependent dependent);
    Dependent deleteDependent(String benefitMemberId);
    Map<String, String> getDecryptedInfo(List<FPERecord> fpeRecordList);
}
