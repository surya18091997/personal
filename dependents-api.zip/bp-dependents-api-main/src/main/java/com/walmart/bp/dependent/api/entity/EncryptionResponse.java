package com.walmart.bp.dependent.api.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class EncryptionResponse {
    private int responseCode;
    private String transactionId;
    private List<Record> records;
    private List<Record> errorRecords;
}
