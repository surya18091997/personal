package com.walmart.bp.dependent.api;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Include Walmart platform spring components.
 */

// The following import is required to support CCM annotation @ManagedConfiguration
//@Import({StratiBeanConfig.class})
// Will send swagger requests using the correct protocol for deployment to avoid CORS exception
@SpringBootApplication(scanBasePackages = {
  //"Application.class",
  "com.walmart.bp.dependent.api",
//        "com.walmart.platform.ccm.client",
        "com.walmart.bp.dependent.api.controllers",
        "com.walmart.bp.dependent.api.services.impl",
        "com.walmart.bp.dependent.api.repositories"
})

public class Application {
  static { //runs when the main class is loaded.
    System.setProperty("org.jboss.logging.provider", "slf4j");

  }
  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  //@Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(Application.class).bannerMode(Banner.Mode.OFF).headless(true);
  }
}
