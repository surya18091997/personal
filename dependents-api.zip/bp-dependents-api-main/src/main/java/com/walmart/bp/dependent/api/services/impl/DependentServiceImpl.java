package com.walmart.bp.dependent.api.services.impl;

import com.azure.cosmos.CosmosException;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.DependentAddress;
import com.walmart.bp.dependent.api.entity.FPEFld;
import com.walmart.bp.dependent.api.entity.Fld;
import com.walmart.bp.dependent.api.entity.Record;
import com.walmart.bp.dependent.api.entity.FPERecord;
import com.walmart.bp.dependent.api.common.util.DependentConstant;
import com.walmart.bp.dependent.api.exceptions.ResourceAlreadyExistsException;
import com.walmart.bp.dependent.api.exceptions.ResourceNotFoundException;
import com.walmart.bp.dependent.api.exceptions.ValidationException;
import com.walmart.bp.dependent.api.mappers.DependentDBObjectMapper;
import com.walmart.bp.dependent.api.models.DependentDO;
import com.walmart.bp.dependent.api.repositories.DependentRepository;
import com.walmart.bp.dependent.api.services.DependentService;
import com.walmart.bp.dependent.api.services.SequnceGeneratorService;

import com.walmart.bp.dependent.api.util.CryptoUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class DependentServiceImpl implements DependentService {

    private final CryptoUtils cryptoUtils;
    private final DependentRepository dependentRepository;
    private static final DependentDBObjectMapper mapper = DependentDBObjectMapper.INSTANCE;
    private final SequnceGeneratorService sequnceGeneratorService;
    private final RetryTemplate retryTemplate;

    private static final String ENCRYPTION_ERROR_MSG = "Error encrypting dependent data for benefitMemberId";

    @Autowired
    public DependentServiceImpl(CryptoUtils cryptoUtils, 
                               DependentRepository dependentRepository,
                               SequnceGeneratorService sequnceGeneratorService,
                               RetryTemplate retryTemplate) {
        this.cryptoUtils = cryptoUtils;
        this.dependentRepository = dependentRepository;
        this.sequnceGeneratorService = sequnceGeneratorService;
        this.retryTemplate = retryTemplate;
    }

    @Override
    public DependentDO getDependentByBenefitMemberId(String benefitMemberId) {
        List<DependentDO> dependentDOList = dependentRepository.getDependentByBenefitMemberId(benefitMemberId);

        if(dependentDOList == null || dependentDOList.isEmpty()) {
            throw new ResourceNotFoundException("Dependent not found for benefitMemberId: " + benefitMemberId);
        }
        decryptSensitiveFields(mapper.fromDependentDO(dependentDOList));

        return dependentDOList.get(0);
    }

    private static @NotNull List<FPERecord> getFpeRecords(List<DependentDO> dependentDOList) {
        List<FPERecord> fpeRecordList = new ArrayList<>();

        for(DependentDO dependentDO: dependentDOList) {
            for(DependentAddress dependentAddress : dependentDO.getDependentProfile().getAddress()) {
                FPEFld fpeFld = new FPEFld();
                fpeFld.setCity(dependentAddress.getCity());
                fpeFld.setZip(dependentAddress.getZip());
                fpeFld.setSsn(dependentDO.getDependentProfile().getNationalId());
                fpeFld.setPhone(dependentDO.getDependentProfile().getContacts().getPhoneNumber());
                FPERecord fpeRecord = new FPERecord(dependentDO.getBenefitMemberId() + "-" + dependentAddress.getAddressId(), fpeFld);
                fpeRecordList.add(fpeRecord);
            }
        }
        return fpeRecordList;
    }

    @Override
    public List<Dependent> getAllDependents() {
        List<DependentDO> dependents = dependentRepository.getAllDependents()
                .orElseThrow(() -> new ResourceNotFoundException("No dependents found"));
        decryptSensitiveFields(mapper.fromDependentDO(dependents));

        return dependents.stream().map(mapper::fromDependentDO).toList();
    }

    private void decryptSensitiveFields(List<Dependent> dependentList) {
        List<FPERecord> fpeRecordList = getFpeRecords(mapper.fromDependent(dependentList));

        List<Record> recordList = cryptoUtils.getFPEEncryptDecryptRecords(fpeRecordList, DependentConstant.FPEAction.DECRYPT);

        if (recordList != null && !recordList.isEmpty()) {
            for(Record encryptedRecord: recordList) {
                Optional<Dependent> optionalDependent = dependentList.stream().filter(dependentTemp -> 
                    encryptedRecord.getId().substring(0, encryptedRecord.getId().split("-")[0].length()).equals(dependentTemp.getBenefitMemberId())).findFirst();

                setSensitiveFieldsValues(encryptedRecord, optionalDependent);
            }
        }
    }

    private static void setSensitiveFieldsValues(Record encryptedRecord, Optional<Dependent> optionalDependent) {
        if(optionalDependent.isPresent()) {
            Dependent dependent = optionalDependent.get();
            Optional<DependentAddress> optionalDependentAddress = dependent.getDependentProfile().getAddress().stream()
                    .filter(address -> encryptedRecord.getId().split("-")[1].equals(address.getAddressId())).findFirst();
            setFieldValues(dependent, encryptedRecord, optionalDependentAddress);
        }
    }

    private void encryptSensitiveFields(Dependent dependent) {

        try {
            List<FPERecord> fpeRecordList = getFpeRecords(List.of(mapper.fromDependent(dependent)));

            List<Record> recordList = cryptoUtils.getFPEEncryptDecryptRecords(fpeRecordList, DependentConstant.FPEAction.ENCRYPT);

            if (recordList != null && !recordList.isEmpty()) {
                for(Record encryptedRecord: recordList) {
                    Optional<DependentAddress> optionalDependentAddress = dependent.getDependentProfile().getAddress().stream()
                            .filter(address -> encryptedRecord.getId().split("-")[1].equals(address.getAddressId())).findFirst();
                    setFieldValues(dependent, encryptedRecord, optionalDependentAddress);
                }
            }
        } catch (Exception e) {
            log.error(ENCRYPTION_ERROR_MSG + ": {}", dependent.getBenefitMemberId(), e);
            throw new ResourceNotFoundException(ENCRYPTION_ERROR_MSG + ": " + dependent.getBenefitMemberId());
        }
    }

    private static void setFieldValues(Dependent dependent, Record encryptedRecord, Optional<DependentAddress> optionalDependentAddress) {
        if(optionalDependentAddress.isPresent()) {
            DependentAddress dependentAddress = optionalDependentAddress.get();
            for (Fld fld : encryptedRecord.getFlds()) {
                if (fld.getId().equals("city")) {
                    dependentAddress.setCity(fld.getVal());
                } else if (fld.getId().equals("zip")) {
                    dependentAddress.setZip(fld.getVal());
                } else if (fld.getId().equals("ssn")) {
                    dependent.getDependentProfile().setNationalId(fld.getVal());
                } else if (fld.getId().equals("phone")) {
                    dependent.getDependentProfile().getContacts().setPhoneNumber(fld.getVal());
                }
            }
        }
    }

    @Override
    public Dependent upsertDependent(Dependent dependent) {
        if (dependent == null) {
            throw new IllegalArgumentException("Dependent cannot be null");
        }

        // Check if member ID is provided to determine whether to insert or update
        if (dependent.getBenefitMemberId() == null || dependent.getBenefitMemberId().isEmpty()) {
            // No member ID provided, treat as an insert request
            log.info("No member ID provided, treating as an insert request");

            return insertNewDependent(dependent);
        } else {
            // Member ID provided, treat as an update request
            log.info("Member ID {} provided, treating as an update request", dependent.getBenefitMemberId());
            return updateExistingDependent(dependent);
        }
    }
    
    /**
     * Updates an existing dependent record
     * Uses retry template to handle Cosmos DB conflicts (412 errors)
     */
    private Dependent updateExistingDependent(Dependent dependent) {
        return retryTemplate.execute(context -> {
            try {
                // First, check if the record exists and get its current state
                DependentDO existingDependentDO;
                existingDependentDO = fetchDependentById(dependent);
                encryptSensitiveFields(dependent);
                
                // If we get here, the record exists and we can update it
                DependentDO dependentDO = mapper.fromDependent(dependent);
                dependentDO.setId(existingDependentDO.getId());
                dependentDO.set_eTag(existingDependentDO.get_eTag());
                dependentDO.setVersion(existingDependentDO.getVersion() + 1);
                dependentDO.setActive(existingDependentDO.isActive());
                DependentDO savedDependent = dependentRepository.save(dependentDO);
                return mapper.fromDependentDO(savedDependent);
            } catch (CosmosException e) {
                if (e.getStatusCode() == 412) {
                    log.warn("Conflict detected when updating dependent {}. Retrying with latest data...", dependent.getBenefitMemberId());
                    DependentDO refreshedDependentDO = getDependentByBenefitMemberId(dependent.getBenefitMemberId());
                    DependentDO dependentDO = mapper.fromDependent(dependent);
                    dependentDO.setId(refreshedDependentDO.getId());
                    dependentDO.set_eTag(refreshedDependentDO.get_eTag());
                    dependentDO.setVersion(refreshedDependentDO.getVersion() + 1);
                    dependentDO.setActive(refreshedDependentDO.isActive());
                    DependentDO savedDependent = dependentRepository.save(dependentDO);
                    return mapper.fromDependentDO(savedDependent);
                }
                throw e;
            }
        });
    }

    private DependentDO fetchDependentById(Dependent dependent) {
        try {
            return getDependentByBenefitMemberId(dependent.getBenefitMemberId());
        } catch (ResourceNotFoundException e) {
            log.warn("Attempted to update non-existent member with ID: {}", dependent.getBenefitMemberId());
            throw new ResourceNotFoundException("Cannot update non-existent member with ID: " + dependent.getBenefitMemberId());
        }
    }
    
    /**
     * Inserts a new dependent record using strict insert to prevent accidental overwrites
     * Uses retry template to handle Cosmos DB conflicts (409 errors)
     * Generates a new member ID if needed
     */
    private Dependent insertNewDependent(Dependent dependent) {
        return retryTemplate.execute(context -> {
            try {
                // Always generate a new member ID for insert requests
                String latestMemberId;
                latestMemberId = fetchLatestMemberId();

                // Generate a new unique member ID
                String newMemberId = sequnceGeneratorService.generateUniqueMemberId(latestMemberId);
                
                // Ensure member ID is exactly 8 digits
                if (newMemberId.length() > 8) {
                    throw new ValidationException("Benefit Id cannot be more than 8 digits");
                }
                
                dependent.setBenefitMemberId(newMemberId);
                log.info("Generated new member ID: {} for new dependent", newMemberId);
                encryptSensitiveFields(dependent);
                
                // Map to DependentDO and prepare for insertion
                DependentDO dependentDO = mapper.fromDependent(dependent);
                dependentDO.setId(UUID.randomUUID().toString());
                dependentDO.setVersion(1);
                dependentDO.setActive(true);
                
                return handleResourceAlreadyException(dependent, newMemberId, dependentDO);
            } catch (Exception e) {
                log.error("Error inserting new dependent", e);
                throw e;
            }
        });
    }

    private String fetchLatestMemberId() {
        String latestMemberId;
        try {
            List<DependentDO> dependentDOList = dependentRepository.findTopByOrderByBenefitMemberIdDesc();
            // Default starting value - ensure it's 8 digits
            latestMemberId = dependentDOList.isEmpty() ? "10000000" : dependentDOList.get(0).getBenefitMemberId();
        } catch (Exception e) {
            log.warn("Error fetching latest member ID, using default value", e);
            latestMemberId = "10000000"; // Default starting value - ensure it's 8 digits
        }
        return latestMemberId;
    }

    private Dependent handleResourceAlreadyException(Dependent dependent, String newMemberId, DependentDO dependentDO) {
        // Use the strict insert method instead of save
        try {
            DependentDO savedDependent = dependentRepository.insertStrict(dependentDO);
            return mapper.fromDependentDO(savedDependent);
        } catch (ResourceAlreadyExistsException e) {
            log.warn("Conflict detected: A dependent with memberId {} already exists. Generating new ID and retrying...", 
                    dependentDO.getBenefitMemberId());
            
            // If we get a conflict (which shouldn't happen with a newly generated ID, but just in case),
            // generate a new ID and try again
            String newerMemberId = sequnceGeneratorService.generateUniqueMemberId(newMemberId);
            
            // Ensure the newly generated ID is also exactly 8 digits
            if (newerMemberId.length() > 8) {
                throw new ValidationException("Benefit Id cannot be more than 8 digits");
            } 
            
            dependent.setBenefitMemberId(newerMemberId);
            log.info("Generated another member ID: {} after conflict", newerMemberId);
            
            // Try again with the new ID
            DependentDO newDependentDO = mapper.fromDependent(dependent);
            newDependentDO.setId(UUID.randomUUID().toString());
            newDependentDO.setVersion(1);
            newDependentDO.setActive(true);
            
            DependentDO savedDependent = dependentRepository.insertStrict(newDependentDO);
            return mapper.fromDependentDO(savedDependent);
        }
    }

    @Override
    public Dependent deleteDependent(String benefitMemberId) {
        if(benefitMemberId == null || benefitMemberId.isEmpty()) {
            throw new IllegalArgumentException("BenefitMemberId cannot be null or empty");
        }
        
        return retryTemplate.execute(context -> {
            try {
                DependentDO dependentDO = getDependentByBenefitMemberId(benefitMemberId);
                
                dependentDO.setActive(false);
                
                encryptSensitiveFields(dependentDO);
                
                return mapper.fromDependentDO(dependentRepository.save(dependentDO));
            } catch (CosmosException e) {
                if (e.getStatusCode() == 412) {
                    log.warn("Conflict detected when deleting dependent {}. Retrying with latest data...", benefitMemberId);
                    DependentDO refreshedDependentDO = getDependentByBenefitMemberId(benefitMemberId);
                    refreshedDependentDO.setActive(false);
                    return mapper.fromDependentDO(dependentRepository.save(refreshedDependentDO));
                }
                throw e;
            }
        });
    }

    @Override
    public Map<String, String> getDecryptedInfo(List<FPERecord> fpeRecordList) {
        return Map.of();
    }
}
