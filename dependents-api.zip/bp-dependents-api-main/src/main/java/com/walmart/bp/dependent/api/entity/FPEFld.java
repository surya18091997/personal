package com.walmart.bp.dependent.api.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FPEFld {
    private String ssn = "";
    private String city = "";
    private String zip = "";
    private String phone = "";
}
