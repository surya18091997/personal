package com.walmart.bp.dependent.api.common.health;//
//package com.walmart.bp.assessment.api.common.health;
//
//import java.net.InetAddress;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.entity.factory.annotation.Autowired;
//import org.springframework.entity.factory.annotation.Value;
//import org.springframework.boot.actuate.health.Health;
//import org.springframework.boot.actuate.health.HealthIndicator;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.util.DefaultUriBuilderFactory;
//
///**
// * Health indicator for the Swagger endpoint.
// * <p>
// * This class implements the HealthIndicator interface to provide a custom health check for the
// * Swagger endpoint. It checks if the Swagger API documentation is accessible and returns the
// * appropriate health status.
// */
//@Component
//public class SwaggerHealthIndicator implements HealthIndicator {
//
//  @Value("${service-key:BP-PLAN-CONFIG-API-BP-PLAN-CONFIG-API}")
//  private String serviceName;
//  @Value("${server.port:8080}")
//  int serverPort;
//
//  @Override
//  public Health health() {
//
//    RestTemplate restTemplate = new RestTemplate();
//
//    // Set default uri
//    String baseUri = String.format("http://%s:%d", InetAddress.getLoopbackAddress().getHostName(),
//        serverPort);
//    restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(baseUri));
//
//    Health health = Health.unknown().build();
//
//    try {
//      // WM_SVC.NAME Required for requests
//      HttpHeaders httpHeaders = new HttpHeaders();
//      httpHeaders.add("WM_SVC.NAME", serviceName);
//      HttpEntity<String> swaggerHealthRequest = new HttpEntity<String>(httpHeaders);
//
//      // Ensure that Swagger Endpoint is reachable
//      ResponseEntity<String> response = restTemplate.exchange("/v2/api-docs",
//          HttpMethod.GET,
//          swaggerHealthRequest, String.class);
//
//      if (response.getStatusCode() == HttpStatus.OK) {
//        health = Health.up().withDetail("swagger", "isUp").build();
//      } else {
//        health = Health.down().withDetail("info", "Endpoint unavailable").build();
//      }
//    } catch (Exception e) {
//      health = Health.down().withDetail("error", e.getMessage()).build();
//    }
//
//    return health;
//  }
//}
//
