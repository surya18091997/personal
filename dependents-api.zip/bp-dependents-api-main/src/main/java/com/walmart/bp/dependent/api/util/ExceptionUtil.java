package com.walmart.bp.dependent.api.util;

public class ExceptionUtil {

    public static String getExceptionStackTrace(Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.getMessage()).append("--");
        for (StackTraceElement element : e.getStackTrace()) {
            sb.append("--").append(element).append("--");
        }
        return sb.toString();
    }
}

