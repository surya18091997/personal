package com.walmart.bp.dependent.api.common.util;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
@Slf4j
public class ExternalRequestHandler {

    @Autowired
    private Environment env;

    public <Q, R> R post(String url, Q request, HttpHeaders inputHeaders, Class<R> responseClass) {
        HttpClient httpClient = HttpClient.create()
                .secure(sslContextSpec -> {
                    try {
                        SslContext sslContext = SslContextBuilder.forClient()
                                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                                .build();
                        sslContextSpec.sslContext(sslContext);
                    } catch (SSLException e) {
                        throw new RuntimeException("Error configuring SSL context", e);
                    }
                });
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build()
                .post()
                .uri(url)
                .headers(httpHeaders -> setHeaders(inputHeaders, httpHeaders))
                .body(Mono.just(request), request.getClass())
                .retrieve()
                .bodyToMono(responseClass)
                .block();
    }

    private void setHeaders(HttpHeaders inputHeaders, HttpHeaders httpHeaders) {
        if(inputHeaders != null)
            httpHeaders.setAll(inputHeaders.toSingleValueMap());

        httpHeaders.addIfAbsent(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.addIfAbsent(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    }
}