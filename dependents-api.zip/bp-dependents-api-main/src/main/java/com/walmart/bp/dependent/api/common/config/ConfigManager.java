package com.walmart.bp.dependent.api.common.config;


import io.strati.configuration.annotation.ManagedConfiguration;
import io.strati.configuration.annotation.PostRefresh;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Pull CCM properties from a local directory.
 */
@ConditionalOnProperty(name = "ccm.configs.dir")
@ComponentScan(basePackages = "io.strati.tunr.utils.client")
@Configuration
public class ConfigManager {

  private static final Logger LOGGER = LoggerFactory.getLogger(ConfigManager.class);

  @ManagedConfiguration
  private AppConfig appConfig;

  @ManagedConfiguration
  private SecretConfig dbSecretConfig;

  /**
   * Build a DataSource based off the local directory CCM configs.
   */

  @PostRefresh
  public void refreshConfig() {
    List<String> strings = new ArrayList<>();

    try (Stream<Path> paths = Files.walk(Paths.get(System.getProperty("ccm.configs.dir")))) {
      paths.filter(Files::isRegularFile)
        .map(Path::toFile)
        .filter(File::isFile)
        .filter(file -> file.getName().toLowerCase().endsWith(".properties"))
        .forEach(file -> {
          try {
            //strings.addAll(Files.readAllLines(file.toPath(), Charset.defaultCharset()));
            FileUtils.readFileToString(file, StandardCharsets.UTF_8);
            strings.addAll(Collections.singleton(FileUtils.readFileToString(file, StandardCharsets.UTF_8)));
          } catch (IOException e) {
            LOGGER.error("runtime error");
          }
        });

      Map<String, String> propMap = strings.stream()
        .map(s -> s.split("=", 2))
        .filter(item -> item.length > 1)
        .collect(Collectors.toMap(map -> map[0], map -> map.length > 1 ? map[1] : ""));

      for (Map.Entry<String, String> props : propMap.entrySet()) {
        System.setProperty(props.getKey(), props.getValue());
      }
    } catch (IOException e) {
      LOGGER.error("file error");
    }
  }


}
