package com.walmart.bp.dependent.api.exceptions;

public class DependentException extends RuntimeException {

    public DependentException(String message) {
        super(message);
    }
}
