package com.walmart.bp.dependent.api.models;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.GeneratedValue;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@Container(containerName = "dependent")
public class DependentDO extends Dependent {

    @PartitionKey
    private String benefitMemberId;

    @Id
    @GeneratedValue
    private String id;

    // Enable optimistic locking
    @Version
    private String _eTag;

    private boolean isActive;
}
