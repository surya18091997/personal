package com.walmart.bp.dependent.api.common.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;


@Configuration
@ConfigurationProperties(prefix="serviceregistry")
public class ServiceRegistryConfig {

    private Map<String, ServiceRegistry> sr;

    public Map<String, ServiceRegistry> getSr() {
        return sr;
    }

    public void setSr(Map<String, ServiceRegistry> sr) {
        this.sr = sr;
    }

    public static class ServiceRegistry{
        private String envName;
        private String consumerId;
        private String keyVersion;
        private String serviceName;
        public String getServiceName() {
            return serviceName;
        }
        public void setServiceName(String serviceName) {
            this.serviceName = serviceName;
        }
        public String getEnvName() {
            return envName;
        }
        public void setEnvName(String envName) {
            this.envName = envName;
        }
        public String getConsumerId() {
            return consumerId;
        }
        public void setConsumerId(String consumerId) {
            this.consumerId = consumerId;
        }
        public String getKeyVersion() {
            return keyVersion;
        }
        public void setKeyVersion(String keyVersion) {
            this.keyVersion = keyVersion;
        }
    }
}