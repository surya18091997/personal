package com.walmart.bp.dependent.api.repositories;

import com.walmart.bp.dependent.api.exceptions.ResourceAlreadyExistsException;
import com.walmart.bp.dependent.api.models.DependentDO;

import java.util.Optional;

/**
 * Custom repository interface for Dependent operations that require special handling
 */
public interface CustomDependentRepository {
    
    /**
     * Inserts a new dependent record, ensuring it's a strict insert operation.
     * Will fail if a record with the same benefitMemberId already exists.
     * 
     * @param dependent The dependent to insert
     * @return The saved dependent
     * @throws ResourceAlreadyExistsException if a record with the same benefitMemberId already exists
     */
    DependentDO insertStrict(DependentDO dependent) throws ResourceAlreadyExistsException;

}