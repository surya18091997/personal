package com.walmart.bp.dependent.api.exceptions;

public class SequenceGenerationException extends RuntimeException {

    public SequenceGenerationException(String message, Throwable cause) {
        super(message, cause);
    }
}
