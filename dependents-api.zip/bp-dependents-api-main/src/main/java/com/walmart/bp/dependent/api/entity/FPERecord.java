package com.walmart.bp.dependent.api.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class FPERecord {
    private String id = "";
    private FPEFld fpeFld;
}
