package com.walmart.bp.dependent.api.common.security;

//import io.strati.libs.google.common.collect.ImmutableList;

import com.google.common.collect.ImmutableList;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

/**
 * Overrides web security with the below configuration.
 */
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.cors().and()
      .csrf()
      .disable();
    // If your application needs CSRF enabled (which we recommend if the API services a UI)
    // comment the above line with 'disable()' and uncomment below CSRF configuration
    // Uncomment this block when enabling CSRF
    /*
        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).and()
        .headers()
        .contentSecurityPolicy("default-src 'self'; img-src 'self' data:; "
          + "script-src 'self' 'sha256-znd+NctPm874Via52u+V9h1LbMDYA4I/kHHDjZgIM7s=' "
          + "'sha256-epfHad2QZXZLgp6wYaCqbNFkXh59Q4UDNhZGymAervc='; style-src 'self' "
          + "'sha256-pyVPiLlnqL9OWVoJPs/E6VVF5hBecRzM2gBiarnaqAo=' "
          + "'sha256-/jDKvbQ8cdux+c5epDIqkjHbXDaIY8RucT1PmAe8FG4=' "
          + "'sha256-ezdv1bOGcoOD7FKudKN0Y2Mb763O6qVtM8LT2mtanIU=' 'unsafe-hashes';");
     */

    /*
      All inline scripts and stylesheet needs to be converted to sha256 to allow them to be
      executed in content security policy inline scripts can be converted to sha256 using
      websites like - https://report-uri.com/home/hash Copy inline scripts or stylesheets and
      paste in textbox. This will generate sha256 hash which can be used in csp.
    */
  }

  @Bean
  CorsConfigurationSource corsConfigurationSource() {

    CorsConfiguration configuration = new CorsConfiguration();
    configuration.setAllowedOriginPatterns(Arrays.asList("https://*.walmart.net", "https://*.walmart.com", "https://*.wal-mart.com"));
    configuration.setAllowedHeaders(
      Arrays.asList("Origin", "Content-Type", "Accept", "responseType", "Authorization"));
    configuration.setAllowedMethods(ImmutableList.of("GET", "POST", "PUT", "OPTIONS", "DELETE"));
    configuration.setMaxAge(3600L);
    configuration.setAllowCredentials(true);
    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", configuration);

    return source;
  }
}
