package com.walmart.bp.dependent.api.controllers;

import com.walmart.bp.dependent.api.services.SequnceGeneratorService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST controller for managing sequence operations.
 * Provides endpoints for retrieving and generating sequence values.
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping("/sequences")
public class SequenceController {

    private final SequnceGeneratorService sequenceGeneratorService;
    
    /**
     * Gets the current value of a sequence without incrementing it.
     * This is useful for testing and monitoring.
     * 
     * @param sequenceType The type of sequence to check
     * @return The current sequence value, or null if the sequence doesn't exist
     */
    @GetMapping(value = "/{sequenceType}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public Long getCurrentSequenceValue(@PathVariable("sequenceType") String sequenceType) {
        log.info("Getting current value for sequence type: {}", sequenceType);
        return sequenceGeneratorService.getCurrentSequenceValue(sequenceType);
    }
    
    /**
     * Generates a new unique value for the specified sequence type.
     * This will increment the sequence and return the new value.
     * 
     * @param sequenceType The type of sequence to increment
     * @return The new sequence value after incrementing
     */
    @PostMapping(value = "/{sequenceType}/generate", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public String generateNextSequenceValue(@PathVariable("sequenceType") String sequenceType) {
        log.info("Generating next value for sequence type: {}", sequenceType);
        return sequenceGeneratorService.generateUniqueMemberId(sequenceType);
    }
    
    /**
     * Sets the value of a sequence to a specific number.
     * This is useful for initializing a sequence with a specific starting value.
     * 
     * @param sequenceType The type of sequence to set
     * @param requestBody A map containing the value to set
     * @return A confirmation message
     */
    @PutMapping(value = "/{sequenceType}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public Map<String, String> setSequenceValue(
            @PathVariable("sequenceType") String sequenceType,
            @RequestBody Map<String, Long> requestBody) {
        
        Long value = requestBody.get("value");
        if (value == null) {
            throw new IllegalArgumentException("Request body must contain a 'value' field");
        }
        
        log.info("Setting value for sequence type: {} to: {}", sequenceType, value);
        sequenceGeneratorService.setSequenceValue(sequenceType, value);
        
        return Map.of("message", "Sequence value set successfully", 
                     "sequenceType", sequenceType, 
                     "value", String.valueOf(value));
    }
}