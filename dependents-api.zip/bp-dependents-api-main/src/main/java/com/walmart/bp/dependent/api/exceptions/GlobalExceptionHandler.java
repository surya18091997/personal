package com.walmart.bp.dependent.api.exceptions;

import com.walmart.bp.dependent.api.util.ExceptionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handle ResourceNotFoundException and return HTTP 404.
     * @param ex the exception
     * @return ResponseEntity with error message and HTTP status 404
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException ex) {
        LOGGER.error("ResourceNotFoundException: {}", ExceptionUtil.getExceptionStackTrace(ex));
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    /**
     * Handle AssessmentException and return HTTP 500.
     * @param ex the exception
     * @return ResponseEntity with error message and HTTP status 500
     */
    @ExceptionHandler(DependentException.class)
    public ResponseEntity<String> handleAssessmentException(DependentException ex) {
        LOGGER.error("AssessmentException: {}", ExceptionUtil.getExceptionStackTrace(ex));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
    }

    /**
     * Handle IllegalArgumentException and return HTTP 400.
     * @param ex the exception
     * @return ResponseEntity with error message and HTTP status 400
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
        LOGGER.error("IllegalArgumentException: {}", ExceptionUtil.getExceptionStackTrace(ex));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

    /**
     * Handle all other exceptions and return HTTP 500.
     * @param ex the exception
     * @return ResponseEntity with generic error message and HTTP status 500
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception ex) {
        LOGGER.error("Unexpected Exception: {}", ExceptionUtil.getExceptionStackTrace(ex));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred: " + ex.getMessage());
    }
}
