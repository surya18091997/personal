package com.walmart.bp.dependent.api.common.config;


import com.walmart.bp.dependent.api.exceptions.ResourceAlreadyExistsException;
import com.walmart.bp.dependent.api.exceptions.ResourceNotFoundException;
import com.walmart.bp.dependent.api.exceptions.SequenceGenerationException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.NeverRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class BeanConfig {

    /**
     * Configure a RetryTemplate with a backoff of 2 seconds and a maximum of 3 retries,
     * excluding retries for ResourceNotFoundException and ResourceAlreadyExistsException.
     * @return RetryTemplate
     */
    @Bean
    public RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();

        // Configure backoff policy
        FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(2000); // 2 seconds
        retryTemplate.setBackOffPolicy(backOffPolicy);

        // Configure retry policy
        ExceptionClassifierRetryPolicy retryPolicy = new ExceptionClassifierRetryPolicy();
        Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<>();
        policyMap.put(ResourceNotFoundException.class, new NeverRetryPolicy());
        policyMap.put(ResourceAlreadyExistsException.class, new NeverRetryPolicy());
        policyMap.put(SequenceGenerationException.class, new SimpleRetryPolicy(10));
        policyMap.put(Exception.class, new SimpleRetryPolicy(3)); // Retry 3 times for other exceptions
        retryPolicy.setPolicyMap(policyMap);

        retryTemplate.setRetryPolicy(retryPolicy);

        return retryTemplate;
    }
}
