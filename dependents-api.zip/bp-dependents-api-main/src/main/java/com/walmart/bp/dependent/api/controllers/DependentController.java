package com.walmart.bp.dependent.api.controllers;

import com.walmart.benefitsplatformentitymodel.intradomain.dependent.Dependent;
import com.walmart.bp.dependent.api.services.DependentService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping("/dependents")
public class DependentController {

    private final DependentService dependentService;

    @GetMapping(value = "/{benefitMemberId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public Dependent getDependentByBenefitMemberId(@PathVariable("benefitMemberId") String benefitMemberId) {
        log.info("Retrieving dependent for benefitMemberId: {}", benefitMemberId);
        Dependent dependent = dependentService.getDependentByBenefitMemberId(benefitMemberId);

        /*List<FPERecord> fpeRecordList = new ArrayList<>();
        FPEFld fpeFld = new FPEFld();
        fpeFld.setCity(dependent.getDependentProfile().getAddress().get(0).getCity());
        fpeFld.setZip(dependent.getDependentProfile().getAddress().get(0).getZip());
        fpeFld.setSsn(dependent.getDependentProfile().getNationalId());
        fpeFld.setPhone(dependent.getDependentProfile().getContacts().getPhoneNumber());

        FPERecord fpeRecord = new FPERecord("benefitMemberId", fpeFld);
        fpeRecord.setId("12345");
        fpeRecordList.add(fpeRecord);

        log.info(dependentService.getDecryptedInfo(fpeRecordList).toString());*/
        return dependent;
    }

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Dependent> getAllDependents() {
        return dependentService.getAllDependents();
    }

    @PostMapping("/upsert")
    public Dependent upsertDependent(@RequestBody Dependent dependent) {
        log.info("Upserting dependent for benefitMemberId: {}", dependent.getBenefitMemberId());
        /* if (dependent.getBenefitMemberId() == null || dependent.getBenefitMemberId().isEmpty()) {
            throw new ValidationException("Benefit Member ID is not valid");
        } */
        return dependentService.upsertDependent(dependent);
    }

    @DeleteMapping("/{benefitMemberId}")
    public Dependent deleteDependent(@PathVariable("benefitMemberId") String benefitMemberId) {
        log.info("Deleting dependent for benefitMemberId: {}", benefitMemberId);
        return dependentService.deleteDependent(benefitMemberId);
    }
}
