package com.walmart.bp.dependent.api.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;

/**
 * Interface with functions that get us default messages from CCM.
 */
@Configuration(configName = "application")
public interface AppConfig {

  // Default product description
  String getDefaultDescription();

  @Property(propertyName = "spring.datasource.driverClassName")
  String getDriverClassName();

  @Property(propertyName = "spring.datasource.url")
  String getDatasourceUrl();

  @Property(propertyName = "spring.jpa.hibernate.dialect")
  String getDialect();

  @Property(propertyName = "spring.jpa.show-sql")
  String getShowSql();

  @Property(propertyName = "spring.jpa.hibernate.ddl-auto")
  String getDdlAuto();

}
