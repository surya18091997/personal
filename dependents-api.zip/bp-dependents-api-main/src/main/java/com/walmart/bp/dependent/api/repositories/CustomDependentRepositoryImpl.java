package com.walmart.bp.dependent.api.repositories;

import com.azure.cosmos.CosmosException;
import com.azure.cosmos.models.PartitionKey;
import com.azure.cosmos.models.SqlParameter;
import com.azure.cosmos.models.SqlQuerySpec;
import com.azure.spring.data.cosmos.core.CosmosTemplate;
import com.walmart.bp.dependent.api.exceptions.ResourceAlreadyExistsException;
import com.walmart.bp.dependent.api.models.DependentDO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static com.walmart.bp.dependent.api.util.ApplicationConstant.DEPENDENT_CONTAINER;

/**
 * Implementation of CustomDependentRepository that provides strict insert operations
 */
@Component
public class CustomDependentRepositoryImpl implements CustomDependentRepository {

    private static final Logger log = LoggerFactory.getLogger(CustomDependentRepositoryImpl.class);
    private final CosmosTemplate cosmosTemplate;
    
    @Autowired
    public CustomDependentRepositoryImpl(CosmosTemplate cosmosTemplate) {
        this.cosmosTemplate = cosmosTemplate;
    }
    
    @Override
    public DependentDO insertStrict(DependentDO dependent) throws ResourceAlreadyExistsException {
        if (dependent == null) {
            throw new IllegalArgumentException("Dependent cannot be null");
        }
        
        try {
            // Check if a document with the same benefitMemberId already exists
            // Use SqlQuerySpec instead of a String for the query
            String queryStr = "SELECT VALUE COUNT(1) FROM c WHERE c.benefitMemberId = @memberId";
            SqlQuerySpec querySpec = new SqlQuerySpec(queryStr)
                .setParameters(Collections.singletonList(
                    new SqlParameter("@memberId", dependent.getBenefitMemberId())
                ));
            
            Iterable<Integer> results = cosmosTemplate.runQuery(
                querySpec, 
                DependentDO.class,
                Integer.class
            );
            
            Iterator<Integer> iterator = results.iterator();
            if (iterator.hasNext()) {
                Integer count = iterator.next();
                if (count > 0) {
                    throw new ResourceAlreadyExistsException(
                        "A dependent with benefitMemberId " + dependent.getBenefitMemberId() + " already exists");
                }
            }
            
            // For Azure Cosmos DB SDK 5.19.0, we'll use standard insert with proper parameters
            try {
                // Use the insert method with partition key
                PartitionKey partitionKey = new PartitionKey(dependent.getBenefitMemberId());
                return cosmosTemplate.insert(DEPENDENT_CONTAINER, dependent, partitionKey);
            } catch (CosmosException e) {
                if (e.getStatusCode() == 409) { // 409 = Conflict
                    log.warn("Conflict detected: A dependent with memberId {} already exists", dependent.getBenefitMemberId());
                    throw new ResourceAlreadyExistsException(
                            "A dependent with benefitMemberId " + dependent.getBenefitMemberId() + " already exists", e);
                }
                throw e;
            }
        } catch (ResourceAlreadyExistsException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error during strict insert operation", e);
            throw e;
        }
    }
    

}