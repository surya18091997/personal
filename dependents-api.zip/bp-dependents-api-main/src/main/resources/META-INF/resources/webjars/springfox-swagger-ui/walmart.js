const authorizeButton = document.getElementsByClassName("btn authorize unlocked");

var authorizeObserver = new MutationObserver(function() {
    for (var i = 0; i < authorizeButton.length; i++) {
        if (window.addEventListener) {
            authorizeButton[i].addEventListener('click', renderAuthorization, false);
        } else if (window.attachEvent) {
            authorizeButton[i].attachEvent("onclick", renderAuthorization);
        } else {
            authorizeButton[i]["onclick"] = renderAuthorization;
        }

        authorizeObserver.disconnect();
    }
});

authorizeObserver.observe(document.getElementById("swagger-ui"), { attributes: false, childList: true, subtree: true });

const secureButton = document.getElementsByClassName("authorization__btn unlocked");

var secureObserver = new MutationObserver(function() {
    for (var i = 0; i < secureButton.length; i++) {
        if (window.addEventListener) {
            secureButton[i].addEventListener('click', renderAuthorization, false);
        } else if (window.attachEvent) {
            secureButton[i].attachEvent("onclick", renderAuthorization);
        } else {
            secureButton[i]["onclick"] = renderAuthorization;
        }

        secureObserver.disconnect();
    }
});

secureObserver.observe(document.getElementById("swagger-ui"), { attributes: false, childList: true, subtree: true });



var renderAuthorization = function() {
    const authElements = document.getElementsByClassName("auth-container");

    var containerObserver = new MutationObserver(function() {
        for (var i = 0; i < authElements.length; i++) {
            //console.log(authElements[i].firstChild.lastChild);
            authElements[i].firstChild.firstChild.firstChild.removeChild(authElements[i].firstChild.firstChild.firstChild.firstChild);
            if(authElements[i].firstChild.firstChild.firstChild.children.length == 4) {
                authElements[i].firstChild.firstChild.firstChild.removeChild(authElements[i].firstChild.firstChild.firstChild.children[2]);
            }
            else {
                authElements[i].firstChild.firstChild.firstChild.removeChild(authElements[i].firstChild.firstChild.firstChild.children[3]);
            }
            authElements[i].firstChild.lastChild.classList.add("hide");
            containerObserver.disconnect();
        }

        if(authElements.length > 0) {
            const authorizeButton = document.createElement("button");
            authorizeButton.innerText = "Authorize";
            const authorizeButtonClass = document.createAttribute("class");
            authorizeButtonClass.value = "btn modal-btn auth authorize button";
            authorizeButton.setAttributeNode(authorizeButtonClass);
            const authorizeButtonId = document.createAttribute("id");
            authorizeButtonId.value = "authorize-button";
            authorizeButton.setAttributeNode(authorizeButtonId);
            const authorizeButtonClick = document.createAttribute("onclick");
            authorizeButtonClick.value = "authorize()";
            authorizeButton.setAttributeNode(authorizeButtonClick);

            const logoutButton = document.createElement("button");
            logoutButton.innerText = "Logout";
            const logoutButtonClass = document.createAttribute("class");
            logoutButtonClass.value = "btn modal-btn auth button";
            logoutButton.setAttributeNode(logoutButtonClass);
            const logoutButtonId = document.createAttribute("id");
            logoutButtonId.value = "logout-button";
            logoutButton.setAttributeNode(logoutButtonId);
            const logoutButtonClick = document.createAttribute("onclick");
            logoutButtonClick.value = "logout()";
            logoutButton.setAttributeNode(logoutButtonClick);

            const buttonContainer = document.createElement("div");
            const buttonContainerClass = document.createAttribute("class");
            buttonContainerClass.value = "auth-btn-wrapper";
            buttonContainer.setAttributeNode(buttonContainerClass);

            buttonContainer.appendChild(authorizeButton);
            buttonContainer.appendChild(logoutButton);

            document.getElementsByClassName("modal-ux-content")[0].appendChild(buttonContainer);

            const uxContentContainer = document.getElementsByClassName("modal-ux-content");
            const inputs = uxContentContainer[0].getElementsByTagName("input");

            if(inputs.length > 0) {
                document.getElementById('authorize-button').classList.remove("hide");
                document.getElementById('authorize-button').classList.add("show");
                document.getElementById('logout-button').classList.remove("show");
                document.getElementById('logout-button').classList.add("hide");

            }
            else {
                document.getElementById('authorize-button').classList.remove("show");
                document.getElementById('authorize-button').classList.add("hide");
                document.getElementById('logout-button').classList.remove("hide");
                document.getElementById('logout-button').classList.add("show");
            }
        }
    });

    containerObserver.observe(document.getElementById("swagger-ui"), { attributes: false, childList: true, subtree: true });
}

var authorize = function() {

    const uxContentContainer = document.getElementsByClassName("modal-ux-content");
    const inputs = uxContentContainer[0].getElementsByTagName("input");
    var submitEligible = true;

    for (var i = 0; i < inputs.length; i++) {
        if(inputs[i].value == null || inputs[i].value == "") {
            submitEligible = false;
            break;
        }
    }

    if(submitEligible) {
        const submitButtons = uxContentContainer[0].getElementsByTagName("button");

        for (var i = 0; i < submitButtons.length; i++) {
            if(submitButtons[i].getAttribute("type") != null && submitButtons[i].getAttribute("type") == "submit") {
                submitButtons[i].click();
            }
        }

        document.getElementById('authorize-button').classList.remove("show");
        document.getElementById('authorize-button').classList.add("hide");
        document.getElementById('logout-button').classList.remove("hide");
        document.getElementById('logout-button').classList.add("show");
    }
}

var logout = function() {

    const uxContentContainer = document.getElementsByClassName("modal-ux-content");
    const logoutButtons = uxContentContainer[0].getElementsByTagName("button");

    for (var i = 0; i < logoutButtons.length; i++) {
        if(logoutButtons[i].getAttribute("id") != "logout-button" && logoutButtons[i].innerText == "Logout") {
            logoutButtons[i].click();
        }
    }

    document.getElementById('authorize-button').classList.remove("hide");
    document.getElementById('authorize-button').classList.add("show");
    document.getElementById('logout-button').classList.remove("show");
    document.getElementById('logout-button').classList.add("hide");
}
