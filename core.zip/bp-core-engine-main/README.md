# benefits-platform-core-engine


### Prerequisites

Setup Local Vault Secrets  

1. Create a directory named vault in your home dir EX:(/Users/<user_name>/vault)
2. Make a file called `camunda.ldap`in the vault directory with contents like below
_NOTE: You will need to replace the below username and password with an active LDAP account, typically an SVC account but personal login credentials will work for a local setup.

```
{
  "username": "...@homeoffice.wal-mart.com",
  "password": "..."
}
```
3. Add the path to the file in the application.yaml
```
spring:
  profiles: local
  datasource:
    driver-class-name: org.h2.Driver
    url: jdbc:h2:mem:db;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
    username: sa
camunda:
  ldap:
    acceptUntrustedCertificates: true
vault:
  path: <YOUR_LOCAL_VAULT_PATH> EX:(/Users/<user_name>/vault)
```

### Building, and Running Your App Locally

1. Clone repo.
2. CD into the cloned repo.
3. Change the vault.path property in the application.yaml to the path of your local vault directory EX:(/Users/<user_name>/vault)
4. Install the app with `mvn clean install`.
5. Start the app in local-mode with `mvn -Dspring-boot.run.profiles=local -Dspring.env=dev spring-boot:run`.
6. You can then access the app at http://localhost:8080

### Building, and Deploying Your App to WCNP

_NOTE: Before you deploy your app into WCNP
1. Go to the [Vault](https://prod.master.enterprisevault.glb.us.walmart.net:8200/ui/vault/secrets/secret?namespace=k8s) under your AD-Group using all lowercase letters make a secret with the path <YOUR_AD_GROUP>/camunda/dev
_NOTE: You will also need to make one for stage and prod when promoting your application to stage and production.
2. Make a key for db_password (The password for your Database user).
3. camunda.ldap (The LDAP information for authenticating with LDAP use the same JSON format as above).
