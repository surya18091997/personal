package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;

@Slf4j
@Service
public class DefaultEnrollmentCompleteRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public DefaultEnrollmentCompleteRuleRequestProcessor() {
        super(ENROLLMENT_COMPLETE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.debug("Default Enrollment Complete Rule Request Processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        AssociateEligibilityInput associateEligibilityInput = (AssociateEligibilityInput) delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT);
        Enrollment enrollment = (Enrollment) variables.get(ENROLLMENT);
        AssociateBenefitsProfile associateBenefitsProfile = (AssociateBenefitsProfile) variables.get(GET_ASSOCIATE_PROFILE_RESPONSE);

        List<PlanEligibility> allEligiblePlans = associateBenefitsProfile.getEligibility().getPlans();
        List<String> allEligiblePlanIds = allEligiblePlans.stream()
                .map(PlanEligibility::getPlanId)
                .map(String::toUpperCase)
                .toList();
        delegateExecution.setVariable(PLAN_ID_LIST, allEligiblePlanIds);

        String changeActivity = enrollment.getActivity().toString().toUpperCase();
        associateEligibilityInput.setChangeActivity(changeActivity);
        associateEligibilityInput.setSessionDate(associateEvent.getTimeStamp());
        delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);

        log.debug("Default Enrollment Complete Rule Request Processor completed");
        super.process(delegateExecution);
    }

    @Override
    public EventType getEventType() {
        return ENROLLMENT_COMPLETE;
    }
    @Override
    public String getPlanType() { return null; }
}
