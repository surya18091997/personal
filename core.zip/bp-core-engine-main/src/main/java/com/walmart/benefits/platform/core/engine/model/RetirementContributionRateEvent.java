package com.walmart.benefits.platform.core.engine.model;

public class RetirementContributionRateEvent {
    private String planNumber;
    private String transactionId;
    private Double rateChanged;

    public String getPlanNumber() {
        return planNumber;
    }

    public void setPlanNumber(String planNumber) {
        this.planNumber = planNumber;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Double getRateChanged() {
        return rateChanged;
    }

    public void setRateChanged(Double rateChanged) {
        this.rateChanged = rateChanged;
    }
}
