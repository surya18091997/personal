package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

@Component
public class ConverterUtil {
    private static final ModelMapper modelMapper = new ModelMapper();

    private ConverterUtil() {}

    public static <T> T convertToObject(Object map, Class<T> clazz) {
        return modelMapper.map(map, clazz);
    }

    public static String convertDateFormat(String  eligibleFrom) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(MM_DD_YYYY);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        LocalDate date = LocalDate.parse(eligibleFrom, inputFormatter);
        return date.format(outputFormatter);
    }

    public static String convertDateToRuleExpectedFormat(String  eligibleFrom) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(MM_DD_YYYY);
        LocalDate date = LocalDate.parse(eligibleFrom, inputFormatter);
        return date.format(outputFormatter);
    }

    public static String convertTimestampDate(String timeStamp) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(ISO_DATE_TIME_FORMAT);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        LocalDate date = LocalDate.parse(timeStamp, inputFormatter);
        return date.format(outputFormatter);
    }

    public static String convertTimestampToRuleExpectedFormat(String timeStamp) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD_T_HH_MM_SS);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(MM_DD_YYYY);
        LocalDate date = LocalDate.parse(timeStamp, inputFormatter);
        return date.format(outputFormatter);
    }

    public static LocalDate convertStringToDate(String dateStr) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        LocalDate date = LocalDate.parse(dateStr, inputFormatter);
        return LocalDate.parse(date.format(outputFormatter), outputFormatter);

    }

    public static String convertDateToUTCSystemZone(String dateStr) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD);
        LocalDate date = LocalDate.parse(dateStr, inputFormatter);
        ZoneId systemZone = ZoneId.systemDefault();
        ZonedDateTime systemZoneTime = date.atStartOfDay(systemZone);
        ZonedDateTime utcTime = systemZoneTime.withZoneSameInstant(ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ApplicationConstants.ISO_DATE_TIME_FORMAT);
        return dateStr;
    }
    public static String getUTCTimeAsString() {
        ZonedDateTime nowUtc = ZonedDateTime.now(ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_DATE_TIME_FORMAT);
        return nowUtc.format(formatter);

    }

    public static String getFutureDateForEnrollmentEvent(DelegateExecution delegateExecution) {
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        String hireDateStr = benefitsEntity != null ? benefitsEntity.getInterDomainInfo().getAssociateInfo().getEmployment().getHireDate() : null;

        ZonedDateTime nowUtc = ZonedDateTime.now(ZoneOffset.UTC);
        LocalDate currentDate = nowUtc.toLocalDate();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_DATE_TIME_FORMAT);

        if(hireDateStr != null && !hireDateStr.isEmpty()) {

            LocalDate hireDate = LocalDate.parse(hireDateStr);

            // Check if the hire date is within the next 7 days
            boolean isWithin7Days = !hireDate.isBefore(currentDate) && !hireDate.isAfter(currentDate.plusDays(7));

            // Check if the hire date is after Monday
            boolean isAfterMonday = hireDate.getDayOfWeek().getValue() > DayOfWeek.MONDAY.getValue();

            if (isWithin7Days && isAfterMonday) {
                LocalDate nextMonday = hireDate.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
                LocalTime localTime = LocalTime.now();
                ZonedDateTime nextMondayTimestamp = ZonedDateTime.of(nextMonday, localTime, ZoneOffset.UTC);
                return nextMondayTimestamp.format(formatter);
            } else {
                return nowUtc.format(formatter);
            }
        }
        return nowUtc.format(formatter);
    }
}
