package com.walmart.benefits.platform.core.engine.constants;

public class URLConstants {
    public final static String ASSOCIATE_PROFILE_CREATE="associate/benefits/profile/create";
    public final static String ASSOCIATE_PROFILE_UPDATE="associate/benefits/profile/update";
    public final static String ASSOCIATE_PROFILE_UPSERT="associate/benefits/profile/createOrUpdate";
    public final static String ASSESSMENT_UPSERT="assessments/associate/upsert";
    public final static String ASSOCIATE_PROFILE_GET="associate/benefits/profile/?associateId=";
    public final static String ASSOCIATE_BENEFIT_GET="associate/benefit/";
    public final static String ASSOCIATE_BENEFIT_GET_ALL = "associate/benefit/all";
    public final static String ASSOCIATE_BENEFIT_CREATE="associate/benefit/create";
    public final static String ASSOCIATE_BENEFIT_UPDATE="associate/benefit/update";
    public final static String ASSOCIATE_BENEFIT_UPSERT_BULK = "associate/benefit/upsert/bulk";
    public final static String ASSOCIATE_BENEFIT_UPSERT="associate/benefit/upsert";
    public final static String ASSOCIATE_ENROLLMENT_CREATE="enrollment/";
    public final static String TRANSACTION_LOG_CREATE="associate/transactionLog/save";
    public  final static String ASSOCIATE_BENEFIT_HISTORY_PATCH="associate/benefit/update/history/coverage";
    public final static String POST_PAYROLL_SNAPSHOTS_DATE_RANGE_GET="payroll-snapshots/by-associate-and-date-range";
    public static final String TRANSACTION_LOG_BULK_CREATE = "associate/transactionLog/saveAll";
}
