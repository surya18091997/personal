package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessor;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;

@Slf4j
public abstract class AbstractRuleResponseProcessor implements RuleResponseProcessor {
    private final EventType eventType;

    protected AbstractRuleResponseProcessor(EventType eventType) {
        this.eventType = eventType;
    }

    @Override
    public EventType getEventType() {
        return eventType;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Processing rule response for plan: {}, event: {}", getPlanType(), getEventType());
    }

    @Override
    public abstract String getPlanType();
}
