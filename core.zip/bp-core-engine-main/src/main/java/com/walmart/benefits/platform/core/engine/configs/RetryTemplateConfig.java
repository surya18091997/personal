package com.walmart.benefits.platform.core.engine.configs;

import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.transaction.TransactionException;
import org.springframework.web.client.ResourceAccessException;

import java.sql.SQLTransientConnectionException;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class RetryTemplateConfig {


    @Value("${retry.initial-interval:1000}")
    private Long  initialInterval;

    @Value("${retry.multiplier:2.0}")
    private double multiplier;

    @Value("${retry.max-interval:5000}")
    private Long maxInterval;

    @Value("${retry.count:3}")
    private Integer retryCount;

    @Bean
    public RetryTemplate getRetryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();
        Map<Class<? extends Throwable>, Boolean> retryableExceptions = new HashMap<>();
        retryableExceptions.put(SQLTransientConnectionException.class, Boolean.TRUE);
        retryableExceptions.put(JDBCConnectionException.class, Boolean.TRUE);
        retryableExceptions.put(DataAccessException.class, Boolean.TRUE);
        retryableExceptions.put(ResourceAccessException.class, Boolean.TRUE);
        retryableExceptions.put(TransactionException.class, Boolean.TRUE);
        retryableExceptions.put(RuntimeException.class, Boolean.TRUE);

        SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy(retryCount, retryableExceptions);
        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(initialInterval);
        backOffPolicy.setMultiplier(multiplier);
        backOffPolicy.setMaxInterval(maxInterval);


        retryTemplate.setRetryPolicy(simpleRetryPolicy);
        retryTemplate.setBackOffPolicy(backOffPolicy);

        return retryTemplate;
    }
}