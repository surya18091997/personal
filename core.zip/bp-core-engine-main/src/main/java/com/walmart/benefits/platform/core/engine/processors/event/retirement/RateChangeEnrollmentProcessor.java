package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.processors.event.EventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@Service
public class RateChangeEnrollmentProcessor implements EventProcessor {
    @Override
    public void process(DelegateExecution delegateExecution) {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            delegateExecution.setVariable(CREATE_ENROLLMENT, EventUtils.createEnrollment(associateEvent));
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ENROLLMENT_SERVICE, exception.getMessage());
        }
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }

    @Override
    public EventType getEventType() {
        return EventType.RATE_CHANGE;
    }
}
