package com.walmart.benefits.platform.core.engine.processors.event;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.TERMINATION;

@Slf4j
@Service
public class DefaultTerminationEventProcessor extends AbstractEventProcessor{

    public DefaultTerminationEventProcessor() {
        super(TERMINATION);
    }

    @Override
    public String getPlanType() {
        return null;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultTerminationEventProcessor: Default processing for TERMINATION event");
        // Specific default processing logic for TERMINATION event
    }
}
