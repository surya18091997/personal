package com.walmart.benefits.platform.core.engine.constants;

public class WorkflowConstants {
    public static  final String WORKFLOW_SELECTOR ="workflow_selector";
}
