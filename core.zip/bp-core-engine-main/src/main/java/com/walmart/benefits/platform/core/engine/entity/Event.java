package com.walmart.benefits.platform.core.engine.entity;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import lombok.*;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.CORE_HR_ORIGIN;


@Getter
@Setter
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "archive_events")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class Event {

    @Id
    private UUID id;

    @Column(name="associate_id",length = 20)
    private String associateId;

    @Column(name ="event_type",length = 60)
    @Enumerated(EnumType.STRING)
    private EventType eventType;

    @Column(name ="plan_type",length = 80)
    @Enumerated(EnumType.STRING)
    private PlanType planType;

    @Column(name ="origin",length = 60)
    private String origin = CORE_HR_ORIGIN;

    @Column(name ="description")
    private String description = "";

    @Type(type = "jsonb")
    @Column(name = "additional_fields", columnDefinition = "jsonb")
    private Object additionalFields;

    @Column(name="created_at", length = 30)
    private String createdAt;

    @Column(name="created_by", length = 30)
    private String createdBy;

    @OneToMany(mappedBy = "event", cascade = CascadeType.ALL)
    private Set<EventStatus> eventStatuses;

}
