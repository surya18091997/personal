package com.walmart.benefits.platform.core.engine.service.MatchEligibility;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@AllArgsConstructor
@Service("MatchEligibilityService")
public class MatchEligibilityService implements JavaDelegate {
    private EncryptionUtil encryptionUtil;

    private ObjectMapper objectMapper;
    /**
     * Process the Match Eligibility Event.
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        String associateId=null;
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            associateId = associateEvent.getAssociateId();
            log.info("Match Eligibility Service Started.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
            HardshipModel matchEligibilityModel = objectMapper.convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class);
            AssociateBenefitsProfile existing_associate_profile = (AssociateBenefitsProfile) delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE);
            if (existing_associate_profile == null) {
                throw new IllegalStateException("Associate benefits profile not found for processing match eligibility");
            }
            EventUtils.updatePlanEligibility(existing_associate_profile, matchEligibilityModel);

            delegateExecution.setVariable(ASSOCIATE_BENEFITS_PROFILE, existing_associate_profile);

            log.info("Match Eligibility Service completed.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        }
        catch (IllegalStateException e) {
            String safeId = associateId != null ? encryptionUtil.encrypt(associateId) : "unknown";
            log.error("Required data missing for associate {}: {}", safeId, e.getMessage(), e);
            setExceptionData(delegateExecution, "MATCH_ELIGIBILITY_SERVICE", e.getMessage());
        }
        catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, "MATCH_ELIGIBILITY_SERVICE", exception.getMessage());
        }
    }
}
