package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;

@Slf4j
@Service
public class RetirementStateTransferEventProcessor extends AbstractEventProcessor {

    public RetirementStateTransferEventProcessor() {
        super(STATE_TRANSFER);
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("401k event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);

        String isCoverageAvailable = (String) variables.get(IS_COVERAGE_AVAILABLE);
        Boolean isCoverageUpdated = (Boolean) variables.get(IS_COVERAGE_UPDATED);
        variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.updateProfile(associateEvent, benefitsEntity));
        if (isCoverageUpdated != null && isCoverageUpdated) {
            if (isCoverageAvailable.equals(TRUE)) {
                variables.put(UPDATE_COVERAGE, EventUtils.updateCoverageFromRules(benefitsEntity, isCoverageAvailable));
            } else {
                variables.put(ASSOCIATE_COVERAGE, List.of(EventUtils.updateCoverageFromRules(benefitsEntity, isCoverageAvailable)));
            }
        }
        delegateExecution.setVariables(variables);
        log.info("401k event processor ended");
    }
}
