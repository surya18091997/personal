package com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.AbstractRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class RetirementRehireRuleResponseProcessor extends AbstractRuleResponseProcessor {

    public RetirementRehireRuleResponseProcessor() {
        super(RE_HIRE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("RetirementRehireRuleResponseProcessor Started");

        BenefitsEntity benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY);
        String planTypeStr = (String) delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput)delegateExecution.getVariable(RULE_RESPONSE);
        CompanyMatchEligibilityOutput companyMatchEligibilityOutput = (CompanyMatchEligibilityOutput)delegateExecution.getVariable(COMPANY_MATCH_RULE_RESPONSE);
        RehireIndicatorOutput rehireIndicatorOutput = (RehireIndicatorOutput)delegateExecution.getVariable(REHIRE_INDICATOR_RULE_RESPONSE);

        PlanType planType = PlanType.valueOf(planTypeStr);
        if(associateEligibilityOutput != null &&
                associateEligibilityOutput.getIsEligibilityUpdated() != null &&
                Boolean.TRUE.equals(associateEligibilityOutput.getIsEligibilityUpdated())){
            EventUtils.setPlanEligibility(associateEligibilityOutput, planType, benefitsEntity);
            delegateExecution.setVariable(RULE_RESPONSE, null);
        }
        if(companyMatchEligibilityOutput != null &&
                companyMatchEligibilityOutput.getIsCompanyMatchEligibilityUpdated() != null &&
                Boolean.TRUE.equals(companyMatchEligibilityOutput.getIsCompanyMatchEligibilityUpdated())){
            EventUtils.setCompanyMatchEligibility(companyMatchEligibilityOutput, planType, benefitsEntity);
            delegateExecution.setVariable(COMPANY_MATCH_RULE_RESPONSE, null);
        }

        if(rehireIndicatorOutput != null) {
            if(rehireIndicatorOutput.getRehireIndicator() != null) {
                String rehireRebaseComment = Boolean.TRUE.equals(Optional.ofNullable(delegateExecution.getVariable(IS_REHIRE_REBASE)).orElse(false)) ?
                        TRANSACTION_LOG_REHIRE_REBASE_COMMENT : EMPTY;
                delegateExecution.setVariable(
                        ApplicationConstants.TRANSACTION_LOG_COMMENT,
                        rehireIndicatorOutput.getRehireIndicator() + rehireRebaseComment
                );
                if(rehireIndicatorOutput.isOriginalHireDateUpdated()) {
                    EventUtils.setOriginalHireDate(rehireIndicatorOutput, planType, benefitsEntity);
                }
            }
            else {
                log.error(REHIRE_INDICATOR_IS_NULL_ERROR);
                setExceptionData(delegateExecution, ASSOCIATE_PROFILE_SERVICE_UPDATE, REHIRE_INDICATOR_IS_NULL_ERROR);
            }
            delegateExecution.setVariable(REHIRE_INDICATOR_RULE_RESPONSE, null);
        }

        delegateExecution.setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);

        log.info("RetirementRehireRuleResponseProcessor Completed");
    }

    @Override
    public EventType getEventType() {
        return RE_HIRE;
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }
}