package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import org.camunda.bpm.engine.delegate.DelegateExecution;

public interface RuleExecutorProcessor {

    void process(DelegateExecution delegateExecution);

    String getPlanType();

}
