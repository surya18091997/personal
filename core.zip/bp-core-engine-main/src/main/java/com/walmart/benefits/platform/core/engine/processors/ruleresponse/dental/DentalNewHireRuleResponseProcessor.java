package com.walmart.benefits.platform.core.engine.processors.ruleresponse.dental;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.AbstractRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.CoverageOption;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.RecordType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.IS_COVERAGE_UPDATED;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

/**
 * @author Jedidiah Jeyaraj
 * @date 14/03/25
 */

@Slf4j
@Service
public class DentalNewHireRuleResponseProcessor extends AbstractRuleResponseProcessor {

    private final EncryptionUtil encryptionUtil;

    public DentalNewHireRuleResponseProcessor(EncryptionUtil encryptionUtil) {
        super(NEW_HIRE);
        this.encryptionUtil = encryptionUtil;
    }

    @Override
    public EventType getEventType() {
        return NEW_HIRE;
    }

    @Override
    public String getPlanType() {
        return DENTAL;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        AssociateEvent associateEvent = (AssociateEvent) delegateExecution.getVariable(ASSOCIATE_EVENT);
        log.info("NewHireRuleResponse Dental Processor Started for Associate ID {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        BenefitsEntity benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY);
        String planTypeStr = (String) delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput) delegateExecution.getVariable(RULE_RESPONSE);
        PlanType planType = PlanType.valueOf(planTypeStr);
        if (associateEligibilityOutput.getIsEligibilityUpdated() != null && associateEligibilityOutput.getIsEligibilityUpdated()) {
            EventUtils.setPlanEligibility(associateEligibilityOutput, planType, benefitsEntity);
        }
        if (!Objects.isNull(associateEligibilityOutput.getIsCoverageUpdated()) && Boolean.TRUE.equals(associateEligibilityOutput.getIsCoverageUpdated())) {
            AssociateBenefit associateBenefit = new AssociateBenefit();
            associateBenefit.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
            associateBenefit.setStartDate(associateEligibilityOutput.getCoverageStartDate() != null ? associateEligibilityOutput.getCoverageStartDate() : null);
            associateBenefit.setPlanId(planType.getPlanId() != null ? planType.getPlanId() : null);
            associateBenefit.setPlanGroup(planType.getPlanGroup() != null ? planType.getPlanGroup() : null);
            associateBenefit.setCoverageOption(associateEligibilityOutput.getCoverageOption() != null ? CoverageOption.valueOf(associateEligibilityOutput.getCoverageOption()) : null);
            associateBenefit.setEndDate(associateEligibilityOutput.getCoverageEndDate() != null ? associateEligibilityOutput.getCoverageEndDate() : null);
            associateBenefit.setRecordType(associateEligibilityOutput.getRecordType() != null ? RecordType.valueOf(associateEligibilityOutput.getRecordType()):null);

            benefitsEntity.getIntraDomainInfo().setAssociateBenefit(associateBenefit);
        }
        delegateExecution.setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
        delegateExecution.setVariable(IS_ELIGIBILITY_UPDATED, associateEligibilityOutput.getIsEligibilityUpdated());
        delegateExecution.setVariable(IS_COVERAGE_UPDATED, associateEligibilityOutput.getIsCoverageUpdated());
        log.info("NewHireRuleResponse Dental Processor Completed for Associate ID {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
    }
}
