package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Contribution;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.EventUtils.*;

public class RateValidatorUtil {

    private RateValidatorUtil() { }

    public static boolean isPlanEligible(AssociateBenefitsProfile associateBenefitsProfile, AssociateEvent associateEvent) {
        boolean isPlanEligiblity = false;
        if (associateBenefitsProfile != null) {
            List<PlanEligibility> planEligibleList = associateBenefitsProfile.getEligibility().getPlans();
            for (PlanEligibility planList : planEligibleList) {
                if (planList.getPlanId().equalsIgnoreCase(associateEvent.getPlanType().getPlanId())
                        && Boolean.TRUE.equals(planList.getIsEligible())) {
                    isPlanEligiblity = true;
                }
            }
        }

        return isPlanEligiblity;
    }

    public static boolean is401kRegularPlanAvailable(AssociateBenefitsProfile associateBenefitsProfile, String basePlan) {
        boolean isRegularPlanAvailable = false;
        if (associateBenefitsProfile != null && !associateBenefitsProfile.getEligibility().getPlans().isEmpty()) {
            isRegularPlanAvailable = associateBenefitsProfile.getEligibility().getPlans().stream().anyMatch(
                    plan -> plan.getPlanId().equals(basePlan) && Boolean.TRUE.equals(plan.getIsEligible()));
        }

        return isRegularPlanAvailable;
    }

    public static boolean isValidCoverage(AssociateBenefit associateBenefit) {
        boolean isValidCoverage = false;
        if (associateBenefit != null && !StringUtils.hasText(associateBenefit.getEndDate())) {
            isValidCoverage = true;
        }

        return isValidCoverage;
    }

    public static boolean isBeyondMaxRateForCatchupPlan(AssociateEvent associateEvent, List<String> catchupPlanList, String rateChangedPlan, double catchupLimit, List<AssociateBenefit> allRetirementCoveragesList) {
        if (Objects.isNull(allRetirementCoveragesList)) return false;
        Contribution contribution = getContribution(getAdditionalInfoMap(associateEvent));
        double totalRate = contribution.getValue();
        totalRate += getContributionValueForPlan(allRetirementCoveragesList, catchupPlanList, rateChangedPlan);
        return totalRate > catchupLimit;
    }

    public static boolean isBeyondMaxRateForRegularPlan(AssociateEvent associateEvent, List<String> regularPlanList, String rateChangedPlan, double regularLimit, List<AssociateBenefit> allRetirementCoveragesList) {
        if (Objects.isNull(allRetirementCoveragesList))
            return false;
        Contribution contribution = getContribution(getAdditionalInfoMap(associateEvent));
        double totalRate = contribution.getValue();
        totalRate += getContributionValueForPlan(allRetirementCoveragesList, regularPlanList, rateChangedPlan);
        return totalRate > regularLimit;
    }

    private static double getContributionValueForPlan(List<AssociateBenefit> allRetirementCoveragesList, List<String> planList, String rateChangedPlan) {
        return allRetirementCoveragesList.stream()
                .filter(associateBenefit -> !Objects.equals(associateBenefit.getPlanId(), rateChangedPlan) && planList.contains(associateBenefit.getPlanId()))
                .mapToDouble(associateBenefit -> associateBenefit.getContribution().getValue())
                .sum();
    }

    public static boolean isCatchupPlan(AssociateEvent associateEvent, List<String> catchupPlan) {
        return catchupPlan.contains(associateEvent.getPlanType().getPlanId());
    }

    public static boolean isRegularPlan(AssociateEvent associateEvent, List<String> regularPlan) {
        return regularPlan.contains(associateEvent.getPlanType().getPlanId());
    }

    public static boolean isValidRuleEligibility(AssociateEvent associateEvent, BenefitsEntity benefitsEntity) {
        boolean isValidRuleEligibility = false;
        if (benefitsEntity != null && benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility() != null) {
            isValidRuleEligibility = benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans().stream().
                    anyMatch(planEligibility -> (planEligibility.getPlanId().equals(associateEvent.getPlanType().getPlanId()) &&
                            Boolean.TRUE.equals(planEligibility.getIsEligible()) && planEligibility.getEligibleDate() != null));
        }

        return isValidRuleEligibility;
    }

    public static int calculateAge(BenefitsEntity benefitsEntity) {
        LocalDate currentDate = LocalDate.now();
        String birthDateStr = null;
        if (benefitsEntity != null) {
            birthDateStr = benefitsEntity.getInterDomainInfo().getAssociateInfo().getPersonalInfo().getBirthDate();
        }
        LocalDate birthdate = ConverterUtil.convertStringToDate(birthDateStr);
        return currentDate.getYear() - birthdate.getYear();
    }

    public static boolean isCatchupEligibleAge(BenefitsEntity benefitsEntity, int catchupEligibleAge) {
        boolean isCatchupEligibleAge = false;
        int currentAge = calculateAge(benefitsEntity);
        if (currentAge >= catchupEligibleAge) {
            isCatchupEligibleAge = true;
        }
        return isCatchupEligibleAge;
    }

    public static boolean isEmploymentStatusNotValid(String employStatusCode) {
        return employStatusCode != null && (employStatusCode.equalsIgnoreCase(EMPLOY_STATUS_TERMINATED) ||
                employStatusCode.equalsIgnoreCase(EMPLOY_STATUS_DECEASED) ||
                employStatusCode.equalsIgnoreCase(EMPLOY_STATUS_QUEUED));
    }
    public static boolean isAssocInHardshipWindow(List<AssociateBenefit> allRetirementCoveragesList, String storeStateProvCd) {
        Optional<AssociateBenefit> associateBenefit;
        if (Objects.isNull(allRetirementCoveragesList)) {
            return false;
        }

        if (COUNTRY_CODE_US.equalsIgnoreCase(getStoreStateProvCd(storeStateProvCd))) {
            associateBenefit = allRetirementCoveragesList.stream()
                    .filter(benefit -> benefit.getPlanId().equalsIgnoreCase(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId())).findFirst();
        } else {
            associateBenefit = allRetirementCoveragesList.stream()
                    .filter(benefit -> benefit.getPlanId().equalsIgnoreCase(PlanType.RETIREMENT_401K_HARDSHIP_PR.getPlanId())).findFirst();
        }
        ZonedDateTime nowUtc = ZonedDateTime.now(ZoneOffset.UTC);
        LocalDate currentDate = nowUtc.toLocalDate();
        return associateBenefit.isPresent() && (associateBenefit.get().getStartDate() != null &&
                (LocalDate.parse(associateBenefit.get().getStartDate()).isBefore(currentDate) ||
                        LocalDate.parse(associateBenefit.get().getStartDate()).equals(currentDate)) &&
                (associateBenefit.get().getEndDate() == null ||
                        LocalDate.parse(associateBenefit.get().getEndDate()).isAfter(currentDate) ||
                        LocalDate.parse(associateBenefit.get().getEndDate()).equals(currentDate)));
    }

}
