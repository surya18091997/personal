package com.walmart.benefits.platform.core.engine.service.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.LoanModel;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.LoanStatusCode;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@AllArgsConstructor
@Service("RetirementLoanService")
public class RetirementLoanService implements JavaDelegate {

    private final EncryptionUtil encryptionUtil;
    private final ObjectMapper objectMapper;

    @Override
    public void execute(DelegateExecution delegateExecution) {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            AssociateBenefit latestLoanCoverage = (AssociateBenefit) delegateExecution.getVariable(COVERAGE_RESPONSE);
            if(latestLoanCoverage == null) {
                delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, FALSE);
            }
            log.info("Retirement Loan Service Started.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));

            LoanModel loanModel = objectMapper.convertValue(associateEvent.getAdditionalInfo(), LoanModel.class);
            delegateExecution.setVariable(LOAN_DEDUCTION_AMOUNT, loanModel.getDeductionAmount());

            if (loanModel.getDeductionAmount() == 0.0 &&
                    (latestLoanCoverage == null || latestLoanCoverage.getLoanStatusCode() != LoanStatusCode.A)) {
                throw new IllegalStateException("Deduction amount cannot be zero without having an existing active loan.");
            }

            if (latestLoanCoverage!=null && loanModel.getDeductionAmount() > 0.0 &&
                    !Objects.equals(latestLoanCoverage.getLoanSequenceNumber(), loanModel.getLoanNumber()) &&
                    latestLoanCoverage.getLoanStatusCode() == LoanStatusCode.A) {
                throw new IllegalStateException("New loan seq number with non zero deduction amount for an existing active loan ");
            }

            if (latestLoanCoverage != null) {
                delegateExecution.setVariable(LATEST_COVERAGE_LOAN_SEQUENCE_NUMBER, latestLoanCoverage.getLoanSequenceNumber());
                delegateExecution.setVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER, loanModel.getLoanNumber());
            }

            AssociateBenefit targetPatchCoverage = EventUtils.targetPatchOnCoverage(associateEvent);
            AssociateBenefit coverage = EventUtils.upsertCoverage(associateEvent, loanModel);

            delegateExecution.setVariable(PATCH_UPDATE_COVERAGE, targetPatchCoverage);
            delegateExecution.setVariable(UPDATE_COVERAGE, coverage);

            log.info("Retirement Loan Service completed.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, RETIREMENT_LOAN_SERVICE, exception.getMessage());
        }
    }
}