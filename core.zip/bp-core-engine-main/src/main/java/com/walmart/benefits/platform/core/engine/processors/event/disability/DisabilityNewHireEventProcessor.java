package com.walmart.benefits.platform.core.engine.processors.event.disability;

import com.walmart.benefits.platform.core.engine.processors.event.DefaultNewHireEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

@Slf4j
@Service
public class DisabilityNewHireEventProcessor extends DefaultNewHireEventProcessor {


    public DisabilityNewHireEventProcessor() {
        super();
    }

    @Override
    public String getPlanType() {
        return DISABILITY;
    }

    @Override
    public void process(DelegateExecution delegateExecution){
        super.process(delegateExecution);
        log.info("Disability New Hire Event processor started");

        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        var planElections = (List<PlanElection>) variables.get(PLAN_ELECTIONS);
        if(!Objects.isNull(planElections) && !planElections.isEmpty()){
            //Creates the Enrollment as part of New-Hire for the Eligible Associates
            delegateExecution.setVariable(CREATE_ENROLLMENT, EventUtils.createEnrollmentFromPlanElections(associateEvent,planElections));
        }
        delegateExecution.setVariables(variables);
        log.info("Disability New Hire Event processor ended");
    }

}
