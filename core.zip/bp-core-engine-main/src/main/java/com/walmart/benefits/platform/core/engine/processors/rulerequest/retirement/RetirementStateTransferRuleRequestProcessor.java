package com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.AbstractRuleRequestProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;

@Slf4j
@Service
public class RetirementStateTransferRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public RetirementStateTransferRuleRequestProcessor() {
        super(STATE_TRANSFER);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("State transfer Rule Response Processor");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        AssociateEligibilityInput associateEligibilityInput = (AssociateEligibilityInput) delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT);
        LinkedHashMap<String, String> additionalInfo = (LinkedHashMap<String, String>) associateEvent.getAdditionalInfo();
        associateEligibilityInput.setPrevStateStoreProvCd(additionalInfo.get(PREV_STATE_STORE_PROV_CD));
        delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
        log.info("State transfer Rule Response Processor completed");
    }

    @Override
    public EventType getEventType() {
        return STATE_TRANSFER;
    }
    @Override
    public String getPlanType() { return RETIREMENT; }
}
