package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EventProcessorFactory {
    private final List<EventProcessor> processors;
    private final List<EventProcessor> defaultProcessors;

    public EventProcessor getProcessor(String planType, EventType eventType) {
        return processors.stream()
                .filter(p -> matches(p, planType, eventType))
                .findFirst()
                .orElseGet(() -> getDefaultProcessor(eventType));
    }

    private EventProcessor getDefaultProcessor(EventType eventType) {
        return defaultProcessors.stream()
                .filter(p -> p.getPlanType() == null && p.getEventType().equals(eventType))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No default processor found for event type: " + eventType));
    }

    private boolean matches(EventProcessor processor, String planType, EventType eventType) {
        return processor.getPlanType() != null &&
               processor.getPlanType().equalsIgnoreCase(planType) &&
               processor.getEventType().equals(eventType);
    }
}