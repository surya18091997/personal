package com.walmart.benefits.platform.core.engine.dao;

import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface EventArchiveDao extends JpaRepository<Event, UUID> {

    @Query("SELECT e FROM Event e " +
            "JOIN FETCH e.eventStatuses es " +
            "WHERE e.id = :id AND es.subPlanType = :planType")
    Optional<Event> findByIdAndEventStatus_subPlanType(@Param("id") UUID id, @Param("planType") String planType);

    @Query("SELECT e FROM Event e " +
            "JOIN FETCH e.eventStatuses es " +
            "WHERE e.eventType = :eventType AND es.status = :eventStatus")
    List<Event> findByEventTypeAndEventStatus_subPlanType(@Param("eventType") EventType eventType, @Param("eventStatus") Status eventStatus);

}
