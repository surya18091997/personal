package com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessorFactory;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleExecutionException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleMetadataSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RulesSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RuleExecutorFactory;
import com.walmart.benefits.rules.benefitsrulessdk.executor.services.RuleExecutorService;
import com.walmart.benefits.rules.benefitsrulessdk.mapper.factory.InputSchemaMapperFactory;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleRequest;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleResponse;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;


@Slf4j
@Service
@AllArgsConstructor
public class AssociateEligibilityProcessor implements RuleCategoryProcessor {

    private final EncryptionUtil encryptionUtil;

    private final RuleRequestProcessorFactory ruleRequestProcessorFactory;

    private final RuleResponseProcessorFactory ruleResponseProcessorFactory;

    @Override
    public void process(DelegateExecution delegateExecution) throws RuntimeException {
        log.info("AssociateEligibilityProcessor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        String planTypeStr = (String) variables.get(PLAN_TYPE_STR);
        String planType = (String) variables.get(PLAN_TYPE);
        PlanType planId = PlanType.valueOf(planTypeStr);

        AssociateEligibilityInput associateEligibilityInput = InputSchemaMapperFactory.schemaToInput(benefitsEntity,AssociateEligibilityInput.class);
        delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);

        RuleRequestProcessor processor = ruleRequestProcessorFactory.getProcessor(planType, associateEvent.getEventType());
        processor.process(delegateExecution);

        associateEligibilityInput = (AssociateEligibilityInput) delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT);

        AssociateEligibilityOutput payload = executeRules(delegateExecution, associateEligibilityInput, planId, associateEvent);

        RuleResponseProcessor responseProcessor = ruleResponseProcessorFactory.getProcessor(planType, associateEvent.getEventType());
        responseProcessor.process(delegateExecution);

        log.info("Rule Category ===> {}, Plan Type ===> {}, Eligibility Status for  plan ===> {}, Eligibility Date ===> {},  Coverage Status for  plan ===> {}, Coverage Date ===> {}, Win Number ===> {}",
                getRuleCategory(), planId, payload.getAssociateEligibilityIndicator(), payload.getAssociateEligibilityDate(), payload.getIsCoverageUpdated(), payload.getCoverageStartDate(),
                encryptionUtil.encrypt(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId()));
        delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, null);
        delegateExecution.setVariables(variables);
        log.info("AssociateEligibilityProcessor completed");
    }

    private AssociateEligibilityOutput executeRules(DelegateExecution delegateExecution, AssociateEligibilityInput associateEligibilityInput, PlanType planId, AssociateEvent associateEvent)  {
        RuleRequest<AssociateEligibilityInput> ruleRequest = new RuleRequest<>();
        ruleRequest.setPayload(associateEligibilityInput);
        ruleRequest.setRuleSet(getRuleCategory());
        ruleRequest.setPlan(planId);
        ruleRequest.setEvent(associateEvent.getEventType());
        try {
            RuleExecutorService<AssociateEligibilityInput, AssociateEligibilityOutput> ruleExecutorService = RuleExecutorFactory.createExecutor(getRuleCategory());
            RuleResponse<AssociateEligibilityOutput> ruleResponse = ruleExecutorService.execute(ruleRequest);
            AssociateEligibilityOutput payload = ruleResponse.getPayload();
            delegateExecution.setVariable(RULE_RESPONSE, payload);
            return payload;
        } catch (RulesSyncException | RuleMetadataSyncException | RuleExecutionException e) {
            log.error(e.getMessage(), e);
            throw new com.walmart.benefits.platform.core.engine.exceptions.RuleExecutionException("Rule Execution Failed", e);
        }
    }


    @Override
    public RuleCategory getRuleCategory() {
        return RuleCategory.ASSOCIATE_ELIGIBILITY;
    }


}
