package com.walmart.benefits.platform.core.engine.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.util.concurrent.CompletableFuture;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.StreamSupport;

@Component
@Slf4j
public class DataLakeJsonUtil {

    private final Storage storage;
    private final ObjectMapper objectMapper;
    private final Cache<String, Map<String, List<Object>>> cache;

    public DataLakeJsonUtil(Storage storage) {
        this.storage = storage;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.cache = Caffeine.newBuilder()
                .expireAfterWrite(150, TimeUnit.MINUTES) // Evict entries 30 minutes after write
                .build();
    }

    /**
     * Reads Spark written JSON files from a specified GCS folder and parses them into Java objects.
     *
     * @param gcsFolderPath The GCS folder path (e.g., "bucket-name/folder-path/").
     * @param fullDocumentClass The class type of the key to be mapped (optional).
     *                          If provided, the method maps the specified key to this class.
     * @param fullDocumentColumnName The name of the key to be mapped to the provided class (optional).
     *                               If provided, the method fetches the contents of this key.
     * @param <T> The type of the POJO for the specified key.
     * @return A list of parsed objects. If both `fullDocumentClass` and `fullDocumentColumnName` are provided,
     *         the list contains objects of type `T`. Otherwise, it contains maps of dynamically parsed JSON data.
     * @throws IllegalArgumentException If the bucket is not found or the GCS folder path is invalid.
     * @throws IOException If an error occurs during file reading or parsing.
     */
    public <T> List<Object> readDataLakeJsonFromGcs(String gcsFolderPath, Class<T> fullDocumentClass, String fullDocumentColumnName) throws IOException {
        String bucketName = gcsFolderPath.split("/")[0];
        String folderPath = gcsFolderPath.substring(bucketName.length() + 1);

        Bucket bucket;
        try {
            bucket = storage.get(bucketName);
        } catch (StorageException e) {
            throw new IOException("Failed to access the GCS bucket: " + bucketName, e);
        }

        if (bucket == null) {
            throw new IllegalArgumentException("Bucket not found: " + bucketName);
        }

        List<Blob> blobs = StreamSupport.stream(bucket.list(Storage.BlobListOption.prefix(folderPath)).iterateAll().spliterator(), false)
                .filter(blob -> blob.getName().endsWith(".json") || blob.getName().endsWith(".jsonl"))
                .toList();

        // Process files in parallel using CompletableFuture
        List<CompletableFuture<List<Object>>> futures = blobs.stream()
                .map(blob -> CompletableFuture.supplyAsync(() -> processBlob(blob, fullDocumentClass, fullDocumentColumnName)))
                .toList();

        // Combine results from all futures
        return futures.stream()
                .map(CompletableFuture::join)
                .flatMap(List::stream).toList();
    }

    private <T> List<Object> processBlob(Blob blob, Class<T> fullDocumentClass, String fullDocumentColumnName) {
        List<Object> result = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(blob.getContent())))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.add(parseJsonLine(line, fullDocumentClass, fullDocumentColumnName));
            }
            log.info("Successfully read file: {}", blob.getName());
        } catch (IOException e) {
            log.error("Failed to read content from blob: {}", blob.getName(), e);
        }
        return result;
    }

    private <T> Object parseJsonLine(String line, Class<T> fullDocumentClass, String fullDocumentColumnName) throws IOException {
        try {
            JsonNode jsonNode = objectMapper.readTree(line);

            if (fullDocumentClass != null && fullDocumentColumnName != null) {
                // Map the specified key to the provided POJO class
                return objectMapper.treeToValue(jsonNode.get(fullDocumentColumnName), fullDocumentClass);
            } else {
                // Dynamically parse the entire JSON object
                return objectMapper.convertValue(jsonNode, new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {});
            }
        } catch (JsonProcessingException e) {
            throw new IOException("Failed to parse JSON content: " + line, e);
        }
    }

    public String storeDataInCache(Map<String, List<Object>> data) {
        String key = "dataLakeJson_" + System.currentTimeMillis();
        cache.put(key, data);
        return key;
    }

    public Map<String, List<Object>> getDataFromCache(String key) {
        return cache.getIfPresent(key);
    }

    public void removeFromCache(String key) {
        cache.invalidate(key);
    }

    public void clearCache() {
        cache.invalidateAll();
    }

}