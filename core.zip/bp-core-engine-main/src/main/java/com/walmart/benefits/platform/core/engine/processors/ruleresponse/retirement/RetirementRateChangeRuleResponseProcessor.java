package com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.AbstractRuleResponseProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RATE_CHANGE;

@Slf4j
@Service
public class RetirementRateChangeRuleResponseProcessor extends AbstractRuleResponseProcessor {

    public RetirementRateChangeRuleResponseProcessor() {
        super(ENROLLMENT_COMPLETE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("RateChangeRuleResponseProcessor Started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        BenefitsEntity benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(BENEFITS_ENTITY);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput)delegateExecution.getVariable(RULE_RESPONSE);

        var planEligibilityList = getPlanEligibility(associateEligibilityOutput, associateEvent);
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setEligibility(new Eligibility());
        benefitsEntity.getIntraDomainInfo().setAssociateBenefitsProfile(associateBenefitsProfile);
        benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().setPlans(planEligibilityList);

        delegateExecution.setVariable(BENEFITS_ENTITY, benefitsEntity);
        log.info("RateChangeRuleResponseProcessor Completed");
    }

    public static ArrayList<PlanEligibility> getPlanEligibility(AssociateEligibilityOutput associateEligibilityOutput, AssociateEvent associateEvent) {
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setEligibleDate(associateEligibilityOutput.getAssociateEligibilityDate() != null ? associateEligibilityOutput.getAssociateEligibilityDate() : null);
        planEligibility.setIsEligible(associateEligibilityOutput.getAssociateEligibilityIndicator() != null ? associateEligibilityOutput.getAssociateEligibilityIndicator() : null);
        planEligibility.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        planEligibility.setPlanId(associateEvent.getPlanType().getPlanId());

        var planEligibilityList = new ArrayList<PlanEligibility>();
        planEligibilityList.add(planEligibility);
        return planEligibilityList;
    }

    @Override
    public EventType getEventType() {
        return ENROLLMENT_COMPLETE;
    }
    @Override
    public String getPlanType() { return RETIREMENT; }
}
