package com.walmart.benefits.platform.core.engine.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class HardshipModel {
    private String recordType;
    private String ssnId;
    private String merMatchEligDate;
    private String merMatchEligInd;
    private String startDate;
    private String resumeDate;
    private String countryCode;


}