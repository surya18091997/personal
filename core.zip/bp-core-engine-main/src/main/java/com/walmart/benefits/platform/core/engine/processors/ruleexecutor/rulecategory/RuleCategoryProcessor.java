package com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory;

import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import org.camunda.bpm.engine.delegate.DelegateExecution;

public interface RuleCategoryProcessor {

    void process(DelegateExecution delegateExecution);

    RuleCategory getRuleCategory();
}
