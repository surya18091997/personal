package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.constants.Status;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

@Slf4j
@Service("ErrorHandlerService")
public class ErrorHandlerService implements JavaDelegate {
    private final EventService eventService;

    public ErrorHandlerService(EventService eventService) {
        this.eventService = eventService;
    }

    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        log.info("Error Handler Service Started");
        delegateExecution.setVariable("eventStatus",  Status.FAILED);
        eventService.updateEvent(delegateExecution);
        log.info("Error Handler Service completed");
    }
}
