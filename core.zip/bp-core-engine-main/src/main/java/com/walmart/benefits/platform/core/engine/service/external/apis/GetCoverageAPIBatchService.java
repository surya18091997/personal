package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;


@Slf4j
@Service("GetCoverageAPIBatchService")
public class GetCoverageAPIBatchService implements JavaDelegate {

    @Value("${consumer.associate-benefits-service-app-name}")
    private String associateBenefitServiceAppName;


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;


    public GetCoverageAPIBatchService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Get Data to associate coverage API service
     *
     * @param delegateExecution :
     * @throws Exception :
     */
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        AssociateEvent associateEvent = (AssociateEvent) delegateExecution.getVariable(ASSOCIATE_EVENT);
        log.info("Get coverage batch api started..., Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, FALSE);
            List<AssociateBenefit> coverageResponseList = new ArrayList<>();
            String eventPlanType = (String) delegateExecution.getVariable(PLAN_TYPE_STR);
            List<String> availablePlanTypeList = (List<String>) delegateExecution.getVariable(PLAN_ID_LIST);
            for (String availablePlanType : availablePlanTypeList) {
                getPlanCoverage(coverageResponseList, availablePlanType, eventPlanType, associateEvent, retryCount, delegateExecution);
            }
            delegateExecution.setVariable(COVERAGE_RESPONSE_LIST, coverageResponseList);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, "BENEFIT_COVERAGE_SERVICE", exception.getMessage());
        }
    }

    private void getPlanCoverage(List<AssociateBenefit> coverageResponseList, String availablePlanType, String eventPlanType, AssociateEvent associateEvent, int retryCount, DelegateExecution delegateExecution) throws Exception {
        try {
            PlanType planType = PlanType.valueOf(availablePlanType);
            String coverageURL = UriComponentsBuilder.fromHttpUrl(httpUtils.getCoverageUrl())
                    .queryParam("associateId", associateEvent.getAssociateId())
                    .queryParam("planId", planType.getPlanId())
                    .toUriString();
            ResponseEntity<AssociateBenefit> coverageResponse = restTemplate.exchange(coverageURL, HttpMethod.GET,
                    httpUtils.getHttpEntity(associateBenefitServiceAppName), AssociateBenefit.class);
            log.info("Get coverage api status code : {}, Associate Id {}", coverageResponse.getStatusCode(), encryptionUtil.encrypt(associateEvent.getAssociateId()));

            if (coverageResponse.getStatusCode() == HttpStatus.OK && coverageResponse.getBody() != null) {
                coverageResponseList.add(coverageResponse.getBody());
                if(Objects.equals(eventPlanType, availablePlanType))
                    delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, TRUE);
            }
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() != HttpStatus.NOT_FOUND) {
                log.error(e.getMessage(), e);
            }
        } catch (HttpServerErrorException | ResourceAccessException exception) {
            log.info("Server Error :: retrying...., Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
            if (retryCount == 0) {
                setExceptionData(delegateExecution, "GET_COVERAGE_SERVICE_SERVER_ERROR", exception.getMessage());
            }
            log.error(exception.getMessage(), exception);
            throw exception;
        }
    }
}
