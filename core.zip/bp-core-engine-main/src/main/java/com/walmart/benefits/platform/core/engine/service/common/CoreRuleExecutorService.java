package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.RuleExecutorProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.RuleExecutorProcessorFactory;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;


@Slf4j
@AllArgsConstructor
@Service("CoreRuleExecutorService")
public class CoreRuleExecutorService implements JavaDelegate {

    private final RuleExecutorProcessorFactory ruleExecutorProcessorFactory;

    /**
     * Executes rule to validate the eligibility
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);
            RuleExecutorProcessor ruleExecutorProcessor = ruleExecutorProcessorFactory.getProcessor(planType);
            ruleExecutorProcessor.process(delegateExecution);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, RULE_EXECUTOR_SERVICE, exception.getMessage());
        }
    }
}

