package com.walmart.benefits.platform.core.engine.controllers;

import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.common.AsyncBatchProcessorService;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
public class BatchWorkflowTriggerController {

    private final EventArchiveDao eventArchiveDao;
    private final AsyncBatchProcessorService asyncBatchProcessorService;
    private final HttpUtils httpUtils;
    private final RetryTemplate retryTemplate;

    @GetMapping("/trigger-batch-workflow")
    public ResponseEntity<String> getEventsByTypeAndStatus(
            @RequestParam("eventType") String eventType) {
        log.info("Received request to trigger batch workflow for event type: {}", eventType);

        try {
            // Validate the eventType against allowed values
            EventType validatedEventType = validateEventType(eventType);

            // Fetch the list of queued events using the DAO method
            List<Event> events = retryTemplate.execute(retryContext -> eventArchiveDao.findByEventTypeAndEventStatus_subPlanType(validatedEventType, Status.QUEUED));

            // Check if no events are found
            if (events == null || events.isEmpty()) {
                log.warn("No events of type '{}' are available for batch processing.", validatedEventType);
                return ResponseEntity.ok(httpUtils.escapeHtml("No events of type '" + validatedEventType + "' are available for batch processing."));
            }

            // Trigger the batch process asynchronously
            log.info("Submitting {} events of type '{}' for batch processing.", events.size(), validatedEventType);
            asyncBatchProcessorService.processEvents(events);

            // Return a response indicating the events are submitted for batch processing
            return ResponseEntity.ok(httpUtils.escapeHtml("Events of type '" + validatedEventType + "' are submitted for batch processing."));
        } catch (IllegalArgumentException e) {
            log.error("Invalid event type provided: {}", eventType, e);
            return ResponseEntity.badRequest().body(httpUtils.escapeHtml("Invalid event type: " + eventType));
        } catch (Exception e) {
            log.error("An error occurred while processing events of type '{}'.", eventType, e);
            return ResponseEntity.status(500).body("An error occurred while processing events. Please try again later.");
        }
    }

    private EventType validateEventType(String eventType) {
        try {
            return EventType.valueOf(eventType);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid event type: " + eventType);
        }
    }

}