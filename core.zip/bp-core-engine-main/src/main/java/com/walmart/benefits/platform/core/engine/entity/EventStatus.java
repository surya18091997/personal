package com.walmart.benefits.platform.core.engine.entity;

import com.walmart.benefits.platform.core.engine.constants.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Data
@Builder
@Entity
@Table(name = "event_status")
@NoArgsConstructor
@AllArgsConstructor
public class EventStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "archive_event_id")
    private Event event;

    @Column(name ="sub_plan_type")
    private String subPlanType;

    @Column(name ="status",length = 20 )
    @Enumerated(EnumType.STRING)
    private Status status = Status.RECEIVED;

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    @Column(name="created_at")
    private String createdAt;

    @Column(name="created_by")
    private String createdBy;

    @Column(name="last_modified_at")
    private String lastModifiedAt;

    @Column(name="last_modified_by")
    private String lastModifiedBy;


}
