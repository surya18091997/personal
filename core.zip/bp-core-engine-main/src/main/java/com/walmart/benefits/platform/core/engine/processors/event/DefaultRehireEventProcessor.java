package com.walmart.benefits.platform.core.engine.processors.event;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class DefaultRehireEventProcessor extends AbstractEventProcessor {

    public DefaultRehireEventProcessor() {
        super(RE_HIRE);
    }

    @Override
    public String getPlanType() {
        return null;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultRehireEventProcessor: Default processing for RE_HIRE event");
    }
}