package com.walmart.benefits.platform.core.engine.utils;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.runtime.Job;

@Slf4j
public class ProcessEngineUtil {

    private ProcessEngineUtil(){}

    public static int getRetryCount(DelegateExecution delegateExecution) {
        ManagementService managementService = delegateExecution.getProcessEngineServices().getManagementService();
        Job job = managementService.createJobQuery().processInstanceId(delegateExecution.getProcessInstanceId()).singleResult();
        return job.getRetries() - 1;
    }
}
