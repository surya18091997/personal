package com.walmart.benefits.platform.core.engine.exceptions;

public class CoreEngineRecoverableException extends Exception{

}
