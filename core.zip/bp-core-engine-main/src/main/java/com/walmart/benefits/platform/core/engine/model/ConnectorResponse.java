package com.walmart.benefits.platform.core.engine.model;

import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import lombok.Data;

@Data
public class ConnectorResponse {
    private Data data;

    @lombok.Data
    public static class Data {
        private InterDomainInfo queryAssociateUpstreamDetails;
    }
}
