package com.walmart.benefits.platform.core.engine.configs;

import com.walmart.benefits.platform.core.engine.exceptions.EventTypeConfigurationException;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@Component
@PropertySource("classpath:rule-meta-data-config.yaml")
@ConfigurationProperties(prefix = "rule-metadata")
public class RuleMetaDataConfig {

    private  Map<String,Map<String,List<RuleCategory>>> eventType;


    @PostConstruct
    public void validateEventType() {
        if (eventType == null || eventType.isEmpty()) {
            throw new EventTypeConfigurationException("The 'eventType' property is not defined in the rule-meta-data-config.yaml");
        }
    }

}