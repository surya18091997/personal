package com.walmart.benefits.platform.core.engine.processors.event.dental;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.RecordType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;

@Slf4j
@Service
public class DentalEnrollmentCompleteEventProcessor extends AbstractEventProcessor {

    public DentalEnrollmentCompleteEventProcessor() {
        super(ENROLLMENT_COMPLETE);
    }

    @Override
    public String getPlanType() {
        return DENTAL;
    }

    @Override
    public void process(DelegateExecution delegateExecution){
        log.info("Dental event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent =(AssociateEvent) variables.get(ASSOCIATE_EVENT);
        Enrollment enrollment =(Enrollment) variables.get(ENROLLMENT);
        AssociateBenefit coverageOE = EventUtils.createCoverage(associateEvent,enrollment.getActivity()).get(0);
        String planType = (String) variables.get(PLAN_TYPE);
        List<AssociateBenefit> coverageList = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
        getCoverageStartDate(coverageList, planType, coverageOE);
        delegateExecution.setVariable(UPDATE_COVERAGE,coverageOE);
        delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        delegateExecution.setVariable("isPlanEligible", true);

    }

    private static void getCoverageStartDate(List<AssociateBenefit> coverageList, String planType, AssociateBenefit coverageOE) {
        if (coverageList != null && !coverageList.isEmpty()) {
            coverageList.stream().filter(coverage -> planType.equals(coverage.getPlanGroup())).forEach(coverage -> {
                log.info("plan id: {} Coverage start date  {}", coverage.getPlanId(), coverage.getStartDate());
                coverageOE.setStartDate(coverage.getStartDate());
                //TODO get provider id from store config and recordType from Rule response
                coverageOE.setProviderId("DENTAL");
                coverageOE.setRecordType(RecordType.CURRENT);
            });
        } else {
            log.warn("No coverage list found for dental enrollment complete event");
        }
    }
}
