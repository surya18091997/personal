package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.configs.RateEventPlanConfig;
import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.EventUtils.getStoreStateProvCd;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;

@Slf4j
@Service
public class RetirementEnrollmentCompleteEventProcessor extends AbstractEventProcessor {

    public RetirementEnrollmentCompleteEventProcessor(RateEventPlanConfig rateEventPlanConfig) {
        super(ENROLLMENT_COMPLETE);
        this.rateEventPlanConfig = rateEventPlanConfig;
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }

    private final RateEventPlanConfig rateEventPlanConfig;

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("401k event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        Enrollment enrollment =(Enrollment) variables.get(ENROLLMENT);
        AssociateBenefitsProfile associateBenefitsProfile = CommonUtils.getProfile(delegateExecution);
        String isCoverageAvailable = (String) variables.get(IS_COVERAGE_AVAILABLE);

        Coverage result = getCoverage(associateEvent, isCoverageAvailable, variables);

        String basePlan = rateEventPlanConfig.getBasePlan();
        List<String> regularPlan = rateEventPlanConfig.getRegularPlan();
        List<String> catchupPlan = rateEventPlanConfig.getCatchupPlan();
        double catchupLimit = rateEventPlanConfig.getCatchupLimit();
        double regularLimit = rateEventPlanConfig.getRegularLimit();
        int catchupEligibleAge = rateEventPlanConfig.getCatchupEligibleAge();

        boolean isPlanEligible = RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent);

        variables.put(IS_PLAN_ELIGIBLE, isPlanEligible);
        variables.put(IS_COVERAGE_AVAILABLE, isCoverageAvailable);
        String storeStateProvCd = benefitsEntity.getInterDomainInfo().getAssociateInfo().getEmployment().getStoreInfo().getStoreStateProvCd();
        String employStatusCode = benefitsEntity.getInterDomainInfo().getAssociateInfo().getEmployment().getStatusCode();
        if (RateValidatorUtil.isEmploymentStatusNotValid(employStatusCode)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Associate Terminated");
        } if (validateHardshipEligibility(result, storeStateProvCd)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "ASSOC IS ON HARDSHIP");
        } else if (validateBasePlan(basePlan, storeStateProvCd, associateBenefitsProfile)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Base plan is not available in profile");
        } else if (validateCoverage(isCoverageAvailable, result)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Coverage has end date");
        } else if (validateMaxRate(associateEvent, regularPlan, result, regularLimit)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Exceeded MAX REGULAR RATE");
        } else if(validateCatchupEligibility(associateEvent, catchupPlan, benefitsEntity, catchupEligibleAge)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Associate is not eligible for catchup");
        } else if (validateMaxCatchUpRate(associateEvent, catchupPlan, result, catchupLimit)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Exceeded MAX CATCHUP RATE");
        } else if (!RateValidatorUtil.isValidRuleEligibility(associateEvent, benefitsEntity)) {
            setExceptionData(delegateExecution, VALIDATION_ERROR, "Rule Eligibility is not valid for the plan");
        } else {
            if (isCoverageAvailable.equals(TRUE)) {
                variables.put(UPDATE_COVERAGE, EventUtils.updateCoverage(associateEvent, result.coverage()));
            } else {
                variables.put(ASSOCIATE_COVERAGE, EventUtils.createCoverage(associateEvent,enrollment.getActivity()));
            }
            //Update the plan status based on rule engine response
            if (!isPlanEligible) {
                variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.updateProfile(associateEvent, benefitsEntity));
            }

        }

        delegateExecution.setVariables(variables);
        log.info("401k event processor ended");
    }

    private static boolean validateHardshipEligibility(Coverage result, String storeStateProvCd) {
        return RateValidatorUtil.isAssocInHardshipWindow(result.allRetirementCoveragesList(), storeStateProvCd);
    }
    private static boolean validateMaxCatchUpRate(AssociateEvent associateEvent, List<String> catchupPlan, Coverage result, double catchupLimit) {
        return RateValidatorUtil.isCatchupPlan(associateEvent, catchupPlan) && RateValidatorUtil.isBeyondMaxRateForCatchupPlan(associateEvent, catchupPlan, result.planTypeStr(), catchupLimit, result.allRetirementCoveragesList());
    }

    private static boolean validateCatchupEligibility(AssociateEvent associateEvent, List<String> catchupPlan, BenefitsEntity benefitsEntity, int catchupEligibleAge) {
        return RateValidatorUtil.isCatchupPlan(associateEvent, catchupPlan) && !RateValidatorUtil.isCatchupEligibleAge(benefitsEntity, catchupEligibleAge);
    }

    private static boolean validateMaxRate(AssociateEvent associateEvent, List<String> regularPlan, Coverage result, double regularLimit) {
        return RateValidatorUtil.isRegularPlan(associateEvent, regularPlan) && RateValidatorUtil.isBeyondMaxRateForRegularPlan(associateEvent, regularPlan, result.planTypeStr(), regularLimit, result.allRetirementCoveragesList());
    }

    private static boolean validateCoverage(String isCoverageAvailable, Coverage result) {
        return TRUE.equalsIgnoreCase(isCoverageAvailable) && !RateValidatorUtil.isValidCoverage(result.coverage());
    }

    private static boolean validateBasePlan(String basePlan, String storeStateProvCd, AssociateBenefitsProfile associateBenefitsProfile) {
        return basePlan != null && COUNTRY_CODE_US.equalsIgnoreCase(getStoreStateProvCd(storeStateProvCd)) &&
                !RateValidatorUtil.is401kRegularPlanAvailable(associateBenefitsProfile, basePlan);
    }

    private static Coverage getCoverage(AssociateEvent associateEvent, String isCoverageAvailable, Map<String, Object> variables) {
        AssociateBenefit coverage = null;
        List<AssociateBenefit> allRetirementCoveragesList = null;
        String planTypeStr = associateEvent.getPlanType().getPlanId();

        if(isCoverageAvailable.equals(TRUE)) {
            allRetirementCoveragesList = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
            Optional<AssociateBenefit> currentPlanCoverage = allRetirementCoveragesList.stream()
                    .filter(planCoverage -> planCoverage.getPlanId().equalsIgnoreCase(planTypeStr))
                    .findFirst();

            if (currentPlanCoverage.isPresent()) {
                coverage = currentPlanCoverage.get();
            }
        }
        return new Coverage(coverage, allRetirementCoveragesList, planTypeStr);
    }

    private record Coverage(AssociateBenefit coverage, List<AssociateBenefit> allRetirementCoveragesList, String planTypeStr) {
    }

}
