package com.walmart.benefits.platform.core.engine.exceptions;

public class DataNotAvailableException extends RuntimeException{

    public DataNotAvailableException(String message) {
        super(message);
    }
}
