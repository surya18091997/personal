package com.walmart.benefits.platform.core.engine.exceptions;

public class InvalidStateProvisionCodeException extends RuntimeException{

    public InvalidStateProvisionCodeException(String message) {
        super(message);
    }
}
