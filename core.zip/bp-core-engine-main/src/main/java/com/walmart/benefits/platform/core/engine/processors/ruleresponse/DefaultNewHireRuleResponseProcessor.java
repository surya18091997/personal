package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.RULE_RESPONSE;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class DefaultNewHireRuleResponseProcessor extends AbstractRuleResponseProcessor {

    public DefaultNewHireRuleResponseProcessor() {
        super(NEW_HIRE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultNewHireRuleResponseProcessor: Started");
        super.process(delegateExecution);
        BenefitsEntity benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY);
        String planTypeStr = (String) delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput)delegateExecution.getVariable(RULE_RESPONSE);
        PlanType planType = PlanType.valueOf(planTypeStr);
        if(associateEligibilityOutput.getIsEligibilityUpdated() != null && associateEligibilityOutput.getIsEligibilityUpdated()){
            EventUtils.setPlanEligibility(associateEligibilityOutput, planType, benefitsEntity);
        }
        delegateExecution.setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
        log.info("DefaultNewHireRuleResponseProcessor: Completed");

    }

    @Override
    public String getPlanType() {
        return null;
    }
}
