package com.walmart.benefits.platform.core.engine.consumer;

import com.walmart.benefits.platform.core.engine.service.common.AsyncProcessorService;
import com.walmart.benefits.platform.core.engine.service.common.EventArchiveService;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class EventConsumer {

    private final EventArchiveService eventArchiveService;

    private final AsyncProcessorService asyncProcessorService;

    public EventConsumer(EventArchiveService eventArchiveService, AsyncProcessorService asyncProcessorService) {
        this.eventArchiveService = eventArchiveService;
        this.asyncProcessorService = asyncProcessorService;
    }

    /**
     * Reads the events from upstream systems - Workday/Core Hr
     *
     * @param events
     * @param acknowledgment
     */
    @KafkaListener(topics = "${benefits.kafka.topic-name}", containerFactory = "kafkaListenerContainerFactory")
    public void onEvent(List<ConsumerRecord<String, Object>> events, Acknowledgment acknowledgment) {
        try {
            List<AssociateEvent> associateEvents = eventArchiveService.storeEvents(events);
            acknowledgment.acknowledge();
            log.info("acknowledge completed..");
            Map<EventType, List<AssociateEvent>> eventTypeListMap = associateEvents.stream().collect(Collectors.groupingBy(AssociateEvent::getEventType));
            eventTypeListMap.forEach((key, values) -> {
                log.info("Event Type - {}, Records size - {}", key, values.size());
                asyncProcessorService.processAsync(values);
            });
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
        }
    }

}