package com.walmart.benefits.platform.core.engine.service.enrollment;

import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@Service("ProfileConsentService")
public class ProfileConsentService implements JavaDelegate {
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            delegateExecution.setVariable(IS_PROFILE_CONSENT_AVAILABLE, FALSE);
            var enrollment = (Enrollment) variables.get(ENROLLMENT);
            delegateExecution.setVariable(PLAN_TYPE, CONSENT_UPDATE);
            if(enrollment != null && enrollment.getConsent() != null) {
                delegateExecution.setVariable(IS_PROFILE_CONSENT_AVAILABLE, TRUE);
                delegateExecution.setVariable(ASSOCIATE_BENEFITS_PROFILE, EventUtils.updateConsentProfile(enrollment));
            }

        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ENROLLMENT_SERVICE, exception.getMessage());
        }
    }
}
