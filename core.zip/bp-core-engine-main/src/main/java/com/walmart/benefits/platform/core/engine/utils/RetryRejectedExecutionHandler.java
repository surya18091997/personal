package com.walmart.benefits.platform.core.engine.utils;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.DEFAULT_RETRY;

@Slf4j
public class RetryRejectedExecutionHandler implements RejectedExecutionHandler {

    protected final long retryDelay; // Delay between retries in milliseconds

    public RetryRejectedExecutionHandler() {
        this.retryDelay = DEFAULT_RETRY;
    }
    /**
     * Constructor for the Retry Rejected Execution Handler
     * @param retryDelay Delay parameter in milli seconds
     */
    public RetryRejectedExecutionHandler(long retryDelay) {
        this.retryDelay = retryDelay;
    }

    /**
     * This method used to handle the Task rejection and retry the task.
     * @param r the runnable task requested to be executed
     * @param executor the executor attempting to execute this task
     */
    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
        boolean taskSubmitted = false;
        while (!taskSubmitted) {
            try {
                log.info("Task rejected and handling retry");
                TimeUnit.MILLISECONDS.sleep(retryDelay); // Wait before retrying
                executor.submit(r); // Retry submitting the task
                taskSubmitted = true; // If successful, exit the loop
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restore the interrupted status
                log.info("Task retry interrupted");
                break;
            } catch (RejectedExecutionException e) {
                // Task was rejected again; continue retrying
                log.info("Task retry failed; retrying");
            }
        }
    }
}
