package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class DefaultRehireRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public DefaultRehireRuleRequestProcessor() {
        super(RE_HIRE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultRehireRuleRequestProcessor: Default processing for RE_HIRE event");
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() {
        return null;
    }
}
