package com.walmart.benefits.platform.core.engine.service.external.datalake;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DataLakeJsonReaderFactory {

    private final List<DataLakeJsonReader> dataLakeJsonReaderList;

    public DataLakeJsonReader getDataLakeJsonReader(EventType eventType) {
        return dataLakeJsonReaderList.stream()
                .filter(dataLakeJsonReader -> matches(dataLakeJsonReader, eventType))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No DataLakeJsonReader found for event type: " + eventType));
    }

    private boolean matches(DataLakeJsonReader dataLakeJsonReader, EventType eventType) {
        return dataLakeJsonReader.getEventType() != null &&
        dataLakeJsonReader.getEventType().equals(eventType);
    }


}
