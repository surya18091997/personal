package com.walmart.benefits.platform.core.engine.processors.event.dental;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.assessment.Assessment;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

/**
 * @author Jedidiah Jeyaraj
 * @date 13/03/25
 */

@Slf4j
@Service
public class DentalNewHireEventProcessor extends AbstractEventProcessor {

    public DentalNewHireEventProcessor() {
        super(NEW_HIRE);
    }

    @Override
    public String getPlanType() {
        return DENTAL;
    }

    @Override
    public void process(DelegateExecution delegateExecution){
        log.info("Dental event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput) variables.get(RULE_RESPONSE);
        if(associateEligibilityOutput.getAssessmentEligibility()){
            variables.put(ASSESSMENT, createAssessment(benefitsEntity, associateEligibilityOutput));
        }
        variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.associateProfile(benefitsEntity));
        variables.put(ASSOCIATE_COVERAGE, associateCoverage(benefitsEntity));
        delegateExecution.setVariable("assessmentEligibility",associateEligibilityOutput.getAssessmentEligibility());
        delegateExecution.setVariables(variables);
        log.info("Dental event processor ended");
    }

    private List<Assessment> createAssessment(BenefitsEntity benefitsEntity, AssociateEligibilityOutput associateEligibilityOutput) {
        associateEligibilityOutput.getAssessments().forEach(assessment -> {
            assessment.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
            assessment.setCreatedAt(getUTCTimeAsString());
            assessment.setCreatedBy(SYSTEM_CORE_ENGINE);

        });
        return associateEligibilityOutput.getAssessments();
    }

    private List<AssociateBenefit> associateCoverage(BenefitsEntity benefitsEntity) {
        List<AssociateBenefit> associateBenefits = new ArrayList<>();
        if(benefitsEntity.getIntraDomainInfo().getAssociateBenefit().getPlanId() != null) {
            AssociateBenefit benefit = benefitsEntity.getIntraDomainInfo().getAssociateBenefit();
            benefit.setStartDate(convertDateToUTCSystemZone(benefit.getStartDate()));
            benefit.setCreatedAt(getUTCTimeAsString());
            benefit.setCreatedBy(SYSTEM_CORE_ENGINE);
            benefit.setChangeActivity(Activity.NEW_HIRE);
            associateBenefits.add(benefit);
        }
        return associateBenefits;
    }
}
