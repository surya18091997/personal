package com.walmart.benefits.platform.core.engine.configs;

import com.walmart.benefits.platform.core.engine.utils.RetryRejectedExecutionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASYNC_THREAD_NAME;


@Configuration
@EnableAsync
public class AsyncConfig {


    @Value("#{'${async.corePoolSize}'}")
    private Integer corePoolSize;

    @Value("#{'${async.maxPoolSize}'}")
    private Integer maxPoolSize;

    @Value("#{'${async.maxQueueSize}'}")
    private Integer maxQueueSize;

    @Value("#{'${async.retryDelay}'}")
    private Integer retryDelay;


    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(maxQueueSize);
        executor.setThreadNamePrefix(ASYNC_THREAD_NAME);
        executor.setRejectedExecutionHandler(new RetryRejectedExecutionHandler(retryDelay));
        executor.initialize();
        return executor;
    }
}