package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.configs.EventTypeConfig;
import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@Service("WorkflowChooserService")
@AllArgsConstructor
public class WorkflowChooserService implements JavaDelegate {


    private final RuntimeService runtimeService;

    private final EventTypeConfig eventTypeConfig;

    private final EncryptionUtil encryptionUtil;

    private final RuleMetaDataConfig ruleMetaDataConfig;
    /**
     * Select appropriate workflow based on event and plan type
     *
     * @param delegateExecution
     */
    @Override
    public void execute(DelegateExecution delegateExecution) {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            String eventTypeKey = CommonUtils.generateKey(associateEvent.getEventType());
            List<String> planTypes = eventTypeConfig.getEventType().get(eventTypeKey).getPlanTypes();
            Map<String, List<RuleCategory>> planTypeRuleCategories = ruleMetaDataConfig.getEventType().get(eventTypeKey);

            variables.put(EXECUTE_LATER_AS_BATCH, eventTypeConfig.shouldExecuteAsBatch(eventTypeKey) && !Boolean.TRUE.equals(variables.get(OVERRIDE_DEFERRED_BATCH_EXECUTION)));

            if (eventTypeConfig.shouldExecuteSubPlanTypeWorkflow(eventTypeKey)) {
                Optional.ofNullable(planTypes).ifPresent(plans -> planTypes.forEach(planType -> {
                    variables.put(PLAN_TYPE, planType);
                    planTypeRuleCategories.forEach((subPlanType, ruleCategoryList) -> {
                        // Create a new instance of AssociateEvent using a factory method
                        AssociateEvent newAssociateEvent = EventUtils.createNewAssociateEvent(associateEvent, PlanType.valueOf(subPlanType));
                        newAssociateEvent.setPlanType(PlanType.valueOf(subPlanType));
                        // Update the variables map with the new AssociateEvent instance
                        variables.put(ASSOCIATE_EVENT, newAssociateEvent);

                        // Set the updated variables back to the delegateExecution
                        delegateExecution.setVariables(variables);

                        // Get the workflow name using the current planType and eventType
                        String workflowName = CommonUtils.getWorkflowName(String.valueOf(planType), newAssociateEvent.getEventType());

                        // Log the workflow information
                        logWorkflowInformation(workflowName, newAssociateEvent);

                        // Start the process instance with the updated variables
                        runtimeService.startProcessInstanceByKey(workflowName, variables);
                    });
                }));
            } else {
                Optional.ofNullable(planTypes).ifPresentOrElse(
                        plans -> {
                            assert planTypes != null;
                            planTypes.forEach(planType -> {
                                variables.put(PLAN_TYPE, planType);
                                String workflowName = CommonUtils.getWorkflowName(planType, associateEvent.getEventType());
                                runtimeService.startProcessInstanceByKey(workflowName, variables);
                                logWorkflowInformation(workflowName, associateEvent);
                            });
                        }, () -> {
                            log.info("No plan type found for event type {}", eventTypeKey);
                            String workflowName = CommonUtils.getWorkflowName(null, associateEvent.getEventType());
                            runtimeService.startProcessInstanceByKey(workflowName, variables);
                            logWorkflowInformation(workflowName, associateEvent);
                        });
            }

        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, WORK_FLOW_CHOOSER_SERVICE, exception.getMessage());
        }
    }

    private void logWorkflowInformation(String workflowName, AssociateEvent newAssociateEvent) {
        log.info("Workflow Triggered, Workflow Name- {}, Associate Id - {}", workflowName,
                encryptionUtil.encrypt(String.valueOf(newAssociateEvent.getAssociateId())));
    }


}
