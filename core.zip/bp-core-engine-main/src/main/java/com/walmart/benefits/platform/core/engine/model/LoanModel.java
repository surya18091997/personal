package com.walmart.benefits.platform.core.engine.model;

import lombok.Data;

@Data
public class LoanModel {
    private String ssnId;
    private String loanNumber;
    private double deductionAmount;
    private String loanType;
    private String payrollId;
    private double goalAmount ;
    private String payrollFrequency;
    private String storeLocationCode;
    private String countryCode;
}
