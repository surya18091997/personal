package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.ActivityTypes;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogEnrollment;

@Slf4j
@Service("CreateEnrollmentAPIService")
public class CreateEnrollmentAPIService implements JavaDelegate {


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public CreateEnrollmentAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Push Data to benefits Profile API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        log.info("Create Enrollment api started..., Associate Id  {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            var createEnrollment = (Enrollment) variables.get(CREATE_ENROLLMENT);
            if (createEnrollment == null) {
                log.info("There is No Enrollment, Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
                return;
            }

            ResponseEntity<String> response = restTemplate.exchange(httpUtils.getEnrollmentUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(createEnrollment, httpUtils.getAssociateEnrollmentServiceAppName()), String.class);
            log.info("Create Enrollment api status code : {}, Associate Id  {}", response.getStatusCode(), encryptionUtil.encrypt(associateEvent.getAssociateId()));


           ResponseEntity<String> transactionLogResponse = restTemplate.exchange(httpUtils.getTransactionLogUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(getTransactionLogEnrollment(createEnrollment,associateEvent), httpUtils.getTransactionLogServiceAppName()), String.class);
            log.info("TransactionLogAPI status code : {}, Associate Id {}", transactionLogResponse.getStatusCode(),encryptionUtil.encrypt(associateEvent.getAssociateId()));

        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount,ASSOCIATE_ENROLLMENT_SERVICE_CREATE_SERVER_ERROR);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_ENROLLMENT_SERVICE_CREATE, exception.getMessage());
        }

    }

}
