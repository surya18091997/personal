package com.walmart.benefits.platform.core.engine.service.external.datalake;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;


@Slf4j
public class AbstractDataLakeJsonReader implements DataLakeJsonReader {

    private final EventType eventType;

    @Value("${external.data-lake-unload.gcs-path}")
    @Getter
    private String unloadedDataLakePath;

    public AbstractDataLakeJsonReader(EventType eventType) {
        this.eventType = eventType;
    }

    @Override
    public EventType getEventType() {
        return eventType;
    }

    @Override
    public String readDataLakeJsonFiles() throws IOException {
        return "";
    }
}