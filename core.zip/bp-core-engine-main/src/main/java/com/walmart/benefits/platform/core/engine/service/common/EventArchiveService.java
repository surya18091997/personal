package com.walmart.benefits.platform.core.engine.service.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;

import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
@AllArgsConstructor
public class EventArchiveService {

    private final EventArchiveDao eventArchiveDao;

    private final ObjectMapper objectMapper;

    private final RetryTemplate retryTemplate;

    /**
     * Store upstream events in DB for reconciliation purpose
     *
     * @param events
     * @return List<AssociateEvent>
     */
    @Transactional
    public List<AssociateEvent> storeEvents(List<ConsumerRecord<String, Object>> events) {
        try {
            log.info("Store events started...");
            List<AssociateEvent> associateEvents = new ArrayList<>();
            List<Event> eventList = new ArrayList<>();
            for (ConsumerRecord<String, Object> event : events) {
                if (event.value() != null) {
                    AssociateEvent associateEvent = ConverterUtil.convertToObject(event.value(), AssociateEvent.class);
                    eventList.add(toEvent(associateEvent));
                    associateEvents.add(associateEvent);
                    log.info("UUID - {}", associateEvent.getId());
                }
            }
            List<Event> savedEvents = saveEvents(eventList);

            log.info("Event Stored in Database, Count - {}", savedEvents.size());
            return associateEvents;
        } catch (Exception e) {
            log.error("Error while storing events: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to store events", e);
        }
    }

    @Transactional
    public List<Event> saveEvents(List<Event> eventList) {
        List<Event> savedEvents = new ArrayList<>();
        try {
            if (!eventList.isEmpty()) {
                savedEvents = retryTemplate.execute(retryContext -> {
                    log.info("saveEvents :: Retry attempt # {}", retryContext.getRetryCount());
                    return eventArchiveDao.saveAll(eventList);
                }, retryContext -> {
                    log.error("saveEvents :: Failed to store events after retries: {}", retryContext.getLastThrowable().getMessage());
                    throw new RuntimeException("Failed to store events after retries", retryContext.getLastThrowable());
                });
            }
        } catch (DataAccessException | ResourceAccessException e) {
            log.error("saveEvents :: Database access error while saving events: {}", e.getMessage(), e);
            throw new RuntimeException("saveEvents :: Database access error", e);
        } catch (Exception e) {
            log.error("saveEvents :: Unexpected error while saving events: {}", e.getMessage(), e);
            throw new RuntimeException("saveEvents :: Unexpected error while saving events", e);
        }

        return savedEvents;
    }

    public Event toEvent(AssociateEvent associateEvent) throws JsonProcessingException {
        return Event.builder().id(associateEvent.getId())
                .associateId(associateEvent.getAssociateId())
                .eventType(associateEvent.getEventType())
                .origin(associateEvent.getOrigin().getValue())
                .planType(associateEvent.getPlanType())
                .additionalFields(associateEvent.getAdditionalInfo() != null ? objectMapper.writeValueAsString(associateEvent.getAdditionalInfo()) : null)
                .createdAt(ConverterUtil.getUTCTimeAsString()).createdBy(ApplicationConstants.SYSTEM_CORE_ENGINE)
                .description(associateEvent.getDescription()).build();
    }

    public AssociateEvent toAssociateEvent(Event event) {
        return AssociateEvent.builder().id(event.getId()).associateId(event.getAssociateId())
                .eventType(event.getEventType()).description(event.getDescription())
                .origin(EventOrigin.valueOf(event.getOrigin())).planType(event.getPlanType())
                .additionalInfo(event.getAdditionalFields()).build();
    }

}
