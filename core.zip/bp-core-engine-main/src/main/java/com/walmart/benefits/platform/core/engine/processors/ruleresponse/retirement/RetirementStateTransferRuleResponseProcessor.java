package com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.AbstractRuleResponseProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Contribution;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.ContributionType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;

@Slf4j
@Service
public class RetirementStateTransferRuleResponseProcessor extends AbstractRuleResponseProcessor {

    public RetirementStateTransferRuleResponseProcessor() {
        super(STATE_TRANSFER);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("StateTransferRuleResponseProcessor Started");
        BenefitsEntity benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(BENEFITS_ENTITY);
        AssociateEvent associateEvent = (AssociateEvent) delegateExecution.getVariable(ASSOCIATE_EVENT);
        String planTypeStr = (String) delegateExecution.getVariable(PLAN_TYPE_STR);
        AssociateEligibilityOutput associateeligibilityoutput = (AssociateEligibilityOutput)delegateExecution.getVariable(RULE_RESPONSE);
        PlanType planType = PlanType.valueOf(planTypeStr);


        var planEligibilities = getPlanEligibilities(associateeligibilityoutput, associateEvent);

        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setEligibility(new Eligibility());
        benefitsEntity.getIntraDomainInfo().setAssociateBenefitsProfile(associateBenefitsProfile);
        benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().setPlans(planEligibilities);

        AssociateBenefit associateBenefit = new AssociateBenefit();
        Contribution contribution = new Contribution();
        if (!Objects.isNull(associateeligibilityoutput.getIsCoverageUpdated()) && Boolean.TRUE.equals(associateeligibilityoutput.getIsCoverageUpdated())) {
            associateBenefit.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
            associateBenefit.setStartDate(associateeligibilityoutput.getCoverageStartDate() != null ? associateeligibilityoutput.getCoverageStartDate() : null);
            associateBenefit.setPlanId(planType.getPlanId() != null ? planType.getPlanId() : null);
            associateBenefit.setPlanGroup(planType.getPlanGroup() != null ? planType.getPlanGroup() : null);
            associateBenefit.setEndDate(associateeligibilityoutput.getCoverageEndDate() != null ? associateeligibilityoutput.getCoverageEndDate() : null);
            contribution.setValue(associateeligibilityoutput.getContributionAmount() != null ? associateeligibilityoutput.getContributionAmount() : null);
            contribution.setType(ContributionType.PERCENT);
            associateBenefit.setContribution(contribution);
            benefitsEntity.getIntraDomainInfo().setAssociateBenefit(associateBenefit);
        }
        log.info("Associate id : {}, Plan Type : {} , Eligibility Updated : {}",
                associateEvent.getAssociateId(), associateEvent.getPlanType().getPlanId(),
                associateeligibilityoutput.getIsEligibilityUpdated());

        delegateExecution.setVariable(BENEFITS_ENTITY, benefitsEntity);
        delegateExecution.setVariable(IS_ELIGIBILITY_UPDATED, associateeligibilityoutput.getIsEligibilityUpdated());
        delegateExecution.setVariable(IS_COVERAGE_UPDATED, associateeligibilityoutput.getIsCoverageUpdated());

        log.info("StateTransferRuleResponseProcessor Completed");
    }

    private static ArrayList<PlanEligibility> getPlanEligibilities(AssociateEligibilityOutput associateeligibilityoutput, AssociateEvent associateEvent) {
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setEligibleDate(associateeligibilityoutput.getAssociateEligibilityDate() != null ? associateeligibilityoutput.getAssociateEligibilityDate() : null);
        planEligibility.setIsEligible(associateeligibilityoutput.getAssociateEligibilityIndicator() != null ? associateeligibilityoutput.getAssociateEligibilityIndicator() : null);
        planEligibility.setIsCompanyMatchEligible(associateeligibilityoutput.getCompanyMatchEligibilityIndicator() != null ? associateeligibilityoutput.getCompanyMatchEligibilityIndicator() : null);
        planEligibility.setCompanyMatchEligibleDate(associateeligibilityoutput.getCompanyMatchEligibilityDate() != null ? associateeligibilityoutput.getCompanyMatchEligibilityDate() : null);
        planEligibility.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        planEligibility.setPlanId(associateEvent.getPlanType().getPlanId());
        planEligibility.setOriginalHireDate(associateeligibilityoutput.getCommencementDate());
        var planEligibilities = new ArrayList<PlanEligibility>();
        planEligibilities.add(planEligibility);
        return planEligibilities;
    }


    @Override
    public EventType getEventType() {
        return STATE_TRANSFER;
    }
    @Override
    public String getPlanType() { return RETIREMENT; }
}
