package com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.AbstractRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.utils.DataLakeJsonUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorInput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.EmploymentHistory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PayrollSnapShot;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.exception.NotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.EventUtils.getStoreStateProvCd;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class RetirementRehireRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public RetirementRehireRuleRequestProcessor(DataLakeJsonUtil dataLakeJsonUtil) {
        super(RE_HIRE);
        this.dataLakeJsonUtil = dataLakeJsonUtil;
    }

    private final DataLakeJsonUtil dataLakeJsonUtil;

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Rehire Rule Response Processor");

        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        String planTypeStr = (String) variables.get(PLAN_TYPE_STR);
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        String dataLakeJsonCacheKey = (String) variables.get(DATA_LAKE_JSON_CACHE_KEY);

        AssociateBenefitsProfile associateBenefitsProfile = getAssociateBenefitsProfileFromVariables(delegateExecution, variables, dataLakeJsonCacheKey, associateEvent);
        if (Objects.isNull(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()) && Objects.nonNull(associateBenefitsProfile)) {
            benefitsEntity.getIntraDomainInfo().setAssociateBenefitsProfile(associateBenefitsProfile);
        }
        ConnectorResponse connectorResponse = (ConnectorResponse) delegateExecution.getVariable(CONNECTOR_RESPONSE);
        String originalHireDate = connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().getOriginalHireDate();
        String termDate = getLatestTermDate(connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().getEmploymentHistory());

        PlanEligibility currentPlanEligibility = getCurrentPlanEligibility(associateBenefitsProfile, planTypeStr);
        String stateCode = getStoreStateProvCd(benefitsEntity.getInterDomainInfo().getAssociateInfo().getEmployment().getStoreInfo().getStoreStateProvCd());

        if(planTypeStr.toLowerCase().endsWith((RETIREMENT_REGULAR_PLAN_SUFFIX + stateCode).toLowerCase()) &&
                (Objects.isNull(currentPlanEligibility))) {
            delegateExecution.setVariable(ApplicationConstants.IS_REHIRE_REBASE, true);
        }
        currentPlanEligibility = Objects.isNull(currentPlanEligibility) ? new PlanEligibility() : currentPlanEligibility;

        List<PostPayrollSnapshot> postPayrollSnapshots = getPostPayrollSnapshotsFromCache(dataLakeJsonCacheKey, associateEvent.getAssociateId());
        Double originalComputationalHours = calculateComputationalHoursSum(postPayrollSnapshots, getOriginalHireDate(currentPlanEligibility, originalHireDate));
        Double previousFiscalYearHours = calculateComputationalHoursSum(postPayrollSnapshots, getPreviousFiscalYearBeginDate());

        updateEligibilityInputs(delegateExecution, currentPlanEligibility, originalHireDate, originalComputationalHours, previousFiscalYearHours, termDate);

        log.info("Rehire Rule Request Processor completed");
    }

    private AssociateBenefitsProfile getAssociateBenefitsProfileFromVariables(DelegateExecution delegateExecution, Map<String, Object> variables, String dataLakeJsonCacheKey, AssociateEvent associateEvent) {
        boolean isProfileAvailable = Objects.equals(variables.get(IS_PROFILE_AVAILABLE),"true");
        AssociateBenefitsProfile profileFromDataLake = getAssociateBenefitsProfile(
                dataLakeJsonUtil.getDataFromCache(dataLakeJsonCacheKey).get(PROFILE_HUDI_JSON),
                associateEvent.getAssociateId()
        );

        AssociateBenefitsProfile associateBenefitsProfile = isProfileAvailable
                ? (AssociateBenefitsProfile) variables.get(GET_ASSOCIATE_PROFILE_RESPONSE)
                : profileFromDataLake;

        if (!Objects.isNull(associateBenefitsProfile) && !isProfileAvailable) {
            delegateExecution.setVariable(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
        }

        return associateBenefitsProfile;
    }

    private List<PostPayrollSnapshot> getPostPayrollSnapshotsFromCache(String dataLakeJsonCacheKey, String associateId) {
        List<Object> postPayrollSnapshotsHudiData = dataLakeJsonUtil.getDataFromCache(dataLakeJsonCacheKey).get(POST_PAYROLL_SNAPSHOT_HUDI_JSON);
        return getPostPayrollSnapshots(postPayrollSnapshotsHudiData, associateId);
    }

    private PlanEligibility getCurrentPlanEligibility(AssociateBenefitsProfile associateBenefitsProfile, String planTypeStr) {
        Optional<PlanEligibility> existingPlan = Optional.ofNullable(associateBenefitsProfile)
                .flatMap(profile -> {
                    if (profile.getEligibility() == null) {
                        return Optional.empty();
                    }
                    return profile.getEligibility().getPlans().stream()
                            .filter(plan -> planTypeStr.equals(plan.getPlanId().toUpperCase()))
                            .findFirst();
                });
        return existingPlan.orElse(null);
    }

    private boolean isPreviouslyCompanyMatchEligible(PlanEligibility currentPlanEligibility) {
        return Boolean.TRUE.equals(currentPlanEligibility.getIsPreviouslyCompanyMatchEligible()) ||
                Boolean.TRUE.equals(currentPlanEligibility.getIsCompanyMatchEligible());
    }

    void updateEligibilityInputs(DelegateExecution delegateExecution, PlanEligibility currentPlanEligibility, String originalHireDate, Double originalComputationalHours, Double previousFiscalYearHours, String termDate) {
        boolean isPreviouslyCompanyMatchEligible = isPreviouslyCompanyMatchEligible(currentPlanEligibility);

        if (delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT) != null) {
            AssociateEligibilityInput associateEligibilityInput = (AssociateEligibilityInput) delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT);
            associateEligibilityInput.setOriginalHireDate(getOriginalHireDate(currentPlanEligibility, originalHireDate));
            associateEligibilityInput.setComputationalHour(originalComputationalHours);
            associateEligibilityInput.setPrevCompanyMatchEligibleIndicator(isPreviouslyCompanyMatchEligible);
            associateEligibilityInput.setPrevEligibilityDate(currentPlanEligibility.getEligibleDate());
            delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
        }

        if (delegateExecution.getVariable(COMPANY_MATCH_ELIGIBILITY_INPUT) != null) {
            CompanyMatchEligibilityInput companyMatchEligibilityInput = (CompanyMatchEligibilityInput) delegateExecution.getVariable(COMPANY_MATCH_ELIGIBILITY_INPUT);
            companyMatchEligibilityInput.setOriginalHireDate(getOriginalHireDate(currentPlanEligibility, originalHireDate));
            companyMatchEligibilityInput.setComputationalHour(originalComputationalHours);
            companyMatchEligibilityInput.setPrevCompanyMatchEligibleIndicator(isPreviouslyCompanyMatchEligible);
            companyMatchEligibilityInput.setPrevCompanyMatchEligibilityDate(currentPlanEligibility.getCompanyMatchEligibleDate());
            delegateExecution.setVariable(COMPANY_MATCH_ELIGIBILITY_INPUT, companyMatchEligibilityInput);
        }

        if (delegateExecution.getVariable(REHIRE_INDICATOR_INPUT) != null) {
            RehireIndicatorInput rehireIndicatorInput = (RehireIndicatorInput) delegateExecution.getVariable(REHIRE_INDICATOR_INPUT);
            rehireIndicatorInput.setComputationalHour(originalComputationalHours);
            rehireIndicatorInput.setOriginalHireDate(getOriginalHireDate(currentPlanEligibility, originalHireDate));
            rehireIndicatorInput.setPreviousFiscalHours(previousFiscalYearHours);
            rehireIndicatorInput.setPrevCompanyMatchEligibleIndicator(isPreviouslyCompanyMatchEligible);
            rehireIndicatorInput.setTermDate(termDate);
            delegateExecution.setVariable(REHIRE_INDICATOR_INPUT, rehireIndicatorInput);
        }
    }

    private String getOriginalHireDate(PlanEligibility currentPlanEligibility, String originalHireDate) {
        return !Objects.isNull(currentPlanEligibility.getOriginalHireDate())
                ? currentPlanEligibility.getOriginalHireDate().substring(0, 10)
                : originalHireDate;
    }

    @SuppressWarnings("unchecked")
    public List<PostPayrollSnapshot> getPostPayrollSnapshots(List<Object> postPayrollSnapshotsHudiData, String associateId) {
        List<PostPayrollSnapshot> postPayrollSnapshots = (List<PostPayrollSnapshot>) (List<?>) postPayrollSnapshotsHudiData;
        return postPayrollSnapshots.stream()
                .filter(snapshot -> associateId.equals(snapshot.getAssociateId()))
                .toList();
    }

    @SuppressWarnings("unchecked")
    public AssociateBenefitsProfile getAssociateBenefitsProfile(List<Object> profileHudiData, String associateId) {
        List<AssociateBenefitsProfile> associateBenefitsProfiles = (List<AssociateBenefitsProfile>) (List<?>) profileHudiData;
        return associateBenefitsProfiles.stream()
                .filter(profile -> associateId.equals(profile.getAssociateId()))
                .max(Comparator.comparingInt(AssociateBenefitsProfile::getVersion))
                .orElse(null);
    }

    /**
     * Calculates the sum of computational hours for snapshots within a specific date range
     *
     * @param postPayrollSnapshots List of payroll snapshots
     * @param startDate The start date in yyyy-MM-dd format to filter payroll snapshots
     * @return Sum of eligible hours for filtered snapshots
     */
    public Double calculateComputationalHoursSum(List<PostPayrollSnapshot> postPayrollSnapshots, String startDate) {
        if (postPayrollSnapshots == null) {
            log.warn("Profile response body is null");
            return 0.0;
        }

        // Parse the startDate
        LocalDate start = LocalDate.parse(startDate);
        // Calculate the end date (startDate + 1 year)
        LocalDate end = start.plusYears(1);

        // Determine the plan ID based on the start date condition
        String planId = start.isAfter(FISCAL_YEAR_START_DATE)
                ? RETIREMENT_POST_PAYROLL_COMPANY_MATCH_PLAN_ID
                : RETIREMENT_POST_PAYROLL_ASSOCIATE_MATCH_PLAN_ID;

        return postPayrollSnapshots.stream()
                // Filter snapshots by date range
                .filter(snapshot -> {
                    if (snapshot.getPayPeriodEndDate() == null) {
                        return false;
                    }
                    LocalDate payPeriodEnd = LocalDate.parse(snapshot.getPayPeriodEndDate().substring(0, 10));
                    return !payPeriodEnd.isBefore(start) && !payPeriodEnd.isAfter(end);
                })
                .flatMap(snapshot -> snapshot.getPayrollSnapShot().stream())
                .filter(item -> planId.equals(item.getPlanId()))
                .mapToDouble(PayrollSnapShot::getEligibleHours)
                .sum();
    }

    /**
     * Returns the beginning date of the previous fiscal year.
     * Walmart's fiscal year starts on February 1 and ends on January 31.
     *
     * @return LocalDate representing February 1st of the previous fiscal year
     */
    public String getPreviousFiscalYearBeginDate() {
        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        // The fiscal year that ended most recently
        int previousFiscalYear;
        // If current date is in January, we're still in the previous fiscal year
        // that started last February
        if (currentDate.getMonthValue() == 1) {
            previousFiscalYear = currentYear - 2;
        } else {
            previousFiscalYear = currentYear - 1;
        }
        return LocalDate.of(previousFiscalYear, 2, 1).toString();
    }

    public String getLatestTermDate(List<EmploymentHistory> employmentHistoryList) {
        try {
            if (Objects.isNull(employmentHistoryList)) return PLACEHOLDER_TERM_DATE;
            Optional<EmploymentHistory> latestEmploymentHistory = employmentHistoryList.stream()
                    .filter(eh -> eh.getTermDate() != null && !Objects.equals(eh.getTermDate(), ""))
                    .max(Comparator.comparing(EmploymentHistory::getTermDate));

            return latestEmploymentHistory.map(EmploymentHistory::getTermDate).orElse(PLACEHOLDER_TERM_DATE);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            throw new NotFoundException(TERM_DATE_NOT_FOUND, exception);
        }
    }

    @Override
    public EventType getEventType() {
        return RE_HIRE;
    }
    @Override
    public String getPlanType() { return RETIREMENT; }
}
