package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.consumer.AES;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Base64;


@Slf4j
@Component
public class EncryptionUtil {

    @Value("${encryption.key}")
    private String encryptionKey;

    @Value("${encryption.enabled}")
    private String encryptionEnabled;

    public  String encrypt(String data) {
        try {
            if(encryptionEnabled.equalsIgnoreCase("false")) {
                return data;
            }
            byte[] encrypted = AES.encrypt(data.getBytes(StandardCharsets.UTF_8), encryptionKey);
            return Base64.getEncoder().encodeToString(encrypted);
        }catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
