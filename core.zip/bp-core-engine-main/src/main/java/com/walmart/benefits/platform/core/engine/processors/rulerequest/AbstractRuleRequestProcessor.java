package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;

@Slf4j
public abstract class AbstractRuleRequestProcessor implements RuleRequestProcessor {
    private final EventType eventType;

    protected AbstractRuleRequestProcessor(EventType eventType) {
        this.eventType = eventType;
    }

    @Override
    public EventType getEventType() {
        return eventType;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Processing rule request for plan: {}, event: {}", getPlanType(), getEventType());
    }

    @Override
    public abstract String getPlanType();
}