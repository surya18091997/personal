package com.walmart.benefits.platform.core.engine.processors.ruleresponse.disability;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.AbstractRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.DefaultNewHireRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.CoverageOption;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;


@Slf4j
@Service
public class DisabilityNewHireRuleResponseProcessor extends DefaultNewHireRuleResponseProcessor {

    public DisabilityNewHireRuleResponseProcessor() {
        super();
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        //Disability Related Rules Response goes here
        String planTypeStr = (String) delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR);
        log.info("Disability Rule Response Processor Started :: {}",planTypeStr);
        PlanType planType = PlanType.valueOf(planTypeStr);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput)delegateExecution.getVariable(RULE_RESPONSE);
        if(Boolean.TRUE.equals(associateEligibilityOutput.getIsEnrollmentRequired())){
            PlanElection planElection = new PlanElection();
            planElection.setPlanGroup(planType.getPlanGroup());
            planElection.setPlanId(planType.getPlanId());
            planElection.setTier(Tier.valueOf(associateEligibilityOutput.getTier()));
            planElection.setContribution(null);
            CoverageOption defaultCoverageOption = CoverageOption.valueOf(associateEligibilityOutput.getCoverageOption());
            planElection.setCoverageOption(defaultCoverageOption);
            List<PlanElection> planElections = (List<PlanElection>) delegateExecution.getVariable(PLAN_ELECTIONS);
            planElections.add(planElection);
            delegateExecution.setVariable(PLAN_ELECTIONS,planElections);
        }
        log.info("Disability Rule Response Processor Completed");
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() { return DISABILITY; }
}
