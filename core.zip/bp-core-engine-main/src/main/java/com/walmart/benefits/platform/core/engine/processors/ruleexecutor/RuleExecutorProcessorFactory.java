package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Jedidiah Jeyaraj
 * @date 20/03/25
 */

@Service
@RequiredArgsConstructor
public class RuleExecutorProcessorFactory {
    private final List<RuleExecutorProcessor> processors;
    private final List<RuleExecutorProcessor> defaultProcessors;

    public RuleExecutorProcessor getProcessor(String planType) {
        return processors.stream()
                .filter(p -> matches(p, planType))
                .findFirst()
                .orElseGet(this::getDefaultProcessor);
    }

    private RuleExecutorProcessor getDefaultProcessor() {
        return defaultProcessors.stream()
                .filter(p -> p.getPlanType() == null)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No default processor found for RuleExecutorProcessor: "));
    }

    private boolean matches(RuleExecutorProcessor processor, String planType) {
        return processor.getPlanType() != null &&
                processor.getPlanType().equals(planType);
    }
}
