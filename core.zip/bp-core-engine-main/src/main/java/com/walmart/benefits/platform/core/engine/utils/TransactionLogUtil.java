package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.LoanStatusCode;
import com.walmart.benefitsplatformentitymodel.intradomain.common.DocumentType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;


import java.util.Objects;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.getFutureDateForEnrollmentEvent;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.getUTCTimeAsString;

@Slf4j
public class TransactionLogUtil {

    private TransactionLogUtil() {}

    /**
     * Added DocumentType to identify who is creating transaction log. This will be removed/updated once entity model updated.
     * @param associateBenefitsProfile Associate Benefits Profile
     * @param associateEvent Event that triggered the flow
     * @return TransactionLog
     */
    public static TransactionLog getTransactionLogProfile(AssociateBenefitsProfile associateBenefitsProfile, AssociateEvent associateEvent,
                                                          String planType, Enrollment enrollment) {
        TransactionLog transactionLog= new TransactionLog();
        transactionLog.setAssociateId(associateBenefitsProfile.getAssociateId());
        transactionLog.setPlanGroup(associateEvent.getPlanType().getPlanGroup().isEmpty() ? planType : associateEvent.getPlanType().getPlanGroup());
        transactionLog.setPlanId(associateEvent.getPlanType().getPlanId());
        transactionLog.setComment(String.valueOf(DocumentType.ASSOCIATE_BENEFIT_PROFILE));
        if(associateEvent.getEventType().equals(EventType.ENROLLMENT_COMPLETE)) {
            transactionLog.setActivity(enrollment.getActivity());
            transactionLog.setCreatedAt(associateEvent.getTimeStamp());
            transactionLog.setCreatedBy(associateEvent.getOrigin().getValue());
        } else {
            setActivityDynamic(transactionLog,associateEvent);
            transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
            transactionLog.setCreatedAt(getUTCTimeAsString());
        }
        return transactionLog;
    }
    private static void setActivityDynamic(TransactionLog transactionLog,AssociateEvent associateEvent) {
        EventType eventType = associateEvent.getEventType();
        if (eventType.equals(EventType.ENROLLMENT_COMPLETE)) {
            transactionLog.setActivity(Activity.RATE_CHANGE);
        } else if (eventType.equals(EventType.LOAN)) {
            transactionLog.setActivity(Activity.LOAN_DEDUCTION);
        } else if (eventType.equals(EventType.HARDSHIP)) {
            transactionLog.setActivity(Activity.HARDSHIP_WITHDRAWAL);
        }
        else if (eventType.equals(EventType.MATCH_ELIGIBILITY)) {
            transactionLog.setActivity(Activity.MATCH_ELIGIBILITY);
        }
        else {
            transactionLog.setActivity(Activity.valueOf(eventType.name()));
            transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        }
    }
    /**
     * Added DocumentType to identify who is creating transaction log. This will be removed/updated once entity model updated.
     * @param associateBenefit Coverage details
     * @param associateEvent Event that triggered the flow
     * @return TransactionLog
     */
    public static TransactionLog getTransactionLogCoverage(AssociateBenefit associateBenefit, AssociateEvent associateEvent, Enrollment enrollment, DelegateExecution delegateExecution) {
        TransactionLog transactionLog = initializeTransactionLog(associateBenefit, associateEvent, delegateExecution);
        setActivityAndCreatedBy(transactionLog, associateBenefit, associateEvent, enrollment);
        return transactionLog;
    }

    private static TransactionLog initializeTransactionLog(AssociateBenefit associateBenefit, AssociateEvent associateEvent, DelegateExecution delegateExecution) {
        TransactionLog transactionLog = new TransactionLog();
        transactionLog.setPlanGroup(associateBenefit.getPlanGroup());
        transactionLog.setPlanId(associateBenefit.getPlanId());
        transactionLog.setAssociateId(associateBenefit.getAssociateId());
        transactionLog.setComment(String.valueOf(DocumentType.ASSOCIATE_BENEFIT));
        if(associateEvent.getEventType().equals(EventType.ENROLLMENT_COMPLETE)) {
            transactionLog.setCreatedAt(getFutureDateForEnrollmentEvent(delegateExecution));
        } else {
            transactionLog.setCreatedAt(getUTCTimeAsString());
        }
//        todo : Add transaction log.createdAt ,need to revisit as loan demands current date -1 day validation if there are any records with same planId
        return transactionLog;
    }

    private static void setActivityAndCreatedBy(TransactionLog transactionLog, AssociateBenefit associateBenefit, AssociateEvent associateEvent, Enrollment enrollment) {
        EventType eventType = associateEvent.getEventType();
        if (eventType.equals(EventType.ENROLLMENT_COMPLETE)) {
            if(associateEvent.getPlanType().getPlanGroup().equalsIgnoreCase(RETIREMENT)) {
                transactionLog.setActivity(Activity.RATE_CHANGE);
                transactionLog.setCreatedBy(enrollment  != null ? String.valueOf(enrollment.getOriginSystem()) : associateEvent.getOrigin().getValue());
            } else{
                transactionLog.setActivity(associateBenefit.getChangeActivity());
                transactionLog.setCreatedBy(associateBenefit.getCreatedBy() != null ? associateBenefit.getCreatedBy() : associateBenefit.getLastModifiedBy());
            }

        } else if (eventType.equals(EventType.LOAN)) {
            if(associateBenefit.getLoanStatusCode()== LoanStatusCode.A)
                transactionLog.setActivity(Activity.LOAN_DEDUCTION);
            else if(associateBenefit.getLoanStatusCode()== LoanStatusCode.I)
                transactionLog.setActivity(Activity.LOAN_INACTIVE);
            else if(associateBenefit.getLoanStatusCode()== LoanStatusCode.C)
                transactionLog.setActivity(Activity.LOAN_COMPLETE);
            transactionLog.setComment(generateLoanComments(associateBenefit));
            transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        } else if (eventType.equals(EventType.HARDSHIP)) {
            transactionLog.setActivity(Activity.HARDSHIP_WITHDRAWAL);
            transactionLog.setComment(generateHardshipComments(associateBenefit));
            transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
            transactionLog.setActivityId(HARDSHIP_ACTIVITY_ID);
        }
        else {
            transactionLog.setActivity(Activity.valueOf(eventType.name()));
            transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        }
    }

    /**
     * Generate loan comments based on planId
     * @param associateBenefit Coverage details
     * @return Loan comments as String
     */
    private static String generateLoanComments(AssociateBenefit associateBenefit) {
        return String.format( "%s ; %s", associateBenefit.getPlanId().contains(GENERAL) ? GEN_LOAN : RES_LOAN,
                SEQUENCE_NO + associateBenefit.getLoanSequenceNumber());
    }

    private static String generateHardshipComments(AssociateBenefit associateBenefit) {
        return "HARDSHIP RECORD RECEIVED FROM ML";
    }

    /**
     * Added DocumentType to identify who is creating transaction log. This will be removed/updated once entity model updated.
     * @param associateEvent Actual Event
     * @return TransactionLog
     */
    public static TransactionLog getTransactionLogEvent(AssociateEvent associateEvent) {
        TransactionLog transactionLog= new TransactionLog();
        transactionLog.setAssociateId(associateEvent.getAssociateId());
        transactionLog.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        transactionLog.setPlanId(associateEvent.getPlanType().getPlanId());
        transactionLog.setActivity(Activity.valueOf(associateEvent.getEventType().name()));
        transactionLog.setComment(String.valueOf(DocumentType.ASSOCIATE_BENEFIT_PROFILE));
        transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        transactionLog.setCreatedAt(getUTCTimeAsString());
        return transactionLog;
    }

    /**
     * Added DocumentType to identify who is creating transaction log. This will be removed/updated once entity model updated.
     * @return TransactionLog
     */
    public static TransactionLog getTransactionLogEvent(AssociateEvent associateEvent, String transactionLogComment, String planType) {
        TransactionLog transactionLog= new TransactionLog();
        transactionLog.setAssociateId(associateEvent.getAssociateId());
        transactionLog.setPlanGroup(Optional.ofNullable(associateEvent.getPlanType().getPlanGroup())
                .filter(planGroup -> !planGroup.isEmpty())
                .orElse(planType));
        transactionLog.setPlanId(associateEvent.getPlanType().getPlanId());
        transactionLog.setActivity(Activity.valueOf(associateEvent.getEventType().name()));
        transactionLog.setComment(transactionLogComment);
        transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        transactionLog.setCreatedAt(getUTCTimeAsString());
        return transactionLog;
    }

    public static TransactionLog getTransactionLogEvent(AssociateEvent associateEvent, String transactionLogComment) {
        TransactionLog transactionLog= new TransactionLog();
        transactionLog.setAssociateId(associateEvent.getAssociateId());
        transactionLog.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        transactionLog.setPlanId(associateEvent.getPlanType().getPlanId());
        transactionLog.setActivity(Activity.valueOf(associateEvent.getEventType().name()));
        transactionLog.setComment(transactionLogComment);
        transactionLog.setCreatedBy(SYSTEM_CORE_ENGINE);
        transactionLog.setCreatedAt(getUTCTimeAsString());
        return transactionLog;
    }

    /**
     * Added DocumentType to identify who is creating transaction log. This will be removed/updated once entity model updated.
     * @param associateEvent Event that triggered the flow
     * @return TransactionLog
     */
    public static TransactionLog getTransactionLogEnrollment(Enrollment createEnrollment, AssociateEvent associateEvent) {
        TransactionLog transactionLog= new TransactionLog();
        transactionLog.setAssociateId(createEnrollment.getAssociateId());
        transactionLog.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        transactionLog.setPlanId(associateEvent.getPlanType().getPlanId());
        transactionLog.setComment(String.valueOf(DocumentType.ENROLLMENT));
        transactionLog.setActivity(Activity.valueOf(associateEvent.getEventType().name()));
        transactionLog.setCreatedBy(createEnrollment.getCreatedBy());
        transactionLog.setCreatedAt(createEnrollment.getCreatedAt());
        return transactionLog;
    }
}
