package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RuleRequestProcessorFactory {
    private final List<RuleRequestProcessor> processors;
    private final List<RuleRequestProcessor> defaultProcessors;

    public RuleRequestProcessor getProcessor(String planType, EventType eventType) {
        return processors.stream()
                .filter(p -> matches(p, planType, eventType))
                .findFirst()
                .orElseGet(() -> getDefaultProcessor(eventType));
    }

    private RuleRequestProcessor getDefaultProcessor(EventType eventType) {
        return defaultProcessors.stream()
                .filter(p -> p.getPlanType() == null && p.getEventType().equals(eventType))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No default processor found for event type: " + eventType));
    }

    private boolean matches(RuleRequestProcessor processor, String planType, EventType eventType) {
        return processor.getPlanType() != null &&
               processor.getPlanType().equals(planType) &&
               processor.getEventType().equals(eventType);
    }
}