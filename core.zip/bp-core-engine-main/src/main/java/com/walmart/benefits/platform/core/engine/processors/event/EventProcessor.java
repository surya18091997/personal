package com.walmart.benefits.platform.core.engine.processors.event;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;

public interface EventProcessor {

    void process(DelegateExecution argument);

    EventType getEventType();

    String getPlanType();

}
