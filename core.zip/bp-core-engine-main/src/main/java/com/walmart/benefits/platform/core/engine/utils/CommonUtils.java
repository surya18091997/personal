package com.walmart.benefits.platform.core.engine.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.model.RetirementContributionRateEvent;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.common.constants.DATE_PATTERN;

@Slf4j
public class CommonUtils {

    private CommonUtils() {

    }

    public static String generateKey(EventType eventType) {
        return eventType.name().replace(SYMBOL_UNDER_SCORE, SYMBOL_HYPHEN).toLowerCase();
    }

    //Example.. new_hire_401k
    public static String getWorkflowName(String plan, EventType eventType) {
        if(plan == null) {
            return eventType.name().toLowerCase();
        }
        return eventType.name().toLowerCase().concat(SYMBOL_UNDER_SCORE).concat(plan.toLowerCase());
    }

    public static boolean validEventType(EventType eventType) throws EventNotFoundException {
        if (eventType.equals(EventType.NONE)) {
            throw new EventNotFoundException("Invalid event type");
        }
        return true;
    }

    public static BenefitsEntity getBenefitsEntity(ConnectorResponse connectorResponse, AssociateEvent associateEvent) {
        BenefitsEntity benefitsEntity = new BenefitsEntity();
        InterDomainInfo interDomainInfo = connectorResponse.getData().getQueryAssociateUpstreamDetails();
        interDomainInfo.getAssociateInfo().setAssociateId(associateEvent.getAssociateId());
        benefitsEntity.setInterDomainInfo(interDomainInfo);
        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(associateEvent.getAssociateId());
        intraDomainInfo.setAssociateBenefit(associateBenefit);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);
        return benefitsEntity;
    }


    public static RetirementContributionRateEvent getContributionFromEvent(AssociateEvent associateEvent) {
        ObjectMapper mapper = new ObjectMapper();
        RetirementContributionRateEvent contribution = null;
        if(associateEvent.getAdditionalInfo() != null) {
            contribution = mapper.convertValue(associateEvent.getAdditionalInfo(), RetirementContributionRateEvent.class);
        }
        return contribution;
    }

    public static AssociateBenefitsProfile getProfile(DelegateExecution delegateExecution) {
        Map<String, Object> variables = delegateExecution.getVariables();
        String isProfileAvailable = (String) variables.get(IS_PROFILE_AVAILABLE);
        return TRUE.equals(isProfileAvailable) ?
                (AssociateBenefitsProfile) variables.get(GET_ASSOCIATE_PROFILE_RESPONSE) : null;
    }


    public static Coverage getCoverage(AssociateEvent associateEvent, String isCoverageAvailable, Map<String, Object> variables) {
        AssociateBenefit coverage = null;
        List<AssociateBenefit> allAvailableCoverages = null;
        String planTypeStr = associateEvent.getPlanType().getPlanId();

        if(isCoverageAvailable.equals(TRUE)) {
            allAvailableCoverages = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
            Optional<AssociateBenefit> currentPlanCoverage = allAvailableCoverages.stream()
                    .filter(planCoverage -> planCoverage.getPlanId().equalsIgnoreCase(planTypeStr))
                    .findFirst();

            if (currentPlanCoverage.isPresent()) {
                coverage = currentPlanCoverage.get();
            }
        }
        return new Coverage(coverage, allAvailableCoverages, planTypeStr);
    }


    public static String getTodayString(){
        return LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_PATTERN));
    }

    public record Coverage(AssociateBenefit coverage, List<AssociateBenefit> allRetirementCoveragesList, String planTypeStr) {
    }


}
