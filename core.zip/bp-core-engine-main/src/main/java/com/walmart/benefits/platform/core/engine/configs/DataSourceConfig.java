package com.walmart.benefits.platform.core.engine.configs;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.CORE_ENGINE_ENTITY;

@Configuration
@EnableJpaRepositories(basePackages = "com.walmart.benefits.platform.core.engine.dao", entityManagerFactoryRef = "primaryEntityManagerFactory", transactionManagerRef = "primaryTransactionManager")
public class DataSourceConfig {

    @Primary
    @Bean(name = "primaryProperties")
    @ConfigurationProperties(prefix = "spring.datasource.core-engine")
    public DataSourceProperties dataSource() {
        return new DataSourceProperties();
    }

    @Primary
    @Bean(name = "primaryDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.core-engine.hikari")
    public DataSource primaryDataSource(@Qualifier("primaryProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }


    /**
     * Primary data source used to store core engine business related data into database
     *
     * @param builder
     * @param dataSource
     * @return
     */
    @Primary
    @Bean(name = "primaryEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(EntityManagerFactoryBuilder builder, @Qualifier("primaryDataSource") DataSource dataSource) {
        Map<String, Object> jpaProperties = new HashMap<>();
        jpaProperties.put("hibernate.hbm2ddl.auto", "update");
        return builder.dataSource(dataSource).packages(CORE_ENGINE_ENTITY).persistenceUnit("primary").properties(jpaProperties).build();
    }

    /**
     * Primary transaction manager
     *
     * @param entityManagerFactory
     * @return
     */

    @Primary
    @Bean(name = "primaryTransactionManager")
    public PlatformTransactionManager transactionManager(@Qualifier("primaryEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    /**
     * camunda database configuration
     *
     * @return
     */
    @Bean(name = "camundaProperties")
    @ConfigurationProperties(prefix = "spring.datasource.camunda")
    public DataSourceProperties camundaProperties() {
        return new DataSourceProperties();
    }

    /**
     * Secondary data  source used to store camunda related tables
     *
     * @param properties
     * @return
     */
    @Bean(name = "camundaBpmDataSource")
    public DataSource camundaDataSource(@Qualifier("camundaProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().build();
    }

    /**
     * Camunda transaction manager
     *
     * @param dataSource
     * @return
     */

    @Bean(name = "camundaBpmTransactionManager")
    public PlatformTransactionManager camundaTransactionManager(@Qualifier("camundaBpmDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
