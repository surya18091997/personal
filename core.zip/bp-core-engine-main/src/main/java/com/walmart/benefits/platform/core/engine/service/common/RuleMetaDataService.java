package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RulesExecutor;
import com.walmart.benefits.rules.benefitsrulessdk.models.RulesInputMetadata;
import com.walmart.benefits.rules.benefitsrulessdk.models.RulesMetadataInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.generateKey;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@AllArgsConstructor
@Service("RuleMetaDataService")
public class RuleMetaDataService implements JavaDelegate {

    private final RuleMetaDataConfig ruleMetaDataConfig;

    private final RulesExecutor rulesExecutor;

    private final EncryptionUtil encryptionUtil;

    /**
     * Gets the metadata information from rule engine
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            log.info("Workflow Process Instance Id - {}", delegateExecution.getActivityInstanceId());
            Map<String, Object> variables = delegateExecution.getVariables();
            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            String planType = (String) variables.get(PLAN_TYPE);

            Map<String, List<RuleCategory>> ruleCategories =
                    ruleMetaDataConfig.getEventType().get(generateKey(associateEvent.getEventType()));

            if (!associateEvent.getPlanType().equals(PlanType.NONE)) {
                ruleCategories = ruleCategories.entrySet().stream().filter(entry ->
                                entry.getKey().equals(associateEvent.getPlanType().toString()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, HashMap::new));
            }

            List<RulesMetadataInput> rulesMetadataInputs = new ArrayList<>();
            ruleCategories.forEach((subPlanType, ruleCategoryList) -> {
                if (StringUtils.containsIgnoreCase(subPlanType, planType)) {
                    PlanType plnType = PlanType.valueOf(subPlanType);
                    rulesMetadataInputs.add(RulesMetadataInput.builder()
                            .ruleCategoryList(ruleCategoryList)
                            .event(associateEvent.getEventType())
                            .planType(plnType)
                            .build());
                }
            });

            RulesInputMetadata rulesInputMetadata = rulesExecutor.getRuleMetadata(rulesMetadataInputs);

            delegateExecution.setVariable(RULE_META_DATA, rulesInputMetadata);

            log.info("GraphQL Query Generated - {} , Associate Id - {}", rulesInputMetadata.getUpstreamGraphQlQuery(),
                    encryptionUtil.encrypt(associateEvent.getAssociateId()));
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, RULE_META_DATA_SERVICE, exception.getMessage());
        }
    }


}
