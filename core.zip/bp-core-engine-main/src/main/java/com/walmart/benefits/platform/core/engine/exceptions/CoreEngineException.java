package com.walmart.benefits.platform.core.engine.exceptions;

public class CoreEngineException extends Exception{
    public CoreEngineException(String message, Exception e) {
        super(message,e);
    }
}
