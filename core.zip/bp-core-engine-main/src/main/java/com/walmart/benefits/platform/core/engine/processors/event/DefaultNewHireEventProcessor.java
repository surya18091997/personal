package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.EventUtils.associateCoverage;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class DefaultNewHireEventProcessor extends AbstractEventProcessor {

    public DefaultNewHireEventProcessor() {
        super(NEW_HIRE);
    }

    @Override
    public String getPlanType() {
        return null;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultNewHireEventProcessor: Default processing for NEW_HIRE event");
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.associateProfile(benefitsEntity));
        List<AssociateBenefit> coverages = associateCoverage(benefitsEntity);
        if(!Objects.isNull(coverages) && !coverages.isEmpty()) variables.put(ASSOCIATE_COVERAGE, coverages);
        delegateExecution.setVariables(variables);
        log.info("DefaultNewHireEventProcessor: ended");
    }
}