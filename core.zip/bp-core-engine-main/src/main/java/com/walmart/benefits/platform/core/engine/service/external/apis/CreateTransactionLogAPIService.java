package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogEvent;

@Slf4j
@Service("CreateTransactionLogAPIService")
public class CreateTransactionLogAPIService implements JavaDelegate {


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public CreateTransactionLogAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Push Data to benefits Profile API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        String planType = (String) delegateExecution.getVariable(PLAN_TYPE);
        log.info("Create transaction log api started... Associate id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            String transactionLogComment = (String) variables.get(TRANSACTION_LOG_COMMENT);
            TransactionLog transactionLog = (transactionLogComment == null) ? getTransactionLogEvent(associateEvent) : getTransactionLogEvent(associateEvent, transactionLogComment, planType);
            ResponseEntity<String> transactionLogResponse = restTemplate.exchange(httpUtils.getTransactionLogUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(transactionLog, httpUtils.getTransactionLogServiceAppName()), String.class);
            log.info("Create transaction log api status code : {}, Associate Id {}", transactionLogResponse.getStatusCode(),encryptionUtil.encrypt(associateEvent.getAssociateId()));
        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount,ASSOCIATE_TRANSACTION_LOG_SERVICE_CREATE_SERVER_ERROR);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_TRANSACTION_LOG_SERVICE_CREATE, exception.getMessage());
        }

    }

}
