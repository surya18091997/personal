package com.walmart.benefits.platform.core.engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class BenefitsCoreEngineApplication {
    public static void main(String... args) {
        SpringApplication.run(BenefitsCoreEngineApplication.class, args);
    }
}
