package com.walmart.benefits.platform.core.engine.exceptions;

public class EventTypeConfigurationException extends RuntimeException {
    public EventTypeConfigurationException(String message) {
        super(message);
    }
}