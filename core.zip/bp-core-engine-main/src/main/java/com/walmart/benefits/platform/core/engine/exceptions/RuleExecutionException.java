package com.walmart.benefits.platform.core.engine.exceptions;

public class RuleExecutionException extends RuntimeException {
    public RuleExecutionException(String message, Exception e) {
        super(message,e);
    }
}