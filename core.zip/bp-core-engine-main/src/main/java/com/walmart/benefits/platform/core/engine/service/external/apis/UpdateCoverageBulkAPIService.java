package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogCoverage;

@Slf4j
@Service("UpdateCoverageBulkAPIService")
public class UpdateCoverageBulkAPIService implements JavaDelegate {

    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    public UpdateCoverageBulkAPIService(RestTemplate restTemplate, HttpUtils httpUtils) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
    }

    /**
     * Push Data to associate benefits API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        log.info("UpdateCoverageAPIService Started");
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var enrollment = (Enrollment) variables.get(ENROLLMENT);
            List<AssociateBenefit> updateCoverages = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
            if (updateCoverages != null && !updateCoverages.isEmpty()) {
                var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
                HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
                restTemplate.setRequestFactory(requestFactory);
                ResponseEntity<String> coverageResponse = restTemplate.exchange(httpUtils.getCoverageUpsertBulkUrl(), HttpMethod.PATCH,
                        httpUtils.getHttpEntity(updateCoverages, httpUtils.getAssociateBenefitServiceAppName()), String.class);
                log.info("UpdateCoverageAPIService Response : {}", coverageResponse.getStatusCode());
                updateTransactionLog(associateEvent, updateCoverages, enrollment, delegateExecution);
            }
        } catch (HttpServerErrorException exception) {
            log.info("UpdateCoverageAPIService - retry count{}", retryCount);
            httpUtils.handleError(delegateExecution, exception, retryCount,ASSOCIATE_COVERAGE_SERVICE_UPDATE_SERVER_ERROR);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_COVERAGE_SERVICE_UPDATE, exception.getMessage());
        }
    }

    private void updateTransactionLog(AssociateEvent associateEvent, List<AssociateBenefit> updateCoverages, Enrollment enrollment, DelegateExecution delegateExecution) {
        List<TransactionLog> transactionLogs = updateCoverages.stream().map(benefit -> getTransactionLogCoverage(benefit, associateEvent, enrollment, delegateExecution)).toList();
        String url = String.format("%s?associateId=%s", httpUtils.getTransactionLogBulkUrl(), associateEvent.getAssociateId());
        ResponseEntity<String> transactionLogResponse = restTemplate.exchange(url, HttpMethod.POST,
                httpUtils.getHttpEntity(transactionLogs, httpUtils.getTransactionLogServiceAppName()), String.class);
        log.info("TransactionLogAPIService Response : {}", transactionLogResponse.getStatusCode());
    }

}
