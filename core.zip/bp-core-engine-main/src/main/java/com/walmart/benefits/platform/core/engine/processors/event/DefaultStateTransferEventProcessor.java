package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;

@Slf4j
@Service
public class DefaultStateTransferEventProcessor extends AbstractEventProcessor {

    public DefaultStateTransferEventProcessor() {
        super(STATE_TRANSFER);
    }

    @Override
    public String getPlanType() {
        return null;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultStateTransferEventProcessor: Default processing for STATE_TRANSFER event");
        // Specific default processing logic for STATE_TRANSFER event
    }
}