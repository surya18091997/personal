package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;

@Slf4j
public abstract class AbstractEventProcessor implements EventProcessor {
    private final EventType eventType;

    protected AbstractEventProcessor(EventType eventType) {
        this.eventType = eventType;
    }

    @Override
    public EventType getEventType() {
        return eventType;
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Processing event for plan: {}, event: {}", getPlanType(), getEventType());
        // Default implementation
        // Can be overridden by specific processors if needed
    }

    @Override
    public abstract String getPlanType();

    protected void setExceptionData(DelegateExecution execution, String errorType, String message) {
        log.error("Error processing event: {}", message);
        execution.setVariable("errorType", errorType);
        execution.setVariable("errorMessage", message);
        throw new BpmnError(errorType, message);
    }
}