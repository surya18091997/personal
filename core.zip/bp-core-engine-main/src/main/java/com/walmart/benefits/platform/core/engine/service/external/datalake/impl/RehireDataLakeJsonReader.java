package com.walmart.benefits.platform.core.engine.service.external.datalake.impl;

import com.walmart.benefits.platform.core.engine.service.external.datalake.AbstractDataLakeJsonReader;
import com.walmart.benefits.platform.core.engine.utils.DataLakeJsonUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class RehireDataLakeJsonReader extends AbstractDataLakeJsonReader {

    private final DataLakeJsonUtil dataLakeJsonUtil;

    public RehireDataLakeJsonReader(DataLakeJsonUtil dataLakeJsonUtil) {
        super(RE_HIRE);
        this.dataLakeJsonUtil = dataLakeJsonUtil;
    }

    @Override
    public String readDataLakeJsonFiles() throws IOException {
        Map<String, List<Object>> jsonData = new HashMap<>();

        try {
            log.info("Reading profile data from Data Lake JSON: {}", PROFILE_HUDI_JSON);
            List<Object> profileDataLakeData = dataLakeJsonUtil.readDataLakeJsonFromGcs(
                    getUnloadedDataLakePath() +  "/" + getEventType() +"/" +
                            PROFILE_HUDI_JSON, AssociateBenefitsProfile.class, RAW_DOCUMENT_HUDI_COLUMN);
            jsonData.put(PROFILE_HUDI_JSON, profileDataLakeData);
            log.info("Successfully read profile data from Data Lake JSON: {}", PROFILE_HUDI_JSON);
        } catch (IOException e) {
            log.error("Failed to read profile data from Data Lake JSON: {}", PROFILE_HUDI_JSON, e);
            throw new IOException("Error reading profile data from Data Lake JSON", e);
        }

        try {
            log.info("Reading post payroll snapshot data from Data Lake JSON: {}", POST_PAYROLL_SNAPSHOT_HUDI_JSON);
            List<Object> postPayrollSnapshotDataLakeData = dataLakeJsonUtil.readDataLakeJsonFromGcs(
                    getUnloadedDataLakePath() + "/" + getEventType() +"/" +
                            POST_PAYROLL_SNAPSHOT_HUDI_JSON, PostPayrollSnapshot.class, RAW_DOCUMENT_HUDI_COLUMN);
            jsonData.put(POST_PAYROLL_SNAPSHOT_HUDI_JSON, postPayrollSnapshotDataLakeData);
            log.info("Successfully read post payroll snapshot data from Data Lake JSON: {}", POST_PAYROLL_SNAPSHOT_HUDI_JSON);
        } catch (IOException e) {
            log.error("Failed to read post payroll snapshot data from Data Lake JSON: {}", POST_PAYROLL_SNAPSHOT_HUDI_JSON, e);
            throw new IOException("Error reading post payroll snapshot data from Data Lake JSON", e);
        }
        return dataLakeJsonUtil.storeDataInCache(jsonData);
    }
}