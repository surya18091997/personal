package com.walmart.benefits.platform.core.engine.processors.rulerequest.disability;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.AbstractRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.DefaultNewHireRuleRequestProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class DisabilityNewHireRuleRequestProcessor extends DefaultNewHireRuleRequestProcessor {

    public DisabilityNewHireRuleRequestProcessor() {
        super();
    }
    @Override
    public void process(DelegateExecution delegateExecution) {
        //Custom Logic goes here
        log.info("Disability New Hire Rule Request Processor");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEligibilityInput associateEligibilityInput = (AssociateEligibilityInput) variables.get(ASSOCIATE_ELIGIBILITY_INPUT);
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        String changeActivity = associateEvent.getEventType().name().toUpperCase();
        associateEligibilityInput.setChangeActivity(changeActivity);
        delegateExecution.setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() { return DISABILITY; }
}
