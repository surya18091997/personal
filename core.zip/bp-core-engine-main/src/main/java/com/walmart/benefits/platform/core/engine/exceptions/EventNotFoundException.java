package com.walmart.benefits.platform.core.engine.exceptions;

public class EventNotFoundException extends RuntimeException {
    public EventNotFoundException(String eventNotAvailableInDatabase) {
        super(eventNotAvailableInDatabase);
    }
}
