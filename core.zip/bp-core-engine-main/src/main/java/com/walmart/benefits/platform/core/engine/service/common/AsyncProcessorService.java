package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.constants.WorkflowConstants;
import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_EVENT;


@Slf4j
@Service
@AllArgsConstructor
public class AsyncProcessorService {

    private final RuntimeService runtimeService;

    private final EncryptionUtil encryptionUtil;

    @Async("taskExecutor")
    public void processAsync(List<AssociateEvent> associateEvents) throws EventNotFoundException {
        associateEvents.forEach(event -> {
            if (CommonUtils.validEventType(event.getEventType())) {
                log.info("Async processing started..");
                log.info("Event Received from upstream system - {}, Associate Id - {}", event.getEventType(), encryptionUtil.encrypt(String.valueOf(event.getAssociateId())));
                var variables = new HashMap<String, Object>();
                variables.put(ASSOCIATE_EVENT, event);
                runtimeService.startProcessInstanceByKey(WorkflowConstants.WORKFLOW_SELECTOR, variables);
            }
        });
    }
}
