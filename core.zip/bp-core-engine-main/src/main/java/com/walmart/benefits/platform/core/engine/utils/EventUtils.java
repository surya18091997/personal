package com.walmart.benefits.platform.core.engine.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.exceptions.InvalidStateProvisionCodeException;
import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.model.LoanModel;
import com.walmart.benefits.platform.core.engine.model.RetirementContributionRateEvent;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.*;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.EnrollmentStatus;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.OriginSystem;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.*;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.convertDateToUTCSystemZone;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.getUTCTimeAsString;

@Slf4j
public class EventUtils {

    private EventUtils() {
    }

    public static AssociateBenefitsProfile associateProfile(BenefitsEntity benefitsEntity) {
        Eligibility emptyEligibility = new Eligibility();
        emptyEligibility.setPlans(new ArrayList<>());
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
        associateBenefitsProfile.setCreatedAt(getUTCTimeAsString());
        associateBenefitsProfile.setLastModifiedAt(getUTCTimeAsString());
        associateBenefitsProfile.setEligibility(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile() != null ? benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility() : emptyEligibility);
        associateBenefitsProfile.setCreatedBy(SYSTEM_CORE_ENGINE);
        associateBenefitsProfile.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        return associateBenefitsProfile;
    }

    public static AssociateBenefitsProfile updateAssociateProfile(BenefitsEntity benefitsEntity) {
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
        associateBenefitsProfile.setLastModifiedAt(getUTCTimeAsString());
        associateBenefitsProfile.setEligibility(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility());
        associateBenefitsProfile.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        associateBenefitsProfile.setCreatedBy(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getCreatedBy());
        associateBenefitsProfile.setCreatedAt(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getCreatedAt());
        return associateBenefitsProfile;
    }

    public static void updateAssociateProfile(AssociateBenefitsProfile existing_profile,AssociateEvent associateEvent, HardshipModel hardshipModel) {
        // Create AssociateBenefitsProfile to update
        String startDate = hardshipModel.getStartDate();
        String resumeDate = hardshipModel.getResumeDate();
        String countryCode = associateEvent.getPlanType().getCountryCode();
        String endDate = determineEndDate(startDate, resumeDate, countryCode);
        boolean hardshipPlanExists=false;
        if(existing_profile.getEligibility().getPlans() != null) {
            // Check if hardship plan already exists
             hardshipPlanExists = existing_profile.getEligibility().getPlans().stream()
                    .anyMatch(plan -> plan.getPlanId().equals(associateEvent.getPlanType().getPlanId()));}

            // Only add if it doesn't exist
            if (!hardshipPlanExists) {
                PlanEligibility hardshipEligibility = new PlanEligibility();
                hardshipEligibility.setPlanId(associateEvent.getPlanType().getPlanId());
                hardshipEligibility.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
                Boolean isEligible= true;
                hardshipEligibility.setIsEligible(isEligible);
                hardshipEligibility.setEligibleDate(startDate);
                // Here will be setting the date which is going to added to the profile.
                if (existing_profile.getEligibility().getPlans() != null) {
                    existing_profile.getEligibility().getPlans().add(hardshipEligibility);
                } else {
                    existing_profile.getEligibility().setPlans(new ArrayList<>(List.of(hardshipEligibility)));
                }
            }else{
                // Update the existing plan eligibility
                existing_profile.getEligibility().getPlans().stream()
                        .filter(plan -> plan.getPlanId().equals(associateEvent.getPlanType().getPlanId()))
                        .findFirst()
                        .ifPresent(plan -> {
                            plan.setIsEligible(true);
                            plan.setEligibleDate(startDate);
                        });
            }

        existing_profile.setLastModifiedAt(getUTCTimeAsString());
    }

    public static AssociateBenefitsProfile compareAssociateProfile(BenefitsEntity benefitsEntity, AssociateBenefitsProfile getAssociateBenefitsProfile) {
        AssociateBenefitsProfile associateBenefitsBaseProfile = createBaseProfile(benefitsEntity);

        if (getAssociateBenefitsProfile != null) {
            mergeEligibility(getAssociateBenefitsProfile, associateBenefitsBaseProfile);
            getAssociateBenefitsProfile.setCreatedBy(SYSTEM_CORE_ENGINE);
            return getAssociateBenefitsProfile;
        }

        associateBenefitsBaseProfile.setCreatedBy(SYSTEM_CORE_ENGINE);
        return associateBenefitsBaseProfile;
    }

    private static AssociateBenefitsProfile createBaseProfile(BenefitsEntity benefitsEntity) {
        AssociateBenefitsProfile profile = new AssociateBenefitsProfile();
        profile.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
        profile.setCreatedAt(getUTCTimeAsString());
        profile.setEligibility(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility());
        return profile;
    }

    private static void mergeEligibility(AssociateBenefitsProfile target, AssociateBenefitsProfile source) {
        if (target.getEligibility() != null && source.getEligibility() != null) {
            List<PlanEligibility> targetPlans = target.getEligibility().getPlans();
            List<PlanEligibility> sourcePlans = source.getEligibility().getPlans();

            for (PlanEligibility sourcePlan : sourcePlans) {
                boolean planExists = targetPlans.stream()
                        .anyMatch(plan -> plan.getPlanId().equals(sourcePlan.getPlanId()));

                if (planExists) {
                    targetPlans.stream()
                            .filter(plan -> plan.getPlanId().equals(sourcePlan.getPlanId()))
                            .findFirst()
                            .ifPresent(plan -> {
                                plan.setIsEligible(sourcePlan.getIsEligible());
                                plan.setEligibleDate(sourcePlan.getEligibleDate());
                            });
                } else {
                    targetPlans.add(sourcePlan);
                }
            }
        }
    }


    public static List<AssociateBenefit> associateCoverage(BenefitsEntity benefitsEntity) {
        Optional<AssociateBenefitsProfile> associateBenefitsProfile = Optional.ofNullable(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile());
        List<PlanEligibility> plans = associateBenefitsProfile.isPresent() ? associateBenefitsProfile.get().getEligibility().getPlans() : new ArrayList<>();
        List<AssociateBenefit> associateBenefits = new ArrayList<>();
        plans.forEach(plan -> {
            AssociateBenefit associateBenefit = new AssociateBenefit();
            associateBenefit.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
            associateBenefit.setPlanId(plan.getPlanId());
            associateBenefit.setPlanGroup(plan.getPlanGroup());
            associateBenefit.setCreatedAt(getUTCTimeAsString());
            associateBenefit.setCreatedBy(SYSTEM_CORE_ENGINE);
            associateBenefits.add(associateBenefit);

        });
        return associateBenefits;
    }


    public static AssociateBenefitsProfile updateProfile(AssociateEvent associateEvent, BenefitsEntity benefitsEntity) {
        AssociateBenefitsProfile updateProfile = new AssociateBenefitsProfile();
        PlanEligibility planList = new PlanEligibility();
        Eligibility eligibility = new Eligibility();
        benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans().forEach(planEligibility ->
        {
            planList.setIsEligible(planEligibility.getIsEligible());
            planList.setEligibleDate(planEligibility.getEligibleDate());
            planList.setIsCompanyMatchEligible(planEligibility.getIsCompanyMatchEligible());
            planList.setCompanyMatchEligibleDate(planEligibility.getCompanyMatchEligibleDate());
            planList.setPlanGroup(planEligibility.getPlanGroup());
            if(associateEvent.getEventType().equals(EventType.STATE_TRANSFER))
                planList.setOriginalHireDate(planEligibility.getOriginalHireDate());
            planList.setPlanId(planEligibility.getPlanId());
        });
        eligibility.setPlans(List.of(planList));
        updateProfile.setEligibility(eligibility);
        updateProfile.setAssociateId(associateEvent.getAssociateId());
        updateProfile.setLastModifiedAt(getUTCTimeAsString());
        updateProfile.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        return updateProfile;
    }

    public static AssociateBenefitsProfile updateConsentProfile(Enrollment enrollment) {
        AssociateBenefitsProfile consentProfile = new AssociateBenefitsProfile();
        consentProfile.setConsent(enrollment.getConsent());
        consentProfile.setAssociateId(enrollment.getAssociateId());
        if(enrollment.getPlanElections() == null || enrollment.getPlanElections().isEmpty()) {
            consentProfile.setCreatedAt(getUTCTimeAsString());
            consentProfile.setCreatedBy(SYSTEM_CORE_ENGINE);
        } else {
            consentProfile.setLastModifiedAt(getUTCTimeAsString());
            consentProfile.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        }

        return consentProfile;
    }

    public static List<AssociateBenefit> createCoverage(AssociateEvent associateEvent, Activity activity) {
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(associateEvent.getAssociateId());
        associateBenefit.setPlanId(associateEvent.getPlanType().getPlanId());
        associateBenefit.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        associateBenefit.setStartDate(associateEvent.getTimeStamp());
        associateBenefit.setCreatedAt(associateEvent.getTimeStamp());
        associateBenefit.setCreatedBy(associateEvent.getOrigin().getValue());
        setAdditionalInformation(associateEvent, associateBenefit);
        associateBenefit.setChangeActivity(activity);
        associateBenefit.setRecordType(RecordType.CURRENT);
        return List.of(associateBenefit);
    }

    private static void setAdditionalInformation(AssociateEvent associateEvent, AssociateBenefit associateBenefit) {
        if (associateEvent.getAdditionalInfo() != null) {
            Map<String, Object> additionalInfoMap = getAdditionalInfoMap(associateEvent);
            associateBenefit.setContribution(getContribution(additionalInfoMap));
            associateBenefit.setTier(getTier(additionalInfoMap));
            Optional<Object> coverageOption =  Optional.ofNullable(additionalInfoMap.getOrDefault("coverageOption", null));
            coverageOption.ifPresent(option->
                    associateBenefit.setCoverageOption(CoverageOption.valueOf(option.toString())));
        }
    }

    public static AssociateBenefit createCoverage(AssociateEvent associateEvent, LoanModel loanModel) {
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(associateEvent.getAssociateId());
        associateBenefit.setPlanId(associateEvent.getPlanType().getPlanId());
        associateBenefit.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        associateBenefit.setStartDate(associateEvent.getTimeStamp());
        associateBenefit.setCreatedAt(associateEvent.getTimeStamp());
        associateBenefit.setCreatedBy(associateEvent.getOrigin().getValue());
        associateBenefit.setLoanId(loanModel.getLoanNumber());
        associateBenefit.setLoanSequenceNumber(loanModel.getLoanNumber());
        associateBenefit.setLoanStatusCode(LoanStatusCode.A);
        PlanDeduction planDeduction = new PlanDeduction();
        planDeduction.setValue(loanModel.getDeductionAmount());
        associateBenefit.setDeduction(planDeduction);
        return associateBenefit;
    }
    public static AssociateBenefit createCoverage(AssociateEvent associateEvent, HardshipModel hardshipModel) {
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(associateEvent.getAssociateId());
        associateBenefit.setLastModifiedAt(getUTCTimeAsString());
        associateBenefit.setPlanId(associateEvent.getPlanType().getPlanId());
        associateBenefit.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        associateBenefit.setCreatedAt(associateEvent.getTimeStamp());
        associateBenefit.setCreatedBy(associateEvent.getOrigin().getValue());
        associateBenefit.setStartDate(hardshipModel.getStartDate());
        associateBenefit.setContribution(null);
        associateBenefit.setEndDate(determineEndDate(hardshipModel.getStartDate(), hardshipModel.getResumeDate(),associateEvent.getPlanType().getCountryCode()));
        return associateBenefit;
    }

    public static List<AssociateBenefit> updateCoverageList(List<AssociateBenefit> coverages, HardshipModel hardshipModel) {
        for (AssociateBenefit coverage : coverages) {
            if (coverage.getPlanId().equals(PlanType.RETIREMENT_401K_HARDSHIP_PR.getPlanId()) ||
                    coverage.getPlanId().equals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId())
                || !coverage.getPlanGroup().equals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup()))
                continue;

            coverage.setEndDate(hardshipModel.getStartDate());
            Contribution zeroContribution = new Contribution();
            zeroContribution.setValue(0.0);
            coverage.setContribution(zeroContribution);
            coverage.setLastModifiedAt(getUTCTimeAsString());
            coverage.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        }

        return coverages;
    }


    public static AssociateBenefit updateCoverage(AssociateEvent associateEvent, AssociateBenefit coverage) {
        if (coverage != null) {
            if (isRateChanged(coverage, associateEvent)) {
                coverage.setStartDate(ConverterUtil.convertTimestampDate(associateEvent.getTimeStamp()));
            }
            if (associateEvent.getAdditionalInfo() != null) {
                Map<String, Object> additionalInfoMap = getAdditionalInfoMap(associateEvent);
                coverage.setContribution(getContribution(additionalInfoMap));
            }
            return updateCommonFieldsCoverage(associateEvent, coverage);
        }
        return null;
    }

    public static AssociateBenefit updateCommonFieldsCoverage(AssociateEvent associateEvent, AssociateBenefit coverage) {
        coverage.setLastModifiedAt(getUTCTimeAsString());
        coverage.setLastModifiedBy(associateEvent.getOrigin().getValue());
        return coverage;
    }

    public static AssociateBenefit updateCoverageFromRules(BenefitsEntity benefitsEntity, String isCoverageAvailable) {
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId());
        Optional.of(benefitsEntity)
                .map(BenefitsEntity::getIntraDomainInfo)
                .map(IntraDomainInfo::getAssociateBenefit)
                .ifPresent(associateBenefitData -> {
                    Optional.ofNullable(associateBenefitData.getPlanId())
                            .ifPresent(associateBenefit::setPlanId);
                    Optional.ofNullable(associateBenefitData.getPlanGroup())
                            .ifPresent(associateBenefit::setPlanGroup);
                    Optional.ofNullable(associateBenefitData.getStartDate())
                            .ifPresent(associateBenefit::setStartDate);
                    Optional.ofNullable(associateBenefitData.getEndDate())
                            .ifPresent(associateBenefit::setEndDate);
                    Optional.ofNullable(associateBenefitData.getContribution())
                            .map(Contribution::getValue)
                            .ifPresent(value -> associateBenefit.setContribution(associateBenefitData.getContribution()));
                });
        associateBenefit.setLastModifiedAt(getUTCTimeAsString());
        associateBenefit.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        if (!isCoverageAvailable.equals(TRUE)) {
            associateBenefit.setCreatedAt(getUTCTimeAsString());
            associateBenefit.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        }
        return associateBenefit;
    }

    public static Enrollment createEnrollmentFromPlanElections(AssociateEvent associateEvent,
                                                               List<PlanElection> planElections) {
        Enrollment enrollment = new Enrollment();
        //Associate Details
        enrollment.setAssociateId(associateEvent.getAssociateId());
        enrollment.setEnrollmentId(UUID.randomUUID().toString());

        //System Details
        enrollment.setLastModifiedAt(CommonUtils.getTodayString());
        enrollment.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        enrollment.setCreatedBy(SYSTEM_CORE_ENGINE);
        enrollment.setCreatedAt(associateEvent.getTimeStamp());
        enrollment.setOriginSystem(OriginSystem.OTHER);

        //User Behaviour would be Null as this is an Auto Enrollment

        //Enrollment Details
        enrollment.setPlanElections(planElections);
        enrollment.setActivity(Activity.NEW_HIRE);
        enrollment.setDeviceIndicator(Device.OTHER);
        enrollment.setExternalIndicator(false);
        enrollment.setEventDate(CommonUtils.getTodayString());
        enrollment.setStatus(EnrollmentStatus.COMPLETED);


        return enrollment;
    }

    public static Enrollment createEnrollment(AssociateEvent associateEvent) {
        Enrollment createEnrollment = new Enrollment();
        createEnrollment.setAssociateId(associateEvent.getAssociateId());
        createEnrollment.setPlanElections(setPlanCoverage(associateEvent));
        createEnrollment.setStatus(EnrollmentStatus.COMPLETED);
        createEnrollment.setActivity(Activity.valueOf(associateEvent.getEventType().getValue().toUpperCase()));
        createEnrollment.setCreatedAt(associateEvent.getTimeStamp());
        createEnrollment.setCreatedBy(associateEvent.getOrigin().getValue());
        createEnrollment.setOriginSystem(OriginSystem.valueOf(associateEvent.getOrigin().getValue()));
        return createEnrollment;
    }

    private static List<PlanElection> setPlanCoverage(AssociateEvent associateEvent) {
        List<PlanElection> planElectionList = new ArrayList<>();
        PlanElection planElection = new PlanElection();
        planElection.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        planElection.setPlanId(associateEvent.getPlanType().getPlanId());
        planElection.setContribution(parseContribution(associateEvent));
        planElectionList.add(planElection);
        return planElectionList;
    }


    public static Contribution parseContribution(AssociateEvent associateEvent) {
        Contribution contribution = new Contribution();
        RetirementContributionRateEvent fromEvent = CommonUtils.getContributionFromEvent(associateEvent);
        contribution.setType(ContributionType.PERCENT);
        contribution.setValue(fromEvent.getRateChanged());
        log.info("Contribution - {} ", fromEvent.getRateChanged());
        return contribution;
    }

    public static Contribution getContribution(Map<String, Object> additionalInfoMap) {
        return new ObjectMapper().convertValue(additionalInfoMap.get("contribution"), Contribution.class);
    }

    public static Tier getTier(Map<String, Object> additionalInfoMap) {
        return new ObjectMapper().convertValue(additionalInfoMap.get("tier"), Tier.class);
    }

    public static boolean isRateChanged(AssociateBenefit coverage, AssociateEvent associateEvent) {
        boolean isRateChanged = false;
        Map<String, Object> additionalInfoMap = getAdditionalInfoMap(associateEvent);
        Contribution fromEvent = getContribution(additionalInfoMap);
        if (coverage != null && fromEvent != null) {
            if (coverage.getContribution() != null) {
                int result = Double.compare(coverage.getContribution().getValue(), fromEvent.getValue());
                if (result != 0) {
                    isRateChanged = true;
                }
            } else if (coverage.getContribution() == null) {
                isRateChanged = true;
            }
        }

        return isRateChanged;
    }

    public static Map<String, Object> getAdditionalInfoMap(AssociateEvent associateEvent) {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.convertValue(associateEvent.getAdditionalInfo(), HashMap.class);
    }

    public static String getStoreStateProvCd(String storeStateProvCd) {
        if (storeStateProvCd == null) {
            throw new InvalidStateProvisionCodeException("Store State/Prov Code is null");
        } else {
            if (!storeStateProvCd.equalsIgnoreCase(COUNTRY_CODE_PR))
                storeStateProvCd = COUNTRY_CODE_US;
        }
        return storeStateProvCd;
    }

    public static void setPlanEligibility(AssociateEligibilityOutput associateEligibilityOutput, PlanType planType, BenefitsEntity benefitsEntity) {
        PlanEligibility planEligibility = getPlanEligibility(associateEligibilityOutput, planType);

        if (benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile() == null) {
            var planEligibilityList = new ArrayList<PlanEligibility>();
            planEligibilityList.add(planEligibility);
            AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
            associateBenefitsProfile.setEligibility(new Eligibility());
            associateBenefitsProfile.setCreatedAt(getUTCTimeAsString());
            associateBenefitsProfile.setLastModifiedAt(getUTCTimeAsString());
            associateBenefitsProfile.setCreatedBy(SYSTEM_CORE_ENGINE);
            associateBenefitsProfile.setLastModifiedBy(SYSTEM_CORE_ENGINE);
            benefitsEntity.getIntraDomainInfo().setAssociateBenefitsProfile(associateBenefitsProfile);
            benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().setPlans(planEligibilityList);
        } else {
            // Check if a plan eligibility with the same plan ID already exists
            List<PlanEligibility> plans = Optional.ofNullable(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile())
                    .map(AssociateBenefitsProfile::getEligibility)
                    .map(Eligibility::getPlans)
                    .orElseGet(ArrayList::new);

            if (benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility() == null) {
                Eligibility eligibility = new Eligibility();
                eligibility.setPlans(plans);
                benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().setEligibility(eligibility);
            }

            // Find existing plan eligibility with the same plan ID
            Optional<PlanEligibility> existingPlan = plans.stream()
                    .filter(plan -> plan.getPlanId().equals(planType.getPlanId()))
                    .findFirst();

            if (existingPlan.isPresent()) {
                // Update the existing plan eligibility
                PlanEligibility existing = existingPlan.get();
                existing.setIsEligible(associateEligibilityOutput.getAssociateEligibilityIndicator());
                existing.setEligibleDate(associateEligibilityOutput.getAssociateEligibilityDate());
                existing.setOriginalHireDate(associateEligibilityOutput.getCommencementDate());
            } else {
                plans.add(planEligibility);
            }
        }
    }

    public static void setCompanyMatchEligibility(CompanyMatchEligibilityOutput companyMatchEligibilityOutput, PlanType planType, BenefitsEntity benefitsEntity) {
        // Check if a plan eligibility with the same plan ID already exists
        List<PlanEligibility> plans = benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans();
        // Find existing plan eligibility with the same plan ID
        Optional<PlanEligibility> existingPlan = plans.stream()
                .filter(plan -> plan.getPlanId().equals(planType.getPlanId()))
                .findFirst();
        if (existingPlan.isPresent()) {
            // Update the existing plan eligibility
            PlanEligibility existing = existingPlan.get();
            existing.setCompanyMatchEligibleDate(companyMatchEligibilityOutput.getCompanyMatchEligibilityDate());
            existing.setIsCompanyMatchEligible(companyMatchEligibilityOutput.getCompanyMatchEligibilityIndicator());
        }
    }

    public static void setOriginalHireDate(RehireIndicatorOutput rehireIndicatorOutput, PlanType planType, BenefitsEntity benefitsEntity) {
        // Check if a plan eligibility with the same plan ID already exists
        List<PlanEligibility> plans = benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans();
        // Find existing plan eligibility with the same plan ID
        Optional<PlanEligibility> existingPlan = plans.stream()
                .filter(plan -> plan.getPlanId().equals(planType.getPlanId()))
                .findFirst();
        if (existingPlan.isPresent()) {
            // Update the existing plan eligibility
            PlanEligibility existing = existingPlan.get();
            existing.setOriginalHireDate(rehireIndicatorOutput.getOriginalHireDate());
        }
    }

    private static PlanEligibility getPlanEligibility(AssociateEligibilityOutput associateEligibilityOutput, PlanType planType) {
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setEligibleDate(associateEligibilityOutput.getAssociateEligibilityDate() != null ? convertDateToUTCSystemZone(associateEligibilityOutput.getAssociateEligibilityDate().substring(0, 10)) : null);
        planEligibility.setIsEligible(associateEligibilityOutput.getAssociateEligibilityIndicator() != null ? associateEligibilityOutput.getAssociateEligibilityIndicator() : null);
        planEligibility.setPlanGroup(planType.getPlanGroup());
        planEligibility.setPlanId(planType.getPlanId());
        planEligibility.setIsCompanyMatchEligible(false);
        planEligibility.setEligibleCovOptions(associateEligibilityOutput.getEligibleCoverageOptions());
        planEligibility.setOriginalHireDate(associateEligibilityOutput.getCommencementDate());
        planEligibility.setEligibleCovOptions(associateEligibilityOutput.getEligibleCoverageOptions());
        return planEligibility;
    }

    public static AssociateEvent createNewAssociateEvent(AssociateEvent source, PlanType newPlanType) {
        // Create a new instance of AssociateEvent
        AssociateEvent newEvent = new AssociateEvent();

        // Copy fields from the source
        newEvent.setEventType(source.getEventType());
        newEvent.setAssociateId(source.getAssociateId());
        newEvent.setAdditionalInfo(source.getAdditionalInfo());
        newEvent.setOrigin(source.getOrigin());
        newEvent.setTimeStamp(source.getTimeStamp());
        newEvent.setId(source.getId());
        // Set the new planType
        newEvent.setPlanType(newPlanType);

        return newEvent;
    }
    public static String determineEndDate(String startDate, String hardshipResumeDate, String countryCode) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate start = LocalDate.parse(startDate, formatter);
        LocalDate resumeDate = LocalDate.parse(hardshipResumeDate, formatter);

        // Calculate end date based on PR or non-PR associate using countryCode
        LocalDate calculatedEndDate;
        if ("PR".equalsIgnoreCase(countryCode)) {
            calculatedEndDate = start.plusYears(1);
        } else {
            calculatedEndDate = start.plusMonths(6);
        }

        // Validate against resume date
        if (!calculatedEndDate.equals(resumeDate)) {
            log.warn("ML END DATE IS INCORRECT. CORRECT DATE USED");
            return calculatedEndDate.format(formatter);
        }

        return resumeDate.format(formatter);
    }


    public static AssociateBenefit targetPatchOnCoverage(AssociateEvent associateEvent) {
        AssociateBenefit targetPatchCoverage = new AssociateBenefit();
        targetPatchCoverage.setAssociateId(associateEvent.getAssociateId());
        targetPatchCoverage.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        targetPatchCoverage.setPlanId(associateEvent.getPlanType().getPlanId());
        targetPatchCoverage.setEndDate(getUTCTimeAsString());
        targetPatchCoverage.setLoanStatusCode(LoanStatusCode.I);
        targetPatchCoverage.setLastModifiedAt(getUTCTimeAsString());
        return targetPatchCoverage;
    }

    public static AssociateBenefit upsertCoverage(AssociateEvent associateEvent,LoanModel loanModel) {
        AssociateBenefit coverage = new AssociateBenefit();
        coverage.setAssociateId(associateEvent.getAssociateId());
        coverage.setPlanId(associateEvent.getPlanType().getPlanId());
        coverage.setPlanGroup(associateEvent.getPlanType().getPlanGroup());
        coverage.setCreatedAt(associateEvent.getTimeStamp());
        coverage.setCreatedBy(associateEvent.getOrigin().getValue());
        PlanDeduction planDeduction = new PlanDeduction();
        coverage.setLoanId(loanModel.getLoanNumber());
        coverage.setLoanSequenceNumber(loanModel.getLoanNumber());
        if(loanModel.getDeductionAmount()>0.0){
            planDeduction.setValue(loanModel.getDeductionAmount());
            coverage.setLoanStatusCode(LoanStatusCode.A);
            coverage.setStartDate(associateEvent.getTimeStamp());
            coverage.setEndDate("");
        } else {
            planDeduction.setValue(0.0);
            coverage.setLoanStatusCode(LoanStatusCode.C);
            coverage.setEndDate(getUTCTimeAsString());
        }
        coverage.setDeduction(planDeduction);
        return coverage;

    }
    public static void updatePlanEligibility(AssociateBenefitsProfile existingAssociateProfile, HardshipModel matchEligibilityModel) {
        String merMatchEligDate=matchEligibilityModel.getMerMatchEligDate();

        boolean isEligible = false;//company Match Eligibility date from the Event
        if (matchEligibilityModel.getMerMatchEligInd() != null) {
            isEligible = ELIGIBLE.equalsIgnoreCase(matchEligibilityModel.getMerMatchEligInd());
        }

        if (existingAssociateProfile != null && existingAssociateProfile.getEligibility() != null
                && existingAssociateProfile.getEligibility().getPlans() != null) {

            List<PlanEligibility> plans = existingAssociateProfile.getEligibility().getPlans();

            boolean needsUpdate = false;
            for (PlanEligibility plan : plans) {
                if (!plan.getPlanGroup().equals(RETIREMENT)) {
                    continue;
                }
                if (plan.getIsCompanyMatchEligible()!=isEligible || !Objects.equals(plan.getCompanyMatchEligibleDate(), merMatchEligDate)) {
                    needsUpdate = true;
                    break;
                }
            }

            if (!needsUpdate) {
                log.info("No update needed for match eligibility - values are already up to date");
                return;
            }

            for (PlanEligibility plan : plans) {
                if(!plan.getPlanGroup().equals(RETIREMENT)){continue;}
                plan.setIsCompanyMatchEligible(isEligible);
                plan.setCompanyMatchEligibleDate(merMatchEligDate);
                if(matchEligibilityModel.getCountryCode().equals(COUNTRY_CODE_PR)){
                    plan.setIsEligible(plan.getIsCompanyMatchEligible());
                    plan.setEligibleDate(plan.getCompanyMatchEligibleDate());
                }
            }
            existingAssociateProfile.setLastModifiedBy(BE2089);
            existingAssociateProfile.setLastModifiedAt(getUTCTimeAsString());
        }

    }
}
