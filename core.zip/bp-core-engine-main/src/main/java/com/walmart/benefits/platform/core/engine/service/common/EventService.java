package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@Service("EventService")
@AllArgsConstructor
public class EventService implements JavaDelegate {

    private final EventArchiveDao eventArchiveDao;

    private final EncryptionUtil encryptionUtil;

    private final RetryTemplate retryTemplate;

    /**
     * Update Event status to PROCESSED, FAILED, QUEUED based on the execution context.
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            Status status = Boolean.TRUE.equals(delegateExecution.getVariables().get(EXECUTE_LATER_AS_BATCH)) ? Status.QUEUED : Status.PROCESSED;
            delegateExecution.setVariable(EVENT_STATUS, status);
            updateEvent(delegateExecution);
        }catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, EVENT_SERVICE, exception.getMessage());
        }
    }

    @Transactional
    public void updateEvent(DelegateExecution delegateExecution) throws EventNotFoundException {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            Status eventStatus = (Status) variables.get(EVENT_STATUS);
            String errorCode = (String) delegateExecution.getVariable(ERROR_CODE);
            String errorMessage = (String) delegateExecution.getVariable(ERROR_MESSAGE);
            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);
            log.info("Update event status , associate Id - {}, plan Id - {}, event status {}", encryptionUtil.encrypt(associateEvent.getAssociateId()),
                    associateEvent.getPlanType().getPlanId(), eventStatus);

            Event eventAvailableInDatabase = getArchiveDaoById(associateEvent, associateEvent.getPlanType().equals(PlanType.NONE) ?
                    planType : associateEvent.getPlanType().getPlanId());

            eventAvailableInDatabase.getEventStatuses().forEach(data -> {
                data.setErrorCode(errorCode);
                data.setErrorMessage(errorMessage);
                data.setStatus(eventStatus);
            });

            Event updatedEvent = updateEventStatus(eventAvailableInDatabase);
            log.info("Event updated successfully, UUID - {}", updatedEvent.getId());

        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, EVENT_SERVICE, exception.getMessage());
        }
    }

    public Event updateEventStatus(Event eventAvailableInDatabase) {
        Event updatedEvent = null;
        try {
            updatedEvent = retryTemplate.execute(retryContext -> {
                        log.info("UpdateEventStatus :: Retry attempt # {}", retryContext.getRetryCount());
                        return eventArchiveDao.save(eventAvailableInDatabase);
                    }, retryContext -> {
                        log.error("UpdateEventStatus :: Failed to update the event after retries : {}", retryContext.getLastThrowable().getMessage());
                        throw new RuntimeException("UpdateEventStatus :: Failed to update the event after retries", retryContext.getLastThrowable());
                    }
            );
        } catch (DataAccessException | ResourceAccessException e) {
            log.error("UpdateEventStatus :: Database access error while updating event: {}", e.getMessage(), e);
            throw new RuntimeException("UpdateEventStatus :: Database access error", e);
        } catch (Exception e) {
            log.error("UpdateEventStatus :: Unexpected error while updating event: {}", e.getMessage(), e);
            throw new RuntimeException("UpdateEventStatus :: " +
                    "Unexpected error while updating event", e);
        }
        return updatedEvent;
    }

    @Transactional(readOnly = true)
    public Event getArchiveDaoById(AssociateEvent associateEvent, String planType) {
        try {
            log.info("Get event by ID, associate Id - {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
            return retryTemplate.execute(retryContext -> {
                        return eventArchiveDao.findByIdAndEventStatus_subPlanType(associateEvent.getId(), planType)
                                .orElseThrow(() -> new EventNotFoundException("Event not found for associate Id: " + associateEvent.getAssociateId()));
                    }, retryContext -> {
                        log.error("Failed to retrieve event after retries: {}", retryContext.getLastThrowable().getMessage());
                        throw new RuntimeException("Failed to retrieve event after retries", retryContext.getLastThrowable());
                    }
            );

        } catch (DataAccessException | ResourceAccessException e) {
            log.error("Database access error while updating event, associate Id: {}, error message: {},", associateEvent.getAssociateId(), e.getMessage(), e);
            throw new RuntimeException("Database access error", e);
        } catch (Exception e) {
            log.error("Unexpected error while updating event, associate Id: {}, error message: {}", associateEvent.getAssociateId(), e.getMessage(), e);
            throw new RuntimeException("Unexpected error while updating event", e);
        }

    }

}
