package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.List;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;


@Slf4j
@Service("GetAllCoveragesForAssociateService")
public class GetAllCoveragesForAssociateService implements JavaDelegate {

    @Value("${consumer.associate-benefits-service-app-name}")
    private String associateBenefitServiceAppName;


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;


    public GetAllCoveragesForAssociateService(RestTemplate restTemplate, HttpUtils httpUtils) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
    }

    /**
     * Get Data to associate coverage API service
     *
     * @param delegateExecution :
     * @throws Exception :
     */
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        try {
            delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, FALSE);
            AssociateEvent associateEvent = (AssociateEvent) delegateExecution.getVariable(ASSOCIATE_EVENT);
            List<AssociateBenefit> coverageResponseList = getPlanCoverage(associateEvent, retryCount, delegateExecution);
            delegateExecution.setVariable(COVERAGE_RESPONSE_LIST, coverageResponseList);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, "BENEFIT_COVERAGE_SERVICE", exception.getMessage());
        }
    }

    private List<AssociateBenefit> getPlanCoverage(AssociateEvent associateEvent, int retryCount, DelegateExecution delegateExecution) throws Exception {
        try {
            String coverageURL = UriComponentsBuilder.fromHttpUrl(httpUtils.getAllCoveragesUrl())
                    .queryParam("associateId", associateEvent.getAssociateId())
                    .toUriString();
            ResponseEntity<List<AssociateBenefit>> coverageResponse = restTemplate.exchange(coverageURL, HttpMethod.GET,
                    httpUtils.getHttpEntity(associateBenefitServiceAppName), new ParameterizedTypeReference<List<AssociateBenefit>>() {
                    });
            log.info("GetCoverageAPIService Response : {}", coverageResponse.getStatusCode());

            if (coverageResponse.getStatusCode() == HttpStatus.OK && coverageResponse.getBody() != null) {
                delegateExecution.setVariable(IS_COVERAGE_AVAILABLE, TRUE);
                return coverageResponse.getBody();
            }
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() != HttpStatus.NOT_FOUND) {
                log.error(e.getMessage(), e);
                if (retryCount == 0) {
                    setExceptionData(delegateExecution, "GET_ALL_COVERAGE_SERVICE_ERROR", e.getMessage());
                }
                throw e;
            }
        } catch (HttpServerErrorException | ResourceAccessException exception) {
            log.info("GetCoverageAPIBatchService - retry {}", retryCount);
            if (retryCount == 0) {
                setExceptionData(delegateExecution, "GET_ALL_COVERAGE_SERVICE_NOT_AVAILABLE", exception.getMessage());
            }
            log.error(exception.getMessage(), exception);
            throw exception;
        }
        return Collections.emptyList();
    }
}






