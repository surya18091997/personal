package com.walmart.benefits.platform.core.engine.consumer;

import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.header.Headers;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.AES_SECRET_KEY;

public class AESDeserializer<T> extends JsonDeserializer<T> {

    private String secret ,salt = null;

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        super.configure(configs, isKey);
        secret = (String) configs.get(AES_SECRET_KEY);
        if (secret == null) {
            throw new SerializationException(AES_SECRET_KEY + " cannot be null.");
        }
    }

    @Override
    public T deserialize(String topic, Headers headers, byte[] data) {
        return super.deserialize(topic, headers, AES.decrypt(data, secret));
    }

    @Override
    public T deserialize(String topic, byte[] data) {
        return super.deserialize(topic, AES.decrypt(data, secret));
    }
}