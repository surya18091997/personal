package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class DefaultRehireRuleResponseProcessor extends AbstractRuleResponseProcessor {

    public DefaultRehireRuleResponseProcessor() {
        super(RE_HIRE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultRehireRuleResponseProcessor: Default processing for RE_HIRE event");
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() {
        return null;
    }
}
