package com.walmart.benefits.platform.core.engine.service.executionlisteners;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.entity.EventStatus;
import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.getUTCTimeAsString;

@Slf4j
@Service("WorkFlowStartListener")
@AllArgsConstructor
public class WorkFlowStartListener implements ExecutionListener {

    private final EventArchiveDao eventArchiveDao;

    private final RetryTemplate retryTemplate;

    @Override
    @Transactional
    public void notify(DelegateExecution delegateExecution) {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();

            if(Boolean.TRUE.equals(variables.get(OVERRIDE_DEFERRED_BATCH_EXECUTION))) return;

            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);
            log.info("WorkFlowStartListener starts..., UUID {}", associateEvent.getId());
            Optional<Event> optionalEvent = retryTemplate.execute(context -> eventArchiveDao.findById(associateEvent.getId()));
            Event eventAvailableInDatabase = optionalEvent.orElseThrow(() ->
                    new EventNotFoundException("Event not available in database"));
            if (associateEvent.getOrigin().equals(EventOrigin.ENROLLMENT_API)) {
                Enrollment enrollment = convertMapToEnrollment((LinkedHashMap<String, Object>) associateEvent.getAdditionalInfo());
                log.info("Enrollment ID - {}, Associate ID - {},Origin - {}", enrollment.getEnrollmentId(), enrollment.getAssociateId(), enrollment.getOriginSystem());
                List<AssociateEvent> associateEvents = getAssociateEvents(enrollment, associateEvent, eventAvailableInDatabase);
                delegateExecution.setVariable(ENROLLMENT, enrollment);
                delegateExecution.setVariable(ASSOCIATE_EVENTS, associateEvents);
            } else {
                eventAvailableInDatabase.getEventStatuses().add(buildEventStatus(associateEvent.getPlanType().getPlanId().isEmpty()?planType:associateEvent.getPlanType().getPlanId(), eventAvailableInDatabase));
            }
            retryTemplate.execute(retryContext -> eventArchiveDao.save(eventAvailableInDatabase));
        }catch (Exception e) {
            log.error("Error in WorkFlowStartListener - {}", e.getMessage());
            throw new BpmnError("EXECUTION_START_LISTENER", e.getMessage());
        }
    }

    private List<AssociateEvent> getAssociateEvents(Enrollment enrollment, AssociateEvent associateEvent, Event eventAvailableInDatabase) {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        if(enrollment.getPlanElections() == null || enrollment.getPlanElections().isEmpty())
        {
            log.warn("No plan elections found for enrollment ID - {}", enrollment.getEnrollmentId());
            eventAvailableInDatabase.getEventStatuses().add(buildEventStatus(CONSENT_UPDATE, eventAvailableInDatabase));
            return associateEvents;
        }
        enrollment.getPlanElections().forEach(planElection -> {
            PlanType planType = PlanType.valueOf(planElection.getPlanId().toUpperCase());
            AssociateEvent assocEvent = AssociateEvent.builder()
                    .id(associateEvent.getId())
                    .associateId(associateEvent.getAssociateId())
                    .eventType(associateEvent.getEventType())
                    .description(associateEvent.getDescription())
                    .origin(associateEvent.getOrigin())
                    .planType(planType)
                    .timeStamp(enrollment.getCreatedAt())
                    .additionalInfo(planElection)
                    .build();
            eventAvailableInDatabase.getEventStatuses().add(buildEventStatus(planType.getPlanId(), eventAvailableInDatabase));
            associateEvents.add(assocEvent);
        });
        return associateEvents;
    }

    private EventStatus buildEventStatus(String associateEvent, Event eventAvailableInDatabase) {
        return EventStatus.builder()
                .id(UUID.randomUUID())
                .status(Status.RECEIVED)
                .createdBy(ApplicationConstants.SYSTEM_CORE_ENGINE)
                .createdAt(getUTCTimeAsString())
                .subPlanType(associateEvent)
                .event(eventAvailableInDatabase)
                .build();
    }

    public static Enrollment convertMapToEnrollment(Map<String, Object> map) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return objectMapper.convertValue(map, Enrollment.class);
    }


}
