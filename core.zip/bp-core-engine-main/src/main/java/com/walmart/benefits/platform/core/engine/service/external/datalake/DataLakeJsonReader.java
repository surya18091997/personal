package com.walmart.benefits.platform.core.engine.service.external.datalake;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;

import java.io.IOException;

public interface DataLakeJsonReader {
    EventType getEventType();
    String readDataLakeJsonFiles() throws IOException;
}