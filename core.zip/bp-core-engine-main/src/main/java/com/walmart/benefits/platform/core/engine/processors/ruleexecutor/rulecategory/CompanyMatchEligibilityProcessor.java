package com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessorFactory;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleExecutionException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleMetadataSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RulesSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RuleExecutorFactory;
import com.walmart.benefits.rules.benefitsrulessdk.executor.services.RuleExecutorService;
import com.walmart.benefits.rules.benefitsrulessdk.mapper.factory.InputSchemaMapperFactory;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleRequest;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleResponse;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;


@Slf4j
@Service
@AllArgsConstructor
public class CompanyMatchEligibilityProcessor implements RuleCategoryProcessor {

    private final RuleRequestProcessorFactory processorFactory;

    private final RuleResponseProcessorFactory responseProcessorFactory;

    private final EncryptionUtil encryptionUtil;

    @Override
    public void process(DelegateExecution delegateExecution) throws RuntimeException {
        log.info("CompanyMatchEligibilityProcessor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        String planTypeStr = (String) variables.get(PLAN_TYPE_STR);
        String planType = (String) variables.get(PLAN_TYPE);
        PlanType planId = PlanType.valueOf(planTypeStr);

        CompanyMatchEligibilityInput companyMatchEligibilityInput = InputSchemaMapperFactory.schemaToInput(benefitsEntity, CompanyMatchEligibilityInput.class);
        delegateExecution.setVariable(COMPANY_MATCH_ELIGIBILITY_INPUT, companyMatchEligibilityInput);

        RuleRequestProcessor processor = processorFactory.getProcessor(planType, associateEvent.getEventType());
        processor.process(delegateExecution);

        companyMatchEligibilityInput = (CompanyMatchEligibilityInput) delegateExecution.getVariable(COMPANY_MATCH_ELIGIBILITY_INPUT);

        CompanyMatchEligibilityOutput payload = executeRules(delegateExecution, companyMatchEligibilityInput, planId, associateEvent);

        RuleResponseProcessor responseProcessor = responseProcessorFactory.getProcessor(planType, associateEvent.getEventType());
        responseProcessor.process(delegateExecution);

        log.info("Rule Category ===> {}, Plan Type ===> {}, Eligibility Status for  plan ===> {}, Eligibility Date ===> {}, Win Number ===> {}",
                getRuleCategory(), planId, payload.getCompanyMatchEligibilityIndicator(), payload.getCompanyMatchEligibilityDate(),
                encryptionUtil.encrypt(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId()));
        delegateExecution.setVariables(variables);
        delegateExecution.setVariable(COMPANY_MATCH_ELIGIBILITY_INPUT, null);
        log.info("CompanyMatchEligibilityProcessor completed");
    }

    private CompanyMatchEligibilityOutput executeRules(DelegateExecution delegateExecution, CompanyMatchEligibilityInput companyMatchEligibilityInput, PlanType planId, AssociateEvent associateEvent)  {
        RuleRequest<CompanyMatchEligibilityInput> ruleRequest = new RuleRequest<>();
        ruleRequest.setPayload(companyMatchEligibilityInput);
        ruleRequest.setRuleSet(getRuleCategory());
        ruleRequest.setPlan(planId);
        ruleRequest.setEvent(associateEvent.getEventType());
        try {
            RuleExecutorService<CompanyMatchEligibilityInput, CompanyMatchEligibilityOutput> ruleExecutorService = RuleExecutorFactory.createExecutor(getRuleCategory());
            RuleResponse<CompanyMatchEligibilityOutput> ruleResponse = ruleExecutorService.execute(ruleRequest);
            CompanyMatchEligibilityOutput payload = ruleResponse.getPayload();
            delegateExecution.setVariable(COMPANY_MATCH_RULE_RESPONSE, payload);
            return payload;
        } catch (RulesSyncException | RuleMetadataSyncException | RuleExecutionException e) {
            log.error(e.getMessage(), e);
            throw new com.walmart.benefits.platform.core.engine.exceptions.RuleExecutionException("Rule Execution Failed", e);
        }
    }


    @Override
    public RuleCategory getRuleCategory() {
        return RuleCategory.COMPANY_MATCH_ELIGIBILITY;
    }


}
