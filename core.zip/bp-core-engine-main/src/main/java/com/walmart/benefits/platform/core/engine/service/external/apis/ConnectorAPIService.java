package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.exceptions.DataNotAvailableException;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.RulesInputMetadata;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;


@Slf4j
@Service("ConnectorService")
public class ConnectorAPIService implements JavaDelegate {

    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public ConnectorAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Reads data from connector service
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        log.info("Connector service graphQL started..., Associate Id {}, PlanId {}", encryptionUtil.encrypt(associateEvent.getAssociateId()),
                associateEvent.getPlanType().getPlanId());
        try{
            RulesInputMetadata rulesInputMetadata = (RulesInputMetadata) delegateExecution.getVariable(RULE_META_DATA);

            ResponseEntity<ConnectorResponse> graphQLResponse = restTemplate.exchange(httpUtils.getConnectorGraphqlUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(String.format(rulesInputMetadata.getUpstreamGraphQlQuery(), associateEvent.getAssociateId()), httpUtils.getConnectorConsumerName()), ConnectorResponse.class);

            if(Objects.requireNonNull(graphQLResponse.getBody()).getData().getQueryAssociateUpstreamDetails() == null){
                throw new DataNotAvailableException(String.format("Data not available for associate id %s ", encryptionUtil.encrypt(associateEvent.getAssociateId())));
            }
            delegateExecution.setVariable("connectorResponse", graphQLResponse.getBody());
        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount,CONNECTOR_SERVICE_SERVER_ERROR);
        }catch (Exception exception){
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, CONNECTOR_SERVICE, exception.getMessage());
        }
    }


}
