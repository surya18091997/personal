package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.TERMINATION;

@Slf4j
@Service
public class RetirementTerminationEventProcessor extends AbstractEventProcessor {

    protected RetirementTerminationEventProcessor() {
        super(TERMINATION);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Termination event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        updateCoverages(variables);
        delegateExecution.setVariables(variables);
        log.info("Termination event processor ended");
    }

    private void updateCoverages(Map<String, Object> variables) {
        List<AssociateBenefit> coverages = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
        if (coverages != null && !coverages.isEmpty()) {
            AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            coverages = coverages.stream().filter(c -> c.getPlanId().contains(_401K)).toList();
            coverages.forEach(coverage -> updateCoverage(coverage, associateEvent));
            variables.put(COVERAGE_RESPONSE_LIST, coverages);
        }
    }

    private void updateCoverage(AssociateBenefit coverage, AssociateEvent event) {
        coverage.setEndDate(event.getTimeStamp());
        EventUtils.updateCommonFieldsCoverage(event, coverage);
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }
}



