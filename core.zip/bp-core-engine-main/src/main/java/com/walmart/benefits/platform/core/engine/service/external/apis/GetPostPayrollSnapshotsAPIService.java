package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.exceptions.DataNotAvailableException;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;

@Slf4j
@Service("GetPostPayrollSnapshotsService")
public class GetPostPayrollSnapshotsAPIService implements JavaDelegate {

    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public GetPostPayrollSnapshotsAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Get Data from Post Payroll Snapshots API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            ConnectorResponse connectorResponse = (ConnectorResponse) delegateExecution.getVariable(CONNECTOR_RESPONSE);

            String originalHireDate = connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().getOriginalHireDate();

            // Parse originalHireDate and calculate toDate
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD);
            LocalDate fromDate = LocalDate.parse(originalHireDate, formatter);
            LocalDate toDate = fromDate.plusYears(POST_PAYROLL_SNAPSHOT_YEARS);

            // Construct the URL with query parameters
            String url = String.format(POST_PAYROLL_URL_TEMPLATE,
                    httpUtils.getPostPayrollSnapshotServiceUrl(),
                    associateEvent.getAssociateId(),
                    fromDate.format(formatter),
                    toDate.format(formatter));

            delegateExecution.setVariable(POST_PAYROLL_SNAPSHOTS, new ArrayList<>());

            ResponseEntity<List<PostPayrollSnapshot>> postPayrollResponse = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    httpUtils.getHttpEntity(httpUtils.getPostPayrollSnapshotServiceAppName()),
                    new ParameterizedTypeReference<>() {}
            );
            log.info("GetPostPayrollSnapshotsService Response : {}", postPayrollResponse.getStatusCode());

            if (postPayrollResponse.getStatusCode() == HttpStatus.OK && postPayrollResponse.getBody() != null) {
                delegateExecution.setVariable(POST_PAYROLL_SNAPSHOTS, postPayrollResponse.getBody());
            }
            else {
                throw new DataNotAvailableException(String.format("Data not available for associate id %s ", encryptionUtil.encrypt(associateEvent.getAssociateId())));
            }
        } catch (HttpServerErrorException  exception) {
            log.info("GetPostPayrollSnapshotsService - retry {}", retryCount);
            httpUtils.handleError(delegateExecution, exception, retryCount, ASSOCIATE_POST_PAYROLL_SNAPSHOTS_GET_SERVER_ERROR);
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                var associateEvent = (AssociateEvent) delegateExecution.getVariables().get(ASSOCIATE_EVENT);
                log.info("Post Payroll Snapshots not found - {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
            } else {
                log.error(e.getMessage(), e);
            }
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_POST_PAYROLL_SNAPSHOTS_GET, exception.getMessage());
        }
    }
}