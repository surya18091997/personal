package com.walmart.benefits.platform.core.engine.configs;

import com.walmart.benefits.platform.core.engine.consumer.AESDeserializer;
import com.walmart.benefits.platform.core.engine.exceptions.CoreEngineRecoverableException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.backoff.FixedBackOff;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.apache.kafka.clients.consumer.ConsumerConfig.*;
import static org.apache.kafka.common.config.SslConfigs.*;
import static org.springframework.kafka.support.serializer.JsonDeserializer.TRUSTED_PACKAGES;
import static org.springframework.kafka.support.serializer.JsonDeserializer.VALUE_DEFAULT_TYPE;

@Slf4j
@Configuration
@Data
public class ConsumerConfig {

    @Value("${benefits.kafka.bootstrap-servers}")
    private String eventsQueueBootstrapServers;

    @Value("${benefits.kafka.group-id}")
    private String eventsQueueGroupId;

    @Value("${benefits.kafka.security-protocol}")
    private String securityProtocol;

    @Value("${benefits.kafka.truststore-type}")
    private String truststoreType;

    @Value("${benefits.kafka.truststore-location}")
    private String truststoreLocation;

    @Value("${benefits.kafka.keystore-location}")
    private String keystoreLocation;

    @Value("${benefits.kafka.truststore-password}")
    private String truststorePassword;

    @Value("${benefits.kafka.keystore-password}")
    private String keystorePassword;

    @Value("${benefits.kafka.key-password}")
    private String keyPassword;

    @Value("${benefits.kafka.max-poll-records}")
    private int maxPollRecords;

    @Value("${benefits.kafka.max-poll-time-interval}")
    private int maxPollInterval;

    @Value("${benefits.kafka.session-time-out}")
    private int sessionTimeOut;

    @Value("${benefits.kafka.aes-secret-key}")
    private String aesSecretKey;

    private final RetryTemplate retryTemplate;

    public ConsumerConfig(RetryTemplate retryTemplate) {
        this.retryTemplate = retryTemplate;
    }

    @Bean
    public ConsumerFactory<String, Object> consumerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(BOOTSTRAP_SERVERS_CONFIG, eventsQueueBootstrapServers);
        config.put(GROUP_ID_CONFIG, eventsQueueGroupId);
        config.put(ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(VALUE_DESERIALIZER_CLASS_CONFIG, AESDeserializer.class);
        config.put(AUTO_OFFSET_RESET_CONFIG, LATEST);
        config.put(MAX_POLL_RECORDS_CONFIG, maxPollRecords);
        config.put(SESSION_TIMEOUT_MS_CONFIG, sessionTimeOut);
        config.put(MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
        config.put(SECURITY_PROTOCOL, securityProtocol);
        config.put(VALUE_DEFAULT_TYPE, JAVA_LANG_OBJECT);
        config.put(TRUSTED_PACKAGES, TRUSTED_PACKAGE);
        config.put(AES_SECRET_KEY, aesSecretKey);
        config.put(SSL_TRUSTSTORE_TYPE_CONFIG, truststoreType);
        config.put(SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLocation);
        config.put(SSL_KEYSTORE_LOCATION_CONFIG, keystoreLocation);
        config.put(SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword);
        config.put(SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
        config.put(SSL_KEY_PASSWORD_CONFIG, keyPassword);
        return new DefaultKafkaConsumerFactory<>(config);
    }

    /**
     * Create kafka Listener with batch mode enabled
     * @return
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> concurrentKafkaListenerContainerFactory = new ConcurrentKafkaListenerContainerFactory<>();
        concurrentKafkaListenerContainerFactory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        concurrentKafkaListenerContainerFactory.setConsumerFactory(consumerFactory());
        concurrentKafkaListenerContainerFactory.setCommonErrorHandler(getErrorHandler());
        concurrentKafkaListenerContainerFactory.setBatchListener(true);
        return concurrentKafkaListenerContainerFactory;
    }

    /**
     * Failed message will be handled by DLQ
     * @return
     */
    private DefaultErrorHandler getErrorHandler() {
        FixedBackOff fixedBackOff = new FixedBackOff(1000L, 0);
        List<Class<? extends Exception>> retractableExceptions = Arrays.asList(Exception.class);
        DefaultErrorHandler defaultErrorHandler = new DefaultErrorHandler(consumerRecordRecoverer, fixedBackOff);
        retractableExceptions.forEach(defaultErrorHandler::addRetryableExceptions);
        return defaultErrorHandler;
    }

    ConsumerRecordRecoverer consumerRecordRecoverer = ((consumerRecord, e) -> {
        if (e.getCause() instanceof CoreEngineRecoverableException) {
            ConsumerRecord<String, Object> failedRecord = (ConsumerRecord<String, Object>) consumerRecord;
            try {
                //retryTemplate.execute(context -> saveFailureRecord(failedRecord.value(), e));
            } catch (Exception ex) {
                log.error("Exception occurred persisting the failure record for id {},", failedRecord.value());
            }
        }
    });

}