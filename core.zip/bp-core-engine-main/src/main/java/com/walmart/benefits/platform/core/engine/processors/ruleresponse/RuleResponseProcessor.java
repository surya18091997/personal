package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;

public interface RuleResponseProcessor {

    void process(DelegateExecution delegateExecution);

    EventType getEventType();

    String getPlanType();

}
