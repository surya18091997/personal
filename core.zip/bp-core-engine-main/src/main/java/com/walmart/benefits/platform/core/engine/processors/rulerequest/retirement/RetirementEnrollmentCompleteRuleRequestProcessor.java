package com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.DefaultEnrollmentCompleteRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;

@Slf4j
@Service
public class RetirementEnrollmentCompleteRuleRequestProcessor extends DefaultEnrollmentCompleteRuleRequestProcessor {

    public RetirementEnrollmentCompleteRuleRequestProcessor() {
        super();
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Rate Change Rule Response Processor");
        super.process(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);

        AssociateEligibilityInput associateEligibilityInput = (AssociateEligibilityInput) delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT);
        AssociateBenefitsProfile profile = CommonUtils.getProfile(delegateExecution);
        if (profile != null && profile.getEligibility() != null) {
            profile.getEligibility().getPlans().forEach(planEligibility -> {
                if (planEligibility.getPlanId().equals(associateEvent.getPlanType().getPlanId())) {
                    associateEligibilityInput.setPrevEligibilityDate(planEligibility.getEligibleDate());
                }
            });
        }
        log.info("Rate Change Rule Response Processor completed");
    }

    @Override
    public EventType getEventType() {
        return ENROLLMENT_COMPLETE;
    }
    @Override
    public String getPlanType() { return RETIREMENT; }
}
