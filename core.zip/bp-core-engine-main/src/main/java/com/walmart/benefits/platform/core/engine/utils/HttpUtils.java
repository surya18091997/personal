package com.walmart.benefits.platform.core.engine.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.owasp.encoder.Encode;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_EVENT;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.URL_FORMAT;
import static com.walmart.benefits.platform.core.engine.constants.URLConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@Component
@Data
public class HttpUtils {

    @Value("${consumer.id}")
    private String consumerId;

    @Value("${spring.env}")
    private String environment;

    @Value("${consumer.benefits-api-connector}")
    private String connectorConsumerName;

    @Value("${consumer.associate-benefits-service-app-name}")
    private String associateBenefitsServiceAppName;

    @Value("${consumer.transaction-log-service-app-name}")
    private String transactionLogServiceAppName;

    @Value("${consumer.associate-enrollment-service-app-name}")
    private String associateEnrollmentServiceAppName;

    @Value("${consumer.benefits-profile-service-app-name}")
    private String benefitsProfileServiceAppName;

    @Value("${consumer.associate-benefits-service-app-name}")
    private String associateBenefitServiceAppName;

    @Value("${consumer.benefits-profile-service-app-name}")
    private String associateProfileServiceAppName;

    @Value("${consumer.post-payroll-snapshot-service-app-name}")
    private String postPayrollSnapshotServiceAppName;

    @Value("${consumer.assessment-service-app-name}")
    private String assessmentServiceAppName;

    @Value("${external.connector.graphql-url}")
    private String connectorGraphqlUrl;

    @Value("${external.benefit-api.benefits-profile-service-url}")
    private String benefitsProfileServiceUrl;

    @Value("${external.benefit-api.associate-benefits-service-url}")
    private String associateBenefitsServiceUrl;

    @Value("${external.benefit-api.enrollment-service-url}")
    private String associateEnrollmentServiceUrl;

    @Value("${external.transaction.log-service-url}")
    private String transactionLogServiceUrl;

    @Value("${external.post-payroll.snapshot-service-url}")
    private String postPayrollSnapshotServiceUrl;

    @Value("${external.assessment-api.assessment-service-url}")
    private String assessmentServiceUrl;

    private final EncryptionUtil encryptionUtil;

    public HttpUtils(EncryptionUtil encryptionUtil) {
        this.encryptionUtil = encryptionUtil;
    }

    public HttpEntity<Object> getHttpEntity(Object data, String serviceName) {
        try {
            String requestBody = new ObjectMapper().writeValueAsString(data);
            log.info("Request body :: {}", encryptionUtil.encrypt(requestBody));
        } catch (JsonProcessingException e) {
            log.error("Parser error : {}", e.getMessage());
        }
        return new HttpEntity<>(data, getHeaders(serviceName));
    }

    public HttpEntity<Object> getHttpEntity(String serviceName) {
        return new HttpEntity<>(getHeaders(serviceName));
    }

    private HttpHeaders getHeaders(String serviceName) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ApplicationConstants.WM_SVC_ENV, environment);
        headers.add(ApplicationConstants.WM_SVC_NAME, serviceName);
        headers.add(ApplicationConstants.WM_CONSUMER_ID, consumerId);
        return headers;
    }

    public String getProfileCreateUrl() {
        return String.format(URL_FORMAT, benefitsProfileServiceUrl, ASSOCIATE_PROFILE_CREATE);
    }

    public String getProfileUpsertUrl() {
        return String.format(URL_FORMAT, benefitsProfileServiceUrl, ASSOCIATE_PROFILE_UPSERT);
    }

    public String getAssessmentUpsertUrl() {
        return String.format(URL_FORMAT, assessmentServiceUrl, ASSESSMENT_UPSERT);
    }


    public String getProfileUpdateUrl() {
        return String.format(URL_FORMAT, benefitsProfileServiceUrl, ASSOCIATE_PROFILE_UPDATE);
    }

    public String getProfileUrl() {
        return String.format(URL_FORMAT, benefitsProfileServiceUrl, ASSOCIATE_PROFILE_GET);
    }

    public String getCoverageUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_GET);
    }

    public String getCoverageHistoryUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_HISTORY_PATCH);
    }

    public String getAllCoveragesUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_GET_ALL);
    }

    public String getCoverageCreateUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_CREATE);
    }

    public String getCoverageUpdateUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_UPDATE);
    }

    public String getCoverageUpsertBulkUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_UPSERT_BULK);
    }
    public String getCoverageUpsertUrl() {
        return String.format(URL_FORMAT, associateBenefitsServiceUrl, ASSOCIATE_BENEFIT_UPSERT);
    }

    public String getEnrollmentUrl() {
        return String.format(URL_FORMAT, associateEnrollmentServiceUrl, ASSOCIATE_ENROLLMENT_CREATE);
    }

    public String getTransactionLogUrl() {
        return String.format(URL_FORMAT, transactionLogServiceUrl, TRANSACTION_LOG_CREATE);
    }

    public String getTransactionLogBulkUrl() {
        return String.format(URL_FORMAT, transactionLogServiceUrl, TRANSACTION_LOG_BULK_CREATE);
    }

    public void handleError(DelegateExecution delegateExecution, Exception exception, int retryCount, String serviceName) {
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        if (retryCount == 0) {
            retryExceeded(associateEvent, delegateExecution, serviceName, exception.getMessage());
        }
        if (exception instanceof HttpServerErrorException serverErrorException) {
            log.info("Server Error :: retrying...., Associate Id : {}, Plan Id : {}", encryptionUtil.encrypt(associateEvent.getAssociateId()), associateEvent.getPlanType().getPlanId());
            handleServerError(delegateExecution, retryCount, serviceName, serverErrorException, associateEvent);
        } else if (exception instanceof HttpClientErrorException clientErrorException) {
            log.info("Client Error :: retrying...., Associate Id :  {}, Plan Id : {}", encryptionUtil.encrypt(associateEvent.getAssociateId()),associateEvent.getPlanType().getPlanId());
            handleClientError(delegateExecution, retryCount, serviceName, clientErrorException, associateEvent);
        }
    }

    public void handleClientError(DelegateExecution delegateExecution, int retryCount, String serviceName, HttpClientErrorException clientErrorException, AssociateEvent associateEvent) {
        if (clientErrorException.getStatusCode() == HttpStatus.PRECONDITION_FAILED) {
            retryLogging(retryCount, associateEvent);
            log.error(clientErrorException.getMessage(), clientErrorException);
            throw clientErrorException;
        } else {
            nonRetryExceptions(associateEvent);
            log.error(clientErrorException.getMessage(), clientErrorException);
            setExceptionData(delegateExecution, serviceName, clientErrorException.getMessage());
        }
    }

    public void handleServerError(DelegateExecution delegateExecution, int retryCount, String serviceName, HttpServerErrorException serverErrorException, AssociateEvent associateEvent) {
        if (serverErrorException.getStatusCode() == HttpStatus.BAD_GATEWAY ||
                serverErrorException.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE ||
                serverErrorException.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT ) {
            retryLogging(retryCount, associateEvent);
            log.error(serverErrorException.getMessage(), serverErrorException);
            throw serverErrorException;
        } else {
            nonRetryExceptions(associateEvent);
            log.error(serverErrorException.getMessage(), serverErrorException);
            setExceptionData(delegateExecution, serviceName, serverErrorException.getMessage());
        }
    }

    public void nonRetryExceptions(AssociateEvent associateEvent) {
        log.error("Not a retryable exception,so logging information into archive table, AssociateId {}, Plan Id {}",
                encryptionUtil.encrypt(associateEvent.getAssociateId()), associateEvent.getPlanType().getPlanId());
    }

    public void retryLogging(int retryCount, AssociateEvent associateEvent) {
        log.error("Retry.... count {}, AssociateId {}", retryCount,
                encryptionUtil.encrypt(associateEvent.getAssociateId()));
    }

    private void retryExceeded(AssociateEvent associateEvent, DelegateExecution delegateExecution, String serviceName, String exception) {
        log.error("Retry exceeded.... logging information into archive table, AssociateId {}",
                encryptionUtil.encrypt(associateEvent.getAssociateId()));
        setExceptionData(delegateExecution, serviceName, exception);
    }

    public String escapeHtml(String input) {
        return Encode.forHtml(input);
    }


}
