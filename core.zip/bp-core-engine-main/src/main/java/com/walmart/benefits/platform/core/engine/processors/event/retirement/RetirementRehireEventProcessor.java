package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.RE_HIRE;

@Slf4j
@Service
public class RetirementRehireEventProcessor extends AbstractEventProcessor {

    public RetirementRehireEventProcessor() {
        super(RE_HIRE);
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }

    @Override
    public void process(DelegateExecution delegateExecution){
        log.info("401k event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.updateAssociateProfile(benefitsEntity));
        delegateExecution.setVariables(variables);
        log.info("401k event processor ended");
    }

}
