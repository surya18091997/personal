package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.constants.WorkflowConstants;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.external.datalake.DataLakeJsonReader;
import com.walmart.benefits.platform.core.engine.service.external.datalake.DataLakeJsonReaderFactory;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

@Slf4j
@Service
@AllArgsConstructor
public class AsyncBatchProcessorService {

    private final RuntimeService runtimeService;
    private final EncryptionUtil encryptionUtil;
    private final EventArchiveService eventArchiveService;
    private final DataLakeJsonReaderFactory dataLakeJsonReaderFactory;

    @Async
    public void processEvents(List<Event> events) {
        if (events.isEmpty()) {
            log.warn("No events to process.");
            return;
        }
        try {
            Event firstEvent = events.get(0);
            if (CommonUtils.validEventType(firstEvent.getEventType())) {
                DataLakeJsonReader dataLakeJsonReader = dataLakeJsonReaderFactory.getDataLakeJsonReader(firstEvent.getEventType());
                String dataLakeJsonCacheKey = (dataLakeJsonReader != null) ? dataLakeJsonReader.readDataLakeJsonFiles() : null;

                events.forEach(event -> {
                    try {
                        log.info("Async processing started for Event Type: {}, Associate ID: {}",
                                event.getEventType(), encryptionUtil.encrypt(String.valueOf(event.getAssociateId())));

                        var variables = new HashMap<String, Object>();
                        AssociateEvent associateEvent = eventArchiveService.toAssociateEvent(event);

                        variables.put(ASSOCIATE_EVENT, associateEvent);
                        variables.put(OVERRIDE_DEFERRED_BATCH_EXECUTION, true);
                        if (dataLakeJsonCacheKey != null) variables.put(DATA_LAKE_JSON_CACHE_KEY, dataLakeJsonCacheKey);

                        runtimeService.startProcessInstanceByKey(WorkflowConstants.WORKFLOW_SELECTOR, variables);
                        log.info("Successfully started process instance for Event Type: {}", event.getEventType());
                    } catch (IllegalArgumentException e) {
                        log.error("Invalid event type: {}", event.getEventType(), e);
                    } catch (Exception e) {
                        log.error("Error processing event with Event Type: {}, Associate ID: {}",
                                event.getEventType(), encryptionUtil.encrypt(String.valueOf(event.getAssociateId())), e);
                    }
                });
            }
        } catch (Exception e) {
            log.error("Error fetching DataLakeJsonList for batch processing.", e);
        }
    }
}