package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory.RuleCategoryProcessor;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

@Slf4j
@Service
public class DisabilityRuleExecutorProcessor extends DefaultExecutorProcessor {

    public DisabilityRuleExecutorProcessor(RuleMetaDataConfig ruleMetaDataConfig,List<RuleCategoryProcessor> ruleCategoryProcessors){
        super(ruleMetaDataConfig,ruleCategoryProcessors);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        String planId = associateEvent.getPlanType().getPlanId();
        log.info("Disability Rule Executor Processor started :: {}",planId);
        //Initiating the Plan selection variable
        delegateExecution.setVariable(PLAN_ELECTIONS,new ArrayList<PlanElection>());
        log.info("Disability Rule Executor Processor Ended :: {}",planId);
        super.process(delegateExecution);
    }


    @Override
    public String getPlanType() {
        return DISABILITY;
    }


}
