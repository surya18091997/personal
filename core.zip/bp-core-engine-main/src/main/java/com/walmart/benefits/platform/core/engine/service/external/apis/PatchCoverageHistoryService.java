package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.Objects;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_COVERAGE_SERVICE_GET;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;

@Slf4j
@Service("PatchCoverageHistoryService")
public class PatchCoverageHistoryService implements JavaDelegate {
    private final RestTemplate restTemplate;
    private final HttpUtils httpUtils;
    private final EncryptionUtil encryptionUtil;

    public PatchCoverageHistoryService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        log.info("Patch coverage history api started..., Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            delegateExecution.setVariable(IS_COVERAGE_HISTORY_AVAILABLE, FALSE);
            PlanType planType = associateEvent.getPlanType();

            PatchRequest patchRequest = PatchCoverageRequestFactory.getFactory(associateEvent.getEventType())
                .build(associateEvent, delegateExecution, variables, planType, httpUtils);
            if (patchRequest == null) {
                log.error("No patch request could be built for event type: {}", associateEvent.getEventType());
                setExceptionData(delegateExecution, ASSOCIATE_COVERAGE_SERVICE_GET, "Unsupported event type for patch");
                return;
            }

            ResponseEntity<AssociateBenefit> coverageResponse = restTemplate.exchange(
                    patchRequest.url, HttpMethod.POST,
                    httpUtils.getHttpEntity(patchRequest.payload, httpUtils.getAssociateBenefitServiceAppName()), AssociateBenefit.class);

            log.info("Patch coverage history api status code: {}, Associate Id {}",
                    coverageResponse.getStatusCode(), encryptionUtil.encrypt(associateEvent.getAssociateId()));

            if (coverageResponse.getStatusCode() == HttpStatus.OK) {
                delegateExecution.setVariable(IS_COVERAGE_HISTORY_AVAILABLE, TRUE);
            }
        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount, ASSOCIATE_COVERAGE_SERVICE_GET_SERVER_ERROR);
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.info("Associate coverage history not found {},proceeding with Upsert", encryptionUtil.encrypt(associateEvent.getAssociateId()));
                delegateExecution.setVariable(IS_COVERAGE_HISTORY_AVAILABLE, FALSE);
            } else {
                log.error(e.getMessage(), e);
                setExceptionData(delegateExecution, ASSOCIATE_COVERAGE_SERVICE_GET, e.getMessage());
            }
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_COVERAGE_SERVICE_GET, exception.getMessage());
        }
    }

    public interface PatchCoverageRequestFactory {
        PatchRequest build(AssociateEvent associateEvent, DelegateExecution delegateExecution, Map<String, Object> variables, PlanType planType, HttpUtils httpUtils);
        static PatchCoverageRequestFactory getFactory(EventType eventType) {
            if (Objects.requireNonNull(eventType) == EventType.LOAN) {
                return new LoanPatchCoverageRequestFactory();
            }
            return (a, d, v, p, h) -> null;
        }
    }

    public static class LoanPatchCoverageRequestFactory implements PatchCoverageRequestFactory {
        @Override
        public PatchRequest build(AssociateEvent associateEvent, DelegateExecution delegateExecution, Map<String, Object> variables, PlanType planType, HttpUtils httpUtils) {
            UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(httpUtils.getCoverageHistoryUrl())
                .queryParam("associateId", associateEvent.getAssociateId())
                .queryParam("planId", planType.getPlanId());
            Object loanSequenceNumber = delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER);
            if (loanSequenceNumber != null) {
                urlBuilder.queryParam("loanSequenceNumber", loanSequenceNumber.toString());
                urlBuilder.queryParam("loanStatusCode", "C");
            }
            Object payload = EventUtils.targetPatchOnCoverage(associateEvent);
            return new PatchRequest(urlBuilder.toUriString(), payload);
        }
    }

    /**
     * Simple holder for PATCH request data
     */
    private static class PatchRequest {
        final String url;
        final Object payload;
        PatchRequest(String url, Object payload) {
            this.url = url;
            this.payload = payload;
        }
    }

}
