package com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.AbstractRuleRequestProcessor;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.RETIREMENT;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants._401K;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class RetirementNewHireRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public RetirementNewHireRuleRequestProcessor() {
        super(NEW_HIRE);
    }
    @Override
    public void process(DelegateExecution delegateExecution) {
        // ADD logic here to create custom rule request
    }

    @Override
    public EventType getEventType() {
        return NEW_HIRE;
    }

    @Override
    public String getPlanType() { return RETIREMENT; }
}
