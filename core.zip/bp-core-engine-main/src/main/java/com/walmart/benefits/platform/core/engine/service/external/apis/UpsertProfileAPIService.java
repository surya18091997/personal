package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogProfile;

@Slf4j
@Service("UpsertProfileAPIService")
public class UpsertProfileAPIService implements JavaDelegate {


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public UpsertProfileAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Push Data to benefits Profile API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        Enrollment enrollment =(Enrollment) variables.get(ENROLLMENT);
        log.info("Upsert profile api started..., Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            var associateBenefitsProfile = (AssociateBenefitsProfile) variables.get(ASSOCIATE_BENEFITS_PROFILE);
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);

            ResponseEntity<AssociateBenefitsProfile> response = restTemplate.exchange(httpUtils.getProfileUpsertUrl(), HttpMethod.PATCH,
                    httpUtils.getHttpEntity(associateBenefitsProfile,httpUtils.getBenefitsProfileServiceAppName()), AssociateBenefitsProfile.class);
            log.info("Upsert Profile api response : {} , Associate Id {}", response.getStatusCode(),
                    encryptionUtil.encrypt(associateEvent.getAssociateId()));

            //Transaction Log, will be removed in future release
            ResponseEntity<String> transactionLogResponse = restTemplate.exchange(httpUtils.getTransactionLogUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(getTransactionLogProfile(associateBenefitsProfile, associateEvent, planType,enrollment), httpUtils.getTransactionLogServiceAppName()), String.class);
            log.info("TransactionLog api status code : {}, Associate Id {}", transactionLogResponse.getStatusCode(),
                    encryptionUtil.encrypt(associateEvent.getAssociateId()));

        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount,ASSOCIATE_PROFILE_SERVICE_UPSERT_SERVER_ERROR);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_PROFILE_SERVICE_UPSERT, exception.getMessage());
        }

    }

}
