package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogCoverage;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogProfile;

@Slf4j
@Service("CreateProfileAPIService")
public class CreateProfileAPIService implements JavaDelegate {


    private final RestTemplate restTemplate;

    private final HttpUtils httpUtils;

    private final EncryptionUtil encryptionUtil;

    public CreateProfileAPIService(RestTemplate restTemplate, HttpUtils httpUtils, EncryptionUtil encryptionUtil) {
        this.restTemplate = restTemplate;
        this.httpUtils = httpUtils;
        this.encryptionUtil = encryptionUtil;
    }

    /**
     * Push Data to benefits Profile API service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        int retryCount = getRetryCount(delegateExecution);
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        log.info("Create profile api started..., Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        try {
            var associateBenefitsProfile = (AssociateBenefitsProfile) variables.get(ASSOCIATE_BENEFITS_PROFILE);
            var associateBenefit = (List<AssociateBenefit>) variables.get(ASSOCIATE_COVERAGE);
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);

            ResponseEntity<String> response = restTemplate.exchange(httpUtils.getProfileCreateUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(associateBenefitsProfile,httpUtils.getBenefitsProfileServiceAppName()), String.class);
            log.info("create profile status code: {} , Associate Id {}", response.getStatusCode(),encryptionUtil.encrypt(associateEvent.getAssociateId()));

            //Transaction Log, will be removed in future release
            ResponseEntity<String> transactionLogResponse = restTemplate.exchange(httpUtils.getTransactionLogUrl(), HttpMethod.POST,
                    httpUtils.getHttpEntity(getTransactionLogProfile(associateBenefitsProfile, associateEvent, planType,null), httpUtils.getTransactionLogServiceAppName()), String.class);
            log.info("TransactionLog api status code : {}, Associate Id {}", transactionLogResponse.getStatusCode(),
                    encryptionUtil.encrypt(associateEvent.getAssociateId()));

        } catch (HttpServerErrorException exception) {
            httpUtils.handleError(delegateExecution, exception, retryCount,ASSOCIATE_PROFILE_SERVICE_CREATE_SERVER_ERROR);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, ASSOCIATE_PROFILE_SERVICE_CREATE, exception.getMessage());
        }

    }

}
