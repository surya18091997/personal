package com.walmart.benefits.platform.core.engine.processors.event.disability;

import com.walmart.benefits.platform.core.engine.processors.event.EventProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.CoverageOption;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.RecordType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ConverterUtil.getUTCTimeAsString;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.ENROLLMENT_COMPLETE;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.Coverage;

@Slf4j
@Service
public class DisabilityEnrollmentCompleteEventProcessor implements EventProcessor {


    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Disability Enrollment Complete Processor started");
        Map<String, Object> variables = delegateExecution.getVariables();

        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);
        String isCoverageAvailable = (String) variables.get(IS_COVERAGE_AVAILABLE);
        Enrollment enrollment = (Enrollment) variables.get(ENROLLMENT);
        AssociateEligibilityOutput associateEligibilityOutput = (AssociateEligibilityOutput) variables.get(RULE_RESPONSE);


        AssociateBenefitsProfile associateBenefitsProfile = CommonUtils.getProfile(delegateExecution);
        Activity changeActivity = enrollment.getActivity();

        Coverage result = CommonUtils.getCoverage(associateEvent, isCoverageAvailable, variables);
        boolean isPlanEligible = RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent);

        variables.put(IS_PLAN_ELIGIBLE, isPlanEligible);
        variables.put(IS_COVERAGE_AVAILABLE, isCoverageAvailable);


        if (isCoverageAvailable.equals(TRUE)) {
            AssociateBenefit previousCoverage = result.coverage();
            AssociateBenefit updatedCoverage = updateDisabilityCoverage(
                    previousCoverage,
                    associateEvent,
                    associateEligibilityOutput,
                    enrollment);
            updatedCoverage.setChangeActivity(changeActivity);
            variables.put(UPDATE_COVERAGE,updatedCoverage );
        } else {
            List<AssociateBenefit> createdCoverages =createDisabilityCoverage(associateEvent,associateEligibilityOutput,enrollment,new AssociateBenefit());
            createdCoverages = createdCoverages.stream()
                    .map(coverage-> {
                        coverage.setChangeActivity(changeActivity);
                        return coverage;
                    }).toList();
            variables.put(ASSOCIATE_COVERAGE, createdCoverages);
        }

        //Update the plan status based on rule engine response
        if (!isPlanEligible) {
            variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.updateProfile(associateEvent, benefitsEntity));
        }

        delegateExecution.setVariables(variables);
        log.info("Disability Enrollment Complete Processor Completed");
    }


    public static AssociateBenefit updateDisabilityCoverage( AssociateBenefit coverage ,AssociateEvent associateEvent,  AssociateEligibilityOutput associateEligibilityOutput, Enrollment enrollment){
        Optional<String> planId = Optional.ofNullable(associateEvent.getPlanType().getPlanId());


        Optional<String> changeActivity = Optional.ofNullable(associateEligibilityOutput.getChangeActivity());
        changeActivity.ifPresent(activity -> coverage.setChangeActivity(Activity.valueOf(activity)));

        Optional<String> updatedStartDate = Optional.ofNullable(associateEligibilityOutput.getCoverageStartDate());
        updatedStartDate.ifPresent(coverage::setStartDate);
        Optional<String> updatedEndDate = Optional.ofNullable(associateEligibilityOutput.getCoverageEndDate());
        updatedEndDate.ifPresent(coverage::setEndDate);

        Optional<String> recordType = Optional.ofNullable(associateEligibilityOutput.getRecordType());
        recordType.ifPresentOrElse(rType->coverage.setRecordType(RecordType.valueOf(rType)),
                ()->coverage.setRecordType(RecordType.CURRENT));

        Optional<String> updatedTier = Optional.ofNullable(associateEligibilityOutput.getTier());
        updatedTier.ifPresent(tier->coverage.setTier(Tier.valueOf(tier)));

        Optional<String> updatedCoverageOption = Optional.ofNullable(associateEligibilityOutput.getCoverageOption());
        updatedCoverageOption.ifPresent(option->coverage.setCoverageOption(CoverageOption.valueOf(option)));

        Optional<PlanElection> electedPlan = Optional.empty();

        if(!Objects.isNull(enrollment) && !Objects.isNull(enrollment.getPlanElections()) && planId.isPresent()){
             electedPlan = enrollment.getPlanElections().stream().filter(planElection -> planElection.getPlanId().equalsIgnoreCase(planId.get())).findFirst();
        }

        electedPlan.ifPresent(plan->{
            coverage.setCoverageOption(plan.getCoverageOption());
            coverage.setTier(plan.getTier());
        });

        coverage.setLastModifiedAt(getUTCTimeAsString());
        coverage.setLastModifiedBy(SYSTEM_CORE_ENGINE);
        return coverage;
    }

    public static List<AssociateBenefit> createDisabilityCoverage(AssociateEvent associateEvent, AssociateEligibilityOutput associateEligibilityOutput,Enrollment enrollment, AssociateBenefit coverage){

        //Calling Update Method
        AssociateBenefit newCoverage = updateDisabilityCoverage(coverage,associateEvent,associateEligibilityOutput,enrollment);

        Optional<String> planId = Optional.ofNullable(associateEvent.getPlanType().getPlanId());
        Optional<String> planGroup = Optional.ofNullable(associateEvent.getPlanType().getPlanGroup());
        Optional<String> tier = Optional.ofNullable(associateEligibilityOutput.getTier());


        newCoverage.setAssociateId(associateEvent.getAssociateId());
        planId.ifPresent(newCoverage::setPlanId);
        planGroup.ifPresent(newCoverage::setPlanGroup);
        tier.ifPresent(tierString-> newCoverage.setTier(Tier.valueOf(tierString)));

        //Common Attributes
        newCoverage.setCreatedAt(getUTCTimeAsString());
        newCoverage.setCreatedBy(SYSTEM_CORE_ENGINE);

        //Explicit setting of Last Modified details
        newCoverage.setLastModifiedAt(null);
        newCoverage.setLastModifiedBy(null);

        //Extend this method to provide Deduction and Premium information's in the Coverages for other enrollments
        return List.of(newCoverage);
    }



    @Override
    public EventType getEventType() {
        return ENROLLMENT_COMPLETE;
    }

    @Override
    public String getPlanType() {
        return DISABILITY;
    }

}
