package com.walmart.benefits.platform.core.engine.utils;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ERROR_CODE;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ERROR_MESSAGE;

@Slf4j
public class ErrorUtil {

    private ErrorUtil() {}

    public static void setExceptionData(DelegateExecution delegateExecution, String errorCode, String errorMessage) {
        delegateExecution.setVariable(ERROR_CODE, errorCode);
        delegateExecution.setVariable(ERROR_MESSAGE, getErrorMessage(errorMessage));
        throw new BpmnError(errorCode, errorMessage);
    }

    private static String getErrorMessage(String errorMessage){
        if(errorMessage !=null && errorMessage.length() > 4000)
            return errorMessage.substring(0,2500);
        return errorMessage;

    }

}
