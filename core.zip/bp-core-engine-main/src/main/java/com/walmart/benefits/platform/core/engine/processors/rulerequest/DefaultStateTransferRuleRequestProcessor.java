package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;

@Slf4j
@Service
public class DefaultStateTransferRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public DefaultStateTransferRuleRequestProcessor() {
        super(STATE_TRANSFER);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("DefaultStateTransferRuleRequestProcessor: Default processing for STATE_TRANSFER event");
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() {
        return null;
    }
}