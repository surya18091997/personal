package com.walmart.benefits.platform.core.engine.configs;

import com.walmart.benefits.platform.core.engine.exceptions.EventTypeConfigurationException;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@Component
@ConfigurationProperties(prefix = "event-config")
public class EventTypeConfig {

    private Map<String, EventDetails> eventType;

    public boolean shouldExecuteSubPlanTypeWorkflow(String eventTypeKey) {
        EventDetails eventDetails = eventType.get(eventTypeKey);
        return eventDetails != null && eventDetails.isExecuteSubPlanTypeWorkflow();
    }

    public boolean shouldExecuteAsBatch(String eventTypeKey) {
        EventDetails eventDetails = eventType.get(eventTypeKey);
        return eventDetails != null && eventDetails.isExecuteAsBatch();
    }

    @Getter
    @Setter
    public static class EventDetails {
        private boolean executeSubPlanTypeWorkflow;
        private boolean executeAsBatch;
        private List<String> planTypes;
    }

    @PostConstruct
    public void validateEventType() {
        if (eventType == null || eventType.isEmpty()) {
            throw new EventTypeConfigurationException("The 'eventType' property is not defined in the plan-to-event-mapping.yaml");
        }
    }
}