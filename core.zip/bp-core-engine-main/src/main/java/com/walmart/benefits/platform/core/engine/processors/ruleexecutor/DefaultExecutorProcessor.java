package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory.RuleCategoryProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.PLAN_TYPE_STR;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.generateKey;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.getBenefitsEntity;

/**
 * @author Jedidiah Jeyaraj
 * @date 20/03/25
 */

@Slf4j
@Service
@AllArgsConstructor
public class DefaultExecutorProcessor implements RuleExecutorProcessor {

    private final RuleMetaDataConfig ruleMetaDataConfig;
    private List<RuleCategoryProcessor> ruleCategoryProcessors;

    @Override
    public void process(DelegateExecution delegateExecution) {
        log.info("Default Rule Executor Processor");

        Map<String, Object> variables = delegateExecution.getVariables();
        AssociateEvent associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
        ConnectorResponse connectorResponse = (ConnectorResponse) delegateExecution.getVariable(CONNECTOR_RESPONSE);
        String planType = (String) delegateExecution.getVariable(PLAN_TYPE);

        Map<String, List<RuleCategory>> planTypeRuleCategories = ruleMetaDataConfig.getEventType().get(generateKey(associateEvent.getEventType()));

        if (!associateEvent.getPlanType().equals(PlanType.NONE)) {
            planTypeRuleCategories = planTypeRuleCategories.entrySet().stream().filter(entry ->
                            entry.getKey().equals(associateEvent.getPlanType().toString()))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, HashMap::new));
        }

        BenefitsEntity benefitsEntity = getBenefitsEntity(connectorResponse, associateEvent);
        delegateExecution.setVariable(BENEFITS_ENTITY, benefitsEntity);

        planTypeRuleCategories.forEach((subPlanType, ruleCategoryList) -> {
            if (StringUtils.containsIgnoreCase(subPlanType, planType)) {
                ruleCategoryList.forEach(ruleCategory -> ruleCategoryProcessors.forEach(ruleCategoryProcessor -> {
                    if (ruleCategoryProcessor.getRuleCategory().equals(ruleCategory)) {
                        delegateExecution.setVariable(PLAN_TYPE_STR, subPlanType);
                        ruleCategoryProcessor.process(delegateExecution);
                    }
                }));
            }
        });
        log.info("Default Rule Executor Processor completed");
    }

    @Override
    public String getPlanType() {
        return null;
    }
}
