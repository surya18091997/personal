package com.walmart.benefits.platform.core.engine.processors.event.retirement;

import com.walmart.benefits.platform.core.engine.processors.event.AbstractEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.EventUtils.associateCoverage;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class RetirementNewHireEventProcessor extends AbstractEventProcessor {


    public RetirementNewHireEventProcessor() {
        super(NEW_HIRE);
    }

    @Override
    public String getPlanType() {
        return RETIREMENT;
    }

    @Override
    public void process(DelegateExecution delegateExecution){
        log.info("401k event processor started");
        Map<String, Object> variables = delegateExecution.getVariables();
        BenefitsEntity benefitsEntity = (BenefitsEntity) variables.get(BENEFITS_ENTITY);

        variables.put(ASSOCIATE_BENEFITS_PROFILE, EventUtils.associateProfile(benefitsEntity));
        variables.put(ASSOCIATE_COVERAGE, associateCoverage(benefitsEntity));
        delegateExecution.setVariables(variables);
        log.info("401k event processor ended");
    }

}
