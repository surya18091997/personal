package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.processors.event.EventProcessorFactory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@AllArgsConstructor
@Service("EventProcessorService")
public class EventProcessorService implements JavaDelegate {

    private final EventProcessorFactory eventProcessorFactory;

    /**
     * Prepare Enrollment records
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            String planType = (String) delegateExecution.getVariable(PLAN_TYPE);
            var processor = eventProcessorFactory.getProcessor(planType, associateEvent.getEventType());
            processor.process(delegateExecution);
        }catch (Exception exception){
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, CORE_PROCESSOR_SERVICE, exception.getMessage());
        }
    }
}
