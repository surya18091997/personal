package com.walmart.benefits.platform.core.engine.configs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

@Setter
@Getter
@Component
@PropertySource("classpath:rate-event-plan-config.yaml")
@ConfigurationProperties(prefix = "plan-config")
public class RateEventPlanConfig {
    private String basePlan;
    private List<String> regularPlan;
    private List<String> catchupPlan;
    private Double catchupLimit;
    private Double regularLimit;
    private int catchupEligibleAge;

    @PostConstruct
    public void validatePlanConfig() {
        if(basePlan == null || regularPlan == null || catchupPlan == null || catchupLimit == null || regularLimit == null) {
            throw new IllegalArgumentException("Invalid Plan Config");
        }
    }
}
