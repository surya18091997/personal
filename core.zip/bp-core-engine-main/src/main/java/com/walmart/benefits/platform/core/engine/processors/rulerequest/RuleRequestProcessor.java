package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;

public interface RuleRequestProcessor {

    void process(DelegateExecution delegateExecution);

    EventType getEventType();

    String getPlanType();
}
