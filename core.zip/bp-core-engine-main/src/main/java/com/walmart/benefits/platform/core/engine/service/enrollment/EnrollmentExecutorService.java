package com.walmart.benefits.platform.core.engine.service.enrollment;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;

@Slf4j
@AllArgsConstructor
@Service("EnrollmentExecutorService")
public class EnrollmentExecutorService implements JavaDelegate {

    private final RuntimeService runtimeService;

    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        Map<String, Object> variables = delegateExecution.getVariables();
        var associateEvents = (List<AssociateEvent>) variables.get(ASSOCIATE_EVENTS);
        associateEvents.forEach(event -> {
            variables.put(PLAN_TYPE, event.getPlanType().getPlanGroup());
            variables.put(ASSOCIATE_EVENT, event);
            runtimeService.startProcessInstanceByKey(ApplicationConstants.WORKFLOW_ENROLLMENT_PROCESS, variables);
        });
    }
}
