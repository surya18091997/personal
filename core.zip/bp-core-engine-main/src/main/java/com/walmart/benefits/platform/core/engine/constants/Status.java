package com.walmart.benefits.platform.core.engine.constants;

public enum Status {
   RECEIVED,PROCESSED, FAILED, QUEUED
}
