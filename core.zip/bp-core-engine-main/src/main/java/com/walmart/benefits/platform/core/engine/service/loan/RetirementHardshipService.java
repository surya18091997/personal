package com.walmart.benefits.platform.core.engine.service.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;

@Slf4j
@AllArgsConstructor
@Service("RetirementHardshipService")
public class RetirementHardshipService implements JavaDelegate {
    private EncryptionUtil encryptionUtil;

    private ObjectMapper objectMapper;
    /**
     * Process the retirement hardship loan service
     *
     * @param delegateExecution
     * @throws Exception
     */
    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            var associateEvent = (AssociateEvent) variables.get(ASSOCIATE_EVENT);
            log.info("Retirement Hardship Service Started.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
            HardshipModel hardshipModel = objectMapper.convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class);
            //get the profile service
            AssociateBenefitsProfile existing_associate_profile=(AssociateBenefitsProfile) delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE);
            EventUtils.updateAssociateProfile(existing_associate_profile,associateEvent,hardshipModel);


            List<AssociateBenefit> coverages = (List<AssociateBenefit>) variables.get(COVERAGE_RESPONSE_LIST);
            EventUtils.updateCoverageList(coverages,hardshipModel);

            AssociateBenefit hardship_coverage_record= EventUtils.createCoverage(associateEvent,hardshipModel);
            delegateExecution.setVariable(UPDATE_COVERAGE, hardship_coverage_record);
//            coverages.add(hardship_coverage_record);
            delegateExecution.setVariable(COVERAGE_RESPONSE_LIST, coverages);
            delegateExecution.setVariable(ASSOCIATE_BENEFITS_PROFILE, existing_associate_profile);
            log.info("Retirement Hardship Service completed.. Associate Id {}", encryptionUtil.encrypt(associateEvent.getAssociateId()));
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            setExceptionData(delegateExecution, RETIREMENT_HARDSHIP_SERVICE, exception.getMessage());
        }
    }

}