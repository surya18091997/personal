package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

@Slf4j
@Service
public class DefaultNewHireRuleRequestProcessor extends AbstractRuleRequestProcessor {

    public DefaultNewHireRuleRequestProcessor() {
        super(NEW_HIRE);
    }

    @Override
    public void process(DelegateExecution delegateExecution) {
        String planTypeStr = (String) delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR);
        log.info("DefaultNewHireRuleRequestProcessor: Default processing for NEW_HIRE event :: {}",planTypeStr);
        //Default Logic goes here
        log.info("DefaultNewHireRuleRequestProcessor: Completed :: {}",planTypeStr);
        super.process(delegateExecution);
    }

    @Override
    public String getPlanType() {
        return null;
    }
}