package com.walmart.benefits.platform.core.engine.configs;

import com.walmart.benefits.rules.benefitsrulessdk.executor.RulesExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class RuleEngineConfig {

    @Bean
    public RulesExecutor getInstance() {
        try {
            return RulesExecutor.getInstance();
        }catch (Exception exception) {
            log.error("Rule Executor", exception);
            throw new RuntimeException("Rule Executor", exception);
        }
    }
}
