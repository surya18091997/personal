package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.constants.WorkflowConstants;
import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefits.platform.core.engine.service.common.AsyncProcessorService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.RuntimeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AsyncProcessorServiceTest {

    @Mock
    private RuntimeService runtimeService;

    @Mock
    private EncryptionUtil encryptionUtil;

    @InjectMocks
    private AsyncProcessorService asyncProcessorService;

    @Test
    void triggerNewHireWorkFlow() throws EventNotFoundException {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("123456789");
        associateEvent.setEventType(EventType.NEW_HIRE);
        associateEvents.add(associateEvent);
        var variables = new HashMap<String, Object>();
        variables.put("associateEvent", associateEvents.get(0));
        asyncProcessorService.processAsync(associateEvents);
        verify(runtimeService).startProcessInstanceByKey(WorkflowConstants.WORKFLOW_SELECTOR, variables);
    }

    @Test
    void triggerWorkflowForInvalidEvent() {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("123456789");
        associateEvent.setEventType(EventType.NONE);
        associateEvents.add(associateEvent);
        assertThrows(EventNotFoundException.class, () -> asyncProcessorService.processAsync(associateEvents));
    }

}