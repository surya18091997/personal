package com.walmart.benefits.platform.core.engine.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CoreEngineExceptionTest {
@Test
void createsExceptionWithMessageAndCause() {
    Exception cause = new Exception("Root cause");
    CoreEngineException exception = new CoreEngineException("Core engine error", cause);

    assertEquals("Core engine error", exception.getMessage());
    assertEquals(cause, exception.getCause());
}

@Test
void createsExceptionWithNullCause() {
    CoreEngineException exception = new CoreEngineException("Core engine error", null);

    assertEquals("Core engine error", exception.getMessage());
    assertNull(exception.getCause());
}

@Test
void createsExceptionWithEmptyMessage() {
    Exception cause = new Exception("Root cause");
    CoreEngineException exception = new CoreEngineException("", cause);

    assertEquals("", exception.getMessage());
    assertEquals(cause, exception.getCause());
}
}