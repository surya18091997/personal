package com.walmart.benefits.platform.core.engine.processors.ruleresponse.dental;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;
import static com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType.RETIREMENT_401K_REGULAR_US;
import static org.mockito.Mockito.when;

/**
 * @author Jedidiah Jeyaraj
 * @date 20/03/25
 */
public class DentalNewHireRuleResponseProcessorTest {
    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private EncryptionUtil encryptionUtil;

    @InjectMocks
    private DentalNewHireRuleResponseProcessor processor;

    private static BenefitsEntity getBenefitsEntity() {
        BenefitsEntity benefitsEntity = new BenefitsEntity();

        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        Employment employment = new Employment();
        employment.setHireDate("01/01/2022");
        associateInfo.setEmployment(employment);
        interDomainInfo.setAssociateInfo(associateInfo);

        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();

        benefitsEntity.setInterDomainInfo(interDomainInfo);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);
        return benefitsEntity;
    }

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testEventType() {
        Assertions.assertEquals(NEW_HIRE, processor.getEventType());
    }

    @Test
    void testPlanType() {
        Assertions.assertEquals(DENTAL, processor.getPlanType());
    }

    @Test
    void testProcessWithNullDelegateExecution() {
        Assert.assertThrows(NullPointerException.class, () -> processor.process(null));
    }

    @Test
    void testProcessWithNullRuleResponse() {
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void testProcessWithNullBenefitsEntity() {
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(new AssociateEligibilityOutput());
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void testProcessWithNullPlanTypeStr() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(ruleResponse);
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(new BenefitsEntity());
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void createBaseRecordForDentalPlan() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        ruleResponse.setAssociateEligibilityIndicator(true);
        ruleResponse.setIsEligibilityUpdated(true);
        ruleResponse.setAssociateEligibilityDate("2024-08-09");

        BenefitsEntity benefitsEntity = getBenefitsEntity();

        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(ruleResponse);
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(RETIREMENT_401K_REGULAR_US.name());
        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        processor.process(delegateExecution);
        benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY);

        Assertions.assertNotNull(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans().get(0).getEligibleDate());

    }

    @Test
    void createNoCoverageRecordForDentalPlan() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        ruleResponse.setAssociateEligibilityIndicator(true);
        ruleResponse.setIsCoverageUpdated(true);
        ruleResponse.setCoverageStartDate("2024-08-09");

        BenefitsEntity benefitsEntity = getBenefitsEntity();

        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(ruleResponse);
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(RETIREMENT_401K_REGULAR_US.name());
        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        processor.process(delegateExecution);
        benefitsEntity = (BenefitsEntity) delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY);

        Assertions.assertEquals("2024-08-09",
                benefitsEntity.getIntraDomainInfo().getAssociateBenefit().getStartDate());

    }

}
