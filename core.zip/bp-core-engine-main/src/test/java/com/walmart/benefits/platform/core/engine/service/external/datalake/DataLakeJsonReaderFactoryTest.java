package com.walmart.benefits.platform.core.engine.service.external.datalake;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DataLakeJsonReaderFactoryTest {

    private DataLakeJsonReaderFactory factory;
    private DataLakeJsonReader mockReader1;
    private DataLakeJsonReader mockReader2;

    @BeforeEach
    void setUp() {
        mockReader1 = mock(DataLakeJsonReader.class);
        mockReader2 = mock(DataLakeJsonReader.class);

        when(mockReader1.getEventType()).thenReturn(EventType.RE_HIRE);
        when(mockReader2.getEventType()).thenReturn(EventType.NEW_HIRE);

        factory = new DataLakeJsonReaderFactory(List.of(mockReader1, mockReader2));
    }

    @Test
    void testGetDataLakeJsonReader_ValidEventType() {
        DataLakeJsonReader result = factory.getDataLakeJsonReader(EventType.RE_HIRE);
        assertNotNull(result);
        assertEquals(mockReader1, result);
    }

    @Test
    void testGetDataLakeJsonReader_AnotherValidEventType() {
        DataLakeJsonReader result = factory.getDataLakeJsonReader(EventType.NEW_HIRE);
        assertNotNull(result);
        assertEquals(mockReader2, result);
    }

    @Test
    void testGetDataLakeJsonReader_InvalidEventType() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                factory.getDataLakeJsonReader(EventType.TERMINATION));
        assertEquals("No DataLakeJsonReader found for event type: TERMINATION", exception.getMessage());
    }

    @Test
    void testGetDataLakeJsonReader_NullEventType() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                factory.getDataLakeJsonReader(null));
        assertEquals("No DataLakeJsonReader found for event type: null", exception.getMessage());
    }
}