package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.utils.*;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.ErrorUtil.setExceptionData;
import static com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil.getRetryCount;
import static com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil.getTransactionLogEvent;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class CreateTransactionLogAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    private CreateTransactionLogAPIService createTransactionLogAPIService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        createTransactionLogAPIService = new CreateTransactionLogAPIService(restTemplate, httpUtils, encryptionUtil);
    }

    @Test
    void testExecute_SuccessfulResponse() throws Exception {
        // Mocking variables and dependencies
        Map<String, Object> variables = mock(Map.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        ResponseEntity<String> responseEntity = mock(ResponseEntity.class);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(variables.get(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://mock-url");
        when(httpUtils.getTransactionLogServiceAppName()).thenReturn("MockApp");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(mock(HttpEntity.class));
        when(restTemplate.exchange(eq("http://mock-url"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(responseEntity);
        when(responseEntity.getStatusCode()).thenReturn(mock(org.springframework.http.HttpStatus.class));

        try (MockedStatic<ProcessEngineUtil> mockedProcessEngineUtil = mockStatic(ProcessEngineUtil.class);
             MockedStatic<TransactionLogUtil> mockedTransactionLogUtil = mockStatic(TransactionLogUtil.class)) {

            mockedProcessEngineUtil.when(() -> getRetryCount(delegateExecution)).thenReturn(0);
            mockedTransactionLogUtil.when(() -> getTransactionLogEvent(associateEvent)).thenReturn(mock(TransactionLog.class));

            // Execute method
            createTransactionLogAPIService.execute(delegateExecution);

            // Verify interactions
            verify(delegateExecution, times(1)).getVariables();
            verify(httpUtils, times(1)).getTransactionLogUrl();
            verify(httpUtils, times(1)).getHttpEntity(any(), any());
            verify(restTemplate, times(1))
                    .exchange(eq("http://mock-url"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class));
        }
    }

    @Test
    void testExecute_HttpServerErrorException() throws Exception {
        // Mocking variables and dependencies
        Map<String, Object> variables = mock(Map.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        HttpServerErrorException exception = mock(HttpServerErrorException.class);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(variables.get(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://mock-url");
        when(httpUtils.getTransactionLogServiceAppName()).thenReturn("MockApp");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(mock(HttpEntity.class));
        when(restTemplate.exchange(eq("http://mock-url"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(exception);

        try (MockedStatic<ProcessEngineUtil> mockedProcessEngineUtil = mockStatic(ProcessEngineUtil.class);
            MockedStatic<TransactionLogUtil> transactionLogUtilMockedStatic = mockStatic(TransactionLogUtil.class)) {
            mockedProcessEngineUtil.when(() -> getRetryCount(delegateExecution)).thenReturn(1);

            // Execute method
            createTransactionLogAPIService.execute(delegateExecution);

            // Verify interactions
            verify(httpUtils, times(1))
                    .handleError(delegateExecution, exception, 1, ASSOCIATE_TRANSACTION_LOG_SERVICE_CREATE_SERVER_ERROR);
        }
    }

    @Test
    void testExecute_GenericException() throws Exception {
        // Mocking variables and dependencies
        Map<String, Object> variables = mock(Map.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(variables.get(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://mock-url");
        when(httpUtils.getTransactionLogServiceAppName()).thenReturn("MockApp");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(mock(HttpEntity.class));
        when(restTemplate.exchange(eq("http://mock-url"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException());

        try (MockedStatic<ErrorUtil> mockedErrorUtil = mockStatic(ErrorUtil.class);
             MockedStatic<ProcessEngineUtil> mockedProcessEngineUtil = mockStatic(ProcessEngineUtil.class);
             MockedStatic<TransactionLogUtil> transactionLogUtilMockedStatic = mockStatic(TransactionLogUtil.class)) {
            // Execute method
            createTransactionLogAPIService.execute(delegateExecution);
            mockedErrorUtil.verify(() -> setExceptionData(delegateExecution, ASSOCIATE_TRANSACTION_LOG_SERVICE_CREATE, null));
        }
    }

    @Test
    void testGetTransactionLogEvent_WithValidInputs() {
        // Arrange
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        associateEvent.setPlanType(planType);
        associateEvent.setEventType(EventType.RATE_CHANGE);

        String transactionLogComment = "Test Comment";
        String planTypeOverride = "Override Plan Group";

        // Act
        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogEvent(associateEvent, transactionLogComment, planTypeOverride);

        // Assert
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), transactionLog.getPlanId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals("Test Comment", transactionLog.getComment());
        assertEquals(ApplicationConstants.SYSTEM_CORE_ENGINE, transactionLog.getCreatedBy());
    }

    @Test
    void testGetTransactionLogEvent_WithEmptyPlanGroup() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        associateEvent.setEventType(EventType.RATE_CHANGE);
        String transactionLogComment = "Test Comment";
        String planTypeOverride = "Override Plan Group";
        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogEvent(associateEvent, transactionLogComment, planTypeOverride);
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), transactionLog.getPlanId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals("Test Comment", transactionLog.getComment());
        assertEquals(ApplicationConstants.SYSTEM_CORE_ENGINE, transactionLog.getCreatedBy());
    }

}
