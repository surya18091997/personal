package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedStatic;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class GetProfileAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private GetProfileAPIService service;

    @Mock
    private AssociateEvent associateEvent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(associateEvent.getAssociateId()).thenReturn("12345");
    }

    @Test
    void testExecute_SuccessfulResponse() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(httpUtils.getProfileUrl()).thenReturn("http://test.com/profile/");
            when(httpUtils.getHttpEntity(httpUtils.getAssociateProfileServiceAppName())).thenReturn(null);
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            ResponseEntity<AssociateBenefitsProfile> responseEntity = new ResponseEntity<>(new AssociateBenefitsProfile(), HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/profile/12345", HttpMethod.GET, null, AssociateBenefitsProfile.class))
                    .thenReturn(responseEntity);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(delegateExecution, times(1)).setVariable(GET_ASSOCIATE_PROFILE_RESPONSE, responseEntity.getBody());
            verify(delegateExecution, times(1)).setVariable(IS_PROFILE_AVAILABLE, TRUE);
        }
    }

    @Test
    void testExecute_ClientErrorNotFound() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(httpUtils.getProfileUrl()).thenReturn("http://test.com/profile/");
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            // Mock 404 response
            HttpClientErrorException notFoundException = new HttpClientErrorException(HttpStatus.NOT_FOUND);
            when(restTemplate.exchange("http://test.com/profile/12345", HttpMethod.GET, null, AssociateBenefitsProfile.class))
                    .thenThrow(notFoundException);

            // Execute
            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "associate not found"
            );
            assertTrue(thrown.getMessage().contains("404 NOT_FOUND"));
        }
    }

    @Test
    void testExecute_ServerErrorException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(httpUtils.getProfileUrl()).thenReturn("http://test.com/profile/");
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(1);

            // Mock 500 response
            HttpServerErrorException serverErrorException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange("http://test.com/profile/12345", HttpMethod.GET, null, AssociateBenefitsProfile.class))
                    .thenThrow(serverErrorException);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(httpUtils, times(1)).handleError(delegateExecution, serverErrorException, 1, ASSOCIATE_PROFILE_SERVICE_GET_SERVER_ERROR);
        }
    }

    @Test
    void testExecute_GeneralException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenThrow(new BpmnError("Unexpected error","Unexpected error"));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Unexpected error"));
        }
    }
}
