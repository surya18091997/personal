package com.walmart.benefits.platform.core.engine.service.hardship;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.service.loan.RetirementHardshipService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class RetirementHardshipServiceTest {

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private RetirementHardshipService retirementHardshipService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void execute_updatesVariablesSuccessfully() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("hardshipAmount", 2000))
                .build();
        HardshipModel hardshipModel = new HardshipModel();
        AssociateBenefitsProfile profile = new AssociateBenefitsProfile();
        List<AssociateBenefit> coverages = List.of(new AssociateBenefit());
        AssociateBenefit hardshipCoverage = new AssociateBenefit();

        when(delegateExecution.getVariables()).thenReturn(Map.of(
                ASSOCIATE_EVENT, associateEvent,
                COVERAGE_RESPONSE_LIST, coverages
        ));
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(profile);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class)).thenReturn(hardshipModel);

        try (MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            mockedEventUtils.when(() -> EventUtils.createCoverage(associateEvent, hardshipModel)).thenReturn(hardshipCoverage);
            // Removed incorrect return stubs for void methods

            retirementHardshipService.execute(delegateExecution);

            // Verify void methods were called
            mockedEventUtils.verify(() -> EventUtils.updateAssociateProfile(profile, associateEvent, hardshipModel));
            mockedEventUtils.verify(() -> EventUtils.updateCoverageList(coverages, hardshipModel));

            verify(delegateExecution).setVariable(UPDATE_COVERAGE, hardshipCoverage);
            verify(delegateExecution).setVariable(COVERAGE_RESPONSE_LIST, coverages);
            verify(delegateExecution).setVariable(ASSOCIATE_BENEFITS_PROFILE, profile);
            verify(encryptionUtil, times(2)).encrypt("12345");
            verify(objectMapper).convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class);
        }
    }

    @Test
    void execute_withNullAssociateEvent_throwsException() {
        doThrow(new NullPointerException("associateEvent is null")).when(delegateExecution).getVariables();
        assertThrows(BpmnError.class, () -> {
            retirementHardshipService.execute(delegateExecution);
        });
    }

    @Test
    void execute_withInvalidHardshipModelConversion_throwsException() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("hardshipAmount", 2000))
                .build();

        when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class)).thenThrow(new RuntimeException("Conversion failed"));

        assertThrows(RuntimeException.class, () -> {
            retirementHardshipService.execute(delegateExecution);
        });
    }

}