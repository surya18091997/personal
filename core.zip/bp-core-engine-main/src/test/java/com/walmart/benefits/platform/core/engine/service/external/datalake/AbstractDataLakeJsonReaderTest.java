package com.walmart.benefits.platform.core.engine.service.external.datalake;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AbstractDataLakeJsonReaderTest {

    private AbstractDataLakeJsonReader dataLakeJsonReader;

    @BeforeEach
    void setUp() {
        dataLakeJsonReader = new AbstractDataLakeJsonReader(EventType.RE_HIRE) {};
        ReflectionTestUtils.setField(dataLakeJsonReader, "unloadedDataLakePath", "/mock/path");
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.RE_HIRE, dataLakeJsonReader.getEventType());
    }

    @Test
    void testGetUnloadedDataLakePath() {
        assertEquals("/mock/path", dataLakeJsonReader.getUnloadedDataLakePath());
    }

    @Test
    void testReadDataLakeJsonFiles() throws IOException {
        assertEquals("", dataLakeJsonReader.readDataLakeJsonFiles());
    }
}