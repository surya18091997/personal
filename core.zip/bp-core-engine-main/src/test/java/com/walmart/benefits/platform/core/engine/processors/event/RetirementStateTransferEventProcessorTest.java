package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementStateTransferEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RetirementStateTransferEventProcessorTest {

    @InjectMocks
    private RetirementStateTransferEventProcessor processor;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    private final AssociateBenefit associateBenefit = new AssociateBenefit();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.STATE_TRANSFER, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        assertEquals(RETIREMENT, processor.getPlanType());
    }

    @Test
    void testProcessWithProfileAvailableAndCoverageUpdated() {
        try(MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(IS_COVERAGE_UPDATED, true);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(EventUtils.updateProfile(associateEvent, benefitsEntity)).thenReturn(associateBenefitsProfile);
            when(EventUtils.updateCoverageFromRules(any(), any())).thenReturn(associateBenefit);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariables(variables);
            assertEquals(associateBenefitsProfile, variables.get(ASSOCIATE_BENEFITS_PROFILE));
            assertNotNull(variables.get(UPDATE_COVERAGE));
        }
    }

    @Test
    void testProcessWithCoverageNotAvailable() {
        try(MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(IS_COVERAGE_AVAILABLE, FALSE);
            variables.put(IS_COVERAGE_UPDATED, true);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(EventUtils.updateProfile(associateEvent, benefitsEntity)).thenReturn(associateBenefitsProfile);
            when(EventUtils.updateCoverageFromRules(any(), any())).thenReturn(associateBenefit);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariables(variables);
            assertEquals(associateBenefitsProfile, variables.get(ASSOCIATE_BENEFITS_PROFILE));
            assertNotNull(variables.get(ASSOCIATE_COVERAGE));
        }
    }

    @Test
    void testProcessWithCoverageNotUpdated() {
        try(MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(IS_PROFILE_AVAILABLE, FALSE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(IS_COVERAGE_UPDATED, false);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(EventUtils.updateProfile(associateEvent, benefitsEntity)).thenReturn(associateBenefitsProfile);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariables(variables);
            assertEquals(associateBenefitsProfile, variables.get(ASSOCIATE_BENEFITS_PROFILE));
            assertNull(variables.get(UPDATE_COVERAGE));
            assertNull(variables.get(ASSOCIATE_COVERAGE));
        }
    }
}
