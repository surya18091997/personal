package com.walmart.benefits.platform.core.engine.entity;

import com.walmart.benefits.platform.core.engine.constants.Status;
import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class EventStatusTest {

    @Test
    public void testEquals() {
        EventStatus eventStatus1 = EventStatus.builder()
               .id(UUID.randomUUID())
               .event(new Event())
               .subPlanType("sub-plan-type")
               .status(Status.RECEIVED)
               .errorCode("error-code")
               .errorMessage("error-message")
               .createdAt("created-at")
               .createdBy("created-by")
               .lastModifiedAt("last-modified-at")
               .lastModifiedBy("last-modified-by")
               .build();

        EventStatus eventStatus2 = EventStatus.builder()
               .id(eventStatus1.getId())
               .event(eventStatus1.getEvent())
               .subPlanType(eventStatus1.getSubPlanType())
               .status(eventStatus1.getStatus())
               .errorCode(eventStatus1.getErrorCode())
               .errorMessage(eventStatus1.getErrorMessage())
               .createdAt(eventStatus1.getCreatedAt())
               .createdBy(eventStatus1.getCreatedBy())
               .lastModifiedAt(eventStatus1.getLastModifiedAt())
               .lastModifiedBy(eventStatus1.getLastModifiedBy())
               .build();

        assertEquals(eventStatus1, eventStatus2);

        eventStatus2.setId(UUID.randomUUID());
        assertNotEquals(eventStatus1, eventStatus2);

        eventStatus2.setId(eventStatus1.getId());
        eventStatus2.setEvent(new Event());
        assertNotEquals(eventStatus1, eventStatus2);

        eventStatus2.setEvent(eventStatus1.getEvent());
        eventStatus2.setSubPlanType("different-sub-plan-type");
        assertNotEquals(eventStatus1, eventStatus2);

        // test other fields...
    }

    @Test
    public void testHashCode() {
        EventStatus eventStatus1 = EventStatus.builder()
               .id(UUID.randomUUID())
               .event(new Event())
               .subPlanType("sub-plan-type")
               .status(Status.RECEIVED)
               .errorCode("error-code")
               .errorMessage("error-message")
               .createdAt("created-at")
               .createdBy("created-by")
               .lastModifiedAt("last-modified-at")
               .lastModifiedBy("last-modified-by")
               .build();

        EventStatus eventStatus2 = EventStatus.builder()
               .id(eventStatus1.getId())
               .event(eventStatus1.getEvent())
               .subPlanType(eventStatus1.getSubPlanType())
               .status(eventStatus1.getStatus())
               .errorCode(eventStatus1.getErrorCode())
               .errorMessage(eventStatus1.getErrorMessage())
               .createdAt(eventStatus1.getCreatedAt())
               .createdBy(eventStatus1.getCreatedBy())
               .lastModifiedAt(eventStatus1.getLastModifiedAt())
               .lastModifiedBy(eventStatus1.getLastModifiedBy())
               .build();

        assertEquals(eventStatus1.hashCode(), eventStatus2.hashCode());

        eventStatus2.setId(UUID.randomUUID());
        assertNotEquals(eventStatus1.hashCode(), eventStatus2.hashCode());

        eventStatus2.setId(eventStatus1.getId());
        eventStatus2.setEvent(new Event());
        assertNotEquals(eventStatus1.hashCode(), eventStatus2.hashCode());

        eventStatus2.setEvent(eventStatus1.getEvent());
        eventStatus2.setSubPlanType("different-sub-plan-type");
        assertNotEquals(eventStatus1.hashCode(), eventStatus2.hashCode());

        // test other fields...
    }
}
