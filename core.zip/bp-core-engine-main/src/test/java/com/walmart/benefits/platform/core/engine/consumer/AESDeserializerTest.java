package com.walmart.benefits.platform.core.engine.consumer;

import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.AES_SECRET_KEY;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AESDeserializerTest {

    private AESDeserializer<Object> aesDeserializer;

    @Mock
    private JsonDeserializer<Object> jsonDeserializer;

    @BeforeEach
    void setUp() {
        aesDeserializer = new AESDeserializer<>();
    }

    @Test
    void shouldThrowExceptionWhenSecretKeyIsNull() {
        Map<String, Object> configs = new HashMap<>();
        assertThrows(SerializationException.class, () -> aesDeserializer.configure(configs, false));
    }

    @Test
    void shouldNotThrowExceptionWhenSecretKeyIsNotNull() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AES_SECRET_KEY, "testKey");

        assertDoesNotThrow(() -> aesDeserializer.configure(configs, false));
    }
}