package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_EVENT;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.PATCH_UPDATE_COVERAGE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UpdateCoverageTargetedPatchServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private UpdateCoverageTargetedPatchService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Common mocks needed to prevent NPEs
        when(encryptionUtil.encrypt(anyString())).thenReturn("encrypted-value");

        // Mock app name methods to avoid issues with matchers
        when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("associate-benefit-service");
        when(httpUtils.getTransactionLogServiceAppName()).thenReturn("transaction-log-service");
    }

    @Test
    void executeSuccessfullyUpdatesCoverageAndLogsTransaction() {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            associateEvent.setEventType(EventType.LOAN);
            associateEvent.setPlanType(PlanType.RETIREMENT_401K_LOAN_GENERAL_US);
            AssociateBenefit patchUpdateCoverage = new AssociateBenefit();
            patchUpdateCoverage.setPlanId("retirement_loan_general_us");
            when(delegateExecution.getVariables()).thenReturn(Map.of(
                    ASSOCIATE_EVENT, associateEvent,
                    PATCH_UPDATE_COVERAGE, patchUpdateCoverage
            ));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(httpUtils.getCoverageUpdateUrl()).thenReturn("http://test.com/coverage/update");
            when(httpUtils.getHttpEntity(eq(patchUpdateCoverage), anyString())).thenReturn(null);
            ResponseEntity<String> coverageResponse = new ResponseEntity<>("Success", HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/coverage/update", HttpMethod.PATCH, null, String.class))
                    .thenReturn(coverageResponse);

            when(httpUtils.getTransactionLogUrl()).thenReturn("http://test.com/transaction/log");
            when(httpUtils.getHttpEntity(any(), anyString())).thenReturn(null);
            ResponseEntity<String> transactionLogResponse = new ResponseEntity<>("Logged", HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class))
                    .thenReturn(transactionLogResponse);

            assertDoesNotThrow(() -> service.execute(delegateExecution));

            verify(restTemplate, times(1)).exchange("http://test.com/coverage/update", HttpMethod.PATCH, null, String.class);
            verify(restTemplate, times(1)).exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class);
        }
    }

    @Test
    void executeThrowsErrorWhenCoverageUpdateFails() {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class);
             MockedStatic<TransactionLogUtil> transactionLogUtilMockedStatic = mockStatic(TransactionLogUtil.class)) {
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            AssociateBenefit patchUpdateCoverage = new AssociateBenefit();
            associateEvent.setPlanType(PlanType.RETIREMENT_401K_LOAN_GENERAL_US);
            when(delegateExecution.getVariables()).thenReturn(Map.of(
                    ASSOCIATE_EVENT, associateEvent,
                    PATCH_UPDATE_COVERAGE, patchUpdateCoverage
            ));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(httpUtils.getCoverageUpdateUrl()).thenReturn("http://test.com/coverage/update");
            when(httpUtils.getHttpEntity(eq(patchUpdateCoverage), anyString())).thenReturn(null);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.PATCH), any(), eq(String.class)))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Service unavailable"));

            assertDoesNotThrow(() -> service.execute(delegateExecution));
        }
    }

    @Test
    void executeHandlesNullAssociateEventGracefully() {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            when(delegateExecution.getVariables()).thenReturn(Map.of(
                    PATCH_UPDATE_COVERAGE, new AssociateBenefit()
            ));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            assertThrows(NullPointerException.class, () -> service.execute(delegateExecution));
        }
    }

}