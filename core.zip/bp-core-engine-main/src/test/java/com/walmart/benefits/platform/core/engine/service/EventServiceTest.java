package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.common.EventService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.support.RetryTemplate;

class EventServiceTest {

    @Mock
    private EventArchiveDao eventArchiveDao;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private EncryptionUtil encryptionUtil;

    private EventService eventService;

    @Mock
    private RetryTemplate retryTemplate;

    @BeforeEach
    void setup() {
        Map<String, Object> variables = new HashMap<>();
        MockitoAnnotations.initMocks(this);
        eventService = new EventService(eventArchiveDao, encryptionUtil, retryTemplate);

        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("123456789");
        associateEvent.setId(UUID.randomUUID());
        variables.put("associateEvent", associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
    }

    @Test
    void execute_shouldUpdateEventStatus() throws Exception {
        // Arrange
        UUID eventId = UUID.randomUUID();
        String associateId = "123456789";
        String planType = "DENTAL";
        Status status = Status.PROCESSED;

        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setId(eventId);
        associateEvent.setAssociateId(associateId);
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);

        Event event = new Event();
        event.setId(eventId);
        event.setEventStatuses(new HashSet<>());

        Map<String, Object> variables = new HashMap<>();
        variables.put("associateEvent", associateEvent);
        variables.put("EVENT_STATUS", status);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable("PLAN_TYPE")).thenReturn(planType);
        when(encryptionUtil.encrypt(anyString())).thenReturn("encrypted");

        // Mock RetryTemplate for getArchiveDaoById
        when(retryTemplate.execute(any(), any(RecoveryCallback.class))).thenAnswer(invocation -> {
            // This ensures the first method (getArchiveDaoById) gets the event
            return event;
        });
        // Now mock the DAO that will be called by the RetryCallback
        when(eventArchiveDao.findByIdAndEventStatus_subPlanType(eq(eventId), eq(planType)))
                .thenReturn(Optional.of(event));
        when(eventArchiveDao.save(any(Event.class))).thenReturn(event);

        // Act
        eventService.execute(delegateExecution);

        // Assert
        verify(retryTemplate,times(2)).execute(any(), any(RecoveryCallback.class));
    }

    @Test
    void saveEvent_eventNotFound() throws Exception {
        when(eventArchiveDao.findById(any(UUID.class))).thenReturn(Optional.empty());
        assertThrows(BpmnError.class, () -> eventService.execute(delegateExecution));
    }
}