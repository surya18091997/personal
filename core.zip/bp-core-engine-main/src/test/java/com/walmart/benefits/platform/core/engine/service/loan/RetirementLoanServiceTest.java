package com.walmart.benefits.platform.core.engine.service.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.LoanModel;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.LoanStatusCode;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class RetirementLoanServiceTest {

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private RetirementLoanService retirementLoanService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void execute_setsAllVariablesCorrectly() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("loanAmount", 2000))
                .build();
        LoanModel loanModel = new LoanModel();
        loanModel.setDeductionAmount(2000.0);
        AssociateBenefit latestLoanCoverage = mock(AssociateBenefit.class);
        AssociateBenefit patchCoverage = mock(AssociateBenefit.class);
        AssociateBenefit upsertedCoverage = mock(AssociateBenefit.class);

        when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
        when(delegateExecution.getVariable(COVERAGE_RESPONSE)).thenReturn(latestLoanCoverage);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), LoanModel.class)).thenReturn(loanModel);
        when(latestLoanCoverage.getLoanStatusCode()).thenReturn(LoanStatusCode.A);

        try (MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            mockedEventUtils.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(patchCoverage);
            mockedEventUtils.when(() -> EventUtils.upsertCoverage(associateEvent, loanModel)).thenReturn(upsertedCoverage);

            retirementLoanService.execute(delegateExecution);

            verify(delegateExecution).setVariable(LOAN_DEDUCTION_AMOUNT, 2000.0);
            verify(delegateExecution).setVariable(LATEST_COVERAGE_LOAN_SEQUENCE_NUMBER,latestLoanCoverage.getLoanSequenceNumber());
            verify(delegateExecution).setVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER, loanModel.getLoanNumber());
            verify(delegateExecution).setVariable(PATCH_UPDATE_COVERAGE, patchCoverage);
            verify(delegateExecution).setVariable(UPDATE_COVERAGE, upsertedCoverage);
            verify(encryptionUtil, times(2)).encrypt("12345");
            verify(objectMapper).convertValue(associateEvent.getAdditionalInfo(), LoanModel.class);
            mockedEventUtils.verify(() -> EventUtils.targetPatchOnCoverage(associateEvent));
            mockedEventUtils.verify(() -> EventUtils.upsertCoverage(associateEvent, loanModel));
        }
    }

    @Test
    void execute_setsLoanStatusCodeNullWhenNoCoverage() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("loanAmount", 1000))
                .build();
        LoanModel loanModel = new LoanModel();
        loanModel.setDeductionAmount(1000.0);
        AssociateBenefit patchCoverage = mock(AssociateBenefit.class);
        AssociateBenefit upsertedCoverage = mock(AssociateBenefit.class);

        when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
        when(delegateExecution.getVariable(COVERAGE_RESPONSE)).thenReturn(null);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), LoanModel.class)).thenReturn(loanModel);

        try (MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            mockedEventUtils.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(patchCoverage);
            mockedEventUtils.when(() -> EventUtils.upsertCoverage(associateEvent, loanModel)).thenReturn(upsertedCoverage);

            retirementLoanService.execute(delegateExecution);

            verify(delegateExecution).setVariable(IS_COVERAGE_AVAILABLE, FALSE);
            verify(delegateExecution).setVariable(LOAN_DEDUCTION_AMOUNT, 1000.0);
            verify(delegateExecution).setVariable(PATCH_UPDATE_COVERAGE, patchCoverage);
            verify(delegateExecution).setVariable(UPDATE_COVERAGE, upsertedCoverage);
        }
    }

    @Test
    void execute_withException_setsExceptionData() throws Exception {
        when(delegateExecution.getVariables()).thenThrow(new RuntimeException("error"));
        doNothing().when(delegateExecution).setVariable(anyString(), any());
        assertThrows(Exception.class, () -> retirementLoanService.execute(delegateExecution));
    }

    @Test
    void execute_withNullAssociateEvent_throwsException() throws Exception {
        doThrow(new NullPointerException("associateEvent is null")).when(delegateExecution).getVariables();
        assertThrows(Exception.class, () -> retirementLoanService.execute(delegateExecution));
    }

    @Test
    void execute_withInvalidLoanModelConversion_throwsException() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("loanAmount", 1000))
                .build();

        when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), LoanModel.class)).thenThrow(new RuntimeException("Conversion failed"));

        assertThrows(Exception.class, () -> retirementLoanService.execute(delegateExecution));
    }
}
