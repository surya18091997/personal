package com.walmart.benefits.platform.core.engine.processor;

import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementNewHireEventProcessor;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.RETIREMENT;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;

class RetirementNewHireEventProcessorTest {

    private RetirementNewHireEventProcessor processor;

    @BeforeEach
    void  setup() {
        processor = new RetirementNewHireEventProcessor();
    }

    @Test
    void  testProcessWithValidData() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        BenefitsEntity benefitsEntity = new BenefitsEntity();

        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        associateInfo.setAssociateId("12345");
        interDomainInfo.setAssociateInfo(associateInfo);
        benefitsEntity.setInterDomainInfo(interDomainInfo);

        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility .setPlanId("401k_regular_us");
        planEligibility.setPlanGroup("Retire Plan");
        planEligibility.setIsEligible(true);
        planEligibility.setEligibleDate("2023-01-01");
        eligibility.setPlans(List.of(planEligibility));
        associateBenefitsProfile.setEligibility(eligibility);
        intraDomainInfo.setAssociateBenefitsProfile(associateBenefitsProfile);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);

        variables.put("benefitsEntity", benefitsEntity);

        when(delegateExecution.getVariables()).thenReturn(variables);

        processor.process(delegateExecution);

        verify(delegateExecution,times(1)).setVariables(anyMap());

    }

    @Test
    void  testProcessWithNullBenefitsEntity() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        when(delegateExecution.getVariables()).thenReturn(variables);

       assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void  testEventType(){
        Assertions.assertEquals(NEW_HIRE, processor.getEventType());
    }

    @Test
    void  testPlanType(){
        Assertions.assertEquals(RETIREMENT, processor.getPlanType());
    }


}