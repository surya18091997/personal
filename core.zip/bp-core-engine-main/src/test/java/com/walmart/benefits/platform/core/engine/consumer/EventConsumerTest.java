package com.walmart.benefits.platform.core.engine.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.benefits.platform.core.engine.service.common.AsyncProcessorService;
import com.walmart.benefits.platform.core.engine.service.common.EventArchiveService;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventConsumerTest {

    @Mock
    private EventArchiveService eventArchiveService;

    @Mock
    private AsyncProcessorService asyncProcessorService;

    @Mock
    private Acknowledgment acknowledgment;

    private EventConsumer eventConsumer;

    @BeforeEach
    void setUp() {
        eventConsumer = new EventConsumer(eventArchiveService, asyncProcessorService);
    }

    @Test
    void testOnEvent() throws JsonProcessingException {
        ConsumerRecord<String, Object> record = Mockito.mock(ConsumerRecord.class);
        List<ConsumerRecord<String, Object>> events = Collections.singletonList(record);

        AssociateEvent associateEvent_1 = new AssociateEvent();
        associateEvent_1.setEventType(EventType.NEW_HIRE);
        AssociateEvent associateEvent_2 = new AssociateEvent();
        associateEvent_2.setEventType(EventType.NEW_HIRE);
        List<AssociateEvent> associateEvents = List.of(associateEvent_1,associateEvent_2);

        when(eventArchiveService.storeEvents(events)).thenReturn(associateEvents);

        eventConsumer.onEvent(events, acknowledgment);

        verify(eventArchiveService, times(1)).storeEvents(events);
        verify(acknowledgment, times(1)).acknowledge();
        verify(asyncProcessorService, times(1)).processAsync(associateEvents);
    }

    @Test
    void testOnEvent_withException() throws JsonProcessingException {
        ConsumerRecord<String, Object> record = Mockito.mock(ConsumerRecord.class);
        List<ConsumerRecord<String, Object>> events = Collections.singletonList(record);

        when(eventArchiveService.storeEvents(events)).thenThrow(RuntimeException.class);

        eventConsumer.onEvent(events, acknowledgment);

        verify(eventArchiveService, times(1)).storeEvents(events);
        verify(acknowledgment, times(0)).acknowledge();
        verify(asyncProcessorService, times(0)).processAsync(any());
    }
}