package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.service.common.ErrorHandlerService;
import com.walmart.benefits.platform.core.engine.service.common.EventService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.verify;

 class ErrorHandlerServiceTest {

    @Mock
    private EventService eventService;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private ErrorHandlerService errorHandlerService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
     void testExecute() throws Exception {
        errorHandlerService.execute(delegateExecution);
        verify(eventService).updateEvent(delegateExecution);
    }
}