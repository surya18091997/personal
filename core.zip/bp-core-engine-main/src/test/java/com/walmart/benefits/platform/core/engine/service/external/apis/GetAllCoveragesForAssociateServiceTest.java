package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class GetAllCoveragesForAssociateServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private GetAllCoveragesForAssociateService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testExecute_SuccessfulFlow() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            when(ProcessEngineUtil.getRetryCount(any())).thenReturn(1);
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(delegateExecution.getVariable(PLAN_ID_LIST)).thenReturn(List.of(PlanType.RETIREMENT_401K_REGULAR_US.toString(), PlanType.RETIREMENT_401K_ROTH_US.toString()));
            when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(httpUtils.getAllCoveragesUrl()).thenReturn("http://test.com/coverage");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            ResponseEntity<List<AssociateBenefit>> responseEntity = new ResponseEntity<>(List.of(new AssociateBenefit()), HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), any(ParameterizedTypeReference.class)))
                    .thenReturn(responseEntity);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(delegateExecution, times(1)).setVariable(eq(COVERAGE_RESPONSE_LIST), anyList());
            verify(delegateExecution, times(1)).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        }
    }

    @Test
    void testExecute_ClientErrorNotFound() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(delegateExecution.getVariable(PLAN_ID_LIST)).thenReturn(List.of(PlanType.RETIREMENT_401K_REGULAR_US.toString()));
            when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(httpUtils.getAllCoveragesUrl()).thenReturn("http://test.com/coverage");

            // Mock 404 error
            HttpClientErrorException notFoundException = new HttpClientErrorException(HttpStatus.NOT_FOUND);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), any(ParameterizedTypeReference.class)))
                    .thenThrow(notFoundException);

            // Execute
            service.execute(delegateExecution);

            // Verify no exception data is set
            verify(delegateExecution, times(1)).setVariable(IS_COVERAGE_AVAILABLE, FALSE);
            verify(delegateExecution, times(0)).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
            verify(delegateExecution, times(1)).setVariable(COVERAGE_RESPONSE_LIST, new ArrayList<>());
        }
    }

    @Test
    void testExecute_ServerError() {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(delegateExecution.getVariable(PLAN_ID_LIST)).thenReturn(List.of(PlanType.RETIREMENT_401K_REGULAR_US.toString()));
            when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(httpUtils.getAllCoveragesUrl()).thenReturn("http://test.com/coverage");

            // Mock 500 error
            HttpServerErrorException serverErrorException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), any(ParameterizedTypeReference.class)))
                    .thenThrow(serverErrorException);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("500 INTERNAL_SERVER_ERROR"));
        }
    }

    @Test
    void testExecute_ResourceAccessException() {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(delegateExecution.getVariable(PLAN_ID_LIST)).thenReturn(List.of(PlanType.RETIREMENT_401K_REGULAR_US.toString()));
            when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(httpUtils.getAllCoveragesUrl()).thenReturn("http://test.com/coverage");

            // Mock connection timeout
            ResourceAccessException resourceAccessException = new ResourceAccessException("Connection timeout");
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), any(ParameterizedTypeReference.class)))
                    .thenThrow(resourceAccessException);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Connection timeout"));
        }
    }

    @Test
    void testExecute_ExceptionHandling() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenThrow(new RuntimeException("Unexpected error"));
            when(httpUtils.getAllCoveragesUrl()).thenReturn("http://test.com/coverage");
            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Unexpected error"));
        }
    }
}
