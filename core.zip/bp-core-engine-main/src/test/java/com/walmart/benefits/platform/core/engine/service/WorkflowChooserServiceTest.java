package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.configs.EventTypeConfig;
import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.service.common.WorkflowChooserService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

 class WorkflowChooserServiceTest {

    @Mock
    private RuntimeService runtimeService;

    @Mock
    private EventTypeConfig eventTypeConfig;

    @Mock
    private RuleMetaDataConfig  ruleMetaDataConfig;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private EncryptionUtil  encryptionUtil;

    @InjectMocks
    private WorkflowChooserService workflowChooserService;

    @BeforeEach
     void setUp() {
        MockitoAnnotations.initMocks(this);
        var  eventDetails = new EventTypeConfig.EventDetails();
        eventDetails.setPlanTypes(List.of("401K"));
        eventDetails.setExecuteSubPlanTypeWorkflow(false);
        Map<String, EventTypeConfig.EventDetails> eventTypeMap = new HashMap<>();
        eventTypeMap.put("new-hire", eventDetails);
        when(eventTypeConfig.getEventType()).thenReturn(eventTypeMap);
        Map<String,Map<String,List<RuleCategory>>> eventType = new HashMap<>();
        Map<String,List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        eventType.put("new-hire", ruleCategories);
        when(ruleMetaDataConfig.getEventType()).thenReturn(eventType);
    }

    @Test
     void triggerWorkFlowStateTransfer() {
        var  eventDetails = new EventTypeConfig.EventDetails();
        eventDetails.setPlanTypes(List.of("401K"));
        eventDetails.setExecuteSubPlanTypeWorkflow(true);
        Map<String, EventTypeConfig.EventDetails> eventTypeMap = new HashMap<>();
        eventTypeMap.put("state-transfer", eventDetails);
        when(eventTypeConfig.getEventType()).thenReturn(eventTypeMap);
        when(eventTypeConfig.shouldExecuteSubPlanTypeWorkflow(anyString())).thenReturn(true);

        Map<String,Map<String,List<RuleCategory>>> eventType = new HashMap<>();
        Map<String,List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        eventType.put("state-transfer", ruleCategories);
        when(ruleMetaDataConfig.getEventType()).thenReturn(eventType);

        HashMap<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.STATE_TRANSFER);
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        variables.put("associateEvent", associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
        workflowChooserService.execute(delegateExecution);
        verify(runtimeService).startProcessInstanceByKey(any(String.class), any(Map.class));
    }

    @Test
     void triggerWorkFlowBasedOnEventType() {
        HashMap<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.NEW_HIRE);
        variables.put("associateEvent", associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);
        workflowChooserService.execute(delegateExecution);
        verify(runtimeService).startProcessInstanceByKey(any(String.class), any(Map.class));
    }

    @Test
     void triggerWorkFlowBWithException() {
        HashMap<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(null);
        variables.put("associateEvent", associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);
        assertThrows(BpmnError.class, () -> workflowChooserService.execute(delegateExecution));
    }

}