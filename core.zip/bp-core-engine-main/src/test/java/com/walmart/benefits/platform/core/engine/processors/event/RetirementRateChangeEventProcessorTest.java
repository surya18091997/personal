package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.configs.RateEventPlanConfig;
import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementEnrollmentCompleteEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.StoreInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RetirementRateChangeEventProcessorTest {

    @InjectMocks
    private RetirementEnrollmentCompleteEventProcessor processor;

    @Mock
    private RateEventPlanConfig rateEventPlanConfig;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private InterDomainInfo interDomainInfo;
    @Mock
    private AssociateInfo associateInfo;
    @Mock
    private Employment employment;
    @Mock
    private StoreInfo storeInfo;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    @Mock
    private AssociateBenefit associateBenefit;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        assertEquals(RETIREMENT, processor.getPlanType());
    }

    @Test
    void testProcessWithValidCoverage() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);

            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);
            when(RateValidatorUtil.isValidCoverage(any())).thenReturn(true);
            when(RateValidatorUtil.isValidRuleEligibility(any(), any())).thenReturn(true);
            when(EventUtils.updateCoverage(any(), any())).thenReturn(associateBenefit);
            when(EventUtils.updateCoverage(eq(associateEvent), any())).thenReturn(new AssociateBenefit());

            processor.process(delegateExecution);

            verify(delegateExecution).setVariables(variables);
            assertNotNull(variables.get(UPDATE_COVERAGE));
        }

    }

    @Test
    void testProcessWithInValidCoverage() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);

            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);
            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> processor.process(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Coverage has end date"));
        }
    }

    @Test
    void testProcessWithBasePlanNotAvailable() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);
            when(EventUtils.getStoreStateProvCd(any())).thenReturn("US");
            when(RateValidatorUtil.is401kRegularPlanAvailable(any(), any())).thenReturn(false);
            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);
            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> processor.process(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Base plan is not available in profile"));
        }
    }

    @Test
    void testProcessWithExceededMaxRateRegular() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);
            when(RateValidatorUtil.isValidCoverage(any())).thenReturn(true);
            when(RateValidatorUtil.isValidRuleEligibility(any(), any())).thenReturn(true);
            when(RateValidatorUtil.isRegularPlan(any(),any())).thenReturn(true);
            when(RateValidatorUtil.isBeyondMaxRateForRegularPlan(any(), any(), any(), anyDouble(), any())).thenReturn(true);

            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> processor.process(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Exceeded MAX REGULAR RATE"));
        }
    }

    @Test
    void testProcessWithExceededMaxRateCatchup() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);
            when(RateValidatorUtil.isValidCoverage(any())).thenReturn(true);
            when(RateValidatorUtil.isValidRuleEligibility(any(), any())).thenReturn(true);
            when(RateValidatorUtil.isRegularPlan(any(),any())).thenReturn(false);
            when(RateValidatorUtil.isCatchupPlan(any(),any())).thenReturn(true);
            when(RateValidatorUtil.isBeyondMaxRateForCatchupPlan(any(), any(), any(), anyDouble(), any())).thenReturn(true);
            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);
            when(RateValidatorUtil.isCatchupEligibleAge(any(), anyInt())).thenReturn(true);
            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> processor.process(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Exceeded MAX CATCHUP RATE"));
        }
    }

    @Test
    void testProcessWithAssociateNotEligibleForCatchup() {
        try(MockedStatic<RateValidatorUtil> mockedRateValidatorUtil = mockStatic(RateValidatorUtil.class);
            MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            Map<String, Object> variables = new HashMap<>();

            when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00");
            when(associateEvent.getOrigin()).thenReturn(EventOrigin.CORE_HR);

            variables.put(IS_COVERAGE_AVAILABLE, TRUE);
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(BENEFITS_ENTITY, benefitsEntity);
            variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
            variables.put(IS_PROFILE_AVAILABLE, TRUE);
            variables.put(COVERAGE_RESPONSE_LIST, createCoverageList());

            when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
            when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
            when(associateInfo.getEmployment()).thenReturn(employment);
            when(employment.getStoreInfo()).thenReturn(storeInfo);
            when(storeInfo.getStoreStateProvCd()).thenReturn("NY");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(rateEventPlanConfig.getBasePlan()).thenReturn("BasePlan");
            when(rateEventPlanConfig.getRegularPlan()).thenReturn(Arrays.asList("Plan1", "Plan2"));
            when(rateEventPlanConfig.getCatchupPlan()).thenReturn(Collections.singletonList("CatchupPlan"));
            when(rateEventPlanConfig.getCatchupLimit()).thenReturn(7500.0);
            when(rateEventPlanConfig.getRegularLimit()).thenReturn(20000.0);
            when(rateEventPlanConfig.getCatchupEligibleAge()).thenReturn(50);
            when(RateValidatorUtil.isValidCoverage(any())).thenReturn(true);
            when(RateValidatorUtil.isValidRuleEligibility(any(), any())).thenReturn(true);
            when(RateValidatorUtil.isRegularPlan(any(),any())).thenReturn(false);
            when(RateValidatorUtil.isCatchupPlan(any(),any())).thenReturn(true);
            when(RateValidatorUtil.isBeyondMaxRateForCatchupPlan(any(), any(), any(), anyDouble(), any())).thenReturn(true);
            when(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent)).thenReturn(true);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> processor.process(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Associate is not eligible for catchup"));

//            BpmnError thrown = assertThrows(
//                    BpmnError.class,
//                    () -> processor.process(delegateExecution),
//                    "Expected process to throw, but it didn't"
//            );
//            assertTrue(thrown.getMessage().contains("Exceeded MAX REGULAR RATE"));
        }
    }

    private List<AssociateBenefit> createCoverageList() {
        AssociateBenefit benefit = new AssociateBenefit();
        benefit.setPlanId("Plan1");
        return Collections.singletonList(benefit);
    }
}
