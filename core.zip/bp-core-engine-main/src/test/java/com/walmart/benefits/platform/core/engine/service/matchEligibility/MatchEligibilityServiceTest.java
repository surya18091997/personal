// filepath: /Users/r0d0cmg/Documents/rohit/code/bp-core-engine/src/test/java/com/walmart/benefits/platform/core/engine/service/matchEligibility/MatchEligibilityServiceTest.java
package com.walmart.benefits.platform.core.engine.service.matchEligibility;

// Unit tests for MatchEligibilityService
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.service.MatchEligibility.MatchEligibilityService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.ErrorUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.mockito.Mockito.*;

public class MatchEligibilityServiceTest {

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private MatchEligibilityService matchEligibilityService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void execute_updatesVariablesSuccessfully() throws Exception {
        // Prepare test data
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("matchEligibilityAmount", 5000))
                .build();
        HardshipModel matchEligibilityModel = new HardshipModel();
        AssociateBenefitsProfile profile = new AssociateBenefitsProfile();

        // Configure mocks
        when(delegateExecution.getVariables()).thenReturn(Map.of(
                ASSOCIATE_EVENT, associateEvent
        ));
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(profile);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class)).thenReturn(matchEligibilityModel);

        try (MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {
            // Execute the service
            matchEligibilityService.execute(delegateExecution);

            // Verify interactions
            mockedEventUtils.verify(() -> EventUtils.updatePlanEligibility(profile, matchEligibilityModel));

            verify(delegateExecution).setVariable(ASSOCIATE_BENEFITS_PROFILE, profile);
            verify(encryptionUtil, times(2)).encrypt("12345");
            verify(objectMapper).convertValue(associateEvent.getAdditionalInfo(), HardshipModel.class);
        }
    }

    @Test
    void execute_withException_setsExceptionData() throws Exception {
        // Prepare test data
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("matchEligibilityAmount", 5000))
                .build();

        // Configure mocks
        when(delegateExecution.getVariables()).thenReturn(Map.of(
                ASSOCIATE_EVENT, associateEvent
        ));
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        RuntimeException exception = new RuntimeException("Test exception");
        when(objectMapper.convertValue(any(), eq(HardshipModel.class))).thenThrow(exception);

        try (MockedStatic<ErrorUtil> mockedErrorUtil = mockStatic(ErrorUtil.class)) {
            // Execute the service
            matchEligibilityService.execute(delegateExecution);

            // Verify exception handling
            mockedErrorUtil.verify(() ->
                ErrorUtil.setExceptionData(delegateExecution, "MATCH_ELIGIBILITY_SERVICE", exception.getMessage()));
        }
    }

    @Test
    void execute_withNullAssociateProfile_handlesException() throws Exception {
        // Prepare test data
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .associateId("12345")
                .additionalInfo(Map.of("matchEligibilityAmount", 5000))
                .build();
        HardshipModel matchEligibilityModel = new HardshipModel();

        // Configure mocks
        when(delegateExecution.getVariables()).thenReturn(Map.of(
                ASSOCIATE_EVENT, associateEvent
        ));
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(null);
        when(encryptionUtil.encrypt("12345")).thenReturn("encryptedId");
        when(objectMapper.convertValue(eq(associateEvent.getAdditionalInfo()), eq(HardshipModel.class))).thenReturn(matchEligibilityModel);

        try (MockedStatic<ErrorUtil> mockedErrorUtil = mockStatic(ErrorUtil.class)) {
            // Execute the service
            matchEligibilityService.execute(delegateExecution);

            // Verify exception handling
            mockedErrorUtil.verify(() ->
                    ErrorUtil.setExceptionData(
                            eq(delegateExecution),
                            eq("MATCH_ELIGIBILITY_SERVICE"),
                            eq("Associate benefits profile not found for processing match eligibility")
                    ));
        }
    }
}
