package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

class DefaultEnrollmentCompleteRuleResponseProcessorTest {

    private DefaultEnrollmentCompleteRuleResponseProcessor processor;
    private DelegateExecution delegateExecution;

    @BeforeEach
    void setUp() {
        processor = new DefaultEnrollmentCompleteRuleResponseProcessor();
        delegateExecution = mock(DelegateExecution.class);
    }

    @Test
    void process_test() {
        processor.process(delegateExecution);
        verifyNoInteractions(delegateExecution);
    }

    @Test
    void getEventType_returnsEnrollmentComplete() {
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void getPlanType_returnsNull() {
        assertNull(processor.getPlanType());
    }
}