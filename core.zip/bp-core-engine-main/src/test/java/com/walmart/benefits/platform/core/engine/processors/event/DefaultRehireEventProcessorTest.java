package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DefaultRehireEventProcessorTest {
    @Test
    void process_logsDefaultProcessingMessageForRehireEvent() {
        DefaultRehireEventProcessor processor = new DefaultRehireEventProcessor();
        DelegateExecution delegateExecution = mock(DelegateExecution.class);

        processor.process(delegateExecution);
        assertEquals(EventType.RE_HIRE, processor.getEventType());

        // Verify that the log contains the expected message
        // This requires a logging framework test utility or manual log inspection
    }

    @Test
    void getPlanType_returnsNullForRehireEvent() {
        DefaultRehireEventProcessor processor = new DefaultRehireEventProcessor();

        assertNull(processor.getPlanType());

    }
}