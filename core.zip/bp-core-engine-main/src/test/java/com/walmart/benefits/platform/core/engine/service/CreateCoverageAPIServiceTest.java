package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.service.external.apis.CreateCoverageAPIService;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngineServices;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.runtime.JobQuery;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.SYSTEM_CORE_ENGINE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

 class CreateCoverageAPIServiceTest {

    @Mock
    private ManagementService managementService;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private JobQuery jobQuery;

    @Mock
    private Job job;

    @Mock
    private ProcessEngineServices processEngineServices;

    @InjectMocks
    private CreateCoverageAPIService associateCoverageAPIService;

    @BeforeEach
     void setup() {
        MockitoAnnotations.initMocks(this);
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId("12345678");
        associateBenefit.setPlanId(RETIREMENT_401_K_REGULAR);
        associateBenefit.setPlanGroup(RETIREMENT);
        associateBenefit.setCreatedAt(ConverterUtil.getUTCTimeAsString());
        associateBenefit.setCreatedBy(SYSTEM_CORE_ENGINE);
        Map<String, Object> variables = new HashMap<>();
        variables.put("associateCoverage", List.of(associateBenefit));
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.NEW_HIRE);
        variables.put("associateEvent", associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getProcessEngineServices()).thenReturn(processEngineServices);
        when(delegateExecution.getProcessInstanceId()).thenReturn("1234");
        when(processEngineServices.getManagementService()).thenReturn(managementService);
        when(managementService.createJobQuery()).thenReturn(jobQuery);
        when(jobQuery.processInstanceId(delegateExecution.getProcessInstanceId())).thenReturn(jobQuery);
        when(jobQuery.singleResult()).thenReturn(job);
        when(job.getRetries()).thenReturn(1);
    }


    @Test
     void SuccessfullyStoreCoverageAndTransactionLog() throws Exception {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        associateCoverageAPIService.execute(delegateExecution);
        verify(restTemplate, times(2)).exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class));
    }

    @Test
     void FailToStoreCoverageAndTransactionLog() throws Exception {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        associateCoverageAPIService.execute(delegateExecution);
        verify(restTemplate, times(2)).exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class));

    }

    @Test
    void failureToSaveCoverageAndTransactionLogHttpServerErrorException() {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.SERVICE_UNAVAILABLE));
        doThrow(new BpmnError("SERVICE_NOT_AVAILABLE", "Server Not Available"))
                .when(httpUtils).handleError(any(DelegateExecution.class), any(HttpServerErrorException.class), anyInt(), anyString());
        Assert.assertThrows(BpmnError.class, () -> associateCoverageAPIService.execute(delegateExecution));

    }

    @Test
    void failureToSaveCoverageAndTransactionLogResourceAccessException() {
        mockData();
        when(job.getRetries()).thenReturn(2);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("ResourceAccessException"));
        Assert.assertThrows(Exception.class, () -> associateCoverageAPIService.execute(delegateExecution));
    }

    @Test
    void failureToSaveCoverageAndTransactionLogException() {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new NullPointerException("GeneralException"));
        Assert.assertThrows(BpmnError.class, () -> associateCoverageAPIService.execute(delegateExecution));
    }

    private void mockData() {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity httpEntity = new HttpEntity<>("request body", headers);
        when(httpUtils.getCoverageCreateUrl()).thenReturn("http://coverage.com");
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://tranasaction.com");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(httpEntity);
    }

}