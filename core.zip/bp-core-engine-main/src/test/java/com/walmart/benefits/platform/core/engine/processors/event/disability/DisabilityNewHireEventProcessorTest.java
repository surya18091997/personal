package com.walmart.benefits.platform.core.engine.processors.event.disability;

import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.camunda.bpm.engine.delegate.DelegateExecution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DisabilityNewHireEventProcessorTest {

    private DisabilityNewHireEventProcessor processor;
    private DelegateExecution delegateExecution;
    private Map<String, Object> variables;


    private MockedStatic<CommonUtils> commonUtilsMock;
    private MockedStatic<RateValidatorUtil> rateValidatorUtilMock;
    private MockedStatic<EventUtils> eventUtilsMock;

    @BeforeEach
    void setUp() {

        commonUtilsMock = mockStatic(CommonUtils.class);
        eventUtilsMock = mockStatic(EventUtils.class);
        rateValidatorUtilMock = mockStatic(RateValidatorUtil.class);

        when(EventUtils.associateCoverage(any())).thenReturn(new ArrayList<>());
        when(EventUtils.associateCoverage(any())).thenReturn(new ArrayList<>());
        when(EventUtils.createEnrollmentFromPlanElections(any(), any())).thenReturn(null);


        processor = new DisabilityNewHireEventProcessor();
        delegateExecution = mock(DelegateExecution.class);
        variables = new HashMap<>();
        when(delegateExecution.getVariables()).thenReturn(variables);

    }


    @AfterEach
    void tearDown() {
        commonUtilsMock.close();
        rateValidatorUtilMock.close();
        eventUtilsMock.close();
    }

    @Test
    void process_withValidPlanElections_createsEnrollment() {
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        List<PlanElection> planElections = List.of(mock(PlanElection.class));
        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(PLAN_ELECTIONS, planElections);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(eq(CREATE_ENROLLMENT), any());
    }

    @Test
    void process_withEmptyPlanElections_doesNotCreateEnrollment() {
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        List<PlanElection> planElections = List.of();
        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(PLAN_ELECTIONS, planElections);

        processor.process(delegateExecution);

        verify(delegateExecution, never()).setVariable(eq(CREATE_ENROLLMENT), any());
    }

    @Test
    void process_withNullPlanElections_doesNotCreateEnrollment() {
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(PLAN_ELECTIONS, null);

        processor.process(delegateExecution);

        verify(delegateExecution, never()).setVariable(eq("CREATE_ENROLLMENT"), any());
    }

    @Test
    void getPlanType_returnsDisability() {
        assertEquals(DISABILITY, processor.getPlanType());
    }
}