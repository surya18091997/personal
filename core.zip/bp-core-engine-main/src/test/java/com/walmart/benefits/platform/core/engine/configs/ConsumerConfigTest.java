package com.walmart.benefits.platform.core.engine.configs;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.retry.support.RetryTemplate;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ConsumerConfigTest {

    private ConsumerConfig consumerConfig;

    @Mock
    private RetryTemplate retryTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        consumerConfig = new ConsumerConfig(retryTemplate);
        consumerConfig.setEventsQueueBootstrapServers("localhost:9092");
        consumerConfig.setEventsQueueGroupId("test-group");
        consumerConfig.setSecurityProtocol("SSL");
        consumerConfig.setTruststoreType("JKS");
        consumerConfig.setTruststoreLocation("/path/to/truststore");
        consumerConfig.setKeystoreLocation("/path/to/keystore");
        consumerConfig.setTruststorePassword("truststore-sample");
        consumerConfig.setKeystorePassword("keystore-sample");
        consumerConfig.setKeyPassword("key-sample");
        consumerConfig.setMaxPollRecords(10);
        consumerConfig.setMaxPollInterval(30000);
        consumerConfig.setSessionTimeOut(10000);
        consumerConfig.setAesSecretKey("test-secret-key");
    }

    @Test
    public void testEquals() {
        RetryTemplate template = new RetryTemplate();
        ConsumerConfig config1 = new ConsumerConfig(template);
        config1.setEventsQueueBootstrapServers("bootstrap-servers");
        config1.setEventsQueueGroupId("group-id");

        ConsumerConfig config2 = new ConsumerConfig(template);
        config2.setEventsQueueBootstrapServers("bootstrap-servers");
        config2.setEventsQueueGroupId("group-id");

        assertEquals(config1, config2);

        config2.setEventsQueueBootstrapServers("different-bootstrap-servers");
        assertNotEquals(config1, config2);

        config2.setEventsQueueBootstrapServers("bootstrap-servers");
        config2.setEventsQueueGroupId("different-group-id");
        assertNotEquals(config1, config2);

        // test other fields...
    }

    @Test
    public void testHashCode() {
        RetryTemplate template = new RetryTemplate();
        ConsumerConfig config1 = new ConsumerConfig(template);
        config1.setEventsQueueBootstrapServers("bootstrap-servers");
        config1.setEventsQueueGroupId("group-id");

        ConsumerConfig config2 = new ConsumerConfig(template);
        config2.setEventsQueueBootstrapServers("bootstrap-servers");
        config2.setEventsQueueGroupId("group-id");

        assertEquals(config1.hashCode(), config2.hashCode());

        config2.setEventsQueueBootstrapServers("different-bootstrap-servers");
        assertNotEquals(config1.hashCode(), config2.hashCode());

        config2.setEventsQueueBootstrapServers("bootstrap-servers");
        config2.setEventsQueueGroupId("different-group-id");
        assertNotEquals(config1.hashCode(), config2.hashCode());

        // test other fields...
    }

    @Test
    void testConsumerFactory() {
        var consumerFactory = consumerConfig.consumerFactory();

        assertNotNull(consumerFactory);
        Map<String, Object> configs = ((Map<String, Object>) consumerFactory.getConfigurationProperties());

        assertEquals("localhost:9092", configs.get("bootstrap.servers"));
        assertEquals("test-group", configs.get("group.id"));
        assertEquals(false, configs.get("enable.auto.commit"));
        assertEquals(StringDeserializer.class, configs.get("key.deserializer"));
        assertEquals("SSL", configs.get("security.protocol"));
        assertEquals("/path/to/truststore", configs.get(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
        assertEquals("truststore-sample", configs.get(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
    }

    @Test
    void testKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = consumerConfig.kafkaListenerContainerFactory();

        assertNotNull(factory);
        assertTrue(factory.isBatchListener());
        assertEquals(ContainerProperties.AckMode.MANUAL, factory.getContainerProperties().getAckMode());
        assertNotNull(factory.getConsumerFactory());
    }

    @Test
    void testConsumerRecordRecoverer() {
        ConsumerRecord<String, Object> consumerRecord = mock(ConsumerRecord.class);
        Exception testException = new Exception("Test Exception");

        // Simulate recoverer execution
        consumerConfig.consumerRecordRecoverer.accept(consumerRecord, testException);

        // Verify log message or any logic executed
        verify(consumerRecord, atLeast(0)).value();
    }

    @Test
    void testConsumerConfig() {
        ConsumerConfig config = new ConsumerConfig(retryTemplate);

        config.setEventsQueueBootstrapServers("testServers");
        assertEquals("testServers", config.getEventsQueueBootstrapServers());

        config.setEventsQueueGroupId("testGroupId");
        assertEquals("testGroupId", config.getEventsQueueGroupId());

        config.setSecurityProtocol("testProtocol");
        assertEquals("testProtocol", config.getSecurityProtocol());

        config.setTruststoreType("testType");
        assertEquals("testType", config.getTruststoreType());

        config.setTruststoreLocation("testLocation");
        assertEquals("testLocation", config.getTruststoreLocation());

        config.setKeystoreLocation("testLocation");
        assertEquals("testLocation", config.getKeystoreLocation());

        config.setTruststorePassword("testSample");
        assertEquals("testSample", config.getTruststorePassword());

        config.setKeystorePassword("testSample");
        assertEquals("testSample", config.getKeystorePassword());

        config.setKeyPassword("testSample");
        assertEquals("testSample", config.getKeyPassword());
        assertEquals("testSample", config.getKeyPassword());

        config.setMaxPollRecords(10);
        assertEquals(10, config.getMaxPollRecords());

        config.setMaxPollInterval(10);
        assertEquals(10, config.getMaxPollInterval());

        config.setSessionTimeOut(10);
        assertEquals(10, config.getSessionTimeOut());

        config.setAesSecretKey("testKey");
        assertEquals("testKey", config.getAesSecretKey());
    }

}
