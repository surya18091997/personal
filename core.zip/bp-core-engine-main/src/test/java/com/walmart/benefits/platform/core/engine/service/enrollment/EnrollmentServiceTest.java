package com.walmart.benefits.platform.core.engine.service.enrollment;


import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ENROLLMENT_SERVICE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class EnrollmentServiceTest {

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private EnrollmentService enrollmentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void execute_withEnrollmentApiOrigin_setsCreateEnrollmentVariable() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .origin(EventOrigin.ENROLLMENT_API)
                .eventType(EventType.RATE_CHANGE)
                .origin(EventOrigin.ML)
                .planType(PlanType.RETIREMENT_401K_REGULAR_US)
                .additionalInfo(new LinkedHashMap<>())
                .build();
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));

        //enrollmentService.execute(delegateExecution);

        //verify(delegateExecution).setVariable(eq(ApplicationConstants.CREATE_ENROLLMENT), any());
    }

    @Test
    void execute_withException_setsExceptionData() throws Exception {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .origin(EventOrigin.ENROLLMENT_API)
                .eventType(EventType.NEW_HIRE)
                .additionalInfo(new LinkedHashMap<>())
                .build();
        when(delegateExecution.getVariables()).thenThrow(new BpmnError(ENROLLMENT_SERVICE,"Test Exception"));

        assertThrows(BpmnError.class, () -> enrollmentService.execute(delegateExecution));

    }
}
