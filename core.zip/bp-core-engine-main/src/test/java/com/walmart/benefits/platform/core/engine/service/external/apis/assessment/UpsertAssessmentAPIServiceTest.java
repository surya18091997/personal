package com.walmart.benefits.platform.core.engine.service.external.apis.assessment;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.assessment.Assessment;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UpsertAssessmentAPIServiceTest {

    private HttpUtils httpUtils;
    private EncryptionUtil encryptionUtil;
    private RestTemplate restTemplate;
    private MockedStatic<ProcessEngineUtil> processEngineUtil;
    private MockedStatic<TransactionLogUtil> transactionLogUtil;

    @BeforeEach
    void execute() {
        httpUtils = mock(HttpUtils.class);
        encryptionUtil = mock(EncryptionUtil.class);
        restTemplate = mock(RestTemplate.class);
        processEngineUtil = mockStatic(ProcessEngineUtil.class);
        transactionLogUtil = mockStatic(TransactionLogUtil.class);

        when(ProcessEngineUtil.getRetryCount(any())).thenReturn(0);
        when(TransactionLogUtil.getTransactionLogEvent(any(AssociateEvent.class),anyString())).thenReturn(new TransactionLog());

    }


    @AfterEach
    void tearDown() {
        processEngineUtil.close();
        transactionLogUtil.close();
    }

    @Test
    void execute_callsAssessmentAndTransactionLogApisSuccessfully() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        Assessment assessment = new Assessment();
        List<Assessment> assessments = List.of(assessment);

        when(delegateExecution.getVariables()).thenReturn(Map.of(
            ASSOCIATE_EVENT, associateEvent,
            ASSESSMENT, assessments
        ));
        when(httpUtils.getAssessmentUpsertUrl()).thenReturn("http://assessment-upsert-url");
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://transaction-log-url");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(null);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class)))
            .thenReturn(ResponseEntity.ok("Success"));

        new UpsertAssessmentAPIService(restTemplate, httpUtils, encryptionUtil).execute(delegateExecution);

        verify(restTemplate, times(1)).exchange(eq("http://assessment-upsert-url"), eq(HttpMethod.POST), any(), eq(String.class));
        verify(restTemplate, times(1)).exchange(eq("http://transaction-log-url"), eq(HttpMethod.POST), any(), eq(String.class));
    }

    @Test
    void execute_handlesHttpServerErrorException() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        Assessment assessment = new Assessment();
        List<Assessment> assessments = List.of(assessment);

        when(delegateExecution.getVariables()).thenReturn(Map.of(
            ASSOCIATE_EVENT, associateEvent,
            ASSESSMENT, assessments
        ));
        when(httpUtils.getAssessmentUpsertUrl()).thenReturn("http://assessment-upsert-url");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(null);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class)))
            .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        new UpsertAssessmentAPIService(restTemplate, httpUtils, encryptionUtil).execute(delegateExecution);

        verify(httpUtils).handleError(eq(delegateExecution), any(HttpServerErrorException.class), anyInt(), eq(ASSESSMENT_UPSERT_SERVER_ERROR));
    }

    @Test
    void execute_handlesGenericExceptionAndSetsErrorData() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        Assessment assessment = new Assessment();
        List<Assessment> assessments = List.of(assessment);

        when(delegateExecution.getVariables()).thenReturn(Map.of(
            ASSOCIATE_EVENT, associateEvent,
            ASSESSMENT, assessments
        ));
        when(httpUtils.getAssessmentUpsertUrl()).thenReturn("http://assessment-upsert-url");
        when(httpUtils.getHttpEntity(any(), any())).thenReturn(null);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class)))
            .thenThrow(new RuntimeException("Unexpected error"));

        assertThrows(BpmnError.class, ()->new UpsertAssessmentAPIService(restTemplate, httpUtils, encryptionUtil).execute(delegateExecution));


    }
}