package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.service.external.apis.ConnectorAPIService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.RulesInputMetadata;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngineServices;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.runtime.JobQuery;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ConnectorAPIServiceTest {

    @Mock
    private ManagementService managementService;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private JobQuery jobQuery;

    @Mock
    private Job job;

    @Mock
    private ProcessEngineServices processEngineServices;

    @InjectMocks
    private ConnectorAPIService connectorAPIService;

    @BeforeEach
   void setup() {
        MockitoAnnotations.initMocks(this);
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345678");
        Map<String, Object> variables = new HashMap<>();
        variables.put("associateEvent",associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getProcessEngineServices()).thenReturn(processEngineServices);
        when(delegateExecution.getProcessInstanceId()).thenReturn("1234");
        when(processEngineServices.getManagementService()).thenReturn(managementService);
        when(managementService.createJobQuery()).thenReturn(jobQuery);
        when(jobQuery.processInstanceId(delegateExecution.getProcessInstanceId())).thenReturn(jobQuery);
        when(jobQuery.singleResult()).thenReturn(job);
        when(job.getRetries()).thenReturn(1);
    }


    @Test
   void getDataFromConnectorService() throws Exception {
        mockData();
        RulesInputMetadata rulesInputMetadata = new RulesInputMetadata();
        rulesInputMetadata.setUpstreamGraphQlQuery(ApplicationConstants.GRAPHQL_CONNECTOR_FIELDS);
        when(delegateExecution.getVariable("ruleMetaData")).thenReturn(rulesInputMetadata);
        ConnectorResponse  connectorResponse = new ConnectorResponse();
        ConnectorResponse.Data data = new ConnectorResponse.Data();
        data.setQueryAssociateUpstreamDetails(new InterDomainInfo());
        connectorResponse.setData(data);
        ResponseEntity<ConnectorResponse> graphQLResponse = new ResponseEntity<>(connectorResponse,HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class)))
                .thenReturn(graphQLResponse);
        connectorAPIService.execute(delegateExecution);
        verify(restTemplate,times(1)).exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class));

    }

    @Test
   void dataNotInConnectorService() throws Exception {
        mockData();
        ConnectorResponse  connectorResponse = new ConnectorResponse();
        ConnectorResponse.Data data = new ConnectorResponse.Data();
        data.setQueryAssociateUpstreamDetails(null);
        connectorResponse.setData(data);
        ResponseEntity<ConnectorResponse> graphQLResponse = new ResponseEntity<>(connectorResponse,HttpStatus.OK);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class)))
                .thenReturn(graphQLResponse);

        Assert.assertThrows(BpmnError.class,() -> connectorAPIService.execute(delegateExecution));

    }

    @Test
   void connectorServiceNotAvailableHttpServerError() {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        Assert.assertThrows(BpmnError.class, () -> connectorAPIService.execute(delegateExecution));

    }

    @Test
   void connectorServiceNotAvailableResourceAccessException()  {
        mockData();
        when(job.getRetries()).thenReturn(2);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class)))
                .thenThrow(new ResourceAccessException("ResourceAccessException"));

        Assert.assertThrows(Exception.class, () -> connectorAPIService.execute(delegateExecution));
    }

    @Test
   void connectorServiceNotAvailableException() throws Exception {
        mockData();
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(ConnectorResponse.class)))
                .thenThrow(new NullPointerException("General Exception"));

        Assert.assertThrows(Exception.class, () -> connectorAPIService.execute(delegateExecution));
    }

    private void mockData() {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity httpEntity = new HttpEntity<>("request body", headers);
        when(httpUtils.getHttpEntity(any(),any())).thenReturn(httpEntity);
        when(httpUtils.getConnectorGraphqlUrl()).thenReturn("connectorServiceUrl");
    }

}