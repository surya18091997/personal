package com.walmart.benefits.platform.core.engine.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.common.EventArchiveService;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.support.RetryTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

class EventArchiveServiceTest {

    @Mock
    private EventArchiveDao eventArchiveDao;

    @InjectMocks
    private EventArchiveService eventArchiveService;

    private String event;

    @Mock
    private RetryTemplate retryTemplate;

    @BeforeEach
    public void setup() {
        event = """ 
                 {
                         "id": "0f0fc9f5-de19-4d29-bc41-7b0cca22a431",
                        "associateId": "232507529",
                        "eventType": "NEW_HIRE",
                        "timeStamp": "2024-11-11T05:18:50.994824Z",
                        "origin": "ML",
                        "description": "",
                        "planType": "PLAN_401K",
                        "additionalInfo": ""
                }
                """;
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testStoreEvents() throws JsonProcessingException {
        List<ConsumerRecord<String, Object>> events = new ArrayList<>();
        ConsumerRecord<String, Object> consumerRecord = new ConsumerRecord<>("test", 0, 0, "new-hire", event);
        events.add(consumerRecord);

        AssociateEvent associateEvent = new AssociateEvent();
        List<Event> savedEvents = List.of(new Event());

        // Mock saveAll to return a non-null list
        when(eventArchiveDao.saveAll(anyList())).thenReturn(savedEvents);

        // Mock RetryTemplate for getArchiveDaoById
        when(retryTemplate.execute(any(), any(RecoveryCallback.class))).thenAnswer(invocation -> {
            // This ensures the first method (getArchiveDaoById) gets the event
            return savedEvents;
        });

        List<AssociateEvent> result = eventArchiveService.storeEvents(events);
        assertEquals(1, result.size());
    }
}
