package com.walmart.benefits.platform.core.engine.consumer;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class AESTest {

    private static final String SAMPLE_KEY = "1234567890123456"; // Must be 16 bytes for AES
    private static final String TEST_DATA = "This is a test message.";

    @Test
    void testEncrypt_ValidInput() {
        byte[] encrypted = AES.encrypt(TEST_DATA.getBytes(StandardCharsets.UTF_8), SAMPLE_KEY);

        assertNotNull(encrypted);
        assertTrue(encrypted.length > 0, "Encrypted data should not be empty.");
    }

    @Test
    void testDecrypt_ValidInput() {
        // Encrypt the test data
        byte[] encrypted = AES.encrypt(TEST_DATA.getBytes(StandardCharsets.UTF_8), SAMPLE_KEY);
        assertNotNull(encrypted);

        // Decrypt the encrypted data
        byte[] decrypted = AES.decrypt(encrypted, SAMPLE_KEY);

        assertNotNull(decrypted);
        assertEquals(TEST_DATA, new String(decrypted, StandardCharsets.UTF_8), "Decrypted data should match the original.");
    }

    @Test
    void testEncrypt_InvalidSecret() {
        String invalidSecret = "short";

        // Encrypt with an invalid secret
        byte[] encrypted = AES.encrypt(TEST_DATA.getBytes(StandardCharsets.UTF_8), invalidSecret);

        // Since the encryption fails, an empty byte array is expected
        assertNotNull(encrypted);
        assertEquals(0, encrypted.length, "Encrypted data should be empty due to invalid secret.");
    }

    @Test
    void testDecrypt_InvalidSecret() {
        // Encrypt the test data with a valid secret
        byte[] encrypted = AES.encrypt(TEST_DATA.getBytes(StandardCharsets.UTF_8), SAMPLE_KEY);
        assertNotNull(encrypted);

        // Try to decrypt with an invalid secret
        String invalidSecret = "short";
        byte[] decrypted = AES.decrypt(encrypted, invalidSecret);

        // Decryption should fail and return an empty byte array
        assertNotNull(decrypted);
        assertEquals(0, decrypted.length, "Decrypted data should be empty due to invalid secret.");
    }

    @Test
    void testDecrypt_InvalidData() {
        // Provide random invalid data
        byte[] invalidData = "InvalidEncryptedData".getBytes(StandardCharsets.UTF_8);

        // Decrypt with a valid secret
        byte[] decrypted = AES.decrypt(invalidData, SAMPLE_KEY);

        // Decryption should fail and return an empty byte array
        assertNotNull(decrypted);
        assertEquals(0, decrypted.length, "Decrypted data should be empty for invalid encrypted data.");
    }

    @Test
    void testEncryptDecrypt_Consistency() {
        byte[] encrypted = AES.encrypt(TEST_DATA.getBytes(StandardCharsets.UTF_8), SAMPLE_KEY);
        assertNotNull(encrypted);

        byte[] decrypted = AES.decrypt(encrypted, SAMPLE_KEY);
        assertNotNull(decrypted);

        // The decrypted value should match the original test data
        assertEquals(TEST_DATA, new String(decrypted, StandardCharsets.UTF_8));
    }

    @Test
    void testEncrypt_EmptyData() {
        byte[] encrypted = AES.encrypt(new byte[0], SAMPLE_KEY);

        assertNotNull(encrypted);
        assertTrue(encrypted.length > 0, "Encryption should handle empty input.");
    }

    @Test
    void testDecrypt_EmptyData() {
        byte[] decrypted = AES.decrypt(new byte[0], SAMPLE_KEY);

        assertNotNull(decrypted);
        assertEquals(0, decrypted.length, "Decryption should handle empty input.");
    }
}
