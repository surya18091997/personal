package com.walmart.benefits.platform.core.engine.processor;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement.RetirementNewHireRuleRequestProcessor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;

class RetirementNewHireRuleRequestProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private RetirementNewHireRuleRequestProcessor processor;

    @BeforeEach
    void  setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void  testEventType(){
        Assertions.assertEquals(NEW_HIRE, processor.getEventType());
    }

    @Test
    void  testPlanType(){
        Assertions.assertEquals("Retirement", processor.getPlanType());
    }



}