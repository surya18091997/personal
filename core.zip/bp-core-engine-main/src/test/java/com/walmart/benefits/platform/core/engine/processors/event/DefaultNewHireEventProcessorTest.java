package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DefaultNewHireEventProcessorTest {

    private DefaultNewHireEventProcessor processor;
    private DelegateExecution delegateExecution;
    private Map<String, Object> variables;
    private MockedStatic<EventUtils> eventUtilsMock;

    @BeforeEach
    void setUp() {
        processor = new DefaultNewHireEventProcessor();
        delegateExecution = mock(DelegateExecution.class);
        variables = new HashMap<>();
        when(delegateExecution.getVariables()).thenReturn(variables);
        eventUtilsMock = mockStatic(EventUtils.class);

    }

    @AfterEach
    void tearDown() {
        eventUtilsMock.close();
    }

    @Test
    void process_withValidBenefitsEntity_setsProfileAndCoverage() {
        BenefitsEntity benefitsEntity = new BenefitsEntity();
        List<AssociateBenefit> mockBenefits = List.of(mock(AssociateBenefit.class));
        AssociateBenefitsProfile mockProfile = new AssociateBenefitsProfile();
        variables.put(BENEFITS_ENTITY, benefitsEntity);
        when(EventUtils.associateProfile(benefitsEntity)).thenReturn(mockProfile);

        when(EventUtils.associateCoverage(benefitsEntity)).thenReturn(mockBenefits);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariables(variables);
        assertNotNull(variables.get(ASSOCIATE_BENEFITS_PROFILE));
        assertNotNull(variables.get(ASSOCIATE_COVERAGE));
    }


    @Test
    void process_withNullBenefitsEntity_doesNotSetProfileAndCoverage() {
        variables.put(BENEFITS_ENTITY, null);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariables(variables);
        assertNull(variables.get(ASSOCIATE_COVERAGE));
    }

    @Test
    void getPlanType_returnsNull() {
        assertNull(processor.getPlanType());
    }
}