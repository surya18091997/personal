package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_EVENT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HttpUtilsTest {

    private HttpUtils httpUtils;

    @Mock
    private  EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        httpUtils = new HttpUtils(encryptionUtil);

        httpUtils.setEnvironment("test-env");
        httpUtils.setConsumerId("test-consumer");
        httpUtils.setConnectorConsumerName("test-connector");
        httpUtils.setAssociateBenefitServiceAppName("test-associate-benefits");
        httpUtils.setTransactionLogServiceAppName("test-transaction-log");
        httpUtils.setAssociateEnrollmentServiceAppName("test-enrollment");
        httpUtils.setBenefitsProfileServiceAppName("test-benefits-profile");
        httpUtils.setAssociateProfileServiceAppName("test-profile-service");
        httpUtils.setConnectorGraphqlUrl("http://test.com/graphql");
        httpUtils.setBenefitsProfileServiceUrl("http://test.com/profile");
        httpUtils.setAssociateBenefitsServiceUrl("http://test.com/benefits");
        httpUtils.setAssociateEnrollmentServiceUrl("http://test.com/enrollment");
        httpUtils.setTransactionLogServiceUrl("http://test.com/log");
    }

    @Test
    void testHashCode() {
        EncryptionUtil util = new EncryptionUtil();
        HttpUtils httpUtils1 = new HttpUtils(util);
        httpUtils1.setConsumerId("consumerId");
        httpUtils1.setEnvironment("environment");
        httpUtils1.setConnectorConsumerName("connectorConsumerName");

        HttpUtils httpUtils2 = new HttpUtils(util);
        httpUtils2.setConsumerId("consumerId");
        httpUtils2.setEnvironment("environment");
        httpUtils2.setConnectorConsumerName("connectorConsumerName");

        assertEquals(httpUtils1.hashCode(), httpUtils2.hashCode());

        httpUtils2.setConsumerId("differentConsumerId");
        assertNotEquals(httpUtils1.hashCode(), httpUtils2.hashCode());

        httpUtils2.setConsumerId("consumerId");
        httpUtils2.setEnvironment("differentEnvironment");
        assertNotEquals(httpUtils1.hashCode(), httpUtils2.hashCode());
    }

    @Test
    void testEquals() {
        EncryptionUtil util = new EncryptionUtil();
        HttpUtils httpUtils1 = new HttpUtils(util);
        httpUtils1.setConsumerId("consumerId");
        httpUtils1.setEnvironment("environment");
        httpUtils1.setConnectorConsumerName("connectorConsumerName");

        HttpUtils httpUtils2 = new HttpUtils(util);
        httpUtils2.setConsumerId("consumerId");
        httpUtils2.setEnvironment("environment");
        httpUtils2.setConnectorConsumerName("connectorConsumerName");

        assertEquals(httpUtils1, httpUtils2);

        httpUtils2.setConsumerId("differentConsumerId");
        assertNotEquals(httpUtils1, httpUtils2);

        httpUtils2.setConsumerId("consumerId");
        httpUtils2.setEnvironment("differentEnvironment");
        assertNotEquals(httpUtils1, httpUtils2);
        assertNotEquals(httpUtils1, new Object());
        assertNotEquals(null,httpUtils1);
    }


    @Test
    void testGetHttpEntity_WithData() {
        Object data = new Object();
        HttpEntity<Object> entity = httpUtils.getHttpEntity(data, "test-service");

        assertNotNull(entity);
        assertEquals(data, entity.getBody());

        HttpHeaders headers = entity.getHeaders();
        assertNotNull(headers);
        assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
        assertEquals("test-env", headers.getFirst(ApplicationConstants.WM_SVC_ENV));
        assertEquals("test-service", headers.getFirst(ApplicationConstants.WM_SVC_NAME));
        assertEquals("test-consumer", headers.getFirst(ApplicationConstants.WM_CONSUMER_ID));
    }

    @Test
    void testGetHttpEntity_WithoutData() {
        HttpEntity<Object> entity = httpUtils.getHttpEntity("test-service");

        assertNotNull(entity);
        assertNull(entity.getBody());

        HttpHeaders headers = entity.getHeaders();
        assertNotNull(headers);
        assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
        assertEquals("test-env", headers.getFirst(ApplicationConstants.WM_SVC_ENV));
        assertEquals("test-service", headers.getFirst(ApplicationConstants.WM_SVC_NAME));
        assertEquals("test-consumer", headers.getFirst(ApplicationConstants.WM_CONSUMER_ID));
    }

    @Test
    void testServerNotAvailable_NoRetry_ThrowsException() {
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.SERVICE_UNAVAILABLE, "Service Unavailable");

        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12225");
        variables.put(ASSOCIATE_EVENT, associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);

        BpmnError thrown = assertThrows(
                BpmnError.class,
                () -> httpUtils.handleError(delegateExecution, exception, 0, "test-service"),
                "Expected process to throw, but it didn't"
        );
        assertTrue(thrown.getMessage().contains("503 Service Unavailable"));
    }

    @Test
    void testServerNotAvailable_WithRetry_ThrowsException() {
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT, "Gateway Timeout");
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12225");
        variables.put(ASSOCIATE_EVENT, associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);

        //doNothing().when(delegateExecution).setVariable(ASSOCIATE_EVENT, associateEvent);


        assertThrows(HttpServerErrorException.class, () ->
                httpUtils.handleError(delegateExecution, exception, 1, "test-service"));

        verify(delegateExecution, never()).setVariable(anyString(), any());
    }

    @Test
    void testGetProfileCreateUrl() {
        String url = httpUtils.getProfileCreateUrl();
        assertEquals("http://test.com/profile/associate/benefits/profile/create", url);
    }

    @Test
    void testGetProfileUpdateUrl() {
        String url = httpUtils.getProfileUpdateUrl();
        assertEquals("http://test.com/profile/associate/benefits/profile/update", url);
    }

    @Test
    void testGetProfileUrl() {
        String url = httpUtils.getProfileUrl();
        assertEquals("http://test.com/profile/associate/benefits/profile/?associateId=", url);
    }

    @Test
    void testGetCoverageUrl() {
        String url = httpUtils.getCoverageUrl();
        assertEquals("http://test.com/benefits/associate/benefit/", url);
    }

    @Test
    void testGetCoverageCreateUrl() {
        String url = httpUtils.getCoverageCreateUrl();
        assertEquals("http://test.com/benefits/associate/benefit/create", url);
    }

    @Test
    void testGetCoverageUpdateUrl() {
        String url = httpUtils.getCoverageUpsertUrl();
        assertEquals("http://test.com/benefits/associate/benefit/upsert", url);
    }

    @Test
    void testGetEnrollmentUrl() {
        String url = httpUtils.getEnrollmentUrl();
        assertEquals("http://test.com/enrollment/enrollment/", url);
    }

    @Test
    void testGetTransactionLogUrl() {
        String url = httpUtils.getTransactionLogUrl();
        assertEquals("http://test.com/log/associate/transactionLog/save", url);
    }

    @Test
    void testGetTransactionBulkLogUrl() {
        String url = httpUtils.getTransactionLogBulkUrl();
        assertEquals("http://test.com/log/associate/transactionLog/saveAll", url);
    }

    @Test
    void testHandleClientError_PreconditionFailed() {
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.PRECONDITION_FAILED, "Precondition Failed");
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12225");
        variables.put(ApplicationConstants.ASSOCIATE_EVENT, associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);

        assertThrows(HttpClientErrorException.class, () ->
                httpUtils.handleClientError(delegateExecution, 1, "test-service", exception, associateEvent)
        );

        verify(delegateExecution, never()).setVariable(anyString(), any());
    }

    @Test
    void testHandleClientError_OtherStatus() {
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Bad Request");
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12225");
        variables.put(ApplicationConstants.ASSOCIATE_EVENT, associateEvent);
        when(delegateExecution.getVariables()).thenReturn(variables);

        assertThrows(BpmnError.class, () -> httpUtils.handleClientError(delegateExecution, 1, "test-service", exception, associateEvent));
    }

    @Test
     void testGettersAndSetters() {
        // Set test values
        ReflectionTestUtils.setField(httpUtils, "consumerId", "testId");
        ReflectionTestUtils.setField(httpUtils, "environment", "testEnv");
        ReflectionTestUtils.setField(httpUtils, "connectorConsumerName", "testCCN");
        ReflectionTestUtils.setField(httpUtils, "associateBenefitsServiceAppName", "testABSA");
        ReflectionTestUtils.setField(httpUtils, "transactionLogServiceAppName", "testTLSA");
        ReflectionTestUtils.setField(httpUtils, "associateEnrollmentServiceAppName", "testAESA");
        ReflectionTestUtils.setField(httpUtils, "benefitsProfileServiceAppName", "testBPSA");
        ReflectionTestUtils.setField(httpUtils, "associateBenefitServiceAppName", "testABSA");
        ReflectionTestUtils.setField(httpUtils, "associateProfileServiceAppName", "testAPSA");
        ReflectionTestUtils.setField(httpUtils, "connectorGraphqlUrl", "testCGU");
        ReflectionTestUtils.setField(httpUtils, "benefitsProfileServiceUrl", "testBPSU");
        ReflectionTestUtils.setField(httpUtils, "associateBenefitsServiceUrl", "testABSU");
        ReflectionTestUtils.setField(httpUtils, "associateEnrollmentServiceUrl", "testAESU");
        ReflectionTestUtils.setField(httpUtils, "transactionLogServiceUrl", "testTLSU");

        // Verify getters return the correct values
        assertEquals("testId", httpUtils.getConsumerId());
        assertEquals("testEnv", httpUtils.getEnvironment());
        assertEquals("testCCN", httpUtils.getConnectorConsumerName());
        assertEquals("testABSA", httpUtils.getAssociateBenefitsServiceAppName());
        assertEquals("testTLSA", httpUtils.getTransactionLogServiceAppName());
        assertEquals("testAESA", httpUtils.getAssociateEnrollmentServiceAppName());
        assertEquals("testBPSA", httpUtils.getBenefitsProfileServiceAppName());
        assertEquals("testABSA", httpUtils.getAssociateBenefitServiceAppName());
        assertEquals("testAPSA", httpUtils.getAssociateProfileServiceAppName());
        assertEquals("testCGU", httpUtils.getConnectorGraphqlUrl());
        assertEquals("testBPSU", httpUtils.getBenefitsProfileServiceUrl());
        assertEquals("testABSU", httpUtils.getAssociateBenefitsServiceUrl());
        assertEquals("testAESU", httpUtils.getAssociateEnrollmentServiceUrl());
        assertEquals("testTLSU", httpUtils.getTransactionLogServiceUrl());
    }

    @Test
     void testServerNotAvailable_NoRetry_LogsErrorAndThrowsException() {
        // Arrange

        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        HttpServerErrorException exception = mock(HttpServerErrorException.class);
        EncryptionUtil encryptionUtil1 = mock(EncryptionUtil.class);

        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12225");
        variables.put(ASSOCIATE_EVENT, associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(encryptionUtil1.encrypt(anyString())).thenReturn("dfg");

        when(exception.getMessage()).thenReturn("HttpStatus.GATEWAY_TIMEOUT");
        when(exception.getStatusCode()).thenReturn(HttpStatus.BAD_GATEWAY);
        Assert.assertThrows(BpmnError.class, () -> httpUtils.handleError(delegateExecution, exception, 0, "test-service"));

    }

    @Test
     void testServerNotAvailable_WithRetry_SetsExceptionDataAndThrowsException() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        HttpServerErrorException exception = mock(HttpServerErrorException.class);
        when(exception.getStatusCode()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE);
        HttpUtils httpUtils = new HttpUtils(encryptionUtil);
        Assert.assertThrows(Exception.class, () -> httpUtils.handleError(delegateExecution, exception, 1, "test-service"));

    }

    @Test
     void testBadGateway_WithRetry_SetsExceptionDataAndThrowsException() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        HttpServerErrorException exception = mock(HttpServerErrorException.class);
        when(exception.getStatusCode()).thenReturn(HttpStatus.BAD_GATEWAY);
        HttpUtils httpUtils = new HttpUtils(encryptionUtil);
        Assert.assertThrows(Exception.class, () -> httpUtils.handleError(delegateExecution, exception, 1, "test-service"));

    }

    @Test
     void testGateway_Time_Out_WithRetry_SetsExceptionDataAndThrowsException() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        HttpServerErrorException exception = mock(HttpServerErrorException.class);
        when(exception.getStatusCode()).thenReturn(HttpStatus.GATEWAY_TIMEOUT);
        HttpUtils httpUtils = new HttpUtils(encryptionUtil);
        Assert.assertThrows(Exception.class, () -> httpUtils.handleError(delegateExecution, exception, 1, "test-service"));

    }

}
