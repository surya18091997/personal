package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement.RetirementStateTransferRuleRequestProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.STATE_TRANSFER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class RetirementStateTransferRuleRequestProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    private RetirementStateTransferRuleRequestProcessor ruleRequestProcessor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ruleRequestProcessor = new RetirementStateTransferRuleRequestProcessor();
    }

    @Test
    void testProcess_Success() {
        // Mock variables and objects
        Map<String, Object> variables = mock(Map.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        AssociateEligibilityInput associateEligibilityInput = mock(AssociateEligibilityInput.class);
        LinkedHashMap<String, String> additionalInfo = new LinkedHashMap<>();
        additionalInfo.put(PREV_STATE_STORE_PROV_CD, "TestProvCd");

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(variables.get(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);
        when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);

        // Execute the method
        ruleRequestProcessor.process(delegateExecution);

        // Verify interactions
        verify(delegateExecution, times(1)).getVariables();
        verify(delegateExecution, times(1)).getVariable(ASSOCIATE_ELIGIBILITY_INPUT);
        verify(associateEligibilityInput, times(1)).setPrevStateStoreProvCd("TestProvCd");
        verify(delegateExecution, times(1)).setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
    }

    @Test
    void testGetEventType() {
        // Verify EventType
        EventType eventType = ruleRequestProcessor.getEventType();
        assertEquals(STATE_TRANSFER, eventType);
    }

    @Test
    void testGetPlanType() {
        // Verify PlanType
        String planType = ruleRequestProcessor.getPlanType();
        assertEquals(RETIREMENT, planType);
    }
}
