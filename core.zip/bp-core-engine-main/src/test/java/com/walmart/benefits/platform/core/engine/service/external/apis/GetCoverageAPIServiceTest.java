package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedStatic;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class GetCoverageAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private GetCoverageAPIService service;

    @Mock
    private AssociateEvent associateEvent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(associateEvent.getAssociateId()).thenReturn("12345");
    }

    @Test
    void testExecute_SuccessfulResponse() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(httpUtils.getCoverageUrl()).thenReturn("http://test.com/coverage");
            when(httpUtils.getHttpEntity(any())).thenReturn(null);
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            ResponseEntity<AssociateBenefit> responseEntity = new ResponseEntity<>(new AssociateBenefit(), HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(AssociateBenefit.class)))
                    .thenReturn(responseEntity);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(delegateExecution, times(1)).setVariable(COVERAGE_RESPONSE, responseEntity.getBody());
            verify(delegateExecution, times(1)).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        }
    }

    @Test
    void testExecute_ClientErrorNotFound() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(httpUtils.getCoverageUrl()).thenReturn("http://test.com/coverage");
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            // Mock 404 response
            HttpClientErrorException notFoundException = new HttpClientErrorException(HttpStatus.NOT_FOUND);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(AssociateBenefit.class)))
                    .thenThrow(notFoundException);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(encryptionUtil, times(2)).encrypt("12345");
            verify(delegateExecution, times(2)).setVariable(IS_COVERAGE_AVAILABLE, FALSE);
        }
    }

    @Test
    void testExecute_ServerErrorException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
            when(httpUtils.getCoverageUrl()).thenReturn("http://test.com/coverage");
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(1);

            // Mock 500 response
            HttpServerErrorException serverErrorException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(AssociateBenefit.class)))
                    .thenThrow(serverErrorException);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(httpUtils, times(1)).handleError(delegateExecution, serverErrorException, 1, ASSOCIATE_COVERAGE_SERVICE_GET_SERVER_ERROR);
        }
    }

    @Test
    void testExecute_GeneralException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenThrow(new BpmnError("Unexpected error","Unexpected error"));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Unexpected error"));
        }
    }
}
