package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.exceptions.EventNotFoundException;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.model.RetirementContributionRateEvent;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.COVERAGE_RESPONSE_LIST;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CommonUtilsTest {

    @Mock
    private DelegateExecution delegateExecution;

    @Test
     void testGenerateKey() {
        EventType eventType = EventType.NEW_HIRE;
        String expectedKey = "new-hire";

        String generatedKey = CommonUtils.generateKey(eventType);

        assertEquals(expectedKey, generatedKey);
    }

    @Test
     void testGetWorkflowName() {
        String plan = "401k";
        EventType eventType = EventType.NEW_HIRE;
        String expectedWorkflowName = "new_hire_401k";

        String workflowName = CommonUtils.getWorkflowName(plan, eventType);

        assertEquals(expectedWorkflowName, workflowName);
    }

    @Test
     void testValidEventType() {
        EventType eventType = EventType.NEW_HIRE;

        boolean isValid = CommonUtils.validEventType(eventType);

        assertEquals(true, isValid);
    }

    @Test
     void testInvalidEventType() {
        EventType eventType = EventType.NONE;

        assertThrows(EventNotFoundException.class, () -> {
            CommonUtils.validEventType(eventType);
        });
    }

    @Test
     void testGetBenefitsEntity_ValidInput() {
        ConnectorResponse connectorResponse = new ConnectorResponse();
        InterDomainInfo interDomainInfo = new InterDomainInfo();
        interDomainInfo.setAssociateInfo(new AssociateInfo());
        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        connectorResponse.setData( new ConnectorResponse.Data());
        connectorResponse.getData().setQueryAssociateUpstreamDetails(interDomainInfo);
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId(associateEvent.getAssociateId());
        intraDomainInfo.setAssociateBenefit(associateBenefit);

        BenefitsEntity benefitsEntity = CommonUtils.getBenefitsEntity(connectorResponse, associateEvent);

        Assertions.assertNotNull(benefitsEntity);
        assertEquals(interDomainInfo, benefitsEntity.getInterDomainInfo());
        assertEquals(intraDomainInfo, benefitsEntity.getIntraDomainInfo());
        assertEquals(associateEvent.getAssociateId(), interDomainInfo.getAssociateInfo().getAssociateId());
    }

    @Test
     void testGetBenefitsEntity_NullConnectorResponse() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");

        assertThrows(NullPointerException.class, () -> {
            CommonUtils.getBenefitsEntity(null, associateEvent);
        });
    }

    @Test
     void testGetBenefitsEntity_NullAssociateEvent() {
        ConnectorResponse connectorResponse = new ConnectorResponse();
        assertThrows(NullPointerException.class, () -> {
            CommonUtils.getBenefitsEntity(connectorResponse, null);
        });
    }

    @Test
     void testGetContributionFromEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        RetirementContributionRateEvent expectedContribution = new RetirementContributionRateEvent();
        expectedContribution.setRateChanged(10.0);
        associateEvent.setAdditionalInfo(expectedContribution);

        RetirementContributionRateEvent contribution = CommonUtils.getContributionFromEvent(associateEvent);

        assertEquals(expectedContribution.getRateChanged(), contribution.getRateChanged());
    }

    @Test
     void testGetContributionFromEvent_NullInput() {
        assertThrows(NullPointerException.class, () -> {
            CommonUtils.getContributionFromEvent(null);
        });
    }

    @Test
     void testGetProfileWhenProfileAvailable() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        variables.put("isProfileAvailable", "true");
        variables.put("getAssociateProfileResponse", new AssociateBenefitsProfile());
        when(delegateExecution.getVariables()).thenReturn(variables);

        AssociateBenefitsProfile profile = CommonUtils.getProfile(delegateExecution);
        Assertions.assertNotNull(profile);
    }

    @Test
     void testGetProfileWhenProfileNotAvailable() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        variables.put("isProfileAvailable", "false");
        when(delegateExecution.getVariables()).thenReturn(variables);

        AssociateBenefitsProfile profile = CommonUtils.getProfile(delegateExecution);

        Assertions.assertNull(profile);
    }

    @Test
     void testGetProfileWhenVariablesIsNull() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        when(delegateExecution.getVariables()).thenReturn(null);
        assertThrows(NullPointerException.class, () -> {
            CommonUtils.getProfile(delegateExecution);
        });
    }

    @Test
     void testGetProfileWhenIsProfileAvailableIsNull() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        variables.put("getAssociateProfileResponse", new AssociateBenefitsProfile());
        when(delegateExecution.getVariables()).thenReturn(variables);

        AssociateBenefitsProfile profile = CommonUtils.getProfile(delegateExecution);

        Assertions.assertNull(profile);
    }


    @Test
    void testGetCoverageWhenCoverageAvailable() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setPlanType(PlanType.DISABILITY_STD_US);
        String isCoverageAvailable = "true";
        Map<String, Object> variables = new HashMap<>();
        AssociateBenefit expectedCoverage = new AssociateBenefit();
        expectedCoverage.setPlanId(PlanType.DISABILITY_STD_US.getPlanId());
        List<AssociateBenefit> allAvailableCoverages = List.of(expectedCoverage);
        variables.put(COVERAGE_RESPONSE_LIST, allAvailableCoverages);

        CommonUtils.Coverage coverage = CommonUtils.getCoverage(associateEvent, isCoverageAvailable, variables);

        Assertions.assertNotNull(coverage.coverage());
        assertEquals(expectedCoverage, coverage.coverage());
        assertEquals(allAvailableCoverages, coverage.allRetirementCoveragesList());
        assertEquals(PlanType.DISABILITY_STD_US.name(), coverage.planTypeStr().toUpperCase());
    }

    @Test
    void testGetCoverageWhenCoverageNotAvailable() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setPlanType(PlanType.DISABILITY_STD_US);
        String isCoverageAvailable = "false";
        Map<String, Object> variables = new HashMap<>();

        CommonUtils.Coverage coverage = CommonUtils.getCoverage(associateEvent, isCoverageAvailable, variables);

        Assertions.assertNull(coverage.coverage());
        Assertions.assertNull(coverage.allRetirementCoveragesList());
        assertEquals(PlanType.DISABILITY_STD_US.name(), coverage.planTypeStr().toUpperCase());
    }

}