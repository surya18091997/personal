package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.constants.WorkflowConstants;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.external.datalake.DataLakeJsonReader;
import com.walmart.benefits.platform.core.engine.service.external.datalake.DataLakeJsonReaderFactory;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.RuntimeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Mockito.*;

class AsyncBatchProcessorServiceTest {

    private AsyncBatchProcessorService asyncBatchProcessorService;

    @Mock
    private RuntimeService runtimeService;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private EventArchiveService eventArchiveService;

    @Mock
    private DataLakeJsonReaderFactory dataLakeJsonReaderFactory;

    @Mock
    private DataLakeJsonReader dataLakeJsonReader;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        asyncBatchProcessorService = new AsyncBatchProcessorService(runtimeService, encryptionUtil, eventArchiveService, dataLakeJsonReaderFactory);
    }

    @Test
    void testProcessEvents_EmptyEvents() {
        // Act
        asyncBatchProcessorService.processEvents(Collections.emptyList());

        // Assert
        verifyNoInteractions(runtimeService, encryptionUtil, eventArchiveService, dataLakeJsonReaderFactory);
    }

    @Test
    void testProcessEvents_ValidEvents() throws Exception {
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            // Arrange
            Event event = new Event();
            event.setEventType(EventType.RE_HIRE);
            event.setAssociateId("123");

            mockedCommonUtils.when(() -> CommonUtils.validEventType(EventType.RE_HIRE)).thenReturn(true);
            when(dataLakeJsonReaderFactory.getDataLakeJsonReader(EventType.RE_HIRE)).thenReturn(dataLakeJsonReader);
            when(dataLakeJsonReader.readDataLakeJsonFiles()).thenReturn("cacheKey");
            when(eventArchiveService.toAssociateEvent(event)).thenReturn(new AssociateEvent());
            when(encryptionUtil.encrypt("123")).thenReturn("encryptedId");

            // Act
            asyncBatchProcessorService.processEvents(List.of(event));

            // Assert
            verify(runtimeService).startProcessInstanceByKey(eq(WorkflowConstants.WORKFLOW_SELECTOR), any(HashMap.class));
            verify(encryptionUtil).encrypt("123");
            verify(eventArchiveService).toAssociateEvent(event);
            verify(dataLakeJsonReaderFactory).getDataLakeJsonReader(EventType.RE_HIRE);
        }
    }

    @Test
    void testProcessEvents_InvalidEventType() {
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            // Arrange
            Event event = new Event();
            event.setEventType(EventType.NONE);

            mockedCommonUtils.when(() -> CommonUtils.validEventType(EventType.RE_HIRE)).thenReturn(false);

            // Act
            asyncBatchProcessorService.processEvents(List.of(event));

            // Assert
            verifyNoInteractions(runtimeService, encryptionUtil, eventArchiveService, dataLakeJsonReaderFactory);
        }
    }

    @Test
    void testProcessEvents_ExceptionDuringDataLakeJsonReader() throws Exception {
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            // Arrange
            Event event = new Event();
            event.setEventType(EventType.RE_HIRE);

            mockedCommonUtils.when(() -> CommonUtils.validEventType(EventType.RE_HIRE)).thenReturn(true);
            when(dataLakeJsonReaderFactory.getDataLakeJsonReader(EventType.RE_HIRE)).thenThrow(new RuntimeException("DataLake error"));

            // Act
            asyncBatchProcessorService.processEvents(List.of(event));

            // Assert
            verifyNoInteractions(runtimeService, encryptionUtil, eventArchiveService);
        }
    }

    @Test
    void testProcessEvents_ExceptionDuringEventProcessing() throws Exception {
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
        // Arrange
            Event event = new Event();
            event.setEventType(EventType.RE_HIRE);
            event.setAssociateId("123");

            mockedCommonUtils.when(() -> CommonUtils.validEventType(EventType.RE_HIRE)).thenReturn(true);
            when(dataLakeJsonReaderFactory.getDataLakeJsonReader(EventType.RE_HIRE)).thenReturn(dataLakeJsonReader);
            when(dataLakeJsonReader.readDataLakeJsonFiles()).thenReturn("cacheKey");
            when(eventArchiveService.toAssociateEvent(event)).thenThrow(new RuntimeException("Event processing error"));

            // Act
            asyncBatchProcessorService.processEvents(List.of(event));

            // Assert
            verify(dataLakeJsonReaderFactory).getDataLakeJsonReader(EventType.RE_HIRE);
            verify(dataLakeJsonReader).readDataLakeJsonFiles();
            verifyNoInteractions(runtimeService);
        }
    }
}