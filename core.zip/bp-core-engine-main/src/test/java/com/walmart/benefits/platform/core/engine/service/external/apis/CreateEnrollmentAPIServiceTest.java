package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CreateEnrollmentAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    private CreateEnrollmentAPIService createEnrollmentAPIService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        createEnrollmentAPIService = new CreateEnrollmentAPIService(restTemplate, httpUtils,encryptionUtil);
    }

    @Test
    void testExecute_Success() throws Exception {
        // Mock variables and data
        Map<String, Object> variables = new HashMap<>();
        Enrollment enrollment = mock(Enrollment.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        ResponseEntity<String> successResponse = new ResponseEntity<>(HttpStatus.OK);

        variables.put(CREATE_ENROLLMENT, enrollment);
        variables.put(ASSOCIATE_EVENT, associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(httpUtils.getEnrollmentUrl()).thenReturn("http://mock-enrollment-url");
        when(httpUtils.getTransactionLogUrl()).thenReturn("http://mock-transaction-log-url");
        when(httpUtils.getHttpEntity(eq(enrollment), anyString())).thenReturn(null);
        when(httpUtils.getHttpEntity(any(), anyString())).thenReturn(null);
        when(restTemplate.exchange("http://mock-enrollment-url", HttpMethod.POST, null, String.class)).thenReturn(successResponse);
        when(restTemplate.exchange("http://mock-transaction-log-url", HttpMethod.POST, null, String.class)).thenReturn(successResponse);

        // Execute the service
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class);
             MockedStatic<TransactionLogUtil> mockedTransactionLogUtil = mockStatic(TransactionLogUtil.class)) {
            createEnrollmentAPIService.execute(delegateExecution);
        }

        // Verify interactions
        verify(delegateExecution, times(1)).getVariables();
        verify(restTemplate, times(1)).exchange("http://mock-enrollment-url", HttpMethod.POST, null, String.class);
        verify(restTemplate, times(1)).exchange("http://mock-transaction-log-url", HttpMethod.POST, null, String.class);
    }

    @Test
    void testExecute_HttpServerErrorException() throws Exception {
        // Mock variables and data
        Map<String, Object> variables = new HashMap<>();
        Enrollment enrollment = mock(Enrollment.class);
        AssociateEvent associateEvent = mock(AssociateEvent.class);

        variables.put(CREATE_ENROLLMENT, enrollment);
        variables.put(ASSOCIATE_EVENT, associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(httpUtils.getEnrollmentUrl()).thenReturn("http://mock-enrollment-url");
        when(httpUtils.getHttpEntity(eq(enrollment), anyString())).thenReturn(null);
        when(restTemplate.exchange("http://mock-enrollment-url", HttpMethod.POST, null, String.class))
                .thenThrow(HttpServerErrorException.class);

        // Execute the service
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            createEnrollmentAPIService.execute(delegateExecution);
        }

        // Verify interactions
        verify(delegateExecution, times(1)).getVariables();
        verify(httpUtils, times(1)).handleError(any(), any(), anyInt(), eq(ASSOCIATE_ENROLLMENT_SERVICE_CREATE_SERVER_ERROR));
    }

    @Test
    void testExecuteGenericException() throws Exception {
        // Mock variables and data
        Map<String, Object> variables = new HashMap<>();
        Enrollment enrollment = mock(Enrollment.class);

        variables.put(CREATE_ENROLLMENT, enrollment);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(httpUtils.getEnrollmentUrl()).thenThrow(new RuntimeException("Mock Exception"));

        // Execute the service
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            assertThrows(RuntimeException.class, () -> {
                createEnrollmentAPIService.execute(delegateExecution);
            });

        }
    }
}
