package com.walmart.benefits.platform.core.engine.utils;

import com.google.api.gax.paging.Page;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DataLakeJsonUtilTest {

    @Mock
    private Storage mockStorage;

    @Mock
    private Bucket mockBucket;

    @Mock
    private Blob mockBlob;

    private DataLakeJsonUtil dataLakeJsonUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dataLakeJsonUtil = new DataLakeJsonUtil(mockStorage);
    }

    @Test
    void testReadDataLakeJsonFromGcs_Success() throws IOException {
        String gcsFolderPath = "test-bucket/folder";
        String jsonContent = "{\"key\":\"value\"}";

        // Mock the Page<Blob> object
        Page<Blob> mockPage = mock(Page.class);

        when(mockStorage.get("test-bucket")).thenReturn(mockBucket);
        when(mockBucket.list(any())).thenReturn(mockPage);
        when(mockPage.iterateAll()).thenReturn(List.of(mockBlob));
        when(mockBlob.getName()).thenReturn("folder/file.json");
        when(mockBlob.getContent()).thenReturn(jsonContent.getBytes());

        List<Object> result = dataLakeJsonUtil.readDataLakeJsonFromGcs(gcsFolderPath, null, null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertInstanceOf(Map.class, result.get(0));
        assertEquals("value", ((Map<?, ?>) result.get(0)).get("key"));
    }

    @Test
    void testReadDataLakeJsonFromGcs_InvalidBucket() {
        String gcsFolderPath = "invalid-bucket/folder";

        when(mockStorage.get("invalid-bucket")).thenReturn(null);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                dataLakeJsonUtil.readDataLakeJsonFromGcs(gcsFolderPath, null, null));

        assertEquals("Bucket not found: invalid-bucket", exception.getMessage());
    }

//    @Test
//    void testReadDataLakeJsonFromGcs_InvalidJson() {
//        String gcsFolderPath = "test-bucket/folder";
//        String invalidJsonContent = "{invalid-json}";
//        Page<Blob> mockPage = mock(Page.class);
//        when(mockStorage.get("test-bucket")).thenReturn(mockBucket);
//        when(mockBucket.list(any())).thenReturn(mockPage);
//        when(mockPage.iterateAll()).thenReturn(List.of(mockBlob));
//        when(mockBlob.getName()).thenReturn("folder/file.json");
//        when(mockBlob.getContent()).thenReturn(invalidJsonContent.getBytes());
//
//        IOException exception = assertThrows(IOException.class, () ->
//                dataLakeJsonUtil.readDataLakeJsonFromGcs(gcsFolderPath, null, null));
//
//        assertTrue(exception.getMessage().contains("Failed"));
//    }

    @Test
    void testStoreDataInCache() {
        Map<String, List<Object>> data = Map.of("key", List.of("value"));

        String cacheKey = dataLakeJsonUtil.storeDataInCache(data);

        assertNotNull(cacheKey);
        assertTrue(cacheKey.startsWith("dataLakeJson_"));
        assertEquals(data, dataLakeJsonUtil.getDataFromCache(cacheKey));
    }

    @Test
    void testGetDataFromCache_NonExistentKey() {
        assertNull(dataLakeJsonUtil.getDataFromCache("non_existent_key"));
    }

    @Test
    void testRemoveFromCache() {
        Map<String, List<Object>> data = Map.of("key", List.of("value"));

        String cacheKey = dataLakeJsonUtil.storeDataInCache(data);
        assertNotNull(dataLakeJsonUtil.getDataFromCache(cacheKey));

        dataLakeJsonUtil.removeFromCache(cacheKey);
        assertNull(dataLakeJsonUtil.getDataFromCache(cacheKey));
    }

    @Test
    void testClearCache() {
        Map<String, List<Object>> data1 = Map.of("key1", List.of("value1"));
        Map<String, List<Object>> data2 = Map.of("key2", List.of("value2"));

        String cacheKey1 = dataLakeJsonUtil.storeDataInCache(data1);
        String cacheKey2 = dataLakeJsonUtil.storeDataInCache(data2);

        assertNotNull(dataLakeJsonUtil.getDataFromCache(cacheKey1));
        assertNotNull(dataLakeJsonUtil.getDataFromCache(cacheKey2));

        dataLakeJsonUtil.clearCache();

        assertNull(dataLakeJsonUtil.getDataFromCache(cacheKey1));
        assertNull(dataLakeJsonUtil.getDataFromCache(cacheKey2));
    }
}