package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

class DefaultNewHireRuleRequestProcessorTest {

    private DefaultNewHireRuleRequestProcessor processor;
    private DelegateExecution delegateExecution;

    @BeforeEach
    void setUp() {
        processor = new DefaultNewHireRuleRequestProcessor();
        delegateExecution = mock(DelegateExecution.class);
    }



    @Test
    void getPlanType_returnsNull() {
        assertNull(processor.getPlanType());
    }
}