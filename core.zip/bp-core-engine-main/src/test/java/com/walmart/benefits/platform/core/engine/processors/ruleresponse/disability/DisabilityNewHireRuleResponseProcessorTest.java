package com.walmart.benefits.platform.core.engine.processors.ruleresponse.disability;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.CoverageOption;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DisabilityNewHireRuleResponseProcessorTest {

    private DisabilityNewHireRuleResponseProcessor processor;
    private DelegateExecution delegateExecution;
    private AssociateEligibilityOutput associateEligibilityOutput;

    @BeforeEach
    void setUp() {
        processor = new DisabilityNewHireRuleResponseProcessor();
        delegateExecution = mock(DelegateExecution.class);
        associateEligibilityOutput = new AssociateEligibilityOutput();
    }

    @Test
    void process_withEnrollmentRequired() {
        associateEligibilityOutput.setIsEnrollmentRequired(true);
        associateEligibilityOutput.setTier(Tier.ASSOCIATE.name());
        associateEligibilityOutput.setCoverageOption(CoverageOption.LTD_BASIC.name());

        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.DISABILITY_STD_US.name());
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_ELECTIONS)).thenReturn(new ArrayList<PlanElection>());

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(eq(ApplicationConstants.PLAN_ELECTIONS), anyList());
    }

    @Test
    void process_withoutEnrollmentRequired() {
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.DISABILITY_STD_US.name());
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_ELECTIONS)).thenReturn(new ArrayList<PlanElection>());
        associateEligibilityOutput.setIsEnrollmentRequired(false);

        processor.process(delegateExecution);

        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.PLAN_ELECTIONS), anyList());
    }

    @Test
    void process_withNullPlanType() {
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);

        assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void getPlanType_returnsDisability() {
        assertEquals(ApplicationConstants.DISABILITY, processor.getPlanType());
    }
}