package com.walmart.benefits.platform.core.engine.controllers;

import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.service.common.AsyncBatchProcessorService;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class BatchWorkflowTriggerControllerTest {

    private BatchWorkflowTriggerController controller;

    @Mock
    private EventArchiveDao eventArchiveDao;

    @Mock
    private AsyncBatchProcessorService asyncBatchProcessorService;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private RetryTemplate retryTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        controller = new BatchWorkflowTriggerController(eventArchiveDao, asyncBatchProcessorService, httpUtils,retryTemplate);
    }

    @Test
    void testGetEventsByTypeAndStatus_ValidRequest() {
        // Arrange
        Event event = new Event();
        when(eventArchiveDao.findByEventTypeAndEventStatus_subPlanType(EventType.RE_HIRE, Status.QUEUED))
                .thenReturn(List.of(event));
        // Mock retryTemplate to execute the lambda and return the events
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback<List<Event>, RuntimeException>) invocation.getArgument(0)).doWithRetry(null);
        });
        // Act
        ResponseEntity<String> response = controller.getEventsByTypeAndStatus("RE_HIRE");

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        verify(asyncBatchProcessorService).processEvents(List.of(event));
    }

    @Test
    void testGetEventsByTypeAndStatus_NoEventsFound() {
        // Arrange
        when(eventArchiveDao.findByEventTypeAndEventStatus_subPlanType(EventType.RE_HIRE, Status.QUEUED))
                .thenReturn(Collections.emptyList());

        // Act
        ResponseEntity<String> response = controller.getEventsByTypeAndStatus("RE_HIRE");

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        verifyNoInteractions(asyncBatchProcessorService);
    }

    @Test
    void testGetEventsByTypeAndStatus_InvalidEventType() {
        // Act
        ResponseEntity<String> response = controller.getEventsByTypeAndStatus("INVALID_TYPE");

        // Assert
        assertEquals(400, response.getStatusCodeValue());
        verifyNoInteractions(eventArchiveDao, asyncBatchProcessorService);
    }

    @Test
    void testGetEventsByTypeAndStatus_ExceptionThrown() {
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback<List<Event>, RuntimeException>) invocation.getArgument(0)).doWithRetry(null);
        });
        // Arrange
        when(eventArchiveDao.findByEventTypeAndEventStatus_subPlanType(EventType.RE_HIRE, Status.QUEUED))
                .thenThrow(new RuntimeException("Database error"));

        // Act
        ResponseEntity<String> response = controller.getEventsByTypeAndStatus("RE_HIRE");
        // Mock retryTemplate to execute the lambda and return the events

        // Assert
        assertEquals(500, response.getStatusCodeValue());
        assertEquals("An error occurred while processing events. Please try again later.", response.getBody());
        verifyNoInteractions(asyncBatchProcessorService);
    }
}