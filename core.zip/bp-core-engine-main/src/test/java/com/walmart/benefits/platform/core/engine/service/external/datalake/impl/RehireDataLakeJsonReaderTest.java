package com.walmart.benefits.platform.core.engine.service.external.datalake.impl;

import com.walmart.benefits.platform.core.engine.utils.DataLakeJsonUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RehireDataLakeJsonReaderTest {

    private RehireDataLakeJsonReader rehireDataLakeJsonReader;
    private DataLakeJsonUtil mockDataLakeJsonUtil;

    @BeforeEach
    void setUp() {
        mockDataLakeJsonUtil = mock(DataLakeJsonUtil.class);
        rehireDataLakeJsonReader = new RehireDataLakeJsonReader(mockDataLakeJsonUtil);
    }

    @Test
    void testReadDataLakeJsonFiles_Success() throws IOException {
        // Mock data
        List<Object> mockProfileData = List.of(new AssociateBenefitsProfile());
        List<Object> mockPostPayrollData = List.of(new PostPayrollSnapshot());
        Map<String, List<Object>> mockCacheData = Map.of(
                PROFILE_HUDI_JSON, mockProfileData,
                POST_PAYROLL_SNAPSHOT_HUDI_JSON, mockPostPayrollData
        );

        // Mock behavior
        when(mockDataLakeJsonUtil.readDataLakeJsonFromGcs(
                anyString(), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN)))
                .thenReturn(mockProfileData);
        when(mockDataLakeJsonUtil.readDataLakeJsonFromGcs(
                anyString(), eq(PostPayrollSnapshot.class), eq(RAW_DOCUMENT_HUDI_COLUMN)))
                .thenReturn(mockPostPayrollData);
        when(mockDataLakeJsonUtil.storeDataInCache(mockCacheData)).thenReturn("cacheKey");

        // Execute
        String result = rehireDataLakeJsonReader.readDataLakeJsonFiles();

        // Verify
        assertNotNull(result);
        assertEquals("cacheKey", result);
        verify(mockDataLakeJsonUtil, times(1)).readDataLakeJsonFromGcs(
                contains(PROFILE_HUDI_JSON), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN));
        verify(mockDataLakeJsonUtil, times(1)).readDataLakeJsonFromGcs(
                contains(POST_PAYROLL_SNAPSHOT_HUDI_JSON), eq(PostPayrollSnapshot.class), eq(RAW_DOCUMENT_HUDI_COLUMN));
        verify(mockDataLakeJsonUtil, times(1)).storeDataInCache(mockCacheData);
    }

    @Test
    void testReadDataLakeJsonFiles_ProfileDataIOException() throws IOException {
        // Mock behavior
        when(mockDataLakeJsonUtil.readDataLakeJsonFromGcs(
                anyString(), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN)))
                .thenThrow(new IOException("Profile data error"));

        // Execute and verify
        IOException exception = assertThrows(IOException.class, () -> rehireDataLakeJsonReader.readDataLakeJsonFiles());
        assertEquals("Error reading profile data from Data Lake JSON", exception.getMessage());
        verify(mockDataLakeJsonUtil, times(1)).readDataLakeJsonFromGcs(
                contains(PROFILE_HUDI_JSON), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN));
    }

    @Test
    void testReadDataLakeJsonFiles_PostPayrollDataIOException() throws IOException {
        // Mock data
        List<Object> mockProfileData = List.of(new AssociateBenefitsProfile());

        // Mock behavior
        when(mockDataLakeJsonUtil.readDataLakeJsonFromGcs(
                anyString(), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN)))
                .thenReturn(mockProfileData);
        when(mockDataLakeJsonUtil.readDataLakeJsonFromGcs(
                anyString(), eq(PostPayrollSnapshot.class), eq(RAW_DOCUMENT_HUDI_COLUMN)))
                .thenThrow(new IOException("Post payroll data error"));

        // Execute and verify
        IOException exception = assertThrows(IOException.class, () -> rehireDataLakeJsonReader.readDataLakeJsonFiles());
        assertEquals("Error reading post payroll snapshot data from Data Lake JSON", exception.getMessage());
        verify(mockDataLakeJsonUtil, times(1)).readDataLakeJsonFromGcs(
                contains(PROFILE_HUDI_JSON), eq(AssociateBenefitsProfile.class), eq(RAW_DOCUMENT_HUDI_COLUMN));
        verify(mockDataLakeJsonUtil, times(1)).readDataLakeJsonFromGcs(
                contains(POST_PAYROLL_SNAPSHOT_HUDI_JSON), eq(PostPayrollSnapshot.class), eq(RAW_DOCUMENT_HUDI_COLUMN));
    }
}