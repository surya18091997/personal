package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.ProcessEngineException;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class PatchCoverageHistoryTest {

    @Mock
    private RestTemplate restTemplate;
    @Mock
    private HttpUtils httpUtils;
    @Mock
    private EncryptionUtil encryptionUtil;
    @Mock
    private DelegateExecution delegateExecution;
    @Mock
    private AssociateEvent associateEvent;
    @Mock
    private PlanType planType;

    @InjectMocks
    private PatchCoverageHistoryService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Set up common mocks
        when(associateEvent.getAssociateId()).thenReturn("12345");
        when(associateEvent.getPlanType()).thenReturn(planType);
        when(planType.getPlanId()).thenReturn("plan1");
    }

    @Test
    void successfulResponseSetsCoverageHistoryAvailableToTrue() throws Exception {
        try (MockedStatic<EventUtils> eventUtilsMocked = mockStatic(EventUtils.class);
             MockedStatic<ProcessEngineUtil> processUtilMocked = mockStatic(ProcessEngineUtil.class)) {

            // Setup - Add event type mock which is critical for the factory method
            when(associateEvent.getEventType()).thenReturn(EventType.LOAN); // Set a specific event type
            AssociateBenefit mockPayload = mock(AssociateBenefit.class);
            eventUtilsMocked.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(mockPayload);
            processUtilMocked.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            // Add loan sequence number mock since we're testing with EventType.LOAN
            when(delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER)).thenReturn("123");
            when(httpUtils.getCoverageHistoryUrl()).thenReturn("http://test.com/coverage/history");
            when(httpUtils.getHttpEntity(mockPayload, "benefitService")).thenReturn(new HttpEntity<>(mockPayload));
            when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("benefitService");

            ResponseEntity<AssociateBenefit> response = new ResponseEntity<>(HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(AssociateBenefit.class)))
                    .thenReturn(response);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(delegateExecution).setVariable(IS_COVERAGE_HISTORY_AVAILABLE, TRUE);
        }
    }

    @Test
    void serverErrorCallsHttpUtilsHandleError() throws Exception {
        try (MockedStatic<EventUtils> eventUtilsMocked = mockStatic(EventUtils.class);
             MockedStatic<ProcessEngineUtil> processUtilMocked = mockStatic(ProcessEngineUtil.class)) {

            // Setup
            when(associateEvent.getEventType()).thenReturn(EventType.LOAN); // Adding event type
            AssociateBenefit mockPayload = mock(AssociateBenefit.class);
            eventUtilsMocked.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(mockPayload);
            int retryCount = 2;
            processUtilMocked.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(retryCount);

            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER)).thenReturn("123");
            when(httpUtils.getCoverageHistoryUrl()).thenReturn("http://test.com/coverage/history");
            when(httpUtils.getHttpEntity(mockPayload, "benefitService")).thenReturn(null);
            when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("benefitService");

            HttpServerErrorException serverError = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(AssociateBenefit.class)))
                    .thenThrow(serverError);

            // Set up the mock to throw an exception
            doThrow(new ProcessEngineException("Error Message is null")).when(httpUtils)
                    .handleError(eq(delegateExecution), eq(serverError), eq(retryCount),
                            eq(ASSOCIATE_COVERAGE_SERVICE_GET_SERVER_ERROR));

            // Execute and verify exception
            Exception exception = assertThrows(ProcessEngineException.class, () -> service.execute(delegateExecution));
            assertEquals("Error Message is null", exception.getMessage());
        }
    }

    @Test
    void notFoundErrorSetsCoverageHistoryAvailableToFalse() throws Exception {
        try (MockedStatic<EventUtils> eventUtilsMocked = mockStatic(EventUtils.class);
             MockedStatic<ProcessEngineUtil> processUtilMocked = mockStatic(ProcessEngineUtil.class)) {

            // Setup
            when(associateEvent.getEventType()).thenReturn(EventType.LOAN); // Adding event type
            AssociateBenefit mockPayload = mock(AssociateBenefit.class);
            eventUtilsMocked.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(mockPayload);
            processUtilMocked.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER)).thenReturn("123");
            when(httpUtils.getCoverageHistoryUrl()).thenReturn("http://test.com/coverage/history");
            when(httpUtils.getHttpEntity(mockPayload, "benefitService")).thenReturn(null);
            when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("benefitService");

            HttpClientErrorException notFoundException = new HttpClientErrorException(HttpStatus.NOT_FOUND);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(AssociateBenefit.class)))
                    .thenThrow(notFoundException);

            // Execute
            service.execute(delegateExecution);

            // Verify - using atLeastOnce() since the method is called multiple times
            verify(delegateExecution, atLeastOnce()).setVariable(IS_COVERAGE_HISTORY_AVAILABLE, FALSE);
        }
    }

    @Test
    void loanEventWithSequenceNumberIncludesLoanParameters() throws Exception {
        try (MockedStatic<EventUtils> eventUtilsMocked = mockStatic(EventUtils.class);
             MockedStatic<ProcessEngineUtil> processUtilMocked = mockStatic(ProcessEngineUtil.class)) {

            // Setup
            AssociateBenefit mockPayload = mock(AssociateBenefit.class);
            eventUtilsMocked.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(mockPayload);
            processUtilMocked.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(associateEvent.getEventType()).thenReturn(EventType.LOAN);
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER)).thenReturn("123");
            when(httpUtils.getCoverageHistoryUrl()).thenReturn("http://test.com/coverage/history");
            when(httpUtils.getHttpEntity(mockPayload, "benefitService")).thenReturn(null);
            when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("benefitService");

            ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
            when(restTemplate.exchange(urlCaptor.capture(), any(), any(), eq(AssociateBenefit.class)))
                    .thenReturn(new ResponseEntity<>(HttpStatus.OK));

            // Execute
            service.execute(delegateExecution);

            // Verify URL contains the loan parameters
            String capturedUrl = urlCaptor.getValue();
            assertTrue(capturedUrl.contains("loanSequenceNumber=123"));
            assertTrue(capturedUrl.contains("loanStatusCode=C"));
            verify(delegateExecution).setVariable(IS_COVERAGE_HISTORY_AVAILABLE, TRUE);
        }
    }

    @Test
    void loanEventTypeSetsUpProperMocking() throws Exception {
        try (MockedStatic<EventUtils> eventUtilsMocked = mockStatic(EventUtils.class);
             MockedStatic<ProcessEngineUtil> processUtilMocked = mockStatic(ProcessEngineUtil.class)) {

            // Setup for loan event type
            when(associateEvent.getEventType()).thenReturn(EventType.LOAN);
            AssociateBenefit mockPayload = mock(AssociateBenefit.class);
            eventUtilsMocked.when(() -> EventUtils.targetPatchOnCoverage(associateEvent)).thenReturn(mockPayload);
            processUtilMocked.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent));
            when(delegateExecution.getVariable(LOAN_MODEL_LOAN_SEQUENCE_NUMBER)).thenReturn("123");
            when(httpUtils.getCoverageHistoryUrl()).thenReturn("http://test.com/coverage/history");
            when(httpUtils.getHttpEntity(mockPayload, "benefitService")).thenReturn(null);
            when(httpUtils.getAssociateBenefitServiceAppName()).thenReturn("benefitService");

            ResponseEntity<AssociateBenefit> response = new ResponseEntity<>(HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(AssociateBenefit.class)))
                    .thenReturn(response);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(delegateExecution).setVariable(IS_COVERAGE_HISTORY_AVAILABLE, TRUE);
            verify(restTemplate).exchange(contains("loanSequenceNumber=123"), eq(HttpMethod.POST), any(), eq(AssociateBenefit.class));
        }
    }


    @Test
    void executeHandlesGeneralException() throws Exception {
        when(delegateExecution.getVariables()).thenThrow(new RuntimeException("Unexpected error"));

        assertThrows(RuntimeException.class, () -> service.execute(delegateExecution));
    }
}