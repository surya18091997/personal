package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.processors.event.EventProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementNewHireEventProcessor;
import com.walmart.benefits.platform.core.engine.service.common.EventProcessorService;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.List;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class EventProcessorServiceTest {

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private EventProcessorFactory eventProcessorFactory;

    @InjectMocks
    private EventProcessorService eventProcessorService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        var map = new HashMap<String, Object>();
        var associateEvent = new AssociateEvent();
        var benefitsEntity= new BenefitsEntity();
        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(List.of(new PlanEligibility()));
        associateBenefitsProfile.setEligibility(eligibility);
        intraDomainInfo.setAssociateBenefitsProfile(associateBenefitsProfile);

        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        associateInfo.setAssociateId("123");
        interDomainInfo.setAssociateInfo(associateInfo);

        benefitsEntity.setInterDomainInfo(interDomainInfo);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);

        associateEvent.setEventType(EventType.NEW_HIRE);
        map.put(ASSOCIATE_EVENT, associateEvent);
        map.put(BENEFITS_ENTITY, benefitsEntity);
        when(delegateExecution.getVariables()).thenReturn(map);
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn("401k");

        eventProcessorService = new EventProcessorService(eventProcessorFactory);
        when(eventProcessorFactory.getProcessor("401k", EventType.NEW_HIRE)).thenReturn(new RetirementNewHireEventProcessor());
    }

    @Test
    void validate401kProcessorTriggered() throws Exception {
        eventProcessorService.execute(delegateExecution);
        verify(eventProcessorFactory, times(1)).getProcessor("401k", EventType.NEW_HIRE);
    }

    @Test
    void validateWithNullDelegateExecution() {
        assertThrows(NullPointerException.class, () -> {
            eventProcessorService.execute(null);
        });
    }

    @Test
    void validateWithNullProcessors() {
        EventProcessorService coreProcessorService = new EventProcessorService(null);
        assertThrows(BpmnError.class, () -> {
            coreProcessorService.execute(delegateExecution);
        });
    }
}