package com.walmart.benefits.platform.core.engine.utils;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.BENEFITS_ENTITY;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.SYSTEM_CORE_ENGINE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.PersonalInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.LoanStatusCode;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.OriginSystem;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.TransactionLog;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Map;

class TransactionLogUtilTest {


    private BenefitsEntity benefitsEntity;

    private DelegateExecution delegateExecution;

    @BeforeEach
    void setUp() {
        delegateExecution = Mockito.mock(DelegateExecution.class);
    }


    @Test
    void testGetTransactionLogCoverageForRateChangeEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.RATE_CHANGE);

        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setPlanId("123");
        associateBenefit.setPlanGroup("Plan Name");
        associateBenefit.setAssociateId("12345");
        associateBenefit.setCreatedBy("createdBy");
        associateBenefit.setLastModifiedBy("lastModifiedBy");
        associateBenefit.setCreatedAt("2022-01-01T00:00:00Z");
        associateBenefit.setLastModifiedAt("2022-01-02T00:00:00Z");

        Enrollment enrollment = new Enrollment();
        enrollment.setOriginSystem(OriginSystem.OE);




        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogCoverage(associateBenefit, associateEvent, enrollment,delegateExecution);
        assertEquals("123", transactionLog.getPlanId());
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals("SYSTEM_CORE_ENGINE", transactionLog.getCreatedBy());
        //assertEquals("2022-01-01T00:00:00Z", transactionLog.getCreatedAt());
    }
    @Test
    void testGetTransactionLogCoverageForNewHireEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.NEW_HIRE);

        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setPlanId("None");
        associateBenefit.setPlanGroup(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup());
        associateBenefit.setAssociateId("12345");

        Enrollment enrollment = null;

        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogCoverage(associateBenefit, associateEvent, enrollment,delegateExecution);
        assertEquals("None", transactionLog.getPlanId());
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(Activity.NEW_HIRE, transactionLog.getActivity());
        assertEquals(SYSTEM_CORE_ENGINE, transactionLog.getCreatedBy());
    }

    @Test
    void testGetTransactionLogEnrollment() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.RATE_CHANGE);
        associateEvent.setTimeStamp("2022-01-01T00:00:00Z");
        associateEvent.setOrigin(EventOrigin.ML);

        Enrollment createEnrollment = new Enrollment();
        createEnrollment.setAssociateId("12345");
        createEnrollment.setCreatedBy("ML");
        createEnrollment.setCreatedAt("2022-01-01T00:00:00Z");

        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogEnrollment(createEnrollment, associateEvent);
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals("ML", transactionLog.getCreatedBy());
        assertEquals("2022-01-01T00:00:00Z", transactionLog.getCreatedAt());
    }

    @Test
    void getTransactionLogEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("123");
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        associateEvent.setEventType(EventType.RATE_CHANGE);
        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogEvent(associateEvent);
        assertEquals("123", transactionLog.getAssociateId());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), transactionLog.getPlanId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals(SYSTEM_CORE_ENGINE, transactionLog.getCreatedBy());
    }

    @Test
    void testGetTransactionLogCoverageForLoanEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.LOAN);

        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setPlanId("123");
        associateBenefit.setAssociateId("12345");
        associateBenefit.setLoanStatusCode(LoanStatusCode.A);

        Enrollment enrollment = null;

        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogCoverage(associateBenefit, associateEvent, enrollment, delegateExecution);

        assertEquals("123", transactionLog.getPlanId());
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(Activity.LOAN_DEDUCTION, transactionLog.getActivity());
        assertEquals(SYSTEM_CORE_ENGINE, transactionLog.getCreatedBy());
    }


    @Test
    void testGetTransactionLogCoverageForEnrollmentCompleteEvent() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.ENROLLMENT_COMPLETE);
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);

        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setPlanId("123");
        associateBenefit.setAssociateId("12345");
        associateBenefit.setCreatedBy("OE");
        Enrollment enrollment = new Enrollment();
        enrollment.setOriginSystem(OriginSystem.OE);

        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogCoverage(associateBenefit, associateEvent, enrollment, delegateExecution);

        assertEquals("123", transactionLog.getPlanId());
        assertEquals("12345", transactionLog.getAssociateId());
        assertEquals(Activity.RATE_CHANGE, transactionLog.getActivity());
        assertEquals("OE", transactionLog.getCreatedBy());
    }

    @Test
    void testgetTransactionLogEvent(){
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.RATE_CHANGE);
        associateEvent.setTimeStamp("2022-01-01T00:00:00Z");
        associateEvent.setOrigin(EventOrigin.ML);
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        TransactionLog transactionLog = TransactionLogUtil.getTransactionLogEvent(associateEvent,"test");
        assertEquals("12345", transactionLog.getAssociateId());

    }

}