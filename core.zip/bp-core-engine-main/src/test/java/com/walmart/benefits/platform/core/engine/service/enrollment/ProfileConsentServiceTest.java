package com.walmart.benefits.platform.core.engine.service.enrollment;

import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Consent;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProfileConsentServiceTest {

    @Test
    void execute() {
    }

    @Test
    void execute_setsProfileConsentAvailableWhenEnrollmentHasConsent() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Enrollment enrollment = new Enrollment();
        enrollment.setConsent(new Consent());

        when(delegateExecution.getVariables()).thenReturn(Map.of(ENROLLMENT, enrollment));

        new ProfileConsentService().execute(delegateExecution);

        verify(delegateExecution).setVariable(IS_PROFILE_CONSENT_AVAILABLE, TRUE);
        verify(delegateExecution).setVariable(eq(ASSOCIATE_BENEFITS_PROFILE), any());
    }

    @Test
    void execute_setsProfileConsentUnavailableWhenEnrollmentIsNull() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);

        when(delegateExecution.getVariables()).thenReturn(Map.of());

        new ProfileConsentService().execute(delegateExecution);

        verify(delegateExecution).setVariable(IS_PROFILE_CONSENT_AVAILABLE, FALSE);
        verify(delegateExecution, never()).setVariable(eq(ASSOCIATE_BENEFITS_PROFILE), any());
    }

    @Test
    void execute_setsProfileConsentUnavailableWhenConsentIsNull() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Enrollment enrollment = new Enrollment();

        when(delegateExecution.getVariables()).thenReturn(Map.of(ENROLLMENT, enrollment));

        new ProfileConsentService().execute(delegateExecution);

        verify(delegateExecution).setVariable(IS_PROFILE_CONSENT_AVAILABLE, FALSE);
        verify(delegateExecution, never()).setVariable(eq(ASSOCIATE_BENEFITS_PROFILE), any());
    }

    @Test
    void execute_handlesExceptionAndSetsErrorData() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);

        when(delegateExecution.getVariables()).thenThrow(new RuntimeException("Test exception"));

        assertThrows(BpmnError.class,()->new ProfileConsentService().execute(delegateExecution));


    }
}