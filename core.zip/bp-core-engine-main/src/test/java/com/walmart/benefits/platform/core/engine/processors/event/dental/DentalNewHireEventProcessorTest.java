package com.walmart.benefits.platform.core.engine.processors.event.dental;

import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Jedidiah Jeyaraj
 * @date 20/03/25
 */
public class DentalNewHireEventProcessorTest {
    private DentalNewHireEventProcessor processor;

    @BeforeEach
    void setup() {
        processor = new DentalNewHireEventProcessor();
    }

    @Test
    void testEventType() {
        Assertions.assertEquals(NEW_HIRE, processor.getEventType());
    }

    @Test
    void testPlanType() {
        Assertions.assertEquals(DENTAL, processor.getPlanType());
    }

    @Test
    public void testProcess() {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        BenefitsEntity benefitsEntity = new BenefitsEntity();

        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        associateInfo.setAssociateId("12345");
        interDomainInfo.setAssociateInfo(associateInfo);
        benefitsEntity.setInterDomainInfo(interDomainInfo);

        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId("dental_no_coverage");
        planEligibility.setPlanGroup("dental");
        planEligibility.setIsEligible(true);
        planEligibility.setEligibleDate("2023-01-01");
        eligibility.setPlans(List.of(planEligibility));
        associateBenefitsProfile.setEligibility(eligibility);
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId("12345");
        associateBenefit.setPlanId("dental_no_coverage_us");
        intraDomainInfo.setAssociateBenefit(associateBenefit);
        intraDomainInfo.setAssociateBenefitsProfile(associateBenefitsProfile);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);
        AssociateEligibilityOutput associateEligibilityOutput = new AssociateEligibilityOutput();
        associateEligibilityOutput.setAssessmentEligibility(false);

        variables.put(RULE_RESPONSE,associateEligibilityOutput);
        variables.put(BENEFITS_ENTITY, benefitsEntity);

        when(delegateExecution.getVariables()).thenReturn(variables);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class);
             MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {

            processor.process(delegateExecution);
        }

        verify(delegateExecution, times(1)).setVariables(anyMap());
    }

    @Test
    public void testAssociateCoverage() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        BenefitsEntity benefitsEntity = new BenefitsEntity();
        AssociateBenefit associateBenefit = new AssociateBenefit();
        associateBenefit.setAssociateId("12345");
        associateBenefit.setPlanId("dental_no_coverage_us");
        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
        intraDomainInfo.setAssociateBenefit(associateBenefit);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);
        Method method = DentalNewHireEventProcessor.class.getDeclaredMethod(ASSOCIATE_COVERAGE, BenefitsEntity.class);
        method.setAccessible(true);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class);
             MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {
            List<AssociateBenefit> associateBenefits = (List<AssociateBenefit>) method.invoke(processor, benefitsEntity);
            assertEquals(1, associateBenefits.size());
            assertEquals(associateBenefit, associateBenefits.get(0));
        }
    }
}
