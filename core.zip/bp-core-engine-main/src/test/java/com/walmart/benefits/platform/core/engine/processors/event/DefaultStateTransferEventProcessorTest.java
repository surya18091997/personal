package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DefaultStateTransferEventProcessorTest {
@Test
void process_logsDefaultProcessingMessageForStateTransferEvent() {
    DefaultStateTransferEventProcessor processor = new DefaultStateTransferEventProcessor();
    DelegateExecution delegateExecution = mock(DelegateExecution.class);

    processor.process(delegateExecution);

    assertEquals(EventType.STATE_TRANSFER,processor.getEventType());

    // Verify that the log contains the expected message
    // This requires a logging framework test utility or manual log inspection
}

@Test
void getPlanType_returnsNullForStateTransferEvent() {
    DefaultStateTransferEventProcessor processor = new DefaultStateTransferEventProcessor();

    assertNull(processor.getPlanType());
}
}