package com.walmart.benefits.platform.core.engine.service.enrollment;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.entity.EventStatus;
import com.walmart.benefits.platform.core.engine.service.executionlisteners.WorkFlowStartListener;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.retry.support.RetryTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class WorkFlowStartListenerTest {
    @Mock
    private EventArchiveDao eventArchiveDao;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private WorkFlowStartListener workFlowStartListener;

    @Mock
    private RetryTemplate retryTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void notify_withEventType_new_hire() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .origin(EventOrigin.CORE_HR)
                .eventType(EventType.NEW_HIRE).planType(PlanType.NONE)
                .additionalInfo(new LinkedHashMap<>())
                .build();
        Event event = new Event();
        event.setEventStatuses(new HashSet<>()); // Initialize eventStatuses
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.of(event));

        // Mock RetryTemplate to execute the lambda and return the expected value
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback) invocation.getArgument(0)).doWithRetry(null);
        });

        workFlowStartListener.notify(delegateExecution);

        verify(eventArchiveDao).save(event);
    }

    @Test
    void notify_eventNotFound_throwsEventNotFoundException() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .build();
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.empty());

        assertThrows(BpmnError.class, () -> workFlowStartListener.notify(delegateExecution));
    }

    @Test
    void execute_withEnrollmentApiOrigin_setsCreateEnrollmentVariable() throws Exception {
        String additionalInfo = "{\"locale\": \"EN_US\", \"status\": \"COMPLETED\", \"address\": null, \"consent\": null, \"version\": 1, \"activity\": \"RATE_CHANGE\", \"termsAck\": null, \"createdAt\": \"2025-02-27T10:30:23.3388330Z\", \"createdBy\": \"ML\", \"eventDate\": null, \"lifeStyle\": null, \"disability\": null, \"associateId\": \"112341496\", \"enrollmentId\": \"e038088c-e198-4f0d-a174-79e9762c9aa9\", \"originSystem\": \"ML\", \"planElections\": [{\"tier\": null, \"planId\": \"retirement_401k_regular_us\", \"tierId\": null, \"planGroup\": \"Retirement\", \"contribution\": {\"type\": \"PERCENT\", \"value\": 6.0}}], \"lastModifiedAt\": \"2025-02-27T10:30:23.3388330Z\", \"lastModifiedBy\": null, \"deviceIndicator\": null, \"externalIndicator\": false}";
        LinkedHashMap linkedHashMap = new ObjectMapper().readValue(additionalInfo, LinkedHashMap.class);
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .origin(EventOrigin.ENROLLMENT_API)
                .eventType(EventType.RATE_CHANGE)
                .additionalInfo(linkedHashMap)
                .associateId("112341496")
                .build();
        Event event = new Event();
        event.setEventStatuses(new HashSet<>());
        EventStatus eventStatus = new EventStatus();
        eventStatus.setStatus(Status.RECEIVED);
        event.getEventStatuses().add(eventStatus);

        // Mock RetryTemplate to execute the lambda and return the expected value
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback) invocation.getArgument(0)).doWithRetry(null);
        });

        Optional<Event> eventOptional = Optional.of(event);
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(eventOptional);
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));

        workFlowStartListener.notify(delegateExecution);
        verify(delegateExecution, times(2)).setVariable(any(), any());
        verify(retryTemplate, times(2)).execute(any());
        verify(eventArchiveDao).findById(associateEvent.getId());
        verify(eventArchiveDao).save(event);
    }
}