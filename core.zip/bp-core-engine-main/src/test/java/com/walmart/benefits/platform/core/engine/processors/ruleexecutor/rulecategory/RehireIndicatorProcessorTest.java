package com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.DefaultNewHireRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement.RetirementNewHireRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.DefaultNewHireRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement.RetirementNewHireRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleExecutionException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleMetadataSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RulesSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RuleExecutorFactory;
import com.walmart.benefits.rules.benefitsrulessdk.executor.services.RuleExecutorService;
import com.walmart.benefits.rules.benefitsrulessdk.mapper.factory.InputSchemaMapperFactory;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleRequest;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleResponse;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.StoreInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RehireIndicatorProcessorTest {

    @InjectMocks
    private RehireIndicatorProcessor processor;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private InterDomainInfo interDomainInfo;

    @Mock
    private AssociateInfo associateInfo;

    @Mock
    private RuleExecutorService<Object, Object> ruleExecutorService;

    @Mock
    private RehireIndicatorOutput rehireIndicatorOutput;

    @Mock
    private RuleResponse<RehireIndicatorOutput> ruleResponse;

    List requestProcessors = List.of(new RetirementNewHireRuleRequestProcessor());

    List defaultNewHireRuleRequestProcessors = List.of(new DefaultNewHireRuleRequestProcessor());

    List responseProcessor = List.of(new RetirementNewHireRuleResponseProcessor());

    List defaultNewHireRuleResponseProcessors = List.of(new DefaultNewHireRuleResponseProcessor());

    private RuleRequestProcessorFactory processorFactory = new RuleRequestProcessorFactory(requestProcessors, defaultNewHireRuleRequestProcessors);

    private RuleResponseProcessorFactory responseProcessorFactory = new RuleResponseProcessorFactory(responseProcessor, defaultNewHireRuleResponseProcessors);


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        processor = new RehireIndicatorProcessor(
                processorFactory, responseProcessorFactory, encryptionUtil
        );
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        Employment employment = new Employment();
        StoreInfo storeInfo = new StoreInfo();
        storeInfo.setStoreStateProvCd("NY");
        employment.setStoreInfo(storeInfo);
        when(associateInfo.getEmployment()).thenReturn(employment);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
    }

    @Test
    void testProcessSuccess() throws Exception {

        try (MockedStatic<InputSchemaMapperFactory> inputSchemaMapperFactoryMockedStatic = mockStatic(InputSchemaMapperFactory.class);
             MockedStatic<RuleExecutorFactory> ruleExecutorFactoryMockedStatic = mockStatic(RuleExecutorFactory.class)) {

            RehireIndicatorInput rehireIndicatorInput = new RehireIndicatorInput();

            AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
            Eligibility eligibility = new Eligibility();
            eligibility.setPlans(List.of(PlanEligibility.builder()
                    .planGroup(PlanType.RETIREMENT_401K_REGULAR_US.toString())
                    .planId(PlanType.RETIREMENT_401K_REGULAR_US.toString())
                    .isEligible(true)
                    .build()));
            associateBenefitsProfile.setEligibility(eligibility);
            IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
            intraDomainInfo.setAssociateBenefitsProfile(associateBenefitsProfile);
            when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);

            Map<String, Object> variables = Map.of(
                    ASSOCIATE_EVENT, associateEvent,
                    BENEFITS_ENTITY, benefitsEntity,
                    PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.toString(),
                    PLAN_TYPE, PlanType.RETIREMENT_401K_REGULAR_US.toString()
            );


            when(delegateExecution.getVariables()).thenReturn(variables);
            var eligilibilityOutput =  new AssociateEligibilityOutput();
            eligilibilityOutput.setIsEligibilityUpdated(false);
            when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(eligilibilityOutput);
            when(delegateExecution.getVariable(REHIRE_INDICATOR_INPUT)).thenReturn(rehireIndicatorInput);
            when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.name());
            when(InputSchemaMapperFactory.schemaToInput(any(BenefitsEntity.class), eq(RehireIndicatorInput.class)))
                    .thenReturn(rehireIndicatorInput);
            when(RuleExecutorFactory.createExecutor(RuleCategory.REHIRE_INDICATOR)).thenReturn(ruleExecutorService);
            when(ruleExecutorService.execute(any(RuleRequest.class))).thenReturn(ruleResponse);
            when(ruleResponse.getPayload()).thenReturn(rehireIndicatorOutput);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(eq(REHIRE_INDICATOR_INPUT), any(RehireIndicatorInput.class));
            verify(delegateExecution).setVariable(REHIRE_INDICATOR_RULE_RESPONSE, rehireIndicatorOutput);
        }
    }

    @Test
    void testProcessWithRuleExecutionException() throws RuleMetadataSyncException, RulesSyncException, RuleExecutionException {
        try (MockedStatic<InputSchemaMapperFactory> inputSchemaMapperFactoryMockedStatic = mockStatic(InputSchemaMapperFactory.class);
             MockedStatic<RuleExecutorFactory> ruleExecutorFactoryMockedStatic = mockStatic(RuleExecutorFactory.class)) {
            AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
            Eligibility eligibility = new Eligibility();
            eligibility.setPlans(List.of(PlanEligibility.builder()
                            .planGroup(PlanType.RETIREMENT_401K_REGULAR_US.toString())
                            .planId(PlanType.RETIREMENT_401K_REGULAR_US.toString())
                            .isEligible(true)
                    .build()));
            associateBenefitsProfile.setEligibility(eligibility);
            IntraDomainInfo intraDomainInfo = new IntraDomainInfo();
            intraDomainInfo.setAssociateBenefitsProfile(associateBenefitsProfile);
            when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);
            Map<String, Object> variables = Map.of(
                    ASSOCIATE_EVENT, associateEvent,
                    BENEFITS_ENTITY, benefitsEntity,
                    PLAN_TYPE, PlanType.RETIREMENT_401K_REGULAR_US.toString(),
                    PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.toString()
            );
            RehireIndicatorInput rehireIndicatorInput = new RehireIndicatorInput();

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(COMPANY_MATCH_ELIGIBILITY_INPUT)).thenReturn(rehireIndicatorInput);
            when(InputSchemaMapperFactory.schemaToInput(any(BenefitsEntity.class), eq(RehireIndicatorInput.class)))
                    .thenReturn(rehireIndicatorInput);
            when(RuleExecutorFactory.createExecutor(RuleCategory.REHIRE_INDICATOR)).thenReturn(ruleExecutorService);
            when(ruleExecutorService.execute(any(RuleRequest.class))).thenThrow(new RuleExecutionException("Execution Failed"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> processor.process(delegateExecution));
            assertEquals("Rule Execution Failed", exception.getMessage());
        }
    }

    @Test
    void testGetRuleCategory() {
        assertEquals(RuleCategory.REHIRE_INDICATOR, processor.getRuleCategory());
    }

}
