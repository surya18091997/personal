package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory.AssociateEligibilityProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.generateKey;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.getBenefitsEntity;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DisabilityRuleExecutorProcessorTest {


    @Mock
    private RuleMetaDataConfig ruleMetaDataConfig;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private AssociateEligibilityProcessor associateEligibilityProcessor;

    private DisabilityRuleExecutorProcessor processor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new DisabilityRuleExecutorProcessor(ruleMetaDataConfig, List.of(associateEligibilityProcessor));
        when(associateEligibilityProcessor.getRuleCategory()).thenReturn(RuleCategory.ASSOCIATE_ELIGIBILITY);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testProcess_WithPlanType() {
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.DISABILITY_LTD_US);
        ConnectorResponse connectorResponse = mock(ConnectorResponse.class);


        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(CONNECTOR_RESPONSE, connectorResponse);
        variables.put(PLAN_TYPE, PlanType.DISABILITY_LTD_US.getPlanId());
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn(PlanType.DISABILITY_LTD_US.getPlanId());
        when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        when(associateEvent.getPlanType()).thenReturn(PlanType.DISABILITY_LTD_US);

        Map<String, List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.DISABILITY_LTD_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        when(ruleMetaDataConfig.getEventType()).thenReturn(Map.of("testEvent", ruleCategories));

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            mockedCommonUtils.when(() -> generateKey(EventType.NEW_HIRE)).thenReturn("testEvent");
            mockedCommonUtils.when(() -> getBenefitsEntity(connectorResponse, associateEvent)).thenReturn(benefitsEntity);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
            verify(delegateExecution).setVariable(PLAN_TYPE_STR, PlanType.DISABILITY_LTD_US.toString());
            verify(delegateExecution).setVariable(eq(PLAN_ELECTIONS),anyList());
            verify(associateEligibilityProcessor).process(delegateExecution);
        }
    }

    @Test
    void testProcess_WithoutPlanType() {
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.DISABILITY_LTD_US);
        ConnectorResponse connectorResponse = mock(ConnectorResponse.class);

        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(CONNECTOR_RESPONSE, connectorResponse);
        variables.put(PLAN_TYPE, "NONE");
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn("NONE");
        when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);

        Map<String, List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.DISABILITY_LTD_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        when(ruleMetaDataConfig.getEventType()).thenReturn(Map.of("testEvent", ruleCategories));

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            mockedCommonUtils.when(() -> generateKey(EventType.NEW_HIRE)).thenReturn("testEvent");
            mockedCommonUtils.when(() -> getBenefitsEntity(connectorResponse, associateEvent)).thenReturn(benefitsEntity);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(eq(PLAN_ELECTIONS),anyList());
            verify(associateEligibilityProcessor, never()).process(delegateExecution);
        }
    }

    @Test
    void testGetPlanType() {
        assertEquals(DISABILITY, processor.getPlanType());
    }
}