package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.consumer.AES;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class EncryptionUtilTest {

    EncryptionUtil encryptionUtil;
    @BeforeEach
     void setup() throws IllegalAccessException, NoSuchFieldException {
        encryptionUtil = new EncryptionUtil();
        Field field = EncryptionUtil.class.getDeclaredField("encryptionKey");
        field.setAccessible(true);
        field.set(encryptionUtil, "benefits-app-core-engine");
        Field field1 = EncryptionUtil.class.getDeclaredField("encryptionEnabled");
        field1.setAccessible(true);
        field1.set(encryptionUtil,"true");
    }

    @Test
     void testEncrypt(){
        String input = "12345678";
        String encryptedData = encryptionUtil.encrypt(input);
        byte[] decode = Base64.getDecoder().decode(encryptedData);
        byte[] decrypt = AES.decrypt(decode,"benefits-app-core-engine");
        assertEquals(input, new String(decrypt, StandardCharsets.UTF_8));
    }

    @Test
     void testEncryptWithNullData() {
        String data = null;
        String encryptedData = encryptionUtil.encrypt(data);
        assertNull(encryptedData);
    }
}