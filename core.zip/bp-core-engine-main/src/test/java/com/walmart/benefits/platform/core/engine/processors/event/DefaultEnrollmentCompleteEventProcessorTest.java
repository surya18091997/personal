package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DefaultEnrollmentCompleteEventProcessorTest {
@Test
void process_logsDefaultProcessingMessage() {
    DefaultEnrollmentCompleteEventProcessor processor = new DefaultEnrollmentCompleteEventProcessor();
    DelegateExecution delegateExecution = mock(DelegateExecution.class);

    processor.process(delegateExecution);

    assertEquals(EventType.ENROLLMENT_COMPLETE,processor.getEventType());


    // Verify that the log contains the expected message
    // This requires a logging framework test utility or manual log inspection
}

@Test
void getPlanType_returnsNull() {
    DefaultEnrollmentCompleteEventProcessor processor = new DefaultEnrollmentCompleteEventProcessor();

    assertNull(processor.getPlanType());
}
}