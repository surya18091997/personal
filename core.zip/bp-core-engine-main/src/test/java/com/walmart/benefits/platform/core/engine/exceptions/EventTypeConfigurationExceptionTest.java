package com.walmart.benefits.platform.core.engine.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventTypeConfigurationExceptionTest {

    @Test
    void throwsExceptionWithCorrectMessage() {
        EventTypeConfigurationException exception = assertThrows(
                EventTypeConfigurationException.class,
                () -> {
                    throw new EventTypeConfigurationException("Invalid event type");
                }
        );
        assertEquals("Invalid event type", exception.getMessage());
    }

    @Test
    void doesNotThrowExceptionForValidMessage() {
        EventTypeConfigurationException exception = new EventTypeConfigurationException("Valid event type");
        assertNotNull(exception);
        assertEquals("Valid event type", exception.getMessage());
    }
}