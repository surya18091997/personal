package com.walmart.benefits.platform.core.engine.service;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.service.common.RuleMetaDataService;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RulesExecutor;
import com.walmart.benefits.rules.benefitsrulessdk.models.RulesInputMetadata;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.PLAN_TYPE;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

class RuleMetaDataServiceTest {

    @Mock
    private RuleMetaDataConfig ruleMetaDataConfig;

    @Mock
    private RulesExecutor rulesExecutor;

    @Mock
    private EncryptionUtil encryptionUtil;

    @InjectMocks
    private RuleMetaDataService ruleMetaDataService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
     void testExecuteWithValidData() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String,Map<String, List<RuleCategory>>> eventTypeMap = new HashMap<>();
        Map<String, List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_PR.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        ruleCategories.put(PlanType.RETIREMENT_401K_CATCHUP_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        ruleCategories.put(PlanType.RETIREMENT_401K_CATCHUP_REGULAR_PR.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        eventTypeMap.put("new-hire", ruleCategories);

        when(ruleMetaDataConfig.getEventType()).thenReturn(eventTypeMap);

        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.NEW_HIRE);
        associateEvent.setAssociateId("12345678");

        Map<String, Object> variables = new HashMap<>();
        variables.put("associateEvent", associateEvent);
        variables.put(PLAN_TYPE, "401k");

        when(delegateExecution.getVariables()).thenReturn(variables);

        RulesInputMetadata rulesInputMetadata = new RulesInputMetadata();
        rulesInputMetadata.setUpstreamGraphQlQuery(ApplicationConstants.GRAPHQL_CONNECTOR_FIELDS);
        when(rulesExecutor.getRuleMetadata(anyList())).thenReturn(rulesInputMetadata);
        when(encryptionUtil.encrypt(anyString())).thenReturn("encryptedData");

        ruleMetaDataService.execute(delegateExecution);

        verify(rulesExecutor,times(1)).getRuleMetadata(anyList());

    }

    @Test
     void testExecuteWithNullAssociateEvent() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        variables.put("associateEvent", null);
        when(delegateExecution.getVariables()).thenReturn(variables);

        assertThrows(BpmnError.class, () -> ruleMetaDataService.execute(delegateExecution));

    }

    @Test
     void testExecuteWithNullRuleMetaData() throws Exception {
        DelegateExecution delegateExecution = mock(DelegateExecution.class);
        Map<String, Object> variables = new HashMap<>();
        variables.put("associateEvent", new AssociateEvent());
        when(delegateExecution.getVariables()).thenReturn(variables);
        assertThrows(BpmnError.class, () -> ruleMetaDataService.execute(delegateExecution));

    }
}