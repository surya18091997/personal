package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class EventProcessorFactoryTest {
@Test
void getProcessor_returnsMatchingProcessorForPlanTypeAndEventType() {
    EventProcessor processor = mock(EventProcessor.class);
    when(processor.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_LOAN_RESIDENTIAL_PR.getPlanGroup());
    when(processor.getEventType()).thenReturn(EventType.NEW_HIRE);

    EventProcessorFactory factory = new EventProcessorFactory(List.of(processor), List.of());
    EventProcessor result = factory.getProcessor(PlanType.RETIREMENT_401K_LOAN_RESIDENTIAL_PR.getPlanGroup(), EventType.NEW_HIRE);

    assertEquals(processor, result);
}

@Test
void getProcessor_returnsDefaultProcessorWhenNoMatchFound() {
    EventProcessor defaultProcessor = mock(EventProcessor.class);
    when(defaultProcessor.getPlanType()).thenReturn(null);
    when(defaultProcessor.getEventType()).thenReturn(EventType.NEW_HIRE);

    EventProcessorFactory factory = new EventProcessorFactory(List.of(), List.of(defaultProcessor));
    EventProcessor result = factory.getProcessor(PlanType.DENTAL_US.getPlanGroup(), EventType.NEW_HIRE);

    assertEquals(defaultProcessor, result);
}

@Test
void getProcessor_throwsExceptionWhenNoDefaultProcessorFound() {
    EventProcessorFactory factory = new EventProcessorFactory(List.of(), List.of());

    IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
        () -> factory.getProcessor(PlanType.DISABILITY_STD_US.getPlanGroup(), EventType.NEW_HIRE));

    assertTrue(exception.getMessage().contains("No default processor found for event type"));
}

@Test
void getProcessor_ignoresCaseWhenMatchingPlanType() {
    EventProcessor processor = mock(EventProcessor.class);
    when(processor.getPlanType()).thenReturn("PlanA");
    when(processor.getEventType()).thenReturn(EventType.NEW_HIRE);

    EventProcessorFactory factory = new EventProcessorFactory(List.of(processor), List.of());
    EventProcessor result = factory.getProcessor("plana", EventType.NEW_HIRE);

    assertEquals(processor, result);
}
}