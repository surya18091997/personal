package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class GetPostPayrollSnapshotsAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private GetPostPayrollSnapshotsAPIService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testExecute_Success() throws Exception {

        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            ConnectorResponse connectorResponse = new ConnectorResponse();
            connectorResponse.setData(new ConnectorResponse.Data());
            connectorResponse.getData().setQueryAssociateUpstreamDetails(new InterDomainInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().setAssociateInfo(new AssociateInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().setEmployment(new Employment());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().setOriginalHireDate("2020-01-01");

            Map<String, Object> variables = new HashMap<>();
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(CONNECTOR_RESPONSE, connectorResponse);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
            when(httpUtils.getPostPayrollSnapshotServiceUrl()).thenReturn("http://example.com");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            List<PostPayrollSnapshot> snapshots = new ArrayList<>();
            ResponseEntity<List<PostPayrollSnapshot>> responseEntity = new ResponseEntity<>(snapshots, HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), ArgumentMatchers.<ParameterizedTypeReference<List<PostPayrollSnapshot>>>any()))
                    .thenReturn(responseEntity);
            service.execute(delegateExecution);
            verify(delegateExecution, times(2)).setVariable(eq(POST_PAYROLL_SNAPSHOTS), anyList());
        }
    }

    @Test
    void testExecute_DataNotAvailableException() throws Exception {

        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            ConnectorResponse connectorResponse = new ConnectorResponse();
            connectorResponse.setData(new ConnectorResponse.Data());
            connectorResponse.getData().setQueryAssociateUpstreamDetails(new InterDomainInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().setAssociateInfo(new AssociateInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().setEmployment(new Employment());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().setOriginalHireDate("2020-01-01");

            Map<String, Object> variables = new HashMap<>();
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(CONNECTOR_RESPONSE, connectorResponse);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
            when(httpUtils.getPostPayrollSnapshotServiceUrl()).thenReturn("http://example.com");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            ResponseEntity<List<PostPayrollSnapshot>> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), ArgumentMatchers.<ParameterizedTypeReference<List<PostPayrollSnapshot>>>any()))
                    .thenReturn(responseEntity);
            assertThrows(BpmnError.class, () -> service.execute(delegateExecution));
        }
    }

    @Test
    void testExecute_HttpServerErrorException() throws Exception {

        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            ConnectorResponse connectorResponse = new ConnectorResponse();
            connectorResponse.setData(new ConnectorResponse.Data());
            connectorResponse.getData().setQueryAssociateUpstreamDetails(new InterDomainInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().setAssociateInfo(new AssociateInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().setEmployment(new Employment());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().setOriginalHireDate("2020-01-01");

            Map<String, Object> variables = new HashMap<>();
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(CONNECTOR_RESPONSE, connectorResponse);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
            when(httpUtils.getPostPayrollSnapshotServiceUrl()).thenReturn("http://example.com");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), ArgumentMatchers.<ParameterizedTypeReference<List<PostPayrollSnapshot>>>any()))
                    .thenThrow(exception);
            service.execute(delegateExecution);
            verify(httpUtils).handleError(eq(delegateExecution), eq(exception), anyInt(), eq(ASSOCIATE_POST_PAYROLL_SNAPSHOTS_GET_SERVER_ERROR));
        }
    }

    @Test
    void testExecute_HttpClientErrorException_NotFound() throws Exception {

        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            ConnectorResponse connectorResponse = new ConnectorResponse();
            connectorResponse.setData(new ConnectorResponse.Data());
            connectorResponse.getData().setQueryAssociateUpstreamDetails(new InterDomainInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().setAssociateInfo(new AssociateInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().setEmployment(new Employment());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().setOriginalHireDate("2020-01-01");

            Map<String, Object> variables = new HashMap<>();
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(CONNECTOR_RESPONSE, connectorResponse);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
            when(httpUtils.getPostPayrollSnapshotServiceUrl()).thenReturn("http://example.com");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.NOT_FOUND);
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), ArgumentMatchers.<ParameterizedTypeReference<List<PostPayrollSnapshot>>>any()))
                    .thenThrow(exception);
            service.execute(delegateExecution);
            verify(encryptionUtil).encrypt(associateEvent.getAssociateId());
        }
    }

    @Test
    void testExecute_OtherException() throws Exception {

        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {

            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);
            AssociateEvent associateEvent = new AssociateEvent();
            associateEvent.setAssociateId("12345");
            ConnectorResponse connectorResponse = new ConnectorResponse();
            connectorResponse.setData(new ConnectorResponse.Data());
            connectorResponse.getData().setQueryAssociateUpstreamDetails(new InterDomainInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().setAssociateInfo(new AssociateInfo());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().setEmployment(new Employment());
            connectorResponse.getData().getQueryAssociateUpstreamDetails().getAssociateInfo().getEmployment().setOriginalHireDate("2020-01-01");

            Map<String, Object> variables = new HashMap<>();
            variables.put(ASSOCIATE_EVENT, associateEvent);
            variables.put(CONNECTOR_RESPONSE, connectorResponse);

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
            when(httpUtils.getPostPayrollSnapshotServiceUrl()).thenReturn("http://example.com");
            when(httpUtils.getHttpEntity(anyString())).thenReturn(null);

            Exception exception = new RuntimeException("Test Exception");
            when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), ArgumentMatchers.<ParameterizedTypeReference<List<PostPayrollSnapshot>>>any()))
                    .thenThrow(exception);
            assertThrows(BpmnError.class, () -> service.execute(delegateExecution));
        }
    }
}