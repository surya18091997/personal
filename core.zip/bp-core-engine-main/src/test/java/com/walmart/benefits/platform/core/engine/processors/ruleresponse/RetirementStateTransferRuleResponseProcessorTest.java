package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement.RetirementStateTransferRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Date;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;


class RetirementStateTransferRuleResponseProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private IntraDomainInfo intraDomainInfo;

    @Mock
    private InterDomainInfo interDomainInfo;

    @Mock
    private AssociateInfo associateInfo;

    @Mock
    private AssociateEligibilityOutput associateEligibilityOutput;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    private RetirementStateTransferRuleResponseProcessor processor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new RetirementStateTransferRuleResponseProcessor();

        // Prepare mock data
        when(associateBenefitsProfile.getEligibility()).thenReturn(new Eligibility());
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);
        when(intraDomainInfo.getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);

        when(delegateExecution.getVariable(BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanGroup()).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup());
        when(associateEvent.getPlanType().getPlanId()).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        when(associateEligibilityOutput.getAssociateEligibilityDate()).thenReturn(String.valueOf(new Date()));
        when(associateEligibilityOutput.getAssociateEligibilityIndicator()).thenReturn(true);

    }

    @Test
    void testProcess_WithValidInputs() {

        // Setting conditions for AssociateBenefit and Contribution
        when(associateEligibilityOutput.getIsCoverageUpdated()).thenReturn(true);
        when(associateEligibilityOutput.getCoverageStartDate()).thenReturn(String.valueOf(new Date()));
        when(associateEligibilityOutput.getCoverageEndDate()).thenReturn(String.valueOf(new Date()));
        when(associateEligibilityOutput.getContributionAmount()).thenReturn(100.0);

        try (MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class);
             MockedStatic<EventUtils> mockedEventUtils = mockStatic(EventUtils.class)) {

            // Mock static methods
            mockedConverterUtil.when(() -> ConverterUtil.convertDateFormat(any())).thenReturn("convertedDate");

            // Call the process method
            processor.process(delegateExecution);

            // Verify that setVariable is called
            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
            verify(delegateExecution).setVariable(IS_ELIGIBILITY_UPDATED, associateEligibilityOutput.getIsEligibilityUpdated());
            verify(delegateExecution).setVariable(IS_COVERAGE_UPDATED, associateEligibilityOutput.getIsCoverageUpdated());
        }
    }

    @Test
    void testProcess_WithCoverageNotUpdated() {

        when(associateEligibilityOutput.getIsCoverageUpdated()).thenReturn(false);

        processor.process(delegateExecution);

        // Verify that AssociateBenefit is not set when coverage is not updated
        verify(benefitsEntity.getIntraDomainInfo(), never()).setAssociateBenefit(any());
    }

    @Test
    void testProcess_WithNoCoverageDates() {

        // Simulate that no coverage dates are available
        when(associateEligibilityOutput.getCoverageStartDate()).thenReturn(null);
        when(associateEligibilityOutput.getCoverageEndDate()).thenReturn(null);

        try (MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {
            mockedConverterUtil.when(() -> ConverterUtil.convertDateFormat(any())).thenReturn("convertedDate");

            processor.process(delegateExecution);

            // Verify that coverage dates are correctly handled as null
            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
        }
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.STATE_TRANSFER, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        assertEquals(RETIREMENT, processor.getPlanType());
    }
}
