package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement.RetirementRateChangeRuleResponseProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class RetirementRateChangeRuleResponseProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private AssociateEligibilityOutput associateEligibilityOutput;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    @Mock
    private PlanEligibility planEligibility;

    private RetirementRateChangeRuleResponseProcessor processor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new RetirementRateChangeRuleResponseProcessor();
    }

    @Test
    void testProcess_WithValidInputs() {
        // Prepare mock data
        ArrayList<PlanEligibility> planEligibilityList = new ArrayList<>();
        planEligibilityList.add(planEligibility);

        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanGroup()).thenReturn("401K Plan");
        when(associateEvent.getPlanType().getPlanId()).thenReturn("401K");
        when(associateEligibilityOutput.getAssociateEligibilityDate()).thenReturn(String.valueOf(new Date()));
        when(associateEligibilityOutput.getAssociateEligibilityIndicator()).thenReturn(true);

        // Set up benefits entity structure
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        when(associateBenefitsProfile.getEligibility()).thenReturn(new Eligibility());

        try (MockedStatic<RetirementRateChangeRuleResponseProcessor> mockedProcessor = mockStatic(RetirementRateChangeRuleResponseProcessor.class)) {
            // Mock the static method getPlanEligibility
            mockedProcessor.when(() -> RetirementRateChangeRuleResponseProcessor.getPlanEligibility(associateEligibilityOutput, associateEvent))
                    .thenReturn(planEligibilityList);

            // Call the process method
            processor.process(delegateExecution);

            // Verify that setVariable is called
            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
        }
    }

    @Test
    void testProcess_WithNullEligibilityDate() {
        // Prepare mock data with null eligibility date
        ArrayList<PlanEligibility> planEligibilityList = new ArrayList<>();
        planEligibilityList.add(planEligibility);

        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanGroup()).thenReturn("401K Plan");
        when(associateEvent.getPlanType().getPlanId()).thenReturn("401K");
        when(associateEligibilityOutput.getAssociateEligibilityDate()).thenReturn(null);
        when(associateEligibilityOutput.getAssociateEligibilityIndicator()).thenReturn(true);

        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        when(associateBenefitsProfile.getEligibility()).thenReturn(new Eligibility());

        try (MockedStatic<RetirementRateChangeRuleResponseProcessor> mockedProcessor = mockStatic(RetirementRateChangeRuleResponseProcessor.class)) {
            mockedProcessor.when(() -> RetirementRateChangeRuleResponseProcessor.getPlanEligibility(associateEligibilityOutput, associateEvent))
                    .thenReturn(planEligibilityList);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
        }
    }

    @Test
    void testProcess_WithNullEligibilityIndicator() {
        // Prepare mock data with null eligibility indicator
        ArrayList<PlanEligibility> planEligibilityList = new ArrayList<>();
        planEligibilityList.add(planEligibility);

        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanGroup()).thenReturn("401K Plan");
        when(associateEvent.getPlanType().getPlanId()).thenReturn("401K");
        when(associateEligibilityOutput.getAssociateEligibilityDate()).thenReturn(String.valueOf(new Date()));
        when(associateEligibilityOutput.getAssociateEligibilityIndicator()).thenReturn(null);

        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        when(associateBenefitsProfile.getEligibility()).thenReturn(new Eligibility());

        try (MockedStatic<RetirementRateChangeRuleResponseProcessor> mockedProcessor = mockStatic(RetirementRateChangeRuleResponseProcessor.class)) {
            mockedProcessor.when(() -> RetirementRateChangeRuleResponseProcessor.getPlanEligibility(associateEligibilityOutput, associateEvent))
                    .thenReturn(planEligibilityList);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(BENEFITS_ENTITY, benefitsEntity);
        }
    }

    @Test
    void getPlanEligibilityTest() {
        // setup
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);

        AssociateEligibilityOutput associateEligibilityOutput = new AssociateEligibilityOutput();
        associateEligibilityOutput.setAssociateEligibilityDate(String.valueOf(LocalDate.now()));
        associateEligibilityOutput.setAssociateEligibilityIndicator(true);

        // execute
        ArrayList<PlanEligibility> result = RetirementRateChangeRuleResponseProcessor.getPlanEligibility(associateEligibilityOutput, associateEvent);

        // verify
        assertEquals(1, result.size());
        assertEquals(String.valueOf(LocalDate.now()), result.get(0).getEligibleDate());
        assertEquals(true, result.get(0).getIsEligible());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup(), result.get(0).getPlanGroup());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), result.get(0).getPlanId());
    }

    @Test
    void testGetEventType() {
        // Verify that getEventType() returns RATE_CHANGE
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        // Verify that getPlanType() returns _401K
        assertEquals(RETIREMENT, processor.getPlanType());
    }
}
