package com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_EVENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class RetirementRehireRuleResponseProcessorTest {

    private RetirementRehireRuleResponseProcessor processor;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    @Mock
    private AssociateEligibilityOutput associateEligibilityOutput;

    @Mock
    private CompanyMatchEligibilityOutput companyMatchEligibilityOutput;

    @Mock
    private RehireIndicatorOutput rehireIndicatorOutput;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new RetirementRehireRuleResponseProcessor();
    }

    @Test
    void testProcess_WithEligibilityUpdated() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        when(associateEligibilityOutput.getIsEligibilityUpdated()).thenReturn(true);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        Eligibility eligibility = new Eligibility();
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        List<PlanEligibility> plans = new ArrayList<>();
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        plans.add(planEligibility);
        eligibility.setPlans(plans);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class);
             MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {
            processor.process(delegateExecution);
        }

        verify(delegateExecution).setVariable(ApplicationConstants.RULE_RESPONSE, null);
        verify(delegateExecution).setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
    }

    @Test
    void testProcess_WithCompanyMatchEligibilityUpdated() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        when(delegateExecution.getVariable(ApplicationConstants.COMPANY_MATCH_RULE_RESPONSE)).thenReturn(companyMatchEligibilityOutput);
        when(companyMatchEligibilityOutput.getIsCompanyMatchEligibilityUpdated()).thenReturn(true);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        Eligibility eligibility = new Eligibility();
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        List<PlanEligibility> plans = new ArrayList<>();
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        plans.add(planEligibility);
        eligibility.setPlans(plans);
        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(ApplicationConstants.COMPANY_MATCH_RULE_RESPONSE, null);
        verify(delegateExecution).setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
    }

    @Test
    void testProcess_WithRehireIndicatorUpdated() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        when(delegateExecution.getVariable(ApplicationConstants.REHIRE_INDICATOR_RULE_RESPONSE)).thenReturn(rehireIndicatorOutput);
        when(rehireIndicatorOutput.getRehireIndicator()).thenReturn("Rehired");
        when(rehireIndicatorOutput.isOriginalHireDateUpdated()).thenReturn(true);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        Eligibility eligibility = new Eligibility();
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        List<PlanEligibility> plans = new ArrayList<>();
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        plans.add(planEligibility);
        eligibility.setPlans(plans);
        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(ApplicationConstants.TRANSACTION_LOG_COMMENT, "Rehired");
        verify(delegateExecution).setVariable(ApplicationConstants.REHIRE_INDICATOR_RULE_RESPONSE, null);
        verify(delegateExecution).setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.RE_HIRE, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        assertEquals(ApplicationConstants.RETIREMENT, processor.getPlanType());
    }
}