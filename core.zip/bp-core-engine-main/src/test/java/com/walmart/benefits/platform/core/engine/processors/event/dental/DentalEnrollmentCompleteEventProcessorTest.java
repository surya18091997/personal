package com.walmart.benefits.platform.core.engine.processors.event.dental;

import com.walmart.benefits.platform.core.engine.processors.event.dental.DentalEnrollmentCompleteEventProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.StoreInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.*;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.DISABILITY;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DentalEnrollmentCompleteEventProcessorTest {

    private DentalEnrollmentCompleteEventProcessor processor;
    private DelegateExecution delegateExecution;
    private Map<String, Object> variables;

    private MockedStatic<CommonUtils> commonUtilsMock;
    private MockedStatic<RateValidatorUtil> rateValidatorUtilMock;
    private MockedStatic<EventUtils> eventUtilsMock;

    private final AssociateEvent associateEvent = new AssociateEvent();


    @BeforeEach
    void setUp() {

        commonUtilsMock = mockStatic(CommonUtils.class);
        eventUtilsMock = mockStatic(EventUtils.class);
        rateValidatorUtilMock = mockStatic(RateValidatorUtil.class);


        when(CommonUtils.getTodayString()).thenReturn(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        when(CommonUtils.getProfile(any(DelegateExecution.class))).thenReturn(mock(AssociateBenefitsProfile.class));
        CommonUtils.Coverage mockedCoverage =  new CommonUtils.Coverage(new AssociateBenefit(),null, PlanType.DENTAL_US.getPlanId());
        when(CommonUtils.getCoverage(any(AssociateEvent.class), any(String.class), any(Map.class)))
                .thenReturn(mockedCoverage);

        when(EventUtils.createCoverage(any(AssociateEvent.class), any(Activity.class))).thenReturn(List.of(new AssociateBenefit()));


        processor = new DentalEnrollmentCompleteEventProcessor();
        delegateExecution = mock(DelegateExecution.class);
        variables = new HashMap<>();


        Enrollment enrollment = new Enrollment();
        enrollment.setAssociateId("12345");
        enrollment.setEnrollmentId(UUID.randomUUID().toString());
        enrollment.setOriginSystem(OriginSystem.CORE_ENGINE);
        enrollment.setLocale(BenefitsLocale.EN_US);
        enrollment.setActivity(Activity.NEW_HIRE);
        enrollment.setDeviceIndicator(Device.OTHER);
        enrollment.setExternalIndicator(false);
        enrollment.setEventDate(CommonUtils.getTodayString());
        enrollment.setStatus(EnrollmentStatus.COMPLETED);

        PlanElection election = new PlanElection();
        election.setPlanId(PlanType.DENTAL_US.getPlanId());
        election.setPlanGroup(PlanType.DENTAL_US.getPlanGroup());
        election.setTier(Tier.ASSOCIATE);
        enrollment.setPlanElections(List.of(election));


        associateEvent.setEventType(EventType.ENROLLMENT_COMPLETE);
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.DENTAL_US);
        associateEvent.setOrigin(EventOrigin.ENROLLMENT_API);
        associateEvent.setTimeStamp("2025-04-01 12:30:00");
        associateEvent.setId(UUID.randomUUID());
        associateEvent.setAdditionalInfo(enrollment);

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        InterDomainInfo interDomainInfo = mock(InterDomainInfo.class);
        AssociateInfo associateInfo = mock(AssociateInfo.class);
        Employment employment = mock(Employment.class);
        StoreInfo storeInfo = mock(StoreInfo.class);

        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
        when(associateInfo.getEmployment()).thenReturn(employment);
        when(employment.getStoreInfo()).thenReturn(storeInfo);
        when(storeInfo.getStoreStateProvCd()).thenReturn("CA");

        variables.put(ASSOCIATE_EVENT,associateEvent);
        variables.put(BENEFITS_ENTITY,benefitsEntity);

        variables.put(ENROLLMENT,enrollment);
        AssociateEligibilityOutput mockedAssociateEligibilityOutput = new AssociateEligibilityOutput();
        mockedAssociateEligibilityOutput.setCoverageStartDate("2023-01-01");
        mockedAssociateEligibilityOutput.setCoverageEndDate("2023-12-31");
        mockedAssociateEligibilityOutput.setTier(Tier.ASSOCIATE.name());
        variables.put(RULE_RESPONSE,mockedAssociateEligibilityOutput);


        when(delegateExecution.getVariables()).thenReturn(variables);
    }


    @AfterEach
    void tearDown() {
        commonUtilsMock.close();
        rateValidatorUtilMock.close();
        eventUtilsMock.close();
    }

    @Test
    void process_setsCoverageAndEligibilityWhenCoverageListIsPresent() {
        AssociateBenefit coverage = new AssociateBenefit();
        coverage.setPlanId(PlanType.DENTAL_US.getPlanId());
        coverage.setPlanGroup(PlanType.DENTAL_US.getPlanGroup());
        coverage.setStartDate("2023-01-01");
        List<AssociateBenefit> coverageList = List.of(coverage);

        variables.put(COVERAGE_RESPONSE_LIST, coverageList);
        variables.put(PLAN_TYPE, PlanType.DENTAL_US.getPlanId());

        when(delegateExecution.getVariable(UPDATE_COVERAGE)).thenReturn(coverage);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        verify(delegateExecution).setVariable("isPlanEligible", true);
    }

    @Test
    void process_doesNotSetCoverageWhenCoverageListIsEmpty() {
        variables.put(COVERAGE_RESPONSE_LIST, List.of());

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        verify(delegateExecution).setVariable("isPlanEligible", true);
    }

    @Test
    void process_logsWarningWhenCoverageListIsNull() {
        variables.put(COVERAGE_RESPONSE_LIST, null);


        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(IS_COVERAGE_AVAILABLE, TRUE);
        verify(delegateExecution).setVariable("isPlanEligible", true);
    }


    @Test
    void process_throwsExceptionWhenAssociateEventIsMissing() {
        delegateExecution.getVariables().remove(ASSOCIATE_EVENT);

        assertThrows(IndexOutOfBoundsException.class, () -> processor.process(delegateExecution));
    }







    @Test
    void getEventType_returnsEnrollmentComplete() {
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void getPlanType_returnsDisability() {
        assertEquals(DENTAL, processor.getPlanType());
    }
}