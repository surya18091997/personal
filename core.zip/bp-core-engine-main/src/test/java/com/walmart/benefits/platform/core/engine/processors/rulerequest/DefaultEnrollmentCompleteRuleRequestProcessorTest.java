package com.walmart.benefits.platform.core.engine.processors.rulerequest;

import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DefaultEnrollmentCompleteRuleRequestProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private Enrollment enrollment;

    @Mock
    private AssociateBenefitsProfile associateBenefitsProfile;

    @Mock
    private PlanEligibility planEligibility;

    @Mock
    private AssociateEligibilityInput associateEligibilityInput;

    private DefaultEnrollmentCompleteRuleRequestProcessor processor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new DefaultEnrollmentCompleteRuleRequestProcessor();
        when(enrollment.getActivity()).thenReturn(Activity.NEW_HIRE);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testProcess_WithValidInputs() {
        // Setting up mock data
        Map<String, Object> variables = new HashMap<>();
        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
        variables.put(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
        variables.put(ENROLLMENT, enrollment);


        List<PlanEligibility> eligiblePlans = List.of(planEligibility);
        when(associateBenefitsProfile.getEligibility()).thenReturn(mock(Eligibility.class));
        when(associateBenefitsProfile.getEligibility().getPlans()).thenReturn(eligiblePlans);
        when(planEligibility.getIsEligible()).thenReturn(true);
        when(planEligibility.getPlanId()).thenReturn(PlanType.DISABILITY_STD_US.getPlanId());
        when(planEligibility.getEligibleDate()).thenReturn(String.valueOf(new Date()));

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanId()).thenReturn(PlanType.DISABILITY_STD_US.getPlanId());
        when(associateEvent.getTimeStamp()).thenReturn("2023-01-01");

        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class);
             MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {

            // Mock static methods
            mockedCommonUtils.when(() -> CommonUtils.getProfile(delegateExecution)).thenReturn(associateBenefitsProfile);
            mockedConverterUtil.when(() -> ConverterUtil.convertTimestampDate(any())).thenReturn("convertedTimestamp");

            processor.process(delegateExecution);

            // Verifying the changes
            verify(delegateExecution).setVariable(PLAN_ID_LIST, List.of(PlanType.DISABILITY_STD_US.getPlanId().toUpperCase()));
            verify(delegateExecution).setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
            verify(associateEligibilityInput).setSessionDate("2023-01-01");
        }
    }

    @Test
    void testProcess_WithNoEligiblePlans() {
        Map<String, Object> variables = new HashMap<>();
        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile);
        variables.put(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
        variables.put(ENROLLMENT, enrollment);



        List<PlanEligibility> eligiblePlans = Collections.emptyList();
        when(associateBenefitsProfile.getEligibility()).thenReturn(mock(Eligibility.class));
        when(associateBenefitsProfile.getEligibility().getPlans()).thenReturn(eligiblePlans);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(ASSOCIATE_EVENT)).thenReturn(associateEvent);
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);
        when(associateEvent.getPlanType()).thenReturn(mock(PlanType.class));
        when(associateEvent.getPlanType().getPlanId()).thenReturn(PlanType.DISABILITY_STD_US.getPlanId());

        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class);
             MockedStatic<ConverterUtil> mockedConverterUtil = mockStatic(ConverterUtil.class)) {

            mockedCommonUtils.when(() -> CommonUtils.getProfile(delegateExecution)).thenReturn(associateBenefitsProfile);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable(PLAN_ID_LIST, Collections.emptyList());
            verify(delegateExecution).setVariable(ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
            verify(associateEligibilityInput, never()).setPrevEligibilityDate(any());
        }
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void testPlanType() {
        assertNull(processor.getPlanType());
    }
}