package com.walmart.benefits.platform.core.engine.processors.ruleexecutor;

import com.walmart.benefits.platform.core.engine.configs.RuleMetaDataConfig;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory.AssociateEligibilityProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.generateKey;
import static com.walmart.benefits.platform.core.engine.utils.CommonUtils.getBenefitsEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class DefaultExecutorProcessorTest {

    @Mock
    private RuleMetaDataConfig ruleMetaDataConfig;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private AssociateEligibilityProcessor associateEligibilityProcessor;

    private DefaultExecutorProcessor processor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new DefaultExecutorProcessor(ruleMetaDataConfig, List.of(associateEligibilityProcessor));
        when(associateEligibilityProcessor.getRuleCategory()).thenReturn(RuleCategory.ASSOCIATE_ELIGIBILITY);
    }

    @Test
    void testProcess_WithPlanType() {
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        ConnectorResponse connectorResponse = mock(ConnectorResponse.class);

        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(CONNECTOR_RESPONSE, connectorResponse);
        variables.put(PLAN_TYPE, PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        when(associateEvent.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US);

        Map<String, List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        when(ruleMetaDataConfig.getEventType()).thenReturn(Map.of("testEvent", ruleCategories));

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            mockedCommonUtils.when(() -> generateKey(EventType.NEW_HIRE)).thenReturn("testEvent");
            mockedCommonUtils.when(() -> getBenefitsEntity(connectorResponse, associateEvent)).thenReturn(benefitsEntity);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable("benefitsEntity", benefitsEntity);
            verify(delegateExecution).setVariable(PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.toString());
            verify(associateEligibilityProcessor).process(delegateExecution);
        }
    }

    @Test
    void testProcess_WithoutPlanType() {
        Map<String, Object> variables = new HashMap<>();
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        ConnectorResponse connectorResponse = mock(ConnectorResponse.class);

        variables.put(ASSOCIATE_EVENT, associateEvent);
        variables.put(CONNECTOR_RESPONSE, connectorResponse);
        variables.put(PLAN_TYPE, "NONE");
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn("NONE");
        when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);

        Map<String, List<RuleCategory>> ruleCategories = new HashMap<>();
        ruleCategories.put(PlanType.RETIREMENT_401K_REGULAR_US.toString(), List.of(RuleCategory.ASSOCIATE_ELIGIBILITY));
        when(ruleMetaDataConfig.getEventType()).thenReturn(Map.of("testEvent", ruleCategories));

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        try (MockedStatic<CommonUtils> mockedCommonUtils = mockStatic(CommonUtils.class)) {
            mockedCommonUtils.when(() -> generateKey(EventType.NEW_HIRE)).thenReturn("testEvent");
            mockedCommonUtils.when(() -> getBenefitsEntity(connectorResponse, associateEvent)).thenReturn(benefitsEntity);

            processor.process(delegateExecution);

            verify(delegateExecution).setVariable("benefitsEntity", benefitsEntity);
            verify(associateEligibilityProcessor, never()).process(delegateExecution);
        }
    }

    @Test
    void testGetPlanType() {
        assertEquals(null, processor.getPlanType());
    }
}
