package com.walmart.benefits.platform.core.engine.processors.event.disability;

import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.platform.core.engine.utils.RateValidatorUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.StoreInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.*;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefitsplatformentitymodel.intradomain.common.constants.DATE_PATTERN;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DisabilityEnrollmentCompleteEventProcessorTest {

    private DisabilityEnrollmentCompleteEventProcessor processor;
    private DelegateExecution delegateExecution;
    private Map<String, Object> variables;

    private MockedStatic<CommonUtils> commonUtilsMock;
    private MockedStatic<RateValidatorUtil> rateValidatorUtilMock;
    private MockedStatic<EventUtils> eventUtilsMock;

    private final AssociateEvent associateEvent = new AssociateEvent();


    @BeforeEach
    void setUp() {

        commonUtilsMock = mockStatic(CommonUtils.class);
        eventUtilsMock = mockStatic(EventUtils.class);
        rateValidatorUtilMock = mockStatic(RateValidatorUtil.class);


        when(CommonUtils.getTodayString()).thenReturn(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        when(CommonUtils.getProfile(any(DelegateExecution.class))).thenReturn(mock(AssociateBenefitsProfile.class));
        CommonUtils.Coverage mockedCoverage =  new CommonUtils.Coverage(new AssociateBenefit(),null,PlanType.DISABILITY_LTD_US.getPlanId());
        when(CommonUtils.getCoverage(any(AssociateEvent.class), any(String.class), any(Map.class)))
                .thenReturn(mockedCoverage);




        processor = new DisabilityEnrollmentCompleteEventProcessor();
        delegateExecution = mock(DelegateExecution.class);
        variables = new HashMap<>();


        Enrollment enrollment = new Enrollment();
        enrollment.setAssociateId("12345");
        enrollment.setEnrollmentId(UUID.randomUUID().toString());
        enrollment.setOriginSystem(OriginSystem.CORE_ENGINE);
        enrollment.setLocale(BenefitsLocale.EN_US);
        enrollment.setActivity(Activity.NEW_HIRE);
        enrollment.setDeviceIndicator(Device.OTHER);
        enrollment.setExternalIndicator(false);
        enrollment.setEventDate(CommonUtils.getTodayString());
        enrollment.setStatus(EnrollmentStatus.COMPLETED);

        PlanElection election = new PlanElection();
        election.setPlanId(PlanType.DISABILITY_STD_US.getPlanId());
        election.setPlanGroup(PlanType.DISABILITY_STD_US.getPlanGroup());
        election.setTier(Tier.ASSOCIATE);
        enrollment.setPlanElections(List.of(election));


        associateEvent.setEventType(EventType.ENROLLMENT_COMPLETE);
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.DISABILITY_STD_US);
        associateEvent.setOrigin(EventOrigin.ENROLLMENT_API);
        associateEvent.setTimeStamp("2025-04-01 12:30:00");
        associateEvent.setId(UUID.randomUUID());
        associateEvent.setAdditionalInfo(enrollment);

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        InterDomainInfo interDomainInfo = mock(InterDomainInfo.class);
        AssociateInfo associateInfo = mock(AssociateInfo.class);
        Employment employment = mock(Employment.class);
        StoreInfo storeInfo = mock(StoreInfo.class);

        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
        when(associateInfo.getEmployment()).thenReturn(employment);
        when(employment.getStoreInfo()).thenReturn(storeInfo);
        when(storeInfo.getStoreStateProvCd()).thenReturn("CA");

        variables.put(ASSOCIATE_EVENT,associateEvent);
        variables.put(BENEFITS_ENTITY,benefitsEntity);

        variables.put(ENROLLMENT,enrollment);
        AssociateEligibilityOutput mockedAssociateEligibilityOutput = new AssociateEligibilityOutput();
        mockedAssociateEligibilityOutput.setCoverageStartDate("2023-01-01");
        mockedAssociateEligibilityOutput.setCoverageEndDate("2023-12-31");
        mockedAssociateEligibilityOutput.setTier(Tier.ASSOCIATE.name());
        variables.put(RULE_RESPONSE,mockedAssociateEligibilityOutput);


        when(delegateExecution.getVariables()).thenReturn(variables);
    }


    @AfterEach
    void tearDown() {
        commonUtilsMock.close();
        rateValidatorUtilMock.close();
        eventUtilsMock.close();
    }

    @Test
    void process_withCoverageAvailable() {
        variables.put(IS_COVERAGE_AVAILABLE, "true");
        when(RateValidatorUtil.isPlanEligible(any(AssociateBenefitsProfile.class), any(AssociateEvent.class))).thenReturn(true);

        processor.process(delegateExecution);

        assertEquals(true, variables.get(IS_PLAN_ELIGIBLE));

        AssociateBenefit response = (AssociateBenefit) variables.get(UPDATE_COVERAGE);
        assertEquals("2023-01-01", response.getStartDate());
        assertEquals("2023-12-31", response.getEndDate());
    }

    @Test
    void process_withoutCoverageAvailable() {
        variables.put(IS_COVERAGE_AVAILABLE, "false");
        when(RateValidatorUtil.isPlanEligible(any(AssociateBenefitsProfile.class), any(AssociateEvent.class))).thenReturn(false);
        AssociateBenefitsProfile profile =  new AssociateBenefitsProfile();
        when(EventUtils.updateProfile(any(AssociateEvent.class), any(BenefitsEntity.class))).thenReturn(profile);



        processor.process(delegateExecution);
        assertEquals(false, variables.get(IS_PLAN_ELIGIBLE));
        assertEquals(profile, variables.get(ASSOCIATE_BENEFITS_PROFILE));

        List<AssociateBenefit> response = (List<AssociateBenefit>) variables.get(ASSOCIATE_COVERAGE);
        assertEquals("2023-01-01", response.get(0).getStartDate());
        assertEquals("2023-12-31", response.get(0).getEndDate());
        assertEquals(Activity.NEW_HIRE, response.get(0).getChangeActivity());
    }

    @Test
    void updateDisabilityCoverage_setsCorrectValues() {
        AssociateEligibilityOutput eligibilityOutput = mock(AssociateEligibilityOutput.class);
        when(eligibilityOutput.getCoverageStartDate()).thenReturn("2023-01-01");
        when(eligibilityOutput.getCoverageEndDate()).thenReturn("2023-12-31");

        AssociateBenefit coverage = new AssociateBenefit();
        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.DISABILITY_STD_US);
        Enrollment enrollment = mock(Enrollment.class);
        AssociateBenefit updatedCoverage = processor.updateDisabilityCoverage( coverage,associateEvent,eligibilityOutput,enrollment);

        assertEquals("2023-01-01", updatedCoverage.getStartDate());
        assertEquals("2023-12-31", updatedCoverage.getEndDate());
        assertEquals("SYSTEM_CORE_ENGINE", updatedCoverage.getLastModifiedBy());
    }

    @Test
    void createDisabilityCoverage_createsNewCoverage() {
        AssociateEligibilityOutput eligibilityOutput = mock(AssociateEligibilityOutput.class);
        when(eligibilityOutput.getCoverageStartDate()).thenReturn("2023-01-01");
        when(eligibilityOutput.getCoverageEndDate()).thenReturn("2023-12-31");
        when(eligibilityOutput.getTier()).thenReturn(String.valueOf(Tier.ASSOCIATE));

        BenefitsEntity benefitsEntity = mock(BenefitsEntity.class);
        InterDomainInfo interDomainInfo = mock(InterDomainInfo.class);
        AssociateInfo associateInfo = mock(AssociateInfo.class);
        Employment employment = mock(Employment.class);
        StoreInfo storeInfo = mock(StoreInfo.class);

        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
        when(associateInfo.getEmployment()).thenReturn(employment);
        when(employment.getStoreInfo()).thenReturn(storeInfo);
        when(storeInfo.getStoreStateProvCd()).thenReturn("CA");



        AssociateBenefit coverage = new AssociateBenefit();
        Enrollment enrollment = mock(Enrollment.class);
        List<AssociateBenefit> createdCoverages = processor.createDisabilityCoverage(associateEvent, eligibilityOutput,enrollment, coverage);

        assertEquals(1, createdCoverages.size());
        AssociateBenefit newCoverage = createdCoverages.get(0);
        assertEquals("2023-01-01", newCoverage.getStartDate());
        assertEquals("2023-12-31", newCoverage.getEndDate());
        assertEquals("SYSTEM_CORE_ENGINE", newCoverage.getCreatedBy());

    }

    @Test
    void getEventType_returnsEnrollmentComplete() {
        assertEquals(EventType.ENROLLMENT_COMPLETE, processor.getEventType());
    }

    @Test
    void getPlanType_returnsDisability() {
        assertEquals(DISABILITY, processor.getPlanType());
    }

}