package com.walmart.benefits.platform.core.engine.processor;

import com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement.RetirementNewHireRuleResponseProcessor;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.RETIREMENT;
import static com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType.NEW_HIRE;
import static com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType.RETIREMENT_401K_REGULAR_US;
import static org.mockito.Mockito.when;

class RetirementNewHireRuleResponseProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private RetirementNewHireRuleResponseProcessor processor;

    @BeforeEach
    void  setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void  testProcessWithNullDelegateExecution() {
        Assert.assertThrows(NullPointerException.class, () -> processor.process(null));
    }

    @Test
    void  testProcessWithNullRuleResponse() {
        when(delegateExecution.getVariable("ruleResponse")).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void  testProcessWithNullBenefitsEntity() {
        when(delegateExecution.getVariable("ruleResponse")).thenReturn(new AssociateEligibilityOutput());
        when(delegateExecution.getVariable("benefitsEntity")).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void  testProcessWithNullPlanTypeStr() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        when(delegateExecution.getVariable("ruleResponse")).thenReturn(ruleResponse);
        when(delegateExecution.getVariable("benefitsEntity")).thenReturn(new BenefitsEntity());
        when(delegateExecution.getVariable("planTypeStr")).thenReturn(null);
        Assert.assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void  createBaseRecordFor401kNewHireRegular() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        ruleResponse.setAssociateEligibilityIndicator(true);
        ruleResponse.setIsEligibilityUpdated(true);
        ruleResponse.setAssociateEligibilityDate("2024-08-09");

        BenefitsEntity benefitsEntity = getBenefitsEntity();

        when(delegateExecution.getVariable("ruleResponse")).thenReturn(ruleResponse);
        when(delegateExecution.getVariable("benefitsEntity")).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable("planTypeStr")).thenReturn(RETIREMENT_401K_REGULAR_US.name());

        processor.process(delegateExecution);

        benefitsEntity = (BenefitsEntity) delegateExecution.getVariable("benefitsEntity");

        Assertions.assertNotNull(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans().get(0).getEligibleDate());


    }

    @Test
    void  createBaseRecordFor401kNewHireRegularAndCatchup() {
        AssociateEligibilityOutput ruleResponse = new AssociateEligibilityOutput();
        ruleResponse.setAssociateEligibilityIndicator(true);
        ruleResponse.setIsEligibilityUpdated(true);
        ruleResponse.setAssociateEligibilityDate("2024-08-09");

        BenefitsEntity benefitsEntity = getBenefitsEntity();

        when(delegateExecution.getVariable("ruleResponse")).thenReturn(ruleResponse);
        when(delegateExecution.getVariable("benefitsEntity")).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable("planTypeStr")).thenReturn(RETIREMENT_401K_REGULAR_US.name());

        processor.process(delegateExecution);

        benefitsEntity = (BenefitsEntity) delegateExecution.getVariable("benefitsEntity");

        processor.process(delegateExecution);

        Assertions.assertEquals(1,
                benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility().getPlans().size());


    }

    @Test
    void  testEventType(){
        Assertions.assertEquals(NEW_HIRE, processor.getEventType());
    }

    @Test
    void  testPlanType(){
        Assertions.assertEquals(RETIREMENT, processor.getPlanType());
    }


    private static BenefitsEntity getBenefitsEntity() {
        BenefitsEntity benefitsEntity = new BenefitsEntity();

        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        Employment  employment = new Employment();
        employment.setHireDate("01/01/2022");
        associateInfo.setEmployment(employment);
        interDomainInfo.setAssociateInfo(associateInfo);

        IntraDomainInfo intraDomainInfo = new IntraDomainInfo();

        benefitsEntity.setInterDomainInfo(interDomainInfo);
        benefitsEntity.setIntraDomainInfo(intraDomainInfo);
        return benefitsEntity;
    }
}