package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementRehireEventProcessor;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class RetirementRehireEventProcessorTest {

    @Mock
    private DelegateExecution delegateExecution;

    private RetirementRehireEventProcessor processor;
    private Map<String, Object> variables;
    private BenefitsEntity benefitsEntity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        processor = new RetirementRehireEventProcessor();
        variables = new HashMap<>();
        benefitsEntity = new BenefitsEntity();
        benefitsEntity.setIntraDomainInfo(new IntraDomainInfo());
        benefitsEntity.getIntraDomainInfo().setAssociateBenefitsProfile(new AssociateBenefitsProfile());
        benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().setEligibility(new Eligibility());
        benefitsEntity.setInterDomainInfo(new InterDomainInfo());
        benefitsEntity.getInterDomainInfo().setAssociateInfo(new AssociateInfo());
    }

    @Test
    void testGetEventType() {
        assertEquals(EventType.RE_HIRE, processor.getEventType());
    }

    @Test
    void testGetPlanType() {
        assertEquals(RETIREMENT, processor.getPlanType());
    }

    @Test
    void testProcess() {
        // Setup
        variables.put(BENEFITS_ENTITY, benefitsEntity);
        when(delegateExecution.getVariables()).thenReturn(variables);

        // Execute
        processor.process(delegateExecution);

        // Verify
        verify(delegateExecution).getVariables();
        verify(delegateExecution).setVariables(variables);
        assertNotNull(variables.get(ASSOCIATE_BENEFITS_PROFILE));
    }

}