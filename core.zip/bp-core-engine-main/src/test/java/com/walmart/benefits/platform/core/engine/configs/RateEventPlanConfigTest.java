package com.walmart.benefits.platform.core.engine.configs;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class RateEventPlanConfigTest {

    private RateEventPlanConfig config;

    @BeforeEach
    void setUp() {
        config = new RateEventPlanConfig();
    }

    @Test
    void testValidatePlanConfig_AllFieldsValid() {
        // Set valid values for all fields
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);
        ReflectionTestUtils.setField(config, "catchupEligibleAge", 50);

        // Validate that no exception is thrown
        assertDoesNotThrow(config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_BasePlanNull() {
        // Set invalid value for basePlan
        ReflectionTestUtils.setField(config, "basePlan", null);
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);

        // Validate that exception is thrown
        assertThrows(IllegalArgumentException.class, config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_RegularPlanNull() {
        // Set invalid value for regularPlan
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", null);
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);

        // Validate that exception is thrown
        assertThrows(IllegalArgumentException.class, config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_CatchupPlanNull() {
        // Set invalid value for catchupPlan
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", null);
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);

        // Validate that exception is thrown
        assertThrows(IllegalArgumentException.class, config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_CatchupLimitNull() {
        // Set invalid value for catchupLimit
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", null);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);

        // Validate that exception is thrown
        assertThrows(IllegalArgumentException.class, config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_RegularLimitNull() {
        // Set invalid value for regularLimit
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", null);

        // Validate that exception is thrown
        assertThrows(IllegalArgumentException.class, config::validatePlanConfig);
    }

    @Test
    void testValidatePlanConfig_CatchupEligibleAgeDefault() {
        // Test the default value for catchupEligibleAge
        ReflectionTestUtils.setField(config, "basePlan", "BasePlanA");
        ReflectionTestUtils.setField(config, "regularPlan", Arrays.asList("Plan1", "Plan2"));
        ReflectionTestUtils.setField(config, "catchupPlan", Arrays.asList("Plan3", "Plan4"));
        ReflectionTestUtils.setField(config, "catchupLimit", 5000.0);
        ReflectionTestUtils.setField(config, "regularLimit", 19500.0);

        // Default value for catchupEligibleAge is 0 (primitive type default)
        assertDoesNotThrow(config::validatePlanConfig);
    }

    @Test
    void testGettersAndSetters() {
        config.setBasePlan("Base");
        assertEquals("Base", config.getBasePlan());

        config.setRegularPlan(Arrays.asList("Plan1", "Plan2"));
        assertEquals(Arrays.asList("Plan1", "Plan2"), config.getRegularPlan());

        config.setCatchupPlan(Arrays.asList("Plan3", "Plan4"));
        assertEquals(Arrays.asList("Plan3", "Plan4"), config.getCatchupPlan());

        config.setCatchupLimit(100.0);
        assertEquals(100.0, config.getCatchupLimit());

        config.setRegularLimit(200.0);
        assertEquals(200.0, config.getRegularLimit());

        config.setCatchupEligibleAge(50);
        assertEquals(50, config.getCatchupEligibleAge());
    }

}
