package com.walmart.benefits.platform.core.engine.service.enrollment;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.testng.Assert.assertThrows;

class EnrollmentExecutorServiceTest {

    @Mock
    private RuntimeService runtimeService;

    @Mock
    private DelegateExecution delegateExecution;

    private EnrollmentExecutorService enrollmentExecutorService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        enrollmentExecutorService = new EnrollmentExecutorService(runtimeService);
    }

    @Test
    void testExecute() throws Exception {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        associateEvents.add(new AssociateEvent());
        Map<String, Object> variables = new HashMap<>();
        variables.put(ApplicationConstants.ASSOCIATE_EVENTS, associateEvents);
        when(delegateExecution.getVariables()).thenReturn(variables);
        enrollmentExecutorService.execute(delegateExecution);
        verify(runtimeService, times(1)).startProcessInstanceByKey(anyString(), anyMap());
    }

    @Test
    void testExecute_ExceptionCase() throws Exception {
        List<AssociateEvent> associateEvents = new ArrayList<>();
        associateEvents.add(new AssociateEvent());

        Map<String, Object> variables = new HashMap<>();
        variables.put(ApplicationConstants.ASSOCIATE_EVENTS, associateEvents);

        when(delegateExecution.getVariables()).thenReturn(variables);
        when(runtimeService.startProcessInstanceByKey(anyString(), anyMap())).thenThrow(new RuntimeException("Mock Exception"));

        assertThrows(RuntimeException.class, () -> {
            enrollmentExecutorService.execute(delegateExecution);
        });
    }
}