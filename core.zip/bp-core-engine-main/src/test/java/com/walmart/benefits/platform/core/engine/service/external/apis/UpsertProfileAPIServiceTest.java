package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class UpsertProfileAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private UpsertProfileAPIService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testExecute_SuccessfulResponse() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            when(associateEvent.getPlanType()).thenReturn(PlanType.DENTAL_US);
            AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
            AssociateBenefit associateBenefitObject = AssociateBenefit.builder().planId(PlanType.RETIREMENT_401K_CATCHUP_ROTH_US.getPlanId()).build();
            List<AssociateBenefit> associateBenefit = List.of(associateBenefitObject);
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent, ASSOCIATE_BENEFITS_PROFILE, associateBenefitsProfile, ASSOCIATE_COVERAGE, associateBenefit, PLAN_TYPE, DENTAL));
            when(associateEvent.getAssociateId()).thenReturn("12345");
            when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(httpUtils.getProfileUpsertUrl()).thenReturn("http://test.com/profile/upsert");
            when(httpUtils.getHttpEntity(associateBenefitsProfile, httpUtils.getBenefitsProfileServiceAppName())).thenReturn(null);
            ResponseEntity<AssociateBenefitsProfile> profileResponse = new ResponseEntity<>(associateBenefitsProfile, HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/profile/upsert", HttpMethod.PATCH, null, AssociateBenefitsProfile.class))
                    .thenReturn(profileResponse);

            when(httpUtils.getTransactionLogUrl()).thenReturn("http://test.com/transaction/log");
            ResponseEntity<String> transactionLogResponse = new ResponseEntity<>("Logged", HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class))
                    .thenReturn(transactionLogResponse);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(restTemplate, times(1)).exchange("http://test.com/profile/upsert", HttpMethod.PATCH, null, AssociateBenefitsProfile.class);
            verify(restTemplate, times(1)).exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class);
        }
    }

    @Test
    void testExecute_ServerErrorException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateEvent associateEvent = mock(AssociateEvent.class);
            AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
            when(delegateExecution.getVariables()).thenReturn(Map.of(ASSOCIATE_EVENT, associateEvent, ASSOCIATE_BENEFITS_PROFILE, associateBenefitsProfile));
            when(associateEvent.getAssociateId()).thenReturn("12345");
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(1);

            when(httpUtils.getProfileUpsertUrl()).thenReturn("http://test.com/profile/upsert");
            HttpServerErrorException serverError = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange("http://test.com/profile/upsert", HttpMethod.PATCH, null, AssociateBenefitsProfile.class))
                    .thenThrow(serverError);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(httpUtils, times(1)).handleError(delegateExecution, serverError, 1, ASSOCIATE_PROFILE_SERVICE_UPSERT_SERVER_ERROR);
        }
    }

    @Test
    void testExecute_GeneralException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenThrow(new RuntimeException("Unexpected error"));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            RuntimeException thrown = assertThrows(
                    RuntimeException.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Unexpected error"));
        }
    }
}