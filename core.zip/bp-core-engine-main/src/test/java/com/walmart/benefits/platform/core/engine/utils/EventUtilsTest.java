package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefits.platform.core.engine.model.HardshipModel;
import com.walmart.benefits.platform.core.engine.model.LoanModel;
import com.walmart.benefits.platform.core.engine.model.RetirementContributionRateEvent;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityOutput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Contribution;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.ContributionType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Tier;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.EnrollmentStatus;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.PlanElection;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Consent;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EventUtilsTest {

    private BenefitsEntity benefitsEntity;
    private AssociateEvent associateEvent;
    private AssociateBenefitsProfile existingProfile;
    private RetirementContributionRateEvent rateEvent;
    private PlanEligibility planEligibility1, planEligibility2;

    @BeforeEach
    void setup() {
        // Mock BenefitsEntity
        benefitsEntity = mock(BenefitsEntity.class);
        existingProfile = mock(AssociateBenefitsProfile.class);

        // Mock sub-objects for InterDomainInfo and IntraDomainInfo
        var interDomainInfo = mock(InterDomainInfo.class);
        var intraDomainInfo = mock(IntraDomainInfo.class);
        var associateInfo = mock(AssociateInfo.class);
        var associateBenefitsProfile = mock(AssociateBenefitsProfile.class);
        var eligibility = mock(Eligibility.class);

        // Mock PlanEligibility
        planEligibility1 = new PlanEligibility();
        planEligibility1.setEligibleDate("2024-01-01");
        planEligibility1.setIsEligible(true);
        planEligibility1.setPlanGroup("planName");
        planEligibility1.setPlanId("planId");

        planEligibility2 = new PlanEligibility();
        planEligibility2.setEligibleDate("2023-01-01");
        planEligibility2.setIsEligible(true);
        planEligibility2.setPlanGroup("planName1");
        planEligibility2.setPlanId("planId1");

        // Set up the hierarchy of mocks
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);

        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
        when(associateInfo.getAssociateId()).thenReturn("12345");

        when(intraDomainInfo.getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);
        when(intraDomainInfo.getAssociateBenefitsProfile().getAssociateId()).thenReturn("12345");
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        when(eligibility.getPlans()).thenReturn(Collections.singletonList(planEligibility1));

        // Mock AssociateEvent
        associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        when(associateEvent.getPlanType()).thenReturn(PlanType.NONE);
        when(associateEvent.getAssociateId()).thenReturn("12345");
        when(associateEvent.getTimeStamp()).thenReturn("2024-12-18T10:00:00.0000000Z");
        when(associateEvent.getOrigin()).thenReturn(EventOrigin.ML);

        // Mock _401kContributionRateEvent
        rateEvent = mock(RetirementContributionRateEvent.class);
        when(rateEvent.getRateChanged()).thenReturn(5.0);
    }


    @Test
    void testAssociateProfile() {
        AssociateBenefitsProfile result = EventUtils.associateProfile(benefitsEntity);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertNotNull(result.getEligibility());
        assertEquals(SYSTEM_CORE_ENGINE, result.getCreatedBy());
    }

    @Test
    void testCompareAssociateProfile_WhenExistingProfileIsNull() {
        AssociateBenefitsProfile result = EventUtils.compareAssociateProfile(benefitsEntity, null);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertNotNull(result.getEligibility());
        assertEquals(SYSTEM_CORE_ENGINE, result.getCreatedBy());
    }

    @Test
    void testCompareAssociateProfile() {
        when(benefitsEntity.getInterDomainInfo().getAssociateInfo().getAssociateId()).thenReturn("12345");
        Eligibility eligibility = mock(Eligibility.class);
        when(eligibility.getPlans()).thenReturn(List.of(planEligibility1, planEligibility2));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile().getEligibility()).thenReturn(eligibility);
        when(existingProfile.getAssociateId()).thenReturn("12345");
        when(existingProfile.getEligibility()).thenReturn(eligibility);
        AssociateBenefitsProfile resultProfile = EventUtils.compareAssociateProfile(benefitsEntity, existingProfile);
        assertEquals("12345", resultProfile.getAssociateId());
        assertEquals(eligibility, resultProfile.getEligibility());
    }

    @Test
    void testCompareAssociateProfile_WhenExistingProfileIsNotNull() {
        AssociateBenefitsProfile result = EventUtils.compareAssociateProfile(benefitsEntity, existingProfile);

        assertNotNull(result);
        verify(existingProfile).setCreatedBy(SYSTEM_CORE_ENGINE);
    }

    @Test
    void testAssociateCoverage() {
        List<AssociateBenefit> benefits = EventUtils.associateCoverage(benefitsEntity);

        assertNotNull(benefits);
        assertEquals(1, benefits.size());
        assertEquals("12345", benefits.get(0).getAssociateId());
        assertEquals("planId", benefits.get(0).getPlanId());
        assertEquals("planName", benefits.get(0).getPlanGroup());
    }

    @Test
    void testUpdateProfile() {
        AssociateBenefitsProfile result = EventUtils.updateProfile(associateEvent, benefitsEntity);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertNotNull(result.getEligibility());
    }

    @Test
    void testCreateCoverage() {
        Contribution associateContribution = new Contribution();
        associateContribution.setValue(5.0);
        Map<String, Object> additionalInfo = Map.of("contribution", associateContribution,"coverageOption", "DEN_COVERAGE","activity", "NEWLY_ELIGIBLE");
        when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);
        List<AssociateBenefit> result = EventUtils.createCoverage(associateEvent, Activity.RATE_CHANGE);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("12345", result.get(0).getAssociateId());
        assertEquals(5.0, result.get(0).getContribution().getValue());
    }

    @Test
    void testUpdateCoverage() {
        AssociateBenefit coverage = new AssociateBenefit();
        Contribution contribution = new Contribution();
        contribution.setValue(3.0);
        coverage.setContribution(contribution);
        coverage.setPlanId("planId");

        Contribution associateContribution = new Contribution();
        associateContribution.setValue(5.0);
        Map<String, Object> additionalInfo = Map.of("contribution", associateContribution);
        when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);

        AssociateBenefit result = EventUtils.updateCoverage(associateEvent, coverage);

        assertNotNull(result);}
@Test
void createCoverage_setsCorrectFieldsForHardshipModel() {
    AssociateEvent associateEvent = new AssociateEvent();
    associateEvent.setAssociateId("12345");
    associateEvent.setPlanType(PlanType.RETIREMENT_401K_HARDSHIP_US);
    associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
    associateEvent.setOrigin(EventOrigin.ML);

    HardshipModel hardshipModel = new HardshipModel();
    hardshipModel.setStartDate("2024-01-01");
    hardshipModel.setResumeDate("2024-07-01");

    AssociateBenefit result = EventUtils.createCoverage(associateEvent, hardshipModel);

    assertNotNull(result);
    assertEquals("12345", result.getAssociateId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId(), result.getPlanId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanGroup(), result.getPlanGroup());
    assertEquals("2024-01-01", result.getStartDate());
    assertEquals("2024-07-01", result.getEndDate());
    assertEquals("ML", result.getCreatedBy());
    assertEquals("2024-12-18T10:00:00.0000000Z", result.getCreatedAt());
    assertNull(result.getContribution());
}

@Test
void createCoverage_setsEndDateBasedOnCountryCodePR() {
    AssociateEvent associateEvent = new AssociateEvent();
    associateEvent.setAssociateId("12345");
    associateEvent.setPlanType(PlanType.RETIREMENT_401K_HARDSHIP_PR);
    associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
    associateEvent.setOrigin(EventOrigin.ML);

    HardshipModel hardshipModel = new HardshipModel();
    hardshipModel.setStartDate("2024-01-01");
    hardshipModel.setResumeDate("2025-01-01");

    AssociateBenefit result = EventUtils.createCoverage(associateEvent, hardshipModel);

    assertNotNull(result);
    assertEquals("12345", result.getAssociateId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_PR.getPlanId(), result.getPlanId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_PR.getPlanGroup(), result.getPlanGroup());
    assertEquals("2024-01-01", result.getStartDate());
    assertEquals("2025-01-01", result.getEndDate());
    assertEquals("ML", result.getCreatedBy());
    assertEquals("2024-12-18T10:00:00.0000000Z", result.getCreatedAt());
    assertNull(result.getContribution());
}

@Test
void createCoverage_setsEndDateBasedOnCountryCodeUS() {
    AssociateEvent associateEvent = new AssociateEvent();
    associateEvent.setAssociateId("12345");
    associateEvent.setPlanType(PlanType.RETIREMENT_401K_HARDSHIP_US);
    associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
    associateEvent.setOrigin(EventOrigin.ML);

    HardshipModel hardshipModel = new HardshipModel();
    hardshipModel.setStartDate("2024-01-01");
    hardshipModel.setResumeDate("2024-07-01");

    AssociateBenefit result = EventUtils.createCoverage(associateEvent, hardshipModel);

    assertNotNull(result);
    assertEquals("12345", result.getAssociateId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId(), result.getPlanId());
    assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanGroup(), result.getPlanGroup());
    assertEquals("2024-01-01", result.getStartDate());
    assertEquals("2024-07-01", result.getEndDate());
    assertEquals("ML", result.getCreatedBy());
    assertEquals("2024-12-18T10:00:00.0000000Z", result.getCreatedAt());
    assertNull(result.getContribution());
}

@Test
void createCoverage_handlesNullHardshipModel() {
    AssociateEvent associateEvent = new AssociateEvent();
    associateEvent.setAssociateId("12345");
    associateEvent.setPlanType(PlanType.RETIREMENT_401K_HARDSHIP_US);
    associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
    associateEvent.setOrigin(EventOrigin.ML);

    HardshipModel hardshipModel = new HardshipModel();
    hardshipModel.setStartDate("2024-01-01");
    hardshipModel.setResumeDate("2024-07-01");
    AssociateBenefit result = EventUtils.createCoverage(associateEvent, hardshipModel);

    HardshipModel model = null;

    assertThrows(NullPointerException.class, () -> EventUtils.createCoverage(associateEvent, model));
        assertNotNull(result.getLastModifiedAt());
        assertNull( result.getLastModifiedBy());
        assertThrows(NullPointerException.class, ()->result.getContribution().getValue());
    }

    @Test
    void testCreateEnrollment() {
        try (MockedStatic<CommonUtils> mockedCommonUtils = Mockito.mockStatic(CommonUtils.class)) {
            mockedCommonUtils.when(() -> CommonUtils.getContributionFromEvent(associateEvent)).thenReturn(rateEvent);
            Enrollment enrollment = EventUtils.createEnrollment(associateEvent);

            assertNotNull(enrollment);
            assertEquals("12345", enrollment.getAssociateId());
            assertEquals("ML", enrollment.getCreatedBy());
        }
    }

    @Test
    void testSet401kContribution() {
        Contribution associateContribution = new Contribution();
        associateContribution.setValue(5.0);
        Map<String, Object> additionalInfo = Map.of("contribution", associateContribution);
        when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);
        Contribution contribution = EventUtils.getContribution(additionalInfo);

        assertNotNull(contribution);
        assertEquals(ContributionType.PERCENT, contribution.getType());
        assertEquals(5.0, contribution.getValue());
    }

    @Test
    void testIsRateChanged() {
        // Arrange
        AssociateBenefit coverage = mock(AssociateBenefit.class);
        Contribution existingContribution = new Contribution();
        existingContribution.setValue(5.0);
        existingContribution.setType(ContributionType.PERCENT);
        when(coverage.getContribution()).thenReturn(existingContribution);

        AssociateEvent associateEvent = mock(AssociateEvent.class);
        Contribution contribution = new Contribution();
        contribution.setValue(10.0);
        contribution.setType(ContributionType.PERCENT);
        Map<String, Object> additionalInfo = Map.of("contribution", contribution);
        when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);

        // Act
        boolean result = EventUtils.isRateChanged(coverage, associateEvent);

        // Assert
        assertTrue(result);

    }

    @Test
    void testGetStoreStateProvCdWhenNull() {
        assertThrows(RuntimeException.class, () -> EventUtils.getStoreStateProvCd(null));
    }

    @Test
    void testGetStoreStateProvCdWhenNotPR() {
        String storeStateProvCd = "NY";
        assertEquals("US", EventUtils.getStoreStateProvCd(storeStateProvCd));
    }

    @Test
    void testGetStoreStateProvCdWhenPR() {
        String storeStateProvCd = "PR";
        assertEquals("PR", EventUtils.getStoreStateProvCd(storeStateProvCd));
    }

    @Test
    void testCreateNewAssociateEvent() {
        AssociateEvent newEvent = EventUtils.createNewAssociateEvent(associateEvent, PlanType.RETIREMENT_401K_REGULAR_US);

        assertEquals(associateEvent.getEventType(), newEvent.getEventType());
        assertEquals(associateEvent.getAssociateId(), newEvent.getAssociateId());
        assertEquals(associateEvent.getAdditionalInfo(), newEvent.getAdditionalInfo());
        assertEquals(associateEvent.getOrigin(), newEvent.getOrigin());
        assertEquals(associateEvent.getTimeStamp(), newEvent.getTimeStamp());
        assertEquals(associateEvent.getId(), newEvent.getId());
        assertEquals(PlanType.valueOf(PlanType.RETIREMENT_401K_REGULAR_US.toString()), newEvent.getPlanType());
    }

    @Test
    void testUpdateCoverageFromRules() {
        // Mock IntraDomainInfo
        var intraDomainInfo = mock(IntraDomainInfo.class);
        // Mock AssociateBenefit
        var associateBenefit = mock(AssociateBenefit.class);
        // Mock Contribution
        var contribution = mock(Contribution.class);

        // When associateBenefit.getContribution() is called, return contribution
        when(associateBenefit.getContribution()).thenReturn(contribution);

        // When benefitsEntity.getIntraDomainInfo() is called, return intraDomainInfo
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);
        // When intraDomainInfo.getAssociateBenefit() is called, return associateBenefit
        when(intraDomainInfo.getAssociateBenefit()).thenReturn(associateBenefit);

        // Call method under test
        AssociateBenefit result = EventUtils.updateCoverageFromRules(benefitsEntity,  TRUE);

        // Verify the interactions and the result
        verify(associateBenefit).getPlanId();
        verify(associateBenefit).getPlanGroup();
        verify(associateBenefit).getStartDate();
        verify(associateBenefit).getEndDate();
        verify(contribution).getValue();

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertEquals("SYSTEM_CORE_ENGINE", result.getLastModifiedBy());
        assertNotNull(result.getLastModifiedAt());
    }

    @Test
    void testLoanCreateCoverage() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
        associateEvent.setOrigin(EventOrigin.ML);

        LoanModel loanModel = new LoanModel();
        loanModel.setLoanNumber("LN123");
        loanModel.setLoanType("TypeA");
        loanModel.setDeductionAmount(1000.0);

        AssociateBenefit result = EventUtils.createCoverage(associateEvent, loanModel);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), result.getPlanId());
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup(), result.getPlanGroup());
        assertEquals("2024-12-18T10:00:00.0000000Z", result.getStartDate());
        assertEquals("2024-12-18T10:00:00.0000000Z", result.getCreatedAt());
        assertEquals("ML", result.getCreatedBy());
        assertEquals("LN123", result.getLoanId());
        assertEquals("LN123", result.getLoanSequenceNumber());
        assertEquals(1000.0, result.getDeduction().getValue());
    }

    @Test
    void testSetCompanyMatchEligibility() {
        Eligibility eligibility = new Eligibility();
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        CompanyMatchEligibilityOutput companyMatchEligibilityOutput = new CompanyMatchEligibilityOutput();
        companyMatchEligibilityOutput.setCompanyMatchEligibilityDate("2025-01-01");
        companyMatchEligibilityOutput.setCompanyMatchEligibilityIndicator(true);
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setEligibility(eligibility);
        BenefitsEntity benefitsEntity1 = new BenefitsEntity();
        benefitsEntity1.setIntraDomainInfo(IntraDomainInfo.builder().associateBenefitsProfile(associateBenefitsProfile).build());
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());

        List<PlanEligibility> plans = new ArrayList<>();
        plans.add(planEligibility);
        eligibility.setPlans(plans);
        EventUtils.setCompanyMatchEligibility(companyMatchEligibilityOutput, planType, benefitsEntity1);

        assertEquals("2025-01-01", planEligibility.getCompanyMatchEligibleDate());
        assertTrue(planEligibility.getIsCompanyMatchEligible());
    }

    @Test
    void testSetOriginalHireDate() {
        Eligibility eligibility = new Eligibility();
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        RehireIndicatorOutput rehireIndicatorOutput = new RehireIndicatorOutput();
        rehireIndicatorOutput.setOriginalHireDate("2025-01-01");
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setEligibility(eligibility);
        BenefitsEntity benefitsEntity1 = new BenefitsEntity();
        benefitsEntity1.setIntraDomainInfo(IntraDomainInfo.builder().associateBenefitsProfile(associateBenefitsProfile).build());
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());

        List<PlanEligibility> plans = new ArrayList<>();
        plans.add(planEligibility);
        eligibility.setPlans(plans);

        EventUtils.setOriginalHireDate(rehireIndicatorOutput, planType, benefitsEntity1);

        assertEquals("2025-01-01", planEligibility.getOriginalHireDate());
    }

    @Test
    void createEnrollmentFromPlanElections() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");
        associateEvent.setPlanType(PlanType.RETIREMENT_401K_REGULAR_US);
        associateEvent.setTimeStamp("2024-12-18T10:00:00.0000000Z");
        associateEvent.setOrigin(EventOrigin.ML);

        List<PlanElection> mockElections = new ArrayList<>();

        PlanElection election1 = new PlanElection();
        election1.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId());
        election1.setTier(Tier.ASSOCIATE);
        election1.setPlanGroup(PlanType.RETIREMENT_401K_REGULAR_US.getPlanGroup());
        election1.setContribution(null);
        PlanElection election2 = new PlanElection();

        mockElections.add(election1);
        mockElections.add(election2);

        Enrollment response = EventUtils.createEnrollmentFromPlanElections(associateEvent,mockElections);

        assertEquals(SYSTEM_CORE_ENGINE,response.getCreatedBy());
        assertEquals(EnrollmentStatus.COMPLETED,response.getStatus());
    }
    // Test case: When the hardship plan does not exist, it should be added to the profile.
    @Test
    void testUpdateAssociateProfile_AddNewHardshipPlan() {
        // Arrange
        AssociateBenefitsProfile existingProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(new ArrayList<>());
        existingProfile.setEligibility(eligibility);

        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_HARDSHIP_US);

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");
        hardshipModel.setResumeDate("2024-07-01");

        // Act
        EventUtils.updateAssociateProfile(existingProfile, associateEvent, hardshipModel);

        // Assert
        assertNotNull(existingProfile.getEligibility().getPlans());
        assertEquals(1, existingProfile.getEligibility().getPlans().size());
        PlanEligibility addedPlan = existingProfile.getEligibility().getPlans().get(0);
        assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId(), addedPlan.getPlanId());
        assertEquals("2024-01-01", addedPlan.getEligibleDate());
        assertTrue(addedPlan.getIsEligible());
    }

    // Test case: When the hardship plan already exists, it should update the existing plan.
    @Test
    void testUpdateAssociateProfile_UpdateExistingHardshipPlan() {
        // Arrange
        PlanEligibility existingPlan = new PlanEligibility();
        existingPlan.setPlanId(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId());
        existingPlan.setIsEligible(false);
        existingPlan.setEligibleDate("2023-07-01");

        AssociateBenefitsProfile existingProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(new ArrayList<>(List.of(existingPlan)));
        existingProfile.setEligibility(eligibility);

        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_HARDSHIP_US);

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");
        hardshipModel.setResumeDate("2024-07-01");

        // Act
        EventUtils.updateAssociateProfile(existingProfile, associateEvent, hardshipModel);

        // Assert
        assertNotNull(existingProfile.getEligibility().getPlans());
        assertEquals(1, existingProfile.getEligibility().getPlans().size());
        PlanEligibility updatedPlan = existingProfile.getEligibility().getPlans().get(0);
        assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId(), updatedPlan.getPlanId());
        assertEquals("2024-01-01", updatedPlan.getEligibleDate());
        assertTrue(updatedPlan.getIsEligible());
    }

    // Test case: When the eligibility plans list is null, it should not throw an exception.
    @Test
    void testUpdateAssociateProfile_NullEligibilityPlans() {
        // Arrange
        AssociateBenefitsProfile existingProfile = new AssociateBenefitsProfile();
        existingProfile.setEligibility(new Eligibility());

        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_HARDSHIP_US);

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");
        hardshipModel.setResumeDate("2024-07-01");

        // Act
        EventUtils.updateAssociateProfile(existingProfile, associateEvent, hardshipModel);

        assertNotNull(existingProfile.getEligibility().getPlans());
        assertEquals(1, existingProfile.getEligibility().getPlans().size());
        PlanEligibility addedPlan = existingProfile.getEligibility().getPlans().get(0);
        assertEquals(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId(), addedPlan.getPlanId());
        assertEquals("2024-01-01", addedPlan.getEligibleDate());
        assertTrue(addedPlan.getIsEligible());
    }

    // Test case: Verify the last modified timestamp is updated.
    @Test
    void testUpdateAssociateProfile_LastModifiedAtUpdated() {
        // Arrange
        AssociateBenefitsProfile existingProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(new ArrayList<>());
        existingProfile.setEligibility(eligibility);

        AssociateEvent associateEvent = mock(AssociateEvent.class);
        when(associateEvent.getPlanType()).thenReturn(PlanType.RETIREMENT_401K_HARDSHIP_US);

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");
        hardshipModel.setResumeDate("2024-07-01");

        // Act
        EventUtils.updateAssociateProfile(existingProfile, associateEvent, hardshipModel);

        // Assert
        assertNotNull(existingProfile.getLastModifiedAt());
    }

    @Test
    void updateCoverageList_updatesEndDateAndContributionForNonHardshipPlans() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");

        AssociateBenefit coverage1 = new AssociateBenefit();
        coverage1.setPlanId("NON_HARDSHIP_PLAN_1");
        coverage1.setPlanGroup("Retirement");
        coverage1.setContribution(new Contribution());

        AssociateBenefit coverage2 = new AssociateBenefit();
        coverage2.setPlanId("NON_HARDSHIP_PLAN_2");
        coverage2.setPlanGroup("Retirement");
        coverage2.setContribution(new Contribution());

        List<AssociateBenefit> coverages = List.of(coverage1, coverage2);

        List<AssociateBenefit> updatedCoverages = EventUtils.updateCoverageList(coverages, hardshipModel);

        assertNotNull(updatedCoverages);
        assertEquals(2, updatedCoverages.size());
        for (AssociateBenefit coverage : updatedCoverages) {
            assertEquals("2024-01-01", coverage.getEndDate());
            assertEquals(0.0, coverage.getContribution().getValue());
            assertNotNull(coverage.getLastModifiedAt());
            assertEquals(SYSTEM_CORE_ENGINE, coverage.getLastModifiedBy());
        }
    }

    @Test
    void updateCoverageList_skipsHardshipPlans() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");

        AssociateBenefit hardshipCoverage1 = new AssociateBenefit();
        hardshipCoverage1.setPlanId(PlanType.RETIREMENT_401K_HARDSHIP_PR.getPlanId());

        AssociateBenefit hardshipCoverage2 = new AssociateBenefit();
        hardshipCoverage2.setPlanId(PlanType.RETIREMENT_401K_HARDSHIP_US.getPlanId());

        List<AssociateBenefit> coverages = List.of(hardshipCoverage1, hardshipCoverage2);

        List<AssociateBenefit> updatedCoverages = EventUtils.updateCoverageList(coverages, hardshipModel);

        assertNotNull(updatedCoverages);
        assertEquals(2, updatedCoverages.size());
        for (AssociateBenefit coverage : updatedCoverages) {
            assertNull(coverage.getEndDate());
            assertNull(coverage.getContribution());
        }
    }

    @Test
    void updateCoverageList_handlesEmptyCoverageList() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");

        List<AssociateBenefit> coverages = new ArrayList<>();

        List<AssociateBenefit> updatedCoverages = EventUtils.updateCoverageList(coverages, hardshipModel);

        assertNotNull(updatedCoverages);
        assertTrue(updatedCoverages.isEmpty());
    }

    @Test
    void updateCoverageList_handlesNullCoverageList() {
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setAssociateId("12345");

        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setStartDate("2024-01-01");


        assertThrows(NullPointerException.class,()->EventUtils.updateCoverageList(null, hardshipModel));
    }

    @Test
    void updateConsentProfile_setsCorrectFields() {
        Enrollment enrollment = new Enrollment();
        Consent consent = new Consent();
        enrollment.setConsent(consent);
        enrollment.setAssociateId("12345");

        AssociateBenefitsProfile result = EventUtils.updateConsentProfile(enrollment);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertEquals(consent, result.getConsent());
    }

    @Test
    void updateConsentProfile_handlesNullConsent() {
        Enrollment enrollment = new Enrollment();
        enrollment.setConsent(null);
        enrollment.setAssociateId("12345");

        AssociateBenefitsProfile result = EventUtils.updateConsentProfile(enrollment);

        assertNotNull(result);
        assertEquals("12345", result.getAssociateId());
        assertNull(result.getConsent());
    }

    @Test
    void updateConsentProfile_handlesNullEnrollment() {
        assertThrows(NullPointerException.class, () -> EventUtils.updateConsentProfile(null));
    }
    @Test
    void testUpdatePlanEligibility_NoUpdateWhenValuesAlreadyMatch() {
        // Arrange
        AssociateBenefitsProfile existingProfile = new AssociateBenefitsProfile();
        Eligibility eligibility = new Eligibility();

        // Create a plan with existing match eligibility values
        PlanEligibility existingPlan = new PlanEligibility();
        existingPlan.setPlanGroup(RETIREMENT);
        existingPlan.setPlanId("retirement_401k_catchup_us");
        existingPlan.setIsCompanyMatchEligible(true);
        existingPlan.setCompanyMatchEligibleDate("2024-05-01");

        eligibility.setPlans(new ArrayList<>(List.of(existingPlan)));
        existingProfile.setEligibility(eligibility);

        String initialModifiedTime = "2024-05-10T12:00:00.000Z";
        existingProfile.setLastModifiedAt(initialModifiedTime);
        existingProfile.setLastModifiedBy("SYSTEM_CORE_ENGINE");

        // Create hardship model with matching values
        HardshipModel hardshipModel = new HardshipModel();
        hardshipModel.setMerMatchEligDate("2024-05-01");
        hardshipModel.setMerMatchEligInd(ELIGIBLE);

        // Act
        EventUtils.updatePlanEligibility(existingProfile, hardshipModel);

        // Assert
        // Verify no updates were made - last modified values should remain unchanged
        assertEquals(initialModifiedTime, existingProfile.getLastModifiedAt());
        assertEquals("SYSTEM_CORE_ENGINE", existingProfile.getLastModifiedBy());

        // Verify plan values are unchanged
        PlanEligibility plan = existingProfile.getEligibility().getPlans().get(0);
        assertEquals("2024-05-01", plan.getCompanyMatchEligibleDate());
        assertTrue(plan.getIsCompanyMatchEligible());
    }

}
