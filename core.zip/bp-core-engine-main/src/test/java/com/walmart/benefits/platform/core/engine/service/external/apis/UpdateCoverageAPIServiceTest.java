package com.walmart.benefits.platform.core.engine.service.external.apis;

import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.platform.core.engine.utils.HttpUtils;
import com.walmart.benefits.platform.core.engine.utils.ProcessEngineUtil;
import com.walmart.benefits.platform.core.engine.utils.TransactionLogUtil;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.OriginSystem;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class UpdateCoverageAPIServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpUtils httpUtils;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @InjectMocks
    private UpdateCoverageAPIService service;

    @Mock
    private AssociateEvent associateEvent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(associateEvent.getAssociateId()).thenReturn("12345");
        EventType eventType = EventType.NEW_HIRE;
        when(associateEvent.getEventType()).thenReturn(eventType);
    }

    @Test
    void testExecute_SuccessfulResponse() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            Enrollment enrollment = new Enrollment();
            enrollment.setOriginSystem(OriginSystem.OE);
            AssociateBenefit updateCoverage = new AssociateBenefit();
            when(delegateExecution.getVariables()).thenReturn(Map.of(UPDATE_COVERAGE, updateCoverage, ASSOCIATE_EVENT, associateEvent));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            when(httpUtils.getCoverageUpsertUrl()).thenReturn("http://test.com/coverage/update");
            when(httpUtils.getHttpEntity(updateCoverage, httpUtils.getAssociateBenefitServiceAppName())).thenReturn(null);
            ResponseEntity<String> coverageResponse = new ResponseEntity<>("Success", HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/coverage/update", HttpMethod.PATCH, null, String.class))
                    .thenReturn(coverageResponse);

            when(httpUtils.getTransactionLogUrl()).thenReturn("http://test.com/transaction/log");
            when(httpUtils.getHttpEntity(TransactionLogUtil.getTransactionLogCoverage(updateCoverage, associateEvent, enrollment, delegateExecution),
                    httpUtils.getTransactionLogServiceAppName())).thenReturn(null);
            ResponseEntity<String> transactionLogResponse = new ResponseEntity<>("Logged", HttpStatus.OK);
            when(restTemplate.exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class))
                    .thenReturn(transactionLogResponse);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(restTemplate, times(1)).exchange("http://test.com/coverage/update", HttpMethod.PATCH, null, String.class);
            verify(restTemplate, times(1)).exchange("http://test.com/transaction/log", HttpMethod.POST, null, String.class);
        }
    }

    @Test
    void testExecute_ServerErrorException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            AssociateBenefit updateCoverage = new AssociateBenefit();
            when(delegateExecution.getVariables()).thenReturn(Map.of(UPDATE_COVERAGE, updateCoverage,ASSOCIATE_EVENT, associateEvent));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(1);

            when(httpUtils.getCoverageUpsertUrl()).thenReturn("http://test.com/coverage/update");
            HttpServerErrorException serverError = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
            when(restTemplate.exchange("http://test.com/coverage/update", HttpMethod.PATCH, null, String.class))
                    .thenThrow(serverError);

            // Execute
            service.execute(delegateExecution);

            // Verify
            verify(httpUtils, times(1)).handleError(delegateExecution, serverError, 1, ASSOCIATE_COVERAGE_SERVICE_UPDATE_SERVER_ERROR);
        }
    }

    @Test
    void testExecute_GeneralException() throws Exception {
        try (MockedStatic<ProcessEngineUtil> processEngineUtilMockedStatic = mockStatic(ProcessEngineUtil.class)) {
            // Mock variables
            when(delegateExecution.getVariables()).thenThrow(new BpmnError("Unexpected error","Unexpected error"));
            processEngineUtilMockedStatic.when(() -> ProcessEngineUtil.getRetryCount(delegateExecution)).thenReturn(0);

            BpmnError thrown = assertThrows(
                    BpmnError.class,
                    () -> service.execute(delegateExecution),
                    "Expected process to throw, but it didn't"
            );
            assertTrue(thrown.getMessage().contains("Unexpected error"));
        }
    }
}
