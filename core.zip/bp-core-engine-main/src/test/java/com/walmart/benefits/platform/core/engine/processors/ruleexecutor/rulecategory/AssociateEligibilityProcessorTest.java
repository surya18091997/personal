package com.walmart.benefits.platform.core.engine.processors.ruleexecutor.rulecategory;

import com.walmart.benefits.platform.core.engine.processors.rulerequest.DefaultNewHireRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.RuleRequestProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement.RetirementNewHireRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.DefaultNewHireRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.RuleResponseProcessorFactory;
import com.walmart.benefits.platform.core.engine.processors.ruleresponse.retirement.RetirementNewHireRuleResponseProcessor;
import com.walmart.benefits.platform.core.engine.utils.EncryptionUtil;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleExecutionException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RuleMetadataSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.exceptions.RulesSyncException;
import com.walmart.benefits.rules.benefitsrulessdk.executor.RuleExecutorFactory;
import com.walmart.benefits.rules.benefitsrulessdk.executor.services.RuleExecutorService;
import com.walmart.benefits.rules.benefitsrulessdk.mapper.factory.InputSchemaMapperFactory;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleRequest;
import com.walmart.benefits.rules.benefitsrulessdk.models.RuleResponse;
import com.walmart.benefits.rules.benefitsrulessdk.models.enums.RuleCategory;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AssociateEligibilityProcessorTest {

    @InjectMocks
    private AssociateEligibilityProcessor processor;

    @Mock
    private EncryptionUtil encryptionUtil;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private BenefitsEntity benefitsEntity;

    @Mock
    private AssociateEvent associateEvent;

    @Mock
    private InterDomainInfo interDomainInfo;

    @Mock
    private AssociateInfo associateInfo;

    @Mock
    private RuleExecutorService<Object, Object> ruleExecutorService;

    @Mock
    private AssociateEligibilityOutput eligibilityOutput;

    @Mock
    private RuleResponse<AssociateEligibilityOutput> ruleResponse;

    List requestProcessors = List.of(new RetirementNewHireRuleRequestProcessor());

    List defaultNewHireRuleRequestProcessors = List.of(new DefaultNewHireRuleRequestProcessor());

    List responseProcessor = List.of(new RetirementNewHireRuleResponseProcessor());

    List defaultNewHireRuleResponseProcessors = List.of(new DefaultNewHireRuleResponseProcessor());

    private RuleRequestProcessorFactory processorFactory = new RuleRequestProcessorFactory(requestProcessors, defaultNewHireRuleRequestProcessors);

    private RuleResponseProcessorFactory responseProcessorFactory = new RuleResponseProcessorFactory(responseProcessor, defaultNewHireRuleResponseProcessors);


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(associateEvent.getEventType()).thenReturn(EventType.NEW_HIRE);
        processor = new AssociateEligibilityProcessor(
                encryptionUtil, processorFactory, responseProcessorFactory
        );
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
    }

//    @Test
//    void testProcessSuccess() throws Exception {
//
//        try (MockedStatic<InputSchemaMapperFactory> inputSchemaMapperFactoryMockedStatic = mockStatic(InputSchemaMapperFactory.class);
//             MockedStatic<RuleExecutorFactory> ruleExecutorFactoryMockedStatic = mockStatic(RuleExecutorFactory.class)) {
//
//            AssociateEligibilityInput associateEligibilityInput = new AssociateEligibilityInput();
//            associateEligibilityInput.setPlanName("Plan Name");
//
//            Map<String, Object> variables = Map.of(
//                    ASSOCIATE_EVENT, associateEvent,
//                    BENEFITS_ENTITY, benefitsEntity,
//                    PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.toString(),
//                    PLAN_TYPE, PlanType.RETIREMENT_401K_REGULAR_US.toString()
//            );
//
//
//            when(delegateExecution.getVariables()).thenReturn(variables);
//            when(delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);
//            when(InputSchemaMapperFactory.schemaToInput(any(BenefitsEntity.class), eq(AssociateEligibilityInput.class)))
//                    .thenReturn(associateEligibilityInput);
//            when(RuleExecutorFactory.createExecutor(RuleCategory.ASSOCIATE_ELIGIBILITY)).thenReturn(ruleExecutorService);
//            when(ruleExecutorService.execute(any(RuleRequest.class))).thenReturn(ruleResponse);
//            when(ruleResponse.getPayload()).thenReturn(eligibilityOutput);
//
//            processor.process(delegateExecution);
//
//            verify(delegateExecution).setVariable(eq(ASSOCIATE_ELIGIBILITY_INPUT), any(AssociateEligibilityInput.class));
//            verify(delegateExecution).setVariable(RULE_RESPONSE, eligibilityOutput);
//        }
//    }

    @Test
    void testProcessWithRuleExecutionException() throws RuleMetadataSyncException, RulesSyncException, RuleExecutionException {
        try (MockedStatic<InputSchemaMapperFactory> inputSchemaMapperFactoryMockedStatic = mockStatic(InputSchemaMapperFactory.class);
             MockedStatic<RuleExecutorFactory> ruleExecutorFactoryMockedStatic = mockStatic(RuleExecutorFactory.class)) {
            Map<String, Object> variables = Map.of(
                    ASSOCIATE_EVENT, associateEvent,
                    BENEFITS_ENTITY, benefitsEntity,
                    PLAN_TYPE, PlanType.RETIREMENT_401K_REGULAR_US.toString(),
                    PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.toString()
            );
            AssociateEligibilityInput associateEligibilityInput = new AssociateEligibilityInput();
            associateEligibilityInput.setPlanName("Plan Name");

            when(delegateExecution.getVariables()).thenReturn(variables);
            when(delegateExecution.getVariable(ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);
            when(InputSchemaMapperFactory.schemaToInput(any(BenefitsEntity.class), eq(AssociateEligibilityInput.class)))
                    .thenReturn(associateEligibilityInput);
            when(RuleExecutorFactory.createExecutor(RuleCategory.ASSOCIATE_ELIGIBILITY)).thenReturn(ruleExecutorService);
            when(ruleExecutorService.execute(any(RuleRequest.class))).thenThrow(new RuleExecutionException("Execution Failed"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> processor.process(delegateExecution));
            assertEquals("Rule Execution Failed", exception.getMessage());
        }
    }

    @Test
    void testGetRuleCategory() {
        assertEquals(RuleCategory.ASSOCIATE_ELIGIBILITY, processor.getRuleCategory());
    }

}
