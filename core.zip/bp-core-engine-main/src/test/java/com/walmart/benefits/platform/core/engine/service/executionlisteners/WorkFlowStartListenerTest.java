package com.walmart.benefits.platform.core.engine.service.executionlisteners;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.constants.Status;
import com.walmart.benefits.platform.core.engine.dao.EventArchiveDao;
import com.walmart.benefits.platform.core.engine.entity.Event;
import com.walmart.benefits.platform.core.engine.entity.EventStatus;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.retry.support.RetryTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class WorkFlowStartListenerTest {

    @Mock
    private EventArchiveDao eventArchiveDao;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private RetryTemplate retryTemplate;

    @InjectMocks
    private WorkFlowStartListener workFlowStartListener;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void notify_withNewHireEvent_addsEmptyEventStatus() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .eventType(EventType.NEW_HIRE).planType(PlanType.NONE)
                .origin(EventOrigin.CORE_HR)
                .build();
        Event event = new Event();
        event.setEventStatuses(new HashSet<>()); // Initialize eventStatuses
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.of(event));

        // Mock RetryTemplate to execute the lambda and return the expected value
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback) invocation.getArgument(0)).doWithRetry(null);
        });

        workFlowStartListener.notify(delegateExecution);

        assertEquals(1, event.getEventStatuses().size());
        List<Status> list = event.getEventStatuses().stream().map(EventStatus::getStatus).toList();
        assertEquals(Status.RECEIVED, list.get(0));
        verify(eventArchiveDao).save(event);
    }

    @Test
    void notify_withOtherEvent_addsEventStatusWithPlanId() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .planType(PlanType.RETIREMENT_401K_REGULAR_US)
                .eventType(EventType.RATE_CHANGE)
                .origin(EventOrigin.CORE_HR) // Initialize origin
                .build();
        Event event = new Event();
        event.setEventStatuses(new HashSet<>()); // Initialize eventStatuses
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.of(event));

        // Mock RetryTemplate to execute the lambda and return the expected value
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback) invocation.getArgument(0)).doWithRetry(null);
        });

        workFlowStartListener.notify(delegateExecution);

        assertEquals(1, event.getEventStatuses().size());
        List<Status> list = event.getEventStatuses().stream().map(EventStatus::getStatus).toList();
        List<String> planType = event.getEventStatuses().stream().map(EventStatus::getSubPlanType).toList();
        assertEquals(Status.RECEIVED, list.get(0));
        assertEquals(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(), planType.get(0));
        verify(eventArchiveDao).save(event);
    }

    @Test
    void notify_withEnrollmentApiOrigin_setsAssociateEventsVariable() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .origin(EventOrigin.CORE_HR).planType(PlanType.NONE)
                .eventType(EventType.NEW_HIRE)
                .additionalInfo(new LinkedHashMap<>())
                .build();
        Event event = new Event();
        event.setEventStatuses(new HashSet<>()); // Initialize eventStatuses
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.of(event));
        when(retryTemplate.execute(any())).thenAnswer(invocation -> {
            // The lambda receives a RetryContext, but we can ignore it for the test
            return ((org.springframework.retry.RetryCallback) invocation.getArgument(0)).doWithRetry(null);
        });
        workFlowStartListener.notify(delegateExecution);
        verify(eventArchiveDao).save(event);
    }

    @Test
    void notify_eventNotFound_throwsEventNotFoundException() {
        AssociateEvent associateEvent = AssociateEvent.builder()
                .id(UUID.randomUUID())
                .build();
        when(delegateExecution.getVariables()).thenReturn(Map.of(ApplicationConstants.ASSOCIATE_EVENT, associateEvent));
        when(eventArchiveDao.findById(associateEvent.getId())).thenReturn(Optional.empty());

        assertThrows(BpmnError.class, () -> workFlowStartListener.notify(delegateExecution));
    }

    @Test
    void convertMapToEnrollment_withValidMap_returnsEnrollment() {
        LinkedHashMap<String, Object> map = new LinkedHashMap<>();
        map.put("planElections", new ArrayList<>());

        Enrollment enrollment = WorkFlowStartListener.convertMapToEnrollment(map);

        assertNotNull(enrollment);
        assertNotNull(enrollment.getPlanElections());
    }

}