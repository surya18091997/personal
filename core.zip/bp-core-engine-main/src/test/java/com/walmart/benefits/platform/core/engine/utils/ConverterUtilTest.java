package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.modelmapper.MappingException;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ConverterUtilTest {

    @Test
    void testConvertToObject() {

        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setId(UUID.fromString("41b2f102-8568-4218-b458-a85f69acbfdd"));
        associateEvent.setAssociateId("12345678");
        associateEvent.setEventType(EventType.NEW_HIRE);

        Map<String, Object> map = new HashMap<>();
        map.put("id",UUID.fromString("41b2f102-8568-4218-b458-a85f69acbfdd"));
        map.put("associateId", 12345678);
        map.put("eventType", EventType.NEW_HIRE);

        AssociateEvent convertedObject = ConverterUtil.convertToObject(map, AssociateEvent.class);

        assertEquals(associateEvent, convertedObject);
    }

    @Test
    void testInvalidConvertToObject() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", "invalid_id");
        map.put("associateId", 12345678);
        map.put("eventType", EventType.NEW_HIRE);
        assertThrows(MappingException.class, ()-> ConverterUtil.convertToObject(map, AssociateEvent.class));
    }

    @Test
    void testConvertDateFormat() {
        String eligibleFrom = "01/01/2022";
        String expectedDate = "2022-01-01";

        String convertedDate = ConverterUtil.convertDateFormat(eligibleFrom);

        assertEquals(expectedDate, convertedDate);
    }

    @Test
    void testConvertTimestampDate() {
        String timeStamp = "2022-01-01T00:00:00.0000000Z";
        String expectedDate = "2022-01-01";

        String convertedDate = ConverterUtil.convertTimestampDate(timeStamp);

        assertEquals(expectedDate, convertedDate);
    }

    @Test
    void testConvertTimestampDate_NullInput() {
        Assert.assertThrows(NullPointerException.class, () -> ConverterUtil.convertTimestampDate(null));

    }

    @Test
    void testConvertDateToRuleExpectedFormat() {
        String eligibleFrom = "2025-01-01";
        String expectedDate = "01/01/2025";

        String convertedDate = ConverterUtil.convertDateToRuleExpectedFormat(eligibleFrom);

        assertEquals(expectedDate, convertedDate);
    }

    @Test
    void testConvertTimestampToRuleExpectedFormat() {
        String timeStamp = "2025-01-01T00:00:00";
        String expectedDate = "01/01/2025";

        String convertedDate = ConverterUtil.convertTimestampToRuleExpectedFormat(timeStamp);

        assertEquals(expectedDate, convertedDate);
    }

    @Test
    void testConvertStringToDate() {
        String dateStr = "2025-01-01";
        LocalDate expectedDate = LocalDate.parse("2025-01-01");

        LocalDate convertedDate = ConverterUtil.convertStringToDate(dateStr);

        assertEquals(expectedDate, convertedDate);
    }


}
