package com.walmart.benefits.platform.core.engine.processors.rulerequest.retirement;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.model.ConnectorResponse;
import com.walmart.benefits.platform.core.engine.utils.DataLakeJsonUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.companymatcheligibility.CompanyMatchEligibilityInput;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.rehireindicator.RehireIndicatorInput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.Employment;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.EmploymentHistory;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.StoreInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PayrollSnapShot;
import com.walmart.benefitsplatformentitymodel.intradomain.postPayrollSnapshot.PostPayrollSnapshot;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.mockito.Mockito.*;

class RetirementRehireRuleRequestProcessorTest {

    private RetirementRehireRuleRequestProcessor processor;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private PlanEligibility planEligibility;

    @Mock
    private PostPayrollSnapshot postPayrollSnapshot;

    @Mock
    private PayrollSnapShot payrollSnapShot;

    @Mock
    private DataLakeJsonUtil dataLakeJsonUtil;

    @Mock
    private ConnectorResponse connectorResponse;

    @Mock
    private BenefitsEntity benefitsEntity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ConnectorResponse.Data data = new ConnectorResponse.Data();
        InterDomainInfo interDomainInfo = new InterDomainInfo();
        AssociateInfo associateInfo = new AssociateInfo();
        Employment employment = new Employment();
        associateInfo.setEmployment(employment);
        interDomainInfo.setAssociateInfo(associateInfo);
        data.setQueryAssociateUpstreamDetails(interDomainInfo);
        employment.setOriginalHireDate("2025-01-01");
        EmploymentHistory employmentHistory = new EmploymentHistory();
        employmentHistory.setTermDate("2025-03-01");
        employment.setEmploymentHistory(List.of(employmentHistory));
        StoreInfo storeInfo = new StoreInfo();
        storeInfo.setStoreStateProvCd("CA");
        employment.setStoreInfo(storeInfo);
        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(List.of(planEligibility));

        when(delegateExecution.getVariable(CONNECTOR_RESPONSE)).thenReturn(connectorResponse);
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setAssociateId("123");
        associateBenefitsProfile.setEligibility(eligibility);
        when(delegateExecution.getVariable(GET_ASSOCIATE_PROFILE_RESPONSE)).thenReturn(associateBenefitsProfile);
        when(delegateExecution.getVariable(POST_PAYROLL_SNAPSHOTS)).thenReturn(List.of(postPayrollSnapshot));
        processor = new RetirementRehireRuleRequestProcessor(dataLakeJsonUtil);
        Map<String, Object> variables = Map.of(
                CONNECTOR_RESPONSE, connectorResponse,
                GET_ASSOCIATE_PROFILE_RESPONSE, associateBenefitsProfile,
                PLAN_TYPE_STR, PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(),
                ASSOCIATE_EVENT, AssociateEvent.builder().associateId("123").build(),
                BENEFITS_ENTITY, benefitsEntity
        );
        Map<String, List<Object>> dataLakeJson = Map.of(
                PROFILE_HUDI_JSON, List.of(associateBenefitsProfile),
                POST_PAYROLL_SNAPSHOT_HUDI_JSON, new ArrayList<>()
        );

        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(mock(IntraDomainInfo.class));
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);

        when(dataLakeJsonUtil.getDataFromCache(any())).thenReturn(dataLakeJson);
        when(delegateExecution.getVariables()).thenReturn(variables);
        when(connectorResponse.getData()).thenReturn(data);
        when(postPayrollSnapshot.getPayPeriodEndDate()).thenReturn("2025-12-31");
        when(postPayrollSnapshot.getPayrollSnapShot()).thenReturn(List.of(payrollSnapShot));
        when(payrollSnapShot.getPlanId()).thenReturn(RETIREMENT_POST_PAYROLL_ASSOCIATE_MATCH_PLAN_ID);
        when(payrollSnapShot.getEligibleHours()).thenReturn(100.0);
        when(planEligibility.getPlanId()).thenReturn(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId().toUpperCase());
        when(planEligibility.getOriginalHireDate()).thenReturn("2025-01-01");
        when(planEligibility.getIsPreviouslyCompanyMatchEligible()).thenReturn(true);
        when(planEligibility.getEligibleDate()).thenReturn("2025-01-01");
        when(planEligibility.getCompanyMatchEligibleDate()).thenReturn("2025-01-01");
    }

    @Test
    void testProcess_WithNullPlanEligibility() {
        when(delegateExecution.getVariable(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.REHIRE_INDICATOR_INPUT)).thenReturn(null);

        processor.process(delegateExecution);

        verify(delegateExecution, times(1)).setVariable(eq(ApplicationConstants.IS_REHIRE_REBASE), eq(true));
    }

    @Test
    void testUpdateEligibilityInputs_WithNullPlanEligibility() {
        processor.updateEligibilityInputs(delegateExecution, planEligibility, "2025-01-01", 100.0, 50.0, "2025-03-01");
        verify(delegateExecution, never()).setVariable(IS_REHIRE_REBASE, true);
    }

    @Test
    void testUpdateEligibilityInputs_WithNonNullAssociateEligibilityInput() {
        PlanEligibility currentPlanEligibility = new PlanEligibility();
        AssociateEligibilityInput associateEligibilityInput = new AssociateEligibilityInput();

        when(delegateExecution.getVariable(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(associateEligibilityInput);

        processor.updateEligibilityInputs(delegateExecution, currentPlanEligibility, "2025-01-01", 100.0, 50.0, "2025-03-01");

        verify(delegateExecution).setVariable(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT, associateEligibilityInput);
    }

    @Test
    void testUpdateEligibilityInputs_WithNonNullCompanyMatchEligibilityInput() {
        PlanEligibility currentPlanEligibility = new PlanEligibility();
        CompanyMatchEligibilityInput companyMatchEligibilityInput = new CompanyMatchEligibilityInput();

        when(delegateExecution.getVariable(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT)).thenReturn(companyMatchEligibilityInput);

        processor.updateEligibilityInputs(delegateExecution, currentPlanEligibility, "2025-01-01", 100.0, 50.0, "2025-03-01");

        verify(delegateExecution).setVariable(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT, companyMatchEligibilityInput);
    }

    @Test
    void testUpdateEligibilityInputs_WithRehireIndicatorInput() {
        PlanEligibility currentPlanEligibility = new PlanEligibility();
        RehireIndicatorInput rehireIndicatorInput = new RehireIndicatorInput();

        when(delegateExecution.getVariable(ApplicationConstants.REHIRE_INDICATOR_INPUT)).thenReturn(rehireIndicatorInput);

        processor.updateEligibilityInputs(delegateExecution, currentPlanEligibility, "2025-01-01", 100.0, 50.0, "2025-03-01");

        verify(delegateExecution).setVariable(ApplicationConstants.REHIRE_INDICATOR_INPUT, rehireIndicatorInput);
    }

    @Test
    void testUpdateEligibilityInputs_WithNullInputs() {
        PlanEligibility currentPlanEligibility = new PlanEligibility();

        when(delegateExecution.getVariable(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.REHIRE_INDICATOR_INPUT)).thenReturn(null);

        processor.updateEligibilityInputs(delegateExecution, currentPlanEligibility, "2025-01-01", 100.0, 50.0, "2025-03-01");

        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT), any());
        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT), any());
        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.REHIRE_INDICATOR_INPUT), any());
    }

    @Test
    void testProcess_WithNullInputs() {
        when(delegateExecution.getVariable(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.REHIRE_INDICATOR_INPUT)).thenReturn(null);

        processor.process(delegateExecution);

        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT), any());
        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.COMPANY_MATCH_ELIGIBILITY_INPUT), any());
        verify(delegateExecution, never()).setVariable(eq(ApplicationConstants.REHIRE_INDICATOR_INPUT), any());
    }

    @Test
    void testProcess_WithPayrollSnapshots() {
        when(postPayrollSnapshot.getPayPeriodEndDate()).thenReturn("2025-12-31");
        when(postPayrollSnapshot.getPayrollSnapShot()).thenReturn(List.of(payrollSnapShot));
        when(payrollSnapShot.getPlanId()).thenReturn(ApplicationConstants.RETIREMENT_POST_PAYROLL_ASSOCIATE_MATCH_PLAN_ID);
        when(payrollSnapShot.getEligibleHours()).thenReturn(100.0);

        processor.process(delegateExecution);

        verify(delegateExecution, atLeastOnce()).setVariable(anyString(), any());
    }
}