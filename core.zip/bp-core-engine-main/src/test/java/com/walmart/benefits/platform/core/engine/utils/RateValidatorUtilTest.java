package com.walmart.benefits.platform.core.engine.utils;

import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.interdomain.InterDomainInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.AssociateInfo;
import com.walmart.benefitsplatformentitymodel.interdomain.hr.PersonalInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.IntraDomainInfo;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Contribution;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.ContributionType;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RateValidatorUtilTest {

    private AssociateBenefitsProfile associateBenefitsProfile;
    private AssociateEvent associateEvent;
    private BenefitsEntity benefitsEntity;
    private AssociateBenefit associateBenefit;
    private IntraDomainInfo intraDomainInfo;

    @BeforeEach
    void setUp() {
        associateBenefitsProfile = mock(AssociateBenefitsProfile.class);
        associateEvent = mock(AssociateEvent.class);
        benefitsEntity = mock(BenefitsEntity.class);
        intraDomainInfo = mock(IntraDomainInfo.class);
        InterDomainInfo interDomainInfo = mock(InterDomainInfo.class);
        associateBenefit = mock(AssociateBenefit.class);
        AssociateInfo associateInfo = mock(AssociateInfo.class);
        PersonalInfo personalInfo = mock(PersonalInfo.class);
        when(associateInfo.getPersonalInfo()).thenReturn(personalInfo);
        when(interDomainInfo.getAssociateInfo()).thenReturn(associateInfo);
        when(benefitsEntity.getInterDomainInfo()).thenReturn(interDomainInfo);
        when(benefitsEntity.getIntraDomainInfo()).thenReturn(intraDomainInfo);
    }

    @Test
    void testIsPlanEligible() {
        Eligibility eligibility = mock(Eligibility.class);
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        planEligibility.setIsEligible(true);

        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        when(eligibility.getPlans()).thenReturn(List.of(planEligibility));
        when(associateEvent.getPlanType()).thenReturn(PlanType.valueOf(PlanType.RETIREMENT_401K_REGULAR_US.toString()));

        assertTrue(RateValidatorUtil.isPlanEligible(associateBenefitsProfile, associateEvent));
    }

    @Test
    void testIs401kRegularPlanAvailable() {
        Eligibility eligibility = mock(Eligibility.class);
        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(PlanType.RETIREMENT_401K_REGULAR_US.toString());
        planEligibility.setIsEligible(true);

        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        when(eligibility.getPlans()).thenReturn(List.of(planEligibility));

        assertTrue(RateValidatorUtil.is401kRegularPlanAvailable(associateBenefitsProfile, PlanType.RETIREMENT_401K_REGULAR_US.toString()));
    }

    @Test
    void testIsValidCoverage() {
        when(associateBenefit.getEndDate()).thenReturn(null);
        assertTrue(RateValidatorUtil.isValidCoverage(associateBenefit));

        when(associateBenefit.getEndDate()).thenReturn("2025-01-01");
        assertFalse(RateValidatorUtil.isValidCoverage(associateBenefit));
    }

    @Test
    void testIsBeyondMaxRateForCatchupPlan() {
        try (MockedStatic<EventUtils> mockedEventUtils = Mockito.mockStatic(EventUtils.class)) {
            // Arrange
            Contribution contribution = new Contribution();
            contribution.setValue(50.0);
            mockedEventUtils.when(() -> EventUtils.getContribution(anyMap())).thenReturn(contribution);

            AssociateBenefit benefit1 = mock(AssociateBenefit.class);
            Contribution contribution1 = new Contribution();
            contribution1.setValue(30.0);
            when(benefit1.getContribution()).thenReturn(contribution1);
            when(benefit1.getPlanId()).thenReturn("CatchupPlan1");

            AssociateBenefit benefit2 = mock(AssociateBenefit.class);
            Contribution contribution2 = new Contribution();
            contribution2.setValue(20.0);
            when(benefit2.getContribution()).thenReturn(contribution2);
            when(benefit2.getPlanId()).thenReturn("CatchupPlan2");

            List<AssociateBenefit> benefits = List.of(benefit1, benefit2);
            List<String> catchupPlans = List.of("CatchupPlan1", "CatchupPlan2");

            // Act
            boolean result = RateValidatorUtil.isBeyondMaxRateForCatchupPlan(
                    associateEvent, catchupPlans, "AnotherPlan", 75.0, benefits);

            // Assert
            assertTrue(result);
        }

    }

    @Test
    void testIsBeyondMaxRateForRegularPlan() {
            Contribution associateContribution = mock(Contribution.class);
            when(associateContribution.getValue()).thenReturn(60.0);
            when(associateContribution.getType()).thenReturn(ContributionType.PERCENT);
            Map<String, Object> additionalInfo = Map.of("contribution", associateContribution);
            when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);
            when(associateEvent.getAdditionalInfo()).thenReturn(additionalInfo);

            AssociateBenefit benefit = mock(AssociateBenefit.class);
            Contribution contribution = mock(Contribution.class);
            contribution.setValue(15.0);
            when(benefit.getContribution()).thenReturn(contribution);
            when(benefit.getPlanId()).thenReturn("RegularPlan");

            List<AssociateBenefit> benefits = List.of(benefit);
            List<String> regularPlans = List.of("RegularPlan");

            assertTrue(RateValidatorUtil.isBeyondMaxRateForRegularPlan(associateEvent, regularPlans, "AnotherPlan", 50, benefits));
    }

    @Test
    void testIsCatchupEligibleAge() {
        try (MockedStatic<ConverterUtil> mockedConverterUtil = Mockito.mockStatic(ConverterUtil.class)) {
            mockedConverterUtil.when(() -> ConverterUtil.convertStringToDate(anyString()))
                    .thenReturn(LocalDate.of(1960, 1, 1));

            when(benefitsEntity.getInterDomainInfo().getAssociateInfo().getPersonalInfo().getBirthDate())
                    .thenReturn("1960-01-01");

            assertTrue(RateValidatorUtil.isCatchupEligibleAge(benefitsEntity, 55));
        }
    }

    @Test
    void testIsCatchupPlan() {
        PlanType planType = PlanType.RETIREMENT_401K_CATCHUP_REGULAR_US;
        when(associateEvent.getPlanType()).thenReturn(planType);
        List<String> catchupPlan = Arrays.asList(PlanType.RETIREMENT_401K_CATCHUP_REGULAR_US.getPlanId(),
                PlanType.RETIREMENT_401K_CATCHUP_ROTH_US.getPlanId());

        boolean result = RateValidatorUtil.isCatchupPlan(associateEvent, catchupPlan);

        assertTrue(result);
    }

    @Test
    void testIsRegularPlan() {
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        when(associateEvent.getPlanType()).thenReturn(planType);
        List<String> regularPlan = Arrays.asList(PlanType.RETIREMENT_401K_REGULAR_US.getPlanId(),
                PlanType.RETIREMENT_401K_ROTH_US.getPlanId());

        boolean result = RateValidatorUtil.isRegularPlan(associateEvent, regularPlan);

        assertTrue(result);
    }

    @Test
    void testIsValidRuleEligibility() {
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        when(associateEvent.getPlanType()).thenReturn(planType);

        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId(planType.getPlanId());
        planEligibility.setIsEligible(true);
        planEligibility.setEligibleDate(String.valueOf(LocalDate.now()));

        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(List.of(planEligibility));
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);
        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);

        boolean result = RateValidatorUtil.isValidRuleEligibility(associateEvent, benefitsEntity);

        assertTrue(result);
    }

    @Test
    void testIsValidRuleEligibilityWithIneligiblePlan() {
        PlanType planType = PlanType.RETIREMENT_401K_REGULAR_US;
        when(associateEvent.getPlanType()).thenReturn(planType);

        PlanEligibility planEligibility = new PlanEligibility();
        planEligibility.setPlanId("plan1");
        planEligibility.setIsEligible(false);
        planEligibility.setEligibleDate(String.valueOf(LocalDate.now()));

        Eligibility eligibility = new Eligibility();
        eligibility.setPlans(List.of(planEligibility));
        when(associateBenefitsProfile.getEligibility()).thenReturn(eligibility);

        when(benefitsEntity.getIntraDomainInfo().getAssociateBenefitsProfile()).thenReturn(associateBenefitsProfile);

        boolean result = RateValidatorUtil.isValidRuleEligibility(associateEvent, benefitsEntity);

        assertFalse(result);
    }
}
