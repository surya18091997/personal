package com.walmart.benefits.platform.core.engine.processors.event;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.processors.event.retirement.RetirementTerminationEventProcessor;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventOrigin;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.AssociateBenefit;
import com.walmart.benefitsplatformentitymodel.intradomain.associatebenefit.Contribution;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RetirementTerminationEventProcessorTest {

    @InjectMocks
    private RetirementTerminationEventProcessor terminationEventProcessor;

    @Mock
    private DelegateExecution delegateExecution;

    private AssociateBenefitsProfile getProfile() {
        AssociateBenefitsProfile associateBenefitsProfile = new AssociateBenefitsProfile();
        associateBenefitsProfile.setEligibility(new Eligibility());
        associateBenefitsProfile.getEligibility().setPlans(new ArrayList<>());
        associateBenefitsProfile.getEligibility().getPlans().add(new PlanEligibility());

        return associateBenefitsProfile;
    }

    private AssociateEvent getEvent() {
        AssociateEvent event = new AssociateEvent();
        event.setEventType(EventType.TERMINATION);
        event.setOrigin(EventOrigin.CORE_HR);
        return event;
    }

    @Test
    void testProcess() {
        AssociateBenefit coverage = new AssociateBenefit();
        coverage.setEndDate(null);
        coverage.setPlanId("roth_%s_us".formatted(_401K));
        Contribution contribution = new Contribution();
        contribution.setValue(10.0);
        coverage.setContribution(contribution);
        Map<String, Object> variables = new HashMap<>();
        variables.put(GET_ASSOCIATE_PROFILE_RESPONSE, getProfile());
        variables.put(COVERAGE_RESPONSE_LIST, List.of(coverage));
        variables.put(ASSOCIATE_EVENT, getEvent());
        when(delegateExecution.getVariables()).thenReturn(variables);
        terminationEventProcessor.process(delegateExecution);
        verify(delegateExecution).setVariables(variables);
    }

    @Test
    void testUpdateCoverages() {
        AssociateBenefit coverage = new AssociateBenefit();
        coverage.setPlanId("roth_%s_us".formatted(_401K));
        coverage.setEndDate(null);
        Contribution contribution = new Contribution();
        contribution.setValue(10.0);
        coverage.setContribution(contribution);
        List<AssociateBenefit> associateBenefits = new ArrayList<>();
        associateBenefits.add(coverage);
        Map<String, Object> variables = new HashMap<>();
        variables.put(COVERAGE_RESPONSE_LIST, associateBenefits);
        variables.put(ASSOCIATE_EVENT, getEvent());
        ReflectionTestUtils.invokeMethod(terminationEventProcessor, "updateCoverages", variables);
        assertEquals(10.0, coverage.getContribution().getValue());
    }

    @Test
    void testGetEventType() {
        EventType eventType = terminationEventProcessor.getEventType();
        assertEquals(EventType.TERMINATION, eventType);
    }

    @Test
    void testGetPlanType() {
        String planType = terminationEventProcessor.getPlanType();
        assertEquals(ApplicationConstants.RETIREMENT, planType);
    }
}
