package com.walmart.benefits.platform.core.engine.processors.rulerequest.disability;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.processors.rulerequest.DefaultEnrollmentCompleteRuleRequestProcessor;
import com.walmart.benefits.platform.core.engine.utils.CommonUtils;
import com.walmart.benefits.platform.core.engine.utils.ConverterUtil;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityInput;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.AssociateEvent;
import com.walmart.benefitsplatformentitymodel.intradomain.associateEvent.EventType;
import com.walmart.benefitsplatformentitymodel.intradomain.enrollment.Enrollment;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.AssociateBenefitsProfile;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.Eligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.profile.PlanEligibility;
import com.walmart.benefitsplatformentitymodel.intradomain.transactionLog.Activity;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.*;
import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.ASSOCIATE_ELIGIBILITY_INPUT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DisabilityNewHireRuleRequestProcessorTest {


    private DisabilityNewHireRuleRequestProcessor processor;
    private DelegateExecution delegateExecution;

    @BeforeEach
    void setUp() {
        delegateExecution = mock(DelegateExecution.class);
        processor = new DisabilityNewHireRuleRequestProcessor();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testProcess() {
        Map<String, Object> variables = new HashMap<>();
        AssociateEligibilityInput associateEligibilityInput = new AssociateEligibilityInput();
        AssociateEvent associateEvent = new AssociateEvent();
        associateEvent.setEventType(EventType.NEW_HIRE);
        variables.put(ASSOCIATE_ELIGIBILITY_INPUT,associateEligibilityInput );
        variables.put(ASSOCIATE_EVENT,associateEvent);

        when(delegateExecution.getVariables()).thenReturn(variables);

        processor.process(delegateExecution);

        assertEquals(EventType.NEW_HIRE.name().toUpperCase(),associateEligibilityInput.getChangeActivity());

    }



    @Test
    void testGetEventType() {
        assertEquals(EventType.NEW_HIRE, processor.getEventType());
    }

    @Test
    void testPlanType() {
        assertEquals(DISABILITY, processor.getPlanType());
    }
}