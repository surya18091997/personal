package com.walmart.benefits.platform.core.engine.service.common;

import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.RuleExecutorProcessor;
import com.walmart.benefits.platform.core.engine.processors.ruleexecutor.RuleExecutorProcessorFactory;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.walmart.benefits.platform.core.engine.constants.ApplicationConstants.PLAN_TYPE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CoreRuleExecutorServiceTest {

    @Mock
    private RuleExecutorProcessorFactory ruleExecutorProcessorFactory;

    @Mock
    private DelegateExecution delegateExecution;

    @Mock
    private RuleExecutorProcessor ruleExecutorProcessor;

    private CoreRuleExecutorService coreRuleExecutorService;

    @BeforeEach
    void setUp() {
        coreRuleExecutorService = new CoreRuleExecutorService(ruleExecutorProcessorFactory);
    }

    @Test
    void testExecute() throws Exception {
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn("planType1");
        when(ruleExecutorProcessorFactory.getProcessor(any())).thenReturn(ruleExecutorProcessor);

        coreRuleExecutorService.execute(delegateExecution);

        verify(delegateExecution).getVariable(PLAN_TYPE);
        verify(ruleExecutorProcessorFactory).getProcessor(any());
        verify(ruleExecutorProcessor).process(delegateExecution);
    }

    @Test
    void shouldHandleExceptionWhenRuleExecutionFails() throws Exception {
        when(delegateExecution.getVariable(PLAN_TYPE)).thenReturn("planType1");
        when(ruleExecutorProcessorFactory.getProcessor(any())).thenReturn(ruleExecutorProcessor);
        doThrow(new RuntimeException("test exception")).when(ruleExecutorProcessor).process(any());
        BpmnError thrown = assertThrows(
                BpmnError.class,
                () -> coreRuleExecutorService.execute(delegateExecution),
                "Expected process to throw, but it didn't"
        );
        assertTrue(thrown.getMessage().contains("test exception"));
    }
}