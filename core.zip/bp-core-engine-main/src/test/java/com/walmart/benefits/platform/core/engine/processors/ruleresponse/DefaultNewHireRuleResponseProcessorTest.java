package com.walmart.benefits.platform.core.engine.processors.ruleresponse;

import com.walmart.benefits.platform.core.engine.constants.ApplicationConstants;
import com.walmart.benefits.platform.core.engine.utils.EventUtils;
import com.walmart.benefits.rules.benefitsrulessdk.models.rulecategory.associateeligibility.AssociateEligibilityOutput;
import com.walmart.benefitsplatformentitymodel.BenefitsEntity;
import com.walmart.benefitsplatformentitymodel.intradomain.planconfig.PlanType;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Answers;
import org.mockito.MockedStatic;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DefaultNewHireRuleResponseProcessorTest {

    private DefaultNewHireRuleResponseProcessor processor;
    private DelegateExecution delegateExecution;
    private BenefitsEntity benefitsEntity;
    private AssociateEligibilityOutput associateEligibilityOutput;
    private MockedStatic<EventUtils> eventUtilsMock;

    @BeforeEach
    void setUp() {
        processor = new DefaultNewHireRuleResponseProcessor();
        eventUtilsMock = mockStatic(EventUtils.class);
        delegateExecution = mock(DelegateExecution.class);
        benefitsEntity = new BenefitsEntity();
        associateEligibilityOutput = new AssociateEligibilityOutput();
    }

    @AfterEach
    void tearDown() {
        eventUtilsMock.close();
    }

    @Test
    void process_withValidPlanTypeAndEligibilityUpdated() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.DISABILITY_STD_US.name());
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        associateEligibilityOutput.setIsEligibilityUpdated(true);


        eventUtilsMock.when(() -> EventUtils.setPlanEligibility(associateEligibilityOutput, PlanType.DISABILITY_STD_US, benefitsEntity)).thenAnswer(invocation -> null);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
    }

    @Test
    void process_withValidPlanTypeAndEligibilityNotUpdated() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(PlanType.DISABILITY_STD_US.name());
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);
        associateEligibilityOutput.setIsEligibilityUpdated(false);

        processor.process(delegateExecution);

        verify(delegateExecution).setVariable(ApplicationConstants.BENEFITS_ENTITY, benefitsEntity);
    }

    @Test
    void process_withNullPlanType() {
        when(delegateExecution.getVariable(ApplicationConstants.BENEFITS_ENTITY)).thenReturn(benefitsEntity);
        when(delegateExecution.getVariable(ApplicationConstants.PLAN_TYPE_STR)).thenReturn(null);
        when(delegateExecution.getVariable(ApplicationConstants.RULE_RESPONSE)).thenReturn(associateEligibilityOutput);

        assertThrows(NullPointerException.class, () -> processor.process(delegateExecution));
    }

    @Test
    void getPlanType_returnsNull() {
        assertNull(processor.getPlanType());
    }
}